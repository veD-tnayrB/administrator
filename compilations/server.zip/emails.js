"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.registeredUserTemplate=exports.passwordRecovered=exports.mailer=exports.hmr=exports.forgetPasswordTemplate=exports.__beyond_pkg=exports.IRegisteredUserPayload=exports.IPasswordRecoveryTemplate=exports.IForgetPasswordTemplate=void 0;var dependency_0=require("@beyond-js/kernel/bundle"),dependency_1=require("nodemailer"),dependency_2=require("dotenv");const __Bundle=dependency_0.Bundle,__pkg=new __Bundle({module:{vspecifier:"@essential-js/admin-server@0.0.1/emails"},type:"ts"}).package(),ims=(__pkg.dependencies.update([["nodemailer",dependency_1],["dotenv",dependency_2]]),new Map);ims.set("./index",{hash:1041658464,creator:function(e,r){Object.defineProperty(r,"__esModule",{value:!0}),r.mailer=void 0,e=e("nodemailer"),r.mailer=e.createTransport({host:process.env.MAILER_HOST,port:process.env.MAILER_PORT,secure:!0,auth:{user:process.env.MAILER_FROM,pass:process.env.MAILER_PASS}})}}),ims.set("./templates/forget-password/forget-password",{hash:336132759,creator:function(e,r){Object.defineProperty(r,"__esModule",{value:!0}),r.forgetPasswordTemplate=void 0;const s=process.env.COMPANY_NAME||"Essential";r.forgetPasswordTemplate=({url:e,names:r,lastNames:o})=>({html:`
<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: hsl(210, 40%, 96%);
            margin: 0;
            padding: 0;
        }
        .container {
            width: 100%;
            background-color: #fff;
            margin: 0 auto;
            padding: 20px;
            color: #67727e;
        }
        .header {
            background-color: #1d7a90;
            color: #fff;
            padding: 20px 20px;
            text-align: center;
        }
        .content {
            padding: 20px;
            text-align: left;
            line-height: 1.5;
        }
        .footer {
            background-color: #fff;
            padding: 10px 20px;
            text-align: center;
            border-top: 1px solid #67727e;
        }
        .button {
            background-color: #1d7a90; /* Primary color */
            color: white !important;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
        }
        img.logo {
            max-width: 100px;
            margin-bottom: 10px;
        }
        .actionable {
            text-align: center;    
        }
    </style>
</head>
<body>
    <table class="container" width="100%" cellspacing="0" cellpadding="0">
        <tr>
            <td class="header">
                <h1>Password Recovery</h1>
            </td>
        </tr>
        <tr>
            <td class="content">
                <p>Hello, ${r} ${o}</p>
                <p>You have requested the recovery of your account. Please click on the link below to proceed with the process:</p>
                <div class="actionable">
                    <a href="${e}" class="button">Reset Password</a>
                </div>
                <p>If you have any questions or need assistance, please contact our support team.</p>
            </td>
        </tr>
        <tr>
            <td class="footer">
                &copy; ${s} | All Rights Reserved
            </td>
        </tr>
    </table>
</body>
</html>`,subject:"Reset Password"})}}),ims.set("./templates/forget-password/password-recovered",{hash:2984749907,creator:function(e,r){Object.defineProperty(r,"__esModule",{value:!0}),r.passwordRecovered=void 0;const o=process.env.COMPANY_NAME||"Essential";r.passwordRecovered=({names:e,lastNames:r})=>({html:`
<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: hsl(210, 40%, 96%);
            margin: 0;
            padding: 0;
        }
        .container {
            width: 100%;
            background-color: #fff;
            margin: 0 auto;
            padding: 20px;
            color: #67727e;
        }
        .header {
            background-color: #1d7a90;
            color: #fff;
            padding: 20px 20px;
            text-align: center;
        }
        .content {
            padding: 20px;
            text-align: left;
            line-height: 1.5;
        }
        .footer {
            background-color: #fff;
            padding: 10px 20px;
            text-align: center;
            border-top: 1px solid #67727e;
        }
        .button {
            background-color: #1d7a90; /* Primary color */
            color: white !important;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
        }
        img.logo {
            max-width: 100px;
            margin-bottom: 10px;
        }
        
    </style>
</head>
<body>
    <table class="container" width="100%" cellspacing="0" cellpadding="0">
        <tr>
            <td class="header">
                <h1>Password Recovered</h1>
            </td>
        </tr>
        <tr>
            <td class="content">
                <p>Hello, ${e} ${r}</p>
                <p>Your password was successfully updated</p>
                <p>If you have any questions or need assistance, please contact our support team.</p>
            </td>
        </tr>
        <tr>
            <td class="footer">
                &copy; ${o} | All Rights Reserved
            </td>
        </tr>
    </table>
</body>
</html>
`,subject:"Password Successfully Recovered"})}}),ims.set("./templates/registered-user",{hash:47188197,creator:function(e,r){Object.defineProperty(r,"__esModule",{value:!0}),r.registeredUserTemplate=void 0,e("dotenv").config();const s=process.env.COMPANY_NAME||"Essential";process.env.COMPANY_LOGO,r.registeredUserTemplate=({names:e,lastNames:r,password:o})=>({html:`
<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: hsl(210, 40%, 96%);
            margin: 0;
            padding: 0;
        }
        .container {
            width: 100%;
            background-color: #fff;
            margin: 0 auto;
            padding: 20px;
            color: #67727e;
        }
        .header {
            background-color: #1d7a90;
            color: #fff;
            padding: 20px 20px;
            text-align: center;
        }
        .content {
            padding: 20px;
            text-align: left;
            line-height: 1.5;
        }
        .footer {
            background-color: #fff;
            padding: 10px 20px;
            text-align: center;
            border-top: 1px solid #67727e;
        }
        img.logo {
            max-width: 100px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <table class="container" width="100%" cellspacing="0" cellpadding="0">
        <tr>
            <td class="header">
                <h1>Successful Registration</h1>
            </td>
        </tr>
        <tr>
            <td class="content">
                <p>Hello, ${e} ${r}</p>
                <p>Your account has been successfully created in our system! Here are your account details so you can access our services:</p>
                <p><strong>Password:</strong> ${o}</p>
                <p>We recommend changing your password at your first login for security reasons.</p>
                <p>If you have any questions or need assistance, please contact our support team.</p>
            </td>
        </tr>
        <tr>
            <td class="footer">
                &copy; ${s} | All Rights Reserved
            </td>
        </tr>
    </table>
</body>
</html>
	`,subject:"Successful Registration"})}}),__pkg.exports.descriptor=[{im:"./index",from:"mailer",name:"mailer"},{im:"./templates/forget-password/forget-password",from:"IForgetPasswordTemplate",name:"IForgetPasswordTemplate"},{im:"./templates/forget-password/forget-password",from:"forgetPasswordTemplate",name:"forgetPasswordTemplate"},{im:"./templates/forget-password/password-recovered",from:"IPasswordRecoveryTemplate",name:"IPasswordRecoveryTemplate"},{im:"./templates/forget-password/password-recovered",from:"passwordRecovered",name:"passwordRecovered"},{im:"./templates/registered-user",from:"IRegisteredUserPayload",name:"IRegisteredUserPayload"},{im:"./templates/registered-user",from:"registeredUserTemplate",name:"registeredUserTemplate"}];let mailer=exports.mailer=void 0,IForgetPasswordTemplate=exports.IForgetPasswordTemplate=void 0,forgetPasswordTemplate=exports.forgetPasswordTemplate=void 0,IPasswordRecoveryTemplate=exports.IPasswordRecoveryTemplate=void 0,passwordRecovered=exports.passwordRecovered=void 0,IRegisteredUserPayload=exports.IRegisteredUserPayload=void 0,registeredUserTemplate=exports.registeredUserTemplate=void 0;__pkg.exports.process=function({require:e,prop:r,value:o}){!e&&"mailer"!==r||(exports.mailer=mailer=e?e("./index").mailer:o),!e&&"IForgetPasswordTemplate"!==r||(exports.IForgetPasswordTemplate=IForgetPasswordTemplate=e?e("./templates/forget-password/forget-password").IForgetPasswordTemplate:o),!e&&"forgetPasswordTemplate"!==r||(exports.forgetPasswordTemplate=forgetPasswordTemplate=e?e("./templates/forget-password/forget-password").forgetPasswordTemplate:o),!e&&"IPasswordRecoveryTemplate"!==r||(exports.IPasswordRecoveryTemplate=IPasswordRecoveryTemplate=e?e("./templates/forget-password/password-recovered").IPasswordRecoveryTemplate:o),!e&&"passwordRecovered"!==r||(exports.passwordRecovered=passwordRecovered=e?e("./templates/forget-password/password-recovered").passwordRecovered:o),!e&&"IRegisteredUserPayload"!==r||(exports.IRegisteredUserPayload=IRegisteredUserPayload=e?e("./templates/registered-user").IRegisteredUserPayload:o),!e&&"registeredUserTemplate"!==r||(exports.registeredUserTemplate=registeredUserTemplate=e?e("./templates/registered-user").registeredUserTemplate:o)};const __beyond_pkg=exports.__beyond_pkg=__pkg,hmr=exports.hmr=new function(){this.on=(e,r)=>__pkg.hmr.on(e,r),this.off=(e,r)=>__pkg.hmr.off(e,r)};__pkg.initialise(ims);