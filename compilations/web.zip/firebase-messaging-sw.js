importScripts('https://www.gstatic.com/firebasejs/10.6.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.6.0/firebase-messaging-compat.js');

const config = {
  apiKey: "AIzaSyBBzfRyTyHpGuHPzxgjMU7-UVRCgOjbTdU",
  authDomain: "essential-dashboard-f53e3.firebaseapp.com",
  projectId: "essential-dashboard-f53e3",
  storageBucket: "essential-dashboard-f53e3.appspot.com",
  messagingSenderId: "360770243838",
  appId: "1:360770243838:web:742b9b18602aac2b9d69af",
  measurementId: "G-2MC15ZNZ1D"
};

const app = self.firebase.initializeApp(config);
const messaging = self.firebase.messaging(app);
