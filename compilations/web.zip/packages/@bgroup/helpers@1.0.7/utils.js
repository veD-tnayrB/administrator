System.register(["@beyond-js/kernel@0.1.9/bundle","@bgroup/helpers@1.0.7/md5"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["@beyond-js/kernel","0.1.9"],["@bgroup/helpers","1.0.7"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('@beyond-js/kernel@0.1.9/bundle', dep), dep => dependencies.set('@bgroup/helpers@1.0.7/md5', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
  value: mod,
  enumerable: true
}) : target, mod));
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/@bgroup/helpers/utils.1.0.7.js
var utils_1_0_7_exports = {};
__export(utils_1_0_7_exports, {
  Utils: () => Utils,
  __beyond_pkg: () => __beyond_pkg,
  hmr: () => hmr
});
module.exports = __toCommonJS(utils_1_0_7_exports);

// node_modules/@bgroup/helpers/utils/utils.browser.mjs
var dependency_0 = __toESM(require("@beyond-js/kernel@0.1.9/bundle"), 0);
var dependency_1 = __toESM(require("@bgroup/helpers@1.0.7/md5"), 0);
var import_meta = {};
var {
  Bundle: __Bundle
} = dependency_0;
var __pkg = new __Bundle({
  "module": {
    "vspecifier": "@bgroup/helpers@1.0.7/utils"
  },
  "type": "ts"
}, _context.meta.url).package();
;
__pkg.dependencies.update([["@bgroup/helpers/md5", dependency_1]]);
var ims = /* @__PURE__ */new Map();
ims.set("./index", {
  hash: 2989037873,
  creator: function (require2, exports) {
    "use strict";

    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.Utils = void 0;
    var _md = require2("@bgroup/helpers/md5");
    class Model {
      generateToken(length, onlyNumbers) {
        let result = "";
        const characters = onlyNumbers ? "0123456789" : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        const charactersLength = characters.length;
        for (let i = 0; i < length; i++) {
          result += characters.charAt(Math.floor(Math.random() * charactersLength));
        }
        return result;
      }
      md5(str) {
        return (0, _md.MD5)(str);
      }
      toCamelCase(key) {
        const keyArray = key.split(/\_/.test(key) ? "_" : "-");
        for (let i = 0; i < keyArray.length; i++) {
          if (i === 0) {
            keyArray[i] = keyArray[i].toLowerCase();
            continue;
          }
          keyArray[i] = keyArray[i].replace(/(^|\s)\S/g, letter => letter.toUpperCase());
        }
        return keyArray.join("");
      }
      toUnderscore(key) {
        const keyArray = key.split("");
        for (let i = 0; i < keyArray.length; i++) {
          if (keyArray[i] === keyArray[i].toUpperCase()) keyArray.splice(i++, 0, "_");
        }
        return keyArray.join("").toLowerCase();
      }
      objectProcessor(data, fn) {
        const newObject = {};
        let newKey = "";
        for (let key in data) {
          newKey = fn(key);
          const value = data[key];
          newObject[newKey] = value && typeof value === "object" && !["time_created", "time_updated", "date_created", "date_estimate"].includes(key) ? this.objectProcessor(data[key], fn) : value;
        }
        return newObject;
      }
      underscoreToCamelCase(data) {
        return this.objectProcessor(data, this.toCamelCase);
      }
      camelCaseToUnderscore(data) {
        return this.objectProcessor(data, this.toUnderscore);
      }
      processAdditional(item, model) {
        const record = {};
        for (const key in item) {
          const isField = model.rawAttributes.hasOwnProperty(key);
          if (isField) record[key] = item.dataValues[key];
        }
        return record;
      }
      processQueryItem(item, model, additionalAttributes, additionalModels) {
        const record = {};
        for (let key in item.dataValues) {
          const isField = model.rawAttributes.hasOwnProperty(key);
          const isAdditional = additionalAttributes?.length && additionalAttributes.includes(key) && additionalModels?.length;
          if (isField || isAdditional) {
            const itemValue = item.dataValues[key];
            if (!isAdditional) record[key] = itemValue;else {
              const modelIndex = additionalAttributes.indexOf(key);
              if (modelIndex < 0) continue;
              const additionalModel = additionalModels[modelIndex];
              record[key] = this.processAdditional(itemValue, additionalModel);
            }
          }
        }
        return record;
      }
      processQueryArray(data, model, additionalAttributes, additionalModel) {
        return data.map(item => this.processQueryItem(item, model, additionalAttributes, additionalModel));
      }
      processItems(data) {
        return data.map(item => this.underscoreToCamelCase(item));
      }
      convertObjectToQuery = object => {
        if (typeof object !== "object") throw "PARAM MUST BE AN OBJECT";
        let query = "";
        Object.entries(object).forEach(([key, value], index) => {
          value = typeof value === "object" ? JSON.stringify(value) : value;
          if (index === 0) return query += `?${key}=${value}`;
          query += `&${key}=${value}`;
        });
        return query;
      };
    }
    const Utils2 = exports.Utils = new Model();
  }
});
__pkg.exports.descriptor = [{
  "im": "./index",
  "from": "Utils",
  "name": "Utils"
}];
var Utils;
__pkg.exports.process = function ({
  require: require2,
  prop,
  value
}) {
  (require2 || prop === "Utils") && (Utils = require2 ? require2("./index").Utils : value);
};
var __beyond_pkg = __pkg;
var hmr = new function () {
  this.on = (event, listener) => void 0;
  this.off = (event, listener) => void 0;
}();
__pkg.initialise(ims);
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL0BiZ3JvdXAvaGVscGVycy91dGlscy4xLjAuNy5qcyIsIi4uL25vZGVfbW9kdWxlcy9AYmdyb3VwL2hlbHBlcnMvdXRpbHMvX19zb3VyY2VzL3V0aWxzL2luZGV4LnRzIl0sIm5hbWVzIjpbInV0aWxzXzFfMF83X2V4cG9ydHMiLCJfX2V4cG9ydCIsIlV0aWxzIiwiX19iZXlvbmRfcGtnIiwiaG1yIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsIl9tZCIsInJlcXVpcmUyIiwiTW9kZWwiLCJnZW5lcmF0ZVRva2VuIiwibGVuZ3RoIiwib25seU51bWJlcnMiLCJyZXN1bHQiLCJjaGFyYWN0ZXJzIiwiY2hhcmFjdGVyc0xlbmd0aCIsImkiLCJjaGFyQXQiLCJNYXRoIiwiZmxvb3IiLCJyYW5kb20iLCJtZDUiLCJzdHIiLCJNRDUiLCJ0b0NhbWVsQ2FzZSIsImtleSIsImtleUFycmF5Iiwic3BsaXQiLCJ0ZXN0IiwidG9Mb3dlckNhc2UiLCJyZXBsYWNlIiwibGV0dGVyIiwidG9VcHBlckNhc2UiLCJqb2luIiwidG9VbmRlcnNjb3JlIiwic3BsaWNlIiwib2JqZWN0UHJvY2Vzc29yIiwiZGF0YSIsImZuIiwibmV3T2JqZWN0IiwibmV3S2V5IiwidmFsdWUiLCJpbmNsdWRlcyIsInVuZGVyc2NvcmVUb0NhbWVsQ2FzZSIsImNhbWVsQ2FzZVRvVW5kZXJzY29yZSIsInByb2Nlc3NBZGRpdGlvbmFsIiwiaXRlbSIsIm1vZGVsIiwicmVjb3JkIiwiaXNGaWVsZCIsInJhd0F0dHJpYnV0ZXMiLCJoYXNPd25Qcm9wZXJ0eSIsImRhdGFWYWx1ZXMiLCJwcm9jZXNzUXVlcnlJdGVtIiwiYWRkaXRpb25hbEF0dHJpYnV0ZXMiLCJhZGRpdGlvbmFsTW9kZWxzIiwiaXNBZGRpdGlvbmFsIiwiaXRlbVZhbHVlIiwibW9kZWxJbmRleCIsImluZGV4T2YiLCJhZGRpdGlvbmFsTW9kZWwiLCJwcm9jZXNzUXVlcnlBcnJheSIsIm1hcCIsInByb2Nlc3NJdGVtcyIsImNvbnZlcnRPYmplY3RUb1F1ZXJ5Iiwib2JqZWN0IiwicXVlcnkiLCJPYmplY3QiLCJlbnRyaWVzIiwiZm9yRWFjaCIsImluZGV4IiwiSlNPTiIsInN0cmluZ2lmeSIsIlV0aWxzMiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsbUJBQUE7QUFBQUMsUUFBQSxDQUFBRCxtQkFBQTtFQUFBRSxLQUFBLEVBQUFBLENBQUEsS0FBQUEsS0FBQTtFQUFBQyxZQUFBLEVBQUFBLENBQUEsS0FBQUEsWUFBQTtFQUFBQyxHQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCxtQkFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0lDQUEsSUFBQVEsR0FBQSxHQUFBQyxRQUFBO0lBYUEsTUFBTUMsS0FBQSxDQUFLO01BQ1ZDLGNBQWNDLE1BQUEsRUFBY0MsV0FBQSxFQUFpQjtRQUM1QyxJQUFJQyxNQUFBLEdBQWlCO1FBQ3JCLE1BQU1DLFVBQUEsR0FBcUJGLFdBQUEsR0FDeEIsZUFDQTtRQUNILE1BQU1HLGdCQUFBLEdBQTJCRCxVQUFBLENBQVdILE1BQUE7UUFDNUMsU0FBU0ssQ0FBQSxHQUFZLEdBQUdBLENBQUEsR0FBSUwsTUFBQSxFQUFRSyxDQUFBLElBQUs7VUFDeENILE1BQUEsSUFBVUMsVUFBQSxDQUFXRyxNQUFBLENBQU9DLElBQUEsQ0FBS0MsS0FBQSxDQUFNRCxJQUFBLENBQUtFLE1BQUEsQ0FBTSxJQUFLTCxnQkFBZ0IsQ0FBQzs7UUFFekUsT0FBT0YsTUFBQTtNQUNSO01BRUFRLElBQUlDLEdBQUEsRUFBRztRQUNOLFFBQU8sR0FBQWYsR0FBQSxDQUFBZ0IsR0FBQSxFQUFJRCxHQUFHO01BQ2Y7TUFFQUUsWUFBWUMsR0FBQSxFQUFXO1FBQ3RCLE1BQU1DLFFBQUEsR0FBdUJELEdBQUEsQ0FBSUUsS0FBQSxDQUFNLEtBQUtDLElBQUEsQ0FBS0gsR0FBRyxJQUFJLE1BQU0sR0FBRztRQUNqRSxTQUFTVCxDQUFBLEdBQUksR0FBR0EsQ0FBQSxHQUFJVSxRQUFBLENBQVNmLE1BQUEsRUFBUUssQ0FBQSxJQUFLO1VBQ3pDLElBQUlBLENBQUEsS0FBTSxHQUFHO1lBQ1pVLFFBQUEsQ0FBU1YsQ0FBQSxJQUFLVSxRQUFBLENBQVNWLENBQUEsRUFBR2EsV0FBQSxDQUFXO1lBQ3JDOztVQUVESCxRQUFBLENBQVNWLENBQUEsSUFBS1UsUUFBQSxDQUFTVixDQUFBLEVBQUdjLE9BQUEsQ0FBUSxhQUFjQyxNQUFBLElBQW1CQSxNQUFBLENBQU9DLFdBQUEsQ0FBVyxDQUFFOztRQUV4RixPQUFPTixRQUFBLENBQVNPLElBQUEsQ0FBSyxFQUFFO01BQ3hCO01BRUFDLGFBQWFULEdBQUEsRUFBVztRQUN2QixNQUFNQyxRQUFBLEdBQXVCRCxHQUFBLENBQUlFLEtBQUEsQ0FBTSxFQUFFO1FBQ3pDLFNBQVNYLENBQUEsR0FBSSxHQUFHQSxDQUFBLEdBQUlVLFFBQUEsQ0FBU2YsTUFBQSxFQUFRSyxDQUFBLElBQUs7VUFDekMsSUFBSVUsUUFBQSxDQUFTVixDQUFBLE1BQU9VLFFBQUEsQ0FBU1YsQ0FBQSxFQUFHZ0IsV0FBQSxDQUFXLEdBQUlOLFFBQUEsQ0FBU1MsTUFBQSxDQUFPbkIsQ0FBQSxJQUFLLEdBQUcsR0FBRzs7UUFFM0UsT0FBT1UsUUFBQSxDQUFTTyxJQUFBLENBQUssRUFBRSxFQUFFSixXQUFBLENBQVc7TUFDckM7TUFFQU8sZ0JBQWdCQyxJQUFBLEVBQWNDLEVBQUEsRUFBTztRQUNwQyxNQUFNQyxTQUFBLEdBQW9CO1FBQzFCLElBQUlDLE1BQUEsR0FBaUI7UUFDckIsU0FBU2YsR0FBQSxJQUFPWSxJQUFBLEVBQU07VUFDckJHLE1BQUEsR0FBU0YsRUFBQSxDQUFHYixHQUFHO1VBQ2YsTUFBTWdCLEtBQUEsR0FBUUosSUFBQSxDQUFLWixHQUFBO1VBQ25CYyxTQUFBLENBQVVDLE1BQUEsSUFDVEMsS0FBQSxJQUNDLE9BQU9BLEtBQUEsS0FBVSxZQUNqQixDQUFDLENBQUMsZ0JBQWdCLGdCQUFnQixnQkFBZ0IsZUFBZSxFQUFFQyxRQUFBLENBQVNqQixHQUFHLElBQzdFLEtBQUtXLGVBQUEsQ0FBZ0JDLElBQUEsQ0FBS1osR0FBQSxHQUFNYSxFQUFFLElBQ2xDRyxLQUFBOztRQUVMLE9BQU9GLFNBQUE7TUFDUjtNQUVBSSxzQkFBc0JOLElBQUEsRUFBWTtRQUNqQyxPQUFPLEtBQUtELGVBQUEsQ0FBZ0JDLElBQUEsRUFBTSxLQUFLYixXQUFXO01BQ25EO01BRUFvQixzQkFBc0JQLElBQUEsRUFBWTtRQUNqQyxPQUFPLEtBQUtELGVBQUEsQ0FBZ0JDLElBQUEsRUFBTSxLQUFLSCxZQUFZO01BQ3BEO01BRUFXLGtCQUFrQkMsSUFBQSxFQUFjQyxLQUFBLEVBQWM7UUFDN0MsTUFBTUMsTUFBQSxHQUFTO1FBQ2YsV0FBV3ZCLEdBQUEsSUFBT3FCLElBQUEsRUFBTTtVQUN2QixNQUFNRyxPQUFBLEdBQVVGLEtBQUEsQ0FBTUcsYUFBQSxDQUFjQyxjQUFBLENBQWUxQixHQUFHO1VBQ3RELElBQUl3QixPQUFBLEVBQVNELE1BQUEsQ0FBT3ZCLEdBQUEsSUFBT3FCLElBQUEsQ0FBS00sVUFBQSxDQUFXM0IsR0FBQTs7UUFFNUMsT0FBT3VCLE1BQUE7TUFDUjtNQUVBSyxpQkFBaUJQLElBQUEsRUFBWUMsS0FBQSxFQUFhTyxvQkFBQSxFQUE0QkMsZ0JBQUEsRUFBc0I7UUFDM0YsTUFBTVAsTUFBQSxHQUFTO1FBQ2YsU0FBU3ZCLEdBQUEsSUFBT3FCLElBQUEsQ0FBS00sVUFBQSxFQUFZO1VBQ2hDLE1BQU1ILE9BQUEsR0FBVUYsS0FBQSxDQUFNRyxhQUFBLENBQWNDLGNBQUEsQ0FBZTFCLEdBQUc7VUFDdEQsTUFBTStCLFlBQUEsR0FDTEYsb0JBQUEsRUFBc0IzQyxNQUFBLElBQVUyQyxvQkFBQSxDQUFxQlosUUFBQSxDQUFTakIsR0FBRyxLQUFLOEIsZ0JBQUEsRUFBa0I1QyxNQUFBO1VBQ3pGLElBQUlzQyxPQUFBLElBQVdPLFlBQUEsRUFBYztZQUM1QixNQUFNQyxTQUFBLEdBQVlYLElBQUEsQ0FBS00sVUFBQSxDQUFXM0IsR0FBQTtZQUNsQyxJQUFJLENBQUMrQixZQUFBLEVBQWNSLE1BQUEsQ0FBT3ZCLEdBQUEsSUFBT2dDLFNBQUEsTUFDNUI7Y0FDSixNQUFNQyxVQUFBLEdBQWFKLG9CQUFBLENBQXFCSyxPQUFBLENBQVFsQyxHQUFHO2NBQ25ELElBQUlpQyxVQUFBLEdBQWEsR0FBRztjQUNwQixNQUFNRSxlQUFBLEdBQWtCTCxnQkFBQSxDQUFpQkcsVUFBQTtjQUN6Q1YsTUFBQSxDQUFPdkIsR0FBQSxJQUFPLEtBQUtvQixpQkFBQSxDQUFrQlksU0FBQSxFQUFXRyxlQUFlOzs7O1FBS2xFLE9BQU9aLE1BQUE7TUFDUjtNQUVBYSxrQkFBa0J4QixJQUFBLEVBQU1VLEtBQUEsRUFBT08sb0JBQUEsRUFBdUJNLGVBQUEsRUFBZ0I7UUFDckUsT0FBT3ZCLElBQUEsQ0FBS3lCLEdBQUEsQ0FBSWhCLElBQUEsSUFBUSxLQUFLTyxnQkFBQSxDQUFpQlAsSUFBQSxFQUFNQyxLQUFBLEVBQU9PLG9CQUFBLEVBQXNCTSxlQUFlLENBQUM7TUFDbEc7TUFFQUcsYUFBYTFCLElBQUEsRUFBYztRQUMxQixPQUFPQSxJQUFBLENBQUt5QixHQUFBLENBQUloQixJQUFBLElBQVEsS0FBS0gscUJBQUEsQ0FBc0JHLElBQUksQ0FBQztNQUN6RDtNQUVBa0Isb0JBQUEsR0FBd0JDLE1BQUEsSUFBa0I7UUFDekMsSUFBSSxPQUFPQSxNQUFBLEtBQVcsVUFBVSxNQUFNO1FBQ3RDLElBQUlDLEtBQUEsR0FBUTtRQUNaQyxNQUFBLENBQU9DLE9BQUEsQ0FBUUgsTUFBTSxFQUFFSSxPQUFBLENBQVEsQ0FBQyxDQUFDNUMsR0FBQSxFQUFLZ0IsS0FBSyxHQUFHNkIsS0FBQSxLQUFTO1VBQ3REN0IsS0FBQSxHQUFRLE9BQU9BLEtBQUEsS0FBVSxXQUFXOEIsSUFBQSxDQUFLQyxTQUFBLENBQVUvQixLQUFLLElBQUlBLEtBQUE7VUFDNUQsSUFBSTZCLEtBQUEsS0FBVSxHQUFHLE9BQVFKLEtBQUEsSUFBUyxJQUFJekMsR0FBQSxJQUFPZ0IsS0FBQTtVQUM3Q3lCLEtBQUEsSUFBUyxJQUFJekMsR0FBQSxJQUFPZ0IsS0FBQTtRQUNyQixDQUFDO1FBQ0QsT0FBT3lCLEtBQUE7TUFDUjs7SUFJQSxNQUFNTyxNQUFBLEdBQUtwRSxPQUFBLENBQUFKLEtBQUEsR0FBRyxJQUFJUSxLQUFBLENBQUsiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=