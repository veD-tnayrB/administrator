System.register(["@firebase/util@1.9.3","@firebase/component@0.6.4","@firebase/logger@0.4.0","idb@7.1.1","@firebase/app@0.9.26","tslib@2.6.2"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["@firebase/util","1.9.3"],["@firebase/component","0.6.4"],["@firebase/logger","0.4.0"],["idb","7.1.1"],["@firebase/app","0.9.26"],["tslib","2.6.2"],["@firebase/auth","1.5.1"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('@firebase/util@1.9.3', dep), dep => dependencies.set('@firebase/component@0.6.4', dep), dep => dependencies.set('@firebase/logger@0.4.0', dep), dep => dependencies.set('idb@7.1.1', dep), dep => dependencies.set('@firebase/app@0.9.26', dep), dep => dependencies.set('tslib@2.6.2', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name2 in all) __defProp(target, name2, {
    get: all[name2],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/@firebase/auth.1.5.1.js
var auth_1_5_1_exports = {};
__export(auth_1_5_1_exports, {
  ActionCodeOperation: () => ActionCodeOperation,
  ActionCodeURL: () => ActionCodeURL,
  AuthCredential: () => AuthCredential,
  AuthErrorCodes: () => AUTH_ERROR_CODES_MAP_DO_NOT_USE_INTERNALLY,
  EmailAuthCredential: () => EmailAuthCredential,
  EmailAuthProvider: () => EmailAuthProvider,
  FacebookAuthProvider: () => FacebookAuthProvider,
  FactorId: () => FactorId,
  GithubAuthProvider: () => GithubAuthProvider,
  GoogleAuthProvider: () => GoogleAuthProvider,
  OAuthCredential: () => OAuthCredential,
  OAuthProvider: () => OAuthProvider,
  OperationType: () => OperationType,
  PhoneAuthCredential: () => PhoneAuthCredential,
  PhoneAuthProvider: () => PhoneAuthProvider,
  PhoneMultiFactorGenerator: () => PhoneMultiFactorGenerator,
  ProviderId: () => ProviderId,
  RecaptchaVerifier: () => RecaptchaVerifier,
  SAMLAuthProvider: () => SAMLAuthProvider,
  SignInMethod: () => SignInMethod,
  TotpMultiFactorGenerator: () => TotpMultiFactorGenerator,
  TotpSecret: () => TotpSecret,
  TwitterAuthProvider: () => TwitterAuthProvider,
  applyActionCode: () => applyActionCode,
  beforeAuthStateChanged: () => beforeAuthStateChanged,
  browserLocalPersistence: () => browserLocalPersistence,
  browserPopupRedirectResolver: () => browserPopupRedirectResolver,
  browserSessionPersistence: () => browserSessionPersistence,
  checkActionCode: () => checkActionCode,
  confirmPasswordReset: () => confirmPasswordReset,
  connectAuthEmulator: () => connectAuthEmulator,
  createUserWithEmailAndPassword: () => createUserWithEmailAndPassword,
  debugErrorMap: () => debugErrorMap,
  deleteUser: () => deleteUser,
  fetchSignInMethodsForEmail: () => fetchSignInMethodsForEmail,
  getAdditionalUserInfo: () => getAdditionalUserInfo,
  getAuth: () => getAuth,
  getIdToken: () => getIdToken,
  getIdTokenResult: () => getIdTokenResult,
  getMultiFactorResolver: () => getMultiFactorResolver,
  getRedirectResult: () => getRedirectResult,
  inMemoryPersistence: () => inMemoryPersistence,
  indexedDBLocalPersistence: () => indexedDBLocalPersistence,
  initializeAuth: () => initializeAuth,
  initializeRecaptchaConfig: () => initializeRecaptchaConfig,
  isSignInWithEmailLink: () => isSignInWithEmailLink,
  linkWithCredential: () => linkWithCredential,
  linkWithPhoneNumber: () => linkWithPhoneNumber,
  linkWithPopup: () => linkWithPopup,
  linkWithRedirect: () => linkWithRedirect,
  multiFactor: () => multiFactor,
  onAuthStateChanged: () => onAuthStateChanged,
  onIdTokenChanged: () => onIdTokenChanged,
  parseActionCodeURL: () => parseActionCodeURL,
  prodErrorMap: () => prodErrorMap,
  reauthenticateWithCredential: () => reauthenticateWithCredential,
  reauthenticateWithPhoneNumber: () => reauthenticateWithPhoneNumber,
  reauthenticateWithPopup: () => reauthenticateWithPopup,
  reauthenticateWithRedirect: () => reauthenticateWithRedirect,
  reload: () => reload,
  revokeAccessToken: () => revokeAccessToken,
  sendEmailVerification: () => sendEmailVerification,
  sendPasswordResetEmail: () => sendPasswordResetEmail,
  sendSignInLinkToEmail: () => sendSignInLinkToEmail,
  setPersistence: () => setPersistence,
  signInAnonymously: () => signInAnonymously,
  signInWithCredential: () => signInWithCredential,
  signInWithCustomToken: () => signInWithCustomToken,
  signInWithEmailAndPassword: () => signInWithEmailAndPassword,
  signInWithEmailLink: () => signInWithEmailLink,
  signInWithPhoneNumber: () => signInWithPhoneNumber,
  signInWithPopup: () => signInWithPopup,
  signInWithRedirect: () => signInWithRedirect,
  signOut: () => signOut,
  unlink: () => unlink,
  updateCurrentUser: () => updateCurrentUser,
  updateEmail: () => updateEmail,
  updatePassword: () => updatePassword,
  updatePhoneNumber: () => updatePhoneNumber,
  updateProfile: () => updateProfile,
  useDeviceLanguage: () => useDeviceLanguage,
  validatePassword: () => validatePassword,
  verifyBeforeUpdateEmail: () => verifyBeforeUpdateEmail,
  verifyPasswordResetCode: () => verifyPasswordResetCode
});
module.exports = __toCommonJS(auth_1_5_1_exports);

// node_modules/@firebase/auth/dist/esm2017/index-dd468b12.js
var import_util = require("@firebase/util@1.9.3");
var import_app = require("@firebase/app@0.9.26");
var import_logger = require("@firebase/logger@0.4.0");
var import_tslib = require("tslib@2.6.2");
var import_component = require("@firebase/component@0.6.4");
var FactorId = {
  PHONE: "phone",
  TOTP: "totp"
};
var ProviderId = {
  FACEBOOK: "facebook.com",
  GITHUB: "github.com",
  GOOGLE: "google.com",
  PASSWORD: "password",
  PHONE: "phone",
  TWITTER: "twitter.com"
};
var SignInMethod = {
  EMAIL_LINK: "emailLink",
  EMAIL_PASSWORD: "password",
  FACEBOOK: "facebook.com",
  GITHUB: "github.com",
  GOOGLE: "google.com",
  PHONE: "phone",
  TWITTER: "twitter.com"
};
var OperationType = {
  LINK: "link",
  REAUTHENTICATE: "reauthenticate",
  SIGN_IN: "signIn"
};
var ActionCodeOperation = {
  EMAIL_SIGNIN: "EMAIL_SIGNIN",
  PASSWORD_RESET: "PASSWORD_RESET",
  RECOVER_EMAIL: "RECOVER_EMAIL",
  REVERT_SECOND_FACTOR_ADDITION: "REVERT_SECOND_FACTOR_ADDITION",
  VERIFY_AND_CHANGE_EMAIL: "VERIFY_AND_CHANGE_EMAIL",
  VERIFY_EMAIL: "VERIFY_EMAIL"
};
function _debugErrorMap() {
  return {
    ["admin-restricted-operation"]: "This operation is restricted to administrators only.",
    ["argument-error"]: "",
    ["app-not-authorized"]: "This app, identified by the domain where it's hosted, is not authorized to use Firebase Authentication with the provided API key. Review your key configuration in the Google API console.",
    ["app-not-installed"]: "The requested mobile application corresponding to the identifier (Android package name or iOS bundle ID) provided is not installed on this device.",
    ["captcha-check-failed"]: "The reCAPTCHA response token provided is either invalid, expired, already used or the domain associated with it does not match the list of whitelisted domains.",
    ["code-expired"]: "The SMS code has expired. Please re-send the verification code to try again.",
    ["cordova-not-ready"]: "Cordova framework is not ready.",
    ["cors-unsupported"]: "This browser is not supported.",
    ["credential-already-in-use"]: "This credential is already associated with a different user account.",
    ["custom-token-mismatch"]: "The custom token corresponds to a different audience.",
    ["requires-recent-login"]: "This operation is sensitive and requires recent authentication. Log in again before retrying this request.",
    ["dependent-sdk-initialized-before-auth"]: "Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK.",
    ["dynamic-link-not-activated"]: "Please activate Dynamic Links in the Firebase Console and agree to the terms and conditions.",
    ["email-change-needs-verification"]: "Multi-factor users must always have a verified email.",
    ["email-already-in-use"]: "The email address is already in use by another account.",
    ["emulator-config-failed"]: 'Auth instance has already been used to make a network call. Auth can no longer be configured to use the emulator. Try calling "connectAuthEmulator()" sooner.',
    ["expired-action-code"]: "The action code has expired.",
    ["cancelled-popup-request"]: "This operation has been cancelled due to another conflicting popup being opened.",
    ["internal-error"]: "An internal AuthError has occurred.",
    ["invalid-app-credential"]: "The phone verification request contains an invalid application verifier. The reCAPTCHA token response is either invalid or expired.",
    ["invalid-app-id"]: "The mobile app identifier is not registed for the current project.",
    ["invalid-user-token"]: "This user's credential isn't valid for this project. This can happen if the user's token has been tampered with, or if the user isn't for the project associated with this API key.",
    ["invalid-auth-event"]: "An internal AuthError has occurred.",
    ["invalid-verification-code"]: "The SMS verification code used to create the phone auth credential is invalid. Please resend the verification code sms and be sure to use the verification code provided by the user.",
    ["invalid-continue-uri"]: "The continue URL provided in the request is invalid.",
    ["invalid-cordova-configuration"]: "The following Cordova plugins must be installed to enable OAuth sign-in: cordova-plugin-buildinfo, cordova-universal-links-plugin, cordova-plugin-browsertab, cordova-plugin-inappbrowser and cordova-plugin-customurlscheme.",
    ["invalid-custom-token"]: "The custom token format is incorrect. Please check the documentation.",
    ["invalid-dynamic-link-domain"]: "The provided dynamic link domain is not configured or authorized for the current project.",
    ["invalid-email"]: "The email address is badly formatted.",
    ["invalid-emulator-scheme"]: "Emulator URL must start with a valid scheme (http:// or https://).",
    ["invalid-api-key"]: "Your API key is invalid, please check you have copied it correctly.",
    ["invalid-cert-hash"]: "The SHA-1 certificate hash provided is invalid.",
    ["invalid-credential"]: "The supplied auth credential is incorrect, malformed or has expired.",
    ["invalid-message-payload"]: "The email template corresponding to this action contains invalid characters in its message. Please fix by going to the Auth email templates section in the Firebase Console.",
    ["invalid-multi-factor-session"]: "The request does not contain a valid proof of first factor successful sign-in.",
    ["invalid-oauth-provider"]: "EmailAuthProvider is not supported for this operation. This operation only supports OAuth providers.",
    ["invalid-oauth-client-id"]: "The OAuth client ID provided is either invalid or does not match the specified API key.",
    ["unauthorized-domain"]: "This domain is not authorized for OAuth operations for your Firebase project. Edit the list of authorized domains from the Firebase console.",
    ["invalid-action-code"]: "The action code is invalid. This can happen if the code is malformed, expired, or has already been used.",
    ["wrong-password"]: "The password is invalid or the user does not have a password.",
    ["invalid-persistence-type"]: "The specified persistence type is invalid. It can only be local, session or none.",
    ["invalid-phone-number"]: "The format of the phone number provided is incorrect. Please enter the phone number in a format that can be parsed into E.164 format. E.164 phone numbers are written in the format [+][country code][subscriber number including area code].",
    ["invalid-provider-id"]: "The specified provider ID is invalid.",
    ["invalid-recipient-email"]: "The email corresponding to this action failed to send as the provided recipient email address is invalid.",
    ["invalid-sender"]: "The email template corresponding to this action contains an invalid sender email or name. Please fix by going to the Auth email templates section in the Firebase Console.",
    ["invalid-verification-id"]: "The verification ID used to create the phone auth credential is invalid.",
    ["invalid-tenant-id"]: "The Auth instance's tenant ID is invalid.",
    ["login-blocked"]: "Login blocked by user-provided method: {$originalMessage}",
    ["missing-android-pkg-name"]: "An Android Package Name must be provided if the Android App is required to be installed.",
    ["auth-domain-config-required"]: "Be sure to include authDomain when calling firebase.initializeApp(), by following the instructions in the Firebase console.",
    ["missing-app-credential"]: "The phone verification request is missing an application verifier assertion. A reCAPTCHA response token needs to be provided.",
    ["missing-verification-code"]: "The phone auth credential was created with an empty SMS verification code.",
    ["missing-continue-uri"]: "A continue URL must be provided in the request.",
    ["missing-iframe-start"]: "An internal AuthError has occurred.",
    ["missing-ios-bundle-id"]: "An iOS Bundle ID must be provided if an App Store ID is provided.",
    ["missing-or-invalid-nonce"]: "The request does not contain a valid nonce. This can occur if the SHA-256 hash of the provided raw nonce does not match the hashed nonce in the ID token payload.",
    ["missing-password"]: "A non-empty password must be provided",
    ["missing-multi-factor-info"]: "No second factor identifier is provided.",
    ["missing-multi-factor-session"]: "The request is missing proof of first factor successful sign-in.",
    ["missing-phone-number"]: "To send verification codes, provide a phone number for the recipient.",
    ["missing-verification-id"]: "The phone auth credential was created with an empty verification ID.",
    ["app-deleted"]: "This instance of FirebaseApp has been deleted.",
    ["multi-factor-info-not-found"]: "The user does not have a second factor matching the identifier provided.",
    ["multi-factor-auth-required"]: "Proof of ownership of a second factor is required to complete sign-in.",
    ["account-exists-with-different-credential"]: "An account already exists with the same email address but different sign-in credentials. Sign in using a provider associated with this email address.",
    ["network-request-failed"]: "A network AuthError (such as timeout, interrupted connection or unreachable host) has occurred.",
    ["no-auth-event"]: "An internal AuthError has occurred.",
    ["no-such-provider"]: "User was not linked to an account with the given provider.",
    ["null-user"]: "A null user object was provided as the argument for an operation which requires a non-null user object.",
    ["operation-not-allowed"]: "The given sign-in provider is disabled for this Firebase project. Enable it in the Firebase console, under the sign-in method tab of the Auth section.",
    ["operation-not-supported-in-this-environment"]: 'This operation is not supported in the environment this application is running on. "location.protocol" must be http, https or chrome-extension and web storage must be enabled.',
    ["popup-blocked"]: "Unable to establish a connection with the popup. It may have been blocked by the browser.",
    ["popup-closed-by-user"]: "The popup has been closed by the user before finalizing the operation.",
    ["provider-already-linked"]: "User can only be linked to one identity for the given provider.",
    ["quota-exceeded"]: "The project's quota for this operation has been exceeded.",
    ["redirect-cancelled-by-user"]: "The redirect operation has been cancelled by the user before finalizing.",
    ["redirect-operation-pending"]: "A redirect sign-in operation is already pending.",
    ["rejected-credential"]: "The request contains malformed or mismatching credentials.",
    ["second-factor-already-in-use"]: "The second factor is already enrolled on this account.",
    ["maximum-second-factor-count-exceeded"]: "The maximum allowed number of second factors on a user has been exceeded.",
    ["tenant-id-mismatch"]: "The provided tenant ID does not match the Auth instance's tenant ID",
    ["timeout"]: "The operation has timed out.",
    ["user-token-expired"]: "The user's credential is no longer valid. The user must sign in again.",
    ["too-many-requests"]: "We have blocked all requests from this device due to unusual activity. Try again later.",
    ["unauthorized-continue-uri"]: "The domain of the continue URL is not whitelisted.  Please whitelist the domain in the Firebase console.",
    ["unsupported-first-factor"]: "Enrolling a second factor or signing in with a multi-factor account requires sign-in with a supported first factor.",
    ["unsupported-persistence-type"]: "The current environment does not support the specified persistence type.",
    ["unsupported-tenant-operation"]: "This operation is not supported in a multi-tenant context.",
    ["unverified-email"]: "The operation requires a verified email.",
    ["user-cancelled"]: "The user did not grant your application the permissions it requested.",
    ["user-not-found"]: "There is no user record corresponding to this identifier. The user may have been deleted.",
    ["user-disabled"]: "The user account has been disabled by an administrator.",
    ["user-mismatch"]: "The supplied credentials do not correspond to the previously signed in user.",
    ["user-signed-out"]: "",
    ["weak-password"]: "The password must be 6 characters long or more.",
    ["web-storage-unsupported"]: "This browser is not supported or 3rd party cookies and data may be disabled.",
    ["already-initialized"]: "initializeAuth() has already been called with different options. To avoid this error, call initializeAuth() with the same options as when it was originally called, or call getAuth() to return the already initialized instance.",
    ["missing-recaptcha-token"]: "The reCAPTCHA token is missing when sending request to the backend.",
    ["invalid-recaptcha-token"]: "The reCAPTCHA token is invalid when sending request to the backend.",
    ["invalid-recaptcha-action"]: "The reCAPTCHA action is invalid when sending request to the backend.",
    ["recaptcha-not-enabled"]: "reCAPTCHA Enterprise integration is not enabled for this project.",
    ["missing-client-type"]: "The reCAPTCHA client type is missing when sending request to the backend.",
    ["missing-recaptcha-version"]: "The reCAPTCHA version is missing when sending request to the backend.",
    ["invalid-req-type"]: "Invalid request parameters.",
    ["invalid-recaptcha-version"]: "The reCAPTCHA version is invalid when sending request to the backend.",
    ["unsupported-password-policy-schema-version"]: "The password policy received from the backend uses a schema version that is not supported by this version of the Firebase SDK.",
    ["password-does-not-meet-requirements"]: "The password does not meet the requirements."
  };
}
function _prodErrorMap() {
  return {
    ["dependent-sdk-initialized-before-auth"]: "Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."
  };
}
var debugErrorMap = _debugErrorMap;
var prodErrorMap = _prodErrorMap;
var _DEFAULT_AUTH_ERROR_FACTORY = new import_util.ErrorFactory("auth", "Firebase", _prodErrorMap());
var AUTH_ERROR_CODES_MAP_DO_NOT_USE_INTERNALLY = {
  ADMIN_ONLY_OPERATION: "auth/admin-restricted-operation",
  ARGUMENT_ERROR: "auth/argument-error",
  APP_NOT_AUTHORIZED: "auth/app-not-authorized",
  APP_NOT_INSTALLED: "auth/app-not-installed",
  CAPTCHA_CHECK_FAILED: "auth/captcha-check-failed",
  CODE_EXPIRED: "auth/code-expired",
  CORDOVA_NOT_READY: "auth/cordova-not-ready",
  CORS_UNSUPPORTED: "auth/cors-unsupported",
  CREDENTIAL_ALREADY_IN_USE: "auth/credential-already-in-use",
  CREDENTIAL_MISMATCH: "auth/custom-token-mismatch",
  CREDENTIAL_TOO_OLD_LOGIN_AGAIN: "auth/requires-recent-login",
  DEPENDENT_SDK_INIT_BEFORE_AUTH: "auth/dependent-sdk-initialized-before-auth",
  DYNAMIC_LINK_NOT_ACTIVATED: "auth/dynamic-link-not-activated",
  EMAIL_CHANGE_NEEDS_VERIFICATION: "auth/email-change-needs-verification",
  EMAIL_EXISTS: "auth/email-already-in-use",
  EMULATOR_CONFIG_FAILED: "auth/emulator-config-failed",
  EXPIRED_OOB_CODE: "auth/expired-action-code",
  EXPIRED_POPUP_REQUEST: "auth/cancelled-popup-request",
  INTERNAL_ERROR: "auth/internal-error",
  INVALID_API_KEY: "auth/invalid-api-key",
  INVALID_APP_CREDENTIAL: "auth/invalid-app-credential",
  INVALID_APP_ID: "auth/invalid-app-id",
  INVALID_AUTH: "auth/invalid-user-token",
  INVALID_AUTH_EVENT: "auth/invalid-auth-event",
  INVALID_CERT_HASH: "auth/invalid-cert-hash",
  INVALID_CODE: "auth/invalid-verification-code",
  INVALID_CONTINUE_URI: "auth/invalid-continue-uri",
  INVALID_CORDOVA_CONFIGURATION: "auth/invalid-cordova-configuration",
  INVALID_CUSTOM_TOKEN: "auth/invalid-custom-token",
  INVALID_DYNAMIC_LINK_DOMAIN: "auth/invalid-dynamic-link-domain",
  INVALID_EMAIL: "auth/invalid-email",
  INVALID_EMULATOR_SCHEME: "auth/invalid-emulator-scheme",
  INVALID_IDP_RESPONSE: "auth/invalid-credential",
  INVALID_LOGIN_CREDENTIALS: "auth/invalid-credential",
  INVALID_MESSAGE_PAYLOAD: "auth/invalid-message-payload",
  INVALID_MFA_SESSION: "auth/invalid-multi-factor-session",
  INVALID_OAUTH_CLIENT_ID: "auth/invalid-oauth-client-id",
  INVALID_OAUTH_PROVIDER: "auth/invalid-oauth-provider",
  INVALID_OOB_CODE: "auth/invalid-action-code",
  INVALID_ORIGIN: "auth/unauthorized-domain",
  INVALID_PASSWORD: "auth/wrong-password",
  INVALID_PERSISTENCE: "auth/invalid-persistence-type",
  INVALID_PHONE_NUMBER: "auth/invalid-phone-number",
  INVALID_PROVIDER_ID: "auth/invalid-provider-id",
  INVALID_RECIPIENT_EMAIL: "auth/invalid-recipient-email",
  INVALID_SENDER: "auth/invalid-sender",
  INVALID_SESSION_INFO: "auth/invalid-verification-id",
  INVALID_TENANT_ID: "auth/invalid-tenant-id",
  MFA_INFO_NOT_FOUND: "auth/multi-factor-info-not-found",
  MFA_REQUIRED: "auth/multi-factor-auth-required",
  MISSING_ANDROID_PACKAGE_NAME: "auth/missing-android-pkg-name",
  MISSING_APP_CREDENTIAL: "auth/missing-app-credential",
  MISSING_AUTH_DOMAIN: "auth/auth-domain-config-required",
  MISSING_CODE: "auth/missing-verification-code",
  MISSING_CONTINUE_URI: "auth/missing-continue-uri",
  MISSING_IFRAME_START: "auth/missing-iframe-start",
  MISSING_IOS_BUNDLE_ID: "auth/missing-ios-bundle-id",
  MISSING_OR_INVALID_NONCE: "auth/missing-or-invalid-nonce",
  MISSING_MFA_INFO: "auth/missing-multi-factor-info",
  MISSING_MFA_SESSION: "auth/missing-multi-factor-session",
  MISSING_PHONE_NUMBER: "auth/missing-phone-number",
  MISSING_SESSION_INFO: "auth/missing-verification-id",
  MODULE_DESTROYED: "auth/app-deleted",
  NEED_CONFIRMATION: "auth/account-exists-with-different-credential",
  NETWORK_REQUEST_FAILED: "auth/network-request-failed",
  NULL_USER: "auth/null-user",
  NO_AUTH_EVENT: "auth/no-auth-event",
  NO_SUCH_PROVIDER: "auth/no-such-provider",
  OPERATION_NOT_ALLOWED: "auth/operation-not-allowed",
  OPERATION_NOT_SUPPORTED: "auth/operation-not-supported-in-this-environment",
  POPUP_BLOCKED: "auth/popup-blocked",
  POPUP_CLOSED_BY_USER: "auth/popup-closed-by-user",
  PROVIDER_ALREADY_LINKED: "auth/provider-already-linked",
  QUOTA_EXCEEDED: "auth/quota-exceeded",
  REDIRECT_CANCELLED_BY_USER: "auth/redirect-cancelled-by-user",
  REDIRECT_OPERATION_PENDING: "auth/redirect-operation-pending",
  REJECTED_CREDENTIAL: "auth/rejected-credential",
  SECOND_FACTOR_ALREADY_ENROLLED: "auth/second-factor-already-in-use",
  SECOND_FACTOR_LIMIT_EXCEEDED: "auth/maximum-second-factor-count-exceeded",
  TENANT_ID_MISMATCH: "auth/tenant-id-mismatch",
  TIMEOUT: "auth/timeout",
  TOKEN_EXPIRED: "auth/user-token-expired",
  TOO_MANY_ATTEMPTS_TRY_LATER: "auth/too-many-requests",
  UNAUTHORIZED_DOMAIN: "auth/unauthorized-continue-uri",
  UNSUPPORTED_FIRST_FACTOR: "auth/unsupported-first-factor",
  UNSUPPORTED_PERSISTENCE: "auth/unsupported-persistence-type",
  UNSUPPORTED_TENANT_OPERATION: "auth/unsupported-tenant-operation",
  UNVERIFIED_EMAIL: "auth/unverified-email",
  USER_CANCELLED: "auth/user-cancelled",
  USER_DELETED: "auth/user-not-found",
  USER_DISABLED: "auth/user-disabled",
  USER_MISMATCH: "auth/user-mismatch",
  USER_SIGNED_OUT: "auth/user-signed-out",
  WEAK_PASSWORD: "auth/weak-password",
  WEB_STORAGE_UNSUPPORTED: "auth/web-storage-unsupported",
  ALREADY_INITIALIZED: "auth/already-initialized",
  RECAPTCHA_NOT_ENABLED: "auth/recaptcha-not-enabled",
  MISSING_RECAPTCHA_TOKEN: "auth/missing-recaptcha-token",
  INVALID_RECAPTCHA_TOKEN: "auth/invalid-recaptcha-token",
  INVALID_RECAPTCHA_ACTION: "auth/invalid-recaptcha-action",
  MISSING_CLIENT_TYPE: "auth/missing-client-type",
  MISSING_RECAPTCHA_VERSION: "auth/missing-recaptcha-version",
  INVALID_RECAPTCHA_VERSION: "auth/invalid-recaptcha-version",
  INVALID_REQ_TYPE: "auth/invalid-req-type"
};
var logClient = new import_logger.Logger("@firebase/auth");
function _logWarn(msg, ...args) {
  if (logClient.logLevel <= import_logger.LogLevel.WARN) {
    logClient.warn(`Auth (${import_app.SDK_VERSION}): ${msg}`, ...args);
  }
}
function _logError(msg, ...args) {
  if (logClient.logLevel <= import_logger.LogLevel.ERROR) {
    logClient.error(`Auth (${import_app.SDK_VERSION}): ${msg}`, ...args);
  }
}
function _fail(authOrCode, ...rest) {
  throw createErrorInternal(authOrCode, ...rest);
}
function _createError(authOrCode, ...rest) {
  return createErrorInternal(authOrCode, ...rest);
}
function _errorWithCustomMessage(auth, code, message) {
  const errorMap = Object.assign(Object.assign({}, prodErrorMap()), {
    [code]: message
  });
  const factory = new import_util.ErrorFactory("auth", "Firebase", errorMap);
  return factory.create(code, {
    appName: auth.name
  });
}
function _assertInstanceOf(auth, object, instance) {
  const constructorInstance = instance;
  if (!(object instanceof constructorInstance)) {
    if (constructorInstance.name !== object.constructor.name) {
      _fail(auth, "argument-error");
    }
    throw _errorWithCustomMessage(auth, "argument-error", `Type of ${object.constructor.name} does not match expected instance.Did you pass a reference from a different Auth SDK?`);
  }
}
function createErrorInternal(authOrCode, ...rest) {
  if (typeof authOrCode !== "string") {
    const code = rest[0];
    const fullParams = [...rest.slice(1)];
    if (fullParams[0]) {
      fullParams[0].appName = authOrCode.name;
    }
    return authOrCode._errorFactory.create(code, ...fullParams);
  }
  return _DEFAULT_AUTH_ERROR_FACTORY.create(authOrCode, ...rest);
}
function _assert(assertion, authOrCode, ...rest) {
  if (!assertion) {
    throw createErrorInternal(authOrCode, ...rest);
  }
}
function debugFail(failure) {
  const message = `INTERNAL ASSERTION FAILED: ` + failure;
  _logError(message);
  throw new Error(message);
}
function debugAssert(assertion, message) {
  if (!assertion) {
    debugFail(message);
  }
}
function _getCurrentUrl() {
  var _a;
  return typeof self !== "undefined" && ((_a = self.location) === null || _a === void 0 ? void 0 : _a.href) || "";
}
function _isHttpOrHttps() {
  return _getCurrentScheme() === "http:" || _getCurrentScheme() === "https:";
}
function _getCurrentScheme() {
  var _a;
  return typeof self !== "undefined" && ((_a = self.location) === null || _a === void 0 ? void 0 : _a.protocol) || null;
}
function _isOnline() {
  if (typeof navigator !== "undefined" && navigator && "onLine" in navigator && typeof navigator.onLine === "boolean" && (_isHttpOrHttps() || (0, import_util.isBrowserExtension)() || "connection" in navigator)) {
    return navigator.onLine;
  }
  return true;
}
function _getUserLanguage() {
  if (typeof navigator === "undefined") {
    return null;
  }
  const navigatorLanguage = navigator;
  return navigatorLanguage.languages && navigatorLanguage.languages[0] || navigatorLanguage.language || null;
}
var Delay = class {
  constructor(shortDelay, longDelay) {
    this.shortDelay = shortDelay;
    this.longDelay = longDelay;
    debugAssert(longDelay > shortDelay, "Short delay should be less than long delay!");
    this.isMobile = (0, import_util.isMobileCordova)() || (0, import_util.isReactNative)();
  }
  get() {
    if (!_isOnline()) {
      return Math.min(5e3, this.shortDelay);
    }
    return this.isMobile ? this.longDelay : this.shortDelay;
  }
};
function _emulatorUrl(config, path) {
  debugAssert(config.emulator, "Emulator should always be set here");
  const {
    url
  } = config.emulator;
  if (!path) {
    return url;
  }
  return `${url}${path.startsWith("/") ? path.slice(1) : path}`;
}
var FetchProvider = class {
  static initialize(fetchImpl, headersImpl, responseImpl) {
    this.fetchImpl = fetchImpl;
    if (headersImpl) {
      this.headersImpl = headersImpl;
    }
    if (responseImpl) {
      this.responseImpl = responseImpl;
    }
  }
  static fetch() {
    if (this.fetchImpl) {
      return this.fetchImpl;
    }
    if (typeof self !== "undefined" && "fetch" in self) {
      return self.fetch;
    }
    if (typeof globalThis !== "undefined" && globalThis.fetch) {
      return globalThis.fetch;
    }
    if (typeof fetch !== "undefined") {
      return fetch;
    }
    debugFail("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill");
  }
  static headers() {
    if (this.headersImpl) {
      return this.headersImpl;
    }
    if (typeof self !== "undefined" && "Headers" in self) {
      return self.Headers;
    }
    if (typeof globalThis !== "undefined" && globalThis.Headers) {
      return globalThis.Headers;
    }
    if (typeof Headers !== "undefined") {
      return Headers;
    }
    debugFail("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill");
  }
  static response() {
    if (this.responseImpl) {
      return this.responseImpl;
    }
    if (typeof self !== "undefined" && "Response" in self) {
      return self.Response;
    }
    if (typeof globalThis !== "undefined" && globalThis.Response) {
      return globalThis.Response;
    }
    if (typeof Response !== "undefined") {
      return Response;
    }
    debugFail("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill");
  }
};
var SERVER_ERROR_MAP = {
  ["CREDENTIAL_MISMATCH"]: "custom-token-mismatch",
  ["MISSING_CUSTOM_TOKEN"]: "internal-error",
  ["INVALID_IDENTIFIER"]: "invalid-email",
  ["MISSING_CONTINUE_URI"]: "internal-error",
  ["INVALID_PASSWORD"]: "wrong-password",
  ["MISSING_PASSWORD"]: "missing-password",
  ["INVALID_LOGIN_CREDENTIALS"]: "invalid-credential",
  ["EMAIL_EXISTS"]: "email-already-in-use",
  ["PASSWORD_LOGIN_DISABLED"]: "operation-not-allowed",
  ["INVALID_IDP_RESPONSE"]: "invalid-credential",
  ["INVALID_PENDING_TOKEN"]: "invalid-credential",
  ["FEDERATED_USER_ID_ALREADY_LINKED"]: "credential-already-in-use",
  ["MISSING_REQ_TYPE"]: "internal-error",
  ["EMAIL_NOT_FOUND"]: "user-not-found",
  ["RESET_PASSWORD_EXCEED_LIMIT"]: "too-many-requests",
  ["EXPIRED_OOB_CODE"]: "expired-action-code",
  ["INVALID_OOB_CODE"]: "invalid-action-code",
  ["MISSING_OOB_CODE"]: "internal-error",
  ["CREDENTIAL_TOO_OLD_LOGIN_AGAIN"]: "requires-recent-login",
  ["INVALID_ID_TOKEN"]: "invalid-user-token",
  ["TOKEN_EXPIRED"]: "user-token-expired",
  ["USER_NOT_FOUND"]: "user-token-expired",
  ["TOO_MANY_ATTEMPTS_TRY_LATER"]: "too-many-requests",
  ["PASSWORD_DOES_NOT_MEET_REQUIREMENTS"]: "password-does-not-meet-requirements",
  ["INVALID_CODE"]: "invalid-verification-code",
  ["INVALID_SESSION_INFO"]: "invalid-verification-id",
  ["INVALID_TEMPORARY_PROOF"]: "invalid-credential",
  ["MISSING_SESSION_INFO"]: "missing-verification-id",
  ["SESSION_EXPIRED"]: "code-expired",
  ["MISSING_ANDROID_PACKAGE_NAME"]: "missing-android-pkg-name",
  ["UNAUTHORIZED_DOMAIN"]: "unauthorized-continue-uri",
  ["INVALID_OAUTH_CLIENT_ID"]: "invalid-oauth-client-id",
  ["ADMIN_ONLY_OPERATION"]: "admin-restricted-operation",
  ["INVALID_MFA_PENDING_CREDENTIAL"]: "invalid-multi-factor-session",
  ["MFA_ENROLLMENT_NOT_FOUND"]: "multi-factor-info-not-found",
  ["MISSING_MFA_ENROLLMENT_ID"]: "missing-multi-factor-info",
  ["MISSING_MFA_PENDING_CREDENTIAL"]: "missing-multi-factor-session",
  ["SECOND_FACTOR_EXISTS"]: "second-factor-already-in-use",
  ["SECOND_FACTOR_LIMIT_EXCEEDED"]: "maximum-second-factor-count-exceeded",
  ["BLOCKING_FUNCTION_ERROR_RESPONSE"]: "internal-error",
  ["RECAPTCHA_NOT_ENABLED"]: "recaptcha-not-enabled",
  ["MISSING_RECAPTCHA_TOKEN"]: "missing-recaptcha-token",
  ["INVALID_RECAPTCHA_TOKEN"]: "invalid-recaptcha-token",
  ["INVALID_RECAPTCHA_ACTION"]: "invalid-recaptcha-action",
  ["MISSING_CLIENT_TYPE"]: "missing-client-type",
  ["MISSING_RECAPTCHA_VERSION"]: "missing-recaptcha-version",
  ["INVALID_RECAPTCHA_VERSION"]: "invalid-recaptcha-version",
  ["INVALID_REQ_TYPE"]: "invalid-req-type"
};
var DEFAULT_API_TIMEOUT_MS = new Delay(3e4, 6e4);
function _addTidIfNecessary(auth, request) {
  if (auth.tenantId && !request.tenantId) {
    return Object.assign(Object.assign({}, request), {
      tenantId: auth.tenantId
    });
  }
  return request;
}
async function _performApiRequest(auth, method, path, request, customErrorMap = {}) {
  return _performFetchWithErrorHandling(auth, customErrorMap, async () => {
    let body = {};
    let params = {};
    if (request) {
      if (method === "GET") {
        params = request;
      } else {
        body = {
          body: JSON.stringify(request)
        };
      }
    }
    const query = (0, import_util.querystring)(Object.assign({
      key: auth.config.apiKey
    }, params)).slice(1);
    const headers = await auth._getAdditionalHeaders();
    headers["Content-Type"] = "application/json";
    if (auth.languageCode) {
      headers["X-Firebase-Locale"] = auth.languageCode;
    }
    return FetchProvider.fetch()(_getFinalTarget(auth, auth.config.apiHost, path, query), Object.assign({
      method,
      headers,
      referrerPolicy: "no-referrer"
    }, body));
  });
}
async function _performFetchWithErrorHandling(auth, customErrorMap, fetchFn) {
  auth._canInitEmulator = false;
  const errorMap = Object.assign(Object.assign({}, SERVER_ERROR_MAP), customErrorMap);
  try {
    const networkTimeout = new NetworkTimeout(auth);
    const response = await Promise.race([fetchFn(), networkTimeout.promise]);
    networkTimeout.clearNetworkTimeout();
    const json = await response.json();
    if ("needConfirmation" in json) {
      throw _makeTaggedError(auth, "account-exists-with-different-credential", json);
    }
    if (response.ok && !("errorMessage" in json)) {
      return json;
    } else {
      const errorMessage = response.ok ? json.errorMessage : json.error.message;
      const [serverErrorCode, serverErrorMessage] = errorMessage.split(" : ");
      if (serverErrorCode === "FEDERATED_USER_ID_ALREADY_LINKED") {
        throw _makeTaggedError(auth, "credential-already-in-use", json);
      } else if (serverErrorCode === "EMAIL_EXISTS") {
        throw _makeTaggedError(auth, "email-already-in-use", json);
      } else if (serverErrorCode === "USER_DISABLED") {
        throw _makeTaggedError(auth, "user-disabled", json);
      }
      const authError = errorMap[serverErrorCode] || serverErrorCode.toLowerCase().replace(/[_\s]+/g, "-");
      if (serverErrorMessage) {
        throw _errorWithCustomMessage(auth, authError, serverErrorMessage);
      } else {
        _fail(auth, authError);
      }
    }
  } catch (e) {
    if (e instanceof import_util.FirebaseError) {
      throw e;
    }
    _fail(auth, "network-request-failed", {
      "message": String(e)
    });
  }
}
async function _performSignInRequest(auth, method, path, request, customErrorMap = {}) {
  const serverResponse = await _performApiRequest(auth, method, path, request, customErrorMap);
  if ("mfaPendingCredential" in serverResponse) {
    _fail(auth, "multi-factor-auth-required", {
      _serverResponse: serverResponse
    });
  }
  return serverResponse;
}
function _getFinalTarget(auth, host, path, query) {
  const base = `${host}${path}?${query}`;
  if (!auth.config.emulator) {
    return `${auth.config.apiScheme}://${base}`;
  }
  return _emulatorUrl(auth.config, base);
}
function _parseEnforcementState(enforcementStateStr) {
  switch (enforcementStateStr) {
    case "ENFORCE":
      return "ENFORCE";
    case "AUDIT":
      return "AUDIT";
    case "OFF":
      return "OFF";
    default:
      return "ENFORCEMENT_STATE_UNSPECIFIED";
  }
}
var NetworkTimeout = class {
  constructor(auth) {
    this.auth = auth;
    this.timer = null;
    this.promise = new Promise((_, reject) => {
      this.timer = setTimeout(() => {
        return reject(_createError(this.auth, "network-request-failed"));
      }, DEFAULT_API_TIMEOUT_MS.get());
    });
  }
  clearNetworkTimeout() {
    clearTimeout(this.timer);
  }
};
function _makeTaggedError(auth, code, response) {
  const errorParams = {
    appName: auth.name
  };
  if (response.email) {
    errorParams.email = response.email;
  }
  if (response.phoneNumber) {
    errorParams.phoneNumber = response.phoneNumber;
  }
  const error = _createError(auth, code, errorParams);
  error.customData._tokenResponse = response;
  return error;
}
function isV2(grecaptcha) {
  return grecaptcha !== void 0 && grecaptcha.getResponse !== void 0;
}
function isEnterprise(grecaptcha) {
  return grecaptcha !== void 0 && grecaptcha.enterprise !== void 0;
}
var RecaptchaConfig = class {
  constructor(response) {
    this.siteKey = "";
    this.recaptchaEnforcementState = [];
    if (response.recaptchaKey === void 0) {
      throw new Error("recaptchaKey undefined");
    }
    this.siteKey = response.recaptchaKey.split("/")[3];
    this.recaptchaEnforcementState = response.recaptchaEnforcementState;
  }
  getProviderEnforcementState(providerStr) {
    if (!this.recaptchaEnforcementState || this.recaptchaEnforcementState.length === 0) {
      return null;
    }
    for (const recaptchaEnforcementState of this.recaptchaEnforcementState) {
      if (recaptchaEnforcementState.provider && recaptchaEnforcementState.provider === providerStr) {
        return _parseEnforcementState(recaptchaEnforcementState.enforcementState);
      }
    }
    return null;
  }
  isProviderEnabled(providerStr) {
    return this.getProviderEnforcementState(providerStr) === "ENFORCE" || this.getProviderEnforcementState(providerStr) === "AUDIT";
  }
};
async function getRecaptchaParams(auth) {
  return (await _performApiRequest(auth, "GET", "/v1/recaptchaParams")).recaptchaSiteKey || "";
}
async function getRecaptchaConfig(auth, request) {
  return _performApiRequest(auth, "GET", "/v2/recaptchaConfig", _addTidIfNecessary(auth, request));
}
async function deleteAccount(auth, request) {
  return _performApiRequest(auth, "POST", "/v1/accounts:delete", request);
}
async function deleteLinkedAccounts(auth, request) {
  return _performApiRequest(auth, "POST", "/v1/accounts:update", request);
}
async function getAccountInfo(auth, request) {
  return _performApiRequest(auth, "POST", "/v1/accounts:lookup", request);
}
function utcTimestampToDateString(utcTimestamp) {
  if (!utcTimestamp) {
    return void 0;
  }
  try {
    const date = new Date(Number(utcTimestamp));
    if (!isNaN(date.getTime())) {
      return date.toUTCString();
    }
  } catch (e) {}
  return void 0;
}
function getIdToken(user, forceRefresh = false) {
  return (0, import_util.getModularInstance)(user).getIdToken(forceRefresh);
}
async function getIdTokenResult(user, forceRefresh = false) {
  const userInternal = (0, import_util.getModularInstance)(user);
  const token = await userInternal.getIdToken(forceRefresh);
  const claims = _parseToken(token);
  _assert(claims && claims.exp && claims.auth_time && claims.iat, userInternal.auth, "internal-error");
  const firebase = typeof claims.firebase === "object" ? claims.firebase : void 0;
  const signInProvider = firebase === null || firebase === void 0 ? void 0 : firebase["sign_in_provider"];
  return {
    claims,
    token,
    authTime: utcTimestampToDateString(secondsStringToMilliseconds(claims.auth_time)),
    issuedAtTime: utcTimestampToDateString(secondsStringToMilliseconds(claims.iat)),
    expirationTime: utcTimestampToDateString(secondsStringToMilliseconds(claims.exp)),
    signInProvider: signInProvider || null,
    signInSecondFactor: (firebase === null || firebase === void 0 ? void 0 : firebase["sign_in_second_factor"]) || null
  };
}
function secondsStringToMilliseconds(seconds) {
  return Number(seconds) * 1e3;
}
function _parseToken(token) {
  const [algorithm, payload, signature] = token.split(".");
  if (algorithm === void 0 || payload === void 0 || signature === void 0) {
    _logError("JWT malformed, contained fewer than 3 sections");
    return null;
  }
  try {
    const decoded = (0, import_util.base64Decode)(payload);
    if (!decoded) {
      _logError("Failed to decode base64 JWT payload");
      return null;
    }
    return JSON.parse(decoded);
  } catch (e) {
    _logError("Caught error parsing JWT payload as JSON", e === null || e === void 0 ? void 0 : e.toString());
    return null;
  }
}
function _tokenExpiresIn(token) {
  const parsedToken = _parseToken(token);
  _assert(parsedToken, "internal-error");
  _assert(typeof parsedToken.exp !== "undefined", "internal-error");
  _assert(typeof parsedToken.iat !== "undefined", "internal-error");
  return Number(parsedToken.exp) - Number(parsedToken.iat);
}
async function _logoutIfInvalidated(user, promise, bypassAuthState = false) {
  if (bypassAuthState) {
    return promise;
  }
  try {
    return await promise;
  } catch (e) {
    if (e instanceof import_util.FirebaseError && isUserInvalidated(e)) {
      if (user.auth.currentUser === user) {
        await user.auth.signOut();
      }
    }
    throw e;
  }
}
function isUserInvalidated({
  code
}) {
  return code === `auth/${"user-disabled"}` || code === `auth/${"user-token-expired"}`;
}
var ProactiveRefresh = class {
  constructor(user) {
    this.user = user;
    this.isRunning = false;
    this.timerId = null;
    this.errorBackoff = 3e4;
  }
  _start() {
    if (this.isRunning) {
      return;
    }
    this.isRunning = true;
    this.schedule();
  }
  _stop() {
    if (!this.isRunning) {
      return;
    }
    this.isRunning = false;
    if (this.timerId !== null) {
      clearTimeout(this.timerId);
    }
  }
  getInterval(wasError) {
    var _a;
    if (wasError) {
      const interval = this.errorBackoff;
      this.errorBackoff = Math.min(this.errorBackoff * 2, 96e4);
      return interval;
    } else {
      this.errorBackoff = 3e4;
      const expTime = (_a = this.user.stsTokenManager.expirationTime) !== null && _a !== void 0 ? _a : 0;
      const interval = expTime - Date.now() - 3e5;
      return Math.max(0, interval);
    }
  }
  schedule(wasError = false) {
    if (!this.isRunning) {
      return;
    }
    const interval = this.getInterval(wasError);
    this.timerId = setTimeout(async () => {
      await this.iteration();
    }, interval);
  }
  async iteration() {
    try {
      await this.user.getIdToken(true);
    } catch (e) {
      if ((e === null || e === void 0 ? void 0 : e.code) === `auth/${"network-request-failed"}`) {
        this.schedule(true);
      }
      return;
    }
    this.schedule();
  }
};
var UserMetadata = class {
  constructor(createdAt, lastLoginAt) {
    this.createdAt = createdAt;
    this.lastLoginAt = lastLoginAt;
    this._initializeTime();
  }
  _initializeTime() {
    this.lastSignInTime = utcTimestampToDateString(this.lastLoginAt);
    this.creationTime = utcTimestampToDateString(this.createdAt);
  }
  _copy(metadata) {
    this.createdAt = metadata.createdAt;
    this.lastLoginAt = metadata.lastLoginAt;
    this._initializeTime();
  }
  toJSON() {
    return {
      createdAt: this.createdAt,
      lastLoginAt: this.lastLoginAt
    };
  }
};
async function _reloadWithoutSaving(user) {
  var _a;
  const auth = user.auth;
  const idToken = await user.getIdToken();
  const response = await _logoutIfInvalidated(user, getAccountInfo(auth, {
    idToken
  }));
  _assert(response === null || response === void 0 ? void 0 : response.users.length, auth, "internal-error");
  const coreAccount = response.users[0];
  user._notifyReloadListener(coreAccount);
  const newProviderData = ((_a = coreAccount.providerUserInfo) === null || _a === void 0 ? void 0 : _a.length) ? extractProviderData(coreAccount.providerUserInfo) : [];
  const providerData = mergeProviderData(user.providerData, newProviderData);
  const oldIsAnonymous = user.isAnonymous;
  const newIsAnonymous = !(user.email && coreAccount.passwordHash) && !(providerData === null || providerData === void 0 ? void 0 : providerData.length);
  const isAnonymous = !oldIsAnonymous ? false : newIsAnonymous;
  const updates = {
    uid: coreAccount.localId,
    displayName: coreAccount.displayName || null,
    photoURL: coreAccount.photoUrl || null,
    email: coreAccount.email || null,
    emailVerified: coreAccount.emailVerified || false,
    phoneNumber: coreAccount.phoneNumber || null,
    tenantId: coreAccount.tenantId || null,
    providerData,
    metadata: new UserMetadata(coreAccount.createdAt, coreAccount.lastLoginAt),
    isAnonymous
  };
  Object.assign(user, updates);
}
async function reload(user) {
  const userInternal = (0, import_util.getModularInstance)(user);
  await _reloadWithoutSaving(userInternal);
  await userInternal.auth._persistUserIfCurrent(userInternal);
  userInternal.auth._notifyListenersIfCurrent(userInternal);
}
function mergeProviderData(original, newData) {
  const deduped = original.filter(o => !newData.some(n => n.providerId === o.providerId));
  return [...deduped, ...newData];
}
function extractProviderData(providers) {
  return providers.map(_a => {
    var {
        providerId
      } = _a,
      provider = (0, import_tslib.__rest)(_a, ["providerId"]);
    return {
      providerId,
      uid: provider.rawId || "",
      displayName: provider.displayName || null,
      email: provider.email || null,
      phoneNumber: provider.phoneNumber || null,
      photoURL: provider.photoUrl || null
    };
  });
}
async function requestStsToken(auth, refreshToken) {
  const response = await _performFetchWithErrorHandling(auth, {}, async () => {
    const body = (0, import_util.querystring)({
      "grant_type": "refresh_token",
      "refresh_token": refreshToken
    }).slice(1);
    const {
      tokenApiHost,
      apiKey
    } = auth.config;
    const url = _getFinalTarget(auth, tokenApiHost, "/v1/token", `key=${apiKey}`);
    const headers = await auth._getAdditionalHeaders();
    headers["Content-Type"] = "application/x-www-form-urlencoded";
    return FetchProvider.fetch()(url, {
      method: "POST",
      headers,
      body
    });
  });
  return {
    accessToken: response.access_token,
    expiresIn: response.expires_in,
    refreshToken: response.refresh_token
  };
}
async function revokeToken(auth, request) {
  return _performApiRequest(auth, "POST", "/v2/accounts:revokeToken", _addTidIfNecessary(auth, request));
}
var StsTokenManager = class {
  constructor() {
    this.refreshToken = null;
    this.accessToken = null;
    this.expirationTime = null;
  }
  get isExpired() {
    return !this.expirationTime || Date.now() > this.expirationTime - 3e4;
  }
  updateFromServerResponse(response) {
    _assert(response.idToken, "internal-error");
    _assert(typeof response.idToken !== "undefined", "internal-error");
    _assert(typeof response.refreshToken !== "undefined", "internal-error");
    const expiresIn = "expiresIn" in response && typeof response.expiresIn !== "undefined" ? Number(response.expiresIn) : _tokenExpiresIn(response.idToken);
    this.updateTokensAndExpiration(response.idToken, response.refreshToken, expiresIn);
  }
  async getToken(auth, forceRefresh = false) {
    _assert(!this.accessToken || this.refreshToken, auth, "user-token-expired");
    if (!forceRefresh && this.accessToken && !this.isExpired) {
      return this.accessToken;
    }
    if (this.refreshToken) {
      await this.refresh(auth, this.refreshToken);
      return this.accessToken;
    }
    return null;
  }
  clearRefreshToken() {
    this.refreshToken = null;
  }
  async refresh(auth, oldToken) {
    const {
      accessToken,
      refreshToken,
      expiresIn
    } = await requestStsToken(auth, oldToken);
    this.updateTokensAndExpiration(accessToken, refreshToken, Number(expiresIn));
  }
  updateTokensAndExpiration(accessToken, refreshToken, expiresInSec) {
    this.refreshToken = refreshToken || null;
    this.accessToken = accessToken || null;
    this.expirationTime = Date.now() + expiresInSec * 1e3;
  }
  static fromJSON(appName, object) {
    const {
      refreshToken,
      accessToken,
      expirationTime
    } = object;
    const manager = new StsTokenManager();
    if (refreshToken) {
      _assert(typeof refreshToken === "string", "internal-error", {
        appName
      });
      manager.refreshToken = refreshToken;
    }
    if (accessToken) {
      _assert(typeof accessToken === "string", "internal-error", {
        appName
      });
      manager.accessToken = accessToken;
    }
    if (expirationTime) {
      _assert(typeof expirationTime === "number", "internal-error", {
        appName
      });
      manager.expirationTime = expirationTime;
    }
    return manager;
  }
  toJSON() {
    return {
      refreshToken: this.refreshToken,
      accessToken: this.accessToken,
      expirationTime: this.expirationTime
    };
  }
  _assign(stsTokenManager) {
    this.accessToken = stsTokenManager.accessToken;
    this.refreshToken = stsTokenManager.refreshToken;
    this.expirationTime = stsTokenManager.expirationTime;
  }
  _clone() {
    return Object.assign(new StsTokenManager(), this.toJSON());
  }
  _performRefresh() {
    return debugFail("not implemented");
  }
};
function assertStringOrUndefined(assertion, appName) {
  _assert(typeof assertion === "string" || typeof assertion === "undefined", "internal-error", {
    appName
  });
}
var UserImpl = class {
  constructor(_a) {
    var {
        uid,
        auth,
        stsTokenManager
      } = _a,
      opt = (0, import_tslib.__rest)(_a, ["uid", "auth", "stsTokenManager"]);
    this.providerId = "firebase";
    this.proactiveRefresh = new ProactiveRefresh(this);
    this.reloadUserInfo = null;
    this.reloadListener = null;
    this.uid = uid;
    this.auth = auth;
    this.stsTokenManager = stsTokenManager;
    this.accessToken = stsTokenManager.accessToken;
    this.displayName = opt.displayName || null;
    this.email = opt.email || null;
    this.emailVerified = opt.emailVerified || false;
    this.phoneNumber = opt.phoneNumber || null;
    this.photoURL = opt.photoURL || null;
    this.isAnonymous = opt.isAnonymous || false;
    this.tenantId = opt.tenantId || null;
    this.providerData = opt.providerData ? [...opt.providerData] : [];
    this.metadata = new UserMetadata(opt.createdAt || void 0, opt.lastLoginAt || void 0);
  }
  async getIdToken(forceRefresh) {
    const accessToken = await _logoutIfInvalidated(this, this.stsTokenManager.getToken(this.auth, forceRefresh));
    _assert(accessToken, this.auth, "internal-error");
    if (this.accessToken !== accessToken) {
      this.accessToken = accessToken;
      await this.auth._persistUserIfCurrent(this);
      this.auth._notifyListenersIfCurrent(this);
    }
    return accessToken;
  }
  getIdTokenResult(forceRefresh) {
    return getIdTokenResult(this, forceRefresh);
  }
  reload() {
    return reload(this);
  }
  _assign(user) {
    if (this === user) {
      return;
    }
    _assert(this.uid === user.uid, this.auth, "internal-error");
    this.displayName = user.displayName;
    this.photoURL = user.photoURL;
    this.email = user.email;
    this.emailVerified = user.emailVerified;
    this.phoneNumber = user.phoneNumber;
    this.isAnonymous = user.isAnonymous;
    this.tenantId = user.tenantId;
    this.providerData = user.providerData.map(userInfo => Object.assign({}, userInfo));
    this.metadata._copy(user.metadata);
    this.stsTokenManager._assign(user.stsTokenManager);
  }
  _clone(auth) {
    const newUser = new UserImpl(Object.assign(Object.assign({}, this), {
      auth,
      stsTokenManager: this.stsTokenManager._clone()
    }));
    newUser.metadata._copy(this.metadata);
    return newUser;
  }
  _onReload(callback) {
    _assert(!this.reloadListener, this.auth, "internal-error");
    this.reloadListener = callback;
    if (this.reloadUserInfo) {
      this._notifyReloadListener(this.reloadUserInfo);
      this.reloadUserInfo = null;
    }
  }
  _notifyReloadListener(userInfo) {
    if (this.reloadListener) {
      this.reloadListener(userInfo);
    } else {
      this.reloadUserInfo = userInfo;
    }
  }
  _startProactiveRefresh() {
    this.proactiveRefresh._start();
  }
  _stopProactiveRefresh() {
    this.proactiveRefresh._stop();
  }
  async _updateTokensIfNecessary(response, reload2 = false) {
    let tokensRefreshed = false;
    if (response.idToken && response.idToken !== this.stsTokenManager.accessToken) {
      this.stsTokenManager.updateFromServerResponse(response);
      tokensRefreshed = true;
    }
    if (reload2) {
      await _reloadWithoutSaving(this);
    }
    await this.auth._persistUserIfCurrent(this);
    if (tokensRefreshed) {
      this.auth._notifyListenersIfCurrent(this);
    }
  }
  async delete() {
    const idToken = await this.getIdToken();
    await _logoutIfInvalidated(this, deleteAccount(this.auth, {
      idToken
    }));
    this.stsTokenManager.clearRefreshToken();
    return this.auth.signOut();
  }
  toJSON() {
    return Object.assign(Object.assign({
      uid: this.uid,
      email: this.email || void 0,
      emailVerified: this.emailVerified,
      displayName: this.displayName || void 0,
      isAnonymous: this.isAnonymous,
      photoURL: this.photoURL || void 0,
      phoneNumber: this.phoneNumber || void 0,
      tenantId: this.tenantId || void 0,
      providerData: this.providerData.map(userInfo => Object.assign({}, userInfo)),
      stsTokenManager: this.stsTokenManager.toJSON(),
      _redirectEventId: this._redirectEventId
    }, this.metadata.toJSON()), {
      apiKey: this.auth.config.apiKey,
      appName: this.auth.name
    });
  }
  get refreshToken() {
    return this.stsTokenManager.refreshToken || "";
  }
  static _fromJSON(auth, object) {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    const displayName = (_a = object.displayName) !== null && _a !== void 0 ? _a : void 0;
    const email = (_b = object.email) !== null && _b !== void 0 ? _b : void 0;
    const phoneNumber = (_c = object.phoneNumber) !== null && _c !== void 0 ? _c : void 0;
    const photoURL = (_d = object.photoURL) !== null && _d !== void 0 ? _d : void 0;
    const tenantId = (_e = object.tenantId) !== null && _e !== void 0 ? _e : void 0;
    const _redirectEventId = (_f = object._redirectEventId) !== null && _f !== void 0 ? _f : void 0;
    const createdAt = (_g = object.createdAt) !== null && _g !== void 0 ? _g : void 0;
    const lastLoginAt = (_h = object.lastLoginAt) !== null && _h !== void 0 ? _h : void 0;
    const {
      uid,
      emailVerified,
      isAnonymous,
      providerData,
      stsTokenManager: plainObjectTokenManager
    } = object;
    _assert(uid && plainObjectTokenManager, auth, "internal-error");
    const stsTokenManager = StsTokenManager.fromJSON(this.name, plainObjectTokenManager);
    _assert(typeof uid === "string", auth, "internal-error");
    assertStringOrUndefined(displayName, auth.name);
    assertStringOrUndefined(email, auth.name);
    _assert(typeof emailVerified === "boolean", auth, "internal-error");
    _assert(typeof isAnonymous === "boolean", auth, "internal-error");
    assertStringOrUndefined(phoneNumber, auth.name);
    assertStringOrUndefined(photoURL, auth.name);
    assertStringOrUndefined(tenantId, auth.name);
    assertStringOrUndefined(_redirectEventId, auth.name);
    assertStringOrUndefined(createdAt, auth.name);
    assertStringOrUndefined(lastLoginAt, auth.name);
    const user = new UserImpl({
      uid,
      auth,
      email,
      emailVerified,
      displayName,
      isAnonymous,
      photoURL,
      phoneNumber,
      tenantId,
      stsTokenManager,
      createdAt,
      lastLoginAt
    });
    if (providerData && Array.isArray(providerData)) {
      user.providerData = providerData.map(userInfo => Object.assign({}, userInfo));
    }
    if (_redirectEventId) {
      user._redirectEventId = _redirectEventId;
    }
    return user;
  }
  static async _fromIdTokenResponse(auth, idTokenResponse, isAnonymous = false) {
    const stsTokenManager = new StsTokenManager();
    stsTokenManager.updateFromServerResponse(idTokenResponse);
    const user = new UserImpl({
      uid: idTokenResponse.localId,
      auth,
      stsTokenManager,
      isAnonymous
    });
    await _reloadWithoutSaving(user);
    return user;
  }
};
var instanceCache = /* @__PURE__ */new Map();
function _getInstance(cls) {
  debugAssert(cls instanceof Function, "Expected a class definition");
  let instance = instanceCache.get(cls);
  if (instance) {
    debugAssert(instance instanceof cls, "Instance stored in cache mismatched with class");
    return instance;
  }
  instance = new cls();
  instanceCache.set(cls, instance);
  return instance;
}
var InMemoryPersistence = class {
  constructor() {
    this.type = "NONE";
    this.storage = {};
  }
  async _isAvailable() {
    return true;
  }
  async _set(key, value) {
    this.storage[key] = value;
  }
  async _get(key) {
    const value = this.storage[key];
    return value === void 0 ? null : value;
  }
  async _remove(key) {
    delete this.storage[key];
  }
  _addListener(_key, _listener) {
    return;
  }
  _removeListener(_key, _listener) {
    return;
  }
};
InMemoryPersistence.type = "NONE";
var inMemoryPersistence = InMemoryPersistence;
function _persistenceKeyName(key, apiKey, appName) {
  return `${"firebase"}:${key}:${apiKey}:${appName}`;
}
var PersistenceUserManager = class {
  constructor(persistence, auth, userKey) {
    this.persistence = persistence;
    this.auth = auth;
    this.userKey = userKey;
    const {
      config,
      name: name2
    } = this.auth;
    this.fullUserKey = _persistenceKeyName(this.userKey, config.apiKey, name2);
    this.fullPersistenceKey = _persistenceKeyName("persistence", config.apiKey, name2);
    this.boundEventHandler = auth._onStorageEvent.bind(auth);
    this.persistence._addListener(this.fullUserKey, this.boundEventHandler);
  }
  setCurrentUser(user) {
    return this.persistence._set(this.fullUserKey, user.toJSON());
  }
  async getCurrentUser() {
    const blob = await this.persistence._get(this.fullUserKey);
    return blob ? UserImpl._fromJSON(this.auth, blob) : null;
  }
  removeCurrentUser() {
    return this.persistence._remove(this.fullUserKey);
  }
  savePersistenceForRedirect() {
    return this.persistence._set(this.fullPersistenceKey, this.persistence.type);
  }
  async setPersistence(newPersistence) {
    if (this.persistence === newPersistence) {
      return;
    }
    const currentUser = await this.getCurrentUser();
    await this.removeCurrentUser();
    this.persistence = newPersistence;
    if (currentUser) {
      return this.setCurrentUser(currentUser);
    }
  }
  delete() {
    this.persistence._removeListener(this.fullUserKey, this.boundEventHandler);
  }
  static async create(auth, persistenceHierarchy, userKey = "authUser") {
    if (!persistenceHierarchy.length) {
      return new PersistenceUserManager(_getInstance(inMemoryPersistence), auth, userKey);
    }
    const availablePersistences = (await Promise.all(persistenceHierarchy.map(async persistence => {
      if (await persistence._isAvailable()) {
        return persistence;
      }
      return void 0;
    }))).filter(persistence => persistence);
    let selectedPersistence = availablePersistences[0] || _getInstance(inMemoryPersistence);
    const key = _persistenceKeyName(userKey, auth.config.apiKey, auth.name);
    let userToMigrate = null;
    for (const persistence of persistenceHierarchy) {
      try {
        const blob = await persistence._get(key);
        if (blob) {
          const user = UserImpl._fromJSON(auth, blob);
          if (persistence !== selectedPersistence) {
            userToMigrate = user;
          }
          selectedPersistence = persistence;
          break;
        }
      } catch (_a) {}
    }
    const migrationHierarchy = availablePersistences.filter(p => p._shouldAllowMigration);
    if (!selectedPersistence._shouldAllowMigration || !migrationHierarchy.length) {
      return new PersistenceUserManager(selectedPersistence, auth, userKey);
    }
    selectedPersistence = migrationHierarchy[0];
    if (userToMigrate) {
      await selectedPersistence._set(key, userToMigrate.toJSON());
    }
    await Promise.all(persistenceHierarchy.map(async persistence => {
      if (persistence !== selectedPersistence) {
        try {
          await persistence._remove(key);
        } catch (_a) {}
      }
    }));
    return new PersistenceUserManager(selectedPersistence, auth, userKey);
  }
};
function _getBrowserName(userAgent) {
  const ua = userAgent.toLowerCase();
  if (ua.includes("opera/") || ua.includes("opr/") || ua.includes("opios/")) {
    return "Opera";
  } else if (_isIEMobile(ua)) {
    return "IEMobile";
  } else if (ua.includes("msie") || ua.includes("trident/")) {
    return "IE";
  } else if (ua.includes("edge/")) {
    return "Edge";
  } else if (_isFirefox(ua)) {
    return "Firefox";
  } else if (ua.includes("silk/")) {
    return "Silk";
  } else if (_isBlackBerry(ua)) {
    return "Blackberry";
  } else if (_isWebOS(ua)) {
    return "Webos";
  } else if (_isSafari(ua)) {
    return "Safari";
  } else if ((ua.includes("chrome/") || _isChromeIOS(ua)) && !ua.includes("edge/")) {
    return "Chrome";
  } else if (_isAndroid(ua)) {
    return "Android";
  } else {
    const re = /([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/;
    const matches = userAgent.match(re);
    if ((matches === null || matches === void 0 ? void 0 : matches.length) === 2) {
      return matches[1];
    }
  }
  return "Other";
}
function _isFirefox(ua = (0, import_util.getUA)()) {
  return /firefox\//i.test(ua);
}
function _isSafari(userAgent = (0, import_util.getUA)()) {
  const ua = userAgent.toLowerCase();
  return ua.includes("safari/") && !ua.includes("chrome/") && !ua.includes("crios/") && !ua.includes("android");
}
function _isChromeIOS(ua = (0, import_util.getUA)()) {
  return /crios\//i.test(ua);
}
function _isIEMobile(ua = (0, import_util.getUA)()) {
  return /iemobile/i.test(ua);
}
function _isAndroid(ua = (0, import_util.getUA)()) {
  return /android/i.test(ua);
}
function _isBlackBerry(ua = (0, import_util.getUA)()) {
  return /blackberry/i.test(ua);
}
function _isWebOS(ua = (0, import_util.getUA)()) {
  return /webos/i.test(ua);
}
function _isIOS(ua = (0, import_util.getUA)()) {
  return /iphone|ipad|ipod/i.test(ua) || /macintosh/i.test(ua) && /mobile/i.test(ua);
}
function _isIOS7Or8(ua = (0, import_util.getUA)()) {
  return /(iPad|iPhone|iPod).*OS 7_\d/i.test(ua) || /(iPad|iPhone|iPod).*OS 8_\d/i.test(ua);
}
function _isIOSStandalone(ua = (0, import_util.getUA)()) {
  var _a;
  return _isIOS(ua) && !!((_a = window.navigator) === null || _a === void 0 ? void 0 : _a.standalone);
}
function _isIE10() {
  return (0, import_util.isIE)() && document.documentMode === 10;
}
function _isMobileBrowser(ua = (0, import_util.getUA)()) {
  return _isIOS(ua) || _isAndroid(ua) || _isWebOS(ua) || _isBlackBerry(ua) || /windows phone/i.test(ua) || _isIEMobile(ua);
}
function _isIframe() {
  try {
    return !!(window && window !== window.top);
  } catch (e) {
    return false;
  }
}
function _getClientVersion(clientPlatform, frameworks = []) {
  let reportedPlatform;
  switch (clientPlatform) {
    case "Browser":
      reportedPlatform = _getBrowserName((0, import_util.getUA)());
      break;
    case "Worker":
      reportedPlatform = `${_getBrowserName((0, import_util.getUA)())}-${clientPlatform}`;
      break;
    default:
      reportedPlatform = clientPlatform;
  }
  const reportedFrameworks = frameworks.length ? frameworks.join(",") : "FirebaseCore-web";
  return `${reportedPlatform}/${"JsCore"}/${import_app.SDK_VERSION}/${reportedFrameworks}`;
}
var AuthMiddlewareQueue = class {
  constructor(auth) {
    this.auth = auth;
    this.queue = [];
  }
  pushCallback(callback, onAbort) {
    const wrappedCallback = user => new Promise((resolve, reject) => {
      try {
        const result = callback(user);
        resolve(result);
      } catch (e) {
        reject(e);
      }
    });
    wrappedCallback.onAbort = onAbort;
    this.queue.push(wrappedCallback);
    const index = this.queue.length - 1;
    return () => {
      this.queue[index] = () => Promise.resolve();
    };
  }
  async runMiddleware(nextUser) {
    if (this.auth.currentUser === nextUser) {
      return;
    }
    const onAbortStack = [];
    try {
      for (const beforeStateCallback of this.queue) {
        await beforeStateCallback(nextUser);
        if (beforeStateCallback.onAbort) {
          onAbortStack.push(beforeStateCallback.onAbort);
        }
      }
    } catch (e) {
      onAbortStack.reverse();
      for (const onAbort of onAbortStack) {
        try {
          onAbort();
        } catch (_) {}
      }
      throw this.auth._errorFactory.create("login-blocked", {
        originalMessage: e === null || e === void 0 ? void 0 : e.message
      });
    }
  }
};
async function _getPasswordPolicy(auth, request = {}) {
  return _performApiRequest(auth, "GET", "/v2/passwordPolicy", _addTidIfNecessary(auth, request));
}
var MINIMUM_MIN_PASSWORD_LENGTH = 6;
var PasswordPolicyImpl = class {
  constructor(response) {
    var _a, _b, _c, _d;
    const responseOptions = response.customStrengthOptions;
    this.customStrengthOptions = {};
    this.customStrengthOptions.minPasswordLength = (_a = responseOptions.minPasswordLength) !== null && _a !== void 0 ? _a : MINIMUM_MIN_PASSWORD_LENGTH;
    if (responseOptions.maxPasswordLength) {
      this.customStrengthOptions.maxPasswordLength = responseOptions.maxPasswordLength;
    }
    if (responseOptions.containsLowercaseCharacter !== void 0) {
      this.customStrengthOptions.containsLowercaseLetter = responseOptions.containsLowercaseCharacter;
    }
    if (responseOptions.containsUppercaseCharacter !== void 0) {
      this.customStrengthOptions.containsUppercaseLetter = responseOptions.containsUppercaseCharacter;
    }
    if (responseOptions.containsNumericCharacter !== void 0) {
      this.customStrengthOptions.containsNumericCharacter = responseOptions.containsNumericCharacter;
    }
    if (responseOptions.containsNonAlphanumericCharacter !== void 0) {
      this.customStrengthOptions.containsNonAlphanumericCharacter = responseOptions.containsNonAlphanumericCharacter;
    }
    this.enforcementState = response.enforcementState;
    if (this.enforcementState === "ENFORCEMENT_STATE_UNSPECIFIED") {
      this.enforcementState = "OFF";
    }
    this.allowedNonAlphanumericCharacters = (_c = (_b = response.allowedNonAlphanumericCharacters) === null || _b === void 0 ? void 0 : _b.join("")) !== null && _c !== void 0 ? _c : "";
    this.forceUpgradeOnSignin = (_d = response.forceUpgradeOnSignin) !== null && _d !== void 0 ? _d : false;
    this.schemaVersion = response.schemaVersion;
  }
  validatePassword(password) {
    var _a, _b, _c, _d, _e, _f;
    const status = {
      isValid: true,
      passwordPolicy: this
    };
    this.validatePasswordLengthOptions(password, status);
    this.validatePasswordCharacterOptions(password, status);
    status.isValid && (status.isValid = (_a = status.meetsMinPasswordLength) !== null && _a !== void 0 ? _a : true);
    status.isValid && (status.isValid = (_b = status.meetsMaxPasswordLength) !== null && _b !== void 0 ? _b : true);
    status.isValid && (status.isValid = (_c = status.containsLowercaseLetter) !== null && _c !== void 0 ? _c : true);
    status.isValid && (status.isValid = (_d = status.containsUppercaseLetter) !== null && _d !== void 0 ? _d : true);
    status.isValid && (status.isValid = (_e = status.containsNumericCharacter) !== null && _e !== void 0 ? _e : true);
    status.isValid && (status.isValid = (_f = status.containsNonAlphanumericCharacter) !== null && _f !== void 0 ? _f : true);
    return status;
  }
  validatePasswordLengthOptions(password, status) {
    const minPasswordLength = this.customStrengthOptions.minPasswordLength;
    const maxPasswordLength = this.customStrengthOptions.maxPasswordLength;
    if (minPasswordLength) {
      status.meetsMinPasswordLength = password.length >= minPasswordLength;
    }
    if (maxPasswordLength) {
      status.meetsMaxPasswordLength = password.length <= maxPasswordLength;
    }
  }
  validatePasswordCharacterOptions(password, status) {
    this.updatePasswordCharacterOptionsStatuses(status, false, false, false, false);
    let passwordChar;
    for (let i = 0; i < password.length; i++) {
      passwordChar = password.charAt(i);
      this.updatePasswordCharacterOptionsStatuses(status, passwordChar >= "a" && passwordChar <= "z", passwordChar >= "A" && passwordChar <= "Z", passwordChar >= "0" && passwordChar <= "9", this.allowedNonAlphanumericCharacters.includes(passwordChar));
    }
  }
  updatePasswordCharacterOptionsStatuses(status, containsLowercaseCharacter, containsUppercaseCharacter, containsNumericCharacter, containsNonAlphanumericCharacter) {
    if (this.customStrengthOptions.containsLowercaseLetter) {
      status.containsLowercaseLetter || (status.containsLowercaseLetter = containsLowercaseCharacter);
    }
    if (this.customStrengthOptions.containsUppercaseLetter) {
      status.containsUppercaseLetter || (status.containsUppercaseLetter = containsUppercaseCharacter);
    }
    if (this.customStrengthOptions.containsNumericCharacter) {
      status.containsNumericCharacter || (status.containsNumericCharacter = containsNumericCharacter);
    }
    if (this.customStrengthOptions.containsNonAlphanumericCharacter) {
      status.containsNonAlphanumericCharacter || (status.containsNonAlphanumericCharacter = containsNonAlphanumericCharacter);
    }
  }
};
var AuthImpl = class {
  constructor(app, heartbeatServiceProvider, appCheckServiceProvider, config) {
    this.app = app;
    this.heartbeatServiceProvider = heartbeatServiceProvider;
    this.appCheckServiceProvider = appCheckServiceProvider;
    this.config = config;
    this.currentUser = null;
    this.emulatorConfig = null;
    this.operations = Promise.resolve();
    this.authStateSubscription = new Subscription(this);
    this.idTokenSubscription = new Subscription(this);
    this.beforeStateQueue = new AuthMiddlewareQueue(this);
    this.redirectUser = null;
    this.isProactiveRefreshEnabled = false;
    this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION = 1;
    this._canInitEmulator = true;
    this._isInitialized = false;
    this._deleted = false;
    this._initializationPromise = null;
    this._popupRedirectResolver = null;
    this._errorFactory = _DEFAULT_AUTH_ERROR_FACTORY;
    this._agentRecaptchaConfig = null;
    this._tenantRecaptchaConfigs = {};
    this._projectPasswordPolicy = null;
    this._tenantPasswordPolicies = {};
    this.lastNotifiedUid = void 0;
    this.languageCode = null;
    this.tenantId = null;
    this.settings = {
      appVerificationDisabledForTesting: false
    };
    this.frameworks = [];
    this.name = app.name;
    this.clientVersion = config.sdkClientVersion;
  }
  _initializeWithPersistence(persistenceHierarchy, popupRedirectResolver) {
    if (popupRedirectResolver) {
      this._popupRedirectResolver = _getInstance(popupRedirectResolver);
    }
    this._initializationPromise = this.queue(async () => {
      var _a, _b;
      if (this._deleted) {
        return;
      }
      this.persistenceManager = await PersistenceUserManager.create(this, persistenceHierarchy);
      if (this._deleted) {
        return;
      }
      if ((_a = this._popupRedirectResolver) === null || _a === void 0 ? void 0 : _a._shouldInitProactively) {
        try {
          await this._popupRedirectResolver._initialize(this);
        } catch (e) {}
      }
      await this.initializeCurrentUser(popupRedirectResolver);
      this.lastNotifiedUid = ((_b = this.currentUser) === null || _b === void 0 ? void 0 : _b.uid) || null;
      if (this._deleted) {
        return;
      }
      this._isInitialized = true;
    });
    return this._initializationPromise;
  }
  async _onStorageEvent() {
    if (this._deleted) {
      return;
    }
    const user = await this.assertedPersistence.getCurrentUser();
    if (!this.currentUser && !user) {
      return;
    }
    if (this.currentUser && user && this.currentUser.uid === user.uid) {
      this._currentUser._assign(user);
      await this.currentUser.getIdToken();
      return;
    }
    await this._updateCurrentUser(user, true);
  }
  async initializeCurrentUser(popupRedirectResolver) {
    var _a;
    const previouslyStoredUser = await this.assertedPersistence.getCurrentUser();
    let futureCurrentUser = previouslyStoredUser;
    let needsTocheckMiddleware = false;
    if (popupRedirectResolver && this.config.authDomain) {
      await this.getOrInitRedirectPersistenceManager();
      const redirectUserEventId = (_a = this.redirectUser) === null || _a === void 0 ? void 0 : _a._redirectEventId;
      const storedUserEventId = futureCurrentUser === null || futureCurrentUser === void 0 ? void 0 : futureCurrentUser._redirectEventId;
      const result = await this.tryRedirectSignIn(popupRedirectResolver);
      if ((!redirectUserEventId || redirectUserEventId === storedUserEventId) && (result === null || result === void 0 ? void 0 : result.user)) {
        futureCurrentUser = result.user;
        needsTocheckMiddleware = true;
      }
    }
    if (!futureCurrentUser) {
      return this.directlySetCurrentUser(null);
    }
    if (!futureCurrentUser._redirectEventId) {
      if (needsTocheckMiddleware) {
        try {
          await this.beforeStateQueue.runMiddleware(futureCurrentUser);
        } catch (e) {
          futureCurrentUser = previouslyStoredUser;
          this._popupRedirectResolver._overrideRedirectResult(this, () => Promise.reject(e));
        }
      }
      if (futureCurrentUser) {
        return this.reloadAndSetCurrentUserOrClear(futureCurrentUser);
      } else {
        return this.directlySetCurrentUser(null);
      }
    }
    _assert(this._popupRedirectResolver, this, "argument-error");
    await this.getOrInitRedirectPersistenceManager();
    if (this.redirectUser && this.redirectUser._redirectEventId === futureCurrentUser._redirectEventId) {
      return this.directlySetCurrentUser(futureCurrentUser);
    }
    return this.reloadAndSetCurrentUserOrClear(futureCurrentUser);
  }
  async tryRedirectSignIn(redirectResolver) {
    let result = null;
    try {
      result = await this._popupRedirectResolver._completeRedirectFn(this, redirectResolver, true);
    } catch (e) {
      await this._setRedirectUser(null);
    }
    return result;
  }
  async reloadAndSetCurrentUserOrClear(user) {
    try {
      await _reloadWithoutSaving(user);
    } catch (e) {
      if ((e === null || e === void 0 ? void 0 : e.code) !== `auth/${"network-request-failed"}`) {
        return this.directlySetCurrentUser(null);
      }
    }
    return this.directlySetCurrentUser(user);
  }
  useDeviceLanguage() {
    this.languageCode = _getUserLanguage();
  }
  async _delete() {
    this._deleted = true;
  }
  async updateCurrentUser(userExtern) {
    const user = userExtern ? (0, import_util.getModularInstance)(userExtern) : null;
    if (user) {
      _assert(user.auth.config.apiKey === this.config.apiKey, this, "invalid-user-token");
    }
    return this._updateCurrentUser(user && user._clone(this));
  }
  async _updateCurrentUser(user, skipBeforeStateCallbacks = false) {
    if (this._deleted) {
      return;
    }
    if (user) {
      _assert(this.tenantId === user.tenantId, this, "tenant-id-mismatch");
    }
    if (!skipBeforeStateCallbacks) {
      await this.beforeStateQueue.runMiddleware(user);
    }
    return this.queue(async () => {
      await this.directlySetCurrentUser(user);
      this.notifyAuthListeners();
    });
  }
  async signOut() {
    await this.beforeStateQueue.runMiddleware(null);
    if (this.redirectPersistenceManager || this._popupRedirectResolver) {
      await this._setRedirectUser(null);
    }
    return this._updateCurrentUser(null, true);
  }
  setPersistence(persistence) {
    return this.queue(async () => {
      await this.assertedPersistence.setPersistence(_getInstance(persistence));
    });
  }
  _getRecaptchaConfig() {
    if (this.tenantId == null) {
      return this._agentRecaptchaConfig;
    } else {
      return this._tenantRecaptchaConfigs[this.tenantId];
    }
  }
  async validatePassword(password) {
    if (!this._getPasswordPolicyInternal()) {
      await this._updatePasswordPolicy();
    }
    const passwordPolicy = this._getPasswordPolicyInternal();
    if (passwordPolicy.schemaVersion !== this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION) {
      return Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version", {}));
    }
    return passwordPolicy.validatePassword(password);
  }
  _getPasswordPolicyInternal() {
    if (this.tenantId === null) {
      return this._projectPasswordPolicy;
    } else {
      return this._tenantPasswordPolicies[this.tenantId];
    }
  }
  async _updatePasswordPolicy() {
    const response = await _getPasswordPolicy(this);
    const passwordPolicy = new PasswordPolicyImpl(response);
    if (this.tenantId === null) {
      this._projectPasswordPolicy = passwordPolicy;
    } else {
      this._tenantPasswordPolicies[this.tenantId] = passwordPolicy;
    }
  }
  _getPersistence() {
    return this.assertedPersistence.persistence.type;
  }
  _updateErrorMap(errorMap) {
    this._errorFactory = new import_util.ErrorFactory("auth", "Firebase", errorMap());
  }
  onAuthStateChanged(nextOrObserver, error, completed) {
    return this.registerStateListener(this.authStateSubscription, nextOrObserver, error, completed);
  }
  beforeAuthStateChanged(callback, onAbort) {
    return this.beforeStateQueue.pushCallback(callback, onAbort);
  }
  onIdTokenChanged(nextOrObserver, error, completed) {
    return this.registerStateListener(this.idTokenSubscription, nextOrObserver, error, completed);
  }
  authStateReady() {
    return new Promise((resolve, reject) => {
      if (this.currentUser) {
        resolve();
      } else {
        const unsubscribe = this.onAuthStateChanged(() => {
          unsubscribe();
          resolve();
        }, reject);
      }
    });
  }
  async revokeAccessToken(token) {
    if (this.currentUser) {
      const idToken = await this.currentUser.getIdToken();
      const request = {
        providerId: "apple.com",
        tokenType: "ACCESS_TOKEN",
        token,
        idToken
      };
      if (this.tenantId != null) {
        request.tenantId = this.tenantId;
      }
      await revokeToken(this, request);
    }
  }
  toJSON() {
    var _a;
    return {
      apiKey: this.config.apiKey,
      authDomain: this.config.authDomain,
      appName: this.name,
      currentUser: (_a = this._currentUser) === null || _a === void 0 ? void 0 : _a.toJSON()
    };
  }
  async _setRedirectUser(user, popupRedirectResolver) {
    const redirectManager = await this.getOrInitRedirectPersistenceManager(popupRedirectResolver);
    return user === null ? redirectManager.removeCurrentUser() : redirectManager.setCurrentUser(user);
  }
  async getOrInitRedirectPersistenceManager(popupRedirectResolver) {
    if (!this.redirectPersistenceManager) {
      const resolver = popupRedirectResolver && _getInstance(popupRedirectResolver) || this._popupRedirectResolver;
      _assert(resolver, this, "argument-error");
      this.redirectPersistenceManager = await PersistenceUserManager.create(this, [_getInstance(resolver._redirectPersistence)], "redirectUser");
      this.redirectUser = await this.redirectPersistenceManager.getCurrentUser();
    }
    return this.redirectPersistenceManager;
  }
  async _redirectUserForId(id) {
    var _a, _b;
    if (this._isInitialized) {
      await this.queue(async () => {});
    }
    if (((_a = this._currentUser) === null || _a === void 0 ? void 0 : _a._redirectEventId) === id) {
      return this._currentUser;
    }
    if (((_b = this.redirectUser) === null || _b === void 0 ? void 0 : _b._redirectEventId) === id) {
      return this.redirectUser;
    }
    return null;
  }
  async _persistUserIfCurrent(user) {
    if (user === this.currentUser) {
      return this.queue(async () => this.directlySetCurrentUser(user));
    }
  }
  _notifyListenersIfCurrent(user) {
    if (user === this.currentUser) {
      this.notifyAuthListeners();
    }
  }
  _key() {
    return `${this.config.authDomain}:${this.config.apiKey}:${this.name}`;
  }
  _startProactiveRefresh() {
    this.isProactiveRefreshEnabled = true;
    if (this.currentUser) {
      this._currentUser._startProactiveRefresh();
    }
  }
  _stopProactiveRefresh() {
    this.isProactiveRefreshEnabled = false;
    if (this.currentUser) {
      this._currentUser._stopProactiveRefresh();
    }
  }
  get _currentUser() {
    return this.currentUser;
  }
  notifyAuthListeners() {
    var _a, _b;
    if (!this._isInitialized) {
      return;
    }
    this.idTokenSubscription.next(this.currentUser);
    const currentUid = (_b = (_a = this.currentUser) === null || _a === void 0 ? void 0 : _a.uid) !== null && _b !== void 0 ? _b : null;
    if (this.lastNotifiedUid !== currentUid) {
      this.lastNotifiedUid = currentUid;
      this.authStateSubscription.next(this.currentUser);
    }
  }
  registerStateListener(subscription, nextOrObserver, error, completed) {
    if (this._deleted) {
      return () => {};
    }
    const cb = typeof nextOrObserver === "function" ? nextOrObserver : nextOrObserver.next.bind(nextOrObserver);
    let isUnsubscribed = false;
    const promise = this._isInitialized ? Promise.resolve() : this._initializationPromise;
    _assert(promise, this, "internal-error");
    promise.then(() => {
      if (isUnsubscribed) {
        return;
      }
      cb(this.currentUser);
    });
    if (typeof nextOrObserver === "function") {
      const unsubscribe = subscription.addObserver(nextOrObserver, error, completed);
      return () => {
        isUnsubscribed = true;
        unsubscribe();
      };
    } else {
      const unsubscribe = subscription.addObserver(nextOrObserver);
      return () => {
        isUnsubscribed = true;
        unsubscribe();
      };
    }
  }
  async directlySetCurrentUser(user) {
    if (this.currentUser && this.currentUser !== user) {
      this._currentUser._stopProactiveRefresh();
    }
    if (user && this.isProactiveRefreshEnabled) {
      user._startProactiveRefresh();
    }
    this.currentUser = user;
    if (user) {
      await this.assertedPersistence.setCurrentUser(user);
    } else {
      await this.assertedPersistence.removeCurrentUser();
    }
  }
  queue(action) {
    this.operations = this.operations.then(action, action);
    return this.operations;
  }
  get assertedPersistence() {
    _assert(this.persistenceManager, this, "internal-error");
    return this.persistenceManager;
  }
  _logFramework(framework) {
    if (!framework || this.frameworks.includes(framework)) {
      return;
    }
    this.frameworks.push(framework);
    this.frameworks.sort();
    this.clientVersion = _getClientVersion(this.config.clientPlatform, this._getFrameworks());
  }
  _getFrameworks() {
    return this.frameworks;
  }
  async _getAdditionalHeaders() {
    var _a;
    const headers = {
      ["X-Client-Version"]: this.clientVersion
    };
    if (this.app.options.appId) {
      headers["X-Firebase-gmpid"] = this.app.options.appId;
    }
    const heartbeatsHeader = await ((_a = this.heartbeatServiceProvider.getImmediate({
      optional: true
    })) === null || _a === void 0 ? void 0 : _a.getHeartbeatsHeader());
    if (heartbeatsHeader) {
      headers["X-Firebase-Client"] = heartbeatsHeader;
    }
    const appCheckToken = await this._getAppCheckToken();
    if (appCheckToken) {
      headers["X-Firebase-AppCheck"] = appCheckToken;
    }
    return headers;
  }
  async _getAppCheckToken() {
    var _a;
    const appCheckTokenResult = await ((_a = this.appCheckServiceProvider.getImmediate({
      optional: true
    })) === null || _a === void 0 ? void 0 : _a.getToken());
    if (appCheckTokenResult === null || appCheckTokenResult === void 0 ? void 0 : appCheckTokenResult.error) {
      _logWarn(`Error while retrieving App Check token: ${appCheckTokenResult.error}`);
    }
    return appCheckTokenResult === null || appCheckTokenResult === void 0 ? void 0 : appCheckTokenResult.token;
  }
};
function _castAuth(auth) {
  return (0, import_util.getModularInstance)(auth);
}
var Subscription = class {
  constructor(auth) {
    this.auth = auth;
    this.observer = null;
    this.addObserver = (0, import_util.createSubscribe)(observer => this.observer = observer);
  }
  get next() {
    _assert(this.observer, this.auth, "internal-error");
    return this.observer.next.bind(this.observer);
  }
};
function getScriptParentElement() {
  var _a, _b;
  return (_b = (_a = document.getElementsByTagName("head")) === null || _a === void 0 ? void 0 : _a[0]) !== null && _b !== void 0 ? _b : document;
}
function _loadJS(url) {
  return new Promise((resolve, reject) => {
    const el = document.createElement("script");
    el.setAttribute("src", url);
    el.onload = resolve;
    el.onerror = e => {
      const error = _createError("internal-error");
      error.customData = e;
      reject(error);
    };
    el.type = "text/javascript";
    el.charset = "UTF-8";
    getScriptParentElement().appendChild(el);
  });
}
function _generateCallbackName(prefix) {
  return `__${prefix}${Math.floor(Math.random() * 1e6)}`;
}
var RECAPTCHA_ENTERPRISE_URL = "https://www.google.com/recaptcha/enterprise.js?render=";
var RECAPTCHA_ENTERPRISE_VERIFIER_TYPE = "recaptcha-enterprise";
var FAKE_TOKEN = "NO_RECAPTCHA";
var RecaptchaEnterpriseVerifier = class {
  constructor(authExtern) {
    this.type = RECAPTCHA_ENTERPRISE_VERIFIER_TYPE;
    this.auth = _castAuth(authExtern);
  }
  async verify(action = "verify", forceRefresh = false) {
    async function retrieveSiteKey(auth) {
      if (!forceRefresh) {
        if (auth.tenantId == null && auth._agentRecaptchaConfig != null) {
          return auth._agentRecaptchaConfig.siteKey;
        }
        if (auth.tenantId != null && auth._tenantRecaptchaConfigs[auth.tenantId] !== void 0) {
          return auth._tenantRecaptchaConfigs[auth.tenantId].siteKey;
        }
      }
      return new Promise(async (resolve, reject) => {
        getRecaptchaConfig(auth, {
          clientType: "CLIENT_TYPE_WEB",
          version: "RECAPTCHA_ENTERPRISE"
        }).then(response => {
          if (response.recaptchaKey === void 0) {
            reject(new Error("recaptcha Enterprise site key undefined"));
          } else {
            const config = new RecaptchaConfig(response);
            if (auth.tenantId == null) {
              auth._agentRecaptchaConfig = config;
            } else {
              auth._tenantRecaptchaConfigs[auth.tenantId] = config;
            }
            return resolve(config.siteKey);
          }
        }).catch(error => {
          reject(error);
        });
      });
    }
    function retrieveRecaptchaToken(siteKey, resolve, reject) {
      const grecaptcha = window.grecaptcha;
      if (isEnterprise(grecaptcha)) {
        grecaptcha.enterprise.ready(() => {
          grecaptcha.enterprise.execute(siteKey, {
            action
          }).then(token => {
            resolve(token);
          }).catch(() => {
            resolve(FAKE_TOKEN);
          });
        });
      } else {
        reject(Error("No reCAPTCHA enterprise script loaded."));
      }
    }
    return new Promise((resolve, reject) => {
      retrieveSiteKey(this.auth).then(siteKey => {
        if (!forceRefresh && isEnterprise(window.grecaptcha)) {
          retrieveRecaptchaToken(siteKey, resolve, reject);
        } else {
          if (typeof window === "undefined") {
            reject(new Error("RecaptchaVerifier is only supported in browser"));
            return;
          }
          _loadJS(RECAPTCHA_ENTERPRISE_URL + siteKey).then(() => {
            retrieveRecaptchaToken(siteKey, resolve, reject);
          }).catch(error => {
            reject(error);
          });
        }
      }).catch(error => {
        reject(error);
      });
    });
  }
};
async function injectRecaptchaFields(auth, request, action, captchaResp = false) {
  const verifier = new RecaptchaEnterpriseVerifier(auth);
  let captchaResponse;
  try {
    captchaResponse = await verifier.verify(action);
  } catch (error) {
    captchaResponse = await verifier.verify(action, true);
  }
  const newRequest = Object.assign({}, request);
  if (!captchaResp) {
    Object.assign(newRequest, {
      captchaResponse
    });
  } else {
    Object.assign(newRequest, {
      "captchaResp": captchaResponse
    });
  }
  Object.assign(newRequest, {
    "clientType": "CLIENT_TYPE_WEB"
  });
  Object.assign(newRequest, {
    "recaptchaVersion": "RECAPTCHA_ENTERPRISE"
  });
  return newRequest;
}
async function handleRecaptchaFlow(authInstance, request, actionName, actionMethod) {
  var _a;
  if ((_a = authInstance._getRecaptchaConfig()) === null || _a === void 0 ? void 0 : _a.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")) {
    const requestWithRecaptcha = await injectRecaptchaFields(authInstance, request, actionName, actionName === "getOobCode");
    return actionMethod(authInstance, requestWithRecaptcha);
  } else {
    return actionMethod(authInstance, request).catch(async error => {
      if (error.code === `auth/${"missing-recaptcha-token"}`) {
        console.log(`${actionName} is protected by reCAPTCHA Enterprise for this project. Automatically triggering the reCAPTCHA flow and restarting the flow.`);
        const requestWithRecaptcha = await injectRecaptchaFields(authInstance, request, actionName, actionName === "getOobCode");
        return actionMethod(authInstance, requestWithRecaptcha);
      } else {
        return Promise.reject(error);
      }
    });
  }
}
async function _initializeRecaptchaConfig(auth) {
  const authInternal = _castAuth(auth);
  const response = await getRecaptchaConfig(authInternal, {
    clientType: "CLIENT_TYPE_WEB",
    version: "RECAPTCHA_ENTERPRISE"
  });
  const config = new RecaptchaConfig(response);
  if (authInternal.tenantId == null) {
    authInternal._agentRecaptchaConfig = config;
  } else {
    authInternal._tenantRecaptchaConfigs[authInternal.tenantId] = config;
  }
  if (config.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")) {
    const verifier = new RecaptchaEnterpriseVerifier(authInternal);
    void verifier.verify();
  }
}
function initializeAuth(app, deps) {
  const provider = (0, import_app._getProvider)(app, "auth");
  if (provider.isInitialized()) {
    const auth2 = provider.getImmediate();
    const initialOptions = provider.getOptions();
    if ((0, import_util.deepEqual)(initialOptions, deps !== null && deps !== void 0 ? deps : {})) {
      return auth2;
    } else {
      _fail(auth2, "already-initialized");
    }
  }
  const auth = provider.initialize({
    options: deps
  });
  return auth;
}
function _initializeAuthInstance(auth, deps) {
  const persistence = (deps === null || deps === void 0 ? void 0 : deps.persistence) || [];
  const hierarchy = (Array.isArray(persistence) ? persistence : [persistence]).map(_getInstance);
  if (deps === null || deps === void 0 ? void 0 : deps.errorMap) {
    auth._updateErrorMap(deps.errorMap);
  }
  auth._initializeWithPersistence(hierarchy, deps === null || deps === void 0 ? void 0 : deps.popupRedirectResolver);
}
function connectAuthEmulator(auth, url, options) {
  const authInternal = _castAuth(auth);
  _assert(authInternal._canInitEmulator, authInternal, "emulator-config-failed");
  _assert(/^https?:\/\//.test(url), authInternal, "invalid-emulator-scheme");
  const disableWarnings = !!(options === null || options === void 0 ? void 0 : options.disableWarnings);
  const protocol = extractProtocol(url);
  const {
    host,
    port
  } = extractHostAndPort(url);
  const portStr = port === null ? "" : `:${port}`;
  authInternal.config.emulator = {
    url: `${protocol}//${host}${portStr}/`
  };
  authInternal.settings.appVerificationDisabledForTesting = true;
  authInternal.emulatorConfig = Object.freeze({
    host,
    port,
    protocol: protocol.replace(":", ""),
    options: Object.freeze({
      disableWarnings
    })
  });
  if (!disableWarnings) {
    emitEmulatorWarning();
  }
}
function extractProtocol(url) {
  const protocolEnd = url.indexOf(":");
  return protocolEnd < 0 ? "" : url.substr(0, protocolEnd + 1);
}
function extractHostAndPort(url) {
  const protocol = extractProtocol(url);
  const authority = /(\/\/)?([^?#/]+)/.exec(url.substr(protocol.length));
  if (!authority) {
    return {
      host: "",
      port: null
    };
  }
  const hostAndPort = authority[2].split("@").pop() || "";
  const bracketedIPv6 = /^(\[[^\]]+\])(:|$)/.exec(hostAndPort);
  if (bracketedIPv6) {
    const host = bracketedIPv6[1];
    return {
      host,
      port: parsePort(hostAndPort.substr(host.length + 1))
    };
  } else {
    const [host, port] = hostAndPort.split(":");
    return {
      host,
      port: parsePort(port)
    };
  }
}
function parsePort(portStr) {
  if (!portStr) {
    return null;
  }
  const port = Number(portStr);
  if (isNaN(port)) {
    return null;
  }
  return port;
}
function emitEmulatorWarning() {
  function attachBanner() {
    const el = document.createElement("p");
    const sty = el.style;
    el.innerText = "Running in emulator mode. Do not use with production credentials.";
    sty.position = "fixed";
    sty.width = "100%";
    sty.backgroundColor = "#ffffff";
    sty.border = ".1em solid #000000";
    sty.color = "#b50000";
    sty.bottom = "0px";
    sty.left = "0px";
    sty.margin = "0px";
    sty.zIndex = "10000";
    sty.textAlign = "center";
    el.classList.add("firebase-emulator-warning");
    document.body.appendChild(el);
  }
  if (typeof console !== "undefined" && typeof console.info === "function") {
    console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials.");
  }
  if (typeof window !== "undefined" && typeof document !== "undefined") {
    if (document.readyState === "loading") {
      window.addEventListener("DOMContentLoaded", attachBanner);
    } else {
      attachBanner();
    }
  }
}
var AuthCredential = class {
  constructor(providerId, signInMethod) {
    this.providerId = providerId;
    this.signInMethod = signInMethod;
  }
  toJSON() {
    return debugFail("not implemented");
  }
  _getIdTokenResponse(_auth) {
    return debugFail("not implemented");
  }
  _linkToIdToken(_auth, _idToken) {
    return debugFail("not implemented");
  }
  _getReauthenticationResolver(_auth) {
    return debugFail("not implemented");
  }
};
async function resetPassword(auth, request) {
  return _performApiRequest(auth, "POST", "/v1/accounts:resetPassword", _addTidIfNecessary(auth, request));
}
async function updateEmailPassword(auth, request) {
  return _performApiRequest(auth, "POST", "/v1/accounts:update", request);
}
async function linkEmailPassword(auth, request) {
  return _performApiRequest(auth, "POST", "/v1/accounts:signUp", request);
}
async function applyActionCode$1(auth, request) {
  return _performApiRequest(auth, "POST", "/v1/accounts:update", _addTidIfNecessary(auth, request));
}
async function signInWithPassword(auth, request) {
  return _performSignInRequest(auth, "POST", "/v1/accounts:signInWithPassword", _addTidIfNecessary(auth, request));
}
async function sendOobCode(auth, request) {
  return _performApiRequest(auth, "POST", "/v1/accounts:sendOobCode", _addTidIfNecessary(auth, request));
}
async function sendEmailVerification$1(auth, request) {
  return sendOobCode(auth, request);
}
async function sendPasswordResetEmail$1(auth, request) {
  return sendOobCode(auth, request);
}
async function sendSignInLinkToEmail$1(auth, request) {
  return sendOobCode(auth, request);
}
async function verifyAndChangeEmail(auth, request) {
  return sendOobCode(auth, request);
}
async function signInWithEmailLink$1(auth, request) {
  return _performSignInRequest(auth, "POST", "/v1/accounts:signInWithEmailLink", _addTidIfNecessary(auth, request));
}
async function signInWithEmailLinkForLinking(auth, request) {
  return _performSignInRequest(auth, "POST", "/v1/accounts:signInWithEmailLink", _addTidIfNecessary(auth, request));
}
var EmailAuthCredential = class extends AuthCredential {
  constructor(_email, _password, signInMethod, _tenantId = null) {
    super("password", signInMethod);
    this._email = _email;
    this._password = _password;
    this._tenantId = _tenantId;
  }
  static _fromEmailAndPassword(email, password) {
    return new EmailAuthCredential(email, password, "password");
  }
  static _fromEmailAndCode(email, oobCode, tenantId = null) {
    return new EmailAuthCredential(email, oobCode, "emailLink", tenantId);
  }
  toJSON() {
    return {
      email: this._email,
      password: this._password,
      signInMethod: this.signInMethod,
      tenantId: this._tenantId
    };
  }
  static fromJSON(json) {
    const obj = typeof json === "string" ? JSON.parse(json) : json;
    if ((obj === null || obj === void 0 ? void 0 : obj.email) && (obj === null || obj === void 0 ? void 0 : obj.password)) {
      if (obj.signInMethod === "password") {
        return this._fromEmailAndPassword(obj.email, obj.password);
      } else if (obj.signInMethod === "emailLink") {
        return this._fromEmailAndCode(obj.email, obj.password, obj.tenantId);
      }
    }
    return null;
  }
  async _getIdTokenResponse(auth) {
    switch (this.signInMethod) {
      case "password":
        const request = {
          returnSecureToken: true,
          email: this._email,
          password: this._password,
          clientType: "CLIENT_TYPE_WEB"
        };
        return handleRecaptchaFlow(auth, request, "signInWithPassword", signInWithPassword);
      case "emailLink":
        return signInWithEmailLink$1(auth, {
          email: this._email,
          oobCode: this._password
        });
      default:
        _fail(auth, "internal-error");
    }
  }
  async _linkToIdToken(auth, idToken) {
    switch (this.signInMethod) {
      case "password":
        const request = {
          idToken,
          returnSecureToken: true,
          email: this._email,
          password: this._password,
          clientType: "CLIENT_TYPE_WEB"
        };
        return handleRecaptchaFlow(auth, request, "signUpPassword", linkEmailPassword);
      case "emailLink":
        return signInWithEmailLinkForLinking(auth, {
          idToken,
          email: this._email,
          oobCode: this._password
        });
      default:
        _fail(auth, "internal-error");
    }
  }
  _getReauthenticationResolver(auth) {
    return this._getIdTokenResponse(auth);
  }
};
async function signInWithIdp(auth, request) {
  return _performSignInRequest(auth, "POST", "/v1/accounts:signInWithIdp", _addTidIfNecessary(auth, request));
}
var IDP_REQUEST_URI$1 = "http://localhost";
var OAuthCredential = class extends AuthCredential {
  constructor() {
    super(...arguments);
    this.pendingToken = null;
  }
  static _fromParams(params) {
    const cred = new OAuthCredential(params.providerId, params.signInMethod);
    if (params.idToken || params.accessToken) {
      if (params.idToken) {
        cred.idToken = params.idToken;
      }
      if (params.accessToken) {
        cred.accessToken = params.accessToken;
      }
      if (params.nonce && !params.pendingToken) {
        cred.nonce = params.nonce;
      }
      if (params.pendingToken) {
        cred.pendingToken = params.pendingToken;
      }
    } else if (params.oauthToken && params.oauthTokenSecret) {
      cred.accessToken = params.oauthToken;
      cred.secret = params.oauthTokenSecret;
    } else {
      _fail("argument-error");
    }
    return cred;
  }
  toJSON() {
    return {
      idToken: this.idToken,
      accessToken: this.accessToken,
      secret: this.secret,
      nonce: this.nonce,
      pendingToken: this.pendingToken,
      providerId: this.providerId,
      signInMethod: this.signInMethod
    };
  }
  static fromJSON(json) {
    const obj = typeof json === "string" ? JSON.parse(json) : json;
    const {
        providerId,
        signInMethod
      } = obj,
      rest = (0, import_tslib.__rest)(obj, ["providerId", "signInMethod"]);
    if (!providerId || !signInMethod) {
      return null;
    }
    const cred = new OAuthCredential(providerId, signInMethod);
    cred.idToken = rest.idToken || void 0;
    cred.accessToken = rest.accessToken || void 0;
    cred.secret = rest.secret;
    cred.nonce = rest.nonce;
    cred.pendingToken = rest.pendingToken || null;
    return cred;
  }
  _getIdTokenResponse(auth) {
    const request = this.buildRequest();
    return signInWithIdp(auth, request);
  }
  _linkToIdToken(auth, idToken) {
    const request = this.buildRequest();
    request.idToken = idToken;
    return signInWithIdp(auth, request);
  }
  _getReauthenticationResolver(auth) {
    const request = this.buildRequest();
    request.autoCreate = false;
    return signInWithIdp(auth, request);
  }
  buildRequest() {
    const request = {
      requestUri: IDP_REQUEST_URI$1,
      returnSecureToken: true
    };
    if (this.pendingToken) {
      request.pendingToken = this.pendingToken;
    } else {
      const postBody = {};
      if (this.idToken) {
        postBody["id_token"] = this.idToken;
      }
      if (this.accessToken) {
        postBody["access_token"] = this.accessToken;
      }
      if (this.secret) {
        postBody["oauth_token_secret"] = this.secret;
      }
      postBody["providerId"] = this.providerId;
      if (this.nonce && !this.pendingToken) {
        postBody["nonce"] = this.nonce;
      }
      request.postBody = (0, import_util.querystring)(postBody);
    }
    return request;
  }
};
async function sendPhoneVerificationCode(auth, request) {
  return _performApiRequest(auth, "POST", "/v1/accounts:sendVerificationCode", _addTidIfNecessary(auth, request));
}
async function signInWithPhoneNumber$1(auth, request) {
  return _performSignInRequest(auth, "POST", "/v1/accounts:signInWithPhoneNumber", _addTidIfNecessary(auth, request));
}
async function linkWithPhoneNumber$1(auth, request) {
  const response = await _performSignInRequest(auth, "POST", "/v1/accounts:signInWithPhoneNumber", _addTidIfNecessary(auth, request));
  if (response.temporaryProof) {
    throw _makeTaggedError(auth, "account-exists-with-different-credential", response);
  }
  return response;
}
var VERIFY_PHONE_NUMBER_FOR_EXISTING_ERROR_MAP_ = {
  ["USER_NOT_FOUND"]: "user-not-found"
};
async function verifyPhoneNumberForExisting(auth, request) {
  const apiRequest = Object.assign(Object.assign({}, request), {
    operation: "REAUTH"
  });
  return _performSignInRequest(auth, "POST", "/v1/accounts:signInWithPhoneNumber", _addTidIfNecessary(auth, apiRequest), VERIFY_PHONE_NUMBER_FOR_EXISTING_ERROR_MAP_);
}
var PhoneAuthCredential = class extends AuthCredential {
  constructor(params) {
    super("phone", "phone");
    this.params = params;
  }
  static _fromVerification(verificationId, verificationCode) {
    return new PhoneAuthCredential({
      verificationId,
      verificationCode
    });
  }
  static _fromTokenResponse(phoneNumber, temporaryProof) {
    return new PhoneAuthCredential({
      phoneNumber,
      temporaryProof
    });
  }
  _getIdTokenResponse(auth) {
    return signInWithPhoneNumber$1(auth, this._makeVerificationRequest());
  }
  _linkToIdToken(auth, idToken) {
    return linkWithPhoneNumber$1(auth, Object.assign({
      idToken
    }, this._makeVerificationRequest()));
  }
  _getReauthenticationResolver(auth) {
    return verifyPhoneNumberForExisting(auth, this._makeVerificationRequest());
  }
  _makeVerificationRequest() {
    const {
      temporaryProof,
      phoneNumber,
      verificationId,
      verificationCode
    } = this.params;
    if (temporaryProof && phoneNumber) {
      return {
        temporaryProof,
        phoneNumber
      };
    }
    return {
      sessionInfo: verificationId,
      code: verificationCode
    };
  }
  toJSON() {
    const obj = {
      providerId: this.providerId
    };
    if (this.params.phoneNumber) {
      obj.phoneNumber = this.params.phoneNumber;
    }
    if (this.params.temporaryProof) {
      obj.temporaryProof = this.params.temporaryProof;
    }
    if (this.params.verificationCode) {
      obj.verificationCode = this.params.verificationCode;
    }
    if (this.params.verificationId) {
      obj.verificationId = this.params.verificationId;
    }
    return obj;
  }
  static fromJSON(json) {
    if (typeof json === "string") {
      json = JSON.parse(json);
    }
    const {
      verificationId,
      verificationCode,
      phoneNumber,
      temporaryProof
    } = json;
    if (!verificationCode && !verificationId && !phoneNumber && !temporaryProof) {
      return null;
    }
    return new PhoneAuthCredential({
      verificationId,
      verificationCode,
      phoneNumber,
      temporaryProof
    });
  }
};
function parseMode(mode) {
  switch (mode) {
    case "recoverEmail":
      return "RECOVER_EMAIL";
    case "resetPassword":
      return "PASSWORD_RESET";
    case "signIn":
      return "EMAIL_SIGNIN";
    case "verifyEmail":
      return "VERIFY_EMAIL";
    case "verifyAndChangeEmail":
      return "VERIFY_AND_CHANGE_EMAIL";
    case "revertSecondFactorAddition":
      return "REVERT_SECOND_FACTOR_ADDITION";
    default:
      return null;
  }
}
function parseDeepLink(url) {
  const link = (0, import_util.querystringDecode)((0, import_util.extractQuerystring)(url))["link"];
  const doubleDeepLink = link ? (0, import_util.querystringDecode)((0, import_util.extractQuerystring)(link))["deep_link_id"] : null;
  const iOSDeepLink = (0, import_util.querystringDecode)((0, import_util.extractQuerystring)(url))["deep_link_id"];
  const iOSDoubleDeepLink = iOSDeepLink ? (0, import_util.querystringDecode)((0, import_util.extractQuerystring)(iOSDeepLink))["link"] : null;
  return iOSDoubleDeepLink || iOSDeepLink || doubleDeepLink || link || url;
}
var ActionCodeURL = class {
  constructor(actionLink) {
    var _a, _b, _c, _d, _e, _f;
    const searchParams = (0, import_util.querystringDecode)((0, import_util.extractQuerystring)(actionLink));
    const apiKey = (_a = searchParams["apiKey"]) !== null && _a !== void 0 ? _a : null;
    const code = (_b = searchParams["oobCode"]) !== null && _b !== void 0 ? _b : null;
    const operation = parseMode((_c = searchParams["mode"]) !== null && _c !== void 0 ? _c : null);
    _assert(apiKey && code && operation, "argument-error");
    this.apiKey = apiKey;
    this.operation = operation;
    this.code = code;
    this.continueUrl = (_d = searchParams["continueUrl"]) !== null && _d !== void 0 ? _d : null;
    this.languageCode = (_e = searchParams["languageCode"]) !== null && _e !== void 0 ? _e : null;
    this.tenantId = (_f = searchParams["tenantId"]) !== null && _f !== void 0 ? _f : null;
  }
  static parseLink(link) {
    const actionLink = parseDeepLink(link);
    try {
      return new ActionCodeURL(actionLink);
    } catch (_a) {
      return null;
    }
  }
};
function parseActionCodeURL(link) {
  return ActionCodeURL.parseLink(link);
}
var EmailAuthProvider = class {
  constructor() {
    this.providerId = EmailAuthProvider.PROVIDER_ID;
  }
  static credential(email, password) {
    return EmailAuthCredential._fromEmailAndPassword(email, password);
  }
  static credentialWithLink(email, emailLink) {
    const actionCodeUrl = ActionCodeURL.parseLink(emailLink);
    _assert(actionCodeUrl, "argument-error");
    return EmailAuthCredential._fromEmailAndCode(email, actionCodeUrl.code, actionCodeUrl.tenantId);
  }
};
EmailAuthProvider.PROVIDER_ID = "password";
EmailAuthProvider.EMAIL_PASSWORD_SIGN_IN_METHOD = "password";
EmailAuthProvider.EMAIL_LINK_SIGN_IN_METHOD = "emailLink";
var FederatedAuthProvider = class {
  constructor(providerId) {
    this.providerId = providerId;
    this.defaultLanguageCode = null;
    this.customParameters = {};
  }
  setDefaultLanguage(languageCode) {
    this.defaultLanguageCode = languageCode;
  }
  setCustomParameters(customOAuthParameters) {
    this.customParameters = customOAuthParameters;
    return this;
  }
  getCustomParameters() {
    return this.customParameters;
  }
};
var BaseOAuthProvider = class extends FederatedAuthProvider {
  constructor() {
    super(...arguments);
    this.scopes = [];
  }
  addScope(scope) {
    if (!this.scopes.includes(scope)) {
      this.scopes.push(scope);
    }
    return this;
  }
  getScopes() {
    return [...this.scopes];
  }
};
var OAuthProvider = class extends BaseOAuthProvider {
  static credentialFromJSON(json) {
    const obj = typeof json === "string" ? JSON.parse(json) : json;
    _assert("providerId" in obj && "signInMethod" in obj, "argument-error");
    return OAuthCredential._fromParams(obj);
  }
  credential(params) {
    return this._credential(Object.assign(Object.assign({}, params), {
      nonce: params.rawNonce
    }));
  }
  _credential(params) {
    _assert(params.idToken || params.accessToken, "argument-error");
    return OAuthCredential._fromParams(Object.assign(Object.assign({}, params), {
      providerId: this.providerId,
      signInMethod: this.providerId
    }));
  }
  static credentialFromResult(userCredential) {
    return OAuthProvider.oauthCredentialFromTaggedObject(userCredential);
  }
  static credentialFromError(error) {
    return OAuthProvider.oauthCredentialFromTaggedObject(error.customData || {});
  }
  static oauthCredentialFromTaggedObject({
    _tokenResponse: tokenResponse
  }) {
    if (!tokenResponse) {
      return null;
    }
    const {
      oauthIdToken,
      oauthAccessToken,
      oauthTokenSecret,
      pendingToken,
      nonce,
      providerId
    } = tokenResponse;
    if (!oauthAccessToken && !oauthTokenSecret && !oauthIdToken && !pendingToken) {
      return null;
    }
    if (!providerId) {
      return null;
    }
    try {
      return new OAuthProvider(providerId)._credential({
        idToken: oauthIdToken,
        accessToken: oauthAccessToken,
        nonce,
        pendingToken
      });
    } catch (e) {
      return null;
    }
  }
};
var FacebookAuthProvider = class extends BaseOAuthProvider {
  constructor() {
    super("facebook.com");
  }
  static credential(accessToken) {
    return OAuthCredential._fromParams({
      providerId: FacebookAuthProvider.PROVIDER_ID,
      signInMethod: FacebookAuthProvider.FACEBOOK_SIGN_IN_METHOD,
      accessToken
    });
  }
  static credentialFromResult(userCredential) {
    return FacebookAuthProvider.credentialFromTaggedObject(userCredential);
  }
  static credentialFromError(error) {
    return FacebookAuthProvider.credentialFromTaggedObject(error.customData || {});
  }
  static credentialFromTaggedObject({
    _tokenResponse: tokenResponse
  }) {
    if (!tokenResponse || !("oauthAccessToken" in tokenResponse)) {
      return null;
    }
    if (!tokenResponse.oauthAccessToken) {
      return null;
    }
    try {
      return FacebookAuthProvider.credential(tokenResponse.oauthAccessToken);
    } catch (_a) {
      return null;
    }
  }
};
FacebookAuthProvider.FACEBOOK_SIGN_IN_METHOD = "facebook.com";
FacebookAuthProvider.PROVIDER_ID = "facebook.com";
var GoogleAuthProvider = class extends BaseOAuthProvider {
  constructor() {
    super("google.com");
    this.addScope("profile");
  }
  static credential(idToken, accessToken) {
    return OAuthCredential._fromParams({
      providerId: GoogleAuthProvider.PROVIDER_ID,
      signInMethod: GoogleAuthProvider.GOOGLE_SIGN_IN_METHOD,
      idToken,
      accessToken
    });
  }
  static credentialFromResult(userCredential) {
    return GoogleAuthProvider.credentialFromTaggedObject(userCredential);
  }
  static credentialFromError(error) {
    return GoogleAuthProvider.credentialFromTaggedObject(error.customData || {});
  }
  static credentialFromTaggedObject({
    _tokenResponse: tokenResponse
  }) {
    if (!tokenResponse) {
      return null;
    }
    const {
      oauthIdToken,
      oauthAccessToken
    } = tokenResponse;
    if (!oauthIdToken && !oauthAccessToken) {
      return null;
    }
    try {
      return GoogleAuthProvider.credential(oauthIdToken, oauthAccessToken);
    } catch (_a) {
      return null;
    }
  }
};
GoogleAuthProvider.GOOGLE_SIGN_IN_METHOD = "google.com";
GoogleAuthProvider.PROVIDER_ID = "google.com";
var GithubAuthProvider = class extends BaseOAuthProvider {
  constructor() {
    super("github.com");
  }
  static credential(accessToken) {
    return OAuthCredential._fromParams({
      providerId: GithubAuthProvider.PROVIDER_ID,
      signInMethod: GithubAuthProvider.GITHUB_SIGN_IN_METHOD,
      accessToken
    });
  }
  static credentialFromResult(userCredential) {
    return GithubAuthProvider.credentialFromTaggedObject(userCredential);
  }
  static credentialFromError(error) {
    return GithubAuthProvider.credentialFromTaggedObject(error.customData || {});
  }
  static credentialFromTaggedObject({
    _tokenResponse: tokenResponse
  }) {
    if (!tokenResponse || !("oauthAccessToken" in tokenResponse)) {
      return null;
    }
    if (!tokenResponse.oauthAccessToken) {
      return null;
    }
    try {
      return GithubAuthProvider.credential(tokenResponse.oauthAccessToken);
    } catch (_a) {
      return null;
    }
  }
};
GithubAuthProvider.GITHUB_SIGN_IN_METHOD = "github.com";
GithubAuthProvider.PROVIDER_ID = "github.com";
var IDP_REQUEST_URI = "http://localhost";
var SAMLAuthCredential = class extends AuthCredential {
  constructor(providerId, pendingToken) {
    super(providerId, providerId);
    this.pendingToken = pendingToken;
  }
  _getIdTokenResponse(auth) {
    const request = this.buildRequest();
    return signInWithIdp(auth, request);
  }
  _linkToIdToken(auth, idToken) {
    const request = this.buildRequest();
    request.idToken = idToken;
    return signInWithIdp(auth, request);
  }
  _getReauthenticationResolver(auth) {
    const request = this.buildRequest();
    request.autoCreate = false;
    return signInWithIdp(auth, request);
  }
  toJSON() {
    return {
      signInMethod: this.signInMethod,
      providerId: this.providerId,
      pendingToken: this.pendingToken
    };
  }
  static fromJSON(json) {
    const obj = typeof json === "string" ? JSON.parse(json) : json;
    const {
      providerId,
      signInMethod,
      pendingToken
    } = obj;
    if (!providerId || !signInMethod || !pendingToken || providerId !== signInMethod) {
      return null;
    }
    return new SAMLAuthCredential(providerId, pendingToken);
  }
  static _create(providerId, pendingToken) {
    return new SAMLAuthCredential(providerId, pendingToken);
  }
  buildRequest() {
    return {
      requestUri: IDP_REQUEST_URI,
      returnSecureToken: true,
      pendingToken: this.pendingToken
    };
  }
};
var SAML_PROVIDER_PREFIX = "saml.";
var SAMLAuthProvider = class extends FederatedAuthProvider {
  constructor(providerId) {
    _assert(providerId.startsWith(SAML_PROVIDER_PREFIX), "argument-error");
    super(providerId);
  }
  static credentialFromResult(userCredential) {
    return SAMLAuthProvider.samlCredentialFromTaggedObject(userCredential);
  }
  static credentialFromError(error) {
    return SAMLAuthProvider.samlCredentialFromTaggedObject(error.customData || {});
  }
  static credentialFromJSON(json) {
    const credential = SAMLAuthCredential.fromJSON(json);
    _assert(credential, "argument-error");
    return credential;
  }
  static samlCredentialFromTaggedObject({
    _tokenResponse: tokenResponse
  }) {
    if (!tokenResponse) {
      return null;
    }
    const {
      pendingToken,
      providerId
    } = tokenResponse;
    if (!pendingToken || !providerId) {
      return null;
    }
    try {
      return SAMLAuthCredential._create(providerId, pendingToken);
    } catch (e) {
      return null;
    }
  }
};
var TwitterAuthProvider = class extends BaseOAuthProvider {
  constructor() {
    super("twitter.com");
  }
  static credential(token, secret) {
    return OAuthCredential._fromParams({
      providerId: TwitterAuthProvider.PROVIDER_ID,
      signInMethod: TwitterAuthProvider.TWITTER_SIGN_IN_METHOD,
      oauthToken: token,
      oauthTokenSecret: secret
    });
  }
  static credentialFromResult(userCredential) {
    return TwitterAuthProvider.credentialFromTaggedObject(userCredential);
  }
  static credentialFromError(error) {
    return TwitterAuthProvider.credentialFromTaggedObject(error.customData || {});
  }
  static credentialFromTaggedObject({
    _tokenResponse: tokenResponse
  }) {
    if (!tokenResponse) {
      return null;
    }
    const {
      oauthAccessToken,
      oauthTokenSecret
    } = tokenResponse;
    if (!oauthAccessToken || !oauthTokenSecret) {
      return null;
    }
    try {
      return TwitterAuthProvider.credential(oauthAccessToken, oauthTokenSecret);
    } catch (_a) {
      return null;
    }
  }
};
TwitterAuthProvider.TWITTER_SIGN_IN_METHOD = "twitter.com";
TwitterAuthProvider.PROVIDER_ID = "twitter.com";
async function signUp(auth, request) {
  return _performSignInRequest(auth, "POST", "/v1/accounts:signUp", _addTidIfNecessary(auth, request));
}
var UserCredentialImpl = class {
  constructor(params) {
    this.user = params.user;
    this.providerId = params.providerId;
    this._tokenResponse = params._tokenResponse;
    this.operationType = params.operationType;
  }
  static async _fromIdTokenResponse(auth, operationType, idTokenResponse, isAnonymous = false) {
    const user = await UserImpl._fromIdTokenResponse(auth, idTokenResponse, isAnonymous);
    const providerId = providerIdForResponse(idTokenResponse);
    const userCred = new UserCredentialImpl({
      user,
      providerId,
      _tokenResponse: idTokenResponse,
      operationType
    });
    return userCred;
  }
  static async _forOperation(user, operationType, response) {
    await user._updateTokensIfNecessary(response, true);
    const providerId = providerIdForResponse(response);
    return new UserCredentialImpl({
      user,
      providerId,
      _tokenResponse: response,
      operationType
    });
  }
};
function providerIdForResponse(response) {
  if (response.providerId) {
    return response.providerId;
  }
  if ("phoneNumber" in response) {
    return "phone";
  }
  return null;
}
async function signInAnonymously(auth) {
  var _a;
  const authInternal = _castAuth(auth);
  await authInternal._initializationPromise;
  if ((_a = authInternal.currentUser) === null || _a === void 0 ? void 0 : _a.isAnonymous) {
    return new UserCredentialImpl({
      user: authInternal.currentUser,
      providerId: null,
      operationType: "signIn"
    });
  }
  const response = await signUp(authInternal, {
    returnSecureToken: true
  });
  const userCredential = await UserCredentialImpl._fromIdTokenResponse(authInternal, "signIn", response, true);
  await authInternal._updateCurrentUser(userCredential.user);
  return userCredential;
}
var MultiFactorError = class extends import_util.FirebaseError {
  constructor(auth, error, operationType, user) {
    var _a;
    super(error.code, error.message);
    this.operationType = operationType;
    this.user = user;
    Object.setPrototypeOf(this, MultiFactorError.prototype);
    this.customData = {
      appName: auth.name,
      tenantId: (_a = auth.tenantId) !== null && _a !== void 0 ? _a : void 0,
      _serverResponse: error.customData._serverResponse,
      operationType
    };
  }
  static _fromErrorAndOperation(auth, error, operationType, user) {
    return new MultiFactorError(auth, error, operationType, user);
  }
};
function _processCredentialSavingMfaContextIfNecessary(auth, operationType, credential, user) {
  const idTokenProvider = operationType === "reauthenticate" ? credential._getReauthenticationResolver(auth) : credential._getIdTokenResponse(auth);
  return idTokenProvider.catch(error => {
    if (error.code === `auth/${"multi-factor-auth-required"}`) {
      throw MultiFactorError._fromErrorAndOperation(auth, error, operationType, user);
    }
    throw error;
  });
}
function providerDataAsNames(providerData) {
  return new Set(providerData.map(({
    providerId
  }) => providerId).filter(pid => !!pid));
}
async function unlink(user, providerId) {
  const userInternal = (0, import_util.getModularInstance)(user);
  await _assertLinkedStatus(true, userInternal, providerId);
  const {
    providerUserInfo
  } = await deleteLinkedAccounts(userInternal.auth, {
    idToken: await userInternal.getIdToken(),
    deleteProvider: [providerId]
  });
  const providersLeft = providerDataAsNames(providerUserInfo || []);
  userInternal.providerData = userInternal.providerData.filter(pd => providersLeft.has(pd.providerId));
  if (!providersLeft.has("phone")) {
    userInternal.phoneNumber = null;
  }
  await userInternal.auth._persistUserIfCurrent(userInternal);
  return userInternal;
}
async function _link$1(user, credential, bypassAuthState = false) {
  const response = await _logoutIfInvalidated(user, credential._linkToIdToken(user.auth, await user.getIdToken()), bypassAuthState);
  return UserCredentialImpl._forOperation(user, "link", response);
}
async function _assertLinkedStatus(expected, user, provider) {
  await _reloadWithoutSaving(user);
  const providerIds = providerDataAsNames(user.providerData);
  const code = expected === false ? "provider-already-linked" : "no-such-provider";
  _assert(providerIds.has(provider) === expected, user.auth, code);
}
async function _reauthenticate(user, credential, bypassAuthState = false) {
  const {
    auth
  } = user;
  const operationType = "reauthenticate";
  try {
    const response = await _logoutIfInvalidated(user, _processCredentialSavingMfaContextIfNecessary(auth, operationType, credential, user), bypassAuthState);
    _assert(response.idToken, auth, "internal-error");
    const parsed = _parseToken(response.idToken);
    _assert(parsed, auth, "internal-error");
    const {
      sub: localId
    } = parsed;
    _assert(user.uid === localId, auth, "user-mismatch");
    return UserCredentialImpl._forOperation(user, operationType, response);
  } catch (e) {
    if ((e === null || e === void 0 ? void 0 : e.code) === `auth/${"user-not-found"}`) {
      _fail(auth, "user-mismatch");
    }
    throw e;
  }
}
async function _signInWithCredential(auth, credential, bypassAuthState = false) {
  const operationType = "signIn";
  const response = await _processCredentialSavingMfaContextIfNecessary(auth, operationType, credential);
  const userCredential = await UserCredentialImpl._fromIdTokenResponse(auth, operationType, response);
  if (!bypassAuthState) {
    await auth._updateCurrentUser(userCredential.user);
  }
  return userCredential;
}
async function signInWithCredential(auth, credential) {
  return _signInWithCredential(_castAuth(auth), credential);
}
async function linkWithCredential(user, credential) {
  const userInternal = (0, import_util.getModularInstance)(user);
  await _assertLinkedStatus(false, userInternal, credential.providerId);
  return _link$1(userInternal, credential);
}
async function reauthenticateWithCredential(user, credential) {
  return _reauthenticate((0, import_util.getModularInstance)(user), credential);
}
async function signInWithCustomToken$1(auth, request) {
  return _performSignInRequest(auth, "POST", "/v1/accounts:signInWithCustomToken", _addTidIfNecessary(auth, request));
}
async function signInWithCustomToken(auth, customToken) {
  const authInternal = _castAuth(auth);
  const response = await signInWithCustomToken$1(authInternal, {
    token: customToken,
    returnSecureToken: true
  });
  const cred = await UserCredentialImpl._fromIdTokenResponse(authInternal, "signIn", response);
  await authInternal._updateCurrentUser(cred.user);
  return cred;
}
var MultiFactorInfoImpl = class {
  constructor(factorId, response) {
    this.factorId = factorId;
    this.uid = response.mfaEnrollmentId;
    this.enrollmentTime = new Date(response.enrolledAt).toUTCString();
    this.displayName = response.displayName;
  }
  static _fromServerResponse(auth, enrollment) {
    if ("phoneInfo" in enrollment) {
      return PhoneMultiFactorInfoImpl._fromServerResponse(auth, enrollment);
    } else if ("totpInfo" in enrollment) {
      return TotpMultiFactorInfoImpl._fromServerResponse(auth, enrollment);
    }
    return _fail(auth, "internal-error");
  }
};
var PhoneMultiFactorInfoImpl = class extends MultiFactorInfoImpl {
  constructor(response) {
    super("phone", response);
    this.phoneNumber = response.phoneInfo;
  }
  static _fromServerResponse(_auth, enrollment) {
    return new PhoneMultiFactorInfoImpl(enrollment);
  }
};
var TotpMultiFactorInfoImpl = class extends MultiFactorInfoImpl {
  constructor(response) {
    super("totp", response);
  }
  static _fromServerResponse(_auth, enrollment) {
    return new TotpMultiFactorInfoImpl(enrollment);
  }
};
function _setActionCodeSettingsOnRequest(auth, request, actionCodeSettings) {
  var _a;
  _assert(((_a = actionCodeSettings.url) === null || _a === void 0 ? void 0 : _a.length) > 0, auth, "invalid-continue-uri");
  _assert(typeof actionCodeSettings.dynamicLinkDomain === "undefined" || actionCodeSettings.dynamicLinkDomain.length > 0, auth, "invalid-dynamic-link-domain");
  request.continueUrl = actionCodeSettings.url;
  request.dynamicLinkDomain = actionCodeSettings.dynamicLinkDomain;
  request.canHandleCodeInApp = actionCodeSettings.handleCodeInApp;
  if (actionCodeSettings.iOS) {
    _assert(actionCodeSettings.iOS.bundleId.length > 0, auth, "missing-ios-bundle-id");
    request.iOSBundleId = actionCodeSettings.iOS.bundleId;
  }
  if (actionCodeSettings.android) {
    _assert(actionCodeSettings.android.packageName.length > 0, auth, "missing-android-pkg-name");
    request.androidInstallApp = actionCodeSettings.android.installApp;
    request.androidMinimumVersionCode = actionCodeSettings.android.minimumVersion;
    request.androidPackageName = actionCodeSettings.android.packageName;
  }
}
async function recachePasswordPolicy(auth) {
  const authInternal = _castAuth(auth);
  if (authInternal._getPasswordPolicyInternal()) {
    await authInternal._updatePasswordPolicy();
  }
}
async function sendPasswordResetEmail(auth, email, actionCodeSettings) {
  const authInternal = _castAuth(auth);
  const request = {
    requestType: "PASSWORD_RESET",
    email,
    clientType: "CLIENT_TYPE_WEB"
  };
  if (actionCodeSettings) {
    _setActionCodeSettingsOnRequest(authInternal, request, actionCodeSettings);
  }
  await handleRecaptchaFlow(authInternal, request, "getOobCode", sendPasswordResetEmail$1);
}
async function confirmPasswordReset(auth, oobCode, newPassword) {
  await resetPassword((0, import_util.getModularInstance)(auth), {
    oobCode,
    newPassword
  }).catch(async error => {
    if (error.code === `auth/${"password-does-not-meet-requirements"}`) {
      void recachePasswordPolicy(auth);
    }
    throw error;
  });
}
async function applyActionCode(auth, oobCode) {
  await applyActionCode$1((0, import_util.getModularInstance)(auth), {
    oobCode
  });
}
async function checkActionCode(auth, oobCode) {
  const authModular = (0, import_util.getModularInstance)(auth);
  const response = await resetPassword(authModular, {
    oobCode
  });
  const operation = response.requestType;
  _assert(operation, authModular, "internal-error");
  switch (operation) {
    case "EMAIL_SIGNIN":
      break;
    case "VERIFY_AND_CHANGE_EMAIL":
      _assert(response.newEmail, authModular, "internal-error");
      break;
    case "REVERT_SECOND_FACTOR_ADDITION":
      _assert(response.mfaInfo, authModular, "internal-error");
    default:
      _assert(response.email, authModular, "internal-error");
  }
  let multiFactorInfo = null;
  if (response.mfaInfo) {
    multiFactorInfo = MultiFactorInfoImpl._fromServerResponse(_castAuth(authModular), response.mfaInfo);
  }
  return {
    data: {
      email: (response.requestType === "VERIFY_AND_CHANGE_EMAIL" ? response.newEmail : response.email) || null,
      previousEmail: (response.requestType === "VERIFY_AND_CHANGE_EMAIL" ? response.email : response.newEmail) || null,
      multiFactorInfo
    },
    operation
  };
}
async function verifyPasswordResetCode(auth, code) {
  const {
    data
  } = await checkActionCode((0, import_util.getModularInstance)(auth), code);
  return data.email;
}
async function createUserWithEmailAndPassword(auth, email, password) {
  const authInternal = _castAuth(auth);
  const request = {
    returnSecureToken: true,
    email,
    password,
    clientType: "CLIENT_TYPE_WEB"
  };
  const signUpResponse = handleRecaptchaFlow(authInternal, request, "signUpPassword", signUp);
  const response = await signUpResponse.catch(error => {
    if (error.code === `auth/${"password-does-not-meet-requirements"}`) {
      void recachePasswordPolicy(auth);
    }
    throw error;
  });
  const userCredential = await UserCredentialImpl._fromIdTokenResponse(authInternal, "signIn", response);
  await authInternal._updateCurrentUser(userCredential.user);
  return userCredential;
}
function signInWithEmailAndPassword(auth, email, password) {
  return signInWithCredential((0, import_util.getModularInstance)(auth), EmailAuthProvider.credential(email, password)).catch(async error => {
    if (error.code === `auth/${"password-does-not-meet-requirements"}`) {
      void recachePasswordPolicy(auth);
    }
    throw error;
  });
}
async function sendSignInLinkToEmail(auth, email, actionCodeSettings) {
  const authInternal = _castAuth(auth);
  const request = {
    requestType: "EMAIL_SIGNIN",
    email,
    clientType: "CLIENT_TYPE_WEB"
  };
  function setActionCodeSettings(request2, actionCodeSettings2) {
    _assert(actionCodeSettings2.handleCodeInApp, authInternal, "argument-error");
    if (actionCodeSettings2) {
      _setActionCodeSettingsOnRequest(authInternal, request2, actionCodeSettings2);
    }
  }
  setActionCodeSettings(request, actionCodeSettings);
  await handleRecaptchaFlow(authInternal, request, "getOobCode", sendSignInLinkToEmail$1);
}
function isSignInWithEmailLink(auth, emailLink) {
  const actionCodeUrl = ActionCodeURL.parseLink(emailLink);
  return (actionCodeUrl === null || actionCodeUrl === void 0 ? void 0 : actionCodeUrl.operation) === "EMAIL_SIGNIN";
}
async function signInWithEmailLink(auth, email, emailLink) {
  const authModular = (0, import_util.getModularInstance)(auth);
  const credential = EmailAuthProvider.credentialWithLink(email, emailLink || _getCurrentUrl());
  _assert(credential._tenantId === (authModular.tenantId || null), authModular, "tenant-id-mismatch");
  return signInWithCredential(authModular, credential);
}
async function createAuthUri(auth, request) {
  return _performApiRequest(auth, "POST", "/v1/accounts:createAuthUri", _addTidIfNecessary(auth, request));
}
async function fetchSignInMethodsForEmail(auth, email) {
  const continueUri = _isHttpOrHttps() ? _getCurrentUrl() : "http://localhost";
  const request = {
    identifier: email,
    continueUri
  };
  const {
    signinMethods
  } = await createAuthUri((0, import_util.getModularInstance)(auth), request);
  return signinMethods || [];
}
async function sendEmailVerification(user, actionCodeSettings) {
  const userInternal = (0, import_util.getModularInstance)(user);
  const idToken = await user.getIdToken();
  const request = {
    requestType: "VERIFY_EMAIL",
    idToken
  };
  if (actionCodeSettings) {
    _setActionCodeSettingsOnRequest(userInternal.auth, request, actionCodeSettings);
  }
  const {
    email
  } = await sendEmailVerification$1(userInternal.auth, request);
  if (email !== user.email) {
    await user.reload();
  }
}
async function verifyBeforeUpdateEmail(user, newEmail, actionCodeSettings) {
  const userInternal = (0, import_util.getModularInstance)(user);
  const idToken = await user.getIdToken();
  const request = {
    requestType: "VERIFY_AND_CHANGE_EMAIL",
    idToken,
    newEmail
  };
  if (actionCodeSettings) {
    _setActionCodeSettingsOnRequest(userInternal.auth, request, actionCodeSettings);
  }
  const {
    email
  } = await verifyAndChangeEmail(userInternal.auth, request);
  if (email !== user.email) {
    await user.reload();
  }
}
async function updateProfile$1(auth, request) {
  return _performApiRequest(auth, "POST", "/v1/accounts:update", request);
}
async function updateProfile(user, {
  displayName,
  photoURL: photoUrl
}) {
  if (displayName === void 0 && photoUrl === void 0) {
    return;
  }
  const userInternal = (0, import_util.getModularInstance)(user);
  const idToken = await userInternal.getIdToken();
  const profileRequest = {
    idToken,
    displayName,
    photoUrl,
    returnSecureToken: true
  };
  const response = await _logoutIfInvalidated(userInternal, updateProfile$1(userInternal.auth, profileRequest));
  userInternal.displayName = response.displayName || null;
  userInternal.photoURL = response.photoUrl || null;
  const passwordProvider = userInternal.providerData.find(({
    providerId
  }) => providerId === "password");
  if (passwordProvider) {
    passwordProvider.displayName = userInternal.displayName;
    passwordProvider.photoURL = userInternal.photoURL;
  }
  await userInternal._updateTokensIfNecessary(response);
}
function updateEmail(user, newEmail) {
  return updateEmailOrPassword((0, import_util.getModularInstance)(user), newEmail, null);
}
function updatePassword(user, newPassword) {
  return updateEmailOrPassword((0, import_util.getModularInstance)(user), null, newPassword);
}
async function updateEmailOrPassword(user, email, password) {
  const {
    auth
  } = user;
  const idToken = await user.getIdToken();
  const request = {
    idToken,
    returnSecureToken: true
  };
  if (email) {
    request.email = email;
  }
  if (password) {
    request.password = password;
  }
  const response = await _logoutIfInvalidated(user, updateEmailPassword(auth, request));
  await user._updateTokensIfNecessary(response, true);
}
function _fromIdTokenResponse(idTokenResponse) {
  var _a, _b;
  if (!idTokenResponse) {
    return null;
  }
  const {
    providerId
  } = idTokenResponse;
  const profile = idTokenResponse.rawUserInfo ? JSON.parse(idTokenResponse.rawUserInfo) : {};
  const isNewUser = idTokenResponse.isNewUser || idTokenResponse.kind === "identitytoolkit#SignupNewUserResponse";
  if (!providerId && (idTokenResponse === null || idTokenResponse === void 0 ? void 0 : idTokenResponse.idToken)) {
    const signInProvider = (_b = (_a = _parseToken(idTokenResponse.idToken)) === null || _a === void 0 ? void 0 : _a.firebase) === null || _b === void 0 ? void 0 : _b["sign_in_provider"];
    if (signInProvider) {
      const filteredProviderId = signInProvider !== "anonymous" && signInProvider !== "custom" ? signInProvider : null;
      return new GenericAdditionalUserInfo(isNewUser, filteredProviderId);
    }
  }
  if (!providerId) {
    return null;
  }
  switch (providerId) {
    case "facebook.com":
      return new FacebookAdditionalUserInfo(isNewUser, profile);
    case "github.com":
      return new GithubAdditionalUserInfo(isNewUser, profile);
    case "google.com":
      return new GoogleAdditionalUserInfo(isNewUser, profile);
    case "twitter.com":
      return new TwitterAdditionalUserInfo(isNewUser, profile, idTokenResponse.screenName || null);
    case "custom":
    case "anonymous":
      return new GenericAdditionalUserInfo(isNewUser, null);
    default:
      return new GenericAdditionalUserInfo(isNewUser, providerId, profile);
  }
}
var GenericAdditionalUserInfo = class {
  constructor(isNewUser, providerId, profile = {}) {
    this.isNewUser = isNewUser;
    this.providerId = providerId;
    this.profile = profile;
  }
};
var FederatedAdditionalUserInfoWithUsername = class extends GenericAdditionalUserInfo {
  constructor(isNewUser, providerId, profile, username) {
    super(isNewUser, providerId, profile);
    this.username = username;
  }
};
var FacebookAdditionalUserInfo = class extends GenericAdditionalUserInfo {
  constructor(isNewUser, profile) {
    super(isNewUser, "facebook.com", profile);
  }
};
var GithubAdditionalUserInfo = class extends FederatedAdditionalUserInfoWithUsername {
  constructor(isNewUser, profile) {
    super(isNewUser, "github.com", profile, typeof (profile === null || profile === void 0 ? void 0 : profile.login) === "string" ? profile === null || profile === void 0 ? void 0 : profile.login : null);
  }
};
var GoogleAdditionalUserInfo = class extends GenericAdditionalUserInfo {
  constructor(isNewUser, profile) {
    super(isNewUser, "google.com", profile);
  }
};
var TwitterAdditionalUserInfo = class extends FederatedAdditionalUserInfoWithUsername {
  constructor(isNewUser, profile, screenName) {
    super(isNewUser, "twitter.com", profile, screenName);
  }
};
function getAdditionalUserInfo(userCredential) {
  const {
    user,
    _tokenResponse
  } = userCredential;
  if (user.isAnonymous && !_tokenResponse) {
    return {
      providerId: null,
      isNewUser: false,
      profile: null
    };
  }
  return _fromIdTokenResponse(_tokenResponse);
}
function setPersistence(auth, persistence) {
  return (0, import_util.getModularInstance)(auth).setPersistence(persistence);
}
function initializeRecaptchaConfig(auth) {
  return _initializeRecaptchaConfig(auth);
}
async function validatePassword(auth, password) {
  const authInternal = _castAuth(auth);
  return authInternal.validatePassword(password);
}
function onIdTokenChanged(auth, nextOrObserver, error, completed) {
  return (0, import_util.getModularInstance)(auth).onIdTokenChanged(nextOrObserver, error, completed);
}
function beforeAuthStateChanged(auth, callback, onAbort) {
  return (0, import_util.getModularInstance)(auth).beforeAuthStateChanged(callback, onAbort);
}
function onAuthStateChanged(auth, nextOrObserver, error, completed) {
  return (0, import_util.getModularInstance)(auth).onAuthStateChanged(nextOrObserver, error, completed);
}
function useDeviceLanguage(auth) {
  (0, import_util.getModularInstance)(auth).useDeviceLanguage();
}
function updateCurrentUser(auth, user) {
  return (0, import_util.getModularInstance)(auth).updateCurrentUser(user);
}
function signOut(auth) {
  return (0, import_util.getModularInstance)(auth).signOut();
}
function revokeAccessToken(auth, token) {
  const authInternal = _castAuth(auth);
  return authInternal.revokeAccessToken(token);
}
async function deleteUser(user) {
  return (0, import_util.getModularInstance)(user).delete();
}
var MultiFactorSessionImpl = class {
  constructor(type, credential, user) {
    this.type = type;
    this.credential = credential;
    this.user = user;
  }
  static _fromIdtoken(idToken, user) {
    return new MultiFactorSessionImpl("enroll", idToken, user);
  }
  static _fromMfaPendingCredential(mfaPendingCredential) {
    return new MultiFactorSessionImpl("signin", mfaPendingCredential);
  }
  toJSON() {
    const key = this.type === "enroll" ? "idToken" : "pendingCredential";
    return {
      multiFactorSession: {
        [key]: this.credential
      }
    };
  }
  static fromJSON(obj) {
    var _a, _b;
    if (obj === null || obj === void 0 ? void 0 : obj.multiFactorSession) {
      if ((_a = obj.multiFactorSession) === null || _a === void 0 ? void 0 : _a.pendingCredential) {
        return MultiFactorSessionImpl._fromMfaPendingCredential(obj.multiFactorSession.pendingCredential);
      } else if ((_b = obj.multiFactorSession) === null || _b === void 0 ? void 0 : _b.idToken) {
        return MultiFactorSessionImpl._fromIdtoken(obj.multiFactorSession.idToken);
      }
    }
    return null;
  }
};
var MultiFactorResolverImpl = class {
  constructor(session, hints, signInResolver) {
    this.session = session;
    this.hints = hints;
    this.signInResolver = signInResolver;
  }
  static _fromError(authExtern, error) {
    const auth = _castAuth(authExtern);
    const serverResponse = error.customData._serverResponse;
    const hints = (serverResponse.mfaInfo || []).map(enrollment => MultiFactorInfoImpl._fromServerResponse(auth, enrollment));
    _assert(serverResponse.mfaPendingCredential, auth, "internal-error");
    const session = MultiFactorSessionImpl._fromMfaPendingCredential(serverResponse.mfaPendingCredential);
    return new MultiFactorResolverImpl(session, hints, async assertion => {
      const mfaResponse = await assertion._process(auth, session);
      delete serverResponse.mfaInfo;
      delete serverResponse.mfaPendingCredential;
      const idTokenResponse = Object.assign(Object.assign({}, serverResponse), {
        idToken: mfaResponse.idToken,
        refreshToken: mfaResponse.refreshToken
      });
      switch (error.operationType) {
        case "signIn":
          const userCredential = await UserCredentialImpl._fromIdTokenResponse(auth, error.operationType, idTokenResponse);
          await auth._updateCurrentUser(userCredential.user);
          return userCredential;
        case "reauthenticate":
          _assert(error.user, auth, "internal-error");
          return UserCredentialImpl._forOperation(error.user, error.operationType, idTokenResponse);
        default:
          _fail(auth, "internal-error");
      }
    });
  }
  async resolveSignIn(assertionExtern) {
    const assertion = assertionExtern;
    return this.signInResolver(assertion);
  }
};
function getMultiFactorResolver(auth, error) {
  var _a;
  const authModular = (0, import_util.getModularInstance)(auth);
  const errorInternal = error;
  _assert(error.customData.operationType, authModular, "argument-error");
  _assert((_a = errorInternal.customData._serverResponse) === null || _a === void 0 ? void 0 : _a.mfaPendingCredential, authModular, "argument-error");
  return MultiFactorResolverImpl._fromError(authModular, errorInternal);
}
function startEnrollPhoneMfa(auth, request) {
  return _performApiRequest(auth, "POST", "/v2/accounts/mfaEnrollment:start", _addTidIfNecessary(auth, request));
}
function finalizeEnrollPhoneMfa(auth, request) {
  return _performApiRequest(auth, "POST", "/v2/accounts/mfaEnrollment:finalize", _addTidIfNecessary(auth, request));
}
function startEnrollTotpMfa(auth, request) {
  return _performApiRequest(auth, "POST", "/v2/accounts/mfaEnrollment:start", _addTidIfNecessary(auth, request));
}
function finalizeEnrollTotpMfa(auth, request) {
  return _performApiRequest(auth, "POST", "/v2/accounts/mfaEnrollment:finalize", _addTidIfNecessary(auth, request));
}
function withdrawMfa(auth, request) {
  return _performApiRequest(auth, "POST", "/v2/accounts/mfaEnrollment:withdraw", _addTidIfNecessary(auth, request));
}
var MultiFactorUserImpl = class {
  constructor(user) {
    this.user = user;
    this.enrolledFactors = [];
    user._onReload(userInfo => {
      if (userInfo.mfaInfo) {
        this.enrolledFactors = userInfo.mfaInfo.map(enrollment => MultiFactorInfoImpl._fromServerResponse(user.auth, enrollment));
      }
    });
  }
  static _fromUser(user) {
    return new MultiFactorUserImpl(user);
  }
  async getSession() {
    return MultiFactorSessionImpl._fromIdtoken(await this.user.getIdToken(), this.user);
  }
  async enroll(assertionExtern, displayName) {
    const assertion = assertionExtern;
    const session = await this.getSession();
    const finalizeMfaResponse = await _logoutIfInvalidated(this.user, assertion._process(this.user.auth, session, displayName));
    await this.user._updateTokensIfNecessary(finalizeMfaResponse);
    return this.user.reload();
  }
  async unenroll(infoOrUid) {
    const mfaEnrollmentId = typeof infoOrUid === "string" ? infoOrUid : infoOrUid.uid;
    const idToken = await this.user.getIdToken();
    try {
      const idTokenResponse = await _logoutIfInvalidated(this.user, withdrawMfa(this.user.auth, {
        idToken,
        mfaEnrollmentId
      }));
      this.enrolledFactors = this.enrolledFactors.filter(({
        uid
      }) => uid !== mfaEnrollmentId);
      await this.user._updateTokensIfNecessary(idTokenResponse);
      await this.user.reload();
    } catch (e) {
      throw e;
    }
  }
};
var multiFactorUserCache = /* @__PURE__ */new WeakMap();
function multiFactor(user) {
  const userModular = (0, import_util.getModularInstance)(user);
  if (!multiFactorUserCache.has(userModular)) {
    multiFactorUserCache.set(userModular, MultiFactorUserImpl._fromUser(userModular));
  }
  return multiFactorUserCache.get(userModular);
}
var STORAGE_AVAILABLE_KEY = "__sak";
var BrowserPersistenceClass = class {
  constructor(storageRetriever, type) {
    this.storageRetriever = storageRetriever;
    this.type = type;
  }
  _isAvailable() {
    try {
      if (!this.storage) {
        return Promise.resolve(false);
      }
      this.storage.setItem(STORAGE_AVAILABLE_KEY, "1");
      this.storage.removeItem(STORAGE_AVAILABLE_KEY);
      return Promise.resolve(true);
    } catch (_a) {
      return Promise.resolve(false);
    }
  }
  _set(key, value) {
    this.storage.setItem(key, JSON.stringify(value));
    return Promise.resolve();
  }
  _get(key) {
    const json = this.storage.getItem(key);
    return Promise.resolve(json ? JSON.parse(json) : null);
  }
  _remove(key) {
    this.storage.removeItem(key);
    return Promise.resolve();
  }
  get storage() {
    return this.storageRetriever();
  }
};
function _iframeCannotSyncWebStorage() {
  const ua = (0, import_util.getUA)();
  return _isSafari(ua) || _isIOS(ua);
}
var _POLLING_INTERVAL_MS$1 = 1e3;
var IE10_LOCAL_STORAGE_SYNC_DELAY = 10;
var BrowserLocalPersistence = class extends BrowserPersistenceClass {
  constructor() {
    super(() => window.localStorage, "LOCAL");
    this.boundEventHandler = (event, poll) => this.onStorageEvent(event, poll);
    this.listeners = {};
    this.localCache = {};
    this.pollTimer = null;
    this.safariLocalStorageNotSynced = _iframeCannotSyncWebStorage() && _isIframe();
    this.fallbackToPolling = _isMobileBrowser();
    this._shouldAllowMigration = true;
  }
  forAllChangedKeys(cb) {
    for (const key of Object.keys(this.listeners)) {
      const newValue = this.storage.getItem(key);
      const oldValue = this.localCache[key];
      if (newValue !== oldValue) {
        cb(key, oldValue, newValue);
      }
    }
  }
  onStorageEvent(event, poll = false) {
    if (!event.key) {
      this.forAllChangedKeys((key2, _oldValue, newValue) => {
        this.notifyListeners(key2, newValue);
      });
      return;
    }
    const key = event.key;
    if (poll) {
      this.detachListener();
    } else {
      this.stopPolling();
    }
    if (this.safariLocalStorageNotSynced) {
      const storedValue2 = this.storage.getItem(key);
      if (event.newValue !== storedValue2) {
        if (event.newValue !== null) {
          this.storage.setItem(key, event.newValue);
        } else {
          this.storage.removeItem(key);
        }
      } else if (this.localCache[key] === event.newValue && !poll) {
        return;
      }
    }
    const triggerListeners = () => {
      const storedValue2 = this.storage.getItem(key);
      if (!poll && this.localCache[key] === storedValue2) {
        return;
      }
      this.notifyListeners(key, storedValue2);
    };
    const storedValue = this.storage.getItem(key);
    if (_isIE10() && storedValue !== event.newValue && event.newValue !== event.oldValue) {
      setTimeout(triggerListeners, IE10_LOCAL_STORAGE_SYNC_DELAY);
    } else {
      triggerListeners();
    }
  }
  notifyListeners(key, value) {
    this.localCache[key] = value;
    const listeners = this.listeners[key];
    if (listeners) {
      for (const listener of Array.from(listeners)) {
        listener(value ? JSON.parse(value) : value);
      }
    }
  }
  startPolling() {
    this.stopPolling();
    this.pollTimer = setInterval(() => {
      this.forAllChangedKeys((key, oldValue, newValue) => {
        this.onStorageEvent(new StorageEvent("storage", {
          key,
          oldValue,
          newValue
        }), true);
      });
    }, _POLLING_INTERVAL_MS$1);
  }
  stopPolling() {
    if (this.pollTimer) {
      clearInterval(this.pollTimer);
      this.pollTimer = null;
    }
  }
  attachListener() {
    window.addEventListener("storage", this.boundEventHandler);
  }
  detachListener() {
    window.removeEventListener("storage", this.boundEventHandler);
  }
  _addListener(key, listener) {
    if (Object.keys(this.listeners).length === 0) {
      if (this.fallbackToPolling) {
        this.startPolling();
      } else {
        this.attachListener();
      }
    }
    if (!this.listeners[key]) {
      this.listeners[key] = /* @__PURE__ */new Set();
      this.localCache[key] = this.storage.getItem(key);
    }
    this.listeners[key].add(listener);
  }
  _removeListener(key, listener) {
    if (this.listeners[key]) {
      this.listeners[key].delete(listener);
      if (this.listeners[key].size === 0) {
        delete this.listeners[key];
      }
    }
    if (Object.keys(this.listeners).length === 0) {
      this.detachListener();
      this.stopPolling();
    }
  }
  async _set(key, value) {
    await super._set(key, value);
    this.localCache[key] = JSON.stringify(value);
  }
  async _get(key) {
    const value = await super._get(key);
    this.localCache[key] = JSON.stringify(value);
    return value;
  }
  async _remove(key) {
    await super._remove(key);
    delete this.localCache[key];
  }
};
BrowserLocalPersistence.type = "LOCAL";
var browserLocalPersistence = BrowserLocalPersistence;
var BrowserSessionPersistence = class extends BrowserPersistenceClass {
  constructor() {
    super(() => window.sessionStorage, "SESSION");
  }
  _addListener(_key, _listener) {
    return;
  }
  _removeListener(_key, _listener) {
    return;
  }
};
BrowserSessionPersistence.type = "SESSION";
var browserSessionPersistence = BrowserSessionPersistence;
function _allSettled(promises) {
  return Promise.all(promises.map(async promise => {
    try {
      const value = await promise;
      return {
        fulfilled: true,
        value
      };
    } catch (reason) {
      return {
        fulfilled: false,
        reason
      };
    }
  }));
}
var Receiver = class {
  constructor(eventTarget) {
    this.eventTarget = eventTarget;
    this.handlersMap = {};
    this.boundEventHandler = this.handleEvent.bind(this);
  }
  static _getInstance(eventTarget) {
    const existingInstance = this.receivers.find(receiver => receiver.isListeningto(eventTarget));
    if (existingInstance) {
      return existingInstance;
    }
    const newInstance = new Receiver(eventTarget);
    this.receivers.push(newInstance);
    return newInstance;
  }
  isListeningto(eventTarget) {
    return this.eventTarget === eventTarget;
  }
  async handleEvent(event) {
    const messageEvent = event;
    const {
      eventId,
      eventType,
      data
    } = messageEvent.data;
    const handlers = this.handlersMap[eventType];
    if (!(handlers === null || handlers === void 0 ? void 0 : handlers.size)) {
      return;
    }
    messageEvent.ports[0].postMessage({
      status: "ack",
      eventId,
      eventType
    });
    const promises = Array.from(handlers).map(async handler => handler(messageEvent.origin, data));
    const response = await _allSettled(promises);
    messageEvent.ports[0].postMessage({
      status: "done",
      eventId,
      eventType,
      response
    });
  }
  _subscribe(eventType, eventHandler) {
    if (Object.keys(this.handlersMap).length === 0) {
      this.eventTarget.addEventListener("message", this.boundEventHandler);
    }
    if (!this.handlersMap[eventType]) {
      this.handlersMap[eventType] = /* @__PURE__ */new Set();
    }
    this.handlersMap[eventType].add(eventHandler);
  }
  _unsubscribe(eventType, eventHandler) {
    if (this.handlersMap[eventType] && eventHandler) {
      this.handlersMap[eventType].delete(eventHandler);
    }
    if (!eventHandler || this.handlersMap[eventType].size === 0) {
      delete this.handlersMap[eventType];
    }
    if (Object.keys(this.handlersMap).length === 0) {
      this.eventTarget.removeEventListener("message", this.boundEventHandler);
    }
  }
};
Receiver.receivers = [];
function _generateEventId(prefix = "", digits = 10) {
  let random = "";
  for (let i = 0; i < digits; i++) {
    random += Math.floor(Math.random() * 10);
  }
  return prefix + random;
}
var Sender = class {
  constructor(target) {
    this.target = target;
    this.handlers = /* @__PURE__ */new Set();
  }
  removeMessageHandler(handler) {
    if (handler.messageChannel) {
      handler.messageChannel.port1.removeEventListener("message", handler.onMessage);
      handler.messageChannel.port1.close();
    }
    this.handlers.delete(handler);
  }
  async _send(eventType, data, timeout = 50) {
    const messageChannel = typeof MessageChannel !== "undefined" ? new MessageChannel() : null;
    if (!messageChannel) {
      throw new Error("connection_unavailable");
    }
    let completionTimer;
    let handler;
    return new Promise((resolve, reject) => {
      const eventId = _generateEventId("", 20);
      messageChannel.port1.start();
      const ackTimer = setTimeout(() => {
        reject(new Error("unsupported_event"));
      }, timeout);
      handler = {
        messageChannel,
        onMessage(event) {
          const messageEvent = event;
          if (messageEvent.data.eventId !== eventId) {
            return;
          }
          switch (messageEvent.data.status) {
            case "ack":
              clearTimeout(ackTimer);
              completionTimer = setTimeout(() => {
                reject(new Error("timeout"));
              }, 3e3);
              break;
            case "done":
              clearTimeout(completionTimer);
              resolve(messageEvent.data.response);
              break;
            default:
              clearTimeout(ackTimer);
              clearTimeout(completionTimer);
              reject(new Error("invalid_response"));
              break;
          }
        }
      };
      this.handlers.add(handler);
      messageChannel.port1.addEventListener("message", handler.onMessage);
      this.target.postMessage({
        eventType,
        eventId,
        data
      }, [messageChannel.port2]);
    }).finally(() => {
      if (handler) {
        this.removeMessageHandler(handler);
      }
    });
  }
};
function _window() {
  return window;
}
function _setWindowLocation(url) {
  _window().location.href = url;
}
function _isWorker() {
  return typeof _window()["WorkerGlobalScope"] !== "undefined" && typeof _window()["importScripts"] === "function";
}
async function _getActiveServiceWorker() {
  if (!(navigator === null || navigator === void 0 ? void 0 : navigator.serviceWorker)) {
    return null;
  }
  try {
    const registration = await navigator.serviceWorker.ready;
    return registration.active;
  } catch (_a) {
    return null;
  }
}
function _getServiceWorkerController() {
  var _a;
  return ((_a = navigator === null || navigator === void 0 ? void 0 : navigator.serviceWorker) === null || _a === void 0 ? void 0 : _a.controller) || null;
}
function _getWorkerGlobalScope() {
  return _isWorker() ? self : null;
}
var DB_NAME = "firebaseLocalStorageDb";
var DB_VERSION = 1;
var DB_OBJECTSTORE_NAME = "firebaseLocalStorage";
var DB_DATA_KEYPATH = "fbase_key";
var DBPromise = class {
  constructor(request) {
    this.request = request;
  }
  toPromise() {
    return new Promise((resolve, reject) => {
      this.request.addEventListener("success", () => {
        resolve(this.request.result);
      });
      this.request.addEventListener("error", () => {
        reject(this.request.error);
      });
    });
  }
};
function getObjectStore(db, isReadWrite) {
  return db.transaction([DB_OBJECTSTORE_NAME], isReadWrite ? "readwrite" : "readonly").objectStore(DB_OBJECTSTORE_NAME);
}
function _deleteDatabase() {
  const request = indexedDB.deleteDatabase(DB_NAME);
  return new DBPromise(request).toPromise();
}
function _openDatabase() {
  const request = indexedDB.open(DB_NAME, DB_VERSION);
  return new Promise((resolve, reject) => {
    request.addEventListener("error", () => {
      reject(request.error);
    });
    request.addEventListener("upgradeneeded", () => {
      const db = request.result;
      try {
        db.createObjectStore(DB_OBJECTSTORE_NAME, {
          keyPath: DB_DATA_KEYPATH
        });
      } catch (e) {
        reject(e);
      }
    });
    request.addEventListener("success", async () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(DB_OBJECTSTORE_NAME)) {
        db.close();
        await _deleteDatabase();
        resolve(await _openDatabase());
      } else {
        resolve(db);
      }
    });
  });
}
async function _putObject(db, key, value) {
  const request = getObjectStore(db, true).put({
    [DB_DATA_KEYPATH]: key,
    value
  });
  return new DBPromise(request).toPromise();
}
async function getObject(db, key) {
  const request = getObjectStore(db, false).get(key);
  const data = await new DBPromise(request).toPromise();
  return data === void 0 ? null : data.value;
}
function _deleteObject(db, key) {
  const request = getObjectStore(db, true).delete(key);
  return new DBPromise(request).toPromise();
}
var _POLLING_INTERVAL_MS = 800;
var _TRANSACTION_RETRY_COUNT = 3;
var IndexedDBLocalPersistence = class {
  constructor() {
    this.type = "LOCAL";
    this._shouldAllowMigration = true;
    this.listeners = {};
    this.localCache = {};
    this.pollTimer = null;
    this.pendingWrites = 0;
    this.receiver = null;
    this.sender = null;
    this.serviceWorkerReceiverAvailable = false;
    this.activeServiceWorker = null;
    this._workerInitializationPromise = this.initializeServiceWorkerMessaging().then(() => {}, () => {});
  }
  async _openDb() {
    if (this.db) {
      return this.db;
    }
    this.db = await _openDatabase();
    return this.db;
  }
  async _withRetries(op) {
    let numAttempts = 0;
    while (true) {
      try {
        const db = await this._openDb();
        return await op(db);
      } catch (e) {
        if (numAttempts++ > _TRANSACTION_RETRY_COUNT) {
          throw e;
        }
        if (this.db) {
          this.db.close();
          this.db = void 0;
        }
      }
    }
  }
  async initializeServiceWorkerMessaging() {
    return _isWorker() ? this.initializeReceiver() : this.initializeSender();
  }
  async initializeReceiver() {
    this.receiver = Receiver._getInstance(_getWorkerGlobalScope());
    this.receiver._subscribe("keyChanged", async (_origin, data) => {
      const keys = await this._poll();
      return {
        keyProcessed: keys.includes(data.key)
      };
    });
    this.receiver._subscribe("ping", async (_origin, _data) => {
      return ["keyChanged"];
    });
  }
  async initializeSender() {
    var _a, _b;
    this.activeServiceWorker = await _getActiveServiceWorker();
    if (!this.activeServiceWorker) {
      return;
    }
    this.sender = new Sender(this.activeServiceWorker);
    const results = await this.sender._send("ping", {}, 800);
    if (!results) {
      return;
    }
    if (((_a = results[0]) === null || _a === void 0 ? void 0 : _a.fulfilled) && ((_b = results[0]) === null || _b === void 0 ? void 0 : _b.value.includes("keyChanged"))) {
      this.serviceWorkerReceiverAvailable = true;
    }
  }
  async notifyServiceWorker(key) {
    if (!this.sender || !this.activeServiceWorker || _getServiceWorkerController() !== this.activeServiceWorker) {
      return;
    }
    try {
      await this.sender._send("keyChanged", {
        key
      }, this.serviceWorkerReceiverAvailable ? 800 : 50);
    } catch (_a) {}
  }
  async _isAvailable() {
    try {
      if (!indexedDB) {
        return false;
      }
      const db = await _openDatabase();
      await _putObject(db, STORAGE_AVAILABLE_KEY, "1");
      await _deleteObject(db, STORAGE_AVAILABLE_KEY);
      return true;
    } catch (_a) {}
    return false;
  }
  async _withPendingWrite(write) {
    this.pendingWrites++;
    try {
      await write();
    } finally {
      this.pendingWrites--;
    }
  }
  async _set(key, value) {
    return this._withPendingWrite(async () => {
      await this._withRetries(db => _putObject(db, key, value));
      this.localCache[key] = value;
      return this.notifyServiceWorker(key);
    });
  }
  async _get(key) {
    const obj = await this._withRetries(db => getObject(db, key));
    this.localCache[key] = obj;
    return obj;
  }
  async _remove(key) {
    return this._withPendingWrite(async () => {
      await this._withRetries(db => _deleteObject(db, key));
      delete this.localCache[key];
      return this.notifyServiceWorker(key);
    });
  }
  async _poll() {
    const result = await this._withRetries(db => {
      const getAllRequest = getObjectStore(db, false).getAll();
      return new DBPromise(getAllRequest).toPromise();
    });
    if (!result) {
      return [];
    }
    if (this.pendingWrites !== 0) {
      return [];
    }
    const keys = [];
    const keysInResult = /* @__PURE__ */new Set();
    if (result.length !== 0) {
      for (const {
        fbase_key: key,
        value
      } of result) {
        keysInResult.add(key);
        if (JSON.stringify(this.localCache[key]) !== JSON.stringify(value)) {
          this.notifyListeners(key, value);
          keys.push(key);
        }
      }
    }
    for (const localKey of Object.keys(this.localCache)) {
      if (this.localCache[localKey] && !keysInResult.has(localKey)) {
        this.notifyListeners(localKey, null);
        keys.push(localKey);
      }
    }
    return keys;
  }
  notifyListeners(key, newValue) {
    this.localCache[key] = newValue;
    const listeners = this.listeners[key];
    if (listeners) {
      for (const listener of Array.from(listeners)) {
        listener(newValue);
      }
    }
  }
  startPolling() {
    this.stopPolling();
    this.pollTimer = setInterval(async () => this._poll(), _POLLING_INTERVAL_MS);
  }
  stopPolling() {
    if (this.pollTimer) {
      clearInterval(this.pollTimer);
      this.pollTimer = null;
    }
  }
  _addListener(key, listener) {
    if (Object.keys(this.listeners).length === 0) {
      this.startPolling();
    }
    if (!this.listeners[key]) {
      this.listeners[key] = /* @__PURE__ */new Set();
      void this._get(key);
    }
    this.listeners[key].add(listener);
  }
  _removeListener(key, listener) {
    if (this.listeners[key]) {
      this.listeners[key].delete(listener);
      if (this.listeners[key].size === 0) {
        delete this.listeners[key];
      }
    }
    if (Object.keys(this.listeners).length === 0) {
      this.stopPolling();
    }
  }
};
IndexedDBLocalPersistence.type = "LOCAL";
var indexedDBLocalPersistence = IndexedDBLocalPersistence;
function startSignInPhoneMfa(auth, request) {
  return _performApiRequest(auth, "POST", "/v2/accounts/mfaSignIn:start", _addTidIfNecessary(auth, request));
}
function finalizeSignInPhoneMfa(auth, request) {
  return _performApiRequest(auth, "POST", "/v2/accounts/mfaSignIn:finalize", _addTidIfNecessary(auth, request));
}
function finalizeSignInTotpMfa(auth, request) {
  return _performApiRequest(auth, "POST", "/v2/accounts/mfaSignIn:finalize", _addTidIfNecessary(auth, request));
}
var _SOLVE_TIME_MS = 500;
var _EXPIRATION_TIME_MS = 6e4;
var _WIDGET_ID_START = 1e12;
var MockReCaptcha = class {
  constructor(auth) {
    this.auth = auth;
    this.counter = _WIDGET_ID_START;
    this._widgets = /* @__PURE__ */new Map();
  }
  render(container, parameters) {
    const id = this.counter;
    this._widgets.set(id, new MockWidget(container, this.auth.name, parameters || {}));
    this.counter++;
    return id;
  }
  reset(optWidgetId) {
    var _a;
    const id = optWidgetId || _WIDGET_ID_START;
    void ((_a = this._widgets.get(id)) === null || _a === void 0 ? void 0 : _a.delete());
    this._widgets.delete(id);
  }
  getResponse(optWidgetId) {
    var _a;
    const id = optWidgetId || _WIDGET_ID_START;
    return ((_a = this._widgets.get(id)) === null || _a === void 0 ? void 0 : _a.getResponse()) || "";
  }
  async execute(optWidgetId) {
    var _a;
    const id = optWidgetId || _WIDGET_ID_START;
    void ((_a = this._widgets.get(id)) === null || _a === void 0 ? void 0 : _a.execute());
    return "";
  }
};
var MockWidget = class {
  constructor(containerOrId, appName, params) {
    this.params = params;
    this.timerId = null;
    this.deleted = false;
    this.responseToken = null;
    this.clickHandler = () => {
      this.execute();
    };
    const container = typeof containerOrId === "string" ? document.getElementById(containerOrId) : containerOrId;
    _assert(container, "argument-error", {
      appName
    });
    this.container = container;
    this.isVisible = this.params.size !== "invisible";
    if (this.isVisible) {
      this.execute();
    } else {
      this.container.addEventListener("click", this.clickHandler);
    }
  }
  getResponse() {
    this.checkIfDeleted();
    return this.responseToken;
  }
  delete() {
    this.checkIfDeleted();
    this.deleted = true;
    if (this.timerId) {
      clearTimeout(this.timerId);
      this.timerId = null;
    }
    this.container.removeEventListener("click", this.clickHandler);
  }
  execute() {
    this.checkIfDeleted();
    if (this.timerId) {
      return;
    }
    this.timerId = window.setTimeout(() => {
      this.responseToken = generateRandomAlphaNumericString(50);
      const {
        callback,
        "expired-callback": expiredCallback
      } = this.params;
      if (callback) {
        try {
          callback(this.responseToken);
        } catch (e) {}
      }
      this.timerId = window.setTimeout(() => {
        this.timerId = null;
        this.responseToken = null;
        if (expiredCallback) {
          try {
            expiredCallback();
          } catch (e) {}
        }
        if (this.isVisible) {
          this.execute();
        }
      }, _EXPIRATION_TIME_MS);
    }, _SOLVE_TIME_MS);
  }
  checkIfDeleted() {
    if (this.deleted) {
      throw new Error("reCAPTCHA mock was already deleted!");
    }
  }
};
function generateRandomAlphaNumericString(len) {
  const chars = [];
  const allowedChars = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  for (let i = 0; i < len; i++) {
    chars.push(allowedChars.charAt(Math.floor(Math.random() * allowedChars.length)));
  }
  return chars.join("");
}
var _JSLOAD_CALLBACK = _generateCallbackName("rcb");
var NETWORK_TIMEOUT_DELAY = new Delay(3e4, 6e4);
var RECAPTCHA_BASE = "https://www.google.com/recaptcha/api.js?";
var ReCaptchaLoaderImpl = class {
  constructor() {
    var _a;
    this.hostLanguage = "";
    this.counter = 0;
    this.librarySeparatelyLoaded = !!((_a = _window().grecaptcha) === null || _a === void 0 ? void 0 : _a.render);
  }
  load(auth, hl = "") {
    _assert(isHostLanguageValid(hl), auth, "argument-error");
    if (this.shouldResolveImmediately(hl) && isV2(_window().grecaptcha)) {
      return Promise.resolve(_window().grecaptcha);
    }
    return new Promise((resolve, reject) => {
      const networkTimeout = _window().setTimeout(() => {
        reject(_createError(auth, "network-request-failed"));
      }, NETWORK_TIMEOUT_DELAY.get());
      _window()[_JSLOAD_CALLBACK] = () => {
        _window().clearTimeout(networkTimeout);
        delete _window()[_JSLOAD_CALLBACK];
        const recaptcha = _window().grecaptcha;
        if (!recaptcha || !isV2(recaptcha)) {
          reject(_createError(auth, "internal-error"));
          return;
        }
        const render = recaptcha.render;
        recaptcha.render = (container, params) => {
          const widgetId = render(container, params);
          this.counter++;
          return widgetId;
        };
        this.hostLanguage = hl;
        resolve(recaptcha);
      };
      const url = `${RECAPTCHA_BASE}?${(0, import_util.querystring)({
        onload: _JSLOAD_CALLBACK,
        render: "explicit",
        hl
      })}`;
      _loadJS(url).catch(() => {
        clearTimeout(networkTimeout);
        reject(_createError(auth, "internal-error"));
      });
    });
  }
  clearedOneInstance() {
    this.counter--;
  }
  shouldResolveImmediately(hl) {
    var _a;
    return !!((_a = _window().grecaptcha) === null || _a === void 0 ? void 0 : _a.render) && (hl === this.hostLanguage || this.counter > 0 || this.librarySeparatelyLoaded);
  }
};
function isHostLanguageValid(hl) {
  return hl.length <= 6 && /^\s*[a-zA-Z0-9\-]*\s*$/.test(hl);
}
var MockReCaptchaLoaderImpl = class {
  async load(auth) {
    return new MockReCaptcha(auth);
  }
  clearedOneInstance() {}
};
var RECAPTCHA_VERIFIER_TYPE = "recaptcha";
var DEFAULT_PARAMS = {
  theme: "light",
  type: "image"
};
var RecaptchaVerifier = class {
  constructor(authExtern, containerOrId, parameters = Object.assign({}, DEFAULT_PARAMS)) {
    this.parameters = parameters;
    this.type = RECAPTCHA_VERIFIER_TYPE;
    this.destroyed = false;
    this.widgetId = null;
    this.tokenChangeListeners = /* @__PURE__ */new Set();
    this.renderPromise = null;
    this.recaptcha = null;
    this.auth = _castAuth(authExtern);
    this.isInvisible = this.parameters.size === "invisible";
    _assert(typeof document !== "undefined", this.auth, "operation-not-supported-in-this-environment");
    const container = typeof containerOrId === "string" ? document.getElementById(containerOrId) : containerOrId;
    _assert(container, this.auth, "argument-error");
    this.container = container;
    this.parameters.callback = this.makeTokenCallback(this.parameters.callback);
    this._recaptchaLoader = this.auth.settings.appVerificationDisabledForTesting ? new MockReCaptchaLoaderImpl() : new ReCaptchaLoaderImpl();
    this.validateStartingState();
  }
  async verify() {
    this.assertNotDestroyed();
    const id = await this.render();
    const recaptcha = this.getAssertedRecaptcha();
    const response = recaptcha.getResponse(id);
    if (response) {
      return response;
    }
    return new Promise(resolve => {
      const tokenChange = token => {
        if (!token) {
          return;
        }
        this.tokenChangeListeners.delete(tokenChange);
        resolve(token);
      };
      this.tokenChangeListeners.add(tokenChange);
      if (this.isInvisible) {
        recaptcha.execute(id);
      }
    });
  }
  render() {
    try {
      this.assertNotDestroyed();
    } catch (e) {
      return Promise.reject(e);
    }
    if (this.renderPromise) {
      return this.renderPromise;
    }
    this.renderPromise = this.makeRenderPromise().catch(e => {
      this.renderPromise = null;
      throw e;
    });
    return this.renderPromise;
  }
  _reset() {
    this.assertNotDestroyed();
    if (this.widgetId !== null) {
      this.getAssertedRecaptcha().reset(this.widgetId);
    }
  }
  clear() {
    this.assertNotDestroyed();
    this.destroyed = true;
    this._recaptchaLoader.clearedOneInstance();
    if (!this.isInvisible) {
      this.container.childNodes.forEach(node => {
        this.container.removeChild(node);
      });
    }
  }
  validateStartingState() {
    _assert(!this.parameters.sitekey, this.auth, "argument-error");
    _assert(this.isInvisible || !this.container.hasChildNodes(), this.auth, "argument-error");
    _assert(typeof document !== "undefined", this.auth, "operation-not-supported-in-this-environment");
  }
  makeTokenCallback(existing) {
    return token => {
      this.tokenChangeListeners.forEach(listener => listener(token));
      if (typeof existing === "function") {
        existing(token);
      } else if (typeof existing === "string") {
        const globalFunc = _window()[existing];
        if (typeof globalFunc === "function") {
          globalFunc(token);
        }
      }
    };
  }
  assertNotDestroyed() {
    _assert(!this.destroyed, this.auth, "internal-error");
  }
  async makeRenderPromise() {
    await this.init();
    if (!this.widgetId) {
      let container = this.container;
      if (!this.isInvisible) {
        const guaranteedEmpty = document.createElement("div");
        container.appendChild(guaranteedEmpty);
        container = guaranteedEmpty;
      }
      this.widgetId = this.getAssertedRecaptcha().render(container, this.parameters);
    }
    return this.widgetId;
  }
  async init() {
    _assert(_isHttpOrHttps() && !_isWorker(), this.auth, "internal-error");
    await domReady();
    this.recaptcha = await this._recaptchaLoader.load(this.auth, this.auth.languageCode || void 0);
    const siteKey = await getRecaptchaParams(this.auth);
    _assert(siteKey, this.auth, "internal-error");
    this.parameters.sitekey = siteKey;
  }
  getAssertedRecaptcha() {
    _assert(this.recaptcha, this.auth, "internal-error");
    return this.recaptcha;
  }
};
function domReady() {
  let resolver = null;
  return new Promise(resolve => {
    if (document.readyState === "complete") {
      resolve();
      return;
    }
    resolver = () => resolve();
    window.addEventListener("load", resolver);
  }).catch(e => {
    if (resolver) {
      window.removeEventListener("load", resolver);
    }
    throw e;
  });
}
var ConfirmationResultImpl = class {
  constructor(verificationId, onConfirmation) {
    this.verificationId = verificationId;
    this.onConfirmation = onConfirmation;
  }
  confirm(verificationCode) {
    const authCredential = PhoneAuthCredential._fromVerification(this.verificationId, verificationCode);
    return this.onConfirmation(authCredential);
  }
};
async function signInWithPhoneNumber(auth, phoneNumber, appVerifier) {
  const authInternal = _castAuth(auth);
  const verificationId = await _verifyPhoneNumber(authInternal, phoneNumber, (0, import_util.getModularInstance)(appVerifier));
  return new ConfirmationResultImpl(verificationId, cred => signInWithCredential(authInternal, cred));
}
async function linkWithPhoneNumber(user, phoneNumber, appVerifier) {
  const userInternal = (0, import_util.getModularInstance)(user);
  await _assertLinkedStatus(false, userInternal, "phone");
  const verificationId = await _verifyPhoneNumber(userInternal.auth, phoneNumber, (0, import_util.getModularInstance)(appVerifier));
  return new ConfirmationResultImpl(verificationId, cred => linkWithCredential(userInternal, cred));
}
async function reauthenticateWithPhoneNumber(user, phoneNumber, appVerifier) {
  const userInternal = (0, import_util.getModularInstance)(user);
  const verificationId = await _verifyPhoneNumber(userInternal.auth, phoneNumber, (0, import_util.getModularInstance)(appVerifier));
  return new ConfirmationResultImpl(verificationId, cred => reauthenticateWithCredential(userInternal, cred));
}
async function _verifyPhoneNumber(auth, options, verifier) {
  var _a;
  const recaptchaToken = await verifier.verify();
  try {
    _assert(typeof recaptchaToken === "string", auth, "argument-error");
    _assert(verifier.type === RECAPTCHA_VERIFIER_TYPE, auth, "argument-error");
    let phoneInfoOptions;
    if (typeof options === "string") {
      phoneInfoOptions = {
        phoneNumber: options
      };
    } else {
      phoneInfoOptions = options;
    }
    if ("session" in phoneInfoOptions) {
      const session = phoneInfoOptions.session;
      if ("phoneNumber" in phoneInfoOptions) {
        _assert(session.type === "enroll", auth, "internal-error");
        const response = await startEnrollPhoneMfa(auth, {
          idToken: session.credential,
          phoneEnrollmentInfo: {
            phoneNumber: phoneInfoOptions.phoneNumber,
            recaptchaToken
          }
        });
        return response.phoneSessionInfo.sessionInfo;
      } else {
        _assert(session.type === "signin", auth, "internal-error");
        const mfaEnrollmentId = ((_a = phoneInfoOptions.multiFactorHint) === null || _a === void 0 ? void 0 : _a.uid) || phoneInfoOptions.multiFactorUid;
        _assert(mfaEnrollmentId, auth, "missing-multi-factor-info");
        const response = await startSignInPhoneMfa(auth, {
          mfaPendingCredential: session.credential,
          mfaEnrollmentId,
          phoneSignInInfo: {
            recaptchaToken
          }
        });
        return response.phoneResponseInfo.sessionInfo;
      }
    } else {
      const {
        sessionInfo
      } = await sendPhoneVerificationCode(auth, {
        phoneNumber: phoneInfoOptions.phoneNumber,
        recaptchaToken
      });
      return sessionInfo;
    }
  } finally {
    verifier._reset();
  }
}
async function updatePhoneNumber(user, credential) {
  await _link$1((0, import_util.getModularInstance)(user), credential);
}
var PhoneAuthProvider = class {
  constructor(auth) {
    this.providerId = PhoneAuthProvider.PROVIDER_ID;
    this.auth = _castAuth(auth);
  }
  verifyPhoneNumber(phoneOptions, applicationVerifier) {
    return _verifyPhoneNumber(this.auth, phoneOptions, (0, import_util.getModularInstance)(applicationVerifier));
  }
  static credential(verificationId, verificationCode) {
    return PhoneAuthCredential._fromVerification(verificationId, verificationCode);
  }
  static credentialFromResult(userCredential) {
    const credential = userCredential;
    return PhoneAuthProvider.credentialFromTaggedObject(credential);
  }
  static credentialFromError(error) {
    return PhoneAuthProvider.credentialFromTaggedObject(error.customData || {});
  }
  static credentialFromTaggedObject({
    _tokenResponse: tokenResponse
  }) {
    if (!tokenResponse) {
      return null;
    }
    const {
      phoneNumber,
      temporaryProof
    } = tokenResponse;
    if (phoneNumber && temporaryProof) {
      return PhoneAuthCredential._fromTokenResponse(phoneNumber, temporaryProof);
    }
    return null;
  }
};
PhoneAuthProvider.PROVIDER_ID = "phone";
PhoneAuthProvider.PHONE_SIGN_IN_METHOD = "phone";
function _withDefaultResolver(auth, resolverOverride) {
  if (resolverOverride) {
    return _getInstance(resolverOverride);
  }
  _assert(auth._popupRedirectResolver, auth, "argument-error");
  return auth._popupRedirectResolver;
}
var IdpCredential = class extends AuthCredential {
  constructor(params) {
    super("custom", "custom");
    this.params = params;
  }
  _getIdTokenResponse(auth) {
    return signInWithIdp(auth, this._buildIdpRequest());
  }
  _linkToIdToken(auth, idToken) {
    return signInWithIdp(auth, this._buildIdpRequest(idToken));
  }
  _getReauthenticationResolver(auth) {
    return signInWithIdp(auth, this._buildIdpRequest());
  }
  _buildIdpRequest(idToken) {
    const request = {
      requestUri: this.params.requestUri,
      sessionId: this.params.sessionId,
      postBody: this.params.postBody,
      tenantId: this.params.tenantId,
      pendingToken: this.params.pendingToken,
      returnSecureToken: true,
      returnIdpCredential: true
    };
    if (idToken) {
      request.idToken = idToken;
    }
    return request;
  }
};
function _signIn(params) {
  return _signInWithCredential(params.auth, new IdpCredential(params), params.bypassAuthState);
}
function _reauth(params) {
  const {
    auth,
    user
  } = params;
  _assert(user, auth, "internal-error");
  return _reauthenticate(user, new IdpCredential(params), params.bypassAuthState);
}
async function _link(params) {
  const {
    auth,
    user
  } = params;
  _assert(user, auth, "internal-error");
  return _link$1(user, new IdpCredential(params), params.bypassAuthState);
}
var AbstractPopupRedirectOperation = class {
  constructor(auth, filter, resolver, user, bypassAuthState = false) {
    this.auth = auth;
    this.resolver = resolver;
    this.user = user;
    this.bypassAuthState = bypassAuthState;
    this.pendingPromise = null;
    this.eventManager = null;
    this.filter = Array.isArray(filter) ? filter : [filter];
  }
  execute() {
    return new Promise(async (resolve, reject) => {
      this.pendingPromise = {
        resolve,
        reject
      };
      try {
        this.eventManager = await this.resolver._initialize(this.auth);
        await this.onExecution();
        this.eventManager.registerConsumer(this);
      } catch (e) {
        this.reject(e);
      }
    });
  }
  async onAuthEvent(event) {
    const {
      urlResponse,
      sessionId,
      postBody,
      tenantId,
      error,
      type
    } = event;
    if (error) {
      this.reject(error);
      return;
    }
    const params = {
      auth: this.auth,
      requestUri: urlResponse,
      sessionId,
      tenantId: tenantId || void 0,
      postBody: postBody || void 0,
      user: this.user,
      bypassAuthState: this.bypassAuthState
    };
    try {
      this.resolve(await this.getIdpTask(type)(params));
    } catch (e) {
      this.reject(e);
    }
  }
  onError(error) {
    this.reject(error);
  }
  getIdpTask(type) {
    switch (type) {
      case "signInViaPopup":
      case "signInViaRedirect":
        return _signIn;
      case "linkViaPopup":
      case "linkViaRedirect":
        return _link;
      case "reauthViaPopup":
      case "reauthViaRedirect":
        return _reauth;
      default:
        _fail(this.auth, "internal-error");
    }
  }
  resolve(cred) {
    debugAssert(this.pendingPromise, "Pending promise was never set");
    this.pendingPromise.resolve(cred);
    this.unregisterAndCleanUp();
  }
  reject(error) {
    debugAssert(this.pendingPromise, "Pending promise was never set");
    this.pendingPromise.reject(error);
    this.unregisterAndCleanUp();
  }
  unregisterAndCleanUp() {
    if (this.eventManager) {
      this.eventManager.unregisterConsumer(this);
    }
    this.pendingPromise = null;
    this.cleanUp();
  }
};
var _POLL_WINDOW_CLOSE_TIMEOUT = new Delay(2e3, 1e4);
async function signInWithPopup(auth, provider, resolver) {
  const authInternal = _castAuth(auth);
  _assertInstanceOf(auth, provider, FederatedAuthProvider);
  const resolverInternal = _withDefaultResolver(authInternal, resolver);
  const action = new PopupOperation(authInternal, "signInViaPopup", provider, resolverInternal);
  return action.executeNotNull();
}
async function reauthenticateWithPopup(user, provider, resolver) {
  const userInternal = (0, import_util.getModularInstance)(user);
  _assertInstanceOf(userInternal.auth, provider, FederatedAuthProvider);
  const resolverInternal = _withDefaultResolver(userInternal.auth, resolver);
  const action = new PopupOperation(userInternal.auth, "reauthViaPopup", provider, resolverInternal, userInternal);
  return action.executeNotNull();
}
async function linkWithPopup(user, provider, resolver) {
  const userInternal = (0, import_util.getModularInstance)(user);
  _assertInstanceOf(userInternal.auth, provider, FederatedAuthProvider);
  const resolverInternal = _withDefaultResolver(userInternal.auth, resolver);
  const action = new PopupOperation(userInternal.auth, "linkViaPopup", provider, resolverInternal, userInternal);
  return action.executeNotNull();
}
var PopupOperation = class extends AbstractPopupRedirectOperation {
  constructor(auth, filter, provider, resolver, user) {
    super(auth, filter, resolver, user);
    this.provider = provider;
    this.authWindow = null;
    this.pollId = null;
    if (PopupOperation.currentPopupAction) {
      PopupOperation.currentPopupAction.cancel();
    }
    PopupOperation.currentPopupAction = this;
  }
  async executeNotNull() {
    const result = await this.execute();
    _assert(result, this.auth, "internal-error");
    return result;
  }
  async onExecution() {
    debugAssert(this.filter.length === 1, "Popup operations only handle one event");
    const eventId = _generateEventId();
    this.authWindow = await this.resolver._openPopup(this.auth, this.provider, this.filter[0], eventId);
    this.authWindow.associatedEvent = eventId;
    this.resolver._originValidation(this.auth).catch(e => {
      this.reject(e);
    });
    this.resolver._isIframeWebStorageSupported(this.auth, isSupported => {
      if (!isSupported) {
        this.reject(_createError(this.auth, "web-storage-unsupported"));
      }
    });
    this.pollUserCancellation();
  }
  get eventId() {
    var _a;
    return ((_a = this.authWindow) === null || _a === void 0 ? void 0 : _a.associatedEvent) || null;
  }
  cancel() {
    this.reject(_createError(this.auth, "cancelled-popup-request"));
  }
  cleanUp() {
    if (this.authWindow) {
      this.authWindow.close();
    }
    if (this.pollId) {
      window.clearTimeout(this.pollId);
    }
    this.authWindow = null;
    this.pollId = null;
    PopupOperation.currentPopupAction = null;
  }
  pollUserCancellation() {
    const poll = () => {
      var _a, _b;
      if ((_b = (_a = this.authWindow) === null || _a === void 0 ? void 0 : _a.window) === null || _b === void 0 ? void 0 : _b.closed) {
        this.pollId = window.setTimeout(() => {
          this.pollId = null;
          this.reject(_createError(this.auth, "popup-closed-by-user"));
        }, 8e3);
        return;
      }
      this.pollId = window.setTimeout(poll, _POLL_WINDOW_CLOSE_TIMEOUT.get());
    };
    poll();
  }
};
PopupOperation.currentPopupAction = null;
var PENDING_REDIRECT_KEY = "pendingRedirect";
var redirectOutcomeMap = /* @__PURE__ */new Map();
var RedirectAction = class extends AbstractPopupRedirectOperation {
  constructor(auth, resolver, bypassAuthState = false) {
    super(auth, ["signInViaRedirect", "linkViaRedirect", "reauthViaRedirect", "unknown"], resolver, void 0, bypassAuthState);
    this.eventId = null;
  }
  async execute() {
    let readyOutcome = redirectOutcomeMap.get(this.auth._key());
    if (!readyOutcome) {
      try {
        const hasPendingRedirect = await _getAndClearPendingRedirectStatus(this.resolver, this.auth);
        const result = hasPendingRedirect ? await super.execute() : null;
        readyOutcome = () => Promise.resolve(result);
      } catch (e) {
        readyOutcome = () => Promise.reject(e);
      }
      redirectOutcomeMap.set(this.auth._key(), readyOutcome);
    }
    if (!this.bypassAuthState) {
      redirectOutcomeMap.set(this.auth._key(), () => Promise.resolve(null));
    }
    return readyOutcome();
  }
  async onAuthEvent(event) {
    if (event.type === "signInViaRedirect") {
      return super.onAuthEvent(event);
    } else if (event.type === "unknown") {
      this.resolve(null);
      return;
    }
    if (event.eventId) {
      const user = await this.auth._redirectUserForId(event.eventId);
      if (user) {
        this.user = user;
        return super.onAuthEvent(event);
      } else {
        this.resolve(null);
      }
    }
  }
  async onExecution() {}
  cleanUp() {}
};
async function _getAndClearPendingRedirectStatus(resolver, auth) {
  const key = pendingRedirectKey(auth);
  const persistence = resolverPersistence(resolver);
  if (!(await persistence._isAvailable())) {
    return false;
  }
  const hasPendingRedirect = (await persistence._get(key)) === "true";
  await persistence._remove(key);
  return hasPendingRedirect;
}
async function _setPendingRedirectStatus(resolver, auth) {
  return resolverPersistence(resolver)._set(pendingRedirectKey(auth), "true");
}
function _clearRedirectOutcomes() {
  redirectOutcomeMap.clear();
}
function _overrideRedirectResult(auth, result) {
  redirectOutcomeMap.set(auth._key(), result);
}
function resolverPersistence(resolver) {
  return _getInstance(resolver._redirectPersistence);
}
function pendingRedirectKey(auth) {
  return _persistenceKeyName(PENDING_REDIRECT_KEY, auth.config.apiKey, auth.name);
}
function signInWithRedirect(auth, provider, resolver) {
  return _signInWithRedirect(auth, provider, resolver);
}
async function _signInWithRedirect(auth, provider, resolver) {
  const authInternal = _castAuth(auth);
  _assertInstanceOf(auth, provider, FederatedAuthProvider);
  await authInternal._initializationPromise;
  const resolverInternal = _withDefaultResolver(authInternal, resolver);
  await _setPendingRedirectStatus(resolverInternal, authInternal);
  return resolverInternal._openRedirect(authInternal, provider, "signInViaRedirect");
}
function reauthenticateWithRedirect(user, provider, resolver) {
  return _reauthenticateWithRedirect(user, provider, resolver);
}
async function _reauthenticateWithRedirect(user, provider, resolver) {
  const userInternal = (0, import_util.getModularInstance)(user);
  _assertInstanceOf(userInternal.auth, provider, FederatedAuthProvider);
  await userInternal.auth._initializationPromise;
  const resolverInternal = _withDefaultResolver(userInternal.auth, resolver);
  await _setPendingRedirectStatus(resolverInternal, userInternal.auth);
  const eventId = await prepareUserForRedirect(userInternal);
  return resolverInternal._openRedirect(userInternal.auth, provider, "reauthViaRedirect", eventId);
}
function linkWithRedirect(user, provider, resolver) {
  return _linkWithRedirect(user, provider, resolver);
}
async function _linkWithRedirect(user, provider, resolver) {
  const userInternal = (0, import_util.getModularInstance)(user);
  _assertInstanceOf(userInternal.auth, provider, FederatedAuthProvider);
  await userInternal.auth._initializationPromise;
  const resolverInternal = _withDefaultResolver(userInternal.auth, resolver);
  await _assertLinkedStatus(false, userInternal, provider.providerId);
  await _setPendingRedirectStatus(resolverInternal, userInternal.auth);
  const eventId = await prepareUserForRedirect(userInternal);
  return resolverInternal._openRedirect(userInternal.auth, provider, "linkViaRedirect", eventId);
}
async function getRedirectResult(auth, resolver) {
  await _castAuth(auth)._initializationPromise;
  return _getRedirectResult(auth, resolver, false);
}
async function _getRedirectResult(auth, resolverExtern, bypassAuthState = false) {
  const authInternal = _castAuth(auth);
  const resolver = _withDefaultResolver(authInternal, resolverExtern);
  const action = new RedirectAction(authInternal, resolver, bypassAuthState);
  const result = await action.execute();
  if (result && !bypassAuthState) {
    delete result.user._redirectEventId;
    await authInternal._persistUserIfCurrent(result.user);
    await authInternal._setRedirectUser(null, resolverExtern);
  }
  return result;
}
async function prepareUserForRedirect(user) {
  const eventId = _generateEventId(`${user.uid}:::`);
  user._redirectEventId = eventId;
  await user.auth._setRedirectUser(user);
  await user.auth._persistUserIfCurrent(user);
  return eventId;
}
var EVENT_DUPLICATION_CACHE_DURATION_MS = 10 * 60 * 1e3;
var AuthEventManager = class {
  constructor(auth) {
    this.auth = auth;
    this.cachedEventUids = /* @__PURE__ */new Set();
    this.consumers = /* @__PURE__ */new Set();
    this.queuedRedirectEvent = null;
    this.hasHandledPotentialRedirect = false;
    this.lastProcessedEventTime = Date.now();
  }
  registerConsumer(authEventConsumer) {
    this.consumers.add(authEventConsumer);
    if (this.queuedRedirectEvent && this.isEventForConsumer(this.queuedRedirectEvent, authEventConsumer)) {
      this.sendToConsumer(this.queuedRedirectEvent, authEventConsumer);
      this.saveEventToCache(this.queuedRedirectEvent);
      this.queuedRedirectEvent = null;
    }
  }
  unregisterConsumer(authEventConsumer) {
    this.consumers.delete(authEventConsumer);
  }
  onEvent(event) {
    if (this.hasEventBeenHandled(event)) {
      return false;
    }
    let handled = false;
    this.consumers.forEach(consumer => {
      if (this.isEventForConsumer(event, consumer)) {
        handled = true;
        this.sendToConsumer(event, consumer);
        this.saveEventToCache(event);
      }
    });
    if (this.hasHandledPotentialRedirect || !isRedirectEvent(event)) {
      return handled;
    }
    this.hasHandledPotentialRedirect = true;
    if (!handled) {
      this.queuedRedirectEvent = event;
      handled = true;
    }
    return handled;
  }
  sendToConsumer(event, consumer) {
    var _a;
    if (event.error && !isNullRedirectEvent(event)) {
      const code = ((_a = event.error.code) === null || _a === void 0 ? void 0 : _a.split("auth/")[1]) || "internal-error";
      consumer.onError(_createError(this.auth, code));
    } else {
      consumer.onAuthEvent(event);
    }
  }
  isEventForConsumer(event, consumer) {
    const eventIdMatches = consumer.eventId === null || !!event.eventId && event.eventId === consumer.eventId;
    return consumer.filter.includes(event.type) && eventIdMatches;
  }
  hasEventBeenHandled(event) {
    if (Date.now() - this.lastProcessedEventTime >= EVENT_DUPLICATION_CACHE_DURATION_MS) {
      this.cachedEventUids.clear();
    }
    return this.cachedEventUids.has(eventUid(event));
  }
  saveEventToCache(event) {
    this.cachedEventUids.add(eventUid(event));
    this.lastProcessedEventTime = Date.now();
  }
};
function eventUid(e) {
  return [e.type, e.eventId, e.sessionId, e.tenantId].filter(v => v).join("-");
}
function isNullRedirectEvent({
  type,
  error
}) {
  return type === "unknown" && (error === null || error === void 0 ? void 0 : error.code) === `auth/${"no-auth-event"}`;
}
function isRedirectEvent(event) {
  switch (event.type) {
    case "signInViaRedirect":
    case "linkViaRedirect":
    case "reauthViaRedirect":
      return true;
    case "unknown":
      return isNullRedirectEvent(event);
    default:
      return false;
  }
}
async function _getProjectConfig(auth, request = {}) {
  return _performApiRequest(auth, "GET", "/v1/projects", request);
}
var IP_ADDRESS_REGEX = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
var HTTP_REGEX = /^https?/;
async function _validateOrigin(auth) {
  if (auth.config.emulator) {
    return;
  }
  const {
    authorizedDomains
  } = await _getProjectConfig(auth);
  for (const domain of authorizedDomains) {
    try {
      if (matchDomain(domain)) {
        return;
      }
    } catch (_a) {}
  }
  _fail(auth, "unauthorized-domain");
}
function matchDomain(expected) {
  const currentUrl = _getCurrentUrl();
  const {
    protocol,
    hostname
  } = new URL(currentUrl);
  if (expected.startsWith("chrome-extension://")) {
    const ceUrl = new URL(expected);
    if (ceUrl.hostname === "" && hostname === "") {
      return protocol === "chrome-extension:" && expected.replace("chrome-extension://", "") === currentUrl.replace("chrome-extension://", "");
    }
    return protocol === "chrome-extension:" && ceUrl.hostname === hostname;
  }
  if (!HTTP_REGEX.test(protocol)) {
    return false;
  }
  if (IP_ADDRESS_REGEX.test(expected)) {
    return hostname === expected;
  }
  const escapedDomainPattern = expected.replace(/\./g, "\\.");
  const re = new RegExp("^(.+\\." + escapedDomainPattern + "|" + escapedDomainPattern + ")$", "i");
  return re.test(hostname);
}
var NETWORK_TIMEOUT = new Delay(3e4, 6e4);
function resetUnloadedGapiModules() {
  const beacon = _window().___jsl;
  if (beacon === null || beacon === void 0 ? void 0 : beacon.H) {
    for (const hint of Object.keys(beacon.H)) {
      beacon.H[hint].r = beacon.H[hint].r || [];
      beacon.H[hint].L = beacon.H[hint].L || [];
      beacon.H[hint].r = [...beacon.H[hint].L];
      if (beacon.CP) {
        for (let i = 0; i < beacon.CP.length; i++) {
          beacon.CP[i] = null;
        }
      }
    }
  }
}
function loadGapi(auth) {
  return new Promise((resolve, reject) => {
    var _a, _b, _c;
    function loadGapiIframe() {
      resetUnloadedGapiModules();
      gapi.load("gapi.iframes", {
        callback: () => {
          resolve(gapi.iframes.getContext());
        },
        ontimeout: () => {
          resetUnloadedGapiModules();
          reject(_createError(auth, "network-request-failed"));
        },
        timeout: NETWORK_TIMEOUT.get()
      });
    }
    if ((_b = (_a = _window().gapi) === null || _a === void 0 ? void 0 : _a.iframes) === null || _b === void 0 ? void 0 : _b.Iframe) {
      resolve(gapi.iframes.getContext());
    } else if (!!((_c = _window().gapi) === null || _c === void 0 ? void 0 : _c.load)) {
      loadGapiIframe();
    } else {
      const cbName = _generateCallbackName("iframefcb");
      _window()[cbName] = () => {
        if (!!gapi.load) {
          loadGapiIframe();
        } else {
          reject(_createError(auth, "network-request-failed"));
        }
      };
      return _loadJS(`https://apis.google.com/js/api.js?onload=${cbName}`).catch(e => reject(e));
    }
  }).catch(error => {
    cachedGApiLoader = null;
    throw error;
  });
}
var cachedGApiLoader = null;
function _loadGapi(auth) {
  cachedGApiLoader = cachedGApiLoader || loadGapi(auth);
  return cachedGApiLoader;
}
var PING_TIMEOUT = new Delay(5e3, 15e3);
var IFRAME_PATH = "__/auth/iframe";
var EMULATED_IFRAME_PATH = "emulator/auth/iframe";
var IFRAME_ATTRIBUTES = {
  style: {
    position: "absolute",
    top: "-100px",
    width: "1px",
    height: "1px"
  },
  "aria-hidden": "true",
  tabindex: "-1"
};
var EID_FROM_APIHOST = /* @__PURE__ */new Map([["identitytoolkit.googleapis.com", "p"], ["staging-identitytoolkit.sandbox.googleapis.com", "s"], ["test-identitytoolkit.sandbox.googleapis.com", "t"]]);
function getIframeUrl(auth) {
  const config = auth.config;
  _assert(config.authDomain, auth, "auth-domain-config-required");
  const url = config.emulator ? _emulatorUrl(config, EMULATED_IFRAME_PATH) : `https://${auth.config.authDomain}/${IFRAME_PATH}`;
  const params = {
    apiKey: config.apiKey,
    appName: auth.name,
    v: import_app.SDK_VERSION
  };
  const eid = EID_FROM_APIHOST.get(auth.config.apiHost);
  if (eid) {
    params.eid = eid;
  }
  const frameworks = auth._getFrameworks();
  if (frameworks.length) {
    params.fw = frameworks.join(",");
  }
  return `${url}?${(0, import_util.querystring)(params).slice(1)}`;
}
async function _openIframe(auth) {
  const context = await _loadGapi(auth);
  const gapi2 = _window().gapi;
  _assert(gapi2, auth, "internal-error");
  return context.open({
    where: document.body,
    url: getIframeUrl(auth),
    messageHandlersFilter: gapi2.iframes.CROSS_ORIGIN_IFRAMES_FILTER,
    attributes: IFRAME_ATTRIBUTES,
    dontclear: true
  }, iframe => new Promise(async (resolve, reject) => {
    await iframe.restyle({
      setHideOnLeave: false
    });
    const networkError = _createError(auth, "network-request-failed");
    const networkErrorTimer = _window().setTimeout(() => {
      reject(networkError);
    }, PING_TIMEOUT.get());
    function clearTimerAndResolve() {
      _window().clearTimeout(networkErrorTimer);
      resolve(iframe);
    }
    iframe.ping(clearTimerAndResolve).then(clearTimerAndResolve, () => {
      reject(networkError);
    });
  }));
}
var BASE_POPUP_OPTIONS = {
  location: "yes",
  resizable: "yes",
  statusbar: "yes",
  toolbar: "no"
};
var DEFAULT_WIDTH = 500;
var DEFAULT_HEIGHT = 600;
var TARGET_BLANK = "_blank";
var FIREFOX_EMPTY_URL = "http://localhost";
var AuthPopup = class {
  constructor(window2) {
    this.window = window2;
    this.associatedEvent = null;
  }
  close() {
    if (this.window) {
      try {
        this.window.close();
      } catch (e) {}
    }
  }
};
function _open(auth, url, name2, width = DEFAULT_WIDTH, height = DEFAULT_HEIGHT) {
  const top = Math.max((window.screen.availHeight - height) / 2, 0).toString();
  const left = Math.max((window.screen.availWidth - width) / 2, 0).toString();
  let target = "";
  const options = Object.assign(Object.assign({}, BASE_POPUP_OPTIONS), {
    width: width.toString(),
    height: height.toString(),
    top,
    left
  });
  const ua = (0, import_util.getUA)().toLowerCase();
  if (name2) {
    target = _isChromeIOS(ua) ? TARGET_BLANK : name2;
  }
  if (_isFirefox(ua)) {
    url = url || FIREFOX_EMPTY_URL;
    options.scrollbars = "yes";
  }
  const optionsString = Object.entries(options).reduce((accum, [key, value]) => `${accum}${key}=${value},`, "");
  if (_isIOSStandalone(ua) && target !== "_self") {
    openAsNewWindowIOS(url || "", target);
    return new AuthPopup(null);
  }
  const newWin = window.open(url || "", target, optionsString);
  _assert(newWin, auth, "popup-blocked");
  try {
    newWin.focus();
  } catch (e) {}
  return new AuthPopup(newWin);
}
function openAsNewWindowIOS(url, target) {
  const el = document.createElement("a");
  el.href = url;
  el.target = target;
  const click = document.createEvent("MouseEvent");
  click.initMouseEvent("click", true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 1, null);
  el.dispatchEvent(click);
}
var WIDGET_PATH = "__/auth/handler";
var EMULATOR_WIDGET_PATH = "emulator/auth/handler";
var FIREBASE_APP_CHECK_FRAGMENT_ID = encodeURIComponent("fac");
async function _getRedirectUrl(auth, provider, authType, redirectUrl, eventId, additionalParams) {
  _assert(auth.config.authDomain, auth, "auth-domain-config-required");
  _assert(auth.config.apiKey, auth, "invalid-api-key");
  const params = {
    apiKey: auth.config.apiKey,
    appName: auth.name,
    authType,
    redirectUrl,
    v: import_app.SDK_VERSION,
    eventId
  };
  if (provider instanceof FederatedAuthProvider) {
    provider.setDefaultLanguage(auth.languageCode);
    params.providerId = provider.providerId || "";
    if (!(0, import_util.isEmpty)(provider.getCustomParameters())) {
      params.customParameters = JSON.stringify(provider.getCustomParameters());
    }
    for (const [key, value] of Object.entries(additionalParams || {})) {
      params[key] = value;
    }
  }
  if (provider instanceof BaseOAuthProvider) {
    const scopes = provider.getScopes().filter(scope => scope !== "");
    if (scopes.length > 0) {
      params.scopes = scopes.join(",");
    }
  }
  if (auth.tenantId) {
    params.tid = auth.tenantId;
  }
  const paramsDict = params;
  for (const key of Object.keys(paramsDict)) {
    if (paramsDict[key] === void 0) {
      delete paramsDict[key];
    }
  }
  const appCheckToken = await auth._getAppCheckToken();
  const appCheckTokenFragment = appCheckToken ? `#${FIREBASE_APP_CHECK_FRAGMENT_ID}=${encodeURIComponent(appCheckToken)}` : "";
  return `${getHandlerBase(auth)}?${(0, import_util.querystring)(paramsDict).slice(1)}${appCheckTokenFragment}`;
}
function getHandlerBase({
  config
}) {
  if (!config.emulator) {
    return `https://${config.authDomain}/${WIDGET_PATH}`;
  }
  return _emulatorUrl(config, EMULATOR_WIDGET_PATH);
}
var WEB_STORAGE_SUPPORT_KEY = "webStorageSupport";
var BrowserPopupRedirectResolver = class {
  constructor() {
    this.eventManagers = {};
    this.iframes = {};
    this.originValidationPromises = {};
    this._redirectPersistence = browserSessionPersistence;
    this._completeRedirectFn = _getRedirectResult;
    this._overrideRedirectResult = _overrideRedirectResult;
  }
  async _openPopup(auth, provider, authType, eventId) {
    var _a;
    debugAssert((_a = this.eventManagers[auth._key()]) === null || _a === void 0 ? void 0 : _a.manager, "_initialize() not called before _openPopup()");
    const url = await _getRedirectUrl(auth, provider, authType, _getCurrentUrl(), eventId);
    return _open(auth, url, _generateEventId());
  }
  async _openRedirect(auth, provider, authType, eventId) {
    await this._originValidation(auth);
    const url = await _getRedirectUrl(auth, provider, authType, _getCurrentUrl(), eventId);
    _setWindowLocation(url);
    return new Promise(() => {});
  }
  _initialize(auth) {
    const key = auth._key();
    if (this.eventManagers[key]) {
      const {
        manager,
        promise: promise2
      } = this.eventManagers[key];
      if (manager) {
        return Promise.resolve(manager);
      } else {
        debugAssert(promise2, "If manager is not set, promise should be");
        return promise2;
      }
    }
    const promise = this.initAndGetManager(auth);
    this.eventManagers[key] = {
      promise
    };
    promise.catch(() => {
      delete this.eventManagers[key];
    });
    return promise;
  }
  async initAndGetManager(auth) {
    const iframe = await _openIframe(auth);
    const manager = new AuthEventManager(auth);
    iframe.register("authEvent", iframeEvent => {
      _assert(iframeEvent === null || iframeEvent === void 0 ? void 0 : iframeEvent.authEvent, auth, "invalid-auth-event");
      const handled = manager.onEvent(iframeEvent.authEvent);
      return {
        status: handled ? "ACK" : "ERROR"
      };
    }, gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER);
    this.eventManagers[auth._key()] = {
      manager
    };
    this.iframes[auth._key()] = iframe;
    return manager;
  }
  _isIframeWebStorageSupported(auth, cb) {
    const iframe = this.iframes[auth._key()];
    iframe.send(WEB_STORAGE_SUPPORT_KEY, {
      type: WEB_STORAGE_SUPPORT_KEY
    }, result => {
      var _a;
      const isSupported = (_a = result === null || result === void 0 ? void 0 : result[0]) === null || _a === void 0 ? void 0 : _a[WEB_STORAGE_SUPPORT_KEY];
      if (isSupported !== void 0) {
        cb(!!isSupported);
      }
      _fail(auth, "internal-error");
    }, gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER);
  }
  _originValidation(auth) {
    const key = auth._key();
    if (!this.originValidationPromises[key]) {
      this.originValidationPromises[key] = _validateOrigin(auth);
    }
    return this.originValidationPromises[key];
  }
  get _shouldInitProactively() {
    return _isMobileBrowser() || _isSafari() || _isIOS();
  }
};
var browserPopupRedirectResolver = BrowserPopupRedirectResolver;
var MultiFactorAssertionImpl = class {
  constructor(factorId) {
    this.factorId = factorId;
  }
  _process(auth, session, displayName) {
    switch (session.type) {
      case "enroll":
        return this._finalizeEnroll(auth, session.credential, displayName);
      case "signin":
        return this._finalizeSignIn(auth, session.credential);
      default:
        return debugFail("unexpected MultiFactorSessionType");
    }
  }
};
var PhoneMultiFactorAssertionImpl = class extends MultiFactorAssertionImpl {
  constructor(credential) {
    super("phone");
    this.credential = credential;
  }
  static _fromCredential(credential) {
    return new PhoneMultiFactorAssertionImpl(credential);
  }
  _finalizeEnroll(auth, idToken, displayName) {
    return finalizeEnrollPhoneMfa(auth, {
      idToken,
      displayName,
      phoneVerificationInfo: this.credential._makeVerificationRequest()
    });
  }
  _finalizeSignIn(auth, mfaPendingCredential) {
    return finalizeSignInPhoneMfa(auth, {
      mfaPendingCredential,
      phoneVerificationInfo: this.credential._makeVerificationRequest()
    });
  }
};
var PhoneMultiFactorGenerator = class {
  constructor() {}
  static assertion(credential) {
    return PhoneMultiFactorAssertionImpl._fromCredential(credential);
  }
};
PhoneMultiFactorGenerator.FACTOR_ID = "phone";
var TotpMultiFactorGenerator = class {
  static assertionForEnrollment(secret, oneTimePassword) {
    return TotpMultiFactorAssertionImpl._fromSecret(secret, oneTimePassword);
  }
  static assertionForSignIn(enrollmentId, oneTimePassword) {
    return TotpMultiFactorAssertionImpl._fromEnrollmentId(enrollmentId, oneTimePassword);
  }
  static async generateSecret(session) {
    var _a;
    const mfaSession = session;
    _assert(typeof ((_a = mfaSession.user) === null || _a === void 0 ? void 0 : _a.auth) !== "undefined", "internal-error");
    const response = await startEnrollTotpMfa(mfaSession.user.auth, {
      idToken: mfaSession.credential,
      totpEnrollmentInfo: {}
    });
    return TotpSecret._fromStartTotpMfaEnrollmentResponse(response, mfaSession.user.auth);
  }
};
TotpMultiFactorGenerator.FACTOR_ID = "totp";
var TotpMultiFactorAssertionImpl = class extends MultiFactorAssertionImpl {
  constructor(otp, enrollmentId, secret) {
    super("totp");
    this.otp = otp;
    this.enrollmentId = enrollmentId;
    this.secret = secret;
  }
  static _fromSecret(secret, otp) {
    return new TotpMultiFactorAssertionImpl(otp, void 0, secret);
  }
  static _fromEnrollmentId(enrollmentId, otp) {
    return new TotpMultiFactorAssertionImpl(otp, enrollmentId);
  }
  async _finalizeEnroll(auth, idToken, displayName) {
    _assert(typeof this.secret !== "undefined", auth, "argument-error");
    return finalizeEnrollTotpMfa(auth, {
      idToken,
      displayName,
      totpVerificationInfo: this.secret._makeTotpVerificationInfo(this.otp)
    });
  }
  async _finalizeSignIn(auth, mfaPendingCredential) {
    _assert(this.enrollmentId !== void 0 && this.otp !== void 0, auth, "argument-error");
    const totpVerificationInfo = {
      verificationCode: this.otp
    };
    return finalizeSignInTotpMfa(auth, {
      mfaPendingCredential,
      mfaEnrollmentId: this.enrollmentId,
      totpVerificationInfo
    });
  }
};
var TotpSecret = class {
  constructor(secretKey, hashingAlgorithm, codeLength, codeIntervalSeconds, enrollmentCompletionDeadline, sessionInfo, auth) {
    this.sessionInfo = sessionInfo;
    this.auth = auth;
    this.secretKey = secretKey;
    this.hashingAlgorithm = hashingAlgorithm;
    this.codeLength = codeLength;
    this.codeIntervalSeconds = codeIntervalSeconds;
    this.enrollmentCompletionDeadline = enrollmentCompletionDeadline;
  }
  static _fromStartTotpMfaEnrollmentResponse(response, auth) {
    return new TotpSecret(response.totpSessionInfo.sharedSecretKey, response.totpSessionInfo.hashingAlgorithm, response.totpSessionInfo.verificationCodeLength, response.totpSessionInfo.periodSec, new Date(response.totpSessionInfo.finalizeEnrollmentTime).toUTCString(), response.totpSessionInfo.sessionInfo, auth);
  }
  _makeTotpVerificationInfo(otp) {
    return {
      sessionInfo: this.sessionInfo,
      verificationCode: otp
    };
  }
  generateQrCodeUrl(accountName, issuer) {
    var _a;
    let useDefaults = false;
    if (_isEmptyString(accountName) || _isEmptyString(issuer)) {
      useDefaults = true;
    }
    if (useDefaults) {
      if (_isEmptyString(accountName)) {
        accountName = ((_a = this.auth.currentUser) === null || _a === void 0 ? void 0 : _a.email) || "unknownuser";
      }
      if (_isEmptyString(issuer)) {
        issuer = this.auth.name;
      }
    }
    return `otpauth://totp/${issuer}:${accountName}?secret=${this.secretKey}&issuer=${issuer}&algorithm=${this.hashingAlgorithm}&digits=${this.codeLength}`;
  }
};
function _isEmptyString(input) {
  return typeof input === "undefined" || (input === null || input === void 0 ? void 0 : input.length) === 0;
}
var name = "@firebase/auth";
var version = "1.5.1";
var AuthInterop = class {
  constructor(auth) {
    this.auth = auth;
    this.internalListeners = /* @__PURE__ */new Map();
  }
  getUid() {
    var _a;
    this.assertAuthConfigured();
    return ((_a = this.auth.currentUser) === null || _a === void 0 ? void 0 : _a.uid) || null;
  }
  async getToken(forceRefresh) {
    this.assertAuthConfigured();
    await this.auth._initializationPromise;
    if (!this.auth.currentUser) {
      return null;
    }
    const accessToken = await this.auth.currentUser.getIdToken(forceRefresh);
    return {
      accessToken
    };
  }
  addAuthTokenListener(listener) {
    this.assertAuthConfigured();
    if (this.internalListeners.has(listener)) {
      return;
    }
    const unsubscribe = this.auth.onIdTokenChanged(user => {
      listener((user === null || user === void 0 ? void 0 : user.stsTokenManager.accessToken) || null);
    });
    this.internalListeners.set(listener, unsubscribe);
    this.updateProactiveRefresh();
  }
  removeAuthTokenListener(listener) {
    this.assertAuthConfigured();
    const unsubscribe = this.internalListeners.get(listener);
    if (!unsubscribe) {
      return;
    }
    this.internalListeners.delete(listener);
    unsubscribe();
    this.updateProactiveRefresh();
  }
  assertAuthConfigured() {
    _assert(this.auth._initializationPromise, "dependent-sdk-initialized-before-auth");
  }
  updateProactiveRefresh() {
    if (this.internalListeners.size > 0) {
      this.auth._startProactiveRefresh();
    } else {
      this.auth._stopProactiveRefresh();
    }
  }
};
function getVersionForPlatform(clientPlatform) {
  switch (clientPlatform) {
    case "Node":
      return "node";
    case "ReactNative":
      return "rn";
    case "Worker":
      return "webworker";
    case "Cordova":
      return "cordova";
    default:
      return void 0;
  }
}
function registerAuth(clientPlatform) {
  (0, import_app._registerComponent)(new import_component.Component("auth", (container, {
    options: deps
  }) => {
    const app = container.getProvider("app").getImmediate();
    const heartbeatServiceProvider = container.getProvider("heartbeat");
    const appCheckServiceProvider = container.getProvider("app-check-internal");
    const {
      apiKey,
      authDomain
    } = app.options;
    _assert(apiKey && !apiKey.includes(":"), "invalid-api-key", {
      appName: app.name
    });
    const config = {
      apiKey,
      authDomain,
      clientPlatform,
      apiHost: "identitytoolkit.googleapis.com",
      tokenApiHost: "securetoken.googleapis.com",
      apiScheme: "https",
      sdkClientVersion: _getClientVersion(clientPlatform)
    };
    const authInstance = new AuthImpl(app, heartbeatServiceProvider, appCheckServiceProvider, config);
    _initializeAuthInstance(authInstance, deps);
    return authInstance;
  }, "PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((container, _instanceIdentifier, _instance) => {
    const authInternalProvider = container.getProvider("auth-internal");
    authInternalProvider.initialize();
  }));
  (0, import_app._registerComponent)(new import_component.Component("auth-internal", container => {
    const auth = _castAuth(container.getProvider("auth").getImmediate());
    return (auth2 => new AuthInterop(auth2))(auth);
  }, "PRIVATE").setInstantiationMode("EXPLICIT"));
  (0, import_app.registerVersion)(name, version, getVersionForPlatform(clientPlatform));
  (0, import_app.registerVersion)(name, version, "esm2017");
}
var DEFAULT_ID_TOKEN_MAX_AGE = 5 * 60;
var authIdTokenMaxAge = (0, import_util.getExperimentalSetting)("authIdTokenMaxAge") || DEFAULT_ID_TOKEN_MAX_AGE;
var lastPostedIdToken = null;
var mintCookieFactory = url => async user => {
  const idTokenResult = user && (await user.getIdTokenResult());
  const idTokenAge = idTokenResult && (new Date().getTime() - Date.parse(idTokenResult.issuedAtTime)) / 1e3;
  if (idTokenAge && idTokenAge > authIdTokenMaxAge) {
    return;
  }
  const idToken = idTokenResult === null || idTokenResult === void 0 ? void 0 : idTokenResult.token;
  if (lastPostedIdToken === idToken) {
    return;
  }
  lastPostedIdToken = idToken;
  await fetch(url, {
    method: idToken ? "POST" : "DELETE",
    headers: idToken ? {
      "Authorization": `Bearer ${idToken}`
    } : {}
  });
};
function getAuth(app = (0, import_app.getApp)()) {
  const provider = (0, import_app._getProvider)(app, "auth");
  if (provider.isInitialized()) {
    return provider.getImmediate();
  }
  const auth = initializeAuth(app, {
    popupRedirectResolver: browserPopupRedirectResolver,
    persistence: [indexedDBLocalPersistence, browserLocalPersistence, browserSessionPersistence]
  });
  const authTokenSyncUrl = (0, import_util.getExperimentalSetting)("authTokenSyncURL");
  if (authTokenSyncUrl) {
    const mintCookie = mintCookieFactory(authTokenSyncUrl);
    beforeAuthStateChanged(auth, mintCookie, () => mintCookie(auth.currentUser));
    onIdTokenChanged(auth, user => mintCookie(user));
  }
  const authEmulatorHost = (0, import_util.getDefaultEmulatorHost)("auth");
  if (authEmulatorHost) {
    connectAuthEmulator(auth, `http://${authEmulatorHost}`);
  }
  return auth;
}
registerAuth("Browser");

// node_modules/@firebase/auth/dist/esm2017/index.js
var import_util2 = require("@firebase/util@1.9.3");
var import_app2 = require("@firebase/app@0.9.26");
var import_logger2 = require("@firebase/logger@0.4.0");
var import_tslib2 = require("tslib@2.6.2");
var import_component2 = require("@firebase/component@0.6.4");
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL0BmaXJlYmFzZS9hdXRoLjEuNS4xLmpzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9tb2RlbC9lbnVtX21hcHMudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2NvcmUvZXJyb3JzLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3V0aWwvbG9nLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3V0aWwvYXNzZXJ0LnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3V0aWwvbG9jYXRpb24udHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2NvcmUvdXRpbC9uYXZpZ2F0b3IudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2NvcmUvdXRpbC9kZWxheS50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvY29yZS91dGlsL2VtdWxhdG9yLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3V0aWwvZmV0Y2hfcHJvdmlkZXIudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2FwaS9lcnJvcnMudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2FwaS9pbmRleC50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvcGxhdGZvcm1fYnJvd3Nlci9yZWNhcHRjaGEvcmVjYXB0Y2hhLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9hcGkvYXV0aGVudGljYXRpb24vcmVjYXB0Y2hhLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9hcGkvYWNjb3VudF9tYW5hZ2VtZW50L2FjY291bnQudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2NvcmUvdXRpbC90aW1lLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3VzZXIvaWRfdG9rZW5fcmVzdWx0LnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3VzZXIvaW52YWxpZGF0aW9uLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3VzZXIvcHJvYWN0aXZlX3JlZnJlc2gudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2NvcmUvdXNlci91c2VyX21ldGFkYXRhLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3VzZXIvcmVsb2FkLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9hcGkvYXV0aGVudGljYXRpb24vdG9rZW4udHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2NvcmUvdXNlci90b2tlbl9tYW5hZ2VyLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3VzZXIvdXNlcl9pbXBsLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3V0aWwvaW5zdGFudGlhdG9yLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3BlcnNpc3RlbmNlL2luX21lbW9yeS50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvY29yZS9wZXJzaXN0ZW5jZS9wZXJzaXN0ZW5jZV91c2VyX21hbmFnZXIudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2NvcmUvdXRpbC9icm93c2VyLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3V0aWwvdmVyc2lvbi50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvY29yZS9hdXRoL21pZGRsZXdhcmUudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2FwaS9wYXNzd29yZF9wb2xpY3kvZ2V0X3Bhc3N3b3JkX3BvbGljeS50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvY29yZS9hdXRoL3Bhc3N3b3JkX3BvbGljeV9pbXBsLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL2F1dGgvYXV0aF9pbXBsLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9wbGF0Zm9ybV9icm93c2VyL2xvYWRfanMudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL3BsYXRmb3JtX2Jyb3dzZXIvcmVjYXB0Y2hhL3JlY2FwdGNoYV9lbnRlcnByaXNlX3ZlcmlmaWVyLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL2F1dGgvaW5pdGlhbGl6ZS50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvY29yZS9hdXRoL2VtdWxhdG9yLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL2NyZWRlbnRpYWxzL2F1dGhfY3JlZGVudGlhbC50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvYXBpL2FjY291bnRfbWFuYWdlbWVudC9lbWFpbF9hbmRfcGFzc3dvcmQudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2FwaS9hdXRoZW50aWNhdGlvbi9lbWFpbF9hbmRfcGFzc3dvcmQudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2FwaS9hdXRoZW50aWNhdGlvbi9lbWFpbF9saW5rLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL2NyZWRlbnRpYWxzL2VtYWlsLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9hcGkvYXV0aGVudGljYXRpb24vaWRwLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL2NyZWRlbnRpYWxzL29hdXRoLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9hcGkvYXV0aGVudGljYXRpb24vc21zLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL2NyZWRlbnRpYWxzL3Bob25lLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL2FjdGlvbl9jb2RlX3VybC50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvY29yZS9wcm92aWRlcnMvZW1haWwudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2NvcmUvcHJvdmlkZXJzL2ZlZGVyYXRlZC50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvY29yZS9wcm92aWRlcnMvb2F1dGgudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2NvcmUvcHJvdmlkZXJzL2ZhY2Vib29rLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3Byb3ZpZGVycy9nb29nbGUudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2NvcmUvcHJvdmlkZXJzL2dpdGh1Yi50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvY29yZS9jcmVkZW50aWFscy9zYW1sLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3Byb3ZpZGVycy9zYW1sLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3Byb3ZpZGVycy90d2l0dGVyLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9hcGkvYXV0aGVudGljYXRpb24vc2lnbl91cC50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvY29yZS91c2VyL3VzZXJfY3JlZGVudGlhbF9pbXBsLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3N0cmF0ZWdpZXMvYW5vbnltb3VzLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9tZmEvbWZhX2Vycm9yLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3V0aWwvcHJvdmlkZXJzLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3VzZXIvbGlua191bmxpbmsudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2NvcmUvdXNlci9yZWF1dGhlbnRpY2F0ZS50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvY29yZS9zdHJhdGVnaWVzL2NyZWRlbnRpYWwudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2FwaS9hdXRoZW50aWNhdGlvbi9jdXN0b21fdG9rZW4udHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2NvcmUvc3RyYXRlZ2llcy9jdXN0b21fdG9rZW4udHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL21mYS9tZmFfaW5mby50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvY29yZS9zdHJhdGVnaWVzL2FjdGlvbl9jb2RlX3NldHRpbmdzLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3N0cmF0ZWdpZXMvZW1haWxfYW5kX3Bhc3N3b3JkLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3N0cmF0ZWdpZXMvZW1haWxfbGluay50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvYXBpL2F1dGhlbnRpY2F0aW9uL2NyZWF0ZV9hdXRoX3VyaS50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvY29yZS9zdHJhdGVnaWVzL2VtYWlsLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9hcGkvYWNjb3VudF9tYW5hZ2VtZW50L3Byb2ZpbGUudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2NvcmUvdXNlci9hY2NvdW50X2luZm8udHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2NvcmUvdXNlci9hZGRpdGlvbmFsX3VzZXJfaW5mby50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvY29yZS9pbmRleC50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvbWZhL21mYV9zZXNzaW9uLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9tZmEvbWZhX3Jlc29sdmVyLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9hcGkvYWNjb3VudF9tYW5hZ2VtZW50L21mYS50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvbWZhL21mYV91c2VyLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3BlcnNpc3RlbmNlL2luZGV4LnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9wbGF0Zm9ybV9icm93c2VyL3BlcnNpc3RlbmNlL2Jyb3dzZXIudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL3BsYXRmb3JtX2Jyb3dzZXIvcGVyc2lzdGVuY2UvbG9jYWxfc3RvcmFnZS50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvcGxhdGZvcm1fYnJvd3Nlci9wZXJzaXN0ZW5jZS9zZXNzaW9uX3N0b3JhZ2UudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL3BsYXRmb3JtX2Jyb3dzZXIvbWVzc2FnZWNoYW5uZWwvcHJvbWlzZS50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvcGxhdGZvcm1fYnJvd3Nlci9tZXNzYWdlY2hhbm5lbC9yZWNlaXZlci50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvY29yZS91dGlsL2V2ZW50X2lkLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9wbGF0Zm9ybV9icm93c2VyL21lc3NhZ2VjaGFubmVsL3NlbmRlci50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvcGxhdGZvcm1fYnJvd3Nlci9hdXRoX3dpbmRvdy50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvcGxhdGZvcm1fYnJvd3Nlci91dGlsL3dvcmtlci50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvcGxhdGZvcm1fYnJvd3Nlci9wZXJzaXN0ZW5jZS9pbmRleGVkX2RiLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9hcGkvYXV0aGVudGljYXRpb24vbWZhLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9wbGF0Zm9ybV9icm93c2VyL3JlY2FwdGNoYS9yZWNhcHRjaGFfbW9jay50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvcGxhdGZvcm1fYnJvd3Nlci9yZWNhcHRjaGEvcmVjYXB0Y2hhX2xvYWRlci50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvcGxhdGZvcm1fYnJvd3Nlci9yZWNhcHRjaGEvcmVjYXB0Y2hhX3ZlcmlmaWVyLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9wbGF0Zm9ybV9icm93c2VyL3N0cmF0ZWdpZXMvcGhvbmUudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL3BsYXRmb3JtX2Jyb3dzZXIvcHJvdmlkZXJzL3Bob25lLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3V0aWwvcmVzb2x2ZXIudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2NvcmUvc3RyYXRlZ2llcy9pZHAudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2NvcmUvc3RyYXRlZ2llcy9hYnN0cmFjdF9wb3B1cF9yZWRpcmVjdF9vcGVyYXRpb24udHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL3BsYXRmb3JtX2Jyb3dzZXIvc3RyYXRlZ2llcy9wb3B1cC50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvY29yZS9zdHJhdGVnaWVzL3JlZGlyZWN0LnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9wbGF0Zm9ybV9icm93c2VyL3N0cmF0ZWdpZXMvcmVkaXJlY3QudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2NvcmUvYXV0aC9hdXRoX2V2ZW50X21hbmFnZXIudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2FwaS9wcm9qZWN0X2NvbmZpZy9nZXRfcHJvamVjdF9jb25maWcudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2NvcmUvdXRpbC92YWxpZGF0ZV9vcmlnaW4udHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL3BsYXRmb3JtX2Jyb3dzZXIvaWZyYW1lL2dhcGkudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL3BsYXRmb3JtX2Jyb3dzZXIvaWZyYW1lL2lmcmFtZS50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvcGxhdGZvcm1fYnJvd3Nlci91dGlsL3BvcHVwLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9jb3JlL3V0aWwvaGFuZGxlci50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvcGxhdGZvcm1fYnJvd3Nlci9wb3B1cF9yZWRpcmVjdC50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvbWZhL21mYV9hc3NlcnRpb24udHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL3BsYXRmb3JtX2Jyb3dzZXIvbWZhL2Fzc2VydGlvbnMvcGhvbmUudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL21mYS9hc3NlcnRpb25zL3RvdHAudHMiLCIuLi9ub2RlX21vZHVsZXMvQGZpcmViYXNlL2F1dGgvc3JjL2NvcmUvYXV0aC9maXJlYmFzZV9pbnRlcm5hbC50cyIsIi4uL25vZGVfbW9kdWxlcy9AZmlyZWJhc2UvYXV0aC9zcmMvY29yZS9hdXRoL3JlZ2lzdGVyLnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL3NyYy9wbGF0Zm9ybV9icm93c2VyL2luZGV4LnRzIiwiLi4vbm9kZV9tb2R1bGVzL0BmaXJlYmFzZS9hdXRoL2Rpc3QvZXNtMjAxNy9pbmRleC5qcyJdLCJuYW1lcyI6WyJhdXRoXzFfNV8xX2V4cG9ydHMiLCJfX2V4cG9ydCIsIkFjdGlvbkNvZGVPcGVyYXRpb24iLCJBY3Rpb25Db2RlVVJMIiwiQXV0aENyZWRlbnRpYWwiLCJBdXRoRXJyb3JDb2RlcyIsIkFVVEhfRVJST1JfQ09ERVNfTUFQX0RPX05PVF9VU0VfSU5URVJOQUxMWSIsIkVtYWlsQXV0aENyZWRlbnRpYWwiLCJFbWFpbEF1dGhQcm92aWRlciIsIkZhY2Vib29rQXV0aFByb3ZpZGVyIiwiRmFjdG9ySWQiLCJHaXRodWJBdXRoUHJvdmlkZXIiLCJHb29nbGVBdXRoUHJvdmlkZXIiLCJPQXV0aENyZWRlbnRpYWwiLCJPQXV0aFByb3ZpZGVyIiwiT3BlcmF0aW9uVHlwZSIsIlBob25lQXV0aENyZWRlbnRpYWwiLCJQaG9uZUF1dGhQcm92aWRlciIsIlBob25lTXVsdGlGYWN0b3JHZW5lcmF0b3IiLCJQcm92aWRlcklkIiwiUmVjYXB0Y2hhVmVyaWZpZXIiLCJTQU1MQXV0aFByb3ZpZGVyIiwiU2lnbkluTWV0aG9kIiwiVG90cE11bHRpRmFjdG9yR2VuZXJhdG9yIiwiVG90cFNlY3JldCIsIlR3aXR0ZXJBdXRoUHJvdmlkZXIiLCJhcHBseUFjdGlvbkNvZGUiLCJiZWZvcmVBdXRoU3RhdGVDaGFuZ2VkIiwiYnJvd3NlckxvY2FsUGVyc2lzdGVuY2UiLCJicm93c2VyUG9wdXBSZWRpcmVjdFJlc29sdmVyIiwiYnJvd3NlclNlc3Npb25QZXJzaXN0ZW5jZSIsImNoZWNrQWN0aW9uQ29kZSIsImNvbmZpcm1QYXNzd29yZFJlc2V0IiwiY29ubmVjdEF1dGhFbXVsYXRvciIsImNyZWF0ZVVzZXJXaXRoRW1haWxBbmRQYXNzd29yZCIsImRlYnVnRXJyb3JNYXAiLCJkZWxldGVVc2VyIiwiZmV0Y2hTaWduSW5NZXRob2RzRm9yRW1haWwiLCJnZXRBZGRpdGlvbmFsVXNlckluZm8iLCJnZXRBdXRoIiwiZ2V0SWRUb2tlbiIsImdldElkVG9rZW5SZXN1bHQiLCJnZXRNdWx0aUZhY3RvclJlc29sdmVyIiwiZ2V0UmVkaXJlY3RSZXN1bHQiLCJpbk1lbW9yeVBlcnNpc3RlbmNlIiwiaW5kZXhlZERCTG9jYWxQZXJzaXN0ZW5jZSIsImluaXRpYWxpemVBdXRoIiwiaW5pdGlhbGl6ZVJlY2FwdGNoYUNvbmZpZyIsImlzU2lnbkluV2l0aEVtYWlsTGluayIsImxpbmtXaXRoQ3JlZGVudGlhbCIsImxpbmtXaXRoUGhvbmVOdW1iZXIiLCJsaW5rV2l0aFBvcHVwIiwibGlua1dpdGhSZWRpcmVjdCIsIm11bHRpRmFjdG9yIiwib25BdXRoU3RhdGVDaGFuZ2VkIiwib25JZFRva2VuQ2hhbmdlZCIsInBhcnNlQWN0aW9uQ29kZVVSTCIsInByb2RFcnJvck1hcCIsInJlYXV0aGVudGljYXRlV2l0aENyZWRlbnRpYWwiLCJyZWF1dGhlbnRpY2F0ZVdpdGhQaG9uZU51bWJlciIsInJlYXV0aGVudGljYXRlV2l0aFBvcHVwIiwicmVhdXRoZW50aWNhdGVXaXRoUmVkaXJlY3QiLCJyZWxvYWQiLCJyZXZva2VBY2Nlc3NUb2tlbiIsInNlbmRFbWFpbFZlcmlmaWNhdGlvbiIsInNlbmRQYXNzd29yZFJlc2V0RW1haWwiLCJzZW5kU2lnbkluTGlua1RvRW1haWwiLCJzZXRQZXJzaXN0ZW5jZSIsInNpZ25JbkFub255bW91c2x5Iiwic2lnbkluV2l0aENyZWRlbnRpYWwiLCJzaWduSW5XaXRoQ3VzdG9tVG9rZW4iLCJzaWduSW5XaXRoRW1haWxBbmRQYXNzd29yZCIsInNpZ25JbldpdGhFbWFpbExpbmsiLCJzaWduSW5XaXRoUGhvbmVOdW1iZXIiLCJzaWduSW5XaXRoUG9wdXAiLCJzaWduSW5XaXRoUmVkaXJlY3QiLCJzaWduT3V0IiwidW5saW5rIiwidXBkYXRlQ3VycmVudFVzZXIiLCJ1cGRhdGVFbWFpbCIsInVwZGF0ZVBhc3N3b3JkIiwidXBkYXRlUGhvbmVOdW1iZXIiLCJ1cGRhdGVQcm9maWxlIiwidXNlRGV2aWNlTGFuZ3VhZ2UiLCJ2YWxpZGF0ZVBhc3N3b3JkIiwidmVyaWZ5QmVmb3JlVXBkYXRlRW1haWwiLCJ2ZXJpZnlQYXNzd29yZFJlc2V0Q29kZSIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJQSE9ORSIsIlRPVFAiLCJGQUNFQk9PSyIsIkdJVEhVQiIsIkdPT0dMRSIsIlBBU1NXT1JEIiwiVFdJVFRFUiIsIkVNQUlMX0xJTksiLCJFTUFJTF9QQVNTV09SRCIsIkxJTksiLCJSRUFVVEhFTlRJQ0FURSIsIlNJR05fSU4iLCJFTUFJTF9TSUdOSU4iLCJQQVNTV09SRF9SRVNFVCIsIlJFQ09WRVJfRU1BSUwiLCJSRVZFUlRfU0VDT05EX0ZBQ1RPUl9BRERJVElPTiIsIlZFUklGWV9BTkRfQ0hBTkdFX0VNQUlMIiwiVkVSSUZZX0VNQUlMIiwiX2RlYnVnRXJyb3JNYXAiLCJfcHJvZEVycm9yTWFwIiwiX0RFRkFVTFRfQVVUSF9FUlJPUl9GQUNUT1JZIiwiaW1wb3J0X3V0aWwiLCJFcnJvckZhY3RvcnkiLCJBRE1JTl9PTkxZX09QRVJBVElPTiIsIkFSR1VNRU5UX0VSUk9SIiwiQVBQX05PVF9BVVRIT1JJWkVEIiwiQVBQX05PVF9JTlNUQUxMRUQiLCJDQVBUQ0hBX0NIRUNLX0ZBSUxFRCIsIkNPREVfRVhQSVJFRCIsIkNPUkRPVkFfTk9UX1JFQURZIiwiQ09SU19VTlNVUFBPUlRFRCIsIkNSRURFTlRJQUxfQUxSRUFEWV9JTl9VU0UiLCJDUkVERU5USUFMX01JU01BVENIIiwiQ1JFREVOVElBTF9UT09fT0xEX0xPR0lOX0FHQUlOIiwiREVQRU5ERU5UX1NES19JTklUX0JFRk9SRV9BVVRIIiwiRFlOQU1JQ19MSU5LX05PVF9BQ1RJVkFURUQiLCJFTUFJTF9DSEFOR0VfTkVFRFNfVkVSSUZJQ0FUSU9OIiwiRU1BSUxfRVhJU1RTIiwiRU1VTEFUT1JfQ09ORklHX0ZBSUxFRCIsIkVYUElSRURfT09CX0NPREUiLCJFWFBJUkVEX1BPUFVQX1JFUVVFU1QiLCJJTlRFUk5BTF9FUlJPUiIsIklOVkFMSURfQVBJX0tFWSIsIklOVkFMSURfQVBQX0NSRURFTlRJQUwiLCJJTlZBTElEX0FQUF9JRCIsIklOVkFMSURfQVVUSCIsIklOVkFMSURfQVVUSF9FVkVOVCIsIklOVkFMSURfQ0VSVF9IQVNIIiwiSU5WQUxJRF9DT0RFIiwiSU5WQUxJRF9DT05USU5VRV9VUkkiLCJJTlZBTElEX0NPUkRPVkFfQ09ORklHVVJBVElPTiIsIklOVkFMSURfQ1VTVE9NX1RPS0VOIiwiSU5WQUxJRF9EWU5BTUlDX0xJTktfRE9NQUlOIiwiSU5WQUxJRF9FTUFJTCIsIklOVkFMSURfRU1VTEFUT1JfU0NIRU1FIiwiSU5WQUxJRF9JRFBfUkVTUE9OU0UiLCJJTlZBTElEX0xPR0lOX0NSRURFTlRJQUxTIiwiSU5WQUxJRF9NRVNTQUdFX1BBWUxPQUQiLCJJTlZBTElEX01GQV9TRVNTSU9OIiwiSU5WQUxJRF9PQVVUSF9DTElFTlRfSUQiLCJJTlZBTElEX09BVVRIX1BST1ZJREVSIiwiSU5WQUxJRF9PT0JfQ09ERSIsIklOVkFMSURfT1JJR0lOIiwiSU5WQUxJRF9QQVNTV09SRCIsIklOVkFMSURfUEVSU0lTVEVOQ0UiLCJJTlZBTElEX1BIT05FX05VTUJFUiIsIklOVkFMSURfUFJPVklERVJfSUQiLCJJTlZBTElEX1JFQ0lQSUVOVF9FTUFJTCIsIklOVkFMSURfU0VOREVSIiwiSU5WQUxJRF9TRVNTSU9OX0lORk8iLCJJTlZBTElEX1RFTkFOVF9JRCIsIk1GQV9JTkZPX05PVF9GT1VORCIsIk1GQV9SRVFVSVJFRCIsIk1JU1NJTkdfQU5EUk9JRF9QQUNLQUdFX05BTUUiLCJNSVNTSU5HX0FQUF9DUkVERU5USUFMIiwiTUlTU0lOR19BVVRIX0RPTUFJTiIsIk1JU1NJTkdfQ09ERSIsIk1JU1NJTkdfQ09OVElOVUVfVVJJIiwiTUlTU0lOR19JRlJBTUVfU1RBUlQiLCJNSVNTSU5HX0lPU19CVU5ETEVfSUQiLCJNSVNTSU5HX09SX0lOVkFMSURfTk9OQ0UiLCJNSVNTSU5HX01GQV9JTkZPIiwiTUlTU0lOR19NRkFfU0VTU0lPTiIsIk1JU1NJTkdfUEhPTkVfTlVNQkVSIiwiTUlTU0lOR19TRVNTSU9OX0lORk8iLCJNT0RVTEVfREVTVFJPWUVEIiwiTkVFRF9DT05GSVJNQVRJT04iLCJORVRXT1JLX1JFUVVFU1RfRkFJTEVEIiwiTlVMTF9VU0VSIiwiTk9fQVVUSF9FVkVOVCIsIk5PX1NVQ0hfUFJPVklERVIiLCJPUEVSQVRJT05fTk9UX0FMTE9XRUQiLCJPUEVSQVRJT05fTk9UX1NVUFBPUlRFRCIsIlBPUFVQX0JMT0NLRUQiLCJQT1BVUF9DTE9TRURfQllfVVNFUiIsIlBST1ZJREVSX0FMUkVBRFlfTElOS0VEIiwiUVVPVEFfRVhDRUVERUQiLCJSRURJUkVDVF9DQU5DRUxMRURfQllfVVNFUiIsIlJFRElSRUNUX09QRVJBVElPTl9QRU5ESU5HIiwiUkVKRUNURURfQ1JFREVOVElBTCIsIlNFQ09ORF9GQUNUT1JfQUxSRUFEWV9FTlJPTExFRCIsIlNFQ09ORF9GQUNUT1JfTElNSVRfRVhDRUVERUQiLCJURU5BTlRfSURfTUlTTUFUQ0giLCJUSU1FT1VUIiwiVE9LRU5fRVhQSVJFRCIsIlRPT19NQU5ZX0FUVEVNUFRTX1RSWV9MQVRFUiIsIlVOQVVUSE9SSVpFRF9ET01BSU4iLCJVTlNVUFBPUlRFRF9GSVJTVF9GQUNUT1IiLCJVTlNVUFBPUlRFRF9QRVJTSVNURU5DRSIsIlVOU1VQUE9SVEVEX1RFTkFOVF9PUEVSQVRJT04iLCJVTlZFUklGSUVEX0VNQUlMIiwiVVNFUl9DQU5DRUxMRUQiLCJVU0VSX0RFTEVURUQiLCJVU0VSX0RJU0FCTEVEIiwiVVNFUl9NSVNNQVRDSCIsIlVTRVJfU0lHTkVEX09VVCIsIldFQUtfUEFTU1dPUkQiLCJXRUJfU1RPUkFHRV9VTlNVUFBPUlRFRCIsIkFMUkVBRFlfSU5JVElBTElaRUQiLCJSRUNBUFRDSEFfTk9UX0VOQUJMRUQiLCJNSVNTSU5HX1JFQ0FQVENIQV9UT0tFTiIsIklOVkFMSURfUkVDQVBUQ0hBX1RPS0VOIiwiSU5WQUxJRF9SRUNBUFRDSEFfQUNUSU9OIiwiTUlTU0lOR19DTElFTlRfVFlQRSIsIk1JU1NJTkdfUkVDQVBUQ0hBX1ZFUlNJT04iLCJJTlZBTElEX1JFQ0FQVENIQV9WRVJTSU9OIiwiSU5WQUxJRF9SRVFfVFlQRSIsImxvZ0NsaWVudCIsImltcG9ydF9sb2dnZXIiLCJMb2dnZXIiLCJfbG9nV2FybiIsIm1zZyIsImFyZ3MiLCJsb2dMZXZlbCIsIkxvZ0xldmVsIiwiV0FSTiIsIndhcm4iLCJpbXBvcnRfYXBwIiwiU0RLX1ZFUlNJT04iLCJfbG9nRXJyb3IiLCJFUlJPUiIsImVycm9yIiwiX2ZhaWwiLCJhdXRoT3JDb2RlIiwicmVzdCIsImNyZWF0ZUVycm9ySW50ZXJuYWwiLCJfY3JlYXRlRXJyb3IiLCJfZXJyb3JXaXRoQ3VzdG9tTWVzc2FnZSIsImF1dGgiLCJjb2RlIiwibWVzc2FnZSIsImVycm9yTWFwIiwiT2JqZWN0IiwiYXNzaWduIiwiZmFjdG9yeSIsImNyZWF0ZSIsImFwcE5hbWUiLCJuYW1lIiwiX2Fzc2VydEluc3RhbmNlT2YiLCJvYmplY3QiLCJpbnN0YW5jZSIsImNvbnN0cnVjdG9ySW5zdGFuY2UiLCJjb25zdHJ1Y3RvciIsImZ1bGxQYXJhbXMiLCJzbGljZSIsIl9lcnJvckZhY3RvcnkiLCJfYXNzZXJ0IiwiYXNzZXJ0aW9uIiwiZGVidWdGYWlsIiwiZmFpbHVyZSIsIkVycm9yIiwiZGVidWdBc3NlcnQiLCJfZ2V0Q3VycmVudFVybCIsInNlbGYiLCJfYSIsImxvY2F0aW9uIiwiaHJlZiIsIl9pc0h0dHBPckh0dHBzIiwiX2dldEN1cnJlbnRTY2hlbWUiLCJwcm90b2NvbCIsIl9pc09ubGluZSIsIm5hdmlnYXRvciIsIm9uTGluZSIsImlzQnJvd3NlckV4dGVuc2lvbiIsIl9nZXRVc2VyTGFuZ3VhZ2UiLCJuYXZpZ2F0b3JMYW5ndWFnZSIsImxhbmd1YWdlcyIsImxhbmd1YWdlIiwiRGVsYXkiLCJzaG9ydERlbGF5IiwibG9uZ0RlbGF5IiwiaXNNb2JpbGUiLCJpc01vYmlsZUNvcmRvdmEiLCJpc1JlYWN0TmF0aXZlIiwiZ2V0IiwiTWF0aCIsIm1pbiIsIl9lbXVsYXRvclVybCIsImNvbmZpZyIsInBhdGgiLCJlbXVsYXRvciIsInVybCIsInN0YXJ0c1dpdGgiLCJGZXRjaFByb3ZpZGVyIiwiaW5pdGlhbGl6ZSIsImZldGNoSW1wbCIsImhlYWRlcnNJbXBsIiwicmVzcG9uc2VJbXBsIiwiZmV0Y2giLCJnbG9iYWxUaGlzIiwiaGVhZGVycyIsIkhlYWRlcnMiLCJyZXNwb25zZSIsIlJlc3BvbnNlIiwiU0VSVkVSX0VSUk9SX01BUCIsIkRFRkFVTFRfQVBJX1RJTUVPVVRfTVMiLCJfYWRkVGlkSWZOZWNlc3NhcnkiLCJyZXF1ZXN0IiwidGVuYW50SWQiLCJfcGVyZm9ybUFwaVJlcXVlc3QiLCJtZXRob2QiLCJjdXN0b21FcnJvck1hcCIsIl9wZXJmb3JtRmV0Y2hXaXRoRXJyb3JIYW5kbGluZyIsImJvZHkiLCJwYXJhbXMiLCJKU09OIiwic3RyaW5naWZ5IiwicXVlcnkiLCJxdWVyeXN0cmluZyIsImtleSIsImFwaUtleSIsIl9nZXRBZGRpdGlvbmFsSGVhZGVycyIsImxhbmd1YWdlQ29kZSIsIl9nZXRGaW5hbFRhcmdldCIsImFwaUhvc3QiLCJyZWZlcnJlclBvbGljeSIsImZldGNoRm4iLCJfY2FuSW5pdEVtdWxhdG9yIiwibmV0d29ya1RpbWVvdXQiLCJOZXR3b3JrVGltZW91dCIsIlByb21pc2UiLCJyYWNlIiwicHJvbWlzZSIsImNsZWFyTmV0d29ya1RpbWVvdXQiLCJqc29uIiwiX21ha2VUYWdnZWRFcnJvciIsIm9rIiwiZXJyb3JNZXNzYWdlIiwic2VydmVyRXJyb3JDb2RlIiwic2VydmVyRXJyb3JNZXNzYWdlIiwic3BsaXQiLCJhdXRoRXJyb3IiLCJ0b0xvd2VyQ2FzZSIsInJlcGxhY2UiLCJlIiwiRmlyZWJhc2VFcnJvciIsIlN0cmluZyIsIl9wZXJmb3JtU2lnbkluUmVxdWVzdCIsInNlcnZlclJlc3BvbnNlIiwiX3NlcnZlclJlc3BvbnNlIiwiaG9zdCIsImJhc2UiLCJhcGlTY2hlbWUiLCJfcGFyc2VFbmZvcmNlbWVudFN0YXRlIiwiZW5mb3JjZW1lbnRTdGF0ZVN0ciIsInRpbWVyIiwiXyIsInJlamVjdCIsInNldFRpbWVvdXQiLCJjbGVhclRpbWVvdXQiLCJlcnJvclBhcmFtcyIsImVtYWlsIiwicGhvbmVOdW1iZXIiLCJjdXN0b21EYXRhIiwiX3Rva2VuUmVzcG9uc2UiLCJpc1YyIiwiZ3JlY2FwdGNoYSIsImdldFJlc3BvbnNlIiwiaXNFbnRlcnByaXNlIiwiZW50ZXJwcmlzZSIsIlJlY2FwdGNoYUNvbmZpZyIsInNpdGVLZXkiLCJyZWNhcHRjaGFFbmZvcmNlbWVudFN0YXRlIiwicmVjYXB0Y2hhS2V5IiwiZ2V0UHJvdmlkZXJFbmZvcmNlbWVudFN0YXRlIiwicHJvdmlkZXJTdHIiLCJsZW5ndGgiLCJwcm92aWRlciIsImVuZm9yY2VtZW50U3RhdGUiLCJpc1Byb3ZpZGVyRW5hYmxlZCIsImdldFJlY2FwdGNoYVBhcmFtcyIsInJlY2FwdGNoYVNpdGVLZXkiLCJnZXRSZWNhcHRjaGFDb25maWciLCJkZWxldGVBY2NvdW50IiwiZGVsZXRlTGlua2VkQWNjb3VudHMiLCJnZXRBY2NvdW50SW5mbyIsInV0Y1RpbWVzdGFtcFRvRGF0ZVN0cmluZyIsInV0Y1RpbWVzdGFtcCIsImRhdGUiLCJEYXRlIiwiTnVtYmVyIiwiaXNOYU4iLCJnZXRUaW1lIiwidG9VVENTdHJpbmciLCJ1c2VyIiwiZm9yY2VSZWZyZXNoIiwiZ2V0TW9kdWxhckluc3RhbmNlIiwidXNlckludGVybmFsIiwidG9rZW4iLCJjbGFpbXMiLCJfcGFyc2VUb2tlbiIsImV4cCIsImF1dGhfdGltZSIsImlhdCIsImZpcmViYXNlIiwic2lnbkluUHJvdmlkZXIiLCJhdXRoVGltZSIsInNlY29uZHNTdHJpbmdUb01pbGxpc2Vjb25kcyIsImlzc3VlZEF0VGltZSIsImV4cGlyYXRpb25UaW1lIiwic2lnbkluU2Vjb25kRmFjdG9yIiwic2Vjb25kcyIsImFsZ29yaXRobSIsInBheWxvYWQiLCJzaWduYXR1cmUiLCJkZWNvZGVkIiwiYmFzZTY0RGVjb2RlIiwicGFyc2UiLCJ0b1N0cmluZyIsIl90b2tlbkV4cGlyZXNJbiIsInBhcnNlZFRva2VuIiwiX2xvZ291dElmSW52YWxpZGF0ZWQiLCJieXBhc3NBdXRoU3RhdGUiLCJpc1VzZXJJbnZhbGlkYXRlZCIsImN1cnJlbnRVc2VyIiwiUHJvYWN0aXZlUmVmcmVzaCIsImlzUnVubmluZyIsInRpbWVySWQiLCJlcnJvckJhY2tvZmYiLCJfc3RhcnQiLCJzY2hlZHVsZSIsIl9zdG9wIiwiZ2V0SW50ZXJ2YWwiLCJ3YXNFcnJvciIsImludGVydmFsIiwiZXhwVGltZSIsInN0c1Rva2VuTWFuYWdlciIsIm5vdyIsIm1heCIsIml0ZXJhdGlvbiIsIlVzZXJNZXRhZGF0YSIsImNyZWF0ZWRBdCIsImxhc3RMb2dpbkF0IiwiX2luaXRpYWxpemVUaW1lIiwibGFzdFNpZ25JblRpbWUiLCJjcmVhdGlvblRpbWUiLCJfY29weSIsIm1ldGFkYXRhIiwidG9KU09OIiwiX3JlbG9hZFdpdGhvdXRTYXZpbmciLCJpZFRva2VuIiwidXNlcnMiLCJjb3JlQWNjb3VudCIsIl9ub3RpZnlSZWxvYWRMaXN0ZW5lciIsIm5ld1Byb3ZpZGVyRGF0YSIsInByb3ZpZGVyVXNlckluZm8iLCJleHRyYWN0UHJvdmlkZXJEYXRhIiwicHJvdmlkZXJEYXRhIiwibWVyZ2VQcm92aWRlckRhdGEiLCJvbGRJc0Fub255bW91cyIsImlzQW5vbnltb3VzIiwibmV3SXNBbm9ueW1vdXMiLCJwYXNzd29yZEhhc2giLCJ1cGRhdGVzIiwidWlkIiwibG9jYWxJZCIsImRpc3BsYXlOYW1lIiwicGhvdG9VUkwiLCJwaG90b1VybCIsImVtYWlsVmVyaWZpZWQiLCJfcGVyc2lzdFVzZXJJZkN1cnJlbnQiLCJfbm90aWZ5TGlzdGVuZXJzSWZDdXJyZW50Iiwib3JpZ2luYWwiLCJuZXdEYXRhIiwiZGVkdXBlZCIsImZpbHRlciIsIm8iLCJzb21lIiwibiIsInByb3ZpZGVySWQiLCJwcm92aWRlcnMiLCJtYXAiLCJpbXBvcnRfdHNsaWIiLCJfX3Jlc3QiLCJyYXdJZCIsInJlcXVlc3RTdHNUb2tlbiIsInJlZnJlc2hUb2tlbiIsInRva2VuQXBpSG9zdCIsImFjY2Vzc1Rva2VuIiwiYWNjZXNzX3Rva2VuIiwiZXhwaXJlc0luIiwiZXhwaXJlc19pbiIsInJlZnJlc2hfdG9rZW4iLCJyZXZva2VUb2tlbiIsIlN0c1Rva2VuTWFuYWdlciIsImlzRXhwaXJlZCIsInVwZGF0ZUZyb21TZXJ2ZXJSZXNwb25zZSIsInVwZGF0ZVRva2Vuc0FuZEV4cGlyYXRpb24iLCJnZXRUb2tlbiIsInJlZnJlc2giLCJjbGVhclJlZnJlc2hUb2tlbiIsIm9sZFRva2VuIiwiZXhwaXJlc0luU2VjIiwiZnJvbUpTT04iLCJtYW5hZ2VyIiwiX2Fzc2lnbiIsIl9jbG9uZSIsIl9wZXJmb3JtUmVmcmVzaCIsImFzc2VydFN0cmluZ09yVW5kZWZpbmVkIiwiVXNlckltcGwiLCJvcHQiLCJwcm9hY3RpdmVSZWZyZXNoIiwicmVsb2FkVXNlckluZm8iLCJyZWxvYWRMaXN0ZW5lciIsInVzZXJJbmZvIiwibmV3VXNlciIsIl9vblJlbG9hZCIsImNhbGxiYWNrIiwiX3N0YXJ0UHJvYWN0aXZlUmVmcmVzaCIsIl9zdG9wUHJvYWN0aXZlUmVmcmVzaCIsIl91cGRhdGVUb2tlbnNJZk5lY2Vzc2FyeSIsInJlbG9hZDIiLCJ0b2tlbnNSZWZyZXNoZWQiLCJkZWxldGUiLCJfcmVkaXJlY3RFdmVudElkIiwiX2Zyb21KU09OIiwiX2IiLCJfYyIsIl9kIiwiX2UiLCJfZiIsIl9nIiwiX2giLCJwbGFpbk9iamVjdFRva2VuTWFuYWdlciIsIkFycmF5IiwiaXNBcnJheSIsIl9mcm9tSWRUb2tlblJlc3BvbnNlIiwiaWRUb2tlblJlc3BvbnNlIiwiaW5zdGFuY2VDYWNoZSIsIk1hcCIsIl9nZXRJbnN0YW5jZSIsImNscyIsIkZ1bmN0aW9uIiwic2V0IiwiSW5NZW1vcnlQZXJzaXN0ZW5jZSIsInR5cGUiLCJzdG9yYWdlIiwiX2lzQXZhaWxhYmxlIiwiX3NldCIsInZhbHVlIiwiX2dldCIsIl9yZW1vdmUiLCJfYWRkTGlzdGVuZXIiLCJfa2V5IiwiX2xpc3RlbmVyIiwiX3JlbW92ZUxpc3RlbmVyIiwiX3BlcnNpc3RlbmNlS2V5TmFtZSIsIlBlcnNpc3RlbmNlVXNlck1hbmFnZXIiLCJwZXJzaXN0ZW5jZSIsInVzZXJLZXkiLCJuYW1lMiIsImZ1bGxVc2VyS2V5IiwiZnVsbFBlcnNpc3RlbmNlS2V5IiwiYm91bmRFdmVudEhhbmRsZXIiLCJfb25TdG9yYWdlRXZlbnQiLCJiaW5kIiwic2V0Q3VycmVudFVzZXIiLCJnZXRDdXJyZW50VXNlciIsImJsb2IiLCJyZW1vdmVDdXJyZW50VXNlciIsInNhdmVQZXJzaXN0ZW5jZUZvclJlZGlyZWN0IiwibmV3UGVyc2lzdGVuY2UiLCJwZXJzaXN0ZW5jZUhpZXJhcmNoeSIsImF2YWlsYWJsZVBlcnNpc3RlbmNlcyIsImFsbCIsInNlbGVjdGVkUGVyc2lzdGVuY2UiLCJ1c2VyVG9NaWdyYXRlIiwibWlncmF0aW9uSGllcmFyY2h5IiwicCIsIl9zaG91bGRBbGxvd01pZ3JhdGlvbiIsIl9nZXRCcm93c2VyTmFtZSIsInVzZXJBZ2VudCIsInVhIiwiaW5jbHVkZXMiLCJfaXNJRU1vYmlsZSIsIl9pc0ZpcmVmb3giLCJfaXNCbGFja0JlcnJ5IiwiX2lzV2ViT1MiLCJfaXNTYWZhcmkiLCJfaXNDaHJvbWVJT1MiLCJfaXNBbmRyb2lkIiwicmUiLCJtYXRjaGVzIiwibWF0Y2giLCJnZXRVQSIsInRlc3QiLCJfaXNJT1MiLCJfaXNJT1M3T3I4IiwiX2lzSU9TU3RhbmRhbG9uZSIsIndpbmRvdyIsInN0YW5kYWxvbmUiLCJfaXNJRTEwIiwiaXNJRSIsImRvY3VtZW50IiwiZG9jdW1lbnRNb2RlIiwiX2lzTW9iaWxlQnJvd3NlciIsIl9pc0lmcmFtZSIsInRvcCIsIl9nZXRDbGllbnRWZXJzaW9uIiwiY2xpZW50UGxhdGZvcm0iLCJmcmFtZXdvcmtzIiwicmVwb3J0ZWRQbGF0Zm9ybSIsInJlcG9ydGVkRnJhbWV3b3JrcyIsImpvaW4iLCJBdXRoTWlkZGxld2FyZVF1ZXVlIiwicXVldWUiLCJwdXNoQ2FsbGJhY2siLCJvbkFib3J0Iiwid3JhcHBlZENhbGxiYWNrIiwicmVzb2x2ZSIsInJlc3VsdCIsInB1c2giLCJpbmRleCIsInJ1bk1pZGRsZXdhcmUiLCJuZXh0VXNlciIsIm9uQWJvcnRTdGFjayIsImJlZm9yZVN0YXRlQ2FsbGJhY2siLCJyZXZlcnNlIiwib3JpZ2luYWxNZXNzYWdlIiwiX2dldFBhc3N3b3JkUG9saWN5IiwiTUlOSU1VTV9NSU5fUEFTU1dPUkRfTEVOR1RIIiwiUGFzc3dvcmRQb2xpY3lJbXBsIiwicmVzcG9uc2VPcHRpb25zIiwiY3VzdG9tU3RyZW5ndGhPcHRpb25zIiwibWluUGFzc3dvcmRMZW5ndGgiLCJtYXhQYXNzd29yZExlbmd0aCIsImNvbnRhaW5zTG93ZXJjYXNlQ2hhcmFjdGVyIiwiY29udGFpbnNMb3dlcmNhc2VMZXR0ZXIiLCJjb250YWluc1VwcGVyY2FzZUNoYXJhY3RlciIsImNvbnRhaW5zVXBwZXJjYXNlTGV0dGVyIiwiY29udGFpbnNOdW1lcmljQ2hhcmFjdGVyIiwiY29udGFpbnNOb25BbHBoYW51bWVyaWNDaGFyYWN0ZXIiLCJhbGxvd2VkTm9uQWxwaGFudW1lcmljQ2hhcmFjdGVycyIsImZvcmNlVXBncmFkZU9uU2lnbmluIiwic2NoZW1hVmVyc2lvbiIsInBhc3N3b3JkIiwic3RhdHVzIiwiaXNWYWxpZCIsInBhc3N3b3JkUG9saWN5IiwidmFsaWRhdGVQYXNzd29yZExlbmd0aE9wdGlvbnMiLCJ2YWxpZGF0ZVBhc3N3b3JkQ2hhcmFjdGVyT3B0aW9ucyIsIm1lZXRzTWluUGFzc3dvcmRMZW5ndGgiLCJtZWV0c01heFBhc3N3b3JkTGVuZ3RoIiwidXBkYXRlUGFzc3dvcmRDaGFyYWN0ZXJPcHRpb25zU3RhdHVzZXMiLCJwYXNzd29yZENoYXIiLCJpIiwiY2hhckF0IiwiQXV0aEltcGwiLCJhcHAiLCJoZWFydGJlYXRTZXJ2aWNlUHJvdmlkZXIiLCJhcHBDaGVja1NlcnZpY2VQcm92aWRlciIsImVtdWxhdG9yQ29uZmlnIiwib3BlcmF0aW9ucyIsImF1dGhTdGF0ZVN1YnNjcmlwdGlvbiIsIlN1YnNjcmlwdGlvbiIsImlkVG9rZW5TdWJzY3JpcHRpb24iLCJiZWZvcmVTdGF0ZVF1ZXVlIiwicmVkaXJlY3RVc2VyIiwiaXNQcm9hY3RpdmVSZWZyZXNoRW5hYmxlZCIsIkVYUEVDVEVEX1BBU1NXT1JEX1BPTElDWV9TQ0hFTUFfVkVSU0lPTiIsIl9pc0luaXRpYWxpemVkIiwiX2RlbGV0ZWQiLCJfaW5pdGlhbGl6YXRpb25Qcm9taXNlIiwiX3BvcHVwUmVkaXJlY3RSZXNvbHZlciIsIl9hZ2VudFJlY2FwdGNoYUNvbmZpZyIsIl90ZW5hbnRSZWNhcHRjaGFDb25maWdzIiwiX3Byb2plY3RQYXNzd29yZFBvbGljeSIsIl90ZW5hbnRQYXNzd29yZFBvbGljaWVzIiwibGFzdE5vdGlmaWVkVWlkIiwic2V0dGluZ3MiLCJhcHBWZXJpZmljYXRpb25EaXNhYmxlZEZvclRlc3RpbmciLCJjbGllbnRWZXJzaW9uIiwic2RrQ2xpZW50VmVyc2lvbiIsIl9pbml0aWFsaXplV2l0aFBlcnNpc3RlbmNlIiwicG9wdXBSZWRpcmVjdFJlc29sdmVyIiwicGVyc2lzdGVuY2VNYW5hZ2VyIiwiX3Nob3VsZEluaXRQcm9hY3RpdmVseSIsIl9pbml0aWFsaXplIiwiaW5pdGlhbGl6ZUN1cnJlbnRVc2VyIiwiYXNzZXJ0ZWRQZXJzaXN0ZW5jZSIsIl9jdXJyZW50VXNlciIsIl91cGRhdGVDdXJyZW50VXNlciIsInByZXZpb3VzbHlTdG9yZWRVc2VyIiwiZnV0dXJlQ3VycmVudFVzZXIiLCJuZWVkc1RvY2hlY2tNaWRkbGV3YXJlIiwiYXV0aERvbWFpbiIsImdldE9ySW5pdFJlZGlyZWN0UGVyc2lzdGVuY2VNYW5hZ2VyIiwicmVkaXJlY3RVc2VyRXZlbnRJZCIsInN0b3JlZFVzZXJFdmVudElkIiwidHJ5UmVkaXJlY3RTaWduSW4iLCJkaXJlY3RseVNldEN1cnJlbnRVc2VyIiwiX292ZXJyaWRlUmVkaXJlY3RSZXN1bHQiLCJyZWxvYWRBbmRTZXRDdXJyZW50VXNlck9yQ2xlYXIiLCJyZWRpcmVjdFJlc29sdmVyIiwiX2NvbXBsZXRlUmVkaXJlY3RGbiIsIl9zZXRSZWRpcmVjdFVzZXIiLCJfZGVsZXRlIiwidXNlckV4dGVybiIsInNraXBCZWZvcmVTdGF0ZUNhbGxiYWNrcyIsIm5vdGlmeUF1dGhMaXN0ZW5lcnMiLCJyZWRpcmVjdFBlcnNpc3RlbmNlTWFuYWdlciIsIl9nZXRSZWNhcHRjaGFDb25maWciLCJfZ2V0UGFzc3dvcmRQb2xpY3lJbnRlcm5hbCIsIl91cGRhdGVQYXNzd29yZFBvbGljeSIsIl9nZXRQZXJzaXN0ZW5jZSIsIl91cGRhdGVFcnJvck1hcCIsIm5leHRPck9ic2VydmVyIiwiY29tcGxldGVkIiwicmVnaXN0ZXJTdGF0ZUxpc3RlbmVyIiwiYXV0aFN0YXRlUmVhZHkiLCJ1bnN1YnNjcmliZSIsInRva2VuVHlwZSIsInJlZGlyZWN0TWFuYWdlciIsInJlc29sdmVyIiwiX3JlZGlyZWN0UGVyc2lzdGVuY2UiLCJfcmVkaXJlY3RVc2VyRm9ySWQiLCJpZCIsIm5leHQiLCJjdXJyZW50VWlkIiwic3Vic2NyaXB0aW9uIiwiY2IiLCJpc1Vuc3Vic2NyaWJlZCIsInRoZW4iLCJhZGRPYnNlcnZlciIsImFjdGlvbiIsIl9sb2dGcmFtZXdvcmsiLCJmcmFtZXdvcmsiLCJzb3J0IiwiX2dldEZyYW1ld29ya3MiLCJvcHRpb25zIiwiYXBwSWQiLCJoZWFydGJlYXRzSGVhZGVyIiwiZ2V0SW1tZWRpYXRlIiwib3B0aW9uYWwiLCJnZXRIZWFydGJlYXRzSGVhZGVyIiwiYXBwQ2hlY2tUb2tlbiIsIl9nZXRBcHBDaGVja1Rva2VuIiwiYXBwQ2hlY2tUb2tlblJlc3VsdCIsIl9jYXN0QXV0aCIsIm9ic2VydmVyIiwiY3JlYXRlU3Vic2NyaWJlIiwiZ2V0U2NyaXB0UGFyZW50RWxlbWVudCIsImdldEVsZW1lbnRzQnlUYWdOYW1lIiwiX2xvYWRKUyIsImVsIiwiY3JlYXRlRWxlbWVudCIsInNldEF0dHJpYnV0ZSIsIm9ubG9hZCIsIm9uZXJyb3IiLCJjaGFyc2V0IiwiYXBwZW5kQ2hpbGQiLCJfZ2VuZXJhdGVDYWxsYmFja05hbWUiLCJwcmVmaXgiLCJmbG9vciIsInJhbmRvbSIsIlJFQ0FQVENIQV9FTlRFUlBSSVNFX1VSTCIsIlJFQ0FQVENIQV9FTlRFUlBSSVNFX1ZFUklGSUVSX1RZUEUiLCJGQUtFX1RPS0VOIiwiUmVjYXB0Y2hhRW50ZXJwcmlzZVZlcmlmaWVyIiwiYXV0aEV4dGVybiIsInZlcmlmeSIsInJldHJpZXZlU2l0ZUtleSIsImNsaWVudFR5cGUiLCJ2ZXJzaW9uIiwiY2F0Y2giLCJyZXRyaWV2ZVJlY2FwdGNoYVRva2VuIiwicmVhZHkiLCJleGVjdXRlIiwiaW5qZWN0UmVjYXB0Y2hhRmllbGRzIiwiY2FwdGNoYVJlc3AiLCJ2ZXJpZmllciIsImNhcHRjaGFSZXNwb25zZSIsIm5ld1JlcXVlc3QiLCJoYW5kbGVSZWNhcHRjaGFGbG93IiwiYXV0aEluc3RhbmNlIiwiYWN0aW9uTmFtZSIsImFjdGlvbk1ldGhvZCIsInJlcXVlc3RXaXRoUmVjYXB0Y2hhIiwiY29uc29sZSIsImxvZyIsIl9pbml0aWFsaXplUmVjYXB0Y2hhQ29uZmlnIiwiYXV0aEludGVybmFsIiwiZGVwcyIsIl9nZXRQcm92aWRlciIsImlzSW5pdGlhbGl6ZWQiLCJhdXRoMiIsImluaXRpYWxPcHRpb25zIiwiZ2V0T3B0aW9ucyIsImRlZXBFcXVhbCIsIl9pbml0aWFsaXplQXV0aEluc3RhbmNlIiwiaGllcmFyY2h5IiwiZGlzYWJsZVdhcm5pbmdzIiwiZXh0cmFjdFByb3RvY29sIiwicG9ydCIsImV4dHJhY3RIb3N0QW5kUG9ydCIsInBvcnRTdHIiLCJmcmVlemUiLCJlbWl0RW11bGF0b3JXYXJuaW5nIiwicHJvdG9jb2xFbmQiLCJpbmRleE9mIiwic3Vic3RyIiwiYXV0aG9yaXR5IiwiZXhlYyIsImhvc3RBbmRQb3J0IiwicG9wIiwiYnJhY2tldGVkSVB2NiIsInBhcnNlUG9ydCIsImF0dGFjaEJhbm5lciIsInN0eSIsInN0eWxlIiwiaW5uZXJUZXh0IiwicG9zaXRpb24iLCJ3aWR0aCIsImJhY2tncm91bmRDb2xvciIsImJvcmRlciIsImNvbG9yIiwiYm90dG9tIiwibGVmdCIsIm1hcmdpbiIsInpJbmRleCIsInRleHRBbGlnbiIsImNsYXNzTGlzdCIsImFkZCIsImluZm8iLCJyZWFkeVN0YXRlIiwiYWRkRXZlbnRMaXN0ZW5lciIsInNpZ25Jbk1ldGhvZCIsIl9nZXRJZFRva2VuUmVzcG9uc2UiLCJfYXV0aCIsIl9saW5rVG9JZFRva2VuIiwiX2lkVG9rZW4iLCJfZ2V0UmVhdXRoZW50aWNhdGlvblJlc29sdmVyIiwicmVzZXRQYXNzd29yZCIsInVwZGF0ZUVtYWlsUGFzc3dvcmQiLCJsaW5rRW1haWxQYXNzd29yZCIsImFwcGx5QWN0aW9uQ29kZSQxIiwic2lnbkluV2l0aFBhc3N3b3JkIiwic2VuZE9vYkNvZGUiLCJzZW5kRW1haWxWZXJpZmljYXRpb24kMSIsInNlbmRQYXNzd29yZFJlc2V0RW1haWwkMSIsInNlbmRTaWduSW5MaW5rVG9FbWFpbCQxIiwidmVyaWZ5QW5kQ2hhbmdlRW1haWwiLCJzaWduSW5XaXRoRW1haWxMaW5rJDEiLCJzaWduSW5XaXRoRW1haWxMaW5rRm9yTGlua2luZyIsIl9lbWFpbCIsIl9wYXNzd29yZCIsIl90ZW5hbnRJZCIsIl9mcm9tRW1haWxBbmRQYXNzd29yZCIsIl9mcm9tRW1haWxBbmRDb2RlIiwib29iQ29kZSIsIm9iaiIsInJldHVyblNlY3VyZVRva2VuIiwic2lnbkluV2l0aElkcCIsIklEUF9SRVFVRVNUX1VSSSQxIiwicGVuZGluZ1Rva2VuIiwiX2Zyb21QYXJhbXMiLCJjcmVkIiwibm9uY2UiLCJvYXV0aFRva2VuIiwib2F1dGhUb2tlblNlY3JldCIsInNlY3JldCIsImJ1aWxkUmVxdWVzdCIsImF1dG9DcmVhdGUiLCJyZXF1ZXN0VXJpIiwicG9zdEJvZHkiLCJzZW5kUGhvbmVWZXJpZmljYXRpb25Db2RlIiwic2lnbkluV2l0aFBob25lTnVtYmVyJDEiLCJsaW5rV2l0aFBob25lTnVtYmVyJDEiLCJ0ZW1wb3JhcnlQcm9vZiIsIlZFUklGWV9QSE9ORV9OVU1CRVJfRk9SX0VYSVNUSU5HX0VSUk9SX01BUF8iLCJ2ZXJpZnlQaG9uZU51bWJlckZvckV4aXN0aW5nIiwiYXBpUmVxdWVzdCIsIm9wZXJhdGlvbiIsIl9mcm9tVmVyaWZpY2F0aW9uIiwidmVyaWZpY2F0aW9uSWQiLCJ2ZXJpZmljYXRpb25Db2RlIiwiX2Zyb21Ub2tlblJlc3BvbnNlIiwiX21ha2VWZXJpZmljYXRpb25SZXF1ZXN0Iiwic2Vzc2lvbkluZm8iLCJwYXJzZU1vZGUiLCJtb2RlIiwicGFyc2VEZWVwTGluayIsImxpbmsiLCJxdWVyeXN0cmluZ0RlY29kZSIsImV4dHJhY3RRdWVyeXN0cmluZyIsImRvdWJsZURlZXBMaW5rIiwiaU9TRGVlcExpbmsiLCJpT1NEb3VibGVEZWVwTGluayIsImFjdGlvbkxpbmsiLCJzZWFyY2hQYXJhbXMiLCJjb250aW51ZVVybCIsInBhcnNlTGluayIsIlBST1ZJREVSX0lEIiwiY3JlZGVudGlhbCIsImNyZWRlbnRpYWxXaXRoTGluayIsImVtYWlsTGluayIsImFjdGlvbkNvZGVVcmwiLCJFTUFJTF9QQVNTV09SRF9TSUdOX0lOX01FVEhPRCIsIkVNQUlMX0xJTktfU0lHTl9JTl9NRVRIT0QiLCJGZWRlcmF0ZWRBdXRoUHJvdmlkZXIiLCJkZWZhdWx0TGFuZ3VhZ2VDb2RlIiwiY3VzdG9tUGFyYW1ldGVycyIsInNldERlZmF1bHRMYW5ndWFnZSIsInNldEN1c3RvbVBhcmFtZXRlcnMiLCJjdXN0b21PQXV0aFBhcmFtZXRlcnMiLCJnZXRDdXN0b21QYXJhbWV0ZXJzIiwiQmFzZU9BdXRoUHJvdmlkZXIiLCJzY29wZXMiLCJhZGRTY29wZSIsInNjb3BlIiwiZ2V0U2NvcGVzIiwiY3JlZGVudGlhbEZyb21KU09OIiwiX2NyZWRlbnRpYWwiLCJyYXdOb25jZSIsImNyZWRlbnRpYWxGcm9tUmVzdWx0IiwidXNlckNyZWRlbnRpYWwiLCJvYXV0aENyZWRlbnRpYWxGcm9tVGFnZ2VkT2JqZWN0IiwiY3JlZGVudGlhbEZyb21FcnJvciIsInRva2VuUmVzcG9uc2UiLCJvYXV0aElkVG9rZW4iLCJvYXV0aEFjY2Vzc1Rva2VuIiwiRkFDRUJPT0tfU0lHTl9JTl9NRVRIT0QiLCJjcmVkZW50aWFsRnJvbVRhZ2dlZE9iamVjdCIsIkdPT0dMRV9TSUdOX0lOX01FVEhPRCIsIkdJVEhVQl9TSUdOX0lOX01FVEhPRCIsIklEUF9SRVFVRVNUX1VSSSIsIlNBTUxBdXRoQ3JlZGVudGlhbCIsIl9jcmVhdGUiLCJTQU1MX1BST1ZJREVSX1BSRUZJWCIsInNhbWxDcmVkZW50aWFsRnJvbVRhZ2dlZE9iamVjdCIsIlRXSVRURVJfU0lHTl9JTl9NRVRIT0QiLCJzaWduVXAiLCJVc2VyQ3JlZGVudGlhbEltcGwiLCJvcGVyYXRpb25UeXBlIiwicHJvdmlkZXJJZEZvclJlc3BvbnNlIiwidXNlckNyZWQiLCJfZm9yT3BlcmF0aW9uIiwiTXVsdGlGYWN0b3JFcnJvciIsInNldFByb3RvdHlwZU9mIiwicHJvdG90eXBlIiwiX2Zyb21FcnJvckFuZE9wZXJhdGlvbiIsIl9wcm9jZXNzQ3JlZGVudGlhbFNhdmluZ01mYUNvbnRleHRJZk5lY2Vzc2FyeSIsImlkVG9rZW5Qcm92aWRlciIsInByb3ZpZGVyRGF0YUFzTmFtZXMiLCJTZXQiLCJwaWQiLCJfYXNzZXJ0TGlua2VkU3RhdHVzIiwiZGVsZXRlUHJvdmlkZXIiLCJwcm92aWRlcnNMZWZ0IiwicGQiLCJoYXMiLCJfbGluayQxIiwiZXhwZWN0ZWQiLCJwcm92aWRlcklkcyIsIl9yZWF1dGhlbnRpY2F0ZSIsInBhcnNlZCIsInN1YiIsIl9zaWduSW5XaXRoQ3JlZGVudGlhbCIsInNpZ25JbldpdGhDdXN0b21Ub2tlbiQxIiwiY3VzdG9tVG9rZW4iLCJNdWx0aUZhY3RvckluZm9JbXBsIiwiZmFjdG9ySWQiLCJtZmFFbnJvbGxtZW50SWQiLCJlbnJvbGxtZW50VGltZSIsImVucm9sbGVkQXQiLCJfZnJvbVNlcnZlclJlc3BvbnNlIiwiZW5yb2xsbWVudCIsIlBob25lTXVsdGlGYWN0b3JJbmZvSW1wbCIsIlRvdHBNdWx0aUZhY3RvckluZm9JbXBsIiwicGhvbmVJbmZvIiwiX3NldEFjdGlvbkNvZGVTZXR0aW5nc09uUmVxdWVzdCIsImFjdGlvbkNvZGVTZXR0aW5ncyIsImR5bmFtaWNMaW5rRG9tYWluIiwiY2FuSGFuZGxlQ29kZUluQXBwIiwiaGFuZGxlQ29kZUluQXBwIiwiaU9TIiwiYnVuZGxlSWQiLCJpT1NCdW5kbGVJZCIsImFuZHJvaWQiLCJwYWNrYWdlTmFtZSIsImFuZHJvaWRJbnN0YWxsQXBwIiwiaW5zdGFsbEFwcCIsImFuZHJvaWRNaW5pbXVtVmVyc2lvbkNvZGUiLCJtaW5pbXVtVmVyc2lvbiIsImFuZHJvaWRQYWNrYWdlTmFtZSIsInJlY2FjaGVQYXNzd29yZFBvbGljeSIsInJlcXVlc3RUeXBlIiwibmV3UGFzc3dvcmQiLCJhdXRoTW9kdWxhciIsIm5ld0VtYWlsIiwibWZhSW5mbyIsIm11bHRpRmFjdG9ySW5mbyIsImRhdGEiLCJwcmV2aW91c0VtYWlsIiwic2lnblVwUmVzcG9uc2UiLCJzZXRBY3Rpb25Db2RlU2V0dGluZ3MiLCJyZXF1ZXN0MiIsImFjdGlvbkNvZGVTZXR0aW5nczIiLCJjcmVhdGVBdXRoVXJpIiwiY29udGludWVVcmkiLCJpZGVudGlmaWVyIiwic2lnbmluTWV0aG9kcyIsInVwZGF0ZVByb2ZpbGUkMSIsInByb2ZpbGVSZXF1ZXN0IiwicGFzc3dvcmRQcm92aWRlciIsImZpbmQiLCJ1cGRhdGVFbWFpbE9yUGFzc3dvcmQiLCJwcm9maWxlIiwicmF3VXNlckluZm8iLCJpc05ld1VzZXIiLCJraW5kIiwiZmlsdGVyZWRQcm92aWRlcklkIiwiR2VuZXJpY0FkZGl0aW9uYWxVc2VySW5mbyIsIkZhY2Vib29rQWRkaXRpb25hbFVzZXJJbmZvIiwiR2l0aHViQWRkaXRpb25hbFVzZXJJbmZvIiwiR29vZ2xlQWRkaXRpb25hbFVzZXJJbmZvIiwiVHdpdHRlckFkZGl0aW9uYWxVc2VySW5mbyIsInNjcmVlbk5hbWUiLCJGZWRlcmF0ZWRBZGRpdGlvbmFsVXNlckluZm9XaXRoVXNlcm5hbWUiLCJ1c2VybmFtZSIsImxvZ2luIiwiTXVsdGlGYWN0b3JTZXNzaW9uSW1wbCIsIl9mcm9tSWR0b2tlbiIsIl9mcm9tTWZhUGVuZGluZ0NyZWRlbnRpYWwiLCJtZmFQZW5kaW5nQ3JlZGVudGlhbCIsIm11bHRpRmFjdG9yU2Vzc2lvbiIsInBlbmRpbmdDcmVkZW50aWFsIiwiTXVsdGlGYWN0b3JSZXNvbHZlckltcGwiLCJzZXNzaW9uIiwiaGludHMiLCJzaWduSW5SZXNvbHZlciIsIl9mcm9tRXJyb3IiLCJtZmFSZXNwb25zZSIsIl9wcm9jZXNzIiwicmVzb2x2ZVNpZ25JbiIsImFzc2VydGlvbkV4dGVybiIsImVycm9ySW50ZXJuYWwiLCJzdGFydEVucm9sbFBob25lTWZhIiwiZmluYWxpemVFbnJvbGxQaG9uZU1mYSIsInN0YXJ0RW5yb2xsVG90cE1mYSIsImZpbmFsaXplRW5yb2xsVG90cE1mYSIsIndpdGhkcmF3TWZhIiwiTXVsdGlGYWN0b3JVc2VySW1wbCIsImVucm9sbGVkRmFjdG9ycyIsIl9mcm9tVXNlciIsImdldFNlc3Npb24iLCJlbnJvbGwiLCJmaW5hbGl6ZU1mYVJlc3BvbnNlIiwidW5lbnJvbGwiLCJpbmZvT3JVaWQiLCJtdWx0aUZhY3RvclVzZXJDYWNoZSIsIldlYWtNYXAiLCJ1c2VyTW9kdWxhciIsIlNUT1JBR0VfQVZBSUxBQkxFX0tFWSIsIkJyb3dzZXJQZXJzaXN0ZW5jZUNsYXNzIiwic3RvcmFnZVJldHJpZXZlciIsInNldEl0ZW0iLCJyZW1vdmVJdGVtIiwiZ2V0SXRlbSIsIl9pZnJhbWVDYW5ub3RTeW5jV2ViU3RvcmFnZSIsIl9QT0xMSU5HX0lOVEVSVkFMX01TJDEiLCJJRTEwX0xPQ0FMX1NUT1JBR0VfU1lOQ19ERUxBWSIsIkJyb3dzZXJMb2NhbFBlcnNpc3RlbmNlIiwibG9jYWxTdG9yYWdlIiwiZXZlbnQiLCJwb2xsIiwib25TdG9yYWdlRXZlbnQiLCJsaXN0ZW5lcnMiLCJsb2NhbENhY2hlIiwicG9sbFRpbWVyIiwic2FmYXJpTG9jYWxTdG9yYWdlTm90U3luY2VkIiwiZmFsbGJhY2tUb1BvbGxpbmciLCJmb3JBbGxDaGFuZ2VkS2V5cyIsImtleXMiLCJuZXdWYWx1ZSIsIm9sZFZhbHVlIiwia2V5MiIsIl9vbGRWYWx1ZSIsIm5vdGlmeUxpc3RlbmVycyIsImRldGFjaExpc3RlbmVyIiwic3RvcFBvbGxpbmciLCJzdG9yZWRWYWx1ZTIiLCJ0cmlnZ2VyTGlzdGVuZXJzIiwic3RvcmVkVmFsdWUiLCJsaXN0ZW5lciIsImZyb20iLCJzdGFydFBvbGxpbmciLCJzZXRJbnRlcnZhbCIsIlN0b3JhZ2VFdmVudCIsImNsZWFySW50ZXJ2YWwiLCJhdHRhY2hMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJzaXplIiwiQnJvd3NlclNlc3Npb25QZXJzaXN0ZW5jZSIsInNlc3Npb25TdG9yYWdlIiwiX2FsbFNldHRsZWQiLCJwcm9taXNlcyIsImZ1bGZpbGxlZCIsInJlYXNvbiIsIlJlY2VpdmVyIiwiZXZlbnRUYXJnZXQiLCJoYW5kbGVyc01hcCIsImhhbmRsZUV2ZW50IiwiZXhpc3RpbmdJbnN0YW5jZSIsInJlY2VpdmVycyIsInJlY2VpdmVyIiwiaXNMaXN0ZW5pbmd0byIsIm5ld0luc3RhbmNlIiwibWVzc2FnZUV2ZW50IiwiZXZlbnRJZCIsImV2ZW50VHlwZSIsImhhbmRsZXJzIiwicG9ydHMiLCJwb3N0TWVzc2FnZSIsImhhbmRsZXIiLCJvcmlnaW4iLCJfc3Vic2NyaWJlIiwiZXZlbnRIYW5kbGVyIiwiX3Vuc3Vic2NyaWJlIiwiX2dlbmVyYXRlRXZlbnRJZCIsImRpZ2l0cyIsIlNlbmRlciIsInRhcmdldCIsInJlbW92ZU1lc3NhZ2VIYW5kbGVyIiwibWVzc2FnZUNoYW5uZWwiLCJwb3J0MSIsIm9uTWVzc2FnZSIsImNsb3NlIiwiX3NlbmQiLCJ0aW1lb3V0IiwiTWVzc2FnZUNoYW5uZWwiLCJjb21wbGV0aW9uVGltZXIiLCJzdGFydCIsImFja1RpbWVyIiwicG9ydDIiLCJmaW5hbGx5IiwiX3dpbmRvdyIsIl9zZXRXaW5kb3dMb2NhdGlvbiIsIl9pc1dvcmtlciIsIl9nZXRBY3RpdmVTZXJ2aWNlV29ya2VyIiwic2VydmljZVdvcmtlciIsInJlZ2lzdHJhdGlvbiIsImFjdGl2ZSIsIl9nZXRTZXJ2aWNlV29ya2VyQ29udHJvbGxlciIsImNvbnRyb2xsZXIiLCJfZ2V0V29ya2VyR2xvYmFsU2NvcGUiLCJEQl9OQU1FIiwiREJfVkVSU0lPTiIsIkRCX09CSkVDVFNUT1JFX05BTUUiLCJEQl9EQVRBX0tFWVBBVEgiLCJEQlByb21pc2UiLCJ0b1Byb21pc2UiLCJnZXRPYmplY3RTdG9yZSIsImRiIiwiaXNSZWFkV3JpdGUiLCJ0cmFuc2FjdGlvbiIsIm9iamVjdFN0b3JlIiwiX2RlbGV0ZURhdGFiYXNlIiwiaW5kZXhlZERCIiwiZGVsZXRlRGF0YWJhc2UiLCJfb3BlbkRhdGFiYXNlIiwib3BlbiIsImNyZWF0ZU9iamVjdFN0b3JlIiwia2V5UGF0aCIsIm9iamVjdFN0b3JlTmFtZXMiLCJjb250YWlucyIsIl9wdXRPYmplY3QiLCJwdXQiLCJnZXRPYmplY3QiLCJfZGVsZXRlT2JqZWN0IiwiX1BPTExJTkdfSU5URVJWQUxfTVMiLCJfVFJBTlNBQ1RJT05fUkVUUllfQ09VTlQiLCJJbmRleGVkREJMb2NhbFBlcnNpc3RlbmNlIiwicGVuZGluZ1dyaXRlcyIsInNlbmRlciIsInNlcnZpY2VXb3JrZXJSZWNlaXZlckF2YWlsYWJsZSIsImFjdGl2ZVNlcnZpY2VXb3JrZXIiLCJfd29ya2VySW5pdGlhbGl6YXRpb25Qcm9taXNlIiwiaW5pdGlhbGl6ZVNlcnZpY2VXb3JrZXJNZXNzYWdpbmciLCJfb3BlbkRiIiwiX3dpdGhSZXRyaWVzIiwib3AiLCJudW1BdHRlbXB0cyIsImluaXRpYWxpemVSZWNlaXZlciIsImluaXRpYWxpemVTZW5kZXIiLCJfb3JpZ2luIiwiX3BvbGwiLCJrZXlQcm9jZXNzZWQiLCJfZGF0YSIsInJlc3VsdHMiLCJub3RpZnlTZXJ2aWNlV29ya2VyIiwiX3dpdGhQZW5kaW5nV3JpdGUiLCJ3cml0ZSIsImdldEFsbFJlcXVlc3QiLCJnZXRBbGwiLCJrZXlzSW5SZXN1bHQiLCJmYmFzZV9rZXkiLCJsb2NhbEtleSIsInN0YXJ0U2lnbkluUGhvbmVNZmEiLCJmaW5hbGl6ZVNpZ25JblBob25lTWZhIiwiZmluYWxpemVTaWduSW5Ub3RwTWZhIiwiX1NPTFZFX1RJTUVfTVMiLCJfRVhQSVJBVElPTl9USU1FX01TIiwiX1dJREdFVF9JRF9TVEFSVCIsIk1vY2tSZUNhcHRjaGEiLCJjb3VudGVyIiwiX3dpZGdldHMiLCJyZW5kZXIiLCJjb250YWluZXIiLCJwYXJhbWV0ZXJzIiwiTW9ja1dpZGdldCIsInJlc2V0Iiwib3B0V2lkZ2V0SWQiLCJjb250YWluZXJPcklkIiwiZGVsZXRlZCIsInJlc3BvbnNlVG9rZW4iLCJjbGlja0hhbmRsZXIiLCJnZXRFbGVtZW50QnlJZCIsImlzVmlzaWJsZSIsImNoZWNrSWZEZWxldGVkIiwiZ2VuZXJhdGVSYW5kb21BbHBoYU51bWVyaWNTdHJpbmciLCJleHBpcmVkQ2FsbGJhY2siLCJsZW4iLCJjaGFycyIsImFsbG93ZWRDaGFycyIsIl9KU0xPQURfQ0FMTEJBQ0siLCJORVRXT1JLX1RJTUVPVVRfREVMQVkiLCJSRUNBUFRDSEFfQkFTRSIsIlJlQ2FwdGNoYUxvYWRlckltcGwiLCJob3N0TGFuZ3VhZ2UiLCJsaWJyYXJ5U2VwYXJhdGVseUxvYWRlZCIsImxvYWQiLCJobCIsImlzSG9zdExhbmd1YWdlVmFsaWQiLCJzaG91bGRSZXNvbHZlSW1tZWRpYXRlbHkiLCJyZWNhcHRjaGEiLCJ3aWRnZXRJZCIsImNsZWFyZWRPbmVJbnN0YW5jZSIsIk1vY2tSZUNhcHRjaGFMb2FkZXJJbXBsIiwiUkVDQVBUQ0hBX1ZFUklGSUVSX1RZUEUiLCJERUZBVUxUX1BBUkFNUyIsInRoZW1lIiwiZGVzdHJveWVkIiwidG9rZW5DaGFuZ2VMaXN0ZW5lcnMiLCJyZW5kZXJQcm9taXNlIiwiaXNJbnZpc2libGUiLCJtYWtlVG9rZW5DYWxsYmFjayIsIl9yZWNhcHRjaGFMb2FkZXIiLCJ2YWxpZGF0ZVN0YXJ0aW5nU3RhdGUiLCJhc3NlcnROb3REZXN0cm95ZWQiLCJnZXRBc3NlcnRlZFJlY2FwdGNoYSIsInRva2VuQ2hhbmdlIiwibWFrZVJlbmRlclByb21pc2UiLCJfcmVzZXQiLCJjbGVhciIsImNoaWxkTm9kZXMiLCJmb3JFYWNoIiwibm9kZSIsInJlbW92ZUNoaWxkIiwic2l0ZWtleSIsImhhc0NoaWxkTm9kZXMiLCJleGlzdGluZyIsImdsb2JhbEZ1bmMiLCJpbml0IiwiZ3VhcmFudGVlZEVtcHR5IiwiZG9tUmVhZHkiLCJDb25maXJtYXRpb25SZXN1bHRJbXBsIiwib25Db25maXJtYXRpb24iLCJjb25maXJtIiwiYXV0aENyZWRlbnRpYWwiLCJhcHBWZXJpZmllciIsIl92ZXJpZnlQaG9uZU51bWJlciIsInJlY2FwdGNoYVRva2VuIiwicGhvbmVJbmZvT3B0aW9ucyIsInBob25lRW5yb2xsbWVudEluZm8iLCJwaG9uZVNlc3Npb25JbmZvIiwibXVsdGlGYWN0b3JIaW50IiwibXVsdGlGYWN0b3JVaWQiLCJwaG9uZVNpZ25JbkluZm8iLCJwaG9uZVJlc3BvbnNlSW5mbyIsInZlcmlmeVBob25lTnVtYmVyIiwicGhvbmVPcHRpb25zIiwiYXBwbGljYXRpb25WZXJpZmllciIsIlBIT05FX1NJR05fSU5fTUVUSE9EIiwiX3dpdGhEZWZhdWx0UmVzb2x2ZXIiLCJyZXNvbHZlck92ZXJyaWRlIiwiSWRwQ3JlZGVudGlhbCIsIl9idWlsZElkcFJlcXVlc3QiLCJzZXNzaW9uSWQiLCJyZXR1cm5JZHBDcmVkZW50aWFsIiwiX3NpZ25JbiIsIl9yZWF1dGgiLCJfbGluayIsIkFic3RyYWN0UG9wdXBSZWRpcmVjdE9wZXJhdGlvbiIsInBlbmRpbmdQcm9taXNlIiwiZXZlbnRNYW5hZ2VyIiwib25FeGVjdXRpb24iLCJyZWdpc3RlckNvbnN1bWVyIiwib25BdXRoRXZlbnQiLCJ1cmxSZXNwb25zZSIsImdldElkcFRhc2siLCJvbkVycm9yIiwidW5yZWdpc3RlckFuZENsZWFuVXAiLCJ1bnJlZ2lzdGVyQ29uc3VtZXIiLCJjbGVhblVwIiwiX1BPTExfV0lORE9XX0NMT1NFX1RJTUVPVVQiLCJyZXNvbHZlckludGVybmFsIiwiUG9wdXBPcGVyYXRpb24iLCJleGVjdXRlTm90TnVsbCIsImF1dGhXaW5kb3ciLCJwb2xsSWQiLCJjdXJyZW50UG9wdXBBY3Rpb24iLCJjYW5jZWwiLCJfb3BlblBvcHVwIiwiYXNzb2NpYXRlZEV2ZW50IiwiX29yaWdpblZhbGlkYXRpb24iLCJfaXNJZnJhbWVXZWJTdG9yYWdlU3VwcG9ydGVkIiwiaXNTdXBwb3J0ZWQiLCJwb2xsVXNlckNhbmNlbGxhdGlvbiIsImNsb3NlZCIsIlBFTkRJTkdfUkVESVJFQ1RfS0VZIiwicmVkaXJlY3RPdXRjb21lTWFwIiwiUmVkaXJlY3RBY3Rpb24iLCJyZWFkeU91dGNvbWUiLCJoYXNQZW5kaW5nUmVkaXJlY3QiLCJfZ2V0QW5kQ2xlYXJQZW5kaW5nUmVkaXJlY3RTdGF0dXMiLCJwZW5kaW5nUmVkaXJlY3RLZXkiLCJyZXNvbHZlclBlcnNpc3RlbmNlIiwiX3NldFBlbmRpbmdSZWRpcmVjdFN0YXR1cyIsIl9jbGVhclJlZGlyZWN0T3V0Y29tZXMiLCJfc2lnbkluV2l0aFJlZGlyZWN0IiwiX29wZW5SZWRpcmVjdCIsIl9yZWF1dGhlbnRpY2F0ZVdpdGhSZWRpcmVjdCIsInByZXBhcmVVc2VyRm9yUmVkaXJlY3QiLCJfbGlua1dpdGhSZWRpcmVjdCIsIl9nZXRSZWRpcmVjdFJlc3VsdCIsInJlc29sdmVyRXh0ZXJuIiwiRVZFTlRfRFVQTElDQVRJT05fQ0FDSEVfRFVSQVRJT05fTVMiLCJBdXRoRXZlbnRNYW5hZ2VyIiwiY2FjaGVkRXZlbnRVaWRzIiwiY29uc3VtZXJzIiwicXVldWVkUmVkaXJlY3RFdmVudCIsImhhc0hhbmRsZWRQb3RlbnRpYWxSZWRpcmVjdCIsImxhc3RQcm9jZXNzZWRFdmVudFRpbWUiLCJhdXRoRXZlbnRDb25zdW1lciIsImlzRXZlbnRGb3JDb25zdW1lciIsInNlbmRUb0NvbnN1bWVyIiwic2F2ZUV2ZW50VG9DYWNoZSIsIm9uRXZlbnQiLCJoYXNFdmVudEJlZW5IYW5kbGVkIiwiaGFuZGxlZCIsImNvbnN1bWVyIiwiaXNSZWRpcmVjdEV2ZW50IiwiaXNOdWxsUmVkaXJlY3RFdmVudCIsImV2ZW50SWRNYXRjaGVzIiwiZXZlbnRVaWQiLCJ2IiwiX2dldFByb2plY3RDb25maWciLCJJUF9BRERSRVNTX1JFR0VYIiwiSFRUUF9SRUdFWCIsIl92YWxpZGF0ZU9yaWdpbiIsImF1dGhvcml6ZWREb21haW5zIiwiZG9tYWluIiwibWF0Y2hEb21haW4iLCJjdXJyZW50VXJsIiwiaG9zdG5hbWUiLCJVUkwiLCJjZVVybCIsImVzY2FwZWREb21haW5QYXR0ZXJuIiwiUmVnRXhwIiwiTkVUV09SS19USU1FT1VUIiwicmVzZXRVbmxvYWRlZEdhcGlNb2R1bGVzIiwiYmVhY29uIiwiX19fanNsIiwiSCIsImhpbnQiLCJyIiwiTCIsIkNQIiwibG9hZEdhcGkiLCJsb2FkR2FwaUlmcmFtZSIsImdhcGkiLCJpZnJhbWVzIiwiZ2V0Q29udGV4dCIsIm9udGltZW91dCIsIklmcmFtZSIsImNiTmFtZSIsImNhY2hlZEdBcGlMb2FkZXIiLCJfbG9hZEdhcGkiLCJQSU5HX1RJTUVPVVQiLCJJRlJBTUVfUEFUSCIsIkVNVUxBVEVEX0lGUkFNRV9QQVRIIiwiSUZSQU1FX0FUVFJJQlVURVMiLCJoZWlnaHQiLCJ0YWJpbmRleCIsIkVJRF9GUk9NX0FQSUhPU1QiLCJnZXRJZnJhbWVVcmwiLCJlaWQiLCJmdyIsIl9vcGVuSWZyYW1lIiwiY29udGV4dCIsImdhcGkyIiwid2hlcmUiLCJtZXNzYWdlSGFuZGxlcnNGaWx0ZXIiLCJDUk9TU19PUklHSU5fSUZSQU1FU19GSUxURVIiLCJhdHRyaWJ1dGVzIiwiZG9udGNsZWFyIiwiaWZyYW1lIiwicmVzdHlsZSIsInNldEhpZGVPbkxlYXZlIiwibmV0d29ya0Vycm9yIiwibmV0d29ya0Vycm9yVGltZXIiLCJjbGVhclRpbWVyQW5kUmVzb2x2ZSIsInBpbmciLCJCQVNFX1BPUFVQX09QVElPTlMiLCJyZXNpemFibGUiLCJzdGF0dXNiYXIiLCJ0b29sYmFyIiwiREVGQVVMVF9XSURUSCIsIkRFRkFVTFRfSEVJR0hUIiwiVEFSR0VUX0JMQU5LIiwiRklSRUZPWF9FTVBUWV9VUkwiLCJBdXRoUG9wdXAiLCJ3aW5kb3cyIiwiX29wZW4iLCJzY3JlZW4iLCJhdmFpbEhlaWdodCIsImF2YWlsV2lkdGgiLCJzY3JvbGxiYXJzIiwib3B0aW9uc1N0cmluZyIsImVudHJpZXMiLCJyZWR1Y2UiLCJhY2N1bSIsIm9wZW5Bc05ld1dpbmRvd0lPUyIsIm5ld1dpbiIsImZvY3VzIiwiY2xpY2siLCJjcmVhdGVFdmVudCIsImluaXRNb3VzZUV2ZW50IiwiZGlzcGF0Y2hFdmVudCIsIldJREdFVF9QQVRIIiwiRU1VTEFUT1JfV0lER0VUX1BBVEgiLCJGSVJFQkFTRV9BUFBfQ0hFQ0tfRlJBR01FTlRfSUQiLCJlbmNvZGVVUklDb21wb25lbnQiLCJfZ2V0UmVkaXJlY3RVcmwiLCJhdXRoVHlwZSIsInJlZGlyZWN0VXJsIiwiYWRkaXRpb25hbFBhcmFtcyIsImlzRW1wdHkiLCJ0aWQiLCJwYXJhbXNEaWN0IiwiYXBwQ2hlY2tUb2tlbkZyYWdtZW50IiwiZ2V0SGFuZGxlckJhc2UiLCJXRUJfU1RPUkFHRV9TVVBQT1JUX0tFWSIsIkJyb3dzZXJQb3B1cFJlZGlyZWN0UmVzb2x2ZXIiLCJldmVudE1hbmFnZXJzIiwib3JpZ2luVmFsaWRhdGlvblByb21pc2VzIiwicHJvbWlzZTIiLCJpbml0QW5kR2V0TWFuYWdlciIsInJlZ2lzdGVyIiwiaWZyYW1lRXZlbnQiLCJhdXRoRXZlbnQiLCJzZW5kIiwiTXVsdGlGYWN0b3JBc3NlcnRpb25JbXBsIiwiX2ZpbmFsaXplRW5yb2xsIiwiX2ZpbmFsaXplU2lnbkluIiwiUGhvbmVNdWx0aUZhY3RvckFzc2VydGlvbkltcGwiLCJfZnJvbUNyZWRlbnRpYWwiLCJwaG9uZVZlcmlmaWNhdGlvbkluZm8iLCJGQUNUT1JfSUQiLCJhc3NlcnRpb25Gb3JFbnJvbGxtZW50Iiwib25lVGltZVBhc3N3b3JkIiwiVG90cE11bHRpRmFjdG9yQXNzZXJ0aW9uSW1wbCIsIl9mcm9tU2VjcmV0IiwiYXNzZXJ0aW9uRm9yU2lnbkluIiwiZW5yb2xsbWVudElkIiwiX2Zyb21FbnJvbGxtZW50SWQiLCJnZW5lcmF0ZVNlY3JldCIsIm1mYVNlc3Npb24iLCJ0b3RwRW5yb2xsbWVudEluZm8iLCJfZnJvbVN0YXJ0VG90cE1mYUVucm9sbG1lbnRSZXNwb25zZSIsIm90cCIsInRvdHBWZXJpZmljYXRpb25JbmZvIiwiX21ha2VUb3RwVmVyaWZpY2F0aW9uSW5mbyIsInNlY3JldEtleSIsImhhc2hpbmdBbGdvcml0aG0iLCJjb2RlTGVuZ3RoIiwiY29kZUludGVydmFsU2Vjb25kcyIsImVucm9sbG1lbnRDb21wbGV0aW9uRGVhZGxpbmUiLCJ0b3RwU2Vzc2lvbkluZm8iLCJzaGFyZWRTZWNyZXRLZXkiLCJ2ZXJpZmljYXRpb25Db2RlTGVuZ3RoIiwicGVyaW9kU2VjIiwiZmluYWxpemVFbnJvbGxtZW50VGltZSIsImdlbmVyYXRlUXJDb2RlVXJsIiwiYWNjb3VudE5hbWUiLCJpc3N1ZXIiLCJ1c2VEZWZhdWx0cyIsIl9pc0VtcHR5U3RyaW5nIiwiaW5wdXQiLCJBdXRoSW50ZXJvcCIsImludGVybmFsTGlzdGVuZXJzIiwiZ2V0VWlkIiwiYXNzZXJ0QXV0aENvbmZpZ3VyZWQiLCJhZGRBdXRoVG9rZW5MaXN0ZW5lciIsInVwZGF0ZVByb2FjdGl2ZVJlZnJlc2giLCJyZW1vdmVBdXRoVG9rZW5MaXN0ZW5lciIsImdldFZlcnNpb25Gb3JQbGF0Zm9ybSIsInJlZ2lzdGVyQXV0aCIsIl9yZWdpc3RlckNvbXBvbmVudCIsImltcG9ydF9jb21wb25lbnQiLCJDb21wb25lbnQiLCJnZXRQcm92aWRlciIsInNldEluc3RhbnRpYXRpb25Nb2RlIiwic2V0SW5zdGFuY2VDcmVhdGVkQ2FsbGJhY2siLCJfaW5zdGFuY2VJZGVudGlmaWVyIiwiX2luc3RhbmNlIiwiYXV0aEludGVybmFsUHJvdmlkZXIiLCJyZWdpc3RlclZlcnNpb24iLCJERUZBVUxUX0lEX1RPS0VOX01BWF9BR0UiLCJhdXRoSWRUb2tlbk1heEFnZSIsImdldEV4cGVyaW1lbnRhbFNldHRpbmciLCJsYXN0UG9zdGVkSWRUb2tlbiIsIm1pbnRDb29raWVGYWN0b3J5IiwiaWRUb2tlblJlc3VsdCIsImlkVG9rZW5BZ2UiLCJnZXRBcHAiLCJhdXRoVG9rZW5TeW5jVXJsIiwibWludENvb2tpZSIsImF1dGhFbXVsYXRvckhvc3QiLCJnZXREZWZhdWx0RW11bGF0b3JIb3N0IiwiaW1wb3J0X3V0aWwyIiwicmVxdWlyZSIsImltcG9ydF9hcHAyIiwiaW1wb3J0X2xvZ2dlcjIiLCJpbXBvcnRfdHNsaWIyIiwiaW1wb3J0X2NvbXBvbmVudDIiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLGtCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsa0JBQUE7RUFBQUUsbUJBQUEsRUFBQUEsQ0FBQSxLQUFBQSxtQkFBQTtFQUFBQyxhQUFBLEVBQUFBLENBQUEsS0FBQUEsYUFBQTtFQUFBQyxjQUFBLEVBQUFBLENBQUEsS0FBQUEsY0FBQTtFQUFBQyxjQUFBLEVBQUFBLENBQUEsS0FBQUMsMENBQUE7RUFBQUMsbUJBQUEsRUFBQUEsQ0FBQSxLQUFBQSxtQkFBQTtFQUFBQyxpQkFBQSxFQUFBQSxDQUFBLEtBQUFBLGlCQUFBO0VBQUFDLG9CQUFBLEVBQUFBLENBQUEsS0FBQUEsb0JBQUE7RUFBQUMsUUFBQSxFQUFBQSxDQUFBLEtBQUFBLFFBQUE7RUFBQUMsa0JBQUEsRUFBQUEsQ0FBQSxLQUFBQSxrQkFBQTtFQUFBQyxrQkFBQSxFQUFBQSxDQUFBLEtBQUFBLGtCQUFBO0VBQUFDLGVBQUEsRUFBQUEsQ0FBQSxLQUFBQSxlQUFBO0VBQUFDLGFBQUEsRUFBQUEsQ0FBQSxLQUFBQSxhQUFBO0VBQUFDLGFBQUEsRUFBQUEsQ0FBQSxLQUFBQSxhQUFBO0VBQUFDLG1CQUFBLEVBQUFBLENBQUEsS0FBQUEsbUJBQUE7RUFBQUMsaUJBQUEsRUFBQUEsQ0FBQSxLQUFBQSxpQkFBQTtFQUFBQyx5QkFBQSxFQUFBQSxDQUFBLEtBQUFBLHlCQUFBO0VBQUFDLFVBQUEsRUFBQUEsQ0FBQSxLQUFBQSxVQUFBO0VBQUFDLGlCQUFBLEVBQUFBLENBQUEsS0FBQUEsaUJBQUE7RUFBQUMsZ0JBQUEsRUFBQUEsQ0FBQSxLQUFBQSxnQkFBQTtFQUFBQyxZQUFBLEVBQUFBLENBQUEsS0FBQUEsWUFBQTtFQUFBQyx3QkFBQSxFQUFBQSxDQUFBLEtBQUFBLHdCQUFBO0VBQUFDLFVBQUEsRUFBQUEsQ0FBQSxLQUFBQSxVQUFBO0VBQUFDLG1CQUFBLEVBQUFBLENBQUEsS0FBQUEsbUJBQUE7RUFBQUMsZUFBQSxFQUFBQSxDQUFBLEtBQUFBLGVBQUE7RUFBQUMsc0JBQUEsRUFBQUEsQ0FBQSxLQUFBQSxzQkFBQTtFQUFBQyx1QkFBQSxFQUFBQSxDQUFBLEtBQUFBLHVCQUFBO0VBQUFDLDRCQUFBLEVBQUFBLENBQUEsS0FBQUEsNEJBQUE7RUFBQUMseUJBQUEsRUFBQUEsQ0FBQSxLQUFBQSx5QkFBQTtFQUFBQyxlQUFBLEVBQUFBLENBQUEsS0FBQUEsZUFBQTtFQUFBQyxvQkFBQSxFQUFBQSxDQUFBLEtBQUFBLG9CQUFBO0VBQUFDLG1CQUFBLEVBQUFBLENBQUEsS0FBQUEsbUJBQUE7RUFBQUMsOEJBQUEsRUFBQUEsQ0FBQSxLQUFBQSw4QkFBQTtFQUFBQyxhQUFBLEVBQUFBLENBQUEsS0FBQUEsYUFBQTtFQUFBQyxVQUFBLEVBQUFBLENBQUEsS0FBQUEsVUFBQTtFQUFBQywwQkFBQSxFQUFBQSxDQUFBLEtBQUFBLDBCQUFBO0VBQUFDLHFCQUFBLEVBQUFBLENBQUEsS0FBQUEscUJBQUE7RUFBQUMsT0FBQSxFQUFBQSxDQUFBLEtBQUFBLE9BQUE7RUFBQUMsVUFBQSxFQUFBQSxDQUFBLEtBQUFBLFVBQUE7RUFBQUMsZ0JBQUEsRUFBQUEsQ0FBQSxLQUFBQSxnQkFBQTtFQUFBQyxzQkFBQSxFQUFBQSxDQUFBLEtBQUFBLHNCQUFBO0VBQUFDLGlCQUFBLEVBQUFBLENBQUEsS0FBQUEsaUJBQUE7RUFBQUMsbUJBQUEsRUFBQUEsQ0FBQSxLQUFBQSxtQkFBQTtFQUFBQyx5QkFBQSxFQUFBQSxDQUFBLEtBQUFBLHlCQUFBO0VBQUFDLGNBQUEsRUFBQUEsQ0FBQSxLQUFBQSxjQUFBO0VBQUFDLHlCQUFBLEVBQUFBLENBQUEsS0FBQUEseUJBQUE7RUFBQUMscUJBQUEsRUFBQUEsQ0FBQSxLQUFBQSxxQkFBQTtFQUFBQyxrQkFBQSxFQUFBQSxDQUFBLEtBQUFBLGtCQUFBO0VBQUFDLG1CQUFBLEVBQUFBLENBQUEsS0FBQUEsbUJBQUE7RUFBQUMsYUFBQSxFQUFBQSxDQUFBLEtBQUFBLGFBQUE7RUFBQUMsZ0JBQUEsRUFBQUEsQ0FBQSxLQUFBQSxnQkFBQTtFQUFBQyxXQUFBLEVBQUFBLENBQUEsS0FBQUEsV0FBQTtFQUFBQyxrQkFBQSxFQUFBQSxDQUFBLEtBQUFBLGtCQUFBO0VBQUFDLGdCQUFBLEVBQUFBLENBQUEsS0FBQUEsZ0JBQUE7RUFBQUMsa0JBQUEsRUFBQUEsQ0FBQSxLQUFBQSxrQkFBQTtFQUFBQyxZQUFBLEVBQUFBLENBQUEsS0FBQUEsWUFBQTtFQUFBQyw0QkFBQSxFQUFBQSxDQUFBLEtBQUFBLDRCQUFBO0VBQUFDLDZCQUFBLEVBQUFBLENBQUEsS0FBQUEsNkJBQUE7RUFBQUMsdUJBQUEsRUFBQUEsQ0FBQSxLQUFBQSx1QkFBQTtFQUFBQywwQkFBQSxFQUFBQSxDQUFBLEtBQUFBLDBCQUFBO0VBQUFDLE1BQUEsRUFBQUEsQ0FBQSxLQUFBQSxNQUFBO0VBQUFDLGlCQUFBLEVBQUFBLENBQUEsS0FBQUEsaUJBQUE7RUFBQUMscUJBQUEsRUFBQUEsQ0FBQSxLQUFBQSxxQkFBQTtFQUFBQyxzQkFBQSxFQUFBQSxDQUFBLEtBQUFBLHNCQUFBO0VBQUFDLHFCQUFBLEVBQUFBLENBQUEsS0FBQUEscUJBQUE7RUFBQUMsY0FBQSxFQUFBQSxDQUFBLEtBQUFBLGNBQUE7RUFBQUMsaUJBQUEsRUFBQUEsQ0FBQSxLQUFBQSxpQkFBQTtFQUFBQyxvQkFBQSxFQUFBQSxDQUFBLEtBQUFBLG9CQUFBO0VBQUFDLHFCQUFBLEVBQUFBLENBQUEsS0FBQUEscUJBQUE7RUFBQUMsMEJBQUEsRUFBQUEsQ0FBQSxLQUFBQSwwQkFBQTtFQUFBQyxtQkFBQSxFQUFBQSxDQUFBLEtBQUFBLG1CQUFBO0VBQUFDLHFCQUFBLEVBQUFBLENBQUEsS0FBQUEscUJBQUE7RUFBQUMsZUFBQSxFQUFBQSxDQUFBLEtBQUFBLGVBQUE7RUFBQUMsa0JBQUEsRUFBQUEsQ0FBQSxLQUFBQSxrQkFBQTtFQUFBQyxPQUFBLEVBQUFBLENBQUEsS0FBQUEsT0FBQTtFQUFBQyxNQUFBLEVBQUFBLENBQUEsS0FBQUEsTUFBQTtFQUFBQyxpQkFBQSxFQUFBQSxDQUFBLEtBQUFBLGlCQUFBO0VBQUFDLFdBQUEsRUFBQUEsQ0FBQSxLQUFBQSxXQUFBO0VBQUFDLGNBQUEsRUFBQUEsQ0FBQSxLQUFBQSxjQUFBO0VBQUFDLGlCQUFBLEVBQUFBLENBQUEsS0FBQUEsaUJBQUE7RUFBQUMsYUFBQSxFQUFBQSxDQUFBLEtBQUFBLGFBQUE7RUFBQUMsaUJBQUEsRUFBQUEsQ0FBQSxLQUFBQSxpQkFBQTtFQUFBQyxnQkFBQSxFQUFBQSxDQUFBLEtBQUFBLGdCQUFBO0VBQUFDLHVCQUFBLEVBQUFBLENBQUEsS0FBQUEsdUJBQUE7RUFBQUMsdUJBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUF6RixrQkFBQTs7Ozs7Ozs7QUNzQmEsSUFBQVUsUUFBQSxHQUFXO0VBRXRCZ0YsS0FBQSxFQUFPO0VBQ1BDLElBQUEsRUFBTTs7QUFRSyxJQUFBeEUsVUFBQSxHQUFhO0VBRXhCeUUsUUFBQSxFQUFVO0VBRVZDLE1BQUEsRUFBUTtFQUVSQyxNQUFBLEVBQVE7RUFFUkMsUUFBQSxFQUFVO0VBRVZMLEtBQUEsRUFBTztFQUVQTSxPQUFBLEVBQVM7O0FBUUUsSUFBQTFFLFlBQUEsR0FBZTtFQUUxQjJFLFVBQUEsRUFBWTtFQUVaQyxjQUFBLEVBQWdCO0VBRWhCTixRQUFBLEVBQVU7RUFFVkMsTUFBQSxFQUFRO0VBRVJDLE1BQUEsRUFBUTtFQUVSSixLQUFBLEVBQU87RUFFUE0sT0FBQSxFQUFTOztBQVFFLElBQUFqRixhQUFBLEdBQWdCO0VBRTNCb0YsSUFBQSxFQUFNO0VBRU5DLGNBQUEsRUFBZ0I7RUFFaEJDLE9BQUEsRUFBUzs7QUFRRSxJQUFBbkcsbUJBQUEsR0FBc0I7RUFFakNvRyxZQUFBLEVBQWM7RUFFZEMsY0FBQSxFQUFnQjtFQUVoQkMsYUFBQSxFQUFlO0VBRWZDLDZCQUFBLEVBQStCO0VBRS9CQyx1QkFBQSxFQUF5QjtFQUV6QkMsWUFBQSxFQUFjOztBQ3NDaEIsU0FBU0MsZUFBQSxFQUFjO0VBQ3JCLE9BQU87SUFDTCxnQ0FDRTtJQUNGLG9CQUFnQztJQUNoQyx3QkFDRTtJQUdGLHVCQUNFO0lBR0YsMEJBQ0U7SUFHRixrQkFDRTtJQUVGLHVCQUFtQztJQUNuQyxzQkFBa0M7SUFDbEMsK0JBQ0U7SUFDRiwyQkFDRTtJQUNGLDJCQUNFO0lBRUYsMkNBQ0U7SUFHRixnQ0FDRTtJQUVGLHFDQUNFO0lBQ0YsMEJBQ0U7SUFDRiw0QkFDRTtJQUdGLHlCQUFrQztJQUNsQyw2QkFDRTtJQUNGLG9CQUFnQztJQUNoQyw0QkFDRTtJQUVGLG9CQUNFO0lBQ0Ysd0JBQ0U7SUFHRix3QkFBb0M7SUFDcEMsK0JBQ0U7SUFHRiwwQkFDRTtJQUNGLG1DQUNFO0lBSUYsMEJBQ0U7SUFDRixpQ0FDRTtJQUNGLG1CQUErQjtJQUMvQiw2QkFDRTtJQUNGLHFCQUNFO0lBQ0YsdUJBQ0U7SUFDRix3QkFDRTtJQUNGLDZCQUNFO0lBRUYsa0NBQ0U7SUFDRiw0QkFDRTtJQUVGLDZCQUNFO0lBRUYseUJBQ0U7SUFFRix5QkFDRTtJQUVGLG9CQUNFO0lBQ0YsOEJBQ0U7SUFDRiwwQkFDRTtJQUlGLHlCQUNFO0lBQ0YsNkJBQ0U7SUFFRixvQkFDRTtJQUVGLDZCQUNFO0lBQ0YsdUJBQ0U7SUFDRixtQkFDRTtJQUNGLDhCQUNFO0lBQ0YsaUNBQ0U7SUFFRiw0QkFDRTtJQUVGLCtCQUNFO0lBQ0YsMEJBQ0U7SUFDRiwwQkFBc0M7SUFDdEMsMkJBQ0U7SUFDRiw4QkFDRTtJQUdGLHNCQUFrQztJQUNsQywrQkFDRTtJQUNGLGtDQUNFO0lBQ0YsMEJBQ0U7SUFDRiw2QkFDRTtJQUNGLGlCQUNFO0lBQ0YsaUNBQ0U7SUFDRixnQ0FDRTtJQUNGLDhDQUNFO0lBR0YsNEJBQ0U7SUFDRixtQkFBK0I7SUFDL0Isc0JBQ0U7SUFDRixlQUNFO0lBRUYsMkJBQ0U7SUFHRixpREFDRTtJQUdGLG1CQUNFO0lBQ0YsMEJBQ0U7SUFDRiw2QkFDRTtJQUNGLG9CQUNFO0lBQ0YsZ0NBQ0U7SUFDRixnQ0FDRTtJQUNGLHlCQUNFO0lBQ0Ysa0NBQ0U7SUFDRiwwQ0FDRTtJQUNGLHdCQUNFO0lBQ0YsYUFBeUI7SUFDekIsd0JBQ0U7SUFDRix1QkFDRTtJQUVGLCtCQUNFO0lBRUYsOEJBQ0U7SUFDRixrQ0FDRTtJQUNGLGtDQUNFO0lBQ0Ysc0JBQ0U7SUFDRixvQkFDRTtJQUNGLG9CQUNFO0lBRUYsbUJBQ0U7SUFDRixtQkFDRTtJQUNGLHFCQUFpQztJQUNqQyxtQkFDRTtJQUNGLDZCQUNFO0lBQ0YseUJBQ0U7SUFJRiw2QkFDRTtJQUNGLDZCQUNFO0lBQ0YsOEJBQ0U7SUFDRiwyQkFDRTtJQUNGLHlCQUNFO0lBQ0YsK0JBQ0U7SUFDRixzQkFBa0M7SUFDbEMsK0JBQ0U7SUFDRixnREFDRTtJQUNGLHlDQUNFOztBQUVOO0FBTUEsU0FBU0MsY0FBQSxFQUFhO0VBSXBCLE9BQU87SUFDTCwyQ0FDRTs7QUFJTjtBQVNPLElBQU0xRSxhQUFBLEdBQThCeUUsY0FBQTtBQVNwQyxJQUFNbkQsWUFBQSxHQUE2Qm9ELGFBQUE7QUF1RG5DLElBQU1DLDJCQUFBLEdBQThCLElBQUlDLFdBQUEsQ0FBQUMsWUFBQSxDQUc3QyxRQUFRLFlBQVlILGFBQUEsQ0FBYSxDQUFFO0FBYXhCLElBQUF2RywwQ0FBQSxHQUE2QztFQUN4RDJHLG9CQUFBLEVBQXNCO0VBQ3RCQyxjQUFBLEVBQWdCO0VBQ2hCQyxrQkFBQSxFQUFvQjtFQUNwQkMsaUJBQUEsRUFBbUI7RUFDbkJDLG9CQUFBLEVBQXNCO0VBQ3RCQyxZQUFBLEVBQWM7RUFDZEMsaUJBQUEsRUFBbUI7RUFDbkJDLGdCQUFBLEVBQWtCO0VBQ2xCQyx5QkFBQSxFQUEyQjtFQUMzQkMsbUJBQUEsRUFBcUI7RUFDckJDLDhCQUFBLEVBQWdDO0VBQ2hDQyw4QkFBQSxFQUFnQztFQUNoQ0MsMEJBQUEsRUFBNEI7RUFDNUJDLCtCQUFBLEVBQWlDO0VBQ2pDQyxZQUFBLEVBQWM7RUFDZEMsc0JBQUEsRUFBd0I7RUFDeEJDLGdCQUFBLEVBQWtCO0VBQ2xCQyxxQkFBQSxFQUF1QjtFQUN2QkMsY0FBQSxFQUFnQjtFQUNoQkMsZUFBQSxFQUFpQjtFQUNqQkMsc0JBQUEsRUFBd0I7RUFDeEJDLGNBQUEsRUFBZ0I7RUFDaEJDLFlBQUEsRUFBYztFQUNkQyxrQkFBQSxFQUFvQjtFQUNwQkMsaUJBQUEsRUFBbUI7RUFDbkJDLFlBQUEsRUFBYztFQUNkQyxvQkFBQSxFQUFzQjtFQUN0QkMsNkJBQUEsRUFBK0I7RUFDL0JDLG9CQUFBLEVBQXNCO0VBQ3RCQywyQkFBQSxFQUE2QjtFQUM3QkMsYUFBQSxFQUFlO0VBQ2ZDLHVCQUFBLEVBQXlCO0VBQ3pCQyxvQkFBQSxFQUFzQjtFQUN0QkMseUJBQUEsRUFBMkI7RUFDM0JDLHVCQUFBLEVBQXlCO0VBQ3pCQyxtQkFBQSxFQUFxQjtFQUNyQkMsdUJBQUEsRUFBeUI7RUFDekJDLHNCQUFBLEVBQXdCO0VBQ3hCQyxnQkFBQSxFQUFrQjtFQUNsQkMsY0FBQSxFQUFnQjtFQUNoQkMsZ0JBQUEsRUFBa0I7RUFDbEJDLG1CQUFBLEVBQXFCO0VBQ3JCQyxvQkFBQSxFQUFzQjtFQUN0QkMsbUJBQUEsRUFBcUI7RUFDckJDLHVCQUFBLEVBQXlCO0VBQ3pCQyxjQUFBLEVBQWdCO0VBQ2hCQyxvQkFBQSxFQUFzQjtFQUN0QkMsaUJBQUEsRUFBbUI7RUFDbkJDLGtCQUFBLEVBQW9CO0VBQ3BCQyxZQUFBLEVBQWM7RUFDZEMsNEJBQUEsRUFBOEI7RUFDOUJDLHNCQUFBLEVBQXdCO0VBQ3hCQyxtQkFBQSxFQUFxQjtFQUNyQkMsWUFBQSxFQUFjO0VBQ2RDLG9CQUFBLEVBQXNCO0VBQ3RCQyxvQkFBQSxFQUFzQjtFQUN0QkMscUJBQUEsRUFBdUI7RUFDdkJDLHdCQUFBLEVBQTBCO0VBQzFCQyxnQkFBQSxFQUFrQjtFQUNsQkMsbUJBQUEsRUFBcUI7RUFDckJDLG9CQUFBLEVBQXNCO0VBQ3RCQyxvQkFBQSxFQUFzQjtFQUN0QkMsZ0JBQUEsRUFBa0I7RUFDbEJDLGlCQUFBLEVBQW1CO0VBQ25CQyxzQkFBQSxFQUF3QjtFQUN4QkMsU0FBQSxFQUFXO0VBQ1hDLGFBQUEsRUFBZTtFQUNmQyxnQkFBQSxFQUFrQjtFQUNsQkMscUJBQUEsRUFBdUI7RUFDdkJDLHVCQUFBLEVBQXlCO0VBQ3pCQyxhQUFBLEVBQWU7RUFDZkMsb0JBQUEsRUFBc0I7RUFDdEJDLHVCQUFBLEVBQXlCO0VBQ3pCQyxjQUFBLEVBQWdCO0VBQ2hCQywwQkFBQSxFQUE0QjtFQUM1QkMsMEJBQUEsRUFBNEI7RUFDNUJDLG1CQUFBLEVBQXFCO0VBQ3JCQyw4QkFBQSxFQUFnQztFQUNoQ0MsNEJBQUEsRUFBOEI7RUFDOUJDLGtCQUFBLEVBQW9CO0VBQ3BCQyxPQUFBLEVBQVM7RUFDVEMsYUFBQSxFQUFlO0VBQ2ZDLDJCQUFBLEVBQTZCO0VBQzdCQyxtQkFBQSxFQUFxQjtFQUNyQkMsd0JBQUEsRUFBMEI7RUFDMUJDLHVCQUFBLEVBQXlCO0VBQ3pCQyw0QkFBQSxFQUE4QjtFQUM5QkMsZ0JBQUEsRUFBa0I7RUFDbEJDLGNBQUEsRUFBZ0I7RUFDaEJDLFlBQUEsRUFBYztFQUNkQyxhQUFBLEVBQWU7RUFDZkMsYUFBQSxFQUFlO0VBQ2ZDLGVBQUEsRUFBaUI7RUFDakJDLGFBQUEsRUFBZTtFQUNmQyx1QkFBQSxFQUF5QjtFQUN6QkMsbUJBQUEsRUFBcUI7RUFDckJDLHFCQUFBLEVBQXVCO0VBQ3ZCQyx1QkFBQSxFQUF5QjtFQUN6QkMsdUJBQUEsRUFBeUI7RUFDekJDLHdCQUFBLEVBQTBCO0VBQzFCQyxtQkFBQSxFQUFxQjtFQUNyQkMseUJBQUEsRUFBMkI7RUFDM0JDLHlCQUFBLEVBQTJCO0VBQzNCQyxnQkFBQSxFQUFrQjs7QUNsa0JwQixJQUFNQyxTQUFBLEdBQVksSUFBSUMsYUFBQSxDQUFBQyxNQUFBLENBQU8sZ0JBQWdCO1NBaUI3QkMsU0FBU0MsR0FBQSxLQUFnQkMsSUFBQSxFQUFjO0VBQ3JELElBQUlMLFNBQUEsQ0FBVU0sUUFBQSxJQUFZTCxhQUFBLENBQUFNLFFBQUEsQ0FBU0MsSUFBQSxFQUFNO0lBQ3ZDUixTQUFBLENBQVVTLElBQUEsQ0FBSyxTQUFTQyxVQUFBLENBQUFDLFdBQUEsTUFBaUJQLEdBQUEsSUFBTyxHQUFHQyxJQUFJO0VBQ3hEO0FBQ0g7U0FFZ0JPLFVBQVVSLEdBQUEsS0FBZ0JDLElBQUEsRUFBYztFQUN0RCxJQUFJTCxTQUFBLENBQVVNLFFBQUEsSUFBWUwsYUFBQSxDQUFBTSxRQUFBLENBQVNNLEtBQUEsRUFBTztJQUN4Q2IsU0FBQSxDQUFVYyxLQUFBLENBQU0sU0FBU0osVUFBQSxDQUFBQyxXQUFBLE1BQWlCUCxHQUFBLElBQU8sR0FBR0MsSUFBSTtFQUN6RDtBQUNIO1NDV2dCVSxNQUNkQyxVQUFBLEtBQ0dDLElBQUEsRUFBZTtFQUVsQixNQUFNQyxtQkFBQSxDQUFvQkYsVUFBQSxFQUFZLEdBQUdDLElBQUk7QUFDL0M7U0FhZ0JFLGFBQ2RILFVBQUEsS0FDR0MsSUFBQSxFQUFlO0VBRWxCLE9BQU9DLG1CQUFBLENBQW9CRixVQUFBLEVBQVksR0FBR0MsSUFBSTtBQUNoRDtTQUVnQkcsd0JBQ2RDLElBQUEsRUFDQUMsSUFBQSxFQUNBQyxPQUFBLEVBQWU7RUFFZixNQUFNQyxRQUFBLEdBQ0FDLE1BQUEsQ0FBQUMsTUFBQSxDQUFBRCxNQUFBLENBQUFDLE1BQUEsS0FBQTFMLFlBQUEsQ0FBa0MsQ0FBRTtJQUN4QyxDQUFDc0wsSUFBQSxHQUFPQztFQUFPO0VBRWpCLE1BQU1JLE9BQUEsR0FBVSxJQUFJckksV0FBQSxDQUFBQyxZQUFBLENBQ2xCLFFBQ0EsWUFDQWlJLFFBQVE7RUFFVixPQUFPRyxPQUFBLENBQVFDLE1BQUEsQ0FBT04sSUFBQSxFQUFNO0lBQzFCTyxPQUFBLEVBQVNSLElBQUEsQ0FBS1M7RUFDZjtBQUNIO1NBRWdCQyxrQkFDZFYsSUFBQSxFQUNBVyxNQUFBLEVBQ0FDLFFBQUEsRUFBaUI7RUFFakIsTUFBTUMsbUJBQUEsR0FBc0JELFFBQUE7RUFDNUIsSUFBSSxFQUFFRCxNQUFBLFlBQWtCRSxtQkFBQSxHQUFzQjtJQUM1QyxJQUFJQSxtQkFBQSxDQUFvQkosSUFBQSxLQUFTRSxNQUFBLENBQU9HLFdBQUEsQ0FBWUwsSUFBQSxFQUFNO01BQ3hEZixLQUFBLENBQU1NLElBQUEsRUFBSTtJQUNYO0lBRUQsTUFBTUQsdUJBQUEsQ0FDSkMsSUFBQSxFQUVBLDZCQUFXVyxNQUFBLENBQU9HLFdBQUEsQ0FBWUwsSUFBQSx1RkFDeUI7RUFFMUQ7QUFDSDtBQUVBLFNBQVNaLG9CQUNQRixVQUFBLEtBQ0dDLElBQUEsRUFBZTtFQUVsQixJQUFJLE9BQU9ELFVBQUEsS0FBZSxVQUFVO0lBQ2xDLE1BQU1NLElBQUEsR0FBT0wsSUFBQSxDQUFLO0lBQ2xCLE1BQU1tQixVQUFBLEdBQWEsQ0FBQyxHQUFHbkIsSUFBQSxDQUFLb0IsS0FBQSxDQUFNLENBQUMsQ0FBQztJQUNwQyxJQUFJRCxVQUFBLENBQVcsSUFBSTtNQUNqQkEsVUFBQSxDQUFXLEdBQUdQLE9BQUEsR0FBVWIsVUFBQSxDQUFXYyxJQUFBO0lBQ3BDO0lBRUQsT0FBUWQsVUFBQSxDQUE0QnNCLGFBQUEsQ0FBY1YsTUFBQSxDQUNoRE4sSUFBQSxFQUNBLEdBQUdjLFVBQVU7RUFFaEI7RUFFRCxPQUFPL0ksMkJBQUEsQ0FBNEJ1SSxNQUFBLENBQ2pDWixVQUFBLEVBQ0EsR0FBSUMsSUFBK0I7QUFFdkM7QUFlTSxTQUFVc0IsUUFDZEMsU0FBQSxFQUNBeEIsVUFBQSxLQUNHQyxJQUFBLEVBQWU7RUFFbEIsSUFBSSxDQUFDdUIsU0FBQSxFQUFXO0lBQ2QsTUFBTXRCLG1CQUFBLENBQW9CRixVQUFBLEVBQVksR0FBR0MsSUFBSTtFQUM5QztBQUNIO0FBNEZNLFNBQVV3QixVQUFVQyxPQUFBLEVBQWU7RUFHdkMsTUFBTW5CLE9BQUEsR0FBVSxnQ0FBZ0NtQixPQUFBO0VBQ2hEOUIsU0FBQSxDQUFVVyxPQUFPO0VBS2pCLE1BQU0sSUFBSW9CLEtBQUEsQ0FBTXBCLE9BQU87QUFDekI7QUFTZ0IsU0FBQXFCLFlBQ2RKLFNBQUEsRUFDQWpCLE9BQUEsRUFBZTtFQUVmLElBQUksQ0FBQ2lCLFNBQUEsRUFBVztJQUNkQyxTQUFBLENBQVVsQixPQUFPO0VBQ2xCO0FBQ0g7U0M3UWdCc0IsZUFBQSxFQUFjOztFQUM1QixPQUFRLE9BQU9DLElBQUEsS0FBUyxpQkFBZUMsRUFBQSxHQUFBRCxJQUFBLENBQUtFLFFBQUEsTUFBUSxRQUFBRCxFQUFBLHVCQUFBQSxFQUFBLENBQUVFLElBQUEsS0FBUztBQUNqRTtTQUVnQkMsZUFBQSxFQUFjO0VBQzVCLE9BQU9DLGlCQUFBLENBQWlCLE1BQU8sV0FBV0EsaUJBQUEsQ0FBaUIsTUFBTztBQUNwRTtTQUVnQkEsa0JBQUEsRUFBaUI7O0VBQy9CLE9BQVEsT0FBT0wsSUFBQSxLQUFTLGlCQUFlQyxFQUFBLEdBQUFELElBQUEsQ0FBS0UsUUFBQSxNQUFRLFFBQUFELEVBQUEsdUJBQUFBLEVBQUEsQ0FBRUssUUFBQSxLQUFhO0FBQ3JFO1NDSmdCQyxVQUFBLEVBQVM7RUFDdkIsSUFDRSxPQUFPQyxTQUFBLEtBQWMsZUFDckJBLFNBQUEsSUFDQSxZQUFZQSxTQUFBLElBQ1osT0FBT0EsU0FBQSxDQUFVQyxNQUFBLEtBQVcsY0FNM0JMLGNBQUEsQ0FBYyxTQUFNNUosV0FBQSxDQUFBa0ssa0JBQUEsRUFBa0IsS0FBTSxnQkFBZ0JGLFNBQUEsR0FDN0Q7SUFDQSxPQUFPQSxTQUFBLENBQVVDLE1BQUE7RUFDbEI7RUFFRCxPQUFPO0FBQ1Q7U0FFZ0JFLGlCQUFBLEVBQWdCO0VBQzlCLElBQUksT0FBT0gsU0FBQSxLQUFjLGFBQWE7SUFDcEMsT0FBTztFQUNSO0VBQ0QsTUFBTUksaUJBQUEsR0FBdUNKLFNBQUE7RUFDN0MsT0FFR0ksaUJBQUEsQ0FBa0JDLFNBQUEsSUFBYUQsaUJBQUEsQ0FBa0JDLFNBQUEsQ0FBVSxNQUc1REQsaUJBQUEsQ0FBa0JFLFFBQUEsSUFFbEI7QUFFSjtJQzFCYUMsS0FBQSxTQUFLO0VBSWhCMUIsWUFDbUIyQixVQUFBLEVBQ0FDLFNBQUEsRUFBaUI7SUFEakIsS0FBVUQsVUFBQSxHQUFWQSxVQUFBO0lBQ0EsS0FBU0MsU0FBQSxHQUFUQSxTQUFBO0lBR2pCbkIsV0FBQSxDQUNFbUIsU0FBQSxHQUFZRCxVQUFBLEVBQ1osNkNBQTZDO0lBRS9DLEtBQUtFLFFBQUEsT0FBVzFLLFdBQUEsQ0FBQTJLLGVBQUEsRUFBZSxTQUFNM0ssV0FBQSxDQUFBNEssYUFBQSxFQUFhOztFQUdwREMsSUFBQSxFQUFHO0lBQ0QsSUFBSSxDQUFDZCxTQUFBLENBQVMsR0FBSTtNQUVoQixPQUFPZSxJQUFBLENBQUtDLEdBQUEsQ0FBRyxLQUFtQixLQUFLUCxVQUFVO0lBQ2xEO0lBS0QsT0FBTyxLQUFLRSxRQUFBLEdBQVcsS0FBS0QsU0FBQSxHQUFZLEtBQUtELFVBQUE7O0FBRWhEO0FDckNlLFNBQUFRLGFBQWFDLE1BQUEsRUFBd0JDLElBQUEsRUFBYTtFQUNoRTVCLFdBQUEsQ0FBWTJCLE1BQUEsQ0FBT0UsUUFBQSxFQUFVLG9DQUFvQztFQUNqRSxNQUFNO0lBQUVDO0VBQUcsSUFBS0gsTUFBQSxDQUFPRSxRQUFBO0VBRXZCLElBQUksQ0FBQ0QsSUFBQSxFQUFNO0lBQ1QsT0FBT0UsR0FBQTtFQUNSO0VBRUQsT0FBTyxHQUFHQSxHQUFBLEdBQU1GLElBQUEsQ0FBS0csVUFBQSxDQUFXLEdBQUcsSUFBSUgsSUFBQSxDQUFLbkMsS0FBQSxDQUFNLENBQUMsSUFBSW1DLElBQUE7QUFDekQ7SUNWYUksYUFBQSxTQUFhO0VBS3hCLE9BQU9DLFdBQ0xDLFNBQUEsRUFDQUMsV0FBQSxFQUNBQyxZQUFBLEVBQThCO0lBRTlCLEtBQUtGLFNBQUEsR0FBWUEsU0FBQTtJQUNqQixJQUFJQyxXQUFBLEVBQWE7TUFDZixLQUFLQSxXQUFBLEdBQWNBLFdBQUE7SUFDcEI7SUFDRCxJQUFJQyxZQUFBLEVBQWM7TUFDaEIsS0FBS0EsWUFBQSxHQUFlQSxZQUFBO0lBQ3JCOztFQUdILE9BQU9DLE1BQUEsRUFBSztJQUNWLElBQUksS0FBS0gsU0FBQSxFQUFXO01BQ2xCLE9BQU8sS0FBS0EsU0FBQTtJQUNiO0lBQ0QsSUFBSSxPQUFPaEMsSUFBQSxLQUFTLGVBQWUsV0FBV0EsSUFBQSxFQUFNO01BQ2xELE9BQU9BLElBQUEsQ0FBS21DLEtBQUE7SUFDYjtJQUNELElBQUksT0FBT0MsVUFBQSxLQUFlLGVBQWVBLFVBQUEsQ0FBV0QsS0FBQSxFQUFPO01BQ3pELE9BQU9DLFVBQUEsQ0FBV0QsS0FBQTtJQUNuQjtJQUNELElBQUksT0FBT0EsS0FBQSxLQUFVLGFBQWE7TUFDaEMsT0FBT0EsS0FBQTtJQUNSO0lBQ0R4QyxTQUFBLENBQ0UsaUhBQWlIOztFQUlySCxPQUFPMEMsUUFBQSxFQUFPO0lBQ1osSUFBSSxLQUFLSixXQUFBLEVBQWE7TUFDcEIsT0FBTyxLQUFLQSxXQUFBO0lBQ2I7SUFDRCxJQUFJLE9BQU9qQyxJQUFBLEtBQVMsZUFBZSxhQUFhQSxJQUFBLEVBQU07TUFDcEQsT0FBT0EsSUFBQSxDQUFLc0MsT0FBQTtJQUNiO0lBQ0QsSUFBSSxPQUFPRixVQUFBLEtBQWUsZUFBZUEsVUFBQSxDQUFXRSxPQUFBLEVBQVM7TUFDM0QsT0FBT0YsVUFBQSxDQUFXRSxPQUFBO0lBQ25CO0lBQ0QsSUFBSSxPQUFPQSxPQUFBLEtBQVksYUFBYTtNQUNsQyxPQUFPQSxPQUFBO0lBQ1I7SUFDRDNDLFNBQUEsQ0FDRSxtSEFBbUg7O0VBSXZILE9BQU80QyxTQUFBLEVBQVE7SUFDYixJQUFJLEtBQUtMLFlBQUEsRUFBYztNQUNyQixPQUFPLEtBQUtBLFlBQUE7SUFDYjtJQUNELElBQUksT0FBT2xDLElBQUEsS0FBUyxlQUFlLGNBQWNBLElBQUEsRUFBTTtNQUNyRCxPQUFPQSxJQUFBLENBQUt3QyxRQUFBO0lBQ2I7SUFDRCxJQUFJLE9BQU9KLFVBQUEsS0FBZSxlQUFlQSxVQUFBLENBQVdJLFFBQUEsRUFBVTtNQUM1RCxPQUFPSixVQUFBLENBQVdJLFFBQUE7SUFDbkI7SUFDRCxJQUFJLE9BQU9BLFFBQUEsS0FBYSxhQUFhO01BQ25DLE9BQU9BLFFBQUE7SUFDUjtJQUNEN0MsU0FBQSxDQUNFLG9IQUFvSDs7QUFHekg7QUN5Q00sSUFBTThDLGdCQUFBLEdBQXlEO0VBRXBFLHlCQUFvRTtFQUVwRSwwQkFBZ0U7RUFHaEUsd0JBQTZEO0VBRTdELDBCQUFnRTtFQUdoRSxzQkFBOEQ7RUFFOUQsc0JBQThEO0VBRzlELCtCQUF5RTtFQUd6RSxrQkFBc0Q7RUFDdEQsNkJBQTBFO0VBRzFFLDBCQUFvRTtFQUNwRSwyQkFBcUU7RUFDckUsc0NBQ3lDO0VBR3pDLHNCQUE0RDtFQUc1RCxxQkFBeUQ7RUFDekQsaUNBQzJDO0VBRTNDLHNCQUE4RDtFQUM5RCxzQkFBOEQ7RUFFOUQsc0JBQTREO0VBRzVELG9DQUM4QztFQUM5QyxzQkFBMEQ7RUFDMUQsbUJBQXdEO0VBQ3hELG9CQUF5RDtFQUd6RCxpQ0FDMkM7RUFDM0MseUNBQ21EO0VBR25ELGtCQUFzRDtFQUN0RCwwQkFBc0U7RUFDdEUsNkJBQXVFO0VBQ3ZFLDBCQUFzRTtFQUN0RSxxQkFBeUQ7RUFLekQsa0NBQzRDO0VBQzVDLHlCQUFvRTtFQUdwRSw2QkFBNEU7RUFHNUUsMEJBQXNFO0VBR3RFLG9DQUNtQztFQUNuQyw4QkFBd0U7RUFDeEUsK0JBQXVFO0VBQ3ZFLG9DQUNtQztFQUNuQywwQkFDOEM7RUFDOUMsa0NBQzRDO0VBRzVDLHNDQUE0RTtFQUc1RSwyQkFBd0U7RUFDeEUsNkJBQTRFO0VBQzVFLDZCQUE0RTtFQUM1RSw4QkFDd0M7RUFDeEMseUJBQW9FO0VBQ3BFLCtCQUN5QztFQUN6QywrQkFDeUM7RUFDekMsc0JBQThEOztBQ2xJekQsSUFBTUMsc0JBQUEsR0FBeUIsSUFBSTNCLEtBQUEsQ0FBTSxLQUFRLEdBQU07QUFFOUMsU0FBQTRCLG1CQUNkcEUsSUFBQSxFQUNBcUUsT0FBQSxFQUFVO0VBRVYsSUFBSXJFLElBQUEsQ0FBS3NFLFFBQUEsSUFBWSxDQUFDRCxPQUFBLENBQVFDLFFBQUEsRUFBVTtJQUN0QyxPQUFBbEUsTUFBQSxDQUFBQyxNQUFBLENBQUFELE1BQUEsQ0FBQUMsTUFBQSxLQUNLZ0UsT0FBTyxHQUNWO01BQUFDLFFBQUEsRUFBVXRFLElBQUEsQ0FBS3NFO0lBQVEsQ0FDdkI7RUFDSDtFQUNELE9BQU9ELE9BQUE7QUFDVDtBQUVPLGVBQWVFLG1CQUNwQnZFLElBQUEsRUFDQXdFLE1BQUEsRUFDQXJCLElBQUEsRUFDQWtCLE9BQUEsRUFDQUksY0FBQSxHQUF1RCxJQUFFO0VBRXpELE9BQU9DLDhCQUFBLENBQStCMUUsSUFBQSxFQUFNeUUsY0FBQSxFQUFnQixZQUFXO0lBQ3JFLElBQUlFLElBQUEsR0FBTztJQUNYLElBQUlDLE1BQUEsR0FBUztJQUNiLElBQUlQLE9BQUEsRUFBUztNQUNYLElBQUlHLE1BQUEsS0FBTSxPQUFxQjtRQUM3QkksTUFBQSxHQUFTUCxPQUFBO01BQ1YsT0FBTTtRQUNMTSxJQUFBLEdBQU87VUFDTEEsSUFBQSxFQUFNRSxJQUFBLENBQUtDLFNBQUEsQ0FBVVQsT0FBTzs7TUFFL0I7SUFDRjtJQUVELE1BQU1VLEtBQUEsT0FBUTlNLFdBQUEsQ0FBQStNLFdBQUEsRUFBVzVFLE1BQUEsQ0FBQUMsTUFBQTtNQUN2QjRFLEdBQUEsRUFBS2pGLElBQUEsQ0FBS2tELE1BQUEsQ0FBT2dDO0lBQU0sR0FDcEJOLE1BQU0sQ0FDVCxFQUFDNUQsS0FBQSxDQUFNLENBQUM7SUFFVixNQUFNOEMsT0FBQSxHQUFVLE1BQU85RCxJQUFBLENBQXNCbUYscUJBQUEsQ0FBcUI7SUFDbEVyQixPQUFBLENBQU8sa0JBQTRCO0lBRW5DLElBQUk5RCxJQUFBLENBQUtvRixZQUFBLEVBQWM7TUFDckJ0QixPQUFBLENBQXFDLHVCQUFHOUQsSUFBQSxDQUFLb0YsWUFBQTtJQUM5QztJQUVELE9BQU83QixhQUFBLENBQWNLLEtBQUEsQ0FBSyxFQUN4QnlCLGVBQUEsQ0FBZ0JyRixJQUFBLEVBQU1BLElBQUEsQ0FBS2tELE1BQUEsQ0FBT29DLE9BQUEsRUFBU25DLElBQUEsRUFBTTRCLEtBQUssR0FBQzNFLE1BQUEsQ0FBQUMsTUFBQTtNQUVyRG1FLE1BQUE7TUFDQVYsT0FBQTtNQUNBeUIsY0FBQSxFQUFnQjtJQUFhLEdBQzFCWixJQUFJO0VBR2IsQ0FBQztBQUNIO0FBRU8sZUFBZUQsK0JBQ3BCMUUsSUFBQSxFQUNBeUUsY0FBQSxFQUNBZSxPQUFBLEVBQWdDO0VBRS9CeEYsSUFBQSxDQUFzQnlGLGdCQUFBLEdBQW1CO0VBQzFDLE1BQU10RixRQUFBLEdBQWdCQyxNQUFBLENBQUFDLE1BQUEsQ0FBQUQsTUFBQSxDQUFBQyxNQUFBLEtBQUE2RCxnQkFBZ0IsR0FBS08sY0FBYztFQUN6RCxJQUFJO0lBQ0YsTUFBTWlCLGNBQUEsR0FBaUIsSUFBSUMsY0FBQSxDQUF5QjNGLElBQUk7SUFDeEQsTUFBTWdFLFFBQUEsR0FBcUIsTUFBTTRCLE9BQUEsQ0FBUUMsSUFBQSxDQUF3QixDQUMvREwsT0FBQSxDQUFPLEdBQ1BFLGNBQUEsQ0FBZUksT0FBQSxDQUNoQjtJQUlESixjQUFBLENBQWVLLG1CQUFBLENBQW1CO0lBRWxDLE1BQU1DLElBQUEsR0FBTyxNQUFNaEMsUUFBQSxDQUFTZ0MsSUFBQSxDQUFJO0lBQ2hDLElBQUksc0JBQXNCQSxJQUFBLEVBQU07TUFDOUIsTUFBTUMsZ0JBQUEsQ0FBaUJqRyxJQUFBLEVBQXVDLDRDQUFBZ0csSUFBSTtJQUNuRTtJQUVELElBQUloQyxRQUFBLENBQVNrQyxFQUFBLElBQU0sRUFBRSxrQkFBa0JGLElBQUEsR0FBTztNQUM1QyxPQUFPQSxJQUFBO0lBQ1IsT0FBTTtNQUNMLE1BQU1HLFlBQUEsR0FBZW5DLFFBQUEsQ0FBU2tDLEVBQUEsR0FBS0YsSUFBQSxDQUFLRyxZQUFBLEdBQWVILElBQUEsQ0FBS3ZHLEtBQUEsQ0FBTVMsT0FBQTtNQUNsRSxNQUFNLENBQUNrRyxlQUFBLEVBQWlCQyxrQkFBa0IsSUFBSUYsWUFBQSxDQUFhRyxLQUFBLENBQU0sS0FBSztNQUN0RSxJQUFJRixlQUFBLEtBQWUsb0NBQW1EO1FBQ3BFLE1BQU1ILGdCQUFBLENBQ0pqRyxJQUFBLEVBRUEsNkJBQUFnRyxJQUFJO01BRVAsV0FBVUksZUFBQSxLQUFlLGdCQUErQjtRQUN2RCxNQUFNSCxnQkFBQSxDQUFpQmpHLElBQUEsRUFBa0Msd0JBQUFnRyxJQUFJO01BQzlELFdBQVVJLGVBQUEsS0FBZSxpQkFBZ0M7UUFDeEQsTUFBTUgsZ0JBQUEsQ0FBaUJqRyxJQUFBLEVBQW1DLGlCQUFBZ0csSUFBSTtNQUMvRDtNQUNELE1BQU1PLFNBQUEsR0FDSnBHLFFBQUEsQ0FBU2lHLGVBQUEsS0FDUkEsZUFBQSxDQUNFSSxXQUFBLENBQVcsRUFDWEMsT0FBQSxDQUFRLFdBQVcsR0FBRztNQUMzQixJQUFJSixrQkFBQSxFQUFvQjtRQUN0QixNQUFNdEcsdUJBQUEsQ0FBd0JDLElBQUEsRUFBTXVHLFNBQUEsRUFBV0Ysa0JBQWtCO01BQ2xFLE9BQU07UUFDTDNHLEtBQUEsQ0FBTU0sSUFBQSxFQUFNdUcsU0FBUztNQUN0QjtJQUNGO0VBQ0YsU0FBUUcsQ0FBQSxFQUFQO0lBQ0EsSUFBSUEsQ0FBQSxZQUFhek8sV0FBQSxDQUFBME8sYUFBQSxFQUFlO01BQzlCLE1BQU1ELENBQUE7SUFDUDtJQUlEaEgsS0FBQSxDQUFNTSxJQUFBLEVBQTRDO01BQUUsV0FBVzRHLE1BQUEsQ0FBT0YsQ0FBQztJQUFDLENBQUU7RUFDM0U7QUFDSDtBQUVPLGVBQWVHLHNCQUNwQjdHLElBQUEsRUFDQXdFLE1BQUEsRUFDQXJCLElBQUEsRUFDQWtCLE9BQUEsRUFDQUksY0FBQSxHQUF1RCxJQUFFO0VBRXpELE1BQU1xQyxjQUFBLEdBQWtCLE1BQU12QyxrQkFBQSxDQUM1QnZFLElBQUEsRUFDQXdFLE1BQUEsRUFDQXJCLElBQUEsRUFDQWtCLE9BQUEsRUFDQUksY0FBYztFQUVoQixJQUFJLDBCQUEwQnFDLGNBQUEsRUFBZ0I7SUFDNUNwSCxLQUFBLENBQU1NLElBQUEsRUFBa0M7TUFDdEMrRyxlQUFBLEVBQWlCRDtJQUNsQjtFQUNGO0VBRUQsT0FBT0EsY0FBQTtBQUNUO0FBRU0sU0FBVXpCLGdCQUNkckYsSUFBQSxFQUNBZ0gsSUFBQSxFQUNBN0QsSUFBQSxFQUNBNEIsS0FBQSxFQUFhO0VBRWIsTUFBTWtDLElBQUEsR0FBTyxHQUFHRCxJQUFBLEdBQU83RCxJQUFBLElBQVE0QixLQUFBO0VBRS9CLElBQUksQ0FBRS9FLElBQUEsQ0FBc0JrRCxNQUFBLENBQU9FLFFBQUEsRUFBVTtJQUMzQyxPQUFPLEdBQUdwRCxJQUFBLENBQUtrRCxNQUFBLENBQU9nRSxTQUFBLE1BQWVELElBQUE7RUFDdEM7RUFFRCxPQUFPaEUsWUFBQSxDQUFhakQsSUFBQSxDQUFLa0QsTUFBQSxFQUEwQitELElBQUk7QUFDekQ7QUFFTSxTQUFVRSx1QkFDZEMsbUJBQUEsRUFBMkI7RUFFM0IsUUFBUUEsbUJBQUE7U0FDRDtNQUNILE9BQWdDO1NBQzdCO01BQ0gsT0FBOEI7U0FDM0I7TUFDSCxPQUE0Qjs7TUFFNUIsT0FBc0Q7O0FBRTVEO0FBRUEsSUFBTXpCLGNBQUEsR0FBTixNQUFvQjtFQWlCbEI3RSxZQUE2QmQsSUFBQSxFQUFVO0lBQVYsS0FBSUEsSUFBQSxHQUFKQSxJQUFBO0lBYnJCLEtBQUtxSCxLQUFBLEdBQWU7SUFDbkIsS0FBT3ZCLE9BQUEsR0FBRyxJQUFJRixPQUFBLENBQVcsQ0FBQzBCLENBQUEsRUFBR0MsTUFBQSxLQUFVO01BQzlDLEtBQUtGLEtBQUEsR0FBUUcsVUFBQSxDQUFXLE1BQUs7UUFDM0IsT0FBT0QsTUFBQSxDQUNMekgsWUFBQSxDQUFhLEtBQUtFLElBQUEsRUFBMkM7TUFFakUsR0FBR21FLHNCQUFBLENBQXVCckIsR0FBQSxDQUFHLENBQUU7SUFDakMsQ0FBQzs7RUFFRGlELG9CQUFBLEVBQW1CO0lBQ2pCMEIsWUFBQSxDQUFhLEtBQUtKLEtBQUs7O0FBSTFCO1NBT2VwQixpQkFDZGpHLElBQUEsRUFDQUMsSUFBQSxFQUNBK0QsUUFBQSxFQUEyQjtFQUUzQixNQUFNMEQsV0FBQSxHQUFnQztJQUNwQ2xILE9BQUEsRUFBU1IsSUFBQSxDQUFLUzs7RUFHaEIsSUFBSXVELFFBQUEsQ0FBUzJELEtBQUEsRUFBTztJQUNsQkQsV0FBQSxDQUFZQyxLQUFBLEdBQVEzRCxRQUFBLENBQVMyRCxLQUFBO0VBQzlCO0VBQ0QsSUFBSTNELFFBQUEsQ0FBUzRELFdBQUEsRUFBYTtJQUN4QkYsV0FBQSxDQUFZRSxXQUFBLEdBQWM1RCxRQUFBLENBQVM0RCxXQUFBO0VBQ3BDO0VBRUQsTUFBTW5JLEtBQUEsR0FBUUssWUFBQSxDQUFhRSxJQUFBLEVBQU1DLElBQUEsRUFBTXlILFdBQVc7RUFHakRqSSxLQUFBLENBQU1vSSxVQUFBLENBQXdDQyxjQUFBLEdBQWlCOUQsUUFBQTtFQUNoRSxPQUFPdkUsS0FBQTtBQUNUO0FDbFNNLFNBQVVzSSxLQUNkQyxVQUFBLEVBQThDO0VBRTlDLE9BQ0VBLFVBQUEsS0FBZSxVQUNkQSxVQUFBLENBQXlCQyxXQUFBLEtBQWdCO0FBRTlDO0FBc0JNLFNBQVVDLGFBQ2RGLFVBQUEsRUFBOEM7RUFFOUMsT0FDRUEsVUFBQSxLQUFlLFVBQ2RBLFVBQUEsQ0FBa0NHLFVBQUEsS0FBZTtBQUV0RDtJQVNhQyxlQUFBLFNBQWU7RUFXMUJ0SCxZQUFZa0QsUUFBQSxFQUFvQztJQVBoRCxLQUFPcUUsT0FBQSxHQUFXO0lBS2xCLEtBQXlCQyx5QkFBQSxHQUF3QztJQUcvRCxJQUFJdEUsUUFBQSxDQUFTdUUsWUFBQSxLQUFpQixRQUFXO01BQ3ZDLE1BQU0sSUFBSWpILEtBQUEsQ0FBTSx3QkFBd0I7SUFDekM7SUFFRCxLQUFLK0csT0FBQSxHQUFVckUsUUFBQSxDQUFTdUUsWUFBQSxDQUFhakMsS0FBQSxDQUFNLEdBQUcsRUFBRTtJQUNoRCxLQUFLZ0MseUJBQUEsR0FBNEJ0RSxRQUFBLENBQVNzRSx5QkFBQTs7RUFTNUNFLDRCQUE0QkMsV0FBQSxFQUFtQjtJQUM3QyxJQUNFLENBQUMsS0FBS0gseUJBQUEsSUFDTixLQUFLQSx5QkFBQSxDQUEwQkksTUFBQSxLQUFXLEdBQzFDO01BQ0EsT0FBTztJQUNSO0lBRUQsV0FBV0oseUJBQUEsSUFBNkIsS0FBS0EseUJBQUEsRUFBMkI7TUFDdEUsSUFDRUEseUJBQUEsQ0FBMEJLLFFBQUEsSUFDMUJMLHlCQUFBLENBQTBCSyxRQUFBLEtBQWFGLFdBQUEsRUFDdkM7UUFDQSxPQUFPdEIsc0JBQUEsQ0FDTG1CLHlCQUFBLENBQTBCTSxnQkFBZ0I7TUFFN0M7SUFDRjtJQUNELE9BQU87O0VBU1RDLGtCQUFrQkosV0FBQSxFQUFtQjtJQUNuQyxPQUNFLEtBQUtELDJCQUFBLENBQTRCQyxXQUFXLE1BQ2xCLGFBQzFCLEtBQUtELDJCQUFBLENBQTRCQyxXQUFXLE1BQUM7O0FBR2xEO0FDMUdNLGVBQWVLLG1CQUFtQjlJLElBQUEsRUFBVTtFQUNqRCxRQUVJLE1BQU11RSxrQkFBQSxDQUNKdkUsSUFBQSxFQUdELCtCQUNEK0ksZ0JBQUEsSUFBb0I7QUFFMUI7QUFtQk8sZUFBZUMsbUJBQ3BCaEosSUFBQSxFQUNBcUUsT0FBQSxFQUFrQztFQUVsQyxPQUFPRSxrQkFBQSxDQUlMdkUsSUFBQSxFQUdBLDhCQUFBb0Usa0JBQUEsQ0FBbUJwRSxJQUFBLEVBQU1xRSxPQUFPLENBQUM7QUFFckM7QUNoRE8sZUFBZTRFLGNBQ3BCakosSUFBQSxFQUNBcUUsT0FBQSxFQUE2QjtFQUU3QixPQUFPRSxrQkFBQSxDQUNMdkUsSUFBQSxFQUdBLCtCQUFBcUUsT0FBTztBQUVYO0FBb0JPLGVBQWU2RSxxQkFDcEJsSixJQUFBLEVBQ0FxRSxPQUFBLEVBQW9DO0VBRXBDLE9BQU9FLGtCQUFBLENBR0x2RSxJQUFBLEVBQWtELCtCQUFBcUUsT0FBTztBQUM3RDtBQXlCTyxlQUFlOEUsZUFDcEJuSixJQUFBLEVBQ0FxRSxPQUFBLEVBQThCO0VBRTlCLE9BQU9FLGtCQUFBLENBQ0x2RSxJQUFBLEVBR0EsK0JBQUFxRSxPQUFPO0FBRVg7QUNqRk0sU0FBVStFLHlCQUNkQyxZQUFBLEVBQThCO0VBRTlCLElBQUksQ0FBQ0EsWUFBQSxFQUFjO0lBQ2pCLE9BQU87RUFDUjtFQUNELElBQUk7SUFFRixNQUFNQyxJQUFBLEdBQU8sSUFBSUMsSUFBQSxDQUFLQyxNQUFBLENBQU9ILFlBQVksQ0FBQztJQUUxQyxJQUFJLENBQUNJLEtBQUEsQ0FBTUgsSUFBQSxDQUFLSSxPQUFBLENBQU8sQ0FBRSxHQUFHO01BRTFCLE9BQU9KLElBQUEsQ0FBS0ssV0FBQSxDQUFXO0lBQ3hCO0VBQ0YsU0FBUWpELENBQUEsRUFBUCxDQUVEO0VBQ0QsT0FBTztBQUNUO1NDR2dCaFQsV0FBV2tXLElBQUEsRUFBWUMsWUFBQSxHQUFlLE9BQUs7RUFDekQsV0FBTzVSLFdBQUEsQ0FBQTZSLGtCQUFBLEVBQW1CRixJQUFJLEVBQUVsVyxVQUFBLENBQVdtVyxZQUFZO0FBQ3pEO0FBY08sZUFBZWxXLGlCQUNwQmlXLElBQUEsRUFDQUMsWUFBQSxHQUFlLE9BQUs7RUFFcEIsTUFBTUUsWUFBQSxPQUFlOVIsV0FBQSxDQUFBNlIsa0JBQUEsRUFBbUJGLElBQUk7RUFDNUMsTUFBTUksS0FBQSxHQUFRLE1BQU1ELFlBQUEsQ0FBYXJXLFVBQUEsQ0FBV21XLFlBQVk7RUFDeEQsTUFBTUksTUFBQSxHQUFTQyxXQUFBLENBQVlGLEtBQUs7RUFFaEM5SSxPQUFBLENBQ0UrSSxNQUFBLElBQVVBLE1BQUEsQ0FBT0UsR0FBQSxJQUFPRixNQUFBLENBQU9HLFNBQUEsSUFBYUgsTUFBQSxDQUFPSSxHQUFBLEVBQ25ETixZQUFBLENBQWEvSixJQUFBLEVBQUk7RUFHbkIsTUFBTXNLLFFBQUEsR0FDSixPQUFPTCxNQUFBLENBQU9LLFFBQUEsS0FBYSxXQUFXTCxNQUFBLENBQU9LLFFBQUEsR0FBVztFQUUxRCxNQUFNQyxjQUFBLEdBQXFDRCxRQUFBLGFBQUFBLFFBQUEsS0FBUSxrQkFBUkEsUUFBQSxDQUFXO0VBRXRELE9BQU87SUFDTEwsTUFBQTtJQUNBRCxLQUFBO0lBQ0FRLFFBQUEsRUFBVXBCLHdCQUFBLENBQ1JxQiwyQkFBQSxDQUE0QlIsTUFBQSxDQUFPRyxTQUFTLENBQUM7SUFFL0NNLFlBQUEsRUFBY3RCLHdCQUFBLENBQ1pxQiwyQkFBQSxDQUE0QlIsTUFBQSxDQUFPSSxHQUFHLENBQUM7SUFFekNNLGNBQUEsRUFBZ0J2Qix3QkFBQSxDQUNkcUIsMkJBQUEsQ0FBNEJSLE1BQUEsQ0FBT0UsR0FBRyxDQUFDO0lBRXpDSSxjQUFBLEVBQWdCQSxjQUFBLElBQWtCO0lBQ2xDSyxrQkFBQSxHQUFvQk4sUUFBQSxhQUFBQSxRQUFBLHVCQUFBQSxRQUFBLENBQVcsNkJBQTRCOztBQUUvRDtBQUVBLFNBQVNHLDRCQUE0QkksT0FBQSxFQUFlO0VBQ2xELE9BQU9yQixNQUFBLENBQU9xQixPQUFPLElBQUk7QUFDM0I7QUFFTSxTQUFVWCxZQUFZRixLQUFBLEVBQWE7RUFDdkMsTUFBTSxDQUFDYyxTQUFBLEVBQVdDLE9BQUEsRUFBU0MsU0FBUyxJQUFJaEIsS0FBQSxDQUFNMUQsS0FBQSxDQUFNLEdBQUc7RUFDdkQsSUFDRXdFLFNBQUEsS0FBYyxVQUNkQyxPQUFBLEtBQVksVUFDWkMsU0FBQSxLQUFjLFFBQ2Q7SUFDQXpMLFNBQUEsQ0FBVSxnREFBZ0Q7SUFDMUQsT0FBTztFQUNSO0VBRUQsSUFBSTtJQUNGLE1BQU0wTCxPQUFBLE9BQVVoVCxXQUFBLENBQUFpVCxZQUFBLEVBQWFILE9BQU87SUFDcEMsSUFBSSxDQUFDRSxPQUFBLEVBQVM7TUFDWjFMLFNBQUEsQ0FBVSxxQ0FBcUM7TUFDL0MsT0FBTztJQUNSO0lBQ0QsT0FBT3NGLElBQUEsQ0FBS3NHLEtBQUEsQ0FBTUYsT0FBTztFQUMxQixTQUFRdkUsQ0FBQSxFQUFQO0lBQ0FuSCxTQUFBLENBQ0UsNENBQ0NtSCxDQUFBLGFBQUFBLENBQUEsdUJBQUFBLENBQUEsQ0FBYTBFLFFBQUEsQ0FBUSxDQUFFO0lBRTFCLE9BQU87RUFDUjtBQUNIO0FBS00sU0FBVUMsZ0JBQWdCckIsS0FBQSxFQUFhO0VBQzNDLE1BQU1zQixXQUFBLEdBQWNwQixXQUFBLENBQVlGLEtBQUs7RUFDckM5SSxPQUFBLENBQVFvSyxXQUFBLEVBQVc7RUFDbkJwSyxPQUFBLENBQVEsT0FBT29LLFdBQUEsQ0FBWW5CLEdBQUEsS0FBUSxhQUFXO0VBQzlDakosT0FBQSxDQUFRLE9BQU9vSyxXQUFBLENBQVlqQixHQUFBLEtBQVEsYUFBVztFQUM5QyxPQUFPYixNQUFBLENBQU84QixXQUFBLENBQVluQixHQUFHLElBQUlYLE1BQUEsQ0FBTzhCLFdBQUEsQ0FBWWpCLEdBQUc7QUFDekQ7QUMzR08sZUFBZWtCLHFCQUNwQjNCLElBQUEsRUFDQTlELE9BQUEsRUFDQTBGLGVBQUEsR0FBa0IsT0FBSztFQUV2QixJQUFJQSxlQUFBLEVBQWlCO0lBQ25CLE9BQU8xRixPQUFBO0VBQ1I7RUFDRCxJQUFJO0lBQ0YsT0FBTyxNQUFNQSxPQUFBO0VBQ2QsU0FBUVksQ0FBQSxFQUFQO0lBQ0EsSUFBSUEsQ0FBQSxZQUFhek8sV0FBQSxDQUFBME8sYUFBQSxJQUFpQjhFLGlCQUFBLENBQWtCL0UsQ0FBQyxHQUFHO01BQ3RELElBQUlrRCxJQUFBLENBQUs1SixJQUFBLENBQUswTCxXQUFBLEtBQWdCOUIsSUFBQSxFQUFNO1FBQ2xDLE1BQU1BLElBQUEsQ0FBSzVKLElBQUEsQ0FBS2xLLE9BQUEsQ0FBTztNQUN4QjtJQUNGO0lBRUQsTUFBTTRRLENBQUE7RUFDUDtBQUNIO0FBRUEsU0FBUytFLGtCQUFrQjtFQUFFeEw7QUFBSSxHQUFpQjtFQUNoRCxPQUNFQSxJQUFBLEtBQVMsUUFBUSxxQkFDakJBLElBQUEsS0FBUyxRQUFRO0FBRXJCO0lDcEJhMEwsZ0JBQUEsU0FBZ0I7RUFVM0I3SyxZQUE2QjhJLElBQUEsRUFBa0I7SUFBbEIsS0FBSUEsSUFBQSxHQUFKQSxJQUFBO0lBVHJCLEtBQVNnQyxTQUFBLEdBQUc7SUFNWixLQUFPQyxPQUFBLEdBQWU7SUFDdEIsS0FBQUMsWUFBQSxHQUEwQzs7RUFJbERDLE9BQUEsRUFBTTtJQUNKLElBQUksS0FBS0gsU0FBQSxFQUFXO01BQ2xCO0lBQ0Q7SUFFRCxLQUFLQSxTQUFBLEdBQVk7SUFDakIsS0FBS0ksUUFBQSxDQUFROztFQUdmQyxNQUFBLEVBQUs7SUFDSCxJQUFJLENBQUMsS0FBS0wsU0FBQSxFQUFXO01BQ25CO0lBQ0Q7SUFFRCxLQUFLQSxTQUFBLEdBQVk7SUFDakIsSUFBSSxLQUFLQyxPQUFBLEtBQVksTUFBTTtNQUN6QnBFLFlBQUEsQ0FBYSxLQUFLb0UsT0FBTztJQUMxQjs7RUFHS0ssWUFBWUMsUUFBQSxFQUFpQjs7SUFDbkMsSUFBSUEsUUFBQSxFQUFVO01BQ1osTUFBTUMsUUFBQSxHQUFXLEtBQUtOLFlBQUE7TUFDdEIsS0FBS0EsWUFBQSxHQUFlL0ksSUFBQSxDQUFLQyxHQUFBLENBQ3ZCLEtBQUs4SSxZQUFBLEdBQWUsR0FBQztNQUd2QixPQUFPTSxRQUFBO0lBQ1IsT0FBTTtNQUVMLEtBQUtOLFlBQUEsR0FBWTtNQUNqQixNQUFNTyxPQUFBLElBQVUzSyxFQUFBLFFBQUtrSSxJQUFBLENBQUswQyxlQUFBLENBQWdCM0IsY0FBQSxNQUFrQixRQUFBakosRUFBQSxjQUFBQSxFQUFBO01BQzVELE1BQU0wSyxRQUFBLEdBQVdDLE9BQUEsR0FBVTlDLElBQUEsQ0FBS2dELEdBQUEsQ0FBRyxJQUFFO01BRXJDLE9BQU94SixJQUFBLENBQUt5SixHQUFBLENBQUksR0FBR0osUUFBUTtJQUM1Qjs7RUFHS0osU0FBU0csUUFBQSxHQUFXLE9BQUs7SUFDL0IsSUFBSSxDQUFDLEtBQUtQLFNBQUEsRUFBVztNQUVuQjtJQUNEO0lBRUQsTUFBTVEsUUFBQSxHQUFXLEtBQUtGLFdBQUEsQ0FBWUMsUUFBUTtJQUMxQyxLQUFLTixPQUFBLEdBQVVyRSxVQUFBLENBQVcsWUFBVztNQUNuQyxNQUFNLEtBQUtpRixTQUFBLENBQVM7T0FDbkJMLFFBQVE7O0VBR0wsTUFBTUssVUFBQSxFQUFTO0lBQ3JCLElBQUk7TUFDRixNQUFNLEtBQUs3QyxJQUFBLENBQUtsVyxVQUFBLENBQVcsSUFBSTtJQUNoQyxTQUFRZ1QsQ0FBQSxFQUFQO01BRUEsS0FDR0EsQ0FBQSxLQUFtQixRQUFuQkEsQ0FBQSx1QkFBQUEsQ0FBQSxDQUFxQnpHLElBQUEsTUFDdEIsUUFBUSw0QkFDUjtRQUNBLEtBQUsrTCxRQUFBLENBQXdCLElBQUk7TUFDbEM7TUFFRDtJQUNEO0lBQ0QsS0FBS0EsUUFBQSxDQUFROztBQUVoQjtJQ3JGWVUsWUFBQSxTQUFZO0VBSXZCNUwsWUFDVTZMLFNBQUEsRUFDQUMsV0FBQSxFQUE2QjtJQUQ3QixLQUFTRCxTQUFBLEdBQVRBLFNBQUE7SUFDQSxLQUFXQyxXQUFBLEdBQVhBLFdBQUE7SUFFUixLQUFLQyxlQUFBLENBQWU7O0VBR2RBLGdCQUFBLEVBQWU7SUFDckIsS0FBS0MsY0FBQSxHQUFpQjFELHdCQUFBLENBQXlCLEtBQUt3RCxXQUFXO0lBQy9ELEtBQUtHLFlBQUEsR0FBZTNELHdCQUFBLENBQXlCLEtBQUt1RCxTQUFTOztFQUc3REssTUFBTUMsUUFBQSxFQUFzQjtJQUMxQixLQUFLTixTQUFBLEdBQVlNLFFBQUEsQ0FBU04sU0FBQTtJQUMxQixLQUFLQyxXQUFBLEdBQWNLLFFBQUEsQ0FBU0wsV0FBQTtJQUM1QixLQUFLQyxlQUFBLENBQWU7O0VBR3RCSyxPQUFBLEVBQU07SUFDSixPQUFPO01BQ0xQLFNBQUEsRUFBVyxLQUFLQSxTQUFBO01BQ2hCQyxXQUFBLEVBQWEsS0FBS0E7OztBQUd2QjtBQ25CTSxlQUFlTyxxQkFBcUJ2RCxJQUFBLEVBQWtCOztFQUMzRCxNQUFNNUosSUFBQSxHQUFPNEosSUFBQSxDQUFLNUosSUFBQTtFQUNsQixNQUFNb04sT0FBQSxHQUFVLE1BQU14RCxJQUFBLENBQUtsVyxVQUFBLENBQVU7RUFDckMsTUFBTXNRLFFBQUEsR0FBVyxNQUFNdUgsb0JBQUEsQ0FDckIzQixJQUFBLEVBQ0FULGNBQUEsQ0FBZW5KLElBQUEsRUFBTTtJQUFFb047RUFBTyxDQUFFLENBQUM7RUFHbkNsTSxPQUFBLENBQVE4QyxRQUFBLGFBQUFBLFFBQUEsdUJBQUFBLFFBQUEsQ0FBVXFKLEtBQUEsQ0FBTTNFLE1BQUEsRUFBUTFJLElBQUEsRUFBSTtFQUVwQyxNQUFNc04sV0FBQSxHQUFjdEosUUFBQSxDQUFTcUosS0FBQSxDQUFNO0VBRW5DekQsSUFBQSxDQUFLMkQscUJBQUEsQ0FBc0JELFdBQVc7RUFFdEMsTUFBTUUsZUFBQSxLQUFrQjlMLEVBQUEsR0FBQTRMLFdBQUEsQ0FBWUcsZ0JBQUEsTUFBZ0IsUUFBQS9MLEVBQUEsdUJBQUFBLEVBQUEsQ0FBRWdILE1BQUEsSUFDbERnRixtQkFBQSxDQUFvQkosV0FBQSxDQUFZRyxnQkFBZ0IsSUFDaEQ7RUFFSixNQUFNRSxZQUFBLEdBQWVDLGlCQUFBLENBQWtCaEUsSUFBQSxDQUFLK0QsWUFBQSxFQUFjSCxlQUFlO0VBT3pFLE1BQU1LLGNBQUEsR0FBaUJqRSxJQUFBLENBQUtrRSxXQUFBO0VBQzVCLE1BQU1DLGNBQUEsR0FDSixFQUFFbkUsSUFBQSxDQUFLakMsS0FBQSxJQUFTMkYsV0FBQSxDQUFZVSxZQUFBLEtBQWlCLEVBQUNMLFlBQUEsYUFBQUEsWUFBQSxLQUFZLGtCQUFaQSxZQUFBLENBQWNqRixNQUFBO0VBQzlELE1BQU1vRixXQUFBLEdBQWMsQ0FBQ0QsY0FBQSxHQUFpQixRQUFRRSxjQUFBO0VBRTlDLE1BQU1FLE9BQUEsR0FBaUM7SUFDckNDLEdBQUEsRUFBS1osV0FBQSxDQUFZYSxPQUFBO0lBQ2pCQyxXQUFBLEVBQWFkLFdBQUEsQ0FBWWMsV0FBQSxJQUFlO0lBQ3hDQyxRQUFBLEVBQVVmLFdBQUEsQ0FBWWdCLFFBQUEsSUFBWTtJQUNsQzNHLEtBQUEsRUFBTzJGLFdBQUEsQ0FBWTNGLEtBQUEsSUFBUztJQUM1QjRHLGFBQUEsRUFBZWpCLFdBQUEsQ0FBWWlCLGFBQUEsSUFBaUI7SUFDNUMzRyxXQUFBLEVBQWEwRixXQUFBLENBQVkxRixXQUFBLElBQWU7SUFDeEN0RCxRQUFBLEVBQVVnSixXQUFBLENBQVloSixRQUFBLElBQVk7SUFDbENxSixZQUFBO0lBQ0FWLFFBQUEsRUFBVSxJQUFJUCxZQUFBLENBQWFZLFdBQUEsQ0FBWVgsU0FBQSxFQUFXVyxXQUFBLENBQVlWLFdBQVc7SUFDekVrQjs7RUFHRjFOLE1BQUEsQ0FBT0MsTUFBQSxDQUFPdUosSUFBQSxFQUFNcUUsT0FBTztBQUM3QjtBQVNPLGVBQWVqWixPQUFPNFUsSUFBQSxFQUFVO0VBQ3JDLE1BQU1HLFlBQUEsT0FBNkI5UixXQUFBLENBQUE2UixrQkFBQSxFQUFtQkYsSUFBSTtFQUMxRCxNQUFNdUQsb0JBQUEsQ0FBcUJwRCxZQUFZO0VBS3ZDLE1BQU1BLFlBQUEsQ0FBYS9KLElBQUEsQ0FBS3dPLHFCQUFBLENBQXNCekUsWUFBWTtFQUMxREEsWUFBQSxDQUFhL0osSUFBQSxDQUFLeU8seUJBQUEsQ0FBMEIxRSxZQUFZO0FBQzFEO0FBRUEsU0FBUzZELGtCQUNQYyxRQUFBLEVBQ0FDLE9BQUEsRUFBbUI7RUFFbkIsTUFBTUMsT0FBQSxHQUFVRixRQUFBLENBQVNHLE1BQUEsQ0FDdkJDLENBQUEsSUFBSyxDQUFDSCxPQUFBLENBQVFJLElBQUEsQ0FBS0MsQ0FBQSxJQUFLQSxDQUFBLENBQUVDLFVBQUEsS0FBZUgsQ0FBQSxDQUFFRyxVQUFVLENBQUM7RUFFeEQsT0FBTyxDQUFDLEdBQUdMLE9BQUEsRUFBUyxHQUFHRCxPQUFPO0FBQ2hDO0FBRUEsU0FBU2pCLG9CQUFvQndCLFNBQUEsRUFBNkI7RUFDeEQsT0FBT0EsU0FBQSxDQUFVQyxHQUFBLENBQUt6TixFQUFBLElBQStCO0lBQS9CO1FBQUV1TjtNQUFVLElBQWV2TixFQUFBO01BQVZpSCxRQUFBLE9BQVF5RyxZQUFBLENBQUFDLE1BQUEsRUFBQTNOLEVBQUEsRUFBekIsY0FBMkI7SUFDL0MsT0FBTztNQUNMdU4sVUFBQTtNQUNBZixHQUFBLEVBQUt2RixRQUFBLENBQVMyRyxLQUFBLElBQVM7TUFDdkJsQixXQUFBLEVBQWF6RixRQUFBLENBQVN5RixXQUFBLElBQWU7TUFDckN6RyxLQUFBLEVBQU9nQixRQUFBLENBQVNoQixLQUFBLElBQVM7TUFDekJDLFdBQUEsRUFBYWUsUUFBQSxDQUFTZixXQUFBLElBQWU7TUFDckN5RyxRQUFBLEVBQVUxRixRQUFBLENBQVMyRixRQUFBLElBQVk7O0VBRW5DLENBQUM7QUFDSDtBQ3JETyxlQUFlaUIsZ0JBQ3BCdlAsSUFBQSxFQUNBd1AsWUFBQSxFQUFvQjtFQUVwQixNQUFNeEwsUUFBQSxHQUNKLE1BQU1VLDhCQUFBLENBQ0oxRSxJQUFBLEVBQ0EsSUFDQSxZQUFXO0lBQ1QsTUFBTTJFLElBQUEsT0FBTzFNLFdBQUEsQ0FBQStNLFdBQUEsRUFBWTtNQUN2QixjQUFjO01BQ2QsaUJBQWlCd0s7SUFDbEIsR0FBRXhPLEtBQUEsQ0FBTSxDQUFDO0lBQ1YsTUFBTTtNQUFFeU8sWUFBQTtNQUFjdks7SUFBTSxJQUFLbEYsSUFBQSxDQUFLa0QsTUFBQTtJQUN0QyxNQUFNRyxHQUFBLEdBQU1nQyxlQUFBLENBQ1ZyRixJQUFBLEVBQ0F5UCxZQUFBLEVBQVksYUFFWixPQUFPdkssTUFBQSxFQUFRO0lBR2pCLE1BQU1wQixPQUFBLEdBQVUsTUFBTzlELElBQUEsQ0FBc0JtRixxQkFBQSxDQUFxQjtJQUNsRXJCLE9BQUEsQ0FBTyxrQkFBNEI7SUFFbkMsT0FBT1AsYUFBQSxDQUFjSyxLQUFBLENBQUssRUFBR1AsR0FBQSxFQUFLO01BQ2hDbUIsTUFBQSxFQUF1QjtNQUN2QlYsT0FBQTtNQUNBYTtJQUNEO0VBQ0gsQ0FBQztFQUlMLE9BQU87SUFDTCtLLFdBQUEsRUFBYTFMLFFBQUEsQ0FBUzJMLFlBQUE7SUFDdEJDLFNBQUEsRUFBVzVMLFFBQUEsQ0FBUzZMLFVBQUE7SUFDcEJMLFlBQUEsRUFBY3hMLFFBQUEsQ0FBUzhMOztBQUUzQjtBQUVPLGVBQWVDLFlBQ3BCL1AsSUFBQSxFQUNBcUUsT0FBQSxFQUEyQjtFQUUzQixPQUFPRSxrQkFBQSxDQUNMdkUsSUFBQSxFQUdBLG9DQUFBb0Usa0JBQUEsQ0FBbUJwRSxJQUFBLEVBQU1xRSxPQUFPLENBQUM7QUFFckM7SUN4RWEyTCxlQUFBLFNBQWU7RUFBNUJsUCxZQUFBO0lBQ0UsS0FBWTBPLFlBQUEsR0FBa0I7SUFDOUIsS0FBV0UsV0FBQSxHQUFrQjtJQUM3QixLQUFjL0UsY0FBQSxHQUFrQjs7RUFFaEMsSUFBSXNGLFVBQUEsRUFBUztJQUNYLE9BQ0UsQ0FBQyxLQUFLdEYsY0FBQSxJQUNOcEIsSUFBQSxDQUFLZ0QsR0FBQSxDQUFHLElBQUssS0FBSzVCLGNBQUEsR0FBcUM7O0VBSTNEdUYseUJBQ0VsTSxRQUFBLEVBQStDO0lBRS9DOUMsT0FBQSxDQUFROEMsUUFBQSxDQUFTb0osT0FBQSxFQUFPO0lBQ3hCbE0sT0FBQSxDQUNFLE9BQU84QyxRQUFBLENBQVNvSixPQUFBLEtBQVksYUFBVztJQUd6Q2xNLE9BQUEsQ0FDRSxPQUFPOEMsUUFBQSxDQUFTd0wsWUFBQSxLQUFpQixhQUFXO0lBRzlDLE1BQU1JLFNBQUEsR0FDSixlQUFlNUwsUUFBQSxJQUFZLE9BQU9BLFFBQUEsQ0FBUzRMLFNBQUEsS0FBYyxjQUNyRHBHLE1BQUEsQ0FBT3hGLFFBQUEsQ0FBUzRMLFNBQVMsSUFDekJ2RSxlQUFBLENBQWdCckgsUUFBQSxDQUFTb0osT0FBTztJQUN0QyxLQUFLK0MseUJBQUEsQ0FDSG5NLFFBQUEsQ0FBU29KLE9BQUEsRUFDVHBKLFFBQUEsQ0FBU3dMLFlBQUEsRUFDVEksU0FBUzs7RUFJYixNQUFNUSxTQUNKcFEsSUFBQSxFQUNBNkosWUFBQSxHQUFlLE9BQUs7SUFFcEIzSSxPQUFBLENBQ0UsQ0FBQyxLQUFLd08sV0FBQSxJQUFlLEtBQUtGLFlBQUEsRUFDMUJ4UCxJQUFBLEVBQUk7SUFJTixJQUFJLENBQUM2SixZQUFBLElBQWdCLEtBQUs2RixXQUFBLElBQWUsQ0FBQyxLQUFLTyxTQUFBLEVBQVc7TUFDeEQsT0FBTyxLQUFLUCxXQUFBO0lBQ2I7SUFFRCxJQUFJLEtBQUtGLFlBQUEsRUFBYztNQUNyQixNQUFNLEtBQUthLE9BQUEsQ0FBUXJRLElBQUEsRUFBTSxLQUFLd1AsWUFBYTtNQUMzQyxPQUFPLEtBQUtFLFdBQUE7SUFDYjtJQUVELE9BQU87O0VBR1RZLGtCQUFBLEVBQWlCO0lBQ2YsS0FBS2QsWUFBQSxHQUFlOztFQUdkLE1BQU1hLFFBQVFyUSxJQUFBLEVBQW9CdVEsUUFBQSxFQUFnQjtJQUN4RCxNQUFNO01BQUViLFdBQUE7TUFBYUYsWUFBQTtNQUFjSTtJQUFTLElBQUssTUFBTUwsZUFBQSxDQUNyRHZQLElBQUEsRUFDQXVRLFFBQVE7SUFFVixLQUFLSix5QkFBQSxDQUNIVCxXQUFBLEVBQ0FGLFlBQUEsRUFDQWhHLE1BQUEsQ0FBT29HLFNBQVMsQ0FBQzs7RUFJYk8sMEJBQ05ULFdBQUEsRUFDQUYsWUFBQSxFQUNBZ0IsWUFBQSxFQUFvQjtJQUVwQixLQUFLaEIsWUFBQSxHQUFlQSxZQUFBLElBQWdCO0lBQ3BDLEtBQUtFLFdBQUEsR0FBY0EsV0FBQSxJQUFlO0lBQ2xDLEtBQUsvRSxjQUFBLEdBQWlCcEIsSUFBQSxDQUFLZ0QsR0FBQSxDQUFHLElBQUtpRSxZQUFBLEdBQWU7O0VBR3BELE9BQU9DLFNBQVNqUSxPQUFBLEVBQWlCRyxNQUFBLEVBQXFCO0lBQ3BELE1BQU07TUFBRTZPLFlBQUE7TUFBY0UsV0FBQTtNQUFhL0U7SUFBYyxJQUFLaEssTUFBQTtJQUV0RCxNQUFNK1AsT0FBQSxHQUFVLElBQUlWLGVBQUEsQ0FBZTtJQUNuQyxJQUFJUixZQUFBLEVBQWM7TUFDaEJ0TyxPQUFBLENBQVEsT0FBT3NPLFlBQUEsS0FBaUIsVUFBd0M7UUFDdEVoUDtNQUNEO01BQ0RrUSxPQUFBLENBQVFsQixZQUFBLEdBQWVBLFlBQUE7SUFDeEI7SUFDRCxJQUFJRSxXQUFBLEVBQWE7TUFDZnhPLE9BQUEsQ0FBUSxPQUFPd08sV0FBQSxLQUFnQixVQUF3QztRQUNyRWxQO01BQ0Q7TUFDRGtRLE9BQUEsQ0FBUWhCLFdBQUEsR0FBY0EsV0FBQTtJQUN2QjtJQUNELElBQUkvRSxjQUFBLEVBQWdCO01BQ2xCekosT0FBQSxDQUNFLE9BQU95SixjQUFBLEtBQW1CLFVBRTFCO1FBQ0VuSztNQUNEO01BRUhrUSxPQUFBLENBQVEvRixjQUFBLEdBQWlCQSxjQUFBO0lBQzFCO0lBQ0QsT0FBTytGLE9BQUE7O0VBR1R4RCxPQUFBLEVBQU07SUFDSixPQUFPO01BQ0xzQyxZQUFBLEVBQWMsS0FBS0EsWUFBQTtNQUNuQkUsV0FBQSxFQUFhLEtBQUtBLFdBQUE7TUFDbEIvRSxjQUFBLEVBQWdCLEtBQUtBOzs7RUFJekJnRyxRQUFRckUsZUFBQSxFQUFnQztJQUN0QyxLQUFLb0QsV0FBQSxHQUFjcEQsZUFBQSxDQUFnQm9ELFdBQUE7SUFDbkMsS0FBS0YsWUFBQSxHQUFlbEQsZUFBQSxDQUFnQmtELFlBQUE7SUFDcEMsS0FBSzdFLGNBQUEsR0FBaUIyQixlQUFBLENBQWdCM0IsY0FBQTs7RUFHeENpRyxPQUFBLEVBQU07SUFDSixPQUFPeFEsTUFBQSxDQUFPQyxNQUFBLENBQU8sSUFBSTJQLGVBQUEsQ0FBZSxHQUFJLEtBQUs5QyxNQUFBLENBQU0sQ0FBRTs7RUFHM0QyRCxnQkFBQSxFQUFlO0lBQ2IsT0FBT3pQLFNBQUEsQ0FBVSxpQkFBaUI7O0FBRXJDO0FDbElELFNBQVMwUCx3QkFDUDNQLFNBQUEsRUFDQVgsT0FBQSxFQUFlO0VBRWZVLE9BQUEsQ0FDRSxPQUFPQyxTQUFBLEtBQWMsWUFBWSxPQUFPQSxTQUFBLEtBQWMsYUFFdEQ7SUFBRVg7RUFBTyxDQUFFO0FBRWY7SUFFYXVRLFFBQUEsU0FBUTtFQXdCbkJqUSxZQUFZWSxFQUFBLEVBQXNEO1FBQXREO1FBQUV3TSxHQUFBO1FBQUtsTyxJQUFBO1FBQU1zTTtNQUFlLElBQUE1SyxFQUFBO01BQUtzUCxHQUFBLE9BQWpDNUIsWUFBQSxDQUFBQyxNQUFBLEVBQUEzTixFQUFBLG9DQUFzQztJQXRCekMsS0FBQXVOLFVBQUEsR0FBaUM7SUFvQnpCLEtBQUFnQyxnQkFBQSxHQUFtQixJQUFJdEYsZ0JBQUEsQ0FBaUIsSUFBSTtJQTZDckQsS0FBY3VGLGNBQUEsR0FBdUI7SUFDckMsS0FBY0MsY0FBQSxHQUErQjtJQTNDbkQsS0FBS2pELEdBQUEsR0FBTUEsR0FBQTtJQUNYLEtBQUtsTyxJQUFBLEdBQU9BLElBQUE7SUFDWixLQUFLc00sZUFBQSxHQUFrQkEsZUFBQTtJQUN2QixLQUFLb0QsV0FBQSxHQUFjcEQsZUFBQSxDQUFnQm9ELFdBQUE7SUFDbkMsS0FBS3RCLFdBQUEsR0FBYzRDLEdBQUEsQ0FBSTVDLFdBQUEsSUFBZTtJQUN0QyxLQUFLekcsS0FBQSxHQUFRcUosR0FBQSxDQUFJckosS0FBQSxJQUFTO0lBQzFCLEtBQUs0RyxhQUFBLEdBQWdCeUMsR0FBQSxDQUFJekMsYUFBQSxJQUFpQjtJQUMxQyxLQUFLM0csV0FBQSxHQUFjb0osR0FBQSxDQUFJcEosV0FBQSxJQUFlO0lBQ3RDLEtBQUt5RyxRQUFBLEdBQVcyQyxHQUFBLENBQUkzQyxRQUFBLElBQVk7SUFDaEMsS0FBS1AsV0FBQSxHQUFja0QsR0FBQSxDQUFJbEQsV0FBQSxJQUFlO0lBQ3RDLEtBQUt4SixRQUFBLEdBQVcwTSxHQUFBLENBQUkxTSxRQUFBLElBQVk7SUFDaEMsS0FBS3FKLFlBQUEsR0FBZXFELEdBQUEsQ0FBSXJELFlBQUEsR0FBZSxDQUFDLEdBQUdxRCxHQUFBLENBQUlyRCxZQUFZLElBQUk7SUFDL0QsS0FBS1YsUUFBQSxHQUFXLElBQUlQLFlBQUEsQ0FDbEJzRSxHQUFBLENBQUlyRSxTQUFBLElBQWEsUUFDakJxRSxHQUFBLENBQUlwRSxXQUFBLElBQWUsTUFBUzs7RUFJaEMsTUFBTWxaLFdBQVdtVyxZQUFBLEVBQXNCO0lBQ3JDLE1BQU02RixXQUFBLEdBQWMsTUFBTW5FLG9CQUFBLENBQ3hCLE1BQ0EsS0FBS2UsZUFBQSxDQUFnQjhELFFBQUEsQ0FBUyxLQUFLcFEsSUFBQSxFQUFNNkosWUFBWSxDQUFDO0lBRXhEM0ksT0FBQSxDQUFRd08sV0FBQSxFQUFhLEtBQUsxUCxJQUFBLEVBQUk7SUFFOUIsSUFBSSxLQUFLMFAsV0FBQSxLQUFnQkEsV0FBQSxFQUFhO01BQ3BDLEtBQUtBLFdBQUEsR0FBY0EsV0FBQTtNQUNuQixNQUFNLEtBQUsxUCxJQUFBLENBQUt3TyxxQkFBQSxDQUFzQixJQUFJO01BQzFDLEtBQUt4TyxJQUFBLENBQUt5Tyx5QkFBQSxDQUEwQixJQUFJO0lBQ3pDO0lBRUQsT0FBT2lCLFdBQUE7O0VBR1QvYixpQkFBaUJrVyxZQUFBLEVBQXNCO0lBQ3JDLE9BQU9sVyxnQkFBQSxDQUFpQixNQUFNa1csWUFBWTs7RUFHNUM3VSxPQUFBLEVBQU07SUFDSixPQUFPQSxNQUFBLENBQU8sSUFBSTs7RUFNcEIyYixRQUFRL0csSUFBQSxFQUFrQjtJQUN4QixJQUFJLFNBQVNBLElBQUEsRUFBTTtNQUNqQjtJQUNEO0lBQ0QxSSxPQUFBLENBQVEsS0FBS2dOLEdBQUEsS0FBUXRFLElBQUEsQ0FBS3NFLEdBQUEsRUFBSyxLQUFLbE8sSUFBQSxFQUFJO0lBQ3hDLEtBQUtvTyxXQUFBLEdBQWN4RSxJQUFBLENBQUt3RSxXQUFBO0lBQ3hCLEtBQUtDLFFBQUEsR0FBV3pFLElBQUEsQ0FBS3lFLFFBQUE7SUFDckIsS0FBSzFHLEtBQUEsR0FBUWlDLElBQUEsQ0FBS2pDLEtBQUE7SUFDbEIsS0FBSzRHLGFBQUEsR0FBZ0IzRSxJQUFBLENBQUsyRSxhQUFBO0lBQzFCLEtBQUszRyxXQUFBLEdBQWNnQyxJQUFBLENBQUtoQyxXQUFBO0lBQ3hCLEtBQUtrRyxXQUFBLEdBQWNsRSxJQUFBLENBQUtrRSxXQUFBO0lBQ3hCLEtBQUt4SixRQUFBLEdBQVdzRixJQUFBLENBQUt0RixRQUFBO0lBQ3JCLEtBQUtxSixZQUFBLEdBQWUvRCxJQUFBLENBQUsrRCxZQUFBLENBQWF3QixHQUFBLENBQUlpQyxRQUFBLElBQVFoUixNQUFBLENBQUFDLE1BQUEsS0FBVStRLFFBQVEsQ0FBRztJQUN2RSxLQUFLbkUsUUFBQSxDQUFTRCxLQUFBLENBQU1wRCxJQUFBLENBQUtxRCxRQUFRO0lBQ2pDLEtBQUtYLGVBQUEsQ0FBZ0JxRSxPQUFBLENBQVEvRyxJQUFBLENBQUswQyxlQUFlOztFQUduRHNFLE9BQU81USxJQUFBLEVBQWtCO0lBQ3ZCLE1BQU1xUixPQUFBLEdBQVUsSUFBSU4sUUFBQSxDQUNmM1EsTUFBQSxDQUFBQyxNQUFBLENBQUFELE1BQUEsQ0FBQUMsTUFBQSxTQUFJO01BQ1BMLElBQUE7TUFDQXNNLGVBQUEsRUFBaUIsS0FBS0EsZUFBQSxDQUFnQnNFLE1BQUEsQ0FBTTtJQUFFO0lBRWhEUyxPQUFBLENBQVFwRSxRQUFBLENBQVNELEtBQUEsQ0FBTSxLQUFLQyxRQUFRO0lBQ3BDLE9BQU9vRSxPQUFBOztFQUdUQyxVQUFVQyxRQUFBLEVBQTZCO0lBRXJDclEsT0FBQSxDQUFRLENBQUMsS0FBS2lRLGNBQUEsRUFBZ0IsS0FBS25SLElBQUEsRUFBSTtJQUN2QyxLQUFLbVIsY0FBQSxHQUFpQkksUUFBQTtJQUN0QixJQUFJLEtBQUtMLGNBQUEsRUFBZ0I7TUFDdkIsS0FBSzNELHFCQUFBLENBQXNCLEtBQUsyRCxjQUFjO01BQzlDLEtBQUtBLGNBQUEsR0FBaUI7SUFDdkI7O0VBR0gzRCxzQkFBc0I2RCxRQUFBLEVBQXFCO0lBQ3pDLElBQUksS0FBS0QsY0FBQSxFQUFnQjtNQUN2QixLQUFLQSxjQUFBLENBQWVDLFFBQVE7SUFDN0IsT0FBTTtNQUVMLEtBQUtGLGNBQUEsR0FBaUJFLFFBQUE7SUFDdkI7O0VBR0hJLHVCQUFBLEVBQXNCO0lBQ3BCLEtBQUtQLGdCQUFBLENBQWlCbEYsTUFBQSxDQUFNOztFQUc5QjBGLHNCQUFBLEVBQXFCO0lBQ25CLEtBQUtSLGdCQUFBLENBQWlCaEYsS0FBQSxDQUFLOztFQUc3QixNQUFNeUYseUJBQ0oxTixRQUFBLEVBQ0EyTixPQUFBLEdBQVMsT0FBSztJQUVkLElBQUlDLGVBQUEsR0FBa0I7SUFDdEIsSUFDRTVOLFFBQUEsQ0FBU29KLE9BQUEsSUFDVHBKLFFBQUEsQ0FBU29KLE9BQUEsS0FBWSxLQUFLZCxlQUFBLENBQWdCb0QsV0FBQSxFQUMxQztNQUNBLEtBQUtwRCxlQUFBLENBQWdCNEQsd0JBQUEsQ0FBeUJsTSxRQUFRO01BQ3RENE4sZUFBQSxHQUFrQjtJQUNuQjtJQUVELElBQUlELE9BQUEsRUFBUTtNQUNWLE1BQU14RSxvQkFBQSxDQUFxQixJQUFJO0lBQ2hDO0lBRUQsTUFBTSxLQUFLbk4sSUFBQSxDQUFLd08scUJBQUEsQ0FBc0IsSUFBSTtJQUMxQyxJQUFJb0QsZUFBQSxFQUFpQjtNQUNuQixLQUFLNVIsSUFBQSxDQUFLeU8seUJBQUEsQ0FBMEIsSUFBSTtJQUN6Qzs7RUFHSCxNQUFNb0QsT0FBQSxFQUFNO0lBQ1YsTUFBTXpFLE9BQUEsR0FBVSxNQUFNLEtBQUsxWixVQUFBLENBQVU7SUFDckMsTUFBTTZYLG9CQUFBLENBQXFCLE1BQU10QyxhQUFBLENBQWMsS0FBS2pKLElBQUEsRUFBTTtNQUFFb047SUFBTyxDQUFFLENBQUM7SUFDdEUsS0FBS2QsZUFBQSxDQUFnQmdFLGlCQUFBLENBQWlCO0lBS3RDLE9BQU8sS0FBS3RRLElBQUEsQ0FBS2xLLE9BQUEsQ0FBTzs7RUFHMUJvWCxPQUFBLEVBQU07SUFDSixPQUFBOU0sTUFBQSxDQUFBQyxNQUFBLENBQUFELE1BQUEsQ0FBQUMsTUFBQTtNQUNFNk4sR0FBQSxFQUFLLEtBQUtBLEdBQUE7TUFDVnZHLEtBQUEsRUFBTyxLQUFLQSxLQUFBLElBQVM7TUFDckI0RyxhQUFBLEVBQWUsS0FBS0EsYUFBQTtNQUNwQkgsV0FBQSxFQUFhLEtBQUtBLFdBQUEsSUFBZTtNQUNqQ04sV0FBQSxFQUFhLEtBQUtBLFdBQUE7TUFDbEJPLFFBQUEsRUFBVSxLQUFLQSxRQUFBLElBQVk7TUFDM0J6RyxXQUFBLEVBQWEsS0FBS0EsV0FBQSxJQUFlO01BQ2pDdEQsUUFBQSxFQUFVLEtBQUtBLFFBQUEsSUFBWTtNQUMzQnFKLFlBQUEsRUFBYyxLQUFLQSxZQUFBLENBQWF3QixHQUFBLENBQUlpQyxRQUFBLElBQVFoUixNQUFBLENBQUFDLE1BQUEsS0FBVStRLFFBQVEsQ0FBRztNQUNqRTlFLGVBQUEsRUFBaUIsS0FBS0EsZUFBQSxDQUFnQlksTUFBQSxDQUFNO01BRzVDNEUsZ0JBQUEsRUFBa0IsS0FBS0E7SUFBZ0IsR0FDcEMsS0FBSzdFLFFBQUEsQ0FBU0MsTUFBQSxDQUFNLENBQUU7TUFHekJoSSxNQUFBLEVBQVEsS0FBS2xGLElBQUEsQ0FBS2tELE1BQUEsQ0FBT2dDLE1BQUE7TUFDekIxRSxPQUFBLEVBQVMsS0FBS1IsSUFBQSxDQUFLUztJQUFJLENBR3ZCOztFQUdKLElBQUkrTyxhQUFBLEVBQVk7SUFDZCxPQUFPLEtBQUtsRCxlQUFBLENBQWdCa0QsWUFBQSxJQUFnQjs7RUFHOUMsT0FBT3VDLFVBQVUvUixJQUFBLEVBQW9CVyxNQUFBLEVBQXFCOztJQUN4RCxNQUFNeU4sV0FBQSxJQUFjMU0sRUFBQSxHQUFBZixNQUFBLENBQU95TixXQUFBLE1BQVcsUUFBQTFNLEVBQUEsY0FBQUEsRUFBQSxHQUFJO0lBQzFDLE1BQU1pRyxLQUFBLElBQVFxSyxFQUFBLEdBQUFyUixNQUFBLENBQU9nSCxLQUFBLE1BQUssUUFBQXFLLEVBQUEsY0FBQUEsRUFBQSxHQUFJO0lBQzlCLE1BQU1wSyxXQUFBLElBQWNxSyxFQUFBLEdBQUF0UixNQUFBLENBQU9pSCxXQUFBLE1BQVcsUUFBQXFLLEVBQUEsY0FBQUEsRUFBQSxHQUFJO0lBQzFDLE1BQU01RCxRQUFBLElBQVc2RCxFQUFBLEdBQUF2UixNQUFBLENBQU8wTixRQUFBLE1BQVEsUUFBQTZELEVBQUEsY0FBQUEsRUFBQSxHQUFJO0lBQ3BDLE1BQU01TixRQUFBLElBQVc2TixFQUFBLEdBQUF4UixNQUFBLENBQU8yRCxRQUFBLE1BQVEsUUFBQTZOLEVBQUEsY0FBQUEsRUFBQSxHQUFJO0lBQ3BDLE1BQU1MLGdCQUFBLElBQW1CTSxFQUFBLEdBQUF6UixNQUFBLENBQU9tUixnQkFBQSxNQUFnQixRQUFBTSxFQUFBLGNBQUFBLEVBQUEsR0FBSTtJQUNwRCxNQUFNekYsU0FBQSxJQUFZMEYsRUFBQSxHQUFBMVIsTUFBQSxDQUFPZ00sU0FBQSxNQUFTLFFBQUEwRixFQUFBLGNBQUFBLEVBQUEsR0FBSTtJQUN0QyxNQUFNekYsV0FBQSxJQUFjMEYsRUFBQSxHQUFBM1IsTUFBQSxDQUFPaU0sV0FBQSxNQUFXLFFBQUEwRixFQUFBLGNBQUFBLEVBQUEsR0FBSTtJQUMxQyxNQUFNO01BQ0pwRSxHQUFBO01BQ0FLLGFBQUE7TUFDQVQsV0FBQTtNQUNBSCxZQUFBO01BQ0FyQixlQUFBLEVBQWlCaUc7SUFBdUIsSUFDdEM1UixNQUFBO0lBRUpPLE9BQUEsQ0FBUWdOLEdBQUEsSUFBT3FFLHVCQUFBLEVBQXlCdlMsSUFBQSxFQUFJO0lBRTVDLE1BQU1zTSxlQUFBLEdBQWtCMEQsZUFBQSxDQUFnQlMsUUFBQSxDQUN0QyxLQUFLaFEsSUFBQSxFQUNMOFIsdUJBQXdDO0lBRzFDclIsT0FBQSxDQUFRLE9BQU9nTixHQUFBLEtBQVEsVUFBVWxPLElBQUEsRUFBSTtJQUNyQzhRLHVCQUFBLENBQXdCMUMsV0FBQSxFQUFhcE8sSUFBQSxDQUFLUyxJQUFJO0lBQzlDcVEsdUJBQUEsQ0FBd0JuSixLQUFBLEVBQU8zSCxJQUFBLENBQUtTLElBQUk7SUFDeENTLE9BQUEsQ0FDRSxPQUFPcU4sYUFBQSxLQUFrQixXQUN6QnZPLElBQUEsRUFBSTtJQUdOa0IsT0FBQSxDQUNFLE9BQU80TSxXQUFBLEtBQWdCLFdBQ3ZCOU4sSUFBQSxFQUFJO0lBR044USx1QkFBQSxDQUF3QmxKLFdBQUEsRUFBYTVILElBQUEsQ0FBS1MsSUFBSTtJQUM5Q3FRLHVCQUFBLENBQXdCekMsUUFBQSxFQUFVck8sSUFBQSxDQUFLUyxJQUFJO0lBQzNDcVEsdUJBQUEsQ0FBd0J4TSxRQUFBLEVBQVV0RSxJQUFBLENBQUtTLElBQUk7SUFDM0NxUSx1QkFBQSxDQUF3QmdCLGdCQUFBLEVBQWtCOVIsSUFBQSxDQUFLUyxJQUFJO0lBQ25EcVEsdUJBQUEsQ0FBd0JuRSxTQUFBLEVBQVczTSxJQUFBLENBQUtTLElBQUk7SUFDNUNxUSx1QkFBQSxDQUF3QmxFLFdBQUEsRUFBYTVNLElBQUEsQ0FBS1MsSUFBSTtJQUM5QyxNQUFNbUosSUFBQSxHQUFPLElBQUltSCxRQUFBLENBQVM7TUFDeEI3QyxHQUFBO01BQ0FsTyxJQUFBO01BQ0EySCxLQUFBO01BQ0E0RyxhQUFBO01BQ0FILFdBQUE7TUFDQU4sV0FBQTtNQUNBTyxRQUFBO01BQ0F6RyxXQUFBO01BQ0F0RCxRQUFBO01BQ0FnSSxlQUFBO01BQ0FLLFNBQUE7TUFDQUM7SUFDRDtJQUVELElBQUllLFlBQUEsSUFBZ0I2RSxLQUFBLENBQU1DLE9BQUEsQ0FBUTlFLFlBQVksR0FBRztNQUMvQy9ELElBQUEsQ0FBSytELFlBQUEsR0FBZUEsWUFBQSxDQUFhd0IsR0FBQSxDQUFJaUMsUUFBQSxJQUFZaFIsTUFBQSxDQUFBQyxNQUFBLEtBQU0rUSxRQUFRLENBQUc7SUFDbkU7SUFFRCxJQUFJVSxnQkFBQSxFQUFrQjtNQUNwQmxJLElBQUEsQ0FBS2tJLGdCQUFBLEdBQW1CQSxnQkFBQTtJQUN6QjtJQUVELE9BQU9sSSxJQUFBOztFQVFULGFBQWE4SSxxQkFDWDFTLElBQUEsRUFDQTJTLGVBQUEsRUFDQTdFLFdBQUEsR0FBdUIsT0FBSztJQUU1QixNQUFNeEIsZUFBQSxHQUFrQixJQUFJMEQsZUFBQSxDQUFlO0lBQzNDMUQsZUFBQSxDQUFnQjRELHdCQUFBLENBQXlCeUMsZUFBZTtJQUd4RCxNQUFNL0ksSUFBQSxHQUFPLElBQUltSCxRQUFBLENBQVM7TUFDeEI3QyxHQUFBLEVBQUt5RSxlQUFBLENBQWdCeEUsT0FBQTtNQUNyQm5PLElBQUE7TUFDQXNNLGVBQUE7TUFDQXdCO0lBQ0Q7SUFHRCxNQUFNWCxvQkFBQSxDQUFxQnZELElBQUk7SUFDL0IsT0FBT0EsSUFBQTs7QUFFVjtBQ2pURCxJQUFNZ0osYUFBQSxHQUF1QyxtQkFBSUMsR0FBQSxDQUFHO0FBRTlDLFNBQVVDLGFBQWdCQyxHQUFBLEVBQVk7RUFDMUN4UixXQUFBLENBQVl3UixHQUFBLFlBQWVDLFFBQUEsRUFBVSw2QkFBNkI7RUFDbEUsSUFBSXBTLFFBQUEsR0FBV2dTLGFBQUEsQ0FBYzlQLEdBQUEsQ0FBSWlRLEdBQUc7RUFFcEMsSUFBSW5TLFFBQUEsRUFBVTtJQUNaVyxXQUFBLENBQ0VYLFFBQUEsWUFBb0JtUyxHQUFBLEVBQ3BCLGdEQUFnRDtJQUVsRCxPQUFPblMsUUFBQTtFQUNSO0VBRURBLFFBQUEsR0FBVyxJQUFLbVMsR0FBQSxDQUFnQztFQUNoREgsYUFBQSxDQUFjSyxHQUFBLENBQUlGLEdBQUEsRUFBS25TLFFBQVE7RUFDL0IsT0FBT0EsUUFBQTtBQUNUO0lDckJhc1MsbUJBQUEsU0FBbUI7RUFBaENwUyxZQUFBO0lBRVcsS0FBQXFTLElBQUEsR0FBNEI7SUFDckMsS0FBT0MsT0FBQSxHQUFxQzs7RUFFNUMsTUFBTUMsYUFBQSxFQUFZO0lBQ2hCLE9BQU87O0VBR1QsTUFBTUMsS0FBS3JPLEdBQUEsRUFBYXNPLEtBQUEsRUFBdUI7SUFDN0MsS0FBS0gsT0FBQSxDQUFRbk8sR0FBQSxJQUFPc08sS0FBQTs7RUFHdEIsTUFBTUMsS0FBaUN2TyxHQUFBLEVBQVc7SUFDaEQsTUFBTXNPLEtBQUEsR0FBUSxLQUFLSCxPQUFBLENBQVFuTyxHQUFBO0lBQzNCLE9BQU9zTyxLQUFBLEtBQVUsU0FBWSxPQUFRQSxLQUFBOztFQUd2QyxNQUFNRSxRQUFReE8sR0FBQSxFQUFXO0lBQ3ZCLE9BQU8sS0FBS21PLE9BQUEsQ0FBUW5PLEdBQUE7O0VBR3RCeU8sYUFBYUMsSUFBQSxFQUFjQyxTQUFBLEVBQStCO0lBRXhEOztFQUdGQyxnQkFBZ0JGLElBQUEsRUFBY0MsU0FBQSxFQUErQjtJQUUzRDs7O0FBNUJLVixtQkFBQSxDQUFJQyxJQUFBLEdBQVc7QUFxQ2pCLElBQU1yZixtQkFBQSxHQUFtQ29mLG1CQUFBO1NDOUJoQ1ksb0JBQ2Q3TyxHQUFBLEVBQ0FDLE1BQUEsRUFDQTFFLE9BQUEsRUFBZ0I7RUFFaEIsT0FBTyxHQUFHLGNBQXlCeUUsR0FBQSxJQUFPQyxNQUFBLElBQVUxRSxPQUFBO0FBQ3REO0lBRWF1VCxzQkFBQSxTQUFzQjtFQUtqQ2pULFlBQ1NrVCxXQUFBLEVBQ1VoVSxJQUFBLEVBQ0FpVSxPQUFBLEVBQWU7SUFGekIsS0FBV0QsV0FBQSxHQUFYQSxXQUFBO0lBQ1UsS0FBSWhVLElBQUEsR0FBSkEsSUFBQTtJQUNBLEtBQU9pVSxPQUFBLEdBQVBBLE9BQUE7SUFFakIsTUFBTTtNQUFFL1EsTUFBQTtNQUFRekMsSUFBQSxFQUFBeVQ7SUFBSSxJQUFLLEtBQUtsVSxJQUFBO0lBQzlCLEtBQUttVSxXQUFBLEdBQWNMLG1CQUFBLENBQW9CLEtBQUtHLE9BQUEsRUFBUy9RLE1BQUEsQ0FBT2dDLE1BQUEsRUFBUWdQLEtBQUk7SUFDeEUsS0FBS0Usa0JBQUEsR0FBcUJOLG1CQUFBLENBQW1CLGVBRTNDNVEsTUFBQSxDQUFPZ0MsTUFBQSxFQUNQZ1AsS0FBSTtJQUVOLEtBQUtHLGlCQUFBLEdBQW9CclUsSUFBQSxDQUFLc1UsZUFBQSxDQUFnQkMsSUFBQSxDQUFLdlUsSUFBSTtJQUN2RCxLQUFLZ1UsV0FBQSxDQUFZTixZQUFBLENBQWEsS0FBS1MsV0FBQSxFQUFhLEtBQUtFLGlCQUFpQjs7RUFHeEVHLGVBQWU1SyxJQUFBLEVBQWtCO0lBQy9CLE9BQU8sS0FBS29LLFdBQUEsQ0FBWVYsSUFBQSxDQUFLLEtBQUthLFdBQUEsRUFBYXZLLElBQUEsQ0FBS3NELE1BQUEsQ0FBTSxDQUFFOztFQUc5RCxNQUFNdUgsZUFBQSxFQUFjO0lBQ2xCLE1BQU1DLElBQUEsR0FBTyxNQUFNLEtBQUtWLFdBQUEsQ0FBWVIsSUFBQSxDQUFvQixLQUFLVyxXQUFXO0lBQ3hFLE9BQU9PLElBQUEsR0FBTzNELFFBQUEsQ0FBU2dCLFNBQUEsQ0FBVSxLQUFLL1IsSUFBQSxFQUFNMFUsSUFBSSxJQUFJOztFQUd0REMsa0JBQUEsRUFBaUI7SUFDZixPQUFPLEtBQUtYLFdBQUEsQ0FBWVAsT0FBQSxDQUFRLEtBQUtVLFdBQVc7O0VBR2xEUywyQkFBQSxFQUEwQjtJQUN4QixPQUFPLEtBQUtaLFdBQUEsQ0FBWVYsSUFBQSxDQUN0QixLQUFLYyxrQkFBQSxFQUNMLEtBQUtKLFdBQUEsQ0FBWWIsSUFBSTs7RUFJekIsTUFBTTlkLGVBQWV3ZixjQUFBLEVBQW1DO0lBQ3RELElBQUksS0FBS2IsV0FBQSxLQUFnQmEsY0FBQSxFQUFnQjtNQUN2QztJQUNEO0lBRUQsTUFBTW5KLFdBQUEsR0FBYyxNQUFNLEtBQUsrSSxjQUFBLENBQWM7SUFDN0MsTUFBTSxLQUFLRSxpQkFBQSxDQUFpQjtJQUU1QixLQUFLWCxXQUFBLEdBQWNhLGNBQUE7SUFFbkIsSUFBSW5KLFdBQUEsRUFBYTtNQUNmLE9BQU8sS0FBSzhJLGNBQUEsQ0FBZTlJLFdBQVc7SUFDdkM7O0VBR0htRyxPQUFBLEVBQU07SUFDSixLQUFLbUMsV0FBQSxDQUFZSCxlQUFBLENBQWdCLEtBQUtNLFdBQUEsRUFBYSxLQUFLRSxpQkFBaUI7O0VBRzNFLGFBQWE5VCxPQUNYUCxJQUFBLEVBQ0E4VSxvQkFBQSxFQUNBYixPQUFBLEdBQTJCO0lBRTNCLElBQUksQ0FBQ2Esb0JBQUEsQ0FBcUJwTSxNQUFBLEVBQVE7TUFDaEMsT0FBTyxJQUFJcUwsc0JBQUEsQ0FDVGpCLFlBQUEsQ0FBYWhmLG1CQUFtQixHQUNoQ2tNLElBQUEsRUFDQWlVLE9BQU87SUFFVjtJQUdELE1BQU1jLHFCQUFBLElBQ0osTUFBTW5QLE9BQUEsQ0FBUW9QLEdBQUEsQ0FDWkYsb0JBQUEsQ0FBcUIzRixHQUFBLENBQUksTUFBTTZFLFdBQUEsSUFBYztNQUMzQyxJQUFJLE1BQU1BLFdBQUEsQ0FBWVgsWUFBQSxDQUFZLEdBQUk7UUFDcEMsT0FBT1csV0FBQTtNQUNSO01BQ0QsT0FBTztJQUNULENBQUMsQ0FBQyxHQUVKbkYsTUFBQSxDQUFPbUYsV0FBQSxJQUFlQSxXQUFXO0lBR25DLElBQUlpQixtQkFBQSxHQUNGRixxQkFBQSxDQUFzQixNQUN0QmpDLFlBQUEsQ0FBa0NoZixtQkFBbUI7SUFFdkQsTUFBTW1SLEdBQUEsR0FBTTZPLG1CQUFBLENBQW9CRyxPQUFBLEVBQVNqVSxJQUFBLENBQUtrRCxNQUFBLENBQU9nQyxNQUFBLEVBQVFsRixJQUFBLENBQUtTLElBQUk7SUFJdEUsSUFBSXlVLGFBQUEsR0FBcUM7SUFJekMsV0FBV2xCLFdBQUEsSUFBZWMsb0JBQUEsRUFBc0I7TUFDOUMsSUFBSTtRQUNGLE1BQU1KLElBQUEsR0FBTyxNQUFNVixXQUFBLENBQVlSLElBQUEsQ0FBb0J2TyxHQUFHO1FBQ3RELElBQUl5UCxJQUFBLEVBQU07VUFDUixNQUFNOUssSUFBQSxHQUFPbUgsUUFBQSxDQUFTZ0IsU0FBQSxDQUFVL1IsSUFBQSxFQUFNMFUsSUFBSTtVQUMxQyxJQUFJVixXQUFBLEtBQWdCaUIsbUJBQUEsRUFBcUI7WUFDdkNDLGFBQUEsR0FBZ0J0TCxJQUFBO1VBQ2pCO1VBQ0RxTCxtQkFBQSxHQUFzQmpCLFdBQUE7VUFDdEI7UUFDRDtNQUNGLFNBQUN0UyxFQUFBLEdBQU07SUFDVDtJQUlELE1BQU15VCxrQkFBQSxHQUFxQkoscUJBQUEsQ0FBc0JsRyxNQUFBLENBQy9DdUcsQ0FBQSxJQUFLQSxDQUFBLENBQUVDLHFCQUFxQjtJQUk5QixJQUNFLENBQUNKLG1CQUFBLENBQW9CSSxxQkFBQSxJQUNyQixDQUFDRixrQkFBQSxDQUFtQnpNLE1BQUEsRUFDcEI7TUFDQSxPQUFPLElBQUlxTCxzQkFBQSxDQUF1QmtCLG1CQUFBLEVBQXFCalYsSUFBQSxFQUFNaVUsT0FBTztJQUNyRTtJQUVEZ0IsbUJBQUEsR0FBc0JFLGtCQUFBLENBQW1CO0lBQ3pDLElBQUlELGFBQUEsRUFBZTtNQUdqQixNQUFNRCxtQkFBQSxDQUFvQjNCLElBQUEsQ0FBS3JPLEdBQUEsRUFBS2lRLGFBQUEsQ0FBY2hJLE1BQUEsQ0FBTSxDQUFFO0lBQzNEO0lBSUQsTUFBTXRILE9BQUEsQ0FBUW9QLEdBQUEsQ0FDWkYsb0JBQUEsQ0FBcUIzRixHQUFBLENBQUksTUFBTTZFLFdBQUEsSUFBYztNQUMzQyxJQUFJQSxXQUFBLEtBQWdCaUIsbUJBQUEsRUFBcUI7UUFDdkMsSUFBSTtVQUNGLE1BQU1qQixXQUFBLENBQVlQLE9BQUEsQ0FBUXhPLEdBQUc7UUFDOUIsU0FBQ3ZELEVBQUEsR0FBTTtNQUNUO0tBQ0YsQ0FBQztJQUVKLE9BQU8sSUFBSXFTLHNCQUFBLENBQXVCa0IsbUJBQUEsRUFBcUJqVixJQUFBLEVBQU1pVSxPQUFPOztBQUV2RTtBQzVJSyxTQUFVcUIsZ0JBQWdCQyxTQUFBLEVBQWlCO0VBQy9DLE1BQU1DLEVBQUEsR0FBS0QsU0FBQSxDQUFVL08sV0FBQSxDQUFXO0VBQ2hDLElBQUlnUCxFQUFBLENBQUdDLFFBQUEsQ0FBUyxRQUFRLEtBQUtELEVBQUEsQ0FBR0MsUUFBQSxDQUFTLE1BQU0sS0FBS0QsRUFBQSxDQUFHQyxRQUFBLENBQVMsUUFBUSxHQUFHO0lBQ3pFLE9BQXlCO0VBQzFCLFdBQVVDLFdBQUEsQ0FBWUYsRUFBRSxHQUFHO0lBRTFCLE9BQTRCO0VBQzdCLFdBQVVBLEVBQUEsQ0FBR0MsUUFBQSxDQUFTLE1BQU0sS0FBS0QsRUFBQSxDQUFHQyxRQUFBLENBQVMsVUFBVSxHQUFHO0lBQ3pELE9BQXNCO0VBQ3ZCLFdBQVVELEVBQUEsQ0FBR0MsUUFBQSxDQUFTLE9BQU8sR0FBRztJQUMvQixPQUF3QjtFQUN6QixXQUFVRSxVQUFBLENBQVdILEVBQUUsR0FBRztJQUN6QixPQUEyQjtFQUM1QixXQUFVQSxFQUFBLENBQUdDLFFBQUEsQ0FBUyxPQUFPLEdBQUc7SUFDL0IsT0FBd0I7RUFDekIsV0FBVUcsYUFBQSxDQUFjSixFQUFFLEdBQUc7SUFFNUIsT0FBOEI7RUFDL0IsV0FBVUssUUFBQSxDQUFTTCxFQUFFLEdBQUc7SUFFdkIsT0FBeUI7RUFDMUIsV0FBVU0sU0FBQSxDQUFVTixFQUFFLEdBQUc7SUFDeEIsT0FBMEI7RUFDM0IsWUFDRUEsRUFBQSxDQUFHQyxRQUFBLENBQVMsU0FBUyxLQUFLTSxZQUFBLENBQWFQLEVBQUUsTUFDMUMsQ0FBQ0EsRUFBQSxDQUFHQyxRQUFBLENBQVMsT0FBTyxHQUNwQjtJQUNBLE9BQTBCO0VBQzNCLFdBQVVPLFVBQUEsQ0FBV1IsRUFBRSxHQUFHO0lBRXpCLE9BQTJCO0VBQzVCLE9BQU07SUFFTCxNQUFNUyxFQUFBLEdBQUs7SUFDWCxNQUFNQyxPQUFBLEdBQVVYLFNBQUEsQ0FBVVksS0FBQSxDQUFNRixFQUFFO0lBQ2xDLEtBQUlDLE9BQUEsS0FBTyxRQUFQQSxPQUFBLEtBQU8sa0JBQVBBLE9BQUEsQ0FBU3hOLE1BQUEsTUFBVyxHQUFHO01BQ3pCLE9BQU93TixPQUFBLENBQVE7SUFDaEI7RUFDRjtFQUNELE9BQXlCO0FBQzNCO1NBRWdCUCxXQUFXSCxFQUFBLE9BQUt2ZCxXQUFBLENBQUFtZSxLQUFBLEVBQUssR0FBRTtFQUNyQyxPQUFPLGFBQWFDLElBQUEsQ0FBS2IsRUFBRTtBQUM3QjtTQUVnQk0sVUFBVVAsU0FBQSxPQUFZdGQsV0FBQSxDQUFBbWUsS0FBQSxFQUFLLEdBQUU7RUFDM0MsTUFBTVosRUFBQSxHQUFLRCxTQUFBLENBQVUvTyxXQUFBLENBQVc7RUFDaEMsT0FDRWdQLEVBQUEsQ0FBR0MsUUFBQSxDQUFTLFNBQVMsS0FDckIsQ0FBQ0QsRUFBQSxDQUFHQyxRQUFBLENBQVMsU0FBUyxLQUN0QixDQUFDRCxFQUFBLENBQUdDLFFBQUEsQ0FBUyxRQUFRLEtBQ3JCLENBQUNELEVBQUEsQ0FBR0MsUUFBQSxDQUFTLFNBQVM7QUFFMUI7U0FFZ0JNLGFBQWFQLEVBQUEsT0FBS3ZkLFdBQUEsQ0FBQW1lLEtBQUEsRUFBSyxHQUFFO0VBQ3ZDLE9BQU8sV0FBV0MsSUFBQSxDQUFLYixFQUFFO0FBQzNCO1NBRWdCRSxZQUFZRixFQUFBLE9BQUt2ZCxXQUFBLENBQUFtZSxLQUFBLEVBQUssR0FBRTtFQUN0QyxPQUFPLFlBQVlDLElBQUEsQ0FBS2IsRUFBRTtBQUM1QjtTQUVnQlEsV0FBV1IsRUFBQSxPQUFLdmQsV0FBQSxDQUFBbWUsS0FBQSxFQUFLLEdBQUU7RUFDckMsT0FBTyxXQUFXQyxJQUFBLENBQUtiLEVBQUU7QUFDM0I7U0FFZ0JJLGNBQWNKLEVBQUEsT0FBS3ZkLFdBQUEsQ0FBQW1lLEtBQUEsRUFBSyxHQUFFO0VBQ3hDLE9BQU8sY0FBY0MsSUFBQSxDQUFLYixFQUFFO0FBQzlCO1NBRWdCSyxTQUFTTCxFQUFBLE9BQUt2ZCxXQUFBLENBQUFtZSxLQUFBLEVBQUssR0FBRTtFQUNuQyxPQUFPLFNBQVNDLElBQUEsQ0FBS2IsRUFBRTtBQUN6QjtTQUVnQmMsT0FBT2QsRUFBQSxPQUFLdmQsV0FBQSxDQUFBbWUsS0FBQSxFQUFLLEdBQUU7RUFDakMsT0FDRSxvQkFBb0JDLElBQUEsQ0FBS2IsRUFBRSxLQUMxQixhQUFhYSxJQUFBLENBQUtiLEVBQUUsS0FBSyxVQUFVYSxJQUFBLENBQUtiLEVBQUU7QUFFL0M7U0FFZ0JlLFdBQVdmLEVBQUEsT0FBS3ZkLFdBQUEsQ0FBQW1lLEtBQUEsRUFBSyxHQUFFO0VBQ3JDLE9BQ0UsK0JBQStCQyxJQUFBLENBQUtiLEVBQUUsS0FDdEMsK0JBQStCYSxJQUFBLENBQUtiLEVBQUU7QUFFMUM7U0FFZ0JnQixpQkFBaUJoQixFQUFBLE9BQUt2ZCxXQUFBLENBQUFtZSxLQUFBLEVBQUssR0FBRTs7RUFDM0MsT0FBT0UsTUFBQSxDQUFPZCxFQUFFLEtBQUssQ0FBQyxHQUFDOVQsRUFBQSxHQUFDK1UsTUFBQSxDQUFPeFUsU0FBQSxNQUFtQyxRQUFBUCxFQUFBLHVCQUFBQSxFQUFBLENBQUFnVixVQUFBO0FBQ3BFO1NBRWdCQyxRQUFBLEVBQU87RUFDckIsV0FBTzFlLFdBQUEsQ0FBQTJlLElBQUEsRUFBSSxLQUFPQyxRQUFBLENBQXNCQyxZQUFBLEtBQWlCO0FBQzNEO0FBRWdCLFNBQUFDLGlCQUFpQnZCLEVBQUEsT0FBYXZkLFdBQUEsQ0FBQW1lLEtBQUEsRUFBSyxHQUFFO0VBRW5ELE9BQ0VFLE1BQUEsQ0FBT2QsRUFBRSxLQUNUUSxVQUFBLENBQVdSLEVBQUUsS0FDYkssUUFBQSxDQUFTTCxFQUFFLEtBQ1hJLGFBQUEsQ0FBY0osRUFBRSxLQUNoQixpQkFBaUJhLElBQUEsQ0FBS2IsRUFBRSxLQUN4QkUsV0FBQSxDQUFZRixFQUFFO0FBRWxCO1NBRWdCd0IsVUFBQSxFQUFTO0VBQ3ZCLElBQUk7SUFHRixPQUFPLENBQUMsRUFBRVAsTUFBQSxJQUFVQSxNQUFBLEtBQVdBLE1BQUEsQ0FBT1EsR0FBQTtFQUN2QyxTQUFRdlEsQ0FBQSxFQUFQO0lBQ0EsT0FBTztFQUNSO0FBQ0g7U0MvSGdCd1Esa0JBQ2RDLGNBQUEsRUFDQUMsVUFBQSxHQUFnQyxJQUFFO0VBRWxDLElBQUlDLGdCQUFBO0VBQ0osUUFBUUYsY0FBQTtTQUNOO01BRUVFLGdCQUFBLEdBQW1CL0IsZUFBQSxLQUFnQnJkLFdBQUEsQ0FBQW1lLEtBQUEsRUFBSyxDQUFFO01BQzFDO1NBQ0Y7TUFJRWlCLGdCQUFBLEdBQW1CLEdBQUcvQixlQUFBLEtBQWdCcmQsV0FBQSxDQUFBbWUsS0FBQSxFQUFLLENBQUUsS0FBS2UsY0FBQTtNQUNsRDs7TUFFQUUsZ0JBQUEsR0FBbUJGLGNBQUE7O0VBRXZCLE1BQU1HLGtCQUFBLEdBQXFCRixVQUFBLENBQVcxTyxNQUFBLEdBQ2xDME8sVUFBQSxDQUFXRyxJQUFBLENBQUssR0FBRyxJQUNuQjtFQUNKLE9BQU8sR0FBR0YsZ0JBQUEsSUFBb0IsWUFBNkJoWSxVQUFBLENBQUFDLFdBQUEsSUFBZWdZLGtCQUFBO0FBQzVFO0lDcENhRSxtQkFBQSxTQUFtQjtFQUc5QjFXLFlBQTZCZCxJQUFBLEVBQWtCO0lBQWxCLEtBQUlBLElBQUEsR0FBSkEsSUFBQTtJQUZaLEtBQUt5WCxLQUFBLEdBQXNCOztFQUk1Q0MsYUFDRW5HLFFBQUEsRUFDQW9HLE9BQUEsRUFBb0I7SUFJcEIsTUFBTUMsZUFBQSxHQUNKaE8sSUFBQSxJQUVBLElBQUloRSxPQUFBLENBQVEsQ0FBQ2lTLE9BQUEsRUFBU3RRLE1BQUEsS0FBVTtNQUM5QixJQUFJO1FBQ0YsTUFBTXVRLE1BQUEsR0FBU3ZHLFFBQUEsQ0FBUzNILElBQUk7UUFHNUJpTyxPQUFBLENBQVFDLE1BQU07TUFDZixTQUFRcFIsQ0FBQSxFQUFQO1FBRUFhLE1BQUEsQ0FBT2IsQ0FBQztNQUNUO0lBQ0gsQ0FBQztJQUVIa1IsZUFBQSxDQUFnQkQsT0FBQSxHQUFVQSxPQUFBO0lBQzFCLEtBQUtGLEtBQUEsQ0FBTU0sSUFBQSxDQUFLSCxlQUFlO0lBRS9CLE1BQU1JLEtBQUEsR0FBUSxLQUFLUCxLQUFBLENBQU0vTyxNQUFBLEdBQVM7SUFDbEMsT0FBTyxNQUFLO01BR1YsS0FBSytPLEtBQUEsQ0FBTU8sS0FBQSxJQUFTLE1BQU1wUyxPQUFBLENBQVFpUyxPQUFBLENBQU87SUFDM0M7O0VBR0YsTUFBTUksY0FBY0MsUUFBQSxFQUFxQjtJQUN2QyxJQUFJLEtBQUtsWSxJQUFBLENBQUswTCxXQUFBLEtBQWdCd00sUUFBQSxFQUFVO01BQ3RDO0lBQ0Q7SUFLRCxNQUFNQyxZQUFBLEdBQWtDO0lBQ3hDLElBQUk7TUFDRixXQUFXQyxtQkFBQSxJQUF1QixLQUFLWCxLQUFBLEVBQU87UUFDNUMsTUFBTVcsbUJBQUEsQ0FBb0JGLFFBQVE7UUFHbEMsSUFBSUUsbUJBQUEsQ0FBb0JULE9BQUEsRUFBUztVQUMvQlEsWUFBQSxDQUFhSixJQUFBLENBQUtLLG1CQUFBLENBQW9CVCxPQUFPO1FBQzlDO01BQ0Y7SUFDRixTQUFRalIsQ0FBQSxFQUFQO01BR0F5UixZQUFBLENBQWFFLE9BQUEsQ0FBTztNQUNwQixXQUFXVixPQUFBLElBQVdRLFlBQUEsRUFBYztRQUNsQyxJQUFJO1VBQ0ZSLE9BQUEsQ0FBTztRQUNSLFNBQVFyUSxDQUFBLEVBQVAsQ0FFRDtNQUNGO01BRUQsTUFBTSxLQUFLdEgsSUFBQSxDQUFLaUIsYUFBQSxDQUFjVixNQUFBLENBQW9DO1FBQ2hFK1gsZUFBQSxFQUFrQjVSLENBQUEsS0FBVyxRQUFYQSxDQUFBLHVCQUFBQSxDQUFBLENBQWF4RztNQUNoQztJQUNGOztBQUVKO0FDekNNLGVBQWVxWSxtQkFDcEJ2WSxJQUFBLEVBQ0FxRSxPQUFBLEdBQW9DLElBQUU7RUFFdEMsT0FBT0Usa0JBQUEsQ0FJTHZFLElBQUEsRUFHQSw2QkFBQW9FLGtCQUFBLENBQW1CcEUsSUFBQSxFQUFNcUUsT0FBTyxDQUFDO0FBRXJDO0FDNUNBLElBQU1tVSwyQkFBQSxHQUE4QjtJQU92QkMsa0JBQUEsU0FBa0I7RUFPN0IzWCxZQUFZa0QsUUFBQSxFQUFtQzs7SUFFN0MsTUFBTTBVLGVBQUEsR0FBa0IxVSxRQUFBLENBQVMyVSxxQkFBQTtJQUNqQyxLQUFLQSxxQkFBQSxHQUF3QjtJQUU3QixLQUFLQSxxQkFBQSxDQUFzQkMsaUJBQUEsSUFDekJsWCxFQUFBLEdBQUFnWCxlQUFBLENBQWdCRSxpQkFBQSxNQUFpQixRQUFBbFgsRUFBQSxjQUFBQSxFQUFBLEdBQUk4VywyQkFBQTtJQUN2QyxJQUFJRSxlQUFBLENBQWdCRyxpQkFBQSxFQUFtQjtNQUNyQyxLQUFLRixxQkFBQSxDQUFzQkUsaUJBQUEsR0FDekJILGVBQUEsQ0FBZ0JHLGlCQUFBO0lBQ25CO0lBQ0QsSUFBSUgsZUFBQSxDQUFnQkksMEJBQUEsS0FBK0IsUUFBVztNQUM1RCxLQUFLSCxxQkFBQSxDQUFzQkksdUJBQUEsR0FDekJMLGVBQUEsQ0FBZ0JJLDBCQUFBO0lBQ25CO0lBQ0QsSUFBSUosZUFBQSxDQUFnQk0sMEJBQUEsS0FBK0IsUUFBVztNQUM1RCxLQUFLTCxxQkFBQSxDQUFzQk0sdUJBQUEsR0FDekJQLGVBQUEsQ0FBZ0JNLDBCQUFBO0lBQ25CO0lBQ0QsSUFBSU4sZUFBQSxDQUFnQlEsd0JBQUEsS0FBNkIsUUFBVztNQUMxRCxLQUFLUCxxQkFBQSxDQUFzQk8sd0JBQUEsR0FDekJSLGVBQUEsQ0FBZ0JRLHdCQUFBO0lBQ25CO0lBQ0QsSUFBSVIsZUFBQSxDQUFnQlMsZ0NBQUEsS0FBcUMsUUFBVztNQUNsRSxLQUFLUixxQkFBQSxDQUFzQlEsZ0NBQUEsR0FDekJULGVBQUEsQ0FBZ0JTLGdDQUFBO0lBQ25CO0lBRUQsS0FBS3ZRLGdCQUFBLEdBQW1CNUUsUUFBQSxDQUFTNEUsZ0JBQUE7SUFDakMsSUFBSSxLQUFLQSxnQkFBQSxLQUFxQixpQ0FBaUM7TUFDN0QsS0FBS0EsZ0JBQUEsR0FBbUI7SUFDekI7SUFHRCxLQUFLd1EsZ0NBQUEsSUFDSG5ILEVBQUEsSUFBQUQsRUFBQSxHQUFBaE8sUUFBQSxDQUFTb1YsZ0NBQUEsTUFBZ0MsUUFBQXBILEVBQUEsdUJBQUFBLEVBQUEsQ0FBRXVGLElBQUEsQ0FBSyxFQUFFLE9BQUssUUFBQXRGLEVBQUEsY0FBQUEsRUFBQTtJQUV6RCxLQUFLb0gsb0JBQUEsSUFBdUJuSCxFQUFBLEdBQUFsTyxRQUFBLENBQVNxVixvQkFBQSxNQUF3QixRQUFBbkgsRUFBQSxjQUFBQSxFQUFBO0lBQzdELEtBQUtvSCxhQUFBLEdBQWdCdFYsUUFBQSxDQUFTc1YsYUFBQTs7RUFHaENoakIsaUJBQWlCaWpCLFFBQUEsRUFBZ0I7O0lBQy9CLE1BQU1DLE1BQUEsR0FBMkM7TUFDL0NDLE9BQUEsRUFBUztNQUNUQyxjQUFBLEVBQWdCOztJQUlsQixLQUFLQyw2QkFBQSxDQUE4QkosUUFBQSxFQUFVQyxNQUFNO0lBQ25ELEtBQUtJLGdDQUFBLENBQWlDTCxRQUFBLEVBQVVDLE1BQU07SUFHdERBLE1BQUEsQ0FBT0MsT0FBQSxLQUFQRCxNQUFBLENBQU9DLE9BQUEsSUFBWS9YLEVBQUEsR0FBQThYLE1BQUEsQ0FBT0ssc0JBQUEsTUFBc0IsUUFBQW5ZLEVBQUEsY0FBQUEsRUFBQSxHQUFJO0lBQ3BEOFgsTUFBQSxDQUFPQyxPQUFBLEtBQVBELE1BQUEsQ0FBT0MsT0FBQSxJQUFZekgsRUFBQSxHQUFBd0gsTUFBQSxDQUFPTSxzQkFBQSxNQUFzQixRQUFBOUgsRUFBQSxjQUFBQSxFQUFBLEdBQUk7SUFDcER3SCxNQUFBLENBQU9DLE9BQUEsS0FBUEQsTUFBQSxDQUFPQyxPQUFBLElBQVl4SCxFQUFBLEdBQUF1SCxNQUFBLENBQU9ULHVCQUFBLE1BQXVCLFFBQUE5RyxFQUFBLGNBQUFBLEVBQUEsR0FBSTtJQUNyRHVILE1BQUEsQ0FBT0MsT0FBQSxLQUFQRCxNQUFBLENBQU9DLE9BQUEsSUFBWXZILEVBQUEsR0FBQXNILE1BQUEsQ0FBT1AsdUJBQUEsTUFBdUIsUUFBQS9HLEVBQUEsY0FBQUEsRUFBQSxHQUFJO0lBQ3JEc0gsTUFBQSxDQUFPQyxPQUFBLEtBQVBELE1BQUEsQ0FBT0MsT0FBQSxJQUFZdEgsRUFBQSxHQUFBcUgsTUFBQSxDQUFPTix3QkFBQSxNQUF3QixRQUFBL0csRUFBQSxjQUFBQSxFQUFBLEdBQUk7SUFDdERxSCxNQUFBLENBQU9DLE9BQUEsS0FBUEQsTUFBQSxDQUFPQyxPQUFBLElBQVlySCxFQUFBLEdBQUFvSCxNQUFBLENBQU9MLGdDQUFBLE1BQWdDLFFBQUEvRyxFQUFBLGNBQUFBLEVBQUEsR0FBSTtJQUU5RCxPQUFPb0gsTUFBQTs7RUFTREcsOEJBQ05KLFFBQUEsRUFDQUMsTUFBQSxFQUF3QztJQUV4QyxNQUFNWixpQkFBQSxHQUFvQixLQUFLRCxxQkFBQSxDQUFzQkMsaUJBQUE7SUFDckQsTUFBTUMsaUJBQUEsR0FBb0IsS0FBS0YscUJBQUEsQ0FBc0JFLGlCQUFBO0lBQ3JELElBQUlELGlCQUFBLEVBQW1CO01BQ3JCWSxNQUFBLENBQU9LLHNCQUFBLEdBQXlCTixRQUFBLENBQVM3USxNQUFBLElBQVVrUSxpQkFBQTtJQUNwRDtJQUNELElBQUlDLGlCQUFBLEVBQW1CO01BQ3JCVyxNQUFBLENBQU9NLHNCQUFBLEdBQXlCUCxRQUFBLENBQVM3USxNQUFBLElBQVVtUSxpQkFBQTtJQUNwRDs7RUFTS2UsaUNBQ05MLFFBQUEsRUFDQUMsTUFBQSxFQUF3QztJQUd4QyxLQUFLTyxzQ0FBQSxDQUNIUCxNQUFBLEVBQ2tDLE9BQ0EsT0FDRixPQUNRLEtBQUs7SUFHL0MsSUFBSVEsWUFBQTtJQUNKLFNBQVNDLENBQUEsR0FBSSxHQUFHQSxDQUFBLEdBQUlWLFFBQUEsQ0FBUzdRLE1BQUEsRUFBUXVSLENBQUEsSUFBSztNQUN4Q0QsWUFBQSxHQUFlVCxRQUFBLENBQVNXLE1BQUEsQ0FBT0QsQ0FBQztNQUNoQyxLQUFLRixzQ0FBQSxDQUNIUCxNQUFBLEVBQ2tDUSxZQUFBLElBQWdCLE9BQ2hEQSxZQUFBLElBQWdCLEtBQ2dCQSxZQUFBLElBQWdCLE9BQ2hEQSxZQUFBLElBQWdCLEtBQ2NBLFlBQUEsSUFBZ0IsT0FDOUNBLFlBQUEsSUFBZ0IsS0FDc0IsS0FBS1osZ0NBQUEsQ0FBaUMzRCxRQUFBLENBQzVFdUUsWUFBWSxDQUNiO0lBRUo7O0VBY0tELHVDQUNOUCxNQUFBLEVBQ0FWLDBCQUFBLEVBQ0FFLDBCQUFBLEVBQ0FFLHdCQUFBLEVBQ0FDLGdDQUFBLEVBQXlDO0lBRXpDLElBQUksS0FBS1IscUJBQUEsQ0FBc0JJLHVCQUFBLEVBQXlCO01BQ3REUyxNQUFBLENBQU9ULHVCQUFBLEtBQVBTLE1BQUEsQ0FBT1QsdUJBQUEsR0FBNEJELDBCQUFBO0lBQ3BDO0lBQ0QsSUFBSSxLQUFLSCxxQkFBQSxDQUFzQk0sdUJBQUEsRUFBeUI7TUFDdERPLE1BQUEsQ0FBT1AsdUJBQUEsS0FBUE8sTUFBQSxDQUFPUCx1QkFBQSxHQUE0QkQsMEJBQUE7SUFDcEM7SUFDRCxJQUFJLEtBQUtMLHFCQUFBLENBQXNCTyx3QkFBQSxFQUEwQjtNQUN2RE0sTUFBQSxDQUFPTix3QkFBQSxLQUFQTSxNQUFBLENBQU9OLHdCQUFBLEdBQTZCQSx3QkFBQTtJQUNyQztJQUNELElBQUksS0FBS1AscUJBQUEsQ0FBc0JRLGdDQUFBLEVBQWtDO01BQy9ESyxNQUFBLENBQU9MLGdDQUFBLEtBQVBLLE1BQUEsQ0FBT0wsZ0NBQUEsR0FDTEEsZ0NBQUE7SUFDSDs7QUFFSjtJQ3hHWWdCLFFBQUEsU0FBUTtFQXFDbkJyWixZQUNrQnNaLEdBQUEsRUFDQ0Msd0JBQUEsRUFDQUMsdUJBQUEsRUFDRHBYLE1BQUEsRUFBc0I7SUFIdEIsS0FBR2tYLEdBQUEsR0FBSEEsR0FBQTtJQUNDLEtBQXdCQyx3QkFBQSxHQUF4QkEsd0JBQUE7SUFDQSxLQUF1QkMsdUJBQUEsR0FBdkJBLHVCQUFBO0lBQ0QsS0FBTXBYLE1BQUEsR0FBTkEsTUFBQTtJQXhDbEIsS0FBV3dJLFdBQUEsR0FBZ0I7SUFDM0IsS0FBYzZPLGNBQUEsR0FBMEI7SUFDaEMsS0FBQUMsVUFBQSxHQUFhNVUsT0FBQSxDQUFRaVMsT0FBQSxDQUFPO0lBRzVCLEtBQUE0QyxxQkFBQSxHQUF3QixJQUFJQyxZQUFBLENBQW1CLElBQUk7SUFDbkQsS0FBQUMsbUJBQUEsR0FBc0IsSUFBSUQsWUFBQSxDQUFtQixJQUFJO0lBQ3hDLEtBQUFFLGdCQUFBLEdBQW1CLElBQUlwRCxtQkFBQSxDQUFvQixJQUFJO0lBQ3hELEtBQVlxRCxZQUFBLEdBQXdCO0lBQ3BDLEtBQXlCQyx5QkFBQSxHQUFHO0lBQ25CLEtBQXVDQyx1Q0FBQSxHQUFXO0lBSW5FLEtBQWdCdFYsZ0JBQUEsR0FBRztJQUNuQixLQUFjdVYsY0FBQSxHQUFHO0lBQ2pCLEtBQVFDLFFBQUEsR0FBRztJQUNYLEtBQXNCQyxzQkFBQSxHQUF5QjtJQUMvQyxLQUFzQkMsc0JBQUEsR0FBeUM7SUFDL0QsS0FBYWxhLGFBQUEsR0FDWGpKLDJCQUFBO0lBQ0YsS0FBcUJvakIscUJBQUEsR0FBMkI7SUFDaEQsS0FBdUJDLHVCQUFBLEdBQW9DO0lBQzNELEtBQXNCQyxzQkFBQSxHQUFrQztJQUN4RCxLQUF1QkMsdUJBQUEsR0FBMkM7SUFNMUQsS0FBZUMsZUFBQSxHQUE4QjtJQUVyRCxLQUFZcFcsWUFBQSxHQUFrQjtJQUM5QixLQUFRZCxRQUFBLEdBQWtCO0lBQzFCLEtBQUFtWCxRQUFBLEdBQXlCO01BQUVDLGlDQUFBLEVBQW1DO0lBQUs7SUFxbUIzRCxLQUFVdEUsVUFBQSxHQUFhO0lBN2xCN0IsS0FBSzNXLElBQUEsR0FBTzJaLEdBQUEsQ0FBSTNaLElBQUE7SUFDaEIsS0FBS2tiLGFBQUEsR0FBZ0J6WSxNQUFBLENBQU8wWSxnQkFBQTs7RUFHOUJDLDJCQUNFL0csb0JBQUEsRUFDQWdILHFCQUFBLEVBQTZDO0lBRTdDLElBQUlBLHFCQUFBLEVBQXVCO01BQ3pCLEtBQUtYLHNCQUFBLEdBQXlCckksWUFBQSxDQUFhZ0oscUJBQXFCO0lBQ2pFO0lBSUQsS0FBS1osc0JBQUEsR0FBeUIsS0FBS3pELEtBQUEsQ0FBTSxZQUFXOztNQUNsRCxJQUFJLEtBQUt3RCxRQUFBLEVBQVU7UUFDakI7TUFDRDtNQUVELEtBQUtjLGtCQUFBLEdBQXFCLE1BQU1oSSxzQkFBQSxDQUF1QnhULE1BQUEsQ0FDckQsTUFDQXVVLG9CQUFvQjtNQUd0QixJQUFJLEtBQUttRyxRQUFBLEVBQVU7UUFDakI7TUFDRDtNQUlELEtBQUl2WixFQUFBLFFBQUt5WixzQkFBQSxNQUFzQixRQUFBelosRUFBQSx1QkFBQUEsRUFBQSxDQUFFc2Esc0JBQUEsRUFBd0I7UUFFdkQsSUFBSTtVQUNGLE1BQU0sS0FBS2Isc0JBQUEsQ0FBdUJjLFdBQUEsQ0FBWSxJQUFJO1FBQ25ELFNBQVF2VixDQUFBLEVBQVAsQ0FFRDtNQUNGO01BRUQsTUFBTSxLQUFLd1YscUJBQUEsQ0FBc0JKLHFCQUFxQjtNQUN0RCxLQUFLTixlQUFBLEtBQWtCeEosRUFBQSxRQUFLdEcsV0FBQSxNQUFhLFFBQUFzRyxFQUFBLHVCQUFBQSxFQUFBLENBQUE5RCxHQUFBLEtBQU87TUFFaEQsSUFBSSxLQUFLK00sUUFBQSxFQUFVO1FBQ2pCO01BQ0Q7TUFFRCxLQUFLRCxjQUFBLEdBQWlCO0lBQ3hCLENBQUM7SUFFRCxPQUFPLEtBQUtFLHNCQUFBOztFQU1kLE1BQU01RyxnQkFBQSxFQUFlO0lBQ25CLElBQUksS0FBSzJHLFFBQUEsRUFBVTtNQUNqQjtJQUNEO0lBRUQsTUFBTXJSLElBQUEsR0FBTyxNQUFNLEtBQUt1UyxtQkFBQSxDQUFvQjFILGNBQUEsQ0FBYztJQUUxRCxJQUFJLENBQUMsS0FBSy9JLFdBQUEsSUFBZSxDQUFDOUIsSUFBQSxFQUFNO01BRTlCO0lBQ0Q7SUFHRCxJQUFJLEtBQUs4QixXQUFBLElBQWU5QixJQUFBLElBQVEsS0FBSzhCLFdBQUEsQ0FBWXdDLEdBQUEsS0FBUXRFLElBQUEsQ0FBS3NFLEdBQUEsRUFBSztNQUVqRSxLQUFLa08sWUFBQSxDQUFhekwsT0FBQSxDQUFRL0csSUFBSTtNQUc5QixNQUFNLEtBQUs4QixXQUFBLENBQVloWSxVQUFBLENBQVU7TUFDakM7SUFDRDtJQUlELE1BQU0sS0FBSzJvQixrQkFBQSxDQUFtQnpTLElBQUEsRUFBcUMsSUFBSTs7RUFHakUsTUFBTXNTLHNCQUNaSixxQkFBQSxFQUE2Qzs7SUFHN0MsTUFBTVEsb0JBQUEsR0FDSCxNQUFNLEtBQUtILG1CQUFBLENBQW9CMUgsY0FBQSxDQUFjO0lBQ2hELElBQUk4SCxpQkFBQSxHQUFvQkQsb0JBQUE7SUFDeEIsSUFBSUUsc0JBQUEsR0FBeUI7SUFDN0IsSUFBSVYscUJBQUEsSUFBeUIsS0FBSzVZLE1BQUEsQ0FBT3VaLFVBQUEsRUFBWTtNQUNuRCxNQUFNLEtBQUtDLG1DQUFBLENBQW1DO01BQzlDLE1BQU1DLG1CQUFBLElBQXNCamIsRUFBQSxRQUFLbVosWUFBQSxNQUFZLFFBQUFuWixFQUFBLHVCQUFBQSxFQUFBLENBQUVvUSxnQkFBQTtNQUMvQyxNQUFNOEssaUJBQUEsR0FBb0JMLGlCQUFBLEtBQWlCLFFBQWpCQSxpQkFBQSx1QkFBQUEsaUJBQUEsQ0FBbUJ6SyxnQkFBQTtNQUM3QyxNQUFNZ0csTUFBQSxHQUFTLE1BQU0sS0FBSytFLGlCQUFBLENBQWtCZixxQkFBcUI7TUFNakUsS0FDRyxDQUFDYSxtQkFBQSxJQUF1QkEsbUJBQUEsS0FBd0JDLGlCQUFBLE1BQ2pEOUUsTUFBQSxLQUFNLFFBQU5BLE1BQUEsS0FBTSxrQkFBTkEsTUFBQSxDQUFRbE8sSUFBQSxHQUNSO1FBQ0EyUyxpQkFBQSxHQUFvQnpFLE1BQUEsQ0FBT2xPLElBQUE7UUFDM0I0UyxzQkFBQSxHQUF5QjtNQUMxQjtJQUNGO0lBR0QsSUFBSSxDQUFDRCxpQkFBQSxFQUFtQjtNQUN0QixPQUFPLEtBQUtPLHNCQUFBLENBQXVCLElBQUk7SUFDeEM7SUFFRCxJQUFJLENBQUNQLGlCQUFBLENBQWtCekssZ0JBQUEsRUFBa0I7TUFHdkMsSUFBSTBLLHNCQUFBLEVBQXdCO1FBQzFCLElBQUk7VUFDRixNQUFNLEtBQUs1QixnQkFBQSxDQUFpQjNDLGFBQUEsQ0FBY3NFLGlCQUFpQjtRQUM1RCxTQUFRN1YsQ0FBQSxFQUFQO1VBQ0E2VixpQkFBQSxHQUFvQkQsb0JBQUE7VUFHcEIsS0FBS25CLHNCQUFBLENBQXdCNEIsdUJBQUEsQ0FBd0IsTUFBTSxNQUN6RG5YLE9BQUEsQ0FBUTJCLE1BQUEsQ0FBT2IsQ0FBQyxDQUFDO1FBRXBCO01BQ0Y7TUFFRCxJQUFJNlYsaUJBQUEsRUFBbUI7UUFDckIsT0FBTyxLQUFLUyw4QkFBQSxDQUErQlQsaUJBQWlCO01BQzdELE9BQU07UUFDTCxPQUFPLEtBQUtPLHNCQUFBLENBQXVCLElBQUk7TUFDeEM7SUFDRjtJQUVENWIsT0FBQSxDQUFRLEtBQUtpYSxzQkFBQSxFQUF3QixNQUFJO0lBQ3pDLE1BQU0sS0FBS3VCLG1DQUFBLENBQW1DO0lBSzlDLElBQ0UsS0FBSzdCLFlBQUEsSUFDTCxLQUFLQSxZQUFBLENBQWEvSSxnQkFBQSxLQUFxQnlLLGlCQUFBLENBQWtCekssZ0JBQUEsRUFDekQ7TUFDQSxPQUFPLEtBQUtnTCxzQkFBQSxDQUF1QlAsaUJBQWlCO0lBQ3JEO0lBRUQsT0FBTyxLQUFLUyw4QkFBQSxDQUErQlQsaUJBQWlCOztFQUd0RCxNQUFNTSxrQkFDWkksZ0JBQUEsRUFBdUM7SUFrQnZDLElBQUluRixNQUFBLEdBQWdDO0lBQ3BDLElBQUk7TUFHRkEsTUFBQSxHQUFTLE1BQU0sS0FBS3FELHNCQUFBLENBQXdCK0IsbUJBQUEsQ0FDMUMsTUFDQUQsZ0JBQUEsRUFDQSxJQUFJO0lBRVAsU0FBUXZXLENBQUEsRUFBUDtNQUdBLE1BQU0sS0FBS3lXLGdCQUFBLENBQWlCLElBQUk7SUFDakM7SUFFRCxPQUFPckYsTUFBQTs7RUFHRCxNQUFNa0YsK0JBQ1pwVCxJQUFBLEVBQWtCO0lBRWxCLElBQUk7TUFDRixNQUFNdUQsb0JBQUEsQ0FBcUJ2RCxJQUFJO0lBQ2hDLFNBQVFsRCxDQUFBLEVBQVA7TUFDQSxLQUNHQSxDQUFBLEtBQW1CLFFBQW5CQSxDQUFBLHVCQUFBQSxDQUFBLENBQXFCekcsSUFBQSxNQUN0QixRQUFRLDRCQUNSO1FBR0EsT0FBTyxLQUFLNmMsc0JBQUEsQ0FBdUIsSUFBSTtNQUN4QztJQUNGO0lBRUQsT0FBTyxLQUFLQSxzQkFBQSxDQUF1QmxULElBQUk7O0VBR3pDdlQsa0JBQUEsRUFBaUI7SUFDZixLQUFLK08sWUFBQSxHQUFlaEQsZ0JBQUEsQ0FBZ0I7O0VBR3RDLE1BQU1nYixRQUFBLEVBQU87SUFDWCxLQUFLbkMsUUFBQSxHQUFXOztFQUdsQixNQUFNamxCLGtCQUFrQnFuQixVQUFBLEVBQXVCO0lBRzdDLE1BQU16VCxJQUFBLEdBQU95VCxVQUFBLE9BQ1JwbEIsV0FBQSxDQUFBNlIsa0JBQUEsRUFBbUJ1VCxVQUFVLElBQzlCO0lBQ0osSUFBSXpULElBQUEsRUFBTTtNQUNSMUksT0FBQSxDQUNFMEksSUFBQSxDQUFLNUosSUFBQSxDQUFLa0QsTUFBQSxDQUFPZ0MsTUFBQSxLQUFXLEtBQUtoQyxNQUFBLENBQU9nQyxNQUFBLEVBQ3hDLE1BQUk7SUFHUDtJQUNELE9BQU8sS0FBS21YLGtCQUFBLENBQW1CelMsSUFBQSxJQUFRQSxJQUFBLENBQUtnSCxNQUFBLENBQU8sSUFBSSxDQUFDOztFQUcxRCxNQUFNeUwsbUJBQ0p6UyxJQUFBLEVBQ0EwVCx3QkFBQSxHQUFvQyxPQUFLO0lBRXpDLElBQUksS0FBS3JDLFFBQUEsRUFBVTtNQUNqQjtJQUNEO0lBQ0QsSUFBSXJSLElBQUEsRUFBTTtNQUNSMUksT0FBQSxDQUNFLEtBQUtvRCxRQUFBLEtBQWFzRixJQUFBLENBQUt0RixRQUFBLEVBQ3ZCLE1BQUk7SUFHUDtJQUVELElBQUksQ0FBQ2daLHdCQUFBLEVBQTBCO01BQzdCLE1BQU0sS0FBSzFDLGdCQUFBLENBQWlCM0MsYUFBQSxDQUFjck8sSUFBSTtJQUMvQztJQUVELE9BQU8sS0FBSzZOLEtBQUEsQ0FBTSxZQUFXO01BQzNCLE1BQU0sS0FBS3FGLHNCQUFBLENBQXVCbFQsSUFBMkI7TUFDN0QsS0FBSzJULG1CQUFBLENBQW1CO0lBQzFCLENBQUM7O0VBR0gsTUFBTXpuQixRQUFBLEVBQU87SUFFWCxNQUFNLEtBQUs4a0IsZ0JBQUEsQ0FBaUIzQyxhQUFBLENBQWMsSUFBSTtJQUU5QyxJQUFJLEtBQUt1RiwwQkFBQSxJQUE4QixLQUFLckMsc0JBQUEsRUFBd0I7TUFDbEUsTUFBTSxLQUFLZ0MsZ0JBQUEsQ0FBaUIsSUFBSTtJQUNqQztJQUlELE9BQU8sS0FBS2Qsa0JBQUEsQ0FBbUIsTUFBcUMsSUFBSTs7RUFHMUVobkIsZUFBZTJlLFdBQUEsRUFBd0I7SUFDckMsT0FBTyxLQUFLeUQsS0FBQSxDQUFNLFlBQVc7TUFDM0IsTUFBTSxLQUFLMEUsbUJBQUEsQ0FBb0I5bUIsY0FBQSxDQUFleWQsWUFBQSxDQUFha0IsV0FBVyxDQUFDO0lBQ3pFLENBQUM7O0VBR0h5SixvQkFBQSxFQUFtQjtJQUNqQixJQUFJLEtBQUtuWixRQUFBLElBQVksTUFBTTtNQUN6QixPQUFPLEtBQUs4VyxxQkFBQTtJQUNiLE9BQU07TUFDTCxPQUFPLEtBQUtDLHVCQUFBLENBQXdCLEtBQUsvVyxRQUFBO0lBQzFDOztFQUdILE1BQU1oTyxpQkFBaUJpakIsUUFBQSxFQUFnQjtJQUNyQyxJQUFJLENBQUMsS0FBS21FLDBCQUFBLENBQTBCLEdBQUk7TUFDdEMsTUFBTSxLQUFLQyxxQkFBQSxDQUFxQjtJQUNqQztJQUdELE1BQU1qRSxjQUFBLEdBQ0osS0FBS2dFLDBCQUFBLENBQTBCO0lBSWpDLElBQ0VoRSxjQUFBLENBQWVKLGFBQUEsS0FDZixLQUFLeUIsdUNBQUEsRUFDTDtNQUNBLE9BQU9uVixPQUFBLENBQVEyQixNQUFBLENBQ2IsS0FBS3RHLGFBQUEsQ0FBY1YsTUFBQSxDQUFNLDhDQUV2QixFQUFFLENBQ0g7SUFFSjtJQUVELE9BQU9tWixjQUFBLENBQWVwakIsZ0JBQUEsQ0FBaUJpakIsUUFBUTs7RUFHakRtRSwyQkFBQSxFQUEwQjtJQUN4QixJQUFJLEtBQUtwWixRQUFBLEtBQWEsTUFBTTtNQUMxQixPQUFPLEtBQUtnWCxzQkFBQTtJQUNiLE9BQU07TUFDTCxPQUFPLEtBQUtDLHVCQUFBLENBQXdCLEtBQUtqWCxRQUFBO0lBQzFDOztFQUdILE1BQU1xWixzQkFBQSxFQUFxQjtJQUN6QixNQUFNM1osUUFBQSxHQUFXLE1BQU11VSxrQkFBQSxDQUFtQixJQUFJO0lBRTlDLE1BQU1tQixjQUFBLEdBQXlDLElBQUlqQixrQkFBQSxDQUNqRHpVLFFBQVE7SUFHVixJQUFJLEtBQUtNLFFBQUEsS0FBYSxNQUFNO01BQzFCLEtBQUtnWCxzQkFBQSxHQUF5QjVCLGNBQUE7SUFDL0IsT0FBTTtNQUNMLEtBQUs2Qix1QkFBQSxDQUF3QixLQUFLalgsUUFBQSxJQUFZb1YsY0FBQTtJQUMvQzs7RUFHSGtFLGdCQUFBLEVBQWU7SUFDYixPQUFPLEtBQUt6QixtQkFBQSxDQUFvQm5JLFdBQUEsQ0FBWWIsSUFBQTs7RUFHOUMwSyxnQkFBZ0IxZCxRQUFBLEVBQXNCO0lBQ3BDLEtBQUtjLGFBQUEsR0FBZ0IsSUFBSWhKLFdBQUEsQ0FBQUMsWUFBQSxDQUN2QixRQUNBLFlBQ0NpSSxRQUFBLENBQThCLENBQUU7O0VBSXJDM0wsbUJBQ0VzcEIsY0FBQSxFQUNBcmUsS0FBQSxFQUNBc2UsU0FBQSxFQUFzQjtJQUV0QixPQUFPLEtBQUtDLHFCQUFBLENBQ1YsS0FBS3ZELHFCQUFBLEVBQ0xxRCxjQUFBLEVBQ0FyZSxLQUFBLEVBQ0FzZSxTQUFTOztFQUlibHJCLHVCQUNFMGUsUUFBQSxFQUNBb0csT0FBQSxFQUFvQjtJQUVwQixPQUFPLEtBQUtpRCxnQkFBQSxDQUFpQmxELFlBQUEsQ0FBYW5HLFFBQUEsRUFBVW9HLE9BQU87O0VBRzdEbGpCLGlCQUNFcXBCLGNBQUEsRUFDQXJlLEtBQUEsRUFDQXNlLFNBQUEsRUFBc0I7SUFFdEIsT0FBTyxLQUFLQyxxQkFBQSxDQUNWLEtBQUtyRCxtQkFBQSxFQUNMbUQsY0FBQSxFQUNBcmUsS0FBQSxFQUNBc2UsU0FBUzs7RUFJYkUsZUFBQSxFQUFjO0lBQ1osT0FBTyxJQUFJclksT0FBQSxDQUFRLENBQUNpUyxPQUFBLEVBQVN0USxNQUFBLEtBQVU7TUFDckMsSUFBSSxLQUFLbUUsV0FBQSxFQUFhO1FBQ3BCbU0sT0FBQSxDQUFPO01BQ1IsT0FBTTtRQUNMLE1BQU1xRyxXQUFBLEdBQWMsS0FBSzFwQixrQkFBQSxDQUFtQixNQUFLO1VBQy9DMHBCLFdBQUEsQ0FBVztVQUNYckcsT0FBQSxDQUFPO1dBQ050USxNQUFNO01BQ1Y7SUFDSCxDQUFDOztFQU1ILE1BQU10UyxrQkFBa0IrVSxLQUFBLEVBQWE7SUFDbkMsSUFBSSxLQUFLMEIsV0FBQSxFQUFhO01BQ3BCLE1BQU0wQixPQUFBLEdBQVUsTUFBTSxLQUFLMUIsV0FBQSxDQUFZaFksVUFBQSxDQUFVO01BRWpELE1BQU0yUSxPQUFBLEdBQThCO1FBQ2xDNEssVUFBQSxFQUFZO1FBQ1prUCxTQUFBLEVBQWlDO1FBQ2pDblUsS0FBQTtRQUNBb0Q7O01BRUYsSUFBSSxLQUFLOUksUUFBQSxJQUFZLE1BQU07UUFDekJELE9BQUEsQ0FBUUMsUUFBQSxHQUFXLEtBQUtBLFFBQUE7TUFDekI7TUFDRCxNQUFNeUwsV0FBQSxDQUFZLE1BQU0xTCxPQUFPO0lBQ2hDOztFQUdINkksT0FBQSxFQUFNOztJQUNKLE9BQU87TUFDTGhJLE1BQUEsRUFBUSxLQUFLaEMsTUFBQSxDQUFPZ0MsTUFBQTtNQUNwQnVYLFVBQUEsRUFBWSxLQUFLdlosTUFBQSxDQUFPdVosVUFBQTtNQUN4QmpjLE9BQUEsRUFBUyxLQUFLQyxJQUFBO01BQ2RpTCxXQUFBLEdBQWFoSyxFQUFBLFFBQUswYSxZQUFBLE1BQVksUUFBQTFhLEVBQUEsdUJBQUFBLEVBQUEsQ0FBRXdMLE1BQUEsQ0FBTTs7O0VBSTFDLE1BQU1pUSxpQkFDSnZULElBQUEsRUFDQWtTLHFCQUFBLEVBQTZDO0lBRTdDLE1BQU1zQyxlQUFBLEdBQWtCLE1BQU0sS0FBSzFCLG1DQUFBLENBQ2pDWixxQkFBcUI7SUFFdkIsT0FBT2xTLElBQUEsS0FBUyxPQUNad1UsZUFBQSxDQUFnQnpKLGlCQUFBLENBQWlCLElBQ2pDeUosZUFBQSxDQUFnQjVKLGNBQUEsQ0FBZTVLLElBQUk7O0VBR2pDLE1BQU04UyxvQ0FDWloscUJBQUEsRUFBNkM7SUFFN0MsSUFBSSxDQUFDLEtBQUswQiwwQkFBQSxFQUE0QjtNQUNwQyxNQUFNYSxRQUFBLEdBQ0h2QyxxQkFBQSxJQUF5QmhKLFlBQUEsQ0FBYWdKLHFCQUFxQixLQUM1RCxLQUFLWCxzQkFBQTtNQUNQamEsT0FBQSxDQUFRbWQsUUFBQSxFQUFVLE1BQUk7TUFDdEIsS0FBS2IsMEJBQUEsR0FBNkIsTUFBTXpKLHNCQUFBLENBQXVCeFQsTUFBQSxDQUM3RCxNQUNBLENBQUN1UyxZQUFBLENBQWF1TCxRQUFBLENBQVNDLG9CQUFvQixDQUFDLEdBQUM7TUFHL0MsS0FBS3pELFlBQUEsR0FDSCxNQUFNLEtBQUsyQywwQkFBQSxDQUEyQi9JLGNBQUEsQ0FBYztJQUN2RDtJQUVELE9BQU8sS0FBSytJLDBCQUFBOztFQUdkLE1BQU1lLG1CQUFtQkMsRUFBQSxFQUFVOztJQUdqQyxJQUFJLEtBQUt4RCxjQUFBLEVBQWdCO01BQ3ZCLE1BQU0sS0FBS3ZELEtBQUEsQ0FBTSxZQUFXLEVBQUc7SUFDaEM7SUFFRCxNQUFJL1YsRUFBQSxRQUFLMGEsWUFBQSxNQUFjLFFBQUExYSxFQUFBLHVCQUFBQSxFQUFBLENBQUFvUSxnQkFBQSxNQUFxQjBNLEVBQUEsRUFBSTtNQUM5QyxPQUFPLEtBQUtwQyxZQUFBO0lBQ2I7SUFFRCxNQUFJcEssRUFBQSxRQUFLNkksWUFBQSxNQUFjLFFBQUE3SSxFQUFBLHVCQUFBQSxFQUFBLENBQUFGLGdCQUFBLE1BQXFCME0sRUFBQSxFQUFJO01BQzlDLE9BQU8sS0FBSzNELFlBQUE7SUFDYjtJQUVELE9BQU87O0VBR1QsTUFBTXJNLHNCQUFzQjVFLElBQUEsRUFBa0I7SUFDNUMsSUFBSUEsSUFBQSxLQUFTLEtBQUs4QixXQUFBLEVBQWE7TUFDN0IsT0FBTyxLQUFLK0wsS0FBQSxDQUFNLFlBQVksS0FBS3FGLHNCQUFBLENBQXVCbFQsSUFBSSxDQUFDO0lBQ2hFOztFQUlINkUsMEJBQTBCN0UsSUFBQSxFQUFrQjtJQUMxQyxJQUFJQSxJQUFBLEtBQVMsS0FBSzhCLFdBQUEsRUFBYTtNQUM3QixLQUFLNlIsbUJBQUEsQ0FBbUI7SUFDekI7O0VBR0g1SixLQUFBLEVBQUk7SUFDRixPQUFPLEdBQUcsS0FBS3pRLE1BQUEsQ0FBT3VaLFVBQUEsSUFBYyxLQUFLdlosTUFBQSxDQUFPZ0MsTUFBQSxJQUFVLEtBQUt6RSxJQUFBOztFQUdqRStRLHVCQUFBLEVBQXNCO0lBQ3BCLEtBQUtzSix5QkFBQSxHQUE0QjtJQUNqQyxJQUFJLEtBQUtwUCxXQUFBLEVBQWE7TUFDcEIsS0FBSzBRLFlBQUEsQ0FBYTVLLHNCQUFBLENBQXNCO0lBQ3pDOztFQUdIQyxzQkFBQSxFQUFxQjtJQUNuQixLQUFLcUoseUJBQUEsR0FBNEI7SUFDakMsSUFBSSxLQUFLcFAsV0FBQSxFQUFhO01BQ3BCLEtBQUswUSxZQUFBLENBQWEzSyxxQkFBQSxDQUFxQjtJQUN4Qzs7RUFJSCxJQUFJMkssYUFBQSxFQUFZO0lBQ2QsT0FBTyxLQUFLMVEsV0FBQTs7RUFHTjZSLG9CQUFBLEVBQW1COztJQUN6QixJQUFJLENBQUMsS0FBS3ZDLGNBQUEsRUFBZ0I7TUFDeEI7SUFDRDtJQUVELEtBQUtMLG1CQUFBLENBQW9COEQsSUFBQSxDQUFLLEtBQUsvUyxXQUFXO0lBRTlDLE1BQU1nVCxVQUFBLElBQWExTSxFQUFBLElBQUF0USxFQUFBLFFBQUtnSyxXQUFBLE1BQWEsUUFBQWhLLEVBQUEsdUJBQUFBLEVBQUEsQ0FBQXdNLEdBQUEsTUFBTyxRQUFBOEQsRUFBQSxjQUFBQSxFQUFBO0lBQzVDLElBQUksS0FBS3dKLGVBQUEsS0FBb0JrRCxVQUFBLEVBQVk7TUFDdkMsS0FBS2xELGVBQUEsR0FBa0JrRCxVQUFBO01BQ3ZCLEtBQUtqRSxxQkFBQSxDQUFzQmdFLElBQUEsQ0FBSyxLQUFLL1MsV0FBVztJQUNqRDs7RUFHS3NTLHNCQUNOVyxZQUFBLEVBQ0FiLGNBQUEsRUFDQXJlLEtBQUEsRUFDQXNlLFNBQUEsRUFBc0I7SUFFdEIsSUFBSSxLQUFLOUMsUUFBQSxFQUFVO01BQ2pCLE9BQU8sTUFBTztJQUNmO0lBRUQsTUFBTTJELEVBQUEsR0FDSixPQUFPZCxjQUFBLEtBQW1CLGFBQ3RCQSxjQUFBLEdBQ0FBLGNBQUEsQ0FBZVcsSUFBQSxDQUFLbEssSUFBQSxDQUFLdUosY0FBYztJQUU3QyxJQUFJZSxjQUFBLEdBQWlCO0lBRXJCLE1BQU0vWSxPQUFBLEdBQVUsS0FBS2tWLGNBQUEsR0FDakJwVixPQUFBLENBQVFpUyxPQUFBLENBQU8sSUFDZixLQUFLcUQsc0JBQUE7SUFDVGhhLE9BQUEsQ0FBUTRFLE9BQUEsRUFBUyxNQUFJO0lBR3JCQSxPQUFBLENBQVFnWixJQUFBLENBQUssTUFBSztNQUNoQixJQUFJRCxjQUFBLEVBQWdCO1FBQ2xCO01BQ0Q7TUFDREQsRUFBQSxDQUFHLEtBQUtsVCxXQUFXO0lBQ3JCLENBQUM7SUFFRCxJQUFJLE9BQU9vUyxjQUFBLEtBQW1CLFlBQVk7TUFDeEMsTUFBTUksV0FBQSxHQUFjUyxZQUFBLENBQWFJLFdBQUEsQ0FDL0JqQixjQUFBLEVBQ0FyZSxLQUFBLEVBQ0FzZSxTQUFTO01BRVgsT0FBTyxNQUFLO1FBQ1ZjLGNBQUEsR0FBaUI7UUFDakJYLFdBQUEsQ0FBVztNQUNiO0lBQ0QsT0FBTTtNQUNMLE1BQU1BLFdBQUEsR0FBY1MsWUFBQSxDQUFhSSxXQUFBLENBQVlqQixjQUFjO01BQzNELE9BQU8sTUFBSztRQUNWZSxjQUFBLEdBQWlCO1FBQ2pCWCxXQUFBLENBQVc7TUFDYjtJQUNEOztFQVFLLE1BQU1wQix1QkFDWmxULElBQUEsRUFBeUI7SUFFekIsSUFBSSxLQUFLOEIsV0FBQSxJQUFlLEtBQUtBLFdBQUEsS0FBZ0I5QixJQUFBLEVBQU07TUFDakQsS0FBS3dTLFlBQUEsQ0FBYTNLLHFCQUFBLENBQXFCO0lBQ3hDO0lBQ0QsSUFBSTdILElBQUEsSUFBUSxLQUFLa1IseUJBQUEsRUFBMkI7TUFDMUNsUixJQUFBLENBQUs0SCxzQkFBQSxDQUFzQjtJQUM1QjtJQUVELEtBQUs5RixXQUFBLEdBQWM5QixJQUFBO0lBRW5CLElBQUlBLElBQUEsRUFBTTtNQUNSLE1BQU0sS0FBS3VTLG1CQUFBLENBQW9CM0gsY0FBQSxDQUFlNUssSUFBSTtJQUNuRCxPQUFNO01BQ0wsTUFBTSxLQUFLdVMsbUJBQUEsQ0FBb0J4SCxpQkFBQSxDQUFpQjtJQUNqRDs7RUFHSzhDLE1BQU11SCxNQUFBLEVBQW1CO0lBRy9CLEtBQUt4RSxVQUFBLEdBQWEsS0FBS0EsVUFBQSxDQUFXc0UsSUFBQSxDQUFLRSxNQUFBLEVBQVFBLE1BQU07SUFDckQsT0FBTyxLQUFLeEUsVUFBQTs7RUFHZCxJQUFZMkIsb0JBQUEsRUFBbUI7SUFDN0JqYixPQUFBLENBQVEsS0FBSzZhLGtCQUFBLEVBQW9CLE1BQUk7SUFDckMsT0FBTyxLQUFLQSxrQkFBQTs7RUFLZGtELGNBQWNDLFNBQUEsRUFBaUI7SUFDN0IsSUFBSSxDQUFDQSxTQUFBLElBQWEsS0FBSzlILFVBQUEsQ0FBVzNCLFFBQUEsQ0FBU3lKLFNBQVMsR0FBRztNQUNyRDtJQUNEO0lBQ0QsS0FBSzlILFVBQUEsQ0FBV1csSUFBQSxDQUFLbUgsU0FBUztJQUk5QixLQUFLOUgsVUFBQSxDQUFXK0gsSUFBQSxDQUFJO0lBQ3BCLEtBQUt4RCxhQUFBLEdBQWdCekUsaUJBQUEsQ0FDbkIsS0FBS2hVLE1BQUEsQ0FBT2lVLGNBQUEsRUFDWixLQUFLaUksY0FBQSxDQUFjLENBQUU7O0VBR3pCQSxlQUFBLEVBQWM7SUFDWixPQUFPLEtBQUtoSSxVQUFBOztFQUVkLE1BQU1qUyxzQkFBQSxFQUFxQjs7SUFFekIsTUFBTXJCLE9BQUEsR0FBa0M7TUFDdEMsQ0FBNkIscUJBQUUsS0FBSzZYOztJQUd0QyxJQUFJLEtBQUt2QixHQUFBLENBQUlpRixPQUFBLENBQVFDLEtBQUEsRUFBTztNQUMxQnhiLE9BQUEsQ0FBTyxzQkFBZ0MsS0FBS3NXLEdBQUEsQ0FBSWlGLE9BQUEsQ0FBUUMsS0FBQTtJQUN6RDtJQUdELE1BQU1DLGdCQUFBLEdBQW1CLFFBQU03ZCxFQUFBLFFBQUsyWSx3QkFBQSxDQUNqQ21GLFlBQUEsQ0FBYTtNQUNaQyxRQUFBLEVBQVU7SUFDWCxRQUNDLFFBQUEvZCxFQUFBLHVCQUFBQSxFQUFBLENBQUFnZSxtQkFBQSxDQUFtQjtJQUN2QixJQUFJSCxnQkFBQSxFQUFrQjtNQUNwQnpiLE9BQUEsQ0FBTyx1QkFBaUN5YixnQkFBQTtJQUN6QztJQUdELE1BQU1JLGFBQUEsR0FBZ0IsTUFBTSxLQUFLQyxpQkFBQSxDQUFpQjtJQUNsRCxJQUFJRCxhQUFBLEVBQWU7TUFDakI3YixPQUFBLENBQU8seUJBQW9DNmIsYUFBQTtJQUM1QztJQUVELE9BQU83YixPQUFBOztFQUdULE1BQU04YixrQkFBQSxFQUFpQjs7SUFDckIsTUFBTUMsbUJBQUEsR0FBc0IsUUFBTW5lLEVBQUEsUUFBSzRZLHVCQUFBLENBQ3BDa0YsWUFBQSxDQUFhO01BQUVDLFFBQUEsRUFBVTtJQUFJLENBQUUsT0FDOUIsUUFBQS9kLEVBQUEsdUJBQUFBLEVBQUEsQ0FBQTBPLFFBQUEsQ0FBUTtJQUNaLElBQUl5UCxtQkFBQSxhQUFBQSxtQkFBQSxLQUFtQixrQkFBbkJBLG1CQUFBLENBQXFCcGdCLEtBQUEsRUFBTztNQUs5QlgsUUFBQSxDQUNFLDJDQUEyQytnQixtQkFBQSxDQUFvQnBnQixLQUFBLEVBQU87SUFFekU7SUFDRCxPQUFPb2dCLG1CQUFBLGFBQUFBLG1CQUFBLEtBQW1CLGtCQUFuQkEsbUJBQUEsQ0FBcUI3VixLQUFBOztBQUUvQjtBQVFLLFNBQVU4VixVQUFVOWYsSUFBQSxFQUFVO0VBQ2xDLFdBQU8vSCxXQUFBLENBQUE2UixrQkFBQSxFQUFtQjlKLElBQUk7QUFDaEM7QUFHQSxJQUFNMGEsWUFBQSxHQUFOLE1BQWtCO0VBTWhCNVosWUFBcUJkLElBQUEsRUFBa0I7SUFBbEIsS0FBSUEsSUFBQSxHQUFKQSxJQUFBO0lBTGIsS0FBUStmLFFBQUEsR0FBOEI7SUFDckMsS0FBQWhCLFdBQUEsT0FBbUM5bUIsV0FBQSxDQUFBK25CLGVBQUEsRUFDMUNELFFBQUEsSUFBYSxLQUFLQSxRQUFBLEdBQVdBLFFBQVM7O0VBS3hDLElBQUl0QixLQUFBLEVBQUk7SUFDTnZkLE9BQUEsQ0FBUSxLQUFLNmUsUUFBQSxFQUFVLEtBQUsvZixJQUFBLEVBQUk7SUFDaEMsT0FBTyxLQUFLK2YsUUFBQSxDQUFTdEIsSUFBQSxDQUFLbEssSUFBQSxDQUFLLEtBQUt3TCxRQUFROztBQUUvQztBQ255QkQsU0FBU0UsdUJBQUEsRUFBc0I7O0VBQzdCLFFBQU9qTyxFQUFBLElBQUF0USxFQUFBLEdBQUFtVixRQUFBLENBQVNxSixvQkFBQSxDQUFxQixNQUFNLE9BQUksUUFBQXhlLEVBQUEsdUJBQUFBLEVBQUEsU0FBRSxRQUFBc1EsRUFBQSxjQUFBQSxFQUFBLEdBQUk2RSxRQUFBO0FBQ3ZEO0FBRU0sU0FBVXNKLFFBQVE5YyxHQUFBLEVBQVc7RUFFakMsT0FBTyxJQUFJdUMsT0FBQSxDQUFRLENBQUNpUyxPQUFBLEVBQVN0USxNQUFBLEtBQVU7SUFDckMsTUFBTTZZLEVBQUEsR0FBS3ZKLFFBQUEsQ0FBU3dKLGFBQUEsQ0FBYyxRQUFRO0lBQzFDRCxFQUFBLENBQUdFLFlBQUEsQ0FBYSxPQUFPamQsR0FBRztJQUMxQitjLEVBQUEsQ0FBR0csTUFBQSxHQUFTMUksT0FBQTtJQUNadUksRUFBQSxDQUFHSSxPQUFBLEdBQVU5WixDQUFBLElBQUk7TUFDZixNQUFNakgsS0FBQSxHQUFRSyxZQUFBLENBQVk7TUFDMUJMLEtBQUEsQ0FBTW9JLFVBQUEsR0FBYW5CLENBQUE7TUFDbkJhLE1BQUEsQ0FBTzlILEtBQUs7SUFDZDtJQUNBMmdCLEVBQUEsQ0FBR2pOLElBQUEsR0FBTztJQUNWaU4sRUFBQSxDQUFHSyxPQUFBLEdBQVU7SUFDYlIsc0JBQUEsQ0FBc0IsRUFBR1MsV0FBQSxDQUFZTixFQUFFO0VBQ3pDLENBQUM7QUFDSDtBQUVNLFNBQVVPLHNCQUFzQkMsTUFBQSxFQUFjO0VBQ2xELE9BQU8sS0FBS0EsTUFBQSxHQUFTN2QsSUFBQSxDQUFLOGQsS0FBQSxDQUFNOWQsSUFBQSxDQUFLK2QsTUFBQSxDQUFNLElBQUssR0FBTztBQUN6RDtBQ1ZBLElBQU1DLHdCQUFBLEdBQ0o7QUFFSyxJQUFNQyxrQ0FBQSxHQUFxQztBQUMzQyxJQUFNQyxVQUFBLEdBQWE7SUFFYkMsMkJBQUEsU0FBMkI7RUFhdENwZ0IsWUFBWXFnQixVQUFBLEVBQWdCO0lBVG5CLEtBQUloTyxJQUFBLEdBQUc2TixrQ0FBQTtJQVVkLEtBQUtoaEIsSUFBQSxHQUFPOGYsU0FBQSxDQUFVcUIsVUFBVTs7RUFRbEMsTUFBTUMsT0FDSnBDLE1BQUEsR0FBaUIsVUFDakJuVixZQUFBLEdBQWUsT0FBSztJQUVwQixlQUFld1gsZ0JBQWdCcmhCLElBQUEsRUFBa0I7TUFDL0MsSUFBSSxDQUFDNkosWUFBQSxFQUFjO1FBQ2pCLElBQUk3SixJQUFBLENBQUtzRSxRQUFBLElBQVksUUFBUXRFLElBQUEsQ0FBS29iLHFCQUFBLElBQXlCLE1BQU07VUFDL0QsT0FBT3BiLElBQUEsQ0FBS29iLHFCQUFBLENBQXNCL1MsT0FBQTtRQUNuQztRQUNELElBQ0VySSxJQUFBLENBQUtzRSxRQUFBLElBQVksUUFDakJ0RSxJQUFBLENBQUtxYix1QkFBQSxDQUF3QnJiLElBQUEsQ0FBS3NFLFFBQUEsTUFBYyxRQUNoRDtVQUNBLE9BQU90RSxJQUFBLENBQUtxYix1QkFBQSxDQUF3QnJiLElBQUEsQ0FBS3NFLFFBQUEsRUFBVStELE9BQUE7UUFDcEQ7TUFDRjtNQUVELE9BQU8sSUFBSXpDLE9BQUEsQ0FBZ0IsT0FBT2lTLE9BQUEsRUFBU3RRLE1BQUEsS0FBVTtRQUNuRHlCLGtCQUFBLENBQW1CaEosSUFBQSxFQUFNO1VBQ3ZCc2hCLFVBQUEsRUFBbUM7VUFDbkNDLE9BQUEsRUFBb0M7U0FDckMsRUFDRXpDLElBQUEsQ0FBSzlhLFFBQUEsSUFBVztVQUNmLElBQUlBLFFBQUEsQ0FBU3VFLFlBQUEsS0FBaUIsUUFBVztZQUN2Q2hCLE1BQUEsQ0FBTyxJQUFJakcsS0FBQSxDQUFNLHlDQUF5QyxDQUFDO1VBQzVELE9BQU07WUFDTCxNQUFNNEIsTUFBQSxHQUFTLElBQUlrRixlQUFBLENBQWdCcEUsUUFBUTtZQUMzQyxJQUFJaEUsSUFBQSxDQUFLc0UsUUFBQSxJQUFZLE1BQU07Y0FDekJ0RSxJQUFBLENBQUtvYixxQkFBQSxHQUF3QmxZLE1BQUE7WUFDOUIsT0FBTTtjQUNMbEQsSUFBQSxDQUFLcWIsdUJBQUEsQ0FBd0JyYixJQUFBLENBQUtzRSxRQUFBLElBQVlwQixNQUFBO1lBQy9DO1lBQ0QsT0FBTzJVLE9BQUEsQ0FBUTNVLE1BQUEsQ0FBT21GLE9BQU87VUFDOUI7UUFDSCxDQUFDLEVBQ0FtWixLQUFBLENBQU0vaEIsS0FBQSxJQUFRO1VBQ2I4SCxNQUFBLENBQU85SCxLQUFLO1FBQ2QsQ0FBQztNQUNMLENBQUM7O0lBR0gsU0FBU2dpQix1QkFDUHBaLE9BQUEsRUFDQXdQLE9BQUEsRUFDQXRRLE1BQUEsRUFBa0M7TUFFbEMsTUFBTVMsVUFBQSxHQUFheU8sTUFBQSxDQUFPek8sVUFBQTtNQUMxQixJQUFJRSxZQUFBLENBQWFGLFVBQVUsR0FBRztRQUM1QkEsVUFBQSxDQUFXRyxVQUFBLENBQVd1WixLQUFBLENBQU0sTUFBSztVQUMvQjFaLFVBQUEsQ0FBV0csVUFBQSxDQUNSd1osT0FBQSxDQUFRdFosT0FBQSxFQUFTO1lBQUUyVztVQUFNLENBQUUsRUFDM0JGLElBQUEsQ0FBSzlVLEtBQUEsSUFBUTtZQUNaNk4sT0FBQSxDQUFRN04sS0FBSztVQUNmLENBQUMsRUFDQXdYLEtBQUEsQ0FBTSxNQUFLO1lBQ1YzSixPQUFBLENBQVFvSixVQUFVO1VBQ3BCLENBQUM7UUFDTCxDQUFDO01BQ0YsT0FBTTtRQUNMMVosTUFBQSxDQUFPakcsS0FBQSxDQUFNLHdDQUF3QyxDQUFDO01BQ3ZEOztJQUdILE9BQU8sSUFBSXNFLE9BQUEsQ0FBZ0IsQ0FBQ2lTLE9BQUEsRUFBU3RRLE1BQUEsS0FBVTtNQUM3QzhaLGVBQUEsQ0FBZ0IsS0FBS3JoQixJQUFJLEVBQ3RCOGUsSUFBQSxDQUFLelcsT0FBQSxJQUFVO1FBQ2QsSUFBSSxDQUFDd0IsWUFBQSxJQUFnQjNCLFlBQUEsQ0FBYXVPLE1BQUEsQ0FBT3pPLFVBQVUsR0FBRztVQUNwRHlaLHNCQUFBLENBQXVCcFosT0FBQSxFQUFTd1AsT0FBQSxFQUFTdFEsTUFBTTtRQUNoRCxPQUFNO1VBQ0wsSUFBSSxPQUFPa1AsTUFBQSxLQUFXLGFBQWE7WUFDakNsUCxNQUFBLENBQ0UsSUFBSWpHLEtBQUEsQ0FBTSxnREFBZ0QsQ0FBQztZQUU3RDtVQUNEO1VBQ0Q2ZSxPQUFBLENBQ1dZLHdCQUFBLEdBQTJCMVksT0FBTyxFQUMxQ3lXLElBQUEsQ0FBSyxNQUFLO1lBQ1QyQyxzQkFBQSxDQUF1QnBaLE9BQUEsRUFBU3dQLE9BQUEsRUFBU3RRLE1BQU07VUFDakQsQ0FBQyxFQUNBaWEsS0FBQSxDQUFNL2hCLEtBQUEsSUFBUTtZQUNiOEgsTUFBQSxDQUFPOUgsS0FBSztVQUNkLENBQUM7UUFDSjtNQUNILENBQUMsRUFDQStoQixLQUFBLENBQU0vaEIsS0FBQSxJQUFRO1FBQ2I4SCxNQUFBLENBQU85SCxLQUFLO01BQ2QsQ0FBQztJQUNMLENBQUM7O0FBRUo7QUFFTSxlQUFlbWlCLHNCQUNwQjVoQixJQUFBLEVBQ0FxRSxPQUFBLEVBQ0EyYSxNQUFBLEVBQ0E2QyxXQUFBLEdBQWMsT0FBSztFQUVuQixNQUFNQyxRQUFBLEdBQVcsSUFBSVosMkJBQUEsQ0FBNEJsaEIsSUFBSTtFQUNyRCxJQUFJK2hCLGVBQUE7RUFDSixJQUFJO0lBQ0ZBLGVBQUEsR0FBa0IsTUFBTUQsUUFBQSxDQUFTVixNQUFBLENBQU9wQyxNQUFNO0VBQy9DLFNBQVF2ZixLQUFBLEVBQVA7SUFDQXNpQixlQUFBLEdBQWtCLE1BQU1ELFFBQUEsQ0FBU1YsTUFBQSxDQUFPcEMsTUFBQSxFQUFRLElBQUk7RUFDckQ7RUFDRCxNQUFNZ0QsVUFBQSxHQUFVNWhCLE1BQUEsQ0FBQUMsTUFBQSxLQUFRZ0UsT0FBTztFQUMvQixJQUFJLENBQUN3ZCxXQUFBLEVBQWE7SUFDaEJ6aEIsTUFBQSxDQUFPQyxNQUFBLENBQU8yaEIsVUFBQSxFQUFZO01BQUVEO0lBQWUsQ0FBRTtFQUM5QyxPQUFNO0lBQ0wzaEIsTUFBQSxDQUFPQyxNQUFBLENBQU8yaEIsVUFBQSxFQUFZO01BQUUsZUFBZUQ7SUFBZSxDQUFFO0VBQzdEO0VBQ0QzaEIsTUFBQSxDQUFPQyxNQUFBLENBQU8yaEIsVUFBQSxFQUFZO0lBQUUsY0FBWTtFQUFBLENBQTJCO0VBQ25FNWhCLE1BQUEsQ0FBT0MsTUFBQSxDQUFPMmhCLFVBQUEsRUFBWTtJQUN4QixvQkFBK0M7RUFDaEQ7RUFDRCxPQUFPQSxVQUFBO0FBQ1Q7QUFPTyxlQUFlQyxvQkFDcEJDLFlBQUEsRUFDQTdkLE9BQUEsRUFDQThkLFVBQUEsRUFDQUMsWUFBQSxFQUErQzs7RUFFL0MsS0FDRTFnQixFQUFBLEdBQUF3Z0IsWUFBQSxDQUNHekUsbUJBQUEsQ0FBbUIsT0FBRSxRQUFBL2IsRUFBQSx1QkFBQUEsRUFBQSxDQUNwQm1ILGlCQUFBLENBQWlCLDRCQUNyQjtJQUNBLE1BQU13WixvQkFBQSxHQUF1QixNQUFNVCxxQkFBQSxDQUNqQ00sWUFBQSxFQUNBN2QsT0FBQSxFQUNBOGQsVUFBQSxFQUNBQSxVQUFBLEtBQVU7SUFFWixPQUFPQyxZQUFBLENBQWFGLFlBQUEsRUFBY0csb0JBQW9CO0VBQ3ZELE9BQU07SUFDTCxPQUFPRCxZQUFBLENBQWFGLFlBQUEsRUFBYzdkLE9BQU8sRUFBRW1kLEtBQUEsQ0FBTSxNQUFNL2hCLEtBQUEsSUFBUTtNQUM3RCxJQUFJQSxLQUFBLENBQU1RLElBQUEsS0FBUyxRQUFRLDZCQUF5QztRQUNsRXFpQixPQUFBLENBQVFDLEdBQUEsQ0FDTixHQUFHSixVQUFBLDhIQUF3STtRQUU3SSxNQUFNRSxvQkFBQSxHQUF1QixNQUFNVCxxQkFBQSxDQUNqQ00sWUFBQSxFQUNBN2QsT0FBQSxFQUNBOGQsVUFBQSxFQUNBQSxVQUFBLEtBQVU7UUFFWixPQUFPQyxZQUFBLENBQWFGLFlBQUEsRUFBY0csb0JBQW9CO01BQ3ZELE9BQU07UUFDTCxPQUFPemMsT0FBQSxDQUFRMkIsTUFBQSxDQUFPOUgsS0FBSztNQUM1QjtJQUNILENBQUM7RUFDRjtBQUNIO0FBRU8sZUFBZStpQiwyQkFBMkJ4aUIsSUFBQSxFQUFVO0VBQ3pELE1BQU15aUIsWUFBQSxHQUFlM0MsU0FBQSxDQUFVOWYsSUFBSTtFQUVuQyxNQUFNZ0UsUUFBQSxHQUFXLE1BQU1nRixrQkFBQSxDQUFtQnlaLFlBQUEsRUFBYztJQUN0RG5CLFVBQUEsRUFBbUM7SUFDbkNDLE9BQUEsRUFBb0M7RUFDckM7RUFFRCxNQUFNcmUsTUFBQSxHQUFTLElBQUlrRixlQUFBLENBQWdCcEUsUUFBUTtFQUMzQyxJQUFJeWUsWUFBQSxDQUFhbmUsUUFBQSxJQUFZLE1BQU07SUFDakNtZSxZQUFBLENBQWFySCxxQkFBQSxHQUF3QmxZLE1BQUE7RUFDdEMsT0FBTTtJQUNMdWYsWUFBQSxDQUFhcEgsdUJBQUEsQ0FBd0JvSCxZQUFBLENBQWFuZSxRQUFBLElBQVlwQixNQUFBO0VBQy9EO0VBRUQsSUFBSUEsTUFBQSxDQUFPMkYsaUJBQUEsQ0FBaUIsNEJBQTZDO0lBQ3ZFLE1BQU1pWixRQUFBLEdBQVcsSUFBSVosMkJBQUEsQ0FBNEJ1QixZQUFZO0lBQzdELEtBQUtYLFFBQUEsQ0FBU1YsTUFBQSxDQUFNO0VBQ3JCO0FBQ0g7QUM3TGdCLFNBQUFwdEIsZUFBZW9tQixHQUFBLEVBQWtCc0ksSUFBQSxFQUFtQjtFQUNsRSxNQUFNL1osUUFBQSxPQUFXdEosVUFBQSxDQUFBc2pCLFlBQUEsRUFBYXZJLEdBQUEsRUFBSyxNQUFNO0VBRXpDLElBQUl6UixRQUFBLENBQVNpYSxhQUFBLENBQWEsR0FBSTtJQUM1QixNQUFNQyxLQUFBLEdBQU9sYSxRQUFBLENBQVM2VyxZQUFBLENBQVk7SUFDbEMsTUFBTXNELGNBQUEsR0FBaUJuYSxRQUFBLENBQVNvYSxVQUFBLENBQVU7SUFDMUMsUUFBSTlxQixXQUFBLENBQUErcUIsU0FBQSxFQUFVRixjQUFBLEVBQWdCSixJQUFBLEtBQUksUUFBSkEsSUFBQSxLQUFJLFNBQUpBLElBQUEsR0FBUSxFQUFFLEdBQUc7TUFDekMsT0FBT0csS0FBQTtJQUNSLE9BQU07TUFDTG5qQixLQUFBLENBQU1takIsS0FBQSxFQUFJO0lBQ1g7RUFDRjtFQUVELE1BQU03aUIsSUFBQSxHQUFPMkksUUFBQSxDQUFTbkYsVUFBQSxDQUFXO0lBQUU2YixPQUFBLEVBQVNxRDtFQUFJLENBQUU7RUFFbEQsT0FBTzFpQixJQUFBO0FBQ1Q7QUFFZ0IsU0FBQWlqQix3QkFDZGpqQixJQUFBLEVBQ0EwaUIsSUFBQSxFQUFtQjtFQUVuQixNQUFNMU8sV0FBQSxJQUFjME8sSUFBQSxhQUFBQSxJQUFBLHVCQUFBQSxJQUFBLENBQU0xTyxXQUFBLEtBQWU7RUFDekMsTUFBTWtQLFNBQUEsSUFDSjFRLEtBQUEsQ0FBTUMsT0FBQSxDQUFRdUIsV0FBVyxJQUFJQSxXQUFBLEdBQWMsQ0FBQ0EsV0FBVyxHQUN2RDdFLEdBQUEsQ0FBeUIyRCxZQUFZO0VBQ3ZDLElBQUk0UCxJQUFBLGFBQUFBLElBQUEsS0FBSSxrQkFBSkEsSUFBQSxDQUFNdmlCLFFBQUEsRUFBVTtJQUNsQkgsSUFBQSxDQUFLNmQsZUFBQSxDQUFnQjZFLElBQUEsQ0FBS3ZpQixRQUFRO0VBQ25DO0VBS0RILElBQUEsQ0FBSzZiLDBCQUFBLENBQTJCcUgsU0FBQSxFQUFXUixJQUFBLGFBQUFBLElBQUEsdUJBQUFBLElBQUEsQ0FBTTVHLHFCQUFxQjtBQUN4RTtTQzNDZ0Izb0Isb0JBQ2Q2TSxJQUFBLEVBQ0FxRCxHQUFBLEVBQ0FnYyxPQUFBLEVBQXNDO0VBRXRDLE1BQU1vRCxZQUFBLEdBQWUzQyxTQUFBLENBQVU5ZixJQUFJO0VBQ25Da0IsT0FBQSxDQUNFdWhCLFlBQUEsQ0FBYWhkLGdCQUFBLEVBQ2JnZCxZQUFBLEVBQVk7RUFJZHZoQixPQUFBLENBQ0UsZUFBZW1WLElBQUEsQ0FBS2hULEdBQUcsR0FDdkJvZixZQUFBLEVBQVk7RUFJZCxNQUFNVSxlQUFBLEdBQWtCLENBQUMsRUFBQzlELE9BQUEsYUFBQUEsT0FBQSx1QkFBQUEsT0FBQSxDQUFTOEQsZUFBQTtFQUVuQyxNQUFNcGhCLFFBQUEsR0FBV3FoQixlQUFBLENBQWdCL2YsR0FBRztFQUNwQyxNQUFNO0lBQUUyRCxJQUFBO0lBQU1xYztFQUFJLElBQUtDLGtCQUFBLENBQW1CamdCLEdBQUc7RUFDN0MsTUFBTWtnQixPQUFBLEdBQVVGLElBQUEsS0FBUyxPQUFPLEtBQUssSUFBSUEsSUFBQTtFQUd6Q1osWUFBQSxDQUFhdmYsTUFBQSxDQUFPRSxRQUFBLEdBQVc7SUFBRUMsR0FBQSxFQUFLLEdBQUd0QixRQUFBLEtBQWFpRixJQUFBLEdBQU91YyxPQUFBO0VBQVU7RUFDdkVkLFlBQUEsQ0FBYWhILFFBQUEsQ0FBU0MsaUNBQUEsR0FBb0M7RUFDMUQrRyxZQUFBLENBQWFsSSxjQUFBLEdBQWlCbmEsTUFBQSxDQUFPb2pCLE1BQUEsQ0FBTztJQUMxQ3hjLElBQUE7SUFDQXFjLElBQUE7SUFDQXRoQixRQUFBLEVBQVVBLFFBQUEsQ0FBUzBFLE9BQUEsQ0FBUSxLQUFLLEVBQUU7SUFDbEM0WSxPQUFBLEVBQVNqZixNQUFBLENBQU9vakIsTUFBQSxDQUFPO01BQUVMO0lBQWUsQ0FBRTtFQUMzQztFQUVELElBQUksQ0FBQ0EsZUFBQSxFQUFpQjtJQUNwQk0sbUJBQUEsQ0FBbUI7RUFDcEI7QUFDSDtBQUVBLFNBQVNMLGdCQUFnQi9mLEdBQUEsRUFBVztFQUNsQyxNQUFNcWdCLFdBQUEsR0FBY3JnQixHQUFBLENBQUlzZ0IsT0FBQSxDQUFRLEdBQUc7RUFDbkMsT0FBT0QsV0FBQSxHQUFjLElBQUksS0FBS3JnQixHQUFBLENBQUl1Z0IsTUFBQSxDQUFPLEdBQUdGLFdBQUEsR0FBYyxDQUFDO0FBQzdEO0FBRUEsU0FBU0osbUJBQW1CamdCLEdBQUEsRUFBVztFQUlyQyxNQUFNdEIsUUFBQSxHQUFXcWhCLGVBQUEsQ0FBZ0IvZixHQUFHO0VBQ3BDLE1BQU13Z0IsU0FBQSxHQUFZLG1CQUFtQkMsSUFBQSxDQUFLemdCLEdBQUEsQ0FBSXVnQixNQUFBLENBQU83aEIsUUFBQSxDQUFTMkcsTUFBTSxDQUFDO0VBQ3JFLElBQUksQ0FBQ21iLFNBQUEsRUFBVztJQUNkLE9BQU87TUFBRTdjLElBQUEsRUFBTTtNQUFJcWMsSUFBQSxFQUFNO0lBQUk7RUFDOUI7RUFDRCxNQUFNVSxXQUFBLEdBQWNGLFNBQUEsQ0FBVSxHQUFHdmQsS0FBQSxDQUFNLEdBQUcsRUFBRTBkLEdBQUEsQ0FBRyxLQUFNO0VBQ3JELE1BQU1DLGFBQUEsR0FBZ0IscUJBQXFCSCxJQUFBLENBQUtDLFdBQVc7RUFDM0QsSUFBSUUsYUFBQSxFQUFlO0lBQ2pCLE1BQU1qZCxJQUFBLEdBQU9pZCxhQUFBLENBQWM7SUFDM0IsT0FBTztNQUFFamQsSUFBQTtNQUFNcWMsSUFBQSxFQUFNYSxTQUFBLENBQVVILFdBQUEsQ0FBWUgsTUFBQSxDQUFPNWMsSUFBQSxDQUFLMEIsTUFBQSxHQUFTLENBQUMsQ0FBQztJQUFDO0VBQ3BFLE9BQU07SUFDTCxNQUFNLENBQUMxQixJQUFBLEVBQU1xYyxJQUFJLElBQUlVLFdBQUEsQ0FBWXpkLEtBQUEsQ0FBTSxHQUFHO0lBQzFDLE9BQU87TUFBRVUsSUFBQTtNQUFNcWMsSUFBQSxFQUFNYSxTQUFBLENBQVViLElBQUk7SUFBQztFQUNyQztBQUNIO0FBRUEsU0FBU2EsVUFBVVgsT0FBQSxFQUFlO0VBQ2hDLElBQUksQ0FBQ0EsT0FBQSxFQUFTO0lBQ1osT0FBTztFQUNSO0VBQ0QsTUFBTUYsSUFBQSxHQUFPN1osTUFBQSxDQUFPK1osT0FBTztFQUMzQixJQUFJOVosS0FBQSxDQUFNNFosSUFBSSxHQUFHO0lBQ2YsT0FBTztFQUNSO0VBQ0QsT0FBT0EsSUFBQTtBQUNUO0FBRUEsU0FBU0ksb0JBQUEsRUFBbUI7RUFDMUIsU0FBU1UsYUFBQSxFQUFZO0lBQ25CLE1BQU0vRCxFQUFBLEdBQUt2SixRQUFBLENBQVN3SixhQUFBLENBQWMsR0FBRztJQUNyQyxNQUFNK0QsR0FBQSxHQUFNaEUsRUFBQSxDQUFHaUUsS0FBQTtJQUNmakUsRUFBQSxDQUFHa0UsU0FBQSxHQUNEO0lBQ0ZGLEdBQUEsQ0FBSUcsUUFBQSxHQUFXO0lBQ2ZILEdBQUEsQ0FBSUksS0FBQSxHQUFRO0lBQ1pKLEdBQUEsQ0FBSUssZUFBQSxHQUFrQjtJQUN0QkwsR0FBQSxDQUFJTSxNQUFBLEdBQVM7SUFDYk4sR0FBQSxDQUFJTyxLQUFBLEdBQVE7SUFDWlAsR0FBQSxDQUFJUSxNQUFBLEdBQVM7SUFDYlIsR0FBQSxDQUFJUyxJQUFBLEdBQU87SUFDWFQsR0FBQSxDQUFJVSxNQUFBLEdBQVM7SUFDYlYsR0FBQSxDQUFJVyxNQUFBLEdBQVM7SUFDYlgsR0FBQSxDQUFJWSxTQUFBLEdBQVk7SUFDaEI1RSxFQUFBLENBQUc2RSxTQUFBLENBQVVDLEdBQUEsQ0FBSSwyQkFBMkI7SUFDNUNyTyxRQUFBLENBQVNsUyxJQUFBLENBQUsrYixXQUFBLENBQVlOLEVBQUU7O0VBRzlCLElBQUksT0FBT2tDLE9BQUEsS0FBWSxlQUFlLE9BQU9BLE9BQUEsQ0FBUTZDLElBQUEsS0FBUyxZQUFZO0lBQ3hFN0MsT0FBQSxDQUFRNkMsSUFBQSxDQUNOLDhIQUU0QjtFQUUvQjtFQUNELElBQUksT0FBTzFPLE1BQUEsS0FBVyxlQUFlLE9BQU9JLFFBQUEsS0FBYSxhQUFhO0lBQ3BFLElBQUlBLFFBQUEsQ0FBU3VPLFVBQUEsS0FBZSxXQUFXO01BQ3JDM08sTUFBQSxDQUFPNE8sZ0JBQUEsQ0FBaUIsb0JBQW9CbEIsWUFBWTtJQUN6RCxPQUFNO01BQ0xBLFlBQUEsQ0FBWTtJQUNiO0VBQ0Y7QUFDSDtJQzFIYTd5QixjQUFBLFNBQWM7RUFFekJ3UCxZQU9XbU8sVUFBQSxFQVNBcVcsWUFBQSxFQUFvQjtJQVRwQixLQUFVclcsVUFBQSxHQUFWQSxVQUFBO0lBU0EsS0FBWXFXLFlBQUEsR0FBWkEsWUFBQTs7RUFRWHBZLE9BQUEsRUFBTTtJQUNKLE9BQU85TCxTQUFBLENBQVUsaUJBQWlCOztFQUlwQ21rQixvQkFBb0JDLEtBQUEsRUFBbUI7SUFDckMsT0FBT3BrQixTQUFBLENBQVUsaUJBQWlCOztFQUdwQ3FrQixlQUNFRCxLQUFBLEVBQ0FFLFFBQUEsRUFBZ0I7SUFFaEIsT0FBT3RrQixTQUFBLENBQVUsaUJBQWlCOztFQUdwQ3VrQiw2QkFBNkJILEtBQUEsRUFBbUI7SUFDOUMsT0FBT3BrQixTQUFBLENBQVUsaUJBQWlCOztBQUVyQztBQ2pDTSxlQUFld2tCLGNBQ3BCNWxCLElBQUEsRUFDQXFFLE9BQUEsRUFBNkI7RUFFN0IsT0FBT0Usa0JBQUEsQ0FDTHZFLElBQUEsRUFHQSxzQ0FBQW9FLGtCQUFBLENBQW1CcEUsSUFBQSxFQUFNcUUsT0FBTyxDQUFDO0FBRXJDO0FBVU8sZUFBZXdoQixvQkFDcEI3bEIsSUFBQSxFQUNBcUUsT0FBQSxFQUFtQztFQUVuQyxPQUFPRSxrQkFBQSxDQUdMdkUsSUFBQSxFQUFrRCwrQkFBQXFFLE9BQU87QUFDN0Q7QUFJTyxlQUFleWhCLGtCQUNwQjlsQixJQUFBLEVBQ0FxRSxPQUFBLEVBQXNCO0VBRXRCLE9BQU9FLGtCQUFBLENBQ0x2RSxJQUFBLEVBR0EsK0JBQUFxRSxPQUFPO0FBRVg7QUFTTyxlQUFlMGhCLGtCQUNwQi9sQixJQUFBLEVBQ0FxRSxPQUFBLEVBQStCO0VBRS9CLE9BQU9FLGtCQUFBLENBQ0x2RSxJQUFBLEVBR0EsK0JBQUFvRSxrQkFBQSxDQUFtQnBFLElBQUEsRUFBTXFFLE9BQU8sQ0FBQztBQUVyQztBQzFETyxlQUFlMmhCLG1CQUNwQmhtQixJQUFBLEVBQ0FxRSxPQUFBLEVBQWtDO0VBRWxDLE9BQU93QyxxQkFBQSxDQUlMN0csSUFBQSxFQUdBLDJDQUFBb0Usa0JBQUEsQ0FBbUJwRSxJQUFBLEVBQU1xRSxPQUFPLENBQUM7QUFFckM7QUFvREEsZUFBZTRoQixZQUNiam1CLElBQUEsRUFDQXFFLE9BQUEsRUFBMEI7RUFFMUIsT0FBT0Usa0JBQUEsQ0FDTHZFLElBQUEsRUFHQSxvQ0FBQW9FLGtCQUFBLENBQW1CcEUsSUFBQSxFQUFNcUUsT0FBTyxDQUFDO0FBRXJDO0FBRU8sZUFBZTZoQix3QkFDcEJsbUIsSUFBQSxFQUNBcUUsT0FBQSxFQUEyQjtFQUUzQixPQUFPNGhCLFdBQUEsQ0FBWWptQixJQUFBLEVBQU1xRSxPQUFPO0FBQ2xDO0FBRU8sZUFBZThoQix5QkFDcEJubUIsSUFBQSxFQUNBcUUsT0FBQSxFQUE2QjtFQUU3QixPQUFPNGhCLFdBQUEsQ0FBWWptQixJQUFBLEVBQU1xRSxPQUFPO0FBQ2xDO0FBRU8sZUFBZStoQix3QkFDcEJwbUIsSUFBQSxFQUNBcUUsT0FBQSxFQUEyQjtFQUUzQixPQUFPNGhCLFdBQUEsQ0FBWWptQixJQUFBLEVBQU1xRSxPQUFPO0FBQ2xDO0FBRU8sZUFBZWdpQixxQkFDcEJybUIsSUFBQSxFQUNBcUUsT0FBQSxFQUFvQztFQUVwQyxPQUFPNGhCLFdBQUEsQ0FBWWptQixJQUFBLEVBQU1xRSxPQUFPO0FBQ2xDO0FDL0dPLGVBQWVpaUIsc0JBQ3BCdG1CLElBQUEsRUFDQXFFLE9BQUEsRUFBbUM7RUFFbkMsT0FBT3dDLHFCQUFBLENBSUw3RyxJQUFBLEVBR0EsNENBQUFvRSxrQkFBQSxDQUFtQnBFLElBQUEsRUFBTXFFLE9BQU8sQ0FBQztBQUVyQztBQU9PLGVBQWVraUIsOEJBQ3BCdm1CLElBQUEsRUFDQXFFLE9BQUEsRUFBNkM7RUFFN0MsT0FBT3dDLHFCQUFBLENBSUw3RyxJQUFBLEVBR0EsNENBQUFvRSxrQkFBQSxDQUFtQnBFLElBQUEsRUFBTXFFLE9BQU8sQ0FBQztBQUVyQztBQ3hCTSxJQUFPNVMsbUJBQUEsR0FBUCxjQUFtQ0gsY0FBQSxDQUFjO0VBRXJEd1AsWUFFVzBsQixNQUFBLEVBRUFDLFNBQUEsRUFDVG5CLFlBQUEsRUFFU29CLFNBQUEsR0FBMkIsTUFBSTtJQUV4QyxNQUFLLFlBQXNCcEIsWUFBWTtJQVA5QixLQUFNa0IsTUFBQSxHQUFOQSxNQUFBO0lBRUEsS0FBU0MsU0FBQSxHQUFUQSxTQUFBO0lBR0EsS0FBU0MsU0FBQSxHQUFUQSxTQUFBOztFQU1YLE9BQU9DLHNCQUNMaGYsS0FBQSxFQUNBNFIsUUFBQSxFQUFnQjtJQUVoQixPQUFPLElBQUk5bkIsbUJBQUEsQ0FDVGtXLEtBQUEsRUFDQTRSLFFBQUEsRUFBUTs7RUFNWixPQUFPcU4sa0JBQ0xqZixLQUFBLEVBQ0FrZixPQUFBLEVBQ0F2aUIsUUFBQSxHQUEwQixNQUFJO0lBRTlCLE9BQU8sSUFBSTdTLG1CQUFBLENBQ1RrVyxLQUFBLEVBQ0FrZixPQUFBLEVBQU8sYUFFUHZpQixRQUFROztFQUtaNEksT0FBQSxFQUFNO0lBQ0osT0FBTztNQUNMdkYsS0FBQSxFQUFPLEtBQUs2ZSxNQUFBO01BQ1pqTixRQUFBLEVBQVUsS0FBS2tOLFNBQUE7TUFDZm5CLFlBQUEsRUFBYyxLQUFLQSxZQUFBO01BQ25CaGhCLFFBQUEsRUFBVSxLQUFLb2lCOzs7RUFZbkIsT0FBT2pXLFNBQVN6SyxJQUFBLEVBQXFCO0lBQ25DLE1BQU04Z0IsR0FBQSxHQUFNLE9BQU85Z0IsSUFBQSxLQUFTLFdBQVduQixJQUFBLENBQUtzRyxLQUFBLENBQU1uRixJQUFJLElBQUlBLElBQUE7SUFDMUQsS0FBSThnQixHQUFBLEtBQUcsUUFBSEEsR0FBQSxLQUFHLGtCQUFIQSxHQUFBLENBQUtuZixLQUFBLE1BQVNtZixHQUFBLEtBQUcsUUFBSEEsR0FBQSxLQUFHLGtCQUFIQSxHQUFBLENBQUt2TixRQUFBLEdBQVU7TUFDL0IsSUFBSXVOLEdBQUEsQ0FBSXhCLFlBQUEsS0FBWSxZQUFrQztRQUNwRCxPQUFPLEtBQUtxQixxQkFBQSxDQUFzQkcsR0FBQSxDQUFJbmYsS0FBQSxFQUFPbWYsR0FBQSxDQUFJdk4sUUFBUTtNQUMxRCxXQUFVdU4sR0FBQSxDQUFJeEIsWUFBQSxLQUFZLGFBQThCO1FBQ3ZELE9BQU8sS0FBS3NCLGlCQUFBLENBQWtCRSxHQUFBLENBQUluZixLQUFBLEVBQU9tZixHQUFBLENBQUl2TixRQUFBLEVBQVV1TixHQUFBLENBQUl4aUIsUUFBUTtNQUNwRTtJQUNGO0lBQ0QsT0FBTzs7RUFJVCxNQUFNaWhCLG9CQUFvQnZsQixJQUFBLEVBQWtCO0lBQzFDLFFBQVEsS0FBS3NsQixZQUFBO1dBQ1g7UUFDRSxNQUFNamhCLE9BQUEsR0FBcUM7VUFDekMwaUIsaUJBQUEsRUFBbUI7VUFDbkJwZixLQUFBLEVBQU8sS0FBSzZlLE1BQUE7VUFDWmpOLFFBQUEsRUFBVSxLQUFLa04sU0FBQTtVQUNmbkYsVUFBQSxFQUFtQzs7UUFFckMsT0FBT1csbUJBQUEsQ0FDTGppQixJQUFBLEVBQ0FxRSxPQUFBLEVBRUEsc0JBQUEyaEIsa0JBQWtCO1dBRXRCO1FBQ0UsT0FBT00scUJBQUEsQ0FBb0J0bUIsSUFBQSxFQUFNO1VBQy9CMkgsS0FBQSxFQUFPLEtBQUs2ZSxNQUFBO1VBQ1pLLE9BQUEsRUFBUyxLQUFLSjtRQUNmOztRQUVEL21CLEtBQUEsQ0FBTU0sSUFBQSxFQUFJOzs7RUFLaEIsTUFBTXlsQixlQUNKemxCLElBQUEsRUFDQW9OLE9BQUEsRUFBZTtJQUVmLFFBQVEsS0FBS2tZLFlBQUE7V0FDWDtRQUNFLE1BQU1qaEIsT0FBQSxHQUF5QjtVQUM3QitJLE9BQUE7VUFDQTJaLGlCQUFBLEVBQW1CO1VBQ25CcGYsS0FBQSxFQUFPLEtBQUs2ZSxNQUFBO1VBQ1pqTixRQUFBLEVBQVUsS0FBS2tOLFNBQUE7VUFDZm5GLFVBQUEsRUFBbUM7O1FBRXJDLE9BQU9XLG1CQUFBLENBQ0xqaUIsSUFBQSxFQUNBcUUsT0FBQSxFQUVBLGtCQUFBeWhCLGlCQUFpQjtXQUVyQjtRQUNFLE9BQU9TLDZCQUFBLENBQThCdm1CLElBQUEsRUFBTTtVQUN6Q29OLE9BQUE7VUFDQXpGLEtBQUEsRUFBTyxLQUFLNmUsTUFBQTtVQUNaSyxPQUFBLEVBQVMsS0FBS0o7UUFDZjs7UUFFRC9tQixLQUFBLENBQU1NLElBQUEsRUFBSTs7O0VBS2hCMmxCLDZCQUE2QjNsQixJQUFBLEVBQWtCO0lBQzdDLE9BQU8sS0FBS3VsQixtQkFBQSxDQUFvQnZsQixJQUFJOztBQUV2QztBQ2hJTSxlQUFlZ25CLGNBQ3BCaG5CLElBQUEsRUFDQXFFLE9BQUEsRUFBNkI7RUFFN0IsT0FBT3dDLHFCQUFBLENBQ0w3RyxJQUFBLEVBR0Esc0NBQUFvRSxrQkFBQSxDQUFtQnBFLElBQUEsRUFBTXFFLE9BQU8sQ0FBQztBQUVyQztBQzlCQSxJQUFNNGlCLGlCQUFBLEdBQWtCO0FBNkJsQixJQUFPbDFCLGVBQUEsR0FBUCxjQUErQlQsY0FBQSxDQUFjO0VBQW5Ed1AsWUFBQTs7SUFxQlUsS0FBWW9tQixZQUFBLEdBQWtCOztFQUd0QyxPQUFPQyxZQUFZdmlCLE1BQUEsRUFBNkI7SUFDOUMsTUFBTXdpQixJQUFBLEdBQU8sSUFBSXIxQixlQUFBLENBQWdCNlMsTUFBQSxDQUFPcUssVUFBQSxFQUFZckssTUFBQSxDQUFPMGdCLFlBQVk7SUFFdkUsSUFBSTFnQixNQUFBLENBQU93SSxPQUFBLElBQVd4SSxNQUFBLENBQU84SyxXQUFBLEVBQWE7TUFFeEMsSUFBSTlLLE1BQUEsQ0FBT3dJLE9BQUEsRUFBUztRQUNsQmdhLElBQUEsQ0FBS2hhLE9BQUEsR0FBVXhJLE1BQUEsQ0FBT3dJLE9BQUE7TUFDdkI7TUFFRCxJQUFJeEksTUFBQSxDQUFPOEssV0FBQSxFQUFhO1FBQ3RCMFgsSUFBQSxDQUFLMVgsV0FBQSxHQUFjOUssTUFBQSxDQUFPOEssV0FBQTtNQUMzQjtNQUdELElBQUk5SyxNQUFBLENBQU95aUIsS0FBQSxJQUFTLENBQUN6aUIsTUFBQSxDQUFPc2lCLFlBQUEsRUFBYztRQUN4Q0UsSUFBQSxDQUFLQyxLQUFBLEdBQVF6aUIsTUFBQSxDQUFPeWlCLEtBQUE7TUFDckI7TUFFRCxJQUFJemlCLE1BQUEsQ0FBT3NpQixZQUFBLEVBQWM7UUFDdkJFLElBQUEsQ0FBS0YsWUFBQSxHQUFldGlCLE1BQUEsQ0FBT3NpQixZQUFBO01BQzVCO0lBQ0YsV0FBVXRpQixNQUFBLENBQU8waUIsVUFBQSxJQUFjMWlCLE1BQUEsQ0FBTzJpQixnQkFBQSxFQUFrQjtNQUV2REgsSUFBQSxDQUFLMVgsV0FBQSxHQUFjOUssTUFBQSxDQUFPMGlCLFVBQUE7TUFDMUJGLElBQUEsQ0FBS0ksTUFBQSxHQUFTNWlCLE1BQUEsQ0FBTzJpQixnQkFBQTtJQUN0QixPQUFNO01BQ0w3bkIsS0FBQSxDQUFLO0lBQ047SUFFRCxPQUFPMG5CLElBQUE7O0VBSVRsYSxPQUFBLEVBQU07SUFDSixPQUFPO01BQ0xFLE9BQUEsRUFBUyxLQUFLQSxPQUFBO01BQ2RzQyxXQUFBLEVBQWEsS0FBS0EsV0FBQTtNQUNsQjhYLE1BQUEsRUFBUSxLQUFLQSxNQUFBO01BQ2JILEtBQUEsRUFBTyxLQUFLQSxLQUFBO01BQ1pILFlBQUEsRUFBYyxLQUFLQSxZQUFBO01BQ25CalksVUFBQSxFQUFZLEtBQUtBLFVBQUE7TUFDakJxVyxZQUFBLEVBQWMsS0FBS0E7OztFQWF2QixPQUFPN1UsU0FBU3pLLElBQUEsRUFBcUI7SUFDbkMsTUFBTThnQixHQUFBLEdBQU0sT0FBTzlnQixJQUFBLEtBQVMsV0FBV25CLElBQUEsQ0FBS3NHLEtBQUEsQ0FBTW5GLElBQUksSUFBSUEsSUFBQTtJQUMxRCxNQUFNO1FBQUVpSixVQUFBO1FBQVlxVztNQUFZLElBQXFDd0IsR0FBQTtNQUFoQ2xuQixJQUFBLE9BQWdDd1AsWUFBQSxDQUFBQyxNQUFBLEVBQUF5WCxHQUFBLEVBQS9ELDhCQUFxQztJQUMzQyxJQUFJLENBQUM3WCxVQUFBLElBQWMsQ0FBQ3FXLFlBQUEsRUFBYztNQUNoQyxPQUFPO0lBQ1I7SUFFRCxNQUFNOEIsSUFBQSxHQUFPLElBQUlyMUIsZUFBQSxDQUFnQmtkLFVBQUEsRUFBWXFXLFlBQVk7SUFDekQ4QixJQUFBLENBQUtoYSxPQUFBLEdBQVV4TixJQUFBLENBQUt3TixPQUFBLElBQVc7SUFDL0JnYSxJQUFBLENBQUsxWCxXQUFBLEdBQWM5UCxJQUFBLENBQUs4UCxXQUFBLElBQWU7SUFDdkMwWCxJQUFBLENBQUtJLE1BQUEsR0FBUzVuQixJQUFBLENBQUs0bkIsTUFBQTtJQUNuQkosSUFBQSxDQUFLQyxLQUFBLEdBQVF6bkIsSUFBQSxDQUFLeW5CLEtBQUE7SUFDbEJELElBQUEsQ0FBS0YsWUFBQSxHQUFldG5CLElBQUEsQ0FBS3NuQixZQUFBLElBQWdCO0lBQ3pDLE9BQU9FLElBQUE7O0VBSVQ3QixvQkFBb0J2bEIsSUFBQSxFQUFrQjtJQUNwQyxNQUFNcUUsT0FBQSxHQUFVLEtBQUtvakIsWUFBQSxDQUFZO0lBQ2pDLE9BQU9ULGFBQUEsQ0FBY2huQixJQUFBLEVBQU1xRSxPQUFPOztFQUlwQ29oQixlQUNFemxCLElBQUEsRUFDQW9OLE9BQUEsRUFBZTtJQUVmLE1BQU0vSSxPQUFBLEdBQVUsS0FBS29qQixZQUFBLENBQVk7SUFDakNwakIsT0FBQSxDQUFRK0ksT0FBQSxHQUFVQSxPQUFBO0lBQ2xCLE9BQU80WixhQUFBLENBQWNobkIsSUFBQSxFQUFNcUUsT0FBTzs7RUFJcENzaEIsNkJBQTZCM2xCLElBQUEsRUFBa0I7SUFDN0MsTUFBTXFFLE9BQUEsR0FBVSxLQUFLb2pCLFlBQUEsQ0FBWTtJQUNqQ3BqQixPQUFBLENBQVFxakIsVUFBQSxHQUFhO0lBQ3JCLE9BQU9WLGFBQUEsQ0FBY2huQixJQUFBLEVBQU1xRSxPQUFPOztFQUc1Qm9qQixhQUFBLEVBQVk7SUFDbEIsTUFBTXBqQixPQUFBLEdBQWdDO01BQ3BDc2pCLFVBQUEsRUFBWVYsaUJBQUE7TUFDWkYsaUJBQUEsRUFBbUI7O0lBR3JCLElBQUksS0FBS0csWUFBQSxFQUFjO01BQ3JCN2lCLE9BQUEsQ0FBUTZpQixZQUFBLEdBQWUsS0FBS0EsWUFBQTtJQUM3QixPQUFNO01BQ0wsTUFBTVUsUUFBQSxHQUFtQztNQUN6QyxJQUFJLEtBQUt4YSxPQUFBLEVBQVM7UUFDaEJ3YSxRQUFBLENBQVMsY0FBYyxLQUFLeGEsT0FBQTtNQUM3QjtNQUNELElBQUksS0FBS3NDLFdBQUEsRUFBYTtRQUNwQmtZLFFBQUEsQ0FBUyxrQkFBa0IsS0FBS2xZLFdBQUE7TUFDakM7TUFDRCxJQUFJLEtBQUs4WCxNQUFBLEVBQVE7UUFDZkksUUFBQSxDQUFTLHdCQUF3QixLQUFLSixNQUFBO01BQ3ZDO01BRURJLFFBQUEsQ0FBUyxnQkFBZ0IsS0FBSzNZLFVBQUE7TUFDOUIsSUFBSSxLQUFLb1ksS0FBQSxJQUFTLENBQUMsS0FBS0gsWUFBQSxFQUFjO1FBQ3BDVSxRQUFBLENBQVMsV0FBVyxLQUFLUCxLQUFBO01BQzFCO01BRURoakIsT0FBQSxDQUFRdWpCLFFBQUEsT0FBVzN2QixXQUFBLENBQUErTSxXQUFBLEVBQVk0aUIsUUFBUTtJQUN4QztJQUVELE9BQU92akIsT0FBQTs7QUFFVjtBQ3JLTSxlQUFld2pCLDBCQUNwQjduQixJQUFBLEVBQ0FxRSxPQUFBLEVBQXlDO0VBRXpDLE9BQU9FLGtCQUFBLENBSUx2RSxJQUFBLEVBR0EsNkNBQUFvRSxrQkFBQSxDQUFtQnBFLElBQUEsRUFBTXFFLE9BQU8sQ0FBQztBQUVyQztBQTBCTyxlQUFleWpCLHdCQUNwQjluQixJQUFBLEVBQ0FxRSxPQUFBLEVBQXFDO0VBRXJDLE9BQU93QyxxQkFBQSxDQUlMN0csSUFBQSxFQUdBLDhDQUFBb0Usa0JBQUEsQ0FBbUJwRSxJQUFBLEVBQU1xRSxPQUFPLENBQUM7QUFFckM7QUFFTyxlQUFlMGpCLHNCQUNwQi9uQixJQUFBLEVBQ0FxRSxPQUFBLEVBQW1DO0VBRW5DLE1BQU1MLFFBQUEsR0FBVyxNQUFNNkMscUJBQUEsQ0FJckI3RyxJQUFBLEVBQUksOENBR0pvRSxrQkFBQSxDQUFtQnBFLElBQUEsRUFBTXFFLE9BQU8sQ0FBQztFQUVuQyxJQUFJTCxRQUFBLENBQVNna0IsY0FBQSxFQUFnQjtJQUMzQixNQUFNL2hCLGdCQUFBLENBQWlCakcsSUFBQSxFQUF1Qyw0Q0FBQWdFLFFBQVE7RUFDdkU7RUFDRCxPQUFPQSxRQUFBO0FBQ1Q7QUFPQSxJQUFNaWtCLDJDQUFBLEdBRUY7RUFDRixvQkFBd0Q7O0FBR25ELGVBQWVDLDZCQUNwQmxvQixJQUFBLEVBQ0FxRSxPQUFBLEVBQXFDO0VBRXJDLE1BQU04akIsVUFBQSxHQUFVL25CLE1BQUEsQ0FBQUMsTUFBQSxDQUFBRCxNQUFBLENBQUFDLE1BQUEsS0FDWGdFLE9BQU87SUFDVitqQixTQUFBLEVBQVc7RUFBUTtFQUVyQixPQUFPdmhCLHFCQUFBLENBSUw3RyxJQUFBLEVBQUksOENBR0pvRSxrQkFBQSxDQUFtQnBFLElBQUEsRUFBTW1vQixVQUFVLEdBQ25DRiwyQ0FBMkM7QUFFL0M7QUNwR00sSUFBTy8xQixtQkFBQSxHQUFQLGNBQW1DWixjQUFBLENBQWM7RUFDckR3UCxZQUFxQzhELE1BQUEsRUFBcUM7SUFDeEUsTUFBSztJQUQ4QixLQUFNQSxNQUFBLEdBQU5BLE1BQUE7O0VBS3JDLE9BQU95akIsa0JBQ0xDLGNBQUEsRUFDQUMsZ0JBQUEsRUFBd0I7SUFFeEIsT0FBTyxJQUFJcjJCLG1CQUFBLENBQW9CO01BQUVvMkIsY0FBQTtNQUFnQkM7SUFBZ0IsQ0FBRTs7RUFJckUsT0FBT0MsbUJBQ0w1Z0IsV0FBQSxFQUNBb2dCLGNBQUEsRUFBc0I7SUFFdEIsT0FBTyxJQUFJOTFCLG1CQUFBLENBQW9CO01BQUUwVixXQUFBO01BQWFvZ0I7SUFBYyxDQUFFOztFQUloRXpDLG9CQUFvQnZsQixJQUFBLEVBQWtCO0lBQ3BDLE9BQU84bkIsdUJBQUEsQ0FBc0I5bkIsSUFBQSxFQUFNLEtBQUt5b0Isd0JBQUEsQ0FBd0IsQ0FBRTs7RUFJcEVoRCxlQUNFemxCLElBQUEsRUFDQW9OLE9BQUEsRUFBZTtJQUVmLE9BQU8yYSxxQkFBQSxDQUFvQi9uQixJQUFBLEVBQ3pCSSxNQUFBLENBQUFDLE1BQUE7TUFBQStNO0lBQU8sR0FDSixLQUFLcWIsd0JBQUEsQ0FBd0IsQ0FBRTs7RUFLdEM5Qyw2QkFBNkIzbEIsSUFBQSxFQUFrQjtJQUM3QyxPQUFPa29CLDRCQUFBLENBQTZCbG9CLElBQUEsRUFBTSxLQUFLeW9CLHdCQUFBLENBQXdCLENBQUU7O0VBSTNFQSx5QkFBQSxFQUF3QjtJQUN0QixNQUFNO01BQUVULGNBQUE7TUFBZ0JwZ0IsV0FBQTtNQUFhMGdCLGNBQUE7TUFBZ0JDO0lBQWdCLElBQ25FLEtBQUszakIsTUFBQTtJQUNQLElBQUlvakIsY0FBQSxJQUFrQnBnQixXQUFBLEVBQWE7TUFDakMsT0FBTztRQUFFb2dCLGNBQUE7UUFBZ0JwZ0I7TUFBVztJQUNyQztJQUVELE9BQU87TUFDTDhnQixXQUFBLEVBQWFKLGNBQUE7TUFDYnJvQixJQUFBLEVBQU1zb0I7OztFQUtWcmIsT0FBQSxFQUFNO0lBQ0osTUFBTTRaLEdBQUEsR0FBOEI7TUFDbEM3WCxVQUFBLEVBQVksS0FBS0E7O0lBRW5CLElBQUksS0FBS3JLLE1BQUEsQ0FBT2dELFdBQUEsRUFBYTtNQUMzQmtmLEdBQUEsQ0FBSWxmLFdBQUEsR0FBYyxLQUFLaEQsTUFBQSxDQUFPZ0QsV0FBQTtJQUMvQjtJQUNELElBQUksS0FBS2hELE1BQUEsQ0FBT29qQixjQUFBLEVBQWdCO01BQzlCbEIsR0FBQSxDQUFJa0IsY0FBQSxHQUFpQixLQUFLcGpCLE1BQUEsQ0FBT29qQixjQUFBO0lBQ2xDO0lBQ0QsSUFBSSxLQUFLcGpCLE1BQUEsQ0FBTzJqQixnQkFBQSxFQUFrQjtNQUNoQ3pCLEdBQUEsQ0FBSXlCLGdCQUFBLEdBQW1CLEtBQUszakIsTUFBQSxDQUFPMmpCLGdCQUFBO0lBQ3BDO0lBQ0QsSUFBSSxLQUFLM2pCLE1BQUEsQ0FBTzBqQixjQUFBLEVBQWdCO01BQzlCeEIsR0FBQSxDQUFJd0IsY0FBQSxHQUFpQixLQUFLMWpCLE1BQUEsQ0FBTzBqQixjQUFBO0lBQ2xDO0lBRUQsT0FBT3hCLEdBQUE7O0VBSVQsT0FBT3JXLFNBQVN6SyxJQUFBLEVBQXFCO0lBQ25DLElBQUksT0FBT0EsSUFBQSxLQUFTLFVBQVU7TUFDNUJBLElBQUEsR0FBT25CLElBQUEsQ0FBS3NHLEtBQUEsQ0FBTW5GLElBQUk7SUFDdkI7SUFFRCxNQUFNO01BQUVzaUIsY0FBQTtNQUFnQkMsZ0JBQUE7TUFBa0IzZ0IsV0FBQTtNQUFhb2dCO0lBQWMsSUFDbkVoaUIsSUFBQTtJQUNGLElBQ0UsQ0FBQ3VpQixnQkFBQSxJQUNELENBQUNELGNBQUEsSUFDRCxDQUFDMWdCLFdBQUEsSUFDRCxDQUFDb2dCLGNBQUEsRUFDRDtNQUNBLE9BQU87SUFDUjtJQUVELE9BQU8sSUFBSTkxQixtQkFBQSxDQUFvQjtNQUM3Qm8yQixjQUFBO01BQ0FDLGdCQUFBO01BQ0EzZ0IsV0FBQTtNQUNBb2dCO0lBQ0Q7O0FBRUo7QUN0R0QsU0FBU1csVUFBVUMsSUFBQSxFQUFtQjtFQUNwQyxRQUFRQSxJQUFBO1NBQ0Q7TUFDSCxPQUF5QztTQUN0QztNQUNILE9BQTBDO1NBQ3ZDO01BQ0gsT0FBd0M7U0FDckM7TUFDSCxPQUF3QztTQUNyQztNQUNILE9BQW1EO1NBQ2hEO01BQ0gsT0FBeUQ7O01BRXpELE9BQU87O0FBRWI7QUFPQSxTQUFTQyxjQUFjeGxCLEdBQUEsRUFBVztFQUNoQyxNQUFNeWxCLElBQUEsT0FBTzd3QixXQUFBLENBQUE4d0IsaUJBQUEsTUFBa0I5d0IsV0FBQSxDQUFBK3dCLGtCQUFBLEVBQW1CM2xCLEdBQUcsQ0FBQyxFQUFFO0VBR3hELE1BQU00bEIsY0FBQSxHQUFpQkgsSUFBQSxPQUNuQjd3QixXQUFBLENBQUE4d0IsaUJBQUEsTUFBa0I5d0IsV0FBQSxDQUFBK3dCLGtCQUFBLEVBQW1CRixJQUFJLENBQUMsRUFBRSxrQkFDNUM7RUFFSixNQUFNSSxXQUFBLE9BQWNqeEIsV0FBQSxDQUFBOHdCLGlCQUFBLE1BQWtCOXdCLFdBQUEsQ0FBQSt3QixrQkFBQSxFQUFtQjNsQixHQUFHLENBQUMsRUFDM0Q7RUFFRixNQUFNOGxCLGlCQUFBLEdBQW9CRCxXQUFBLE9BQ3RCanhCLFdBQUEsQ0FBQTh3QixpQkFBQSxNQUFrQjl3QixXQUFBLENBQUErd0Isa0JBQUEsRUFBbUJFLFdBQVcsQ0FBQyxFQUFFLFVBQ25EO0VBQ0osT0FBT0MsaUJBQUEsSUFBcUJELFdBQUEsSUFBZUQsY0FBQSxJQUFrQkgsSUFBQSxJQUFRemxCLEdBQUE7QUFDdkU7SUFRYWhTLGFBQUEsU0FBYTtFQWlDeEJ5UCxZQUFZc29CLFVBQUEsRUFBa0I7O0lBQzVCLE1BQU1DLFlBQUEsT0FBZXB4QixXQUFBLENBQUE4d0IsaUJBQUEsTUFBa0I5d0IsV0FBQSxDQUFBK3dCLGtCQUFBLEVBQW1CSSxVQUFVLENBQUM7SUFDckUsTUFBTWxrQixNQUFBLElBQVN4RCxFQUFBLEdBQUEybkIsWUFBQSxDQUFnQyx1QkFBQTNuQixFQUFBLGNBQUFBLEVBQUEsR0FBSTtJQUNuRCxNQUFNekIsSUFBQSxJQUFPK1IsRUFBQSxHQUFBcVgsWUFBQSxDQUE2Qix3QkFBQXJYLEVBQUEsY0FBQUEsRUFBQSxHQUFJO0lBQzlDLE1BQU1vVyxTQUFBLEdBQVlPLFNBQUEsRUFBVTFXLEVBQUEsR0FBQW9YLFlBQUEsQ0FBNkIscUJBQUFwWCxFQUFBLGNBQUFBLEVBQUEsR0FBSSxJQUFJO0lBRWpFL1EsT0FBQSxDQUFRZ0UsTUFBQSxJQUFVakYsSUFBQSxJQUFRbW9CLFNBQUEsRUFBUztJQUNuQyxLQUFLbGpCLE1BQUEsR0FBU0EsTUFBQTtJQUNkLEtBQUtrakIsU0FBQSxHQUFZQSxTQUFBO0lBQ2pCLEtBQUtub0IsSUFBQSxHQUFPQSxJQUFBO0lBQ1osS0FBS3FwQixXQUFBLElBQWNwWCxFQUFBLEdBQUFtWCxZQUFBLENBQXFDLDRCQUFBblgsRUFBQSxjQUFBQSxFQUFBLEdBQUk7SUFDNUQsS0FBSzlNLFlBQUEsSUFBZStNLEVBQUEsR0FBQWtYLFlBQUEsQ0FBc0MsNkJBQUFsWCxFQUFBLGNBQUFBLEVBQUEsR0FBSTtJQUM5RCxLQUFLN04sUUFBQSxJQUFXOE4sRUFBQSxHQUFBaVgsWUFBQSxDQUFrQyx5QkFBQWpYLEVBQUEsY0FBQUEsRUFBQSxHQUFJOztFQVl4RCxPQUFPbVgsVUFBVVQsSUFBQSxFQUFZO0lBQzNCLE1BQU1NLFVBQUEsR0FBYVAsYUFBQSxDQUFjQyxJQUFJO0lBQ3JDLElBQUk7TUFDRixPQUFPLElBQUl6M0IsYUFBQSxDQUFjKzNCLFVBQVU7SUFDcEMsU0FBTzFuQixFQUFBLEVBQU47TUFDQSxPQUFPO0lBQ1I7O0FBRUo7QUFRSyxTQUFVaE4sbUJBQW1CbzBCLElBQUEsRUFBWTtFQUM3QyxPQUFPejNCLGFBQUEsQ0FBY2s0QixTQUFBLENBQVVULElBQUk7QUFDckM7SUNySWFwM0IsaUJBQUEsU0FBaUI7RUFBOUJvUCxZQUFBO0lBa0JXLEtBQUFtTyxVQUFBLEdBQWF2ZCxpQkFBQSxDQUFrQjgzQixXQUFBOztFQW9CeEMsT0FBT0MsV0FBVzloQixLQUFBLEVBQWU0UixRQUFBLEVBQWdCO0lBQy9DLE9BQU85bkIsbUJBQUEsQ0FBb0JrMUIscUJBQUEsQ0FBc0JoZixLQUFBLEVBQU80UixRQUFROztFQXlCbEUsT0FBT21RLG1CQUNML2hCLEtBQUEsRUFDQWdpQixTQUFBLEVBQWlCO0lBRWpCLE1BQU1DLGFBQUEsR0FBZ0J2NEIsYUFBQSxDQUFjazRCLFNBQUEsQ0FBVUksU0FBUztJQUN2RHpvQixPQUFBLENBQVEwb0IsYUFBQSxFQUFhO0lBRXJCLE9BQU9uNEIsbUJBQUEsQ0FBb0JtMUIsaUJBQUEsQ0FDekJqZixLQUFBLEVBQ0FpaUIsYUFBQSxDQUFjM3BCLElBQUEsRUFDZDJwQixhQUFBLENBQWN0bEIsUUFBUTs7O0FBdEVWNVMsaUJBQUEsQ0FBQTgzQixXQUFBLEdBQThDO0FBSTlDOTNCLGlCQUFBLENBQUFtNEIsNkJBQUEsR0FDYztBQUlkbjRCLGlCQUFBLENBQUFvNEIseUJBQUEsR0FDVTtJQ1hOQyxxQkFBQSxTQUFxQjtFQVd6Q2pwQixZQUFxQm1PLFVBQUEsRUFBa0I7SUFBbEIsS0FBVUEsVUFBQSxHQUFWQSxVQUFBO0lBVHJCLEtBQW1CK2EsbUJBQUEsR0FBa0I7SUFFN0IsS0FBZ0JDLGdCQUFBLEdBQXFCOztFQWM3Q0MsbUJBQW1COWtCLFlBQUEsRUFBMkI7SUFDNUMsS0FBSzRrQixtQkFBQSxHQUFzQjVrQixZQUFBOztFQWE3QitrQixvQkFBb0JDLHFCQUFBLEVBQXVDO0lBQ3pELEtBQUtILGdCQUFBLEdBQW1CRyxxQkFBQTtJQUN4QixPQUFPOztFQU1UQyxvQkFBQSxFQUFtQjtJQUNqQixPQUFPLEtBQUtKLGdCQUFBOztBQUVmO0FDZEssSUFBZ0JLLGlCQUFBLEdBQWhCLGNBQ0lQLHFCQUFBLENBQXFCO0VBRC9CanBCLFlBQUE7O0lBS1UsS0FBTXlwQixNQUFBLEdBQWE7O0VBTzNCQyxTQUFTQyxLQUFBLEVBQWE7SUFFcEIsSUFBSSxDQUFDLEtBQUtGLE1BQUEsQ0FBTzlVLFFBQUEsQ0FBU2dWLEtBQUssR0FBRztNQUNoQyxLQUFLRixNQUFBLENBQU94UyxJQUFBLENBQUswUyxLQUFLO0lBQ3ZCO0lBQ0QsT0FBTzs7RUFNVEMsVUFBQSxFQUFTO0lBQ1AsT0FBTyxDQUFDLEdBQUcsS0FBS0gsTUFBTTs7QUFFekI7QUEwQ0ssSUFBT3Y0QixhQUFBLEdBQVAsY0FBNkJzNEIsaUJBQUEsQ0FBaUI7RUFLbEQsT0FBT0ssbUJBQW1CM2tCLElBQUEsRUFBcUI7SUFDN0MsTUFBTThnQixHQUFBLEdBQU0sT0FBTzlnQixJQUFBLEtBQVMsV0FBV25CLElBQUEsQ0FBS3NHLEtBQUEsQ0FBTW5GLElBQUksSUFBSUEsSUFBQTtJQUMxRDlFLE9BQUEsQ0FDRSxnQkFBZ0I0bEIsR0FBQSxJQUFPLGtCQUFrQkEsR0FBQSxFQUFHO0lBRzlDLE9BQU8vMEIsZUFBQSxDQUFnQm8xQixXQUFBLENBQVlMLEdBQUc7O0VBd0J4QzJDLFdBQVc3a0IsTUFBQSxFQUE4QjtJQUN2QyxPQUFPLEtBQUtnbUIsV0FBQSxDQUFXeHFCLE1BQUEsQ0FBQUMsTUFBQSxDQUFBRCxNQUFBLENBQUFDLE1BQUEsS0FBTXVFLE1BQU07TUFBRXlpQixLQUFBLEVBQU96aUIsTUFBQSxDQUFPaW1CO0lBQVE7O0VBSXJERCxZQUNOaG1CLE1BQUEsRUFBa0U7SUFFbEUxRCxPQUFBLENBQVEwRCxNQUFBLENBQU93SSxPQUFBLElBQVd4SSxNQUFBLENBQU84SyxXQUFBLEVBQVc7SUFFNUMsT0FBTzNkLGVBQUEsQ0FBZ0JvMUIsV0FBQSxDQUFXL21CLE1BQUEsQ0FBQUMsTUFBQSxDQUFBRCxNQUFBLENBQUFDLE1BQUEsS0FDN0J1RSxNQUFNO01BQ1RxSyxVQUFBLEVBQVksS0FBS0EsVUFBQTtNQUNqQnFXLFlBQUEsRUFBYyxLQUFLclc7SUFBVTs7RUFTakMsT0FBTzZiLHFCQUNMQyxjQUFBLEVBQThCO0lBRTlCLE9BQU8vNEIsYUFBQSxDQUFjZzVCLCtCQUFBLENBQ25CRCxjQUF3Qzs7RUFTNUMsT0FBT0Usb0JBQW9CeHJCLEtBQUEsRUFBb0I7SUFDN0MsT0FBT3pOLGFBQUEsQ0FBY2c1QiwrQkFBQSxDQUNsQnZyQixLQUFBLENBQU1vSSxVQUFBLElBQWMsRUFBRTs7RUFJbkIsT0FBT21qQixnQ0FBZ0M7SUFDN0NsakIsY0FBQSxFQUFnQm9qQjtFQUFhLEdBQ0w7SUFDeEIsSUFBSSxDQUFDQSxhQUFBLEVBQWU7TUFDbEIsT0FBTztJQUNSO0lBRUQsTUFBTTtNQUNKQyxZQUFBO01BQ0FDLGdCQUFBO01BQ0E3RCxnQkFBQTtNQUNBTCxZQUFBO01BQ0FHLEtBQUE7TUFDQXBZO0lBQVUsSUFDUmljLGFBQUE7SUFDSixJQUNFLENBQUNFLGdCQUFBLElBQ0QsQ0FBQzdELGdCQUFBLElBQ0QsQ0FBQzRELFlBQUEsSUFDRCxDQUFDakUsWUFBQSxFQUNEO01BQ0EsT0FBTztJQUNSO0lBRUQsSUFBSSxDQUFDalksVUFBQSxFQUFZO01BQ2YsT0FBTztJQUNSO0lBRUQsSUFBSTtNQUNGLE9BQU8sSUFBSWpkLGFBQUEsQ0FBY2lkLFVBQVUsRUFBRTJiLFdBQUEsQ0FBWTtRQUMvQ3hkLE9BQUEsRUFBUytkLFlBQUE7UUFDVHpiLFdBQUEsRUFBYTBiLGdCQUFBO1FBQ2IvRCxLQUFBO1FBQ0FIO01BQ0Q7SUFDRixTQUFReGdCLENBQUEsRUFBUDtNQUNBLE9BQU87SUFDUjs7QUFFSjtBQ3BMSyxJQUFPL1Usb0JBQUEsR0FBUCxjQUFvQzI0QixpQkFBQSxDQUFpQjtFQU96RHhwQixZQUFBO0lBQ0UsTUFBSzs7RUFlUCxPQUFPMm9CLFdBQVcvWixXQUFBLEVBQW1CO0lBQ25DLE9BQU8zZCxlQUFBLENBQWdCbzFCLFdBQUEsQ0FBWTtNQUNqQ2xZLFVBQUEsRUFBWXRkLG9CQUFBLENBQXFCNjNCLFdBQUE7TUFDakNsRSxZQUFBLEVBQWMzekIsb0JBQUEsQ0FBcUIwNUIsdUJBQUE7TUFDbkMzYjtJQUNEOztFQVFILE9BQU9vYixxQkFDTEMsY0FBQSxFQUE4QjtJQUU5QixPQUFPcDVCLG9CQUFBLENBQXFCMjVCLDBCQUFBLENBQzFCUCxjQUF3Qzs7RUFVNUMsT0FBT0Usb0JBQW9CeHJCLEtBQUEsRUFBb0I7SUFDN0MsT0FBTzlOLG9CQUFBLENBQXFCMjVCLDBCQUFBLENBQ3pCN3JCLEtBQUEsQ0FBTW9JLFVBQUEsSUFBYyxFQUFFOztFQUluQixPQUFPeWpCLDJCQUEyQjtJQUN4Q3hqQixjQUFBLEVBQWdCb2pCO0VBQWEsR0FDTDtJQUN4QixJQUFJLENBQUNBLGFBQUEsSUFBaUIsRUFBRSxzQkFBc0JBLGFBQUEsR0FBZ0I7TUFDNUQsT0FBTztJQUNSO0lBRUQsSUFBSSxDQUFDQSxhQUFBLENBQWNFLGdCQUFBLEVBQWtCO01BQ25DLE9BQU87SUFDUjtJQUVELElBQUk7TUFDRixPQUFPejVCLG9CQUFBLENBQXFCODNCLFVBQUEsQ0FBV3lCLGFBQUEsQ0FBY0UsZ0JBQWdCO0lBQ3RFLFNBQU8xcEIsRUFBQSxFQUFOO01BQ0EsT0FBTztJQUNSOzs7QUFyRWEvUCxvQkFBQSxDQUFBMDVCLHVCQUFBLEdBQ1E7QUFFUjE1QixvQkFBQSxDQUFBNjNCLFdBQUEsR0FBa0Q7QUNGOUQsSUFBTzEzQixrQkFBQSxHQUFQLGNBQWtDdzRCLGlCQUFBLENBQWlCO0VBTXZEeHBCLFlBQUE7SUFDRSxNQUFLO0lBQ0wsS0FBSzBwQixRQUFBLENBQVMsU0FBUzs7RUFnQnpCLE9BQU9mLFdBQ0xyYyxPQUFBLEVBQ0FzQyxXQUFBLEVBQTJCO0lBRTNCLE9BQU8zZCxlQUFBLENBQWdCbzFCLFdBQUEsQ0FBWTtNQUNqQ2xZLFVBQUEsRUFBWW5kLGtCQUFBLENBQW1CMDNCLFdBQUE7TUFDL0JsRSxZQUFBLEVBQWN4ekIsa0JBQUEsQ0FBbUJ5NUIscUJBQUE7TUFDakNuZSxPQUFBO01BQ0FzQztJQUNEOztFQVFILE9BQU9vYixxQkFDTEMsY0FBQSxFQUE4QjtJQUU5QixPQUFPajVCLGtCQUFBLENBQW1CdzVCLDBCQUFBLENBQ3hCUCxjQUF3Qzs7RUFTNUMsT0FBT0Usb0JBQW9CeHJCLEtBQUEsRUFBb0I7SUFDN0MsT0FBTzNOLGtCQUFBLENBQW1CdzVCLDBCQUFBLENBQ3ZCN3JCLEtBQUEsQ0FBTW9JLFVBQUEsSUFBYyxFQUFFOztFQUluQixPQUFPeWpCLDJCQUEyQjtJQUN4Q3hqQixjQUFBLEVBQWdCb2pCO0VBQWEsR0FDTDtJQUN4QixJQUFJLENBQUNBLGFBQUEsRUFBZTtNQUNsQixPQUFPO0lBQ1I7SUFFRCxNQUFNO01BQUVDLFlBQUE7TUFBY0M7SUFBZ0IsSUFDcENGLGFBQUE7SUFDRixJQUFJLENBQUNDLFlBQUEsSUFBZ0IsQ0FBQ0MsZ0JBQUEsRUFBa0I7TUFFdEMsT0FBTztJQUNSO0lBRUQsSUFBSTtNQUNGLE9BQU90NUIsa0JBQUEsQ0FBbUIyM0IsVUFBQSxDQUFXMEIsWUFBQSxFQUFjQyxnQkFBZ0I7SUFDcEUsU0FBTzFwQixFQUFBLEVBQU47TUFDQSxPQUFPO0lBQ1I7OztBQTVFYTVQLGtCQUFBLENBQUF5NUIscUJBQUEsR0FBMEQ7QUFFMUR6NUIsa0JBQUEsQ0FBQTAzQixXQUFBLEdBQThDO0FDSjFELElBQU8zM0Isa0JBQUEsR0FBUCxjQUFrQ3k0QixpQkFBQSxDQUFpQjtFQU12RHhwQixZQUFBO0lBQ0UsTUFBSzs7RUFRUCxPQUFPMm9CLFdBQVcvWixXQUFBLEVBQW1CO0lBQ25DLE9BQU8zZCxlQUFBLENBQWdCbzFCLFdBQUEsQ0FBWTtNQUNqQ2xZLFVBQUEsRUFBWXBkLGtCQUFBLENBQW1CMjNCLFdBQUE7TUFDL0JsRSxZQUFBLEVBQWN6ekIsa0JBQUEsQ0FBbUIyNUIscUJBQUE7TUFDakM5YjtJQUNEOztFQVFILE9BQU9vYixxQkFDTEMsY0FBQSxFQUE4QjtJQUU5QixPQUFPbDVCLGtCQUFBLENBQW1CeTVCLDBCQUFBLENBQ3hCUCxjQUF3Qzs7RUFVNUMsT0FBT0Usb0JBQW9CeHJCLEtBQUEsRUFBb0I7SUFDN0MsT0FBTzVOLGtCQUFBLENBQW1CeTVCLDBCQUFBLENBQ3ZCN3JCLEtBQUEsQ0FBTW9JLFVBQUEsSUFBYyxFQUFFOztFQUluQixPQUFPeWpCLDJCQUEyQjtJQUN4Q3hqQixjQUFBLEVBQWdCb2pCO0VBQWEsR0FDTDtJQUN4QixJQUFJLENBQUNBLGFBQUEsSUFBaUIsRUFBRSxzQkFBc0JBLGFBQUEsR0FBZ0I7TUFDNUQsT0FBTztJQUNSO0lBRUQsSUFBSSxDQUFDQSxhQUFBLENBQWNFLGdCQUFBLEVBQWtCO01BQ25DLE9BQU87SUFDUjtJQUVELElBQUk7TUFDRixPQUFPdjVCLGtCQUFBLENBQW1CNDNCLFVBQUEsQ0FBV3lCLGFBQUEsQ0FBY0UsZ0JBQWdCO0lBQ3BFLFNBQU8xcEIsRUFBQSxFQUFOO01BQ0EsT0FBTztJQUNSOzs7QUE3RGE3UCxrQkFBQSxDQUFBMjVCLHFCQUFBLEdBQTBEO0FBRTFEMzVCLGtCQUFBLENBQUEyM0IsV0FBQSxHQUE4QztBQ3pDaEUsSUFBTWlDLGVBQUEsR0FBa0I7QUFLbEIsSUFBT0Msa0JBQUEsR0FBUCxjQUFrQ3A2QixjQUFBLENBQWM7RUFFcER3UCxZQUNFbU8sVUFBQSxFQUNpQmlZLFlBQUEsRUFBb0I7SUFFckMsTUFBTWpZLFVBQUEsRUFBWUEsVUFBVTtJQUZYLEtBQVlpWSxZQUFBLEdBQVpBLFlBQUE7O0VBTW5CM0Isb0JBQW9CdmxCLElBQUEsRUFBa0I7SUFDcEMsTUFBTXFFLE9BQUEsR0FBVSxLQUFLb2pCLFlBQUEsQ0FBWTtJQUNqQyxPQUFPVCxhQUFBLENBQWNobkIsSUFBQSxFQUFNcUUsT0FBTzs7RUFJcENvaEIsZUFDRXpsQixJQUFBLEVBQ0FvTixPQUFBLEVBQWU7SUFFZixNQUFNL0ksT0FBQSxHQUFVLEtBQUtvakIsWUFBQSxDQUFZO0lBQ2pDcGpCLE9BQUEsQ0FBUStJLE9BQUEsR0FBVUEsT0FBQTtJQUNsQixPQUFPNFosYUFBQSxDQUFjaG5CLElBQUEsRUFBTXFFLE9BQU87O0VBSXBDc2hCLDZCQUE2QjNsQixJQUFBLEVBQWtCO0lBQzdDLE1BQU1xRSxPQUFBLEdBQVUsS0FBS29qQixZQUFBLENBQVk7SUFDakNwakIsT0FBQSxDQUFRcWpCLFVBQUEsR0FBYTtJQUNyQixPQUFPVixhQUFBLENBQWNobkIsSUFBQSxFQUFNcUUsT0FBTzs7RUFJcEM2SSxPQUFBLEVBQU07SUFDSixPQUFPO01BQ0xvWSxZQUFBLEVBQWMsS0FBS0EsWUFBQTtNQUNuQnJXLFVBQUEsRUFBWSxLQUFLQSxVQUFBO01BQ2pCaVksWUFBQSxFQUFjLEtBQUtBOzs7RUFhdkIsT0FBT3pXLFNBQVN6SyxJQUFBLEVBQXFCO0lBQ25DLE1BQU04Z0IsR0FBQSxHQUFNLE9BQU85Z0IsSUFBQSxLQUFTLFdBQVduQixJQUFBLENBQUtzRyxLQUFBLENBQU1uRixJQUFJLElBQUlBLElBQUE7SUFDMUQsTUFBTTtNQUFFaUosVUFBQTtNQUFZcVcsWUFBQTtNQUFjNEI7SUFBWSxJQUM1Q0osR0FBQTtJQUNGLElBQ0UsQ0FBQzdYLFVBQUEsSUFDRCxDQUFDcVcsWUFBQSxJQUNELENBQUM0QixZQUFBLElBQ0RqWSxVQUFBLEtBQWVxVyxZQUFBLEVBQ2Y7TUFDQSxPQUFPO0lBQ1I7SUFFRCxPQUFPLElBQUlvRyxrQkFBQSxDQUFtQnpjLFVBQUEsRUFBWWlZLFlBQVk7O0VBUXhELE9BQU95RSxRQUFRMWMsVUFBQSxFQUFvQmlZLFlBQUEsRUFBb0I7SUFDckQsT0FBTyxJQUFJd0Usa0JBQUEsQ0FBbUJ6YyxVQUFBLEVBQVlpWSxZQUFZOztFQUdoRE8sYUFBQSxFQUFZO0lBQ2xCLE9BQU87TUFDTEUsVUFBQSxFQUFZOEQsZUFBQTtNQUNaMUUsaUJBQUEsRUFBbUI7TUFDbkJHLFlBQUEsRUFBYyxLQUFLQTs7O0FBR3hCO0FDMUZELElBQU0wRSxvQkFBQSxHQUF1QjtBQU92QixJQUFPcjVCLGdCQUFBLEdBQVAsY0FBZ0N3M0IscUJBQUEsQ0FBcUI7RUFLekRqcEIsWUFBWW1PLFVBQUEsRUFBa0I7SUFDNUIvTixPQUFBLENBQ0UrTixVQUFBLENBQVczTCxVQUFBLENBQVdzb0Isb0JBQW9CLEdBQUM7SUFHN0MsTUFBTTNjLFVBQVU7O0VBbUJsQixPQUFPNmIscUJBQ0xDLGNBQUEsRUFBOEI7SUFFOUIsT0FBT3g0QixnQkFBQSxDQUFpQnM1Qiw4QkFBQSxDQUN0QmQsY0FBd0M7O0VBVTVDLE9BQU9FLG9CQUFvQnhyQixLQUFBLEVBQW9CO0lBQzdDLE9BQU9sTixnQkFBQSxDQUFpQnM1Qiw4QkFBQSxDQUNyQnBzQixLQUFBLENBQU1vSSxVQUFBLElBQWMsRUFBRTs7RUFRM0IsT0FBTzhpQixtQkFBbUIza0IsSUFBQSxFQUFxQjtJQUM3QyxNQUFNeWpCLFVBQUEsR0FBYWlDLGtCQUFBLENBQW1CamIsUUFBQSxDQUFTekssSUFBSTtJQUNuRDlFLE9BQUEsQ0FBUXVvQixVQUFBLEVBQVU7SUFDbEIsT0FBT0EsVUFBQTs7RUFHRCxPQUFPb0MsK0JBQStCO0lBQzVDL2pCLGNBQUEsRUFBZ0JvakI7RUFBYSxHQUNMO0lBQ3hCLElBQUksQ0FBQ0EsYUFBQSxFQUFlO01BQ2xCLE9BQU87SUFDUjtJQUVELE1BQU07TUFBRWhFLFlBQUE7TUFBY2pZO0lBQVUsSUFBS2ljLGFBQUE7SUFFckMsSUFBSSxDQUFDaEUsWUFBQSxJQUFnQixDQUFDalksVUFBQSxFQUFZO01BQ2hDLE9BQU87SUFDUjtJQUVELElBQUk7TUFDRixPQUFPeWMsa0JBQUEsQ0FBbUJDLE9BQUEsQ0FBUTFjLFVBQUEsRUFBWWlZLFlBQVk7SUFDM0QsU0FBUXhnQixDQUFBLEVBQVA7TUFDQSxPQUFPO0lBQ1I7O0FBRUo7QUM5QkssSUFBTy9ULG1CQUFBLEdBQVAsY0FBbUMyM0IsaUJBQUEsQ0FBaUI7RUFNeER4cEIsWUFBQTtJQUNFLE1BQUs7O0VBU1AsT0FBTzJvQixXQUFXemYsS0FBQSxFQUFld2QsTUFBQSxFQUFjO0lBQzdDLE9BQU96MUIsZUFBQSxDQUFnQm8xQixXQUFBLENBQVk7TUFDakNsWSxVQUFBLEVBQVl0YyxtQkFBQSxDQUFvQjYyQixXQUFBO01BQ2hDbEUsWUFBQSxFQUFjM3lCLG1CQUFBLENBQW9CbTVCLHNCQUFBO01BQ2xDeEUsVUFBQSxFQUFZdGQsS0FBQTtNQUNadWQsZ0JBQUEsRUFBa0JDO0lBQ25COztFQVFILE9BQU9zRCxxQkFDTEMsY0FBQSxFQUE4QjtJQUU5QixPQUFPcDRCLG1CQUFBLENBQW9CMjRCLDBCQUFBLENBQ3pCUCxjQUF3Qzs7RUFVNUMsT0FBT0Usb0JBQW9CeHJCLEtBQUEsRUFBb0I7SUFDN0MsT0FBTzlNLG1CQUFBLENBQW9CMjRCLDBCQUFBLENBQ3hCN3JCLEtBQUEsQ0FBTW9JLFVBQUEsSUFBYyxFQUFFOztFQUluQixPQUFPeWpCLDJCQUEyQjtJQUN4Q3hqQixjQUFBLEVBQWdCb2pCO0VBQWEsR0FDTDtJQUN4QixJQUFJLENBQUNBLGFBQUEsRUFBZTtNQUNsQixPQUFPO0lBQ1I7SUFDRCxNQUFNO01BQUVFLGdCQUFBO01BQWtCN0Q7SUFBZ0IsSUFDeEMyRCxhQUFBO0lBQ0YsSUFBSSxDQUFDRSxnQkFBQSxJQUFvQixDQUFDN0QsZ0JBQUEsRUFBa0I7TUFDMUMsT0FBTztJQUNSO0lBRUQsSUFBSTtNQUNGLE9BQU81MEIsbUJBQUEsQ0FBb0I4MkIsVUFBQSxDQUFXMkIsZ0JBQUEsRUFBa0I3RCxnQkFBZ0I7SUFDekUsU0FBTzdsQixFQUFBLEVBQU47TUFDQSxPQUFPO0lBQ1I7OztBQWhFYS9PLG1CQUFBLENBQUFtNUIsc0JBQUEsR0FBNkQ7QUFFN0RuNUIsbUJBQUEsQ0FBQTYyQixXQUFBLEdBQWdEO0FDM0MzRCxlQUFldUMsT0FDcEIvckIsSUFBQSxFQUNBcUUsT0FBQSxFQUFzQjtFQUV0QixPQUFPd0MscUJBQUEsQ0FDTDdHLElBQUEsRUFHQSwrQkFBQW9FLGtCQUFBLENBQW1CcEUsSUFBQSxFQUFNcUUsT0FBTyxDQUFDO0FBRXJDO0lDdkJhMm5CLGtCQUFBLFNBQWtCO0VBUTdCbHJCLFlBQVk4RCxNQUFBLEVBQTRCO0lBQ3RDLEtBQUtnRixJQUFBLEdBQU9oRixNQUFBLENBQU9nRixJQUFBO0lBQ25CLEtBQUtxRixVQUFBLEdBQWFySyxNQUFBLENBQU9xSyxVQUFBO0lBQ3pCLEtBQUtuSCxjQUFBLEdBQWlCbEQsTUFBQSxDQUFPa0QsY0FBQTtJQUM3QixLQUFLbWtCLGFBQUEsR0FBZ0JybkIsTUFBQSxDQUFPcW5CLGFBQUE7O0VBRzlCLGFBQWF2WixxQkFDWDFTLElBQUEsRUFDQWlzQixhQUFBLEVBQ0F0WixlQUFBLEVBQ0E3RSxXQUFBLEdBQXVCLE9BQUs7SUFFNUIsTUFBTWxFLElBQUEsR0FBTyxNQUFNbUgsUUFBQSxDQUFTMkIsb0JBQUEsQ0FDMUIxUyxJQUFBLEVBQ0EyUyxlQUFBLEVBQ0E3RSxXQUFXO0lBRWIsTUFBTW1CLFVBQUEsR0FBYWlkLHFCQUFBLENBQXNCdlosZUFBZTtJQUN4RCxNQUFNd1osUUFBQSxHQUFXLElBQUlILGtCQUFBLENBQW1CO01BQ3RDcGlCLElBQUE7TUFDQXFGLFVBQUE7TUFDQW5ILGNBQUEsRUFBZ0I2SyxlQUFBO01BQ2hCc1o7SUFDRDtJQUNELE9BQU9FLFFBQUE7O0VBR1QsYUFBYUMsY0FDWHhpQixJQUFBLEVBQ0FxaUIsYUFBQSxFQUNBam9CLFFBQUEsRUFBbUM7SUFFbkMsTUFBTTRGLElBQUEsQ0FBSzhILHdCQUFBLENBQXlCMU4sUUFBQSxFQUF1QixJQUFJO0lBQy9ELE1BQU1pTCxVQUFBLEdBQWFpZCxxQkFBQSxDQUFzQmxvQixRQUFRO0lBQ2pELE9BQU8sSUFBSWdvQixrQkFBQSxDQUFtQjtNQUM1QnBpQixJQUFBO01BQ0FxRixVQUFBO01BQ0FuSCxjQUFBLEVBQWdCOUQsUUFBQTtNQUNoQmlvQjtJQUNEOztBQUVKO0FBRUQsU0FBU0Msc0JBQ1Bsb0IsUUFBQSxFQUF5QjtFQUV6QixJQUFJQSxRQUFBLENBQVNpTCxVQUFBLEVBQVk7SUFDdkIsT0FBT2pMLFFBQUEsQ0FBU2lMLFVBQUE7RUFDakI7RUFFRCxJQUFJLGlCQUFpQmpMLFFBQUEsRUFBVTtJQUM3QixPQUF3QjtFQUN6QjtFQUVELE9BQU87QUFDVDtBQzVETyxlQUFlMU8sa0JBQWtCMEssSUFBQSxFQUFVOztFQUNoRCxNQUFNeWlCLFlBQUEsR0FBZTNDLFNBQUEsQ0FBVTlmLElBQUk7RUFDbkMsTUFBTXlpQixZQUFBLENBQWF2SCxzQkFBQTtFQUNuQixLQUFJeFosRUFBQSxHQUFBK2dCLFlBQUEsQ0FBYS9XLFdBQUEsTUFBVyxRQUFBaEssRUFBQSx1QkFBQUEsRUFBQSxDQUFFb00sV0FBQSxFQUFhO0lBRXpDLE9BQU8sSUFBSWtlLGtCQUFBLENBQW1CO01BQzVCcGlCLElBQUEsRUFBTTZZLFlBQUEsQ0FBYS9XLFdBQUE7TUFDbkJ1RCxVQUFBLEVBQVk7TUFDWmdkLGFBQUEsRUFBb0M7SUFDckM7RUFDRjtFQUNELE1BQU1qb0IsUUFBQSxHQUFXLE1BQU0rbkIsTUFBQSxDQUFPdEosWUFBQSxFQUFjO0lBQzFDc0UsaUJBQUEsRUFBbUI7RUFDcEI7RUFDRCxNQUFNZ0UsY0FBQSxHQUFpQixNQUFNaUIsa0JBQUEsQ0FBbUJ0WixvQkFBQSxDQUM5QytQLFlBQUEsRUFFQSxVQUFBemUsUUFBQSxFQUNBLElBQUk7RUFFTixNQUFNeWUsWUFBQSxDQUFhcEcsa0JBQUEsQ0FBbUIwTyxjQUFBLENBQWVuaEIsSUFBSTtFQUN6RCxPQUFPbWhCLGNBQUE7QUFDVDtBQzFCTSxJQUFPc0IsZ0JBQUEsR0FBUCxjQUNJcDBCLFdBQUEsQ0FBQTBPLGFBQUEsQ0FBYTtFQUtyQjdGLFlBQ0VkLElBQUEsRUFDQVAsS0FBQSxFQUNTd3NCLGFBQUEsRUFDQXJpQixJQUFBLEVBQW1COztJQUU1QixNQUFNbkssS0FBQSxDQUFNUSxJQUFBLEVBQU1SLEtBQUEsQ0FBTVMsT0FBTztJQUh0QixLQUFhK3JCLGFBQUEsR0FBYkEsYUFBQTtJQUNBLEtBQUlyaUIsSUFBQSxHQUFKQSxJQUFBO0lBSVR4SixNQUFBLENBQU9rc0IsY0FBQSxDQUFlLE1BQU1ELGdCQUFBLENBQWlCRSxTQUFTO0lBQ3RELEtBQUsxa0IsVUFBQSxHQUFhO01BQ2hCckgsT0FBQSxFQUFTUixJQUFBLENBQUtTLElBQUE7TUFDZDZELFFBQUEsR0FBVTVDLEVBQUEsR0FBQTFCLElBQUEsQ0FBS3NFLFFBQUEsTUFBUSxRQUFBNUMsRUFBQSxjQUFBQSxFQUFBLEdBQUk7TUFDM0JxRixlQUFBLEVBQWlCdEgsS0FBQSxDQUFNb0ksVUFBQSxDQUFZZCxlQUFBO01BQ25Da2xCOzs7RUFJSixPQUFPTyx1QkFDTHhzQixJQUFBLEVBQ0FQLEtBQUEsRUFDQXdzQixhQUFBLEVBQ0FyaUIsSUFBQSxFQUFtQjtJQUVuQixPQUFPLElBQUl5aUIsZ0JBQUEsQ0FBaUJyc0IsSUFBQSxFQUFNUCxLQUFBLEVBQU93c0IsYUFBQSxFQUFlcmlCLElBQUk7O0FBRS9EO0FBRUssU0FBVTZpQiw4Q0FDZHpzQixJQUFBLEVBQ0Fpc0IsYUFBQSxFQUNBeEMsVUFBQSxFQUNBN2YsSUFBQSxFQUFtQjtFQUVuQixNQUFNOGlCLGVBQUEsR0FDSlQsYUFBQSxLQUE4QyxtQkFDMUN4QyxVQUFBLENBQVc5RCw0QkFBQSxDQUE2QjNsQixJQUFJLElBQzVDeXBCLFVBQUEsQ0FBV2xFLG1CQUFBLENBQW9CdmxCLElBQUk7RUFFekMsT0FBTzBzQixlQUFBLENBQWdCbEwsS0FBQSxDQUFNL2hCLEtBQUEsSUFBUTtJQUNuQyxJQUFJQSxLQUFBLENBQU1RLElBQUEsS0FBUyxRQUFRLGdDQUE4QjtNQUN2RCxNQUFNb3NCLGdCQUFBLENBQWlCRyxzQkFBQSxDQUNyQnhzQixJQUFBLEVBQ0FQLEtBQUEsRUFDQXdzQixhQUFBLEVBQ0FyaUIsSUFBSTtJQUVQO0lBRUQsTUFBTW5LLEtBQUE7RUFDUixDQUFDO0FBQ0g7QUMvRE0sU0FBVWt0QixvQkFDZGhmLFlBQUEsRUFBaUI7RUFFakIsT0FBTyxJQUFJaWYsR0FBQSxDQUNUamYsWUFBQSxDQUNHd0IsR0FBQSxDQUFJLENBQUM7SUFBRUY7RUFBVSxNQUFPQSxVQUFVLEVBQ2xDSixNQUFBLENBQU9nZSxHQUFBLElBQU8sQ0FBQyxDQUFDQSxHQUFHLENBQWE7QUFFdkM7QUNPTyxlQUFlOTJCLE9BQU82VCxJQUFBLEVBQVlxRixVQUFBLEVBQWtCO0VBQ3pELE1BQU1sRixZQUFBLE9BQWU5UixXQUFBLENBQUE2UixrQkFBQSxFQUFtQkYsSUFBSTtFQUM1QyxNQUFNa2pCLG1CQUFBLENBQW9CLE1BQU0vaUIsWUFBQSxFQUFja0YsVUFBVTtFQUN4RCxNQUFNO0lBQUV4QjtFQUFnQixJQUFLLE1BQU12RSxvQkFBQSxDQUFxQmEsWUFBQSxDQUFhL0osSUFBQSxFQUFNO0lBQ3pFb04sT0FBQSxFQUFTLE1BQU1yRCxZQUFBLENBQWFyVyxVQUFBLENBQVU7SUFDdENxNUIsY0FBQSxFQUFnQixDQUFDOWQsVUFBVTtFQUM1QjtFQUVELE1BQU0rZCxhQUFBLEdBQWdCTCxtQkFBQSxDQUFvQmxmLGdCQUFBLElBQW9CLEVBQUU7RUFFaEUxRCxZQUFBLENBQWE0RCxZQUFBLEdBQWU1RCxZQUFBLENBQWE0RCxZQUFBLENBQWFrQixNQUFBLENBQU9vZSxFQUFBLElBQzNERCxhQUFBLENBQWNFLEdBQUEsQ0FBSUQsRUFBQSxDQUFHaGUsVUFBVSxDQUFDO0VBRWxDLElBQUksQ0FBQytkLGFBQUEsQ0FBY0UsR0FBQSxDQUFHLFVBQW9CO0lBQ3hDbmpCLFlBQUEsQ0FBYW5DLFdBQUEsR0FBYztFQUM1QjtFQUVELE1BQU1tQyxZQUFBLENBQWEvSixJQUFBLENBQUt3TyxxQkFBQSxDQUFzQnpFLFlBQVk7RUFDMUQsT0FBT0EsWUFBQTtBQUNUO0FBRU8sZUFBZW9qQixRQUNwQnZqQixJQUFBLEVBQ0E2ZixVQUFBLEVBQ0FqZSxlQUFBLEdBQWtCLE9BQUs7RUFFdkIsTUFBTXhILFFBQUEsR0FBVyxNQUFNdUgsb0JBQUEsQ0FDckIzQixJQUFBLEVBQ0E2ZixVQUFBLENBQVdoRSxjQUFBLENBQWU3YixJQUFBLENBQUs1SixJQUFBLEVBQU0sTUFBTTRKLElBQUEsQ0FBS2xXLFVBQUEsQ0FBVSxDQUFFLEdBQzVEOFgsZUFBZTtFQUVqQixPQUFPd2dCLGtCQUFBLENBQW1CSSxhQUFBLENBQWN4aUIsSUFBQSxFQUEwQixRQUFBNUYsUUFBUTtBQUM1RTtBQUVPLGVBQWU4b0Isb0JBQ3BCTSxRQUFBLEVBQ0F4akIsSUFBQSxFQUNBakIsUUFBQSxFQUFnQjtFQUVoQixNQUFNd0Usb0JBQUEsQ0FBcUJ2RCxJQUFJO0VBQy9CLE1BQU15akIsV0FBQSxHQUFjVixtQkFBQSxDQUFvQi9pQixJQUFBLENBQUsrRCxZQUFZO0VBRXpELE1BQU0xTixJQUFBLEdBQ0ptdEIsUUFBQSxLQUFhLFFBQ1YsNEJBQ0Q7RUFDSmxzQixPQUFBLENBQVFtc0IsV0FBQSxDQUFZSCxHQUFBLENBQUl2a0IsUUFBUSxNQUFNeWtCLFFBQUEsRUFBVXhqQixJQUFBLENBQUs1SixJQUFBLEVBQU1DLElBQUk7QUFDakU7QUMxRE8sZUFBZXF0QixnQkFDcEIxakIsSUFBQSxFQUNBNmYsVUFBQSxFQUNBamUsZUFBQSxHQUFrQixPQUFLO0VBRXZCLE1BQU07SUFBRXhMO0VBQUksSUFBSzRKLElBQUE7RUFDakIsTUFBTXFpQixhQUFBLEdBQWE7RUFFbkIsSUFBSTtJQUNGLE1BQU1qb0IsUUFBQSxHQUFXLE1BQU11SCxvQkFBQSxDQUNyQjNCLElBQUEsRUFDQTZpQiw2Q0FBQSxDQUNFenNCLElBQUEsRUFDQWlzQixhQUFBLEVBQ0F4QyxVQUFBLEVBQ0E3ZixJQUFJLEdBRU40QixlQUFlO0lBRWpCdEssT0FBQSxDQUFROEMsUUFBQSxDQUFTb0osT0FBQSxFQUFTcE4sSUFBQSxFQUFJO0lBQzlCLE1BQU11dEIsTUFBQSxHQUFTcmpCLFdBQUEsQ0FBWWxHLFFBQUEsQ0FBU29KLE9BQU87SUFDM0NsTSxPQUFBLENBQVFxc0IsTUFBQSxFQUFRdnRCLElBQUEsRUFBSTtJQUVwQixNQUFNO01BQUV3dEIsR0FBQSxFQUFLcmY7SUFBTyxJQUFLb2YsTUFBQTtJQUN6QnJzQixPQUFBLENBQVEwSSxJQUFBLENBQUtzRSxHQUFBLEtBQVFDLE9BQUEsRUFBU25PLElBQUEsRUFBSTtJQUVsQyxPQUFPZ3NCLGtCQUFBLENBQW1CSSxhQUFBLENBQWN4aUIsSUFBQSxFQUFNcWlCLGFBQUEsRUFBZWpvQixRQUFRO0VBQ3RFLFNBQVEwQyxDQUFBLEVBQVA7SUFFQSxLQUFLQSxDQUFBLGFBQUFBLENBQUEsdUJBQUFBLENBQUEsQ0FBcUJ6RyxJQUFBLE1BQVMsUUFBUSxvQkFBOEI7TUFDdkVQLEtBQUEsQ0FBTU0sSUFBQSxFQUFJO0lBQ1g7SUFDRCxNQUFNMEcsQ0FBQTtFQUNQO0FBQ0g7QUNoQ08sZUFBZSttQixzQkFDcEJ6dEIsSUFBQSxFQUNBeXBCLFVBQUEsRUFDQWplLGVBQUEsR0FBa0IsT0FBSztFQUV2QixNQUFNeWdCLGFBQUEsR0FBYTtFQUNuQixNQUFNam9CLFFBQUEsR0FBVyxNQUFNeW9CLDZDQUFBLENBQ3JCenNCLElBQUEsRUFDQWlzQixhQUFBLEVBQ0F4QyxVQUFVO0VBRVosTUFBTXNCLGNBQUEsR0FBaUIsTUFBTWlCLGtCQUFBLENBQW1CdFosb0JBQUEsQ0FDOUMxUyxJQUFBLEVBQ0Fpc0IsYUFBQSxFQUNBam9CLFFBQVE7RUFHVixJQUFJLENBQUN3SCxlQUFBLEVBQWlCO0lBQ3BCLE1BQU14TCxJQUFBLENBQUtxYyxrQkFBQSxDQUFtQjBPLGNBQUEsQ0FBZW5oQixJQUFJO0VBQ2xEO0VBQ0QsT0FBT21oQixjQUFBO0FBQ1Q7QUFhTyxlQUFleDFCLHFCQUNwQnlLLElBQUEsRUFDQXlwQixVQUFBLEVBQTBCO0VBRTFCLE9BQU9nRSxxQkFBQSxDQUFzQjNOLFNBQUEsQ0FBVTlmLElBQUksR0FBR3lwQixVQUFVO0FBQzFEO0FBYU8sZUFBZXQxQixtQkFDcEJ5VixJQUFBLEVBQ0E2ZixVQUFBLEVBQTBCO0VBRTFCLE1BQU0xZixZQUFBLE9BQWU5UixXQUFBLENBQUE2UixrQkFBQSxFQUFtQkYsSUFBSTtFQUU1QyxNQUFNa2pCLG1CQUFBLENBQW9CLE9BQU8vaUIsWUFBQSxFQUFjMGYsVUFBQSxDQUFXeGEsVUFBVTtFQUVwRSxPQUFPa2UsT0FBQSxDQUFNcGpCLFlBQUEsRUFBYzBmLFVBQVU7QUFDdkM7QUFlTyxlQUFlNzBCLDZCQUNwQmdWLElBQUEsRUFDQTZmLFVBQUEsRUFBMEI7RUFFMUIsT0FBTzZELGVBQUEsS0FBZ0JyMUIsV0FBQSxDQUFBNlIsa0JBQUEsRUFBbUJGLElBQUksR0FBbUI2ZixVQUFVO0FBQzdFO0FDN0VPLGVBQWVpRSx3QkFDcEIxdEIsSUFBQSxFQUNBcUUsT0FBQSxFQUFxQztFQUVyQyxPQUFPd0MscUJBQUEsQ0FJTDdHLElBQUEsRUFHQSw4Q0FBQW9FLGtCQUFBLENBQW1CcEUsSUFBQSxFQUFNcUUsT0FBTyxDQUFDO0FBRXJDO0FDTk8sZUFBZTdPLHNCQUNwQndLLElBQUEsRUFDQTJ0QixXQUFBLEVBQW1CO0VBRW5CLE1BQU1sTCxZQUFBLEdBQWUzQyxTQUFBLENBQVU5ZixJQUFJO0VBQ25DLE1BQU1nRSxRQUFBLEdBQTRCLE1BQU0wcEIsdUJBQUEsQ0FBbUJqTCxZQUFBLEVBQWM7SUFDdkV6WSxLQUFBLEVBQU8yakIsV0FBQTtJQUNQNUcsaUJBQUEsRUFBbUI7RUFDcEI7RUFDRCxNQUFNSyxJQUFBLEdBQU8sTUFBTTRFLGtCQUFBLENBQW1CdFosb0JBQUEsQ0FDcEMrUCxZQUFBLEVBQVksVUFFWnplLFFBQVE7RUFFVixNQUFNeWUsWUFBQSxDQUFhcEcsa0JBQUEsQ0FBbUIrSyxJQUFBLENBQUt4ZCxJQUFJO0VBQy9DLE9BQU93ZCxJQUFBO0FBQ1Q7SUN6QnNCd0csbUJBQUEsU0FBbUI7RUFLdkM5c0IsWUFBK0Irc0IsUUFBQSxFQUFvQjdwQixRQUFBLEVBQXVCO0lBQTNDLEtBQVE2cEIsUUFBQSxHQUFSQSxRQUFBO0lBQzdCLEtBQUszZixHQUFBLEdBQU1sSyxRQUFBLENBQVM4cEIsZUFBQTtJQUNwQixLQUFLQyxjQUFBLEdBQWlCLElBQUl4a0IsSUFBQSxDQUFLdkYsUUFBQSxDQUFTZ3FCLFVBQVUsRUFBRXJrQixXQUFBLENBQVc7SUFDL0QsS0FBS3lFLFdBQUEsR0FBY3BLLFFBQUEsQ0FBU29LLFdBQUE7O0VBRzlCLE9BQU82ZixvQkFDTGp1QixJQUFBLEVBQ0FrdUIsVUFBQSxFQUF5QjtJQUV6QixJQUFJLGVBQWVBLFVBQUEsRUFBWTtNQUM3QixPQUFPQyx3QkFBQSxDQUF5QkYsbUJBQUEsQ0FBb0JqdUIsSUFBQSxFQUFNa3VCLFVBQVU7SUFDckUsV0FBVSxjQUFjQSxVQUFBLEVBQVk7TUFDbkMsT0FBT0UsdUJBQUEsQ0FBd0JILG1CQUFBLENBQW9CanVCLElBQUEsRUFBTWt1QixVQUFVO0lBQ3BFO0lBQ0QsT0FBT3h1QixLQUFBLENBQU1NLElBQUEsRUFBSTs7QUFFcEI7QUFFSyxJQUFPbXVCLHdCQUFBLEdBQVAsY0FDSVAsbUJBQUEsQ0FBbUI7RUFLM0I5c0IsWUFBb0JrRCxRQUFBLEVBQTRCO0lBQzlDLE1BQUssU0FBaUJBLFFBQVE7SUFDOUIsS0FBSzRELFdBQUEsR0FBYzVELFFBQUEsQ0FBU3FxQixTQUFBOztFQUc5QixPQUFPSixvQkFDTHpJLEtBQUEsRUFDQTBJLFVBQUEsRUFBeUI7SUFFekIsT0FBTyxJQUFJQyx3QkFBQSxDQUF5QkQsVUFBZ0M7O0FBRXZFO0FBQ0ssSUFBT0UsdUJBQUEsR0FBUCxjQUNJUixtQkFBQSxDQUFtQjtFQUczQjlzQixZQUFvQmtELFFBQUEsRUFBMkI7SUFDN0MsTUFBSyxRQUFnQkEsUUFBUTs7RUFHL0IsT0FBT2lxQixvQkFDTHpJLEtBQUEsRUFDQTBJLFVBQUEsRUFBeUI7SUFFekIsT0FBTyxJQUFJRSx1QkFBQSxDQUF3QkYsVUFBK0I7O0FBRXJFO1NDakVlSSxnQ0FDZHR1QixJQUFBLEVBQ0FxRSxPQUFBLEVBQ0FrcUIsa0JBQUEsRUFBc0M7O0VBRXRDcnRCLE9BQUEsR0FDRVEsRUFBQSxHQUFBNnNCLGtCQUFBLENBQW1CbHJCLEdBQUEsTUFBSyxRQUFBM0IsRUFBQSx1QkFBQUEsRUFBQSxDQUFBZ0gsTUFBQSxJQUFTLEdBQ2pDMUksSUFBQSxFQUFJO0VBR05rQixPQUFBLENBQ0UsT0FBT3F0QixrQkFBQSxDQUFtQkMsaUJBQUEsS0FBc0IsZUFDOUNELGtCQUFBLENBQW1CQyxpQkFBQSxDQUFrQjlsQixNQUFBLEdBQVMsR0FDaEQxSSxJQUFBLEVBQUk7RUFJTnFFLE9BQUEsQ0FBUWlsQixXQUFBLEdBQWNpRixrQkFBQSxDQUFtQmxyQixHQUFBO0VBQ3pDZ0IsT0FBQSxDQUFRbXFCLGlCQUFBLEdBQW9CRCxrQkFBQSxDQUFtQkMsaUJBQUE7RUFDL0NucUIsT0FBQSxDQUFRb3FCLGtCQUFBLEdBQXFCRixrQkFBQSxDQUFtQkcsZUFBQTtFQUVoRCxJQUFJSCxrQkFBQSxDQUFtQkksR0FBQSxFQUFLO0lBQzFCenRCLE9BQUEsQ0FDRXF0QixrQkFBQSxDQUFtQkksR0FBQSxDQUFJQyxRQUFBLENBQVNsbUIsTUFBQSxHQUFTLEdBQ3pDMUksSUFBQSxFQUFJO0lBR05xRSxPQUFBLENBQVF3cUIsV0FBQSxHQUFjTixrQkFBQSxDQUFtQkksR0FBQSxDQUFJQyxRQUFBO0VBQzlDO0VBRUQsSUFBSUwsa0JBQUEsQ0FBbUJPLE9BQUEsRUFBUztJQUM5QjV0QixPQUFBLENBQ0VxdEIsa0JBQUEsQ0FBbUJPLE9BQUEsQ0FBUUMsV0FBQSxDQUFZcm1CLE1BQUEsR0FBUyxHQUNoRDFJLElBQUEsRUFBSTtJQUdOcUUsT0FBQSxDQUFRMnFCLGlCQUFBLEdBQW9CVCxrQkFBQSxDQUFtQk8sT0FBQSxDQUFRRyxVQUFBO0lBQ3ZENXFCLE9BQUEsQ0FBUTZxQix5QkFBQSxHQUNOWCxrQkFBQSxDQUFtQk8sT0FBQSxDQUFRSyxjQUFBO0lBQzdCOXFCLE9BQUEsQ0FBUStxQixrQkFBQSxHQUFxQmIsa0JBQUEsQ0FBbUJPLE9BQUEsQ0FBUUMsV0FBQTtFQUN6RDtBQUNIO0FDVEEsZUFBZU0sc0JBQXNCcnZCLElBQUEsRUFBVTtFQUM3QyxNQUFNeWlCLFlBQUEsR0FBZTNDLFNBQUEsQ0FBVTlmLElBQUk7RUFDbkMsSUFBSXlpQixZQUFBLENBQWEvRSwwQkFBQSxDQUEwQixHQUFJO0lBQzdDLE1BQU0rRSxZQUFBLENBQWE5RSxxQkFBQSxDQUFxQjtFQUN6QztBQUNIO0FBb0NPLGVBQWV4b0IsdUJBQ3BCNkssSUFBQSxFQUNBMkgsS0FBQSxFQUNBNG1CLGtCQUFBLEVBQXVDO0VBRXZDLE1BQU05TCxZQUFBLEdBQWUzQyxTQUFBLENBQVU5ZixJQUFJO0VBQ25DLE1BQU1xRSxPQUFBLEdBQStDO0lBQ25EaXJCLFdBQUEsRUFBK0M7SUFDL0MzbkIsS0FBQTtJQUNBMlosVUFBQSxFQUFtQzs7RUFFckMsSUFBSWlOLGtCQUFBLEVBQW9CO0lBQ3RCRCwrQkFBQSxDQUFnQzdMLFlBQUEsRUFBY3BlLE9BQUEsRUFBU2txQixrQkFBa0I7RUFDMUU7RUFDRCxNQUFNdE0sbUJBQUEsQ0FDSlEsWUFBQSxFQUNBcGUsT0FBQSxFQUFPLGNBRVA4aEIsd0JBQXFDO0FBRXpDO0FBV08sZUFBZWp6QixxQkFDcEI4TSxJQUFBLEVBQ0E2bUIsT0FBQSxFQUNBMEksV0FBQSxFQUFtQjtFQUVuQixNQUFNM0osYUFBQSxLQUNXM3RCLFdBQUEsQ0FBQTZSLGtCQUFBLEVBQW1COUosSUFBSSxHQUFHO0lBQ3ZDNm1CLE9BQUE7SUFDQTBJO0dBQ0QsRUFDQS9OLEtBQUEsQ0FBTSxNQUFNL2hCLEtBQUEsSUFBUTtJQUNuQixJQUNFQSxLQUFBLENBQU1RLElBQUEsS0FDTixRQUFRLHlDQUNSO01BQ0EsS0FBS292QixxQkFBQSxDQUFzQnJ2QixJQUFJO0lBQ2hDO0lBRUQsTUFBTVAsS0FBQTtFQUNSLENBQUM7QUFFTDtBQVVPLGVBQWU3TSxnQkFDcEJvTixJQUFBLEVBQ0E2bUIsT0FBQSxFQUFlO0VBRWYsTUFBTWQsaUJBQUEsS0FBd0I5dEIsV0FBQSxDQUFBNlIsa0JBQUEsRUFBbUI5SixJQUFJLEdBQUc7SUFBRTZtQjtFQUFPLENBQUU7QUFDckU7QUFZTyxlQUFlNXpCLGdCQUNwQitNLElBQUEsRUFDQTZtQixPQUFBLEVBQWU7RUFFZixNQUFNMkksV0FBQSxPQUFjdjNCLFdBQUEsQ0FBQTZSLGtCQUFBLEVBQW1COUosSUFBSTtFQUMzQyxNQUFNZ0UsUUFBQSxHQUFXLE1BQU00aEIsYUFBQSxDQUFzQjRKLFdBQUEsRUFBYTtJQUFFM0k7RUFBTyxDQUFFO0VBUXJFLE1BQU11QixTQUFBLEdBQVlwa0IsUUFBQSxDQUFTc3JCLFdBQUE7RUFDM0JwdUIsT0FBQSxDQUFRa25CLFNBQUEsRUFBV29ILFdBQUEsRUFBVztFQUM5QixRQUFRcEgsU0FBQTtTQUNOO01BQ0U7U0FDRjtNQUNFbG5CLE9BQUEsQ0FBUThDLFFBQUEsQ0FBU3lyQixRQUFBLEVBQVVELFdBQUEsRUFBVztNQUN0QztTQUNGO01BQ0V0dUIsT0FBQSxDQUFROEMsUUFBQSxDQUFTMHJCLE9BQUEsRUFBU0YsV0FBQSxFQUFXOztNQUdyQ3R1QixPQUFBLENBQVE4QyxRQUFBLENBQVMyRCxLQUFBLEVBQU82bkIsV0FBQSxFQUFXOztFQUl2QyxJQUFJRyxlQUFBLEdBQThDO0VBQ2xELElBQUkzckIsUUFBQSxDQUFTMHJCLE9BQUEsRUFBUztJQUNwQkMsZUFBQSxHQUFrQi9CLG1CQUFBLENBQW9CSyxtQkFBQSxDQUNwQ25PLFNBQUEsQ0FBVTBQLFdBQVcsR0FDckJ4ckIsUUFBQSxDQUFTMHJCLE9BQU87RUFFbkI7RUFFRCxPQUFPO0lBQ0xFLElBQUEsRUFBTTtNQUNKam9CLEtBQUEsR0FDRzNELFFBQUEsQ0FBU3NyQixXQUFBLEtBQTJELDRCQUNqRXRyQixRQUFBLENBQVN5ckIsUUFBQSxHQUNUenJCLFFBQUEsQ0FBUzJELEtBQUEsS0FBVTtNQUN6QmtvQixhQUFBLEdBQ0c3ckIsUUFBQSxDQUFTc3JCLFdBQUEsS0FBMkQsNEJBQ2pFdHJCLFFBQUEsQ0FBUzJELEtBQUEsR0FDVDNELFFBQUEsQ0FBU3lyQixRQUFBLEtBQWE7TUFDNUJFO0lBQ0Q7SUFDRHZIOztBQUVKO0FBWU8sZUFBZTV4Qix3QkFDcEJ3SixJQUFBLEVBQ0FDLElBQUEsRUFBWTtFQUVaLE1BQU07SUFBRTJ2QjtFQUFJLElBQUssTUFBTTM4QixlQUFBLEtBQWdCZ0YsV0FBQSxDQUFBNlIsa0JBQUEsRUFBbUI5SixJQUFJLEdBQUdDLElBQUk7RUFFckUsT0FBTzJ2QixJQUFBLENBQUtqb0IsS0FBQTtBQUNkO0FBbUJPLGVBQWV2VSwrQkFDcEI0TSxJQUFBLEVBQ0EySCxLQUFBLEVBQ0E0UixRQUFBLEVBQWdCO0VBRWhCLE1BQU1rSixZQUFBLEdBQWUzQyxTQUFBLENBQVU5ZixJQUFJO0VBQ25DLE1BQU1xRSxPQUFBLEdBQXlCO0lBQzdCMGlCLGlCQUFBLEVBQW1CO0lBQ25CcGYsS0FBQTtJQUNBNFIsUUFBQTtJQUNBK0gsVUFBQSxFQUFtQzs7RUFFckMsTUFBTXdPLGNBQUEsR0FBMkM3TixtQkFBQSxDQUMvQ1EsWUFBQSxFQUNBcGUsT0FBQSxFQUFPLGtCQUVQMG5CLE1BQU07RUFFUixNQUFNL25CLFFBQUEsR0FBVyxNQUFNOHJCLGNBQUEsQ0FBZXRPLEtBQUEsQ0FBTS9oQixLQUFBLElBQVE7SUFDbEQsSUFDRUEsS0FBQSxDQUFNUSxJQUFBLEtBQVMsUUFBUSx5Q0FDdkI7TUFDQSxLQUFLb3ZCLHFCQUFBLENBQXNCcnZCLElBQUk7SUFDaEM7SUFFRCxNQUFNUCxLQUFBO0VBQ1IsQ0FBQztFQUVELE1BQU1zckIsY0FBQSxHQUFpQixNQUFNaUIsa0JBQUEsQ0FBbUJ0WixvQkFBQSxDQUM5QytQLFlBQUEsRUFBWSxVQUVaemUsUUFBUTtFQUVWLE1BQU15ZSxZQUFBLENBQWFwRyxrQkFBQSxDQUFtQjBPLGNBQUEsQ0FBZW5oQixJQUFJO0VBRXpELE9BQU9taEIsY0FBQTtBQUNUO1NBb0JnQnQxQiwyQkFDZHVLLElBQUEsRUFDQTJILEtBQUEsRUFDQTRSLFFBQUEsRUFBZ0I7RUFFaEIsT0FBT2hrQixvQkFBQSxLQUNMMEMsV0FBQSxDQUFBNlIsa0JBQUEsRUFBbUI5SixJQUFJLEdBQ3ZCdE8saUJBQUEsQ0FBa0IrM0IsVUFBQSxDQUFXOWhCLEtBQUEsRUFBTzRSLFFBQVEsQ0FBQyxFQUM3Q2lJLEtBQUEsQ0FBTSxNQUFNL2hCLEtBQUEsSUFBUTtJQUNwQixJQUNFQSxLQUFBLENBQU1RLElBQUEsS0FBUyxRQUFRLHlDQUN2QjtNQUNBLEtBQUtvdkIscUJBQUEsQ0FBc0JydkIsSUFBSTtJQUNoQztJQUVELE1BQU1QLEtBQUE7RUFDUixDQUFDO0FBQ0g7QUN0UU8sZUFBZXJLLHNCQUNwQjRLLElBQUEsRUFDQTJILEtBQUEsRUFDQTRtQixrQkFBQSxFQUFzQztFQUV0QyxNQUFNOUwsWUFBQSxHQUFlM0MsU0FBQSxDQUFVOWYsSUFBSTtFQUNuQyxNQUFNcUUsT0FBQSxHQUFrQztJQUN0Q2lyQixXQUFBLEVBQTZDO0lBQzdDM25CLEtBQUE7SUFDQTJaLFVBQUEsRUFBbUM7O0VBRXJDLFNBQVN5TyxzQkFDUEMsUUFBQSxFQUNBQyxtQkFBQSxFQUFzQztJQUV0Qy91QixPQUFBLENBQ0UrdUIsbUJBQUEsQ0FBbUJ2QixlQUFBLEVBQ25Cak0sWUFBQSxFQUFZO0lBR2QsSUFBSXdOLG1CQUFBLEVBQW9CO01BQ3RCM0IsK0JBQUEsQ0FDRTdMLFlBQUEsRUFDQXVOLFFBQUEsRUFDQUMsbUJBQWtCO0lBRXJCOztFQUVIRixxQkFBQSxDQUFzQjFyQixPQUFBLEVBQVNrcUIsa0JBQWtCO0VBQ2pELE1BQU10TSxtQkFBQSxDQUNKUSxZQUFBLEVBQ0FwZSxPQUFBLEVBQU8sY0FFUCtoQix1QkFBeUI7QUFFN0I7QUFVZ0IsU0FBQWx5QixzQkFBc0I4TCxJQUFBLEVBQVkycEIsU0FBQSxFQUFpQjtFQUNqRSxNQUFNQyxhQUFBLEdBQWdCdjRCLGFBQUEsQ0FBY2s0QixTQUFBLENBQVVJLFNBQVM7RUFDdkQsUUFBT0MsYUFBQSxhQUFBQSxhQUFBLEtBQWEsa0JBQWJBLGFBQUEsQ0FBZXhCLFNBQUEsTUFBUztBQUNqQztBQXVDTyxlQUFlMXlCLG9CQUNwQnNLLElBQUEsRUFDQTJILEtBQUEsRUFDQWdpQixTQUFBLEVBQWtCO0VBRWxCLE1BQU02RixXQUFBLE9BQWN2M0IsV0FBQSxDQUFBNlIsa0JBQUEsRUFBbUI5SixJQUFJO0VBQzNDLE1BQU15cEIsVUFBQSxHQUFhLzNCLGlCQUFBLENBQWtCZzRCLGtCQUFBLENBQ25DL2hCLEtBQUEsRUFDQWdpQixTQUFBLElBQWFub0IsY0FBQSxDQUFjLENBQUU7RUFJL0JOLE9BQUEsQ0FDRXVvQixVQUFBLENBQVcvQyxTQUFBLE1BQWU4SSxXQUFBLENBQVlsckIsUUFBQSxJQUFZLE9BQ2xEa3JCLFdBQUEsRUFBVztFQUdiLE9BQU9qNkIsb0JBQUEsQ0FBcUJpNkIsV0FBQSxFQUFhL0YsVUFBVTtBQUNyRDtBQ2pKTyxlQUFleUcsY0FDcEJsd0IsSUFBQSxFQUNBcUUsT0FBQSxFQUE2QjtFQUU3QixPQUFPRSxrQkFBQSxDQUNMdkUsSUFBQSxFQUdBLHNDQUFBb0Usa0JBQUEsQ0FBbUJwRSxJQUFBLEVBQU1xRSxPQUFPLENBQUM7QUFFckM7QUNPTyxlQUFlOVEsMkJBQ3BCeU0sSUFBQSxFQUNBMkgsS0FBQSxFQUFhO0VBS2IsTUFBTXdvQixXQUFBLEdBQWN0dUIsY0FBQSxDQUFjLElBQUtMLGNBQUEsQ0FBYyxJQUFLO0VBQzFELE1BQU02QyxPQUFBLEdBQWdDO0lBQ3BDK3JCLFVBQUEsRUFBWXpvQixLQUFBO0lBQ1p3b0I7O0VBR0YsTUFBTTtJQUFFRTtFQUFhLElBQUssTUFBTUgsYUFBQSxLQUM5Qmo0QixXQUFBLENBQUE2UixrQkFBQSxFQUFtQjlKLElBQUksR0FDdkJxRSxPQUFPO0VBR1QsT0FBT2dzQixhQUFBLElBQWlCO0FBQzFCO0FBZ0NPLGVBQWVuN0Isc0JBQ3BCMFUsSUFBQSxFQUNBMmtCLGtCQUFBLEVBQThDO0VBRTlDLE1BQU14a0IsWUFBQSxPQUFlOVIsV0FBQSxDQUFBNlIsa0JBQUEsRUFBbUJGLElBQUk7RUFDNUMsTUFBTXdELE9BQUEsR0FBVSxNQUFNeEQsSUFBQSxDQUFLbFcsVUFBQSxDQUFVO0VBQ3JDLE1BQU0yUSxPQUFBLEdBQWtDO0lBQ3RDaXJCLFdBQUEsRUFBNkM7SUFDN0NsaUI7O0VBRUYsSUFBSW1oQixrQkFBQSxFQUFvQjtJQUN0QkQsK0JBQUEsQ0FDRXZrQixZQUFBLENBQWEvSixJQUFBLEVBQ2JxRSxPQUFBLEVBQ0FrcUIsa0JBQWtCO0VBRXJCO0VBRUQsTUFBTTtJQUFFNW1CO0VBQUssSUFBSyxNQUFNdWUsdUJBQUEsQ0FBMEJuYyxZQUFBLENBQWEvSixJQUFBLEVBQU1xRSxPQUFPO0VBRTVFLElBQUlzRCxLQUFBLEtBQVVpQyxJQUFBLENBQUtqQyxLQUFBLEVBQU87SUFDeEIsTUFBTWlDLElBQUEsQ0FBSzVVLE1BQUEsQ0FBTTtFQUNsQjtBQUNIO0FBb0NPLGVBQWV1Qix3QkFDcEJxVCxJQUFBLEVBQ0E2bEIsUUFBQSxFQUNBbEIsa0JBQUEsRUFBOEM7RUFFOUMsTUFBTXhrQixZQUFBLE9BQWU5UixXQUFBLENBQUE2UixrQkFBQSxFQUFtQkYsSUFBSTtFQUM1QyxNQUFNd0QsT0FBQSxHQUFVLE1BQU14RCxJQUFBLENBQUtsVyxVQUFBLENBQVU7RUFDckMsTUFBTTJRLE9BQUEsR0FBMkM7SUFDL0NpckIsV0FBQSxFQUF3RDtJQUN4RGxpQixPQUFBO0lBQ0FxaUI7O0VBRUYsSUFBSWxCLGtCQUFBLEVBQW9CO0lBQ3RCRCwrQkFBQSxDQUNFdmtCLFlBQUEsQ0FBYS9KLElBQUEsRUFDYnFFLE9BQUEsRUFDQWtxQixrQkFBa0I7RUFFckI7RUFFRCxNQUFNO0lBQUU1bUI7RUFBSyxJQUFLLE1BQU0wZSxvQkFBQSxDQUF5QnRjLFlBQUEsQ0FBYS9KLElBQUEsRUFBTXFFLE9BQU87RUFFM0UsSUFBSXNELEtBQUEsS0FBVWlDLElBQUEsQ0FBS2pDLEtBQUEsRUFBTztJQUd4QixNQUFNaUMsSUFBQSxDQUFLNVUsTUFBQSxDQUFNO0VBQ2xCO0FBQ0g7QUM1Sk8sZUFBZXM3QixnQkFDcEJ0d0IsSUFBQSxFQUNBcUUsT0FBQSxFQUE2QjtFQUU3QixPQUFPRSxrQkFBQSxDQUNMdkUsSUFBQSxFQUdBLCtCQUFBcUUsT0FBTztBQUVYO0FDTk8sZUFBZWpPLGNBQ3BCd1QsSUFBQSxFQUNBO0VBQ0V3RSxXQUFBO0VBQ0FDLFFBQUEsRUFBVUM7QUFBUSxHQUN3QztFQUU1RCxJQUFJRixXQUFBLEtBQWdCLFVBQWFFLFFBQUEsS0FBYSxRQUFXO0lBQ3ZEO0VBQ0Q7RUFFRCxNQUFNdkUsWUFBQSxPQUFlOVIsV0FBQSxDQUFBNlIsa0JBQUEsRUFBbUJGLElBQUk7RUFDNUMsTUFBTXdELE9BQUEsR0FBVSxNQUFNckQsWUFBQSxDQUFhclcsVUFBQSxDQUFVO0VBQzdDLE1BQU02OEIsY0FBQSxHQUFpQjtJQUNyQm5qQixPQUFBO0lBQ0FnQixXQUFBO0lBQ0FFLFFBQUE7SUFDQXlZLGlCQUFBLEVBQW1COztFQUVyQixNQUFNL2lCLFFBQUEsR0FBVyxNQUFNdUgsb0JBQUEsQ0FDckJ4QixZQUFBLEVBQ0F1bUIsZUFBQSxDQUFpQnZtQixZQUFBLENBQWEvSixJQUFBLEVBQU11d0IsY0FBYyxDQUFDO0VBR3JEeG1CLFlBQUEsQ0FBYXFFLFdBQUEsR0FBY3BLLFFBQUEsQ0FBU29LLFdBQUEsSUFBZTtFQUNuRHJFLFlBQUEsQ0FBYXNFLFFBQUEsR0FBV3JLLFFBQUEsQ0FBU3NLLFFBQUEsSUFBWTtFQUc3QyxNQUFNa2lCLGdCQUFBLEdBQW1Cem1CLFlBQUEsQ0FBYTRELFlBQUEsQ0FBYThpQixJQUFBLENBQ2pELENBQUM7SUFBRXhoQjtFQUFVLE1BQU9BLFVBQUEsS0FBVTtFQUVoQyxJQUFJdWhCLGdCQUFBLEVBQWtCO0lBQ3BCQSxnQkFBQSxDQUFpQnBpQixXQUFBLEdBQWNyRSxZQUFBLENBQWFxRSxXQUFBO0lBQzVDb2lCLGdCQUFBLENBQWlCbmlCLFFBQUEsR0FBV3RFLFlBQUEsQ0FBYXNFLFFBQUE7RUFDMUM7RUFFRCxNQUFNdEUsWUFBQSxDQUFhMkgsd0JBQUEsQ0FBeUIxTixRQUFRO0FBQ3REO0FBcUJnQixTQUFBL04sWUFBWTJULElBQUEsRUFBWTZsQixRQUFBLEVBQWdCO0VBQ3RELE9BQU9pQixxQkFBQSxLQUNMejRCLFdBQUEsQ0FBQTZSLGtCQUFBLEVBQW1CRixJQUFJLEdBQ3ZCNmxCLFFBQUEsRUFDQSxJQUFJO0FBRVI7QUFlZ0IsU0FBQXY1QixlQUFlMFQsSUFBQSxFQUFZMmxCLFdBQUEsRUFBbUI7RUFDNUQsT0FBT21CLHFCQUFBLEtBQ0x6NEIsV0FBQSxDQUFBNlIsa0JBQUEsRUFBbUJGLElBQUksR0FDdkIsTUFDQTJsQixXQUFXO0FBRWY7QUFFQSxlQUFlbUIsc0JBQ2I5bUIsSUFBQSxFQUNBakMsS0FBQSxFQUNBNFIsUUFBQSxFQUF1QjtFQUV2QixNQUFNO0lBQUV2WjtFQUFJLElBQUs0SixJQUFBO0VBQ2pCLE1BQU13RCxPQUFBLEdBQVUsTUFBTXhELElBQUEsQ0FBS2xXLFVBQUEsQ0FBVTtFQUNyQyxNQUFNMlEsT0FBQSxHQUFzQztJQUMxQytJLE9BQUE7SUFDQTJaLGlCQUFBLEVBQW1COztFQUdyQixJQUFJcGYsS0FBQSxFQUFPO0lBQ1R0RCxPQUFBLENBQVFzRCxLQUFBLEdBQVFBLEtBQUE7RUFDakI7RUFFRCxJQUFJNFIsUUFBQSxFQUFVO0lBQ1psVixPQUFBLENBQVFrVixRQUFBLEdBQVdBLFFBQUE7RUFDcEI7RUFFRCxNQUFNdlYsUUFBQSxHQUFXLE1BQU11SCxvQkFBQSxDQUNyQjNCLElBQUEsRUFDQWljLG1CQUFBLENBQXVCN2xCLElBQUEsRUFBTXFFLE9BQU8sQ0FBQztFQUV2QyxNQUFNdUYsSUFBQSxDQUFLOEgsd0JBQUEsQ0FBeUIxTixRQUFBLEVBQXVCLElBQUk7QUFDakU7QUMxSE0sU0FBVTBPLHFCQUNkQyxlQUFBLEVBQWlDOztFQUVqQyxJQUFJLENBQUNBLGVBQUEsRUFBaUI7SUFDcEIsT0FBTztFQUNSO0VBQ0QsTUFBTTtJQUFFMUQ7RUFBVSxJQUFLMEQsZUFBQTtFQUN2QixNQUFNZ2UsT0FBQSxHQUFVaGUsZUFBQSxDQUFnQmllLFdBQUEsR0FDNUIvckIsSUFBQSxDQUFLc0csS0FBQSxDQUFNd0gsZUFBQSxDQUFnQmllLFdBQVcsSUFDdEM7RUFDSixNQUFNQyxTQUFBLEdBQ0psZSxlQUFBLENBQWdCa2UsU0FBQSxJQUNoQmxlLGVBQUEsQ0FBZ0JtZSxJQUFBLEtBQUk7RUFDdEIsSUFBSSxDQUFDN2hCLFVBQUEsS0FBYzBELGVBQUEsS0FBZSxRQUFmQSxlQUFBLEtBQWUsa0JBQWZBLGVBQUEsQ0FBaUJ2RixPQUFBLEdBQVM7SUFDM0MsTUFBTTdDLGNBQUEsSUFBaUJ5SCxFQUFBLElBQUF0USxFQUFBLEdBQUF3SSxXQUFBLENBQVl5SSxlQUFBLENBQWdCdkYsT0FBTyxPQUFHLFFBQUExTCxFQUFBLHVCQUFBQSxFQUFBLENBQUE0SSxRQUFBLE1BQzNELFFBQUEwSCxFQUFBLHVCQUFBQSxFQUFBO0lBRUYsSUFBSXpILGNBQUEsRUFBZ0I7TUFDbEIsTUFBTXdtQixrQkFBQSxHQUNKeG1CLGNBQUEsS0FBdUMsZUFDdkNBLGNBQUEsS0FBb0MsV0FDL0JBLGNBQUEsR0FDRDtNQUVOLE9BQU8sSUFBSXltQix5QkFBQSxDQUEwQkgsU0FBQSxFQUFXRSxrQkFBa0I7SUFDbkU7RUFDRjtFQUNELElBQUksQ0FBQzloQixVQUFBLEVBQVk7SUFDZixPQUFPO0VBQ1I7RUFDRCxRQUFRQSxVQUFBO1NBQ047TUFDRSxPQUFPLElBQUlnaUIsMEJBQUEsQ0FBMkJKLFNBQUEsRUFBV0YsT0FBTztTQUMxRDtNQUNFLE9BQU8sSUFBSU8sd0JBQUEsQ0FBeUJMLFNBQUEsRUFBV0YsT0FBTztTQUN4RDtNQUNFLE9BQU8sSUFBSVEsd0JBQUEsQ0FBeUJOLFNBQUEsRUFBV0YsT0FBTztTQUN4RDtNQUNFLE9BQU8sSUFBSVMseUJBQUEsQ0FDVFAsU0FBQSxFQUNBRixPQUFBLEVBQ0FoZSxlQUFBLENBQWdCMGUsVUFBQSxJQUFjLElBQUk7U0FFZjtTQUN2QjtNQUNFLE9BQU8sSUFBSUwseUJBQUEsQ0FBMEJILFNBQUEsRUFBVyxJQUFJOztNQUVwRCxPQUFPLElBQUlHLHlCQUFBLENBQTBCSCxTQUFBLEVBQVc1aEIsVUFBQSxFQUFZMGhCLE9BQU87O0FBRXpFO0FBRUEsSUFBTUsseUJBQUEsR0FBTixNQUErQjtFQUM3Qmx3QixZQUNXK3ZCLFNBQUEsRUFDQTVoQixVQUFBLEVBQ0EwaEIsT0FBQSxHQUFtQyxJQUFFO0lBRnJDLEtBQVNFLFNBQUEsR0FBVEEsU0FBQTtJQUNBLEtBQVU1aEIsVUFBQSxHQUFWQSxVQUFBO0lBQ0EsS0FBTzBoQixPQUFBLEdBQVBBLE9BQUE7O0FBRVo7QUFFRCxJQUFNVyx1Q0FBQSxHQUFOLGNBQXNETix5QkFBQSxDQUF5QjtFQUM3RWx3QixZQUNFK3ZCLFNBQUEsRUFDQTVoQixVQUFBLEVBQ0EwaEIsT0FBQSxFQUNTWSxRQUFBLEVBQXVCO0lBRWhDLE1BQU1WLFNBQUEsRUFBVzVoQixVQUFBLEVBQVkwaEIsT0FBTztJQUYzQixLQUFRWSxRQUFBLEdBQVJBLFFBQUE7O0FBSVo7QUFFRCxJQUFNTiwwQkFBQSxHQUFOLGNBQXlDRCx5QkFBQSxDQUF5QjtFQUNoRWx3QixZQUFZK3ZCLFNBQUEsRUFBb0JGLE9BQUEsRUFBZ0M7SUFDOUQsTUFBTUUsU0FBQSxFQUFnQyxnQkFBQUYsT0FBTzs7QUFFaEQ7QUFFRCxJQUFNTyx3QkFBQSxHQUFOLGNBQXVDSSx1Q0FBQSxDQUF1QztFQUM1RXh3QixZQUFZK3ZCLFNBQUEsRUFBb0JGLE9BQUEsRUFBZ0M7SUFDOUQsTUFDRUUsU0FBQSxFQUVBLGNBQUFGLE9BQUEsRUFDQSxRQUFPQSxPQUFBLEtBQU8sUUFBUEEsT0FBQSxLQUFPLGtCQUFQQSxPQUFBLENBQVNhLEtBQUEsTUFBVSxXQUFXYixPQUFBLEtBQU8sUUFBUEEsT0FBQSx1QkFBQUEsT0FBQSxDQUFTYSxLQUFBLEdBQVEsSUFBSTs7QUFHL0Q7QUFFRCxJQUFNTCx3QkFBQSxHQUFOLGNBQXVDSCx5QkFBQSxDQUF5QjtFQUM5RGx3QixZQUFZK3ZCLFNBQUEsRUFBb0JGLE9BQUEsRUFBZ0M7SUFDOUQsTUFBTUUsU0FBQSxFQUE4QixjQUFBRixPQUFPOztBQUU5QztBQUVELElBQU1TLHlCQUFBLEdBQU4sY0FBd0NFLHVDQUFBLENBQXVDO0VBQzdFeHdCLFlBQ0UrdkIsU0FBQSxFQUNBRixPQUFBLEVBQ0FVLFVBQUEsRUFBeUI7SUFFekIsTUFBTVIsU0FBQSxFQUFTLGVBQXNCRixPQUFBLEVBQVNVLFVBQVU7O0FBRTNEO0FBU0ssU0FBVTc5QixzQkFDZHUzQixjQUFBLEVBQThCO0VBRTlCLE1BQU07SUFBRW5oQixJQUFBO0lBQU05QjtFQUFjLElBQUtpakIsY0FBQTtFQUNqQyxJQUFJbmhCLElBQUEsQ0FBS2tFLFdBQUEsSUFBZSxDQUFDaEcsY0FBQSxFQUFnQjtJQUd2QyxPQUFPO01BQ0xtSCxVQUFBLEVBQVk7TUFDWjRoQixTQUFBLEVBQVc7TUFDWEYsT0FBQSxFQUFTOztFQUVaO0VBRUQsT0FBT2plLG9CQUFBLENBQXFCNUssY0FBYztBQUM1QztBQzNGZ0IsU0FBQXpTLGVBQ2QySyxJQUFBLEVBQ0FnVSxXQUFBLEVBQXdCO0VBRXhCLFdBQU8vYixXQUFBLENBQUE2UixrQkFBQSxFQUFtQjlKLElBQUksRUFBRTNLLGNBQUEsQ0FBZTJlLFdBQVc7QUFDNUQ7QUE2Qk0sU0FBVS9mLDBCQUEwQitMLElBQUEsRUFBVTtFQUNsRCxPQUFPd2lCLDBCQUFBLENBQTJCeGlCLElBQUk7QUFDeEM7QUF5Qk8sZUFBZTFKLGlCQUNwQjBKLElBQUEsRUFDQXVaLFFBQUEsRUFBZ0I7RUFFaEIsTUFBTWtKLFlBQUEsR0FBZTNDLFNBQUEsQ0FBVTlmLElBQUk7RUFDbkMsT0FBT3lpQixZQUFBLENBQWFuc0IsZ0JBQUEsQ0FBaUJpakIsUUFBUTtBQUMvQztBQWtCTSxTQUFVOWtCLGlCQUNkdUwsSUFBQSxFQUNBOGQsY0FBQSxFQUNBcmUsS0FBQSxFQUNBc2UsU0FBQSxFQUFzQjtFQUV0QixXQUFPOWxCLFdBQUEsQ0FBQTZSLGtCQUFBLEVBQW1COUosSUFBSSxFQUFFdkwsZ0JBQUEsQ0FDOUJxcEIsY0FBQSxFQUNBcmUsS0FBQSxFQUNBc2UsU0FBUztBQUViO1NBV2dCbHJCLHVCQUNkbU4sSUFBQSxFQUNBdVIsUUFBQSxFQUNBb0csT0FBQSxFQUFvQjtFQUVwQixXQUFPMWYsV0FBQSxDQUFBNlIsa0JBQUEsRUFBbUI5SixJQUFJLEVBQUVuTixzQkFBQSxDQUF1QjBlLFFBQUEsRUFBVW9HLE9BQU87QUFDMUU7QUFnQk0sU0FBVW5qQixtQkFDZHdMLElBQUEsRUFDQThkLGNBQUEsRUFDQXJlLEtBQUEsRUFDQXNlLFNBQUEsRUFBc0I7RUFFdEIsV0FBTzlsQixXQUFBLENBQUE2UixrQkFBQSxFQUFtQjlKLElBQUksRUFBRXhMLGtCQUFBLENBQzlCc3BCLGNBQUEsRUFDQXJlLEtBQUEsRUFDQXNlLFNBQVM7QUFFYjtBQVFNLFNBQVUxbkIsa0JBQWtCMkosSUFBQSxFQUFVO0VBQzFDLElBQUEvSCxXQUFBLENBQUE2UixrQkFBQSxFQUFtQjlKLElBQUksRUFBRTNKLGlCQUFBLENBQWlCO0FBQzVDO0FBbUJnQixTQUFBTCxrQkFDZGdLLElBQUEsRUFDQTRKLElBQUEsRUFBaUI7RUFFakIsV0FBTzNSLFdBQUEsQ0FBQTZSLGtCQUFBLEVBQW1COUosSUFBSSxFQUFFaEssaUJBQUEsQ0FBa0I0VCxJQUFJO0FBQ3hEO0FBUU0sU0FBVTlULFFBQVFrSyxJQUFBLEVBQVU7RUFDaEMsV0FBTy9ILFdBQUEsQ0FBQTZSLGtCQUFBLEVBQW1COUosSUFBSSxFQUFFbEssT0FBQSxDQUFPO0FBQ3pDO0FBVWdCLFNBQUFiLGtCQUFrQitLLElBQUEsRUFBWWdLLEtBQUEsRUFBYTtFQUN6RCxNQUFNeVksWUFBQSxHQUFlM0MsU0FBQSxDQUFVOWYsSUFBSTtFQUNuQyxPQUFPeWlCLFlBQUEsQ0FBYXh0QixpQkFBQSxDQUFrQitVLEtBQUs7QUFDN0M7QUErRU8sZUFBZTFXLFdBQVdzVyxJQUFBLEVBQVU7RUFDekMsV0FBTzNSLFdBQUEsQ0FBQTZSLGtCQUFBLEVBQW1CRixJQUFJLEVBQUVpSSxNQUFBLENBQU07QUFDeEM7SUNuVGE0ZixzQkFBQSxTQUFzQjtFQUNqQzN3QixZQUNXcVMsSUFBQSxFQUNBc1csVUFBQSxFQUNBN2YsSUFBQSxFQUFtQjtJQUZuQixLQUFJdUosSUFBQSxHQUFKQSxJQUFBO0lBQ0EsS0FBVXNXLFVBQUEsR0FBVkEsVUFBQTtJQUNBLEtBQUk3ZixJQUFBLEdBQUpBLElBQUE7O0VBR1gsT0FBTzhuQixhQUNMdGtCLE9BQUEsRUFDQXhELElBQUEsRUFBbUI7SUFFbkIsT0FBTyxJQUFJNm5CLHNCQUFBLENBQXNCLFVBRS9CcmtCLE9BQUEsRUFDQXhELElBQUk7O0VBSVIsT0FBTytuQiwwQkFDTEMsb0JBQUEsRUFBNEI7SUFFNUIsT0FBTyxJQUFJSCxzQkFBQSxDQUVULFVBQUFHLG9CQUFvQjs7RUFJeEIxa0IsT0FBQSxFQUFNO0lBQ0osTUFBTWpJLEdBQUEsR0FDSixLQUFLa08sSUFBQSxLQUFzQyxXQUN2QyxZQUNBO0lBQ04sT0FBTztNQUNMMGUsa0JBQUEsRUFBb0I7UUFDbEIsQ0FBQzVzQixHQUFBLEdBQU0sS0FBS3drQjtNQUNiOzs7RUFJTCxPQUFPaFosU0FDTHFXLEdBQUEsRUFBMEM7O0lBRTFDLElBQUlBLEdBQUEsYUFBQUEsR0FBQSxLQUFHLGtCQUFIQSxHQUFBLENBQUsrSyxrQkFBQSxFQUFvQjtNQUMzQixLQUFJbndCLEVBQUEsR0FBQW9sQixHQUFBLENBQUkrSyxrQkFBQSxNQUFrQixRQUFBbndCLEVBQUEsdUJBQUFBLEVBQUEsQ0FBRW93QixpQkFBQSxFQUFtQjtRQUM3QyxPQUFPTCxzQkFBQSxDQUF1QkUseUJBQUEsQ0FDNUI3SyxHQUFBLENBQUkrSyxrQkFBQSxDQUFtQkMsaUJBQWlCO01BRTNDLFlBQVU5ZixFQUFBLEdBQUE4VSxHQUFBLENBQUkrSyxrQkFBQSxNQUFrQixRQUFBN2YsRUFBQSx1QkFBQUEsRUFBQSxDQUFFNUUsT0FBQSxFQUFTO1FBQzFDLE9BQU9xa0Isc0JBQUEsQ0FBdUJDLFlBQUEsQ0FDNUI1SyxHQUFBLENBQUkrSyxrQkFBQSxDQUFtQnprQixPQUFPO01BRWpDO0lBQ0Y7SUFDRCxPQUFPOztBQUVWO0lDbkRZMmtCLHVCQUFBLFNBQXVCO0VBQ2xDanhCLFlBQ1dreEIsT0FBQSxFQUNBQyxLQUFBLEVBQ1FDLGNBQUEsRUFFbUI7SUFKM0IsS0FBT0YsT0FBQSxHQUFQQSxPQUFBO0lBQ0EsS0FBS0MsS0FBQSxHQUFMQSxLQUFBO0lBQ1EsS0FBY0MsY0FBQSxHQUFkQSxjQUFBOztFQU1uQixPQUFPQyxXQUNMaFIsVUFBQSxFQUNBMWhCLEtBQUEsRUFBK0I7SUFFL0IsTUFBTU8sSUFBQSxHQUFPOGYsU0FBQSxDQUFVcUIsVUFBVTtJQUNqQyxNQUFNcmEsY0FBQSxHQUFpQnJILEtBQUEsQ0FBTW9JLFVBQUEsQ0FBV2QsZUFBQTtJQUN4QyxNQUFNa3JCLEtBQUEsSUFBU25yQixjQUFBLENBQWU0b0IsT0FBQSxJQUFXLElBQUl2Z0IsR0FBQSxDQUFJK2UsVUFBQSxJQUMvQ04sbUJBQUEsQ0FBb0JLLG1CQUFBLENBQW9CanVCLElBQUEsRUFBTWt1QixVQUFVLENBQUM7SUFHM0RodEIsT0FBQSxDQUNFNEYsY0FBQSxDQUFlOHFCLG9CQUFBLEVBQ2Y1eEIsSUFBQSxFQUFJO0lBR04sTUFBTWd5QixPQUFBLEdBQVVQLHNCQUFBLENBQXVCRSx5QkFBQSxDQUNyQzdxQixjQUFBLENBQWU4cUIsb0JBQW9CO0lBR3JDLE9BQU8sSUFBSUcsdUJBQUEsQ0FDVEMsT0FBQSxFQUNBQyxLQUFBLEVBQ0EsTUFDRTl3QixTQUFBLElBQ21DO01BQ25DLE1BQU1peEIsV0FBQSxHQUFjLE1BQU1qeEIsU0FBQSxDQUFVa3hCLFFBQUEsQ0FBU3J5QixJQUFBLEVBQU1neUIsT0FBTztNQUUxRCxPQUFPbHJCLGNBQUEsQ0FBZTRvQixPQUFBO01BQ3RCLE9BQU81b0IsY0FBQSxDQUFlOHFCLG9CQUFBO01BR3RCLE1BQU1qZixlQUFBLEdBQ0R2UyxNQUFBLENBQUFDLE1BQUEsQ0FBQUQsTUFBQSxDQUFBQyxNQUFBLEtBQUF5RyxjQUFjLEdBQ2pCO1FBQUFzRyxPQUFBLEVBQVNnbEIsV0FBQSxDQUFZaGxCLE9BQUE7UUFDckJvQyxZQUFBLEVBQWM0aUIsV0FBQSxDQUFZNWlCO01BQVk7TUFJeEMsUUFBUS9QLEtBQUEsQ0FBTXdzQixhQUFBO2FBQ1o7VUFDRSxNQUFNbEIsY0FBQSxHQUNKLE1BQU1pQixrQkFBQSxDQUFtQnRaLG9CQUFBLENBQ3ZCMVMsSUFBQSxFQUNBUCxLQUFBLENBQU13c0IsYUFBQSxFQUNOdFosZUFBZTtVQUVuQixNQUFNM1MsSUFBQSxDQUFLcWMsa0JBQUEsQ0FBbUIwTyxjQUFBLENBQWVuaEIsSUFBSTtVQUNqRCxPQUFPbWhCLGNBQUE7YUFDVDtVQUNFN3BCLE9BQUEsQ0FBUXpCLEtBQUEsQ0FBTW1LLElBQUEsRUFBTTVKLElBQUEsRUFBSTtVQUN4QixPQUFPZ3NCLGtCQUFBLENBQW1CSSxhQUFBLENBQ3hCM3NCLEtBQUEsQ0FBTW1LLElBQUEsRUFDTm5LLEtBQUEsQ0FBTXdzQixhQUFBLEVBQ050WixlQUFlOztVQUdqQmpULEtBQUEsQ0FBTU0sSUFBQSxFQUFJOztJQUVoQixDQUFDOztFQUlMLE1BQU1zeUIsY0FDSkMsZUFBQSxFQUF5QztJQUV6QyxNQUFNcHhCLFNBQUEsR0FBWW94QixlQUFBO0lBQ2xCLE9BQU8sS0FBS0wsY0FBQSxDQUFlL3dCLFNBQVM7O0FBRXZDO0FBWWUsU0FBQXZOLHVCQUNkb00sSUFBQSxFQUNBUCxLQUFBLEVBQXVCOztFQUV2QixNQUFNK3ZCLFdBQUEsT0FBY3YzQixXQUFBLENBQUE2UixrQkFBQSxFQUFtQjlKLElBQUk7RUFDM0MsTUFBTXd5QixhQUFBLEdBQWdCL3lCLEtBQUE7RUFDdEJ5QixPQUFBLENBQ0V6QixLQUFBLENBQU1vSSxVQUFBLENBQVdva0IsYUFBQSxFQUNqQnVELFdBQUEsRUFBVztFQUdidHVCLE9BQUEsRUFDRVEsRUFBQSxHQUFBOHdCLGFBQUEsQ0FBYzNxQixVQUFBLENBQVdkLGVBQUEsTUFBZSxRQUFBckYsRUFBQSx1QkFBQUEsRUFBQSxDQUFFa3dCLG9CQUFBLEVBQzFDcEMsV0FBQSxFQUFXO0VBSWIsT0FBT3VDLHVCQUFBLENBQXdCSSxVQUFBLENBQVczQyxXQUFBLEVBQWFnRCxhQUFhO0FBQ3RFO0FDNUVnQixTQUFBQyxvQkFDZHp5QixJQUFBLEVBQ0FxRSxPQUFBLEVBQXVDO0VBRXZDLE9BQU9FLGtCQUFBLENBSUx2RSxJQUFBLEVBR0EsNENBQUFvRSxrQkFBQSxDQUFtQnBFLElBQUEsRUFBTXFFLE9BQU8sQ0FBQztBQUVyQztBQVlnQixTQUFBcXVCLHVCQUNkMXlCLElBQUEsRUFDQXFFLE9BQUEsRUFBMEM7RUFFMUMsT0FBT0Usa0JBQUEsQ0FJTHZFLElBQUEsRUFHQSwrQ0FBQW9FLGtCQUFBLENBQW1CcEUsSUFBQSxFQUFNcUUsT0FBTyxDQUFDO0FBRXJDO0FBa0JnQixTQUFBc3VCLG1CQUNkM3lCLElBQUEsRUFDQXFFLE9BQUEsRUFBc0M7RUFFdEMsT0FBT0Usa0JBQUEsQ0FJTHZFLElBQUEsRUFHQSw0Q0FBQW9FLGtCQUFBLENBQW1CcEUsSUFBQSxFQUFNcUUsT0FBTyxDQUFDO0FBRXJDO0FBZ0JnQixTQUFBdXVCLHNCQUNkNXlCLElBQUEsRUFDQXFFLE9BQUEsRUFBeUM7RUFFekMsT0FBT0Usa0JBQUEsQ0FJTHZFLElBQUEsRUFHQSwrQ0FBQW9FLGtCQUFBLENBQW1CcEUsSUFBQSxFQUFNcUUsT0FBTyxDQUFDO0FBRXJDO0FBVWdCLFNBQUF3dUIsWUFDZDd5QixJQUFBLEVBQ0FxRSxPQUFBLEVBQTJCO0VBRTNCLE9BQU9FLGtCQUFBLENBQ0x2RSxJQUFBLEVBR0EsK0NBQUFvRSxrQkFBQSxDQUFtQnBFLElBQUEsRUFBTXFFLE9BQU8sQ0FBQztBQUVyQztJQzFKYXl1QixtQkFBQSxTQUFtQjtFQUc5Qmh5QixZQUE2QjhJLElBQUEsRUFBa0I7SUFBbEIsS0FBSUEsSUFBQSxHQUFKQSxJQUFBO0lBRjdCLEtBQWVtcEIsZUFBQSxHQUFzQjtJQUduQ25wQixJQUFBLENBQUswSCxTQUFBLENBQVVGLFFBQUEsSUFBVztNQUN4QixJQUFJQSxRQUFBLENBQVNzZSxPQUFBLEVBQVM7UUFDcEIsS0FBS3FELGVBQUEsR0FBa0IzaEIsUUFBQSxDQUFTc2UsT0FBQSxDQUFRdmdCLEdBQUEsQ0FBSStlLFVBQUEsSUFDMUNOLG1CQUFBLENBQW9CSyxtQkFBQSxDQUFvQnJrQixJQUFBLENBQUs1SixJQUFBLEVBQU1rdUIsVUFBVSxDQUFDO01BRWpFO0lBQ0gsQ0FBQzs7RUFHSCxPQUFPOEUsVUFBVXBwQixJQUFBLEVBQWtCO0lBQ2pDLE9BQU8sSUFBSWtwQixtQkFBQSxDQUFvQmxwQixJQUFJOztFQUdyQyxNQUFNcXBCLFdBQUEsRUFBVTtJQUNkLE9BQU94QixzQkFBQSxDQUF1QkMsWUFBQSxDQUM1QixNQUFNLEtBQUs5bkIsSUFBQSxDQUFLbFcsVUFBQSxDQUFVLEdBQzFCLEtBQUtrVyxJQUFJOztFQUliLE1BQU1zcEIsT0FDSlgsZUFBQSxFQUNBbmtCLFdBQUEsRUFBMkI7SUFFM0IsTUFBTWpOLFNBQUEsR0FBWW94QixlQUFBO0lBQ2xCLE1BQU1QLE9BQUEsR0FBVyxNQUFNLEtBQUtpQixVQUFBLENBQVU7SUFDdEMsTUFBTUUsbUJBQUEsR0FBc0IsTUFBTTVuQixvQkFBQSxDQUNoQyxLQUFLM0IsSUFBQSxFQUNMekksU0FBQSxDQUFVa3hCLFFBQUEsQ0FBUyxLQUFLem9CLElBQUEsQ0FBSzVKLElBQUEsRUFBTWd5QixPQUFBLEVBQVM1akIsV0FBVyxDQUFDO0lBSTFELE1BQU0sS0FBS3hFLElBQUEsQ0FBSzhILHdCQUFBLENBQXlCeWhCLG1CQUFtQjtJQUk1RCxPQUFPLEtBQUt2cEIsSUFBQSxDQUFLNVUsTUFBQSxDQUFNOztFQUd6QixNQUFNbytCLFNBQVNDLFNBQUEsRUFBbUM7SUFDaEQsTUFBTXZGLGVBQUEsR0FDSixPQUFPdUYsU0FBQSxLQUFjLFdBQVdBLFNBQUEsR0FBWUEsU0FBQSxDQUFVbmxCLEdBQUE7SUFDeEQsTUFBTWQsT0FBQSxHQUFVLE1BQU0sS0FBS3hELElBQUEsQ0FBS2xXLFVBQUEsQ0FBVTtJQUMxQyxJQUFJO01BQ0YsTUFBTWlmLGVBQUEsR0FBa0IsTUFBTXBILG9CQUFBLENBQzVCLEtBQUszQixJQUFBLEVBQ0xpcEIsV0FBQSxDQUFZLEtBQUtqcEIsSUFBQSxDQUFLNUosSUFBQSxFQUFNO1FBQzFCb04sT0FBQTtRQUNBMGdCO01BQ0QsRUFBQztNQUdKLEtBQUtpRixlQUFBLEdBQWtCLEtBQUtBLGVBQUEsQ0FBZ0Jsa0IsTUFBQSxDQUMxQyxDQUFDO1FBQUVYO01BQUcsTUFBT0EsR0FBQSxLQUFRNGYsZUFBZTtNQU10QyxNQUFNLEtBQUtsa0IsSUFBQSxDQUFLOEgsd0JBQUEsQ0FBeUJpQixlQUFlO01BQ3hELE1BQU0sS0FBSy9JLElBQUEsQ0FBSzVVLE1BQUEsQ0FBTTtJQUN2QixTQUFRMFIsQ0FBQSxFQUFQO01BQ0EsTUFBTUEsQ0FBQTtJQUNQOztBQUVKO0FBRUQsSUFBTTRzQixvQkFBQSxHQUF1QixtQkFBSUMsT0FBQSxDQUFPO0FBWWxDLFNBQVVoL0IsWUFBWXFWLElBQUEsRUFBVTtFQUNwQyxNQUFNNHBCLFdBQUEsT0FBY3Y3QixXQUFBLENBQUE2UixrQkFBQSxFQUFtQkYsSUFBSTtFQUMzQyxJQUFJLENBQUMwcEIsb0JBQUEsQ0FBcUJwRyxHQUFBLENBQUlzRyxXQUFXLEdBQUc7SUFDMUNGLG9CQUFBLENBQXFCcmdCLEdBQUEsQ0FDbkJ1Z0IsV0FBQSxFQUNBVixtQkFBQSxDQUFvQkUsU0FBQSxDQUFVUSxXQUEyQixDQUFDO0VBRTdEO0VBQ0QsT0FBT0Ysb0JBQUEsQ0FBcUJ4d0IsR0FBQSxDQUFJMHdCLFdBQVc7QUFDN0M7QUM1Rk8sSUFBTUMscUJBQUEsR0FBd0I7SUNMZkMsdUJBQUEsU0FBdUI7RUFDM0M1eUIsWUFDcUI2eUIsZ0JBQUEsRUFDVnhnQixJQUFBLEVBQXFCO0lBRFgsS0FBZ0J3Z0IsZ0JBQUEsR0FBaEJBLGdCQUFBO0lBQ1YsS0FBSXhnQixJQUFBLEdBQUpBLElBQUE7O0VBR1hFLGFBQUEsRUFBWTtJQUNWLElBQUk7TUFDRixJQUFJLENBQUMsS0FBS0QsT0FBQSxFQUFTO1FBQ2pCLE9BQU94TixPQUFBLENBQVFpUyxPQUFBLENBQVEsS0FBSztNQUM3QjtNQUNELEtBQUt6RSxPQUFBLENBQVF3Z0IsT0FBQSxDQUFRSCxxQkFBQSxFQUF1QixHQUFHO01BQy9DLEtBQUtyZ0IsT0FBQSxDQUFReWdCLFVBQUEsQ0FBV0oscUJBQXFCO01BQzdDLE9BQU83dEIsT0FBQSxDQUFRaVMsT0FBQSxDQUFRLElBQUk7SUFDNUIsU0FBT25XLEVBQUEsRUFBTjtNQUNBLE9BQU9rRSxPQUFBLENBQVFpUyxPQUFBLENBQVEsS0FBSztJQUM3Qjs7RUFHSHZFLEtBQUtyTyxHQUFBLEVBQWFzTyxLQUFBLEVBQXVCO0lBQ3ZDLEtBQUtILE9BQUEsQ0FBUXdnQixPQUFBLENBQVEzdUIsR0FBQSxFQUFLSixJQUFBLENBQUtDLFNBQUEsQ0FBVXlPLEtBQUssQ0FBQztJQUMvQyxPQUFPM04sT0FBQSxDQUFRaVMsT0FBQSxDQUFPOztFQUd4QnJFLEtBQWlDdk8sR0FBQSxFQUFXO0lBQzFDLE1BQU1lLElBQUEsR0FBTyxLQUFLb04sT0FBQSxDQUFRMGdCLE9BQUEsQ0FBUTd1QixHQUFHO0lBQ3JDLE9BQU9XLE9BQUEsQ0FBUWlTLE9BQUEsQ0FBUTdSLElBQUEsR0FBT25CLElBQUEsQ0FBS3NHLEtBQUEsQ0FBTW5GLElBQUksSUFBSSxJQUFJOztFQUd2RHlOLFFBQVF4TyxHQUFBLEVBQVc7SUFDakIsS0FBS21PLE9BQUEsQ0FBUXlnQixVQUFBLENBQVc1dUIsR0FBRztJQUMzQixPQUFPVyxPQUFBLENBQVFpUyxPQUFBLENBQU87O0VBR3hCLElBQWN6RSxRQUFBLEVBQU87SUFDbkIsT0FBTyxLQUFLdWdCLGdCQUFBLENBQWdCOztBQUUvQjtBQzdCRCxTQUFTSSw0QkFBQSxFQUEyQjtFQUNsQyxNQUFNdmUsRUFBQSxPQUFLdmQsV0FBQSxDQUFBbWUsS0FBQSxFQUFLO0VBQ2hCLE9BQU9OLFNBQUEsQ0FBVU4sRUFBRSxLQUFLYyxNQUFBLENBQU9kLEVBQUU7QUFDbkM7QUFHTyxJQUFNd2Usc0JBQUEsR0FBdUI7QUFHcEMsSUFBTUMsNkJBQUEsR0FBZ0M7QUFFdEMsSUFBTUMsdUJBQUEsR0FBTixjQUNVUix1QkFBQSxDQUF1QjtFQUsvQjV5QixZQUFBO0lBQ0UsTUFBTSxNQUFNMlYsTUFBQSxDQUFPMGQsWUFBQSxFQUFZO0lBR2hCLEtBQUE5ZixpQkFBQSxHQUFvQixDQUNuQytmLEtBQUEsRUFDQUMsSUFBQSxLQUNTLEtBQUtDLGNBQUEsQ0FBZUYsS0FBQSxFQUFPQyxJQUFJO0lBQ3pCLEtBQVNFLFNBQUEsR0FBOEM7SUFDdkQsS0FBVUMsVUFBQSxHQUFrQztJQUdyRCxLQUFTQyxTQUFBLEdBQWU7SUFHZixLQUFBQywyQkFBQSxHQUNmWCwyQkFBQSxDQUEyQixLQUFNL2MsU0FBQSxDQUFTO0lBRTNCLEtBQWlCMmQsaUJBQUEsR0FBRzVkLGdCQUFBLENBQWdCO0lBQzVDLEtBQXFCMUIscUJBQUEsR0FBRzs7RUFFekJ1ZixrQkFDTmhXLEVBQUEsRUFBMkU7SUFHM0UsV0FBVzNaLEdBQUEsSUFBTzdFLE1BQUEsQ0FBT3kwQixJQUFBLENBQUssS0FBS04sU0FBUyxHQUFHO01BRTdDLE1BQU1PLFFBQUEsR0FBVyxLQUFLMWhCLE9BQUEsQ0FBUTBnQixPQUFBLENBQVE3dUIsR0FBRztNQUN6QyxNQUFNOHZCLFFBQUEsR0FBVyxLQUFLUCxVQUFBLENBQVd2dkIsR0FBQTtNQUdqQyxJQUFJNnZCLFFBQUEsS0FBYUMsUUFBQSxFQUFVO1FBQ3pCblcsRUFBQSxDQUFHM1osR0FBQSxFQUFLOHZCLFFBQUEsRUFBVUQsUUFBUTtNQUMzQjtJQUNGOztFQUdLUixlQUFlRixLQUFBLEVBQXFCQyxJQUFBLEdBQU8sT0FBSztJQUV0RCxJQUFJLENBQUNELEtBQUEsQ0FBTW52QixHQUFBLEVBQUs7TUFDZCxLQUFLMnZCLGlCQUFBLENBQ0gsQ0FBQ0ksSUFBQSxFQUFhQyxTQUFBLEVBQTBCSCxRQUFBLEtBQTJCO1FBQ2pFLEtBQUtJLGVBQUEsQ0FBZ0JGLElBQUEsRUFBS0YsUUFBUTtNQUNwQyxDQUFDO01BRUg7SUFDRDtJQUVELE1BQU03dkIsR0FBQSxHQUFNbXZCLEtBQUEsQ0FBTW52QixHQUFBO0lBSWxCLElBQUlvdkIsSUFBQSxFQUFNO01BR1IsS0FBS2MsY0FBQSxDQUFjO0lBQ3BCLE9BQU07TUFHTCxLQUFLQyxXQUFBLENBQVc7SUFDakI7SUFJRCxJQUFJLEtBQUtWLDJCQUFBLEVBQTZCO01BRXBDLE1BQU1XLFlBQUEsR0FBYyxLQUFLamlCLE9BQUEsQ0FBUTBnQixPQUFBLENBQVE3dUIsR0FBRztNQUU1QyxJQUFJbXZCLEtBQUEsQ0FBTVUsUUFBQSxLQUFhTyxZQUFBLEVBQWE7UUFDbEMsSUFBSWpCLEtBQUEsQ0FBTVUsUUFBQSxLQUFhLE1BQU07VUFFM0IsS0FBSzFoQixPQUFBLENBQVF3Z0IsT0FBQSxDQUFRM3VCLEdBQUEsRUFBS212QixLQUFBLENBQU1VLFFBQVE7UUFDekMsT0FBTTtVQUVMLEtBQUsxaEIsT0FBQSxDQUFReWdCLFVBQUEsQ0FBVzV1QixHQUFHO1FBQzVCO01BQ0YsV0FBVSxLQUFLdXZCLFVBQUEsQ0FBV3Z2QixHQUFBLE1BQVNtdkIsS0FBQSxDQUFNVSxRQUFBLElBQVksQ0FBQ1QsSUFBQSxFQUFNO1FBRTNEO01BQ0Q7SUFDRjtJQUVELE1BQU1pQixnQkFBQSxHQUFtQkEsQ0FBQSxLQUFXO01BR2xDLE1BQU1ELFlBQUEsR0FBYyxLQUFLamlCLE9BQUEsQ0FBUTBnQixPQUFBLENBQVE3dUIsR0FBRztNQUM1QyxJQUFJLENBQUNvdkIsSUFBQSxJQUFRLEtBQUtHLFVBQUEsQ0FBV3Z2QixHQUFBLE1BQVNvd0IsWUFBQSxFQUFhO1FBR2pEO01BQ0Q7TUFDRCxLQUFLSCxlQUFBLENBQWdCandCLEdBQUEsRUFBS293QixZQUFXO0lBQ3ZDO0lBRUEsTUFBTUUsV0FBQSxHQUFjLEtBQUtuaUIsT0FBQSxDQUFRMGdCLE9BQUEsQ0FBUTd1QixHQUFHO0lBQzVDLElBQ0UwUixPQUFBLENBQU8sS0FDUDRlLFdBQUEsS0FBZ0JuQixLQUFBLENBQU1VLFFBQUEsSUFDdEJWLEtBQUEsQ0FBTVUsUUFBQSxLQUFhVixLQUFBLENBQU1XLFFBQUEsRUFDekI7TUFLQXZ0QixVQUFBLENBQVc4dEIsZ0JBQUEsRUFBa0JyQiw2QkFBNkI7SUFDM0QsT0FBTTtNQUNMcUIsZ0JBQUEsQ0FBZ0I7SUFDakI7O0VBR0tKLGdCQUFnQmp3QixHQUFBLEVBQWFzTyxLQUFBLEVBQW9CO0lBQ3ZELEtBQUtpaEIsVUFBQSxDQUFXdnZCLEdBQUEsSUFBT3NPLEtBQUE7SUFDdkIsTUFBTWdoQixTQUFBLEdBQVksS0FBS0EsU0FBQSxDQUFVdHZCLEdBQUE7SUFDakMsSUFBSXN2QixTQUFBLEVBQVc7TUFDYixXQUFXaUIsUUFBQSxJQUFZaGpCLEtBQUEsQ0FBTWlqQixJQUFBLENBQUtsQixTQUFTLEdBQUc7UUFDNUNpQixRQUFBLENBQVNqaUIsS0FBQSxHQUFRMU8sSUFBQSxDQUFLc0csS0FBQSxDQUFNb0ksS0FBSyxJQUFJQSxLQUFLO01BQzNDO0lBQ0Y7O0VBR0ttaUIsYUFBQSxFQUFZO0lBQ2xCLEtBQUtOLFdBQUEsQ0FBVztJQUVoQixLQUFLWCxTQUFBLEdBQVlrQixXQUFBLENBQVksTUFBSztNQUNoQyxLQUFLZixpQkFBQSxDQUNILENBQUMzdkIsR0FBQSxFQUFhOHZCLFFBQUEsRUFBeUJELFFBQUEsS0FBMkI7UUFDaEUsS0FBS1IsY0FBQSxDQUNILElBQUlzQixZQUFBLENBQWEsV0FBVztVQUMxQjN3QixHQUFBO1VBQ0E4dkIsUUFBQTtVQUNBRDtTQUNELEdBQ1UsSUFBSTtNQUVuQixDQUFDO09BRUZkLHNCQUFvQjs7RUFHakJvQixZQUFBLEVBQVc7SUFDakIsSUFBSSxLQUFLWCxTQUFBLEVBQVc7TUFDbEJvQixhQUFBLENBQWMsS0FBS3BCLFNBQVM7TUFDNUIsS0FBS0EsU0FBQSxHQUFZO0lBQ2xCOztFQUdLcUIsZUFBQSxFQUFjO0lBQ3BCcmYsTUFBQSxDQUFPNE8sZ0JBQUEsQ0FBaUIsV0FBVyxLQUFLaFIsaUJBQWlCOztFQUduRDhnQixlQUFBLEVBQWM7SUFDcEIxZSxNQUFBLENBQU9zZixtQkFBQSxDQUFvQixXQUFXLEtBQUsxaEIsaUJBQWlCOztFQUc5RFgsYUFBYXpPLEdBQUEsRUFBYXV3QixRQUFBLEVBQThCO0lBQ3RELElBQUlwMUIsTUFBQSxDQUFPeTBCLElBQUEsQ0FBSyxLQUFLTixTQUFTLEVBQUU3ckIsTUFBQSxLQUFXLEdBQUc7TUFLNUMsSUFBSSxLQUFLaXNCLGlCQUFBLEVBQW1CO1FBQzFCLEtBQUtlLFlBQUEsQ0FBWTtNQUNsQixPQUFNO1FBQ0wsS0FBS0ksY0FBQSxDQUFjO01BQ3BCO0lBQ0Y7SUFDRCxJQUFJLENBQUMsS0FBS3ZCLFNBQUEsQ0FBVXR2QixHQUFBLEdBQU07TUFDeEIsS0FBS3N2QixTQUFBLENBQVV0dkIsR0FBQSxJQUFPLG1CQUFJMm5CLEdBQUEsQ0FBRztNQUU3QixLQUFLNEgsVUFBQSxDQUFXdnZCLEdBQUEsSUFBTyxLQUFLbU8sT0FBQSxDQUFRMGdCLE9BQUEsQ0FBUTd1QixHQUFHO0lBQ2hEO0lBQ0QsS0FBS3N2QixTQUFBLENBQVV0dkIsR0FBQSxFQUFLaWdCLEdBQUEsQ0FBSXNRLFFBQVE7O0VBR2xDM2hCLGdCQUFnQjVPLEdBQUEsRUFBYXV3QixRQUFBLEVBQThCO0lBQ3pELElBQUksS0FBS2pCLFNBQUEsQ0FBVXR2QixHQUFBLEdBQU07TUFDdkIsS0FBS3N2QixTQUFBLENBQVV0dkIsR0FBQSxFQUFLNE0sTUFBQSxDQUFPMmpCLFFBQVE7TUFFbkMsSUFBSSxLQUFLakIsU0FBQSxDQUFVdHZCLEdBQUEsRUFBSyt3QixJQUFBLEtBQVMsR0FBRztRQUNsQyxPQUFPLEtBQUt6QixTQUFBLENBQVV0dkIsR0FBQTtNQUN2QjtJQUNGO0lBRUQsSUFBSTdFLE1BQUEsQ0FBT3kwQixJQUFBLENBQUssS0FBS04sU0FBUyxFQUFFN3JCLE1BQUEsS0FBVyxHQUFHO01BQzVDLEtBQUt5c0IsY0FBQSxDQUFjO01BQ25CLEtBQUtDLFdBQUEsQ0FBVztJQUNqQjs7RUFLSCxNQUFNOWhCLEtBQUtyTyxHQUFBLEVBQWFzTyxLQUFBLEVBQXVCO0lBQzdDLE1BQU0sTUFBTUQsSUFBQSxDQUFLck8sR0FBQSxFQUFLc08sS0FBSztJQUMzQixLQUFLaWhCLFVBQUEsQ0FBV3Z2QixHQUFBLElBQU9KLElBQUEsQ0FBS0MsU0FBQSxDQUFVeU8sS0FBSzs7RUFHN0MsTUFBTUMsS0FBaUN2TyxHQUFBLEVBQVc7SUFDaEQsTUFBTXNPLEtBQUEsR0FBUSxNQUFNLE1BQU1DLElBQUEsQ0FBUXZPLEdBQUc7SUFDckMsS0FBS3V2QixVQUFBLENBQVd2dkIsR0FBQSxJQUFPSixJQUFBLENBQUtDLFNBQUEsQ0FBVXlPLEtBQUs7SUFDM0MsT0FBT0EsS0FBQTs7RUFHVCxNQUFNRSxRQUFReE8sR0FBQSxFQUFXO0lBQ3ZCLE1BQU0sTUFBTXdPLE9BQUEsQ0FBUXhPLEdBQUc7SUFDdkIsT0FBTyxLQUFLdXZCLFVBQUEsQ0FBV3Z2QixHQUFBOzs7QUE5TWxCaXZCLHVCQUFBLENBQUkvZ0IsSUFBQSxHQUFZO0FBd05sQixJQUFNcmdCLHVCQUFBLEdBQXVDb2hDLHVCQUFBO0FDaFBwRCxJQUFNK0IseUJBQUEsR0FBTixjQUNVdkMsdUJBQUEsQ0FBdUI7RUFLL0I1eUIsWUFBQTtJQUNFLE1BQU0sTUFBTTJWLE1BQUEsQ0FBT3lmLGNBQUEsRUFBYzs7RUFHbkN4aUIsYUFBYUMsSUFBQSxFQUFjQyxTQUFBLEVBQStCO0lBRXhEOztFQUdGQyxnQkFBZ0JGLElBQUEsRUFBY0MsU0FBQSxFQUErQjtJQUUzRDs7O0FBYktxaUIseUJBQUEsQ0FBSTlpQixJQUFBLEdBQWM7QUF1QnBCLElBQU1uZ0IseUJBQUEsR0FBeUNpakMseUJBQUE7QUNmaEQsU0FBVUUsWUFDZEMsUUFBQSxFQUEyQjtFQUUzQixPQUFPeHdCLE9BQUEsQ0FBUW9QLEdBQUEsQ0FDYm9oQixRQUFBLENBQVNqbkIsR0FBQSxDQUFJLE1BQU1ySixPQUFBLElBQVU7SUFDM0IsSUFBSTtNQUNGLE1BQU15TixLQUFBLEdBQVEsTUFBTXpOLE9BQUE7TUFDcEIsT0FBTztRQUNMdXdCLFNBQUEsRUFBVztRQUNYOWlCOztJQUVILFNBQVEraUIsTUFBQSxFQUFQO01BQ0EsT0FBTztRQUNMRCxTQUFBLEVBQVc7UUFDWEM7O0lBRUg7R0FDRixDQUFDO0FBRU47SUMxQmFDLFFBQUEsU0FBUTtFQVVuQnoxQixZQUE2QjAxQixXQUFBLEVBQXdCO0lBQXhCLEtBQVdBLFdBQUEsR0FBWEEsV0FBQTtJQU5aLEtBQVdDLFdBQUEsR0FJeEI7SUFHRixLQUFLcGlCLGlCQUFBLEdBQW9CLEtBQUtxaUIsV0FBQSxDQUFZbmlCLElBQUEsQ0FBSyxJQUFJOztFQVNyRCxPQUFPekIsYUFBYTBqQixXQUFBLEVBQXdCO0lBSTFDLE1BQU1HLGdCQUFBLEdBQW1CLEtBQUtDLFNBQUEsQ0FBVW5HLElBQUEsQ0FBS29HLFFBQUEsSUFDM0NBLFFBQUEsQ0FBU0MsYUFBQSxDQUFjTixXQUFXLENBQUM7SUFFckMsSUFBSUcsZ0JBQUEsRUFBa0I7TUFDcEIsT0FBT0EsZ0JBQUE7SUFDUjtJQUNELE1BQU1JLFdBQUEsR0FBYyxJQUFJUixRQUFBLENBQVNDLFdBQVc7SUFDNUMsS0FBS0ksU0FBQSxDQUFVN2UsSUFBQSxDQUFLZ2YsV0FBVztJQUMvQixPQUFPQSxXQUFBOztFQUdERCxjQUFjTixXQUFBLEVBQXdCO0lBQzVDLE9BQU8sS0FBS0EsV0FBQSxLQUFnQkEsV0FBQTs7RUFhdEIsTUFBTUUsWUFHWnRDLEtBQUEsRUFBWTtJQUNaLE1BQU00QyxZQUFBLEdBQWU1QyxLQUFBO0lBQ3JCLE1BQU07TUFBRTZDLE9BQUE7TUFBU0MsU0FBQTtNQUFXdEg7SUFBSSxJQUFLb0gsWUFBQSxDQUFhcEgsSUFBQTtJQUVsRCxNQUFNdUgsUUFBQSxHQUNKLEtBQUtWLFdBQUEsQ0FBWVMsU0FBQTtJQUNuQixJQUFJLEVBQUNDLFFBQUEsYUFBQUEsUUFBQSxLQUFRLGtCQUFSQSxRQUFBLENBQVVuQixJQUFBLEdBQU07TUFDbkI7SUFDRDtJQUVEZ0IsWUFBQSxDQUFhSSxLQUFBLENBQU0sR0FBR0MsV0FBQSxDQUFZO01BQ2hDN2QsTUFBQSxFQUFtQjtNQUNuQnlkLE9BQUE7TUFDQUM7SUFDRDtJQUVELE1BQU1kLFFBQUEsR0FBVzVqQixLQUFBLENBQU1pakIsSUFBQSxDQUFLMEIsUUFBUSxFQUFFaG9CLEdBQUEsQ0FBSSxNQUFNbW9CLE9BQUEsSUFDOUNBLE9BQUEsQ0FBUU4sWUFBQSxDQUFhTyxNQUFBLEVBQVEzSCxJQUFJLENBQUM7SUFFcEMsTUFBTTVyQixRQUFBLEdBQVcsTUFBTW15QixXQUFBLENBQVlDLFFBQVE7SUFDM0NZLFlBQUEsQ0FBYUksS0FBQSxDQUFNLEdBQUdDLFdBQUEsQ0FBWTtNQUNoQzdkLE1BQUEsRUFBb0I7TUFDcEJ5ZCxPQUFBO01BQ0FDLFNBQUE7TUFDQWx6QjtJQUNEOztFQVVId3pCLFdBQ0VOLFNBQUEsRUFDQU8sWUFBQSxFQUFtQztJQUVuQyxJQUFJcjNCLE1BQUEsQ0FBT3kwQixJQUFBLENBQUssS0FBSzRCLFdBQVcsRUFBRS90QixNQUFBLEtBQVcsR0FBRztNQUM5QyxLQUFLOHRCLFdBQUEsQ0FBWW5SLGdCQUFBLENBQWlCLFdBQVcsS0FBS2hSLGlCQUFpQjtJQUNwRTtJQUVELElBQUksQ0FBQyxLQUFLb2lCLFdBQUEsQ0FBWVMsU0FBQSxHQUFZO01BQ2hDLEtBQUtULFdBQUEsQ0FBWVMsU0FBQSxJQUFhLG1CQUFJdEssR0FBQSxDQUFHO0lBQ3RDO0lBRUQsS0FBSzZKLFdBQUEsQ0FBWVMsU0FBQSxFQUFXaFMsR0FBQSxDQUFJdVMsWUFBWTs7RUFVOUNDLGFBQ0VSLFNBQUEsRUFDQU8sWUFBQSxFQUFvQztJQUVwQyxJQUFJLEtBQUtoQixXQUFBLENBQVlTLFNBQUEsS0FBY08sWUFBQSxFQUFjO01BQy9DLEtBQUtoQixXQUFBLENBQVlTLFNBQUEsRUFBV3JsQixNQUFBLENBQU80bEIsWUFBWTtJQUNoRDtJQUNELElBQUksQ0FBQ0EsWUFBQSxJQUFnQixLQUFLaEIsV0FBQSxDQUFZUyxTQUFBLEVBQVdsQixJQUFBLEtBQVMsR0FBRztNQUMzRCxPQUFPLEtBQUtTLFdBQUEsQ0FBWVMsU0FBQTtJQUN6QjtJQUVELElBQUk5MkIsTUFBQSxDQUFPeTBCLElBQUEsQ0FBSyxLQUFLNEIsV0FBVyxFQUFFL3RCLE1BQUEsS0FBVyxHQUFHO01BQzlDLEtBQUs4dEIsV0FBQSxDQUFZVCxtQkFBQSxDQUFvQixXQUFXLEtBQUsxaEIsaUJBQWlCO0lBQ3ZFOzs7QUF6SHFCa2lCLFFBQUEsQ0FBU0ssU0FBQSxHQUFlO0FDZjVDLFNBQVVlLGlCQUFpQi9XLE1BQUEsR0FBUyxJQUFJZ1gsTUFBQSxHQUFTLElBQUU7RUFDdkQsSUFBSTlXLE1BQUEsR0FBUztFQUNiLFNBQVM3RyxDQUFBLEdBQUksR0FBR0EsQ0FBQSxHQUFJMmQsTUFBQSxFQUFRM2QsQ0FBQSxJQUFLO0lBQy9CNkcsTUFBQSxJQUFVL2QsSUFBQSxDQUFLOGQsS0FBQSxDQUFNOWQsSUFBQSxDQUFLK2QsTUFBQSxDQUFNLElBQUssRUFBRTtFQUN4QztFQUNELE9BQU9GLE1BQUEsR0FBU0UsTUFBQTtBQUNsQjtJQ2dCYStXLE1BQUEsU0FBTTtFQUdqQi8yQixZQUE2QmczQixNQUFBLEVBQXFCO0lBQXJCLEtBQU1BLE1BQUEsR0FBTkEsTUFBQTtJQUZaLEtBQUFYLFFBQUEsR0FBVyxtQkFBSXZLLEdBQUEsQ0FBRzs7RUFTM0JtTCxxQkFBcUJULE9BQUEsRUFBdUI7SUFDbEQsSUFBSUEsT0FBQSxDQUFRVSxjQUFBLEVBQWdCO01BQzFCVixPQUFBLENBQVFVLGNBQUEsQ0FBZUMsS0FBQSxDQUFNbEMsbUJBQUEsQ0FDM0IsV0FDQXVCLE9BQUEsQ0FBUVksU0FBUztNQUVuQlosT0FBQSxDQUFRVSxjQUFBLENBQWVDLEtBQUEsQ0FBTUUsS0FBQSxDQUFLO0lBQ25DO0lBQ0QsS0FBS2hCLFFBQUEsQ0FBU3RsQixNQUFBLENBQU95bEIsT0FBTzs7RUFnQjlCLE1BQU1jLE1BQ0psQixTQUFBLEVBQ0F0SCxJQUFBLEVBQ0F5SSxPQUFBLEdBQThCO0lBRTlCLE1BQU1MLGNBQUEsR0FDSixPQUFPTSxjQUFBLEtBQW1CLGNBQWMsSUFBSUEsY0FBQSxDQUFjLElBQUs7SUFDakUsSUFBSSxDQUFDTixjQUFBLEVBQWdCO01BQ25CLE1BQU0sSUFBSTEyQixLQUFBLENBQUs7SUFDaEI7SUFLRCxJQUFJaTNCLGVBQUE7SUFDSixJQUFJakIsT0FBQTtJQUNKLE9BQU8sSUFBSTF4QixPQUFBLENBQXFDLENBQUNpUyxPQUFBLEVBQVN0USxNQUFBLEtBQVU7TUFDbEUsTUFBTTB2QixPQUFBLEdBQVVVLGdCQUFBLENBQWlCLElBQUksRUFBRTtNQUN2Q0ssY0FBQSxDQUFlQyxLQUFBLENBQU1PLEtBQUEsQ0FBSztNQUMxQixNQUFNQyxRQUFBLEdBQVdqeEIsVUFBQSxDQUFXLE1BQUs7UUFDL0JELE1BQUEsQ0FBTyxJQUFJakcsS0FBQSxDQUFLLG9CQUFpQztTQUNoRCsyQixPQUFPO01BQ1ZmLE9BQUEsR0FBVTtRQUNSVSxjQUFBO1FBQ0FFLFVBQVU5RCxLQUFBLEVBQVk7VUFDcEIsTUFBTTRDLFlBQUEsR0FBZTVDLEtBQUE7VUFDckIsSUFBSTRDLFlBQUEsQ0FBYXBILElBQUEsQ0FBS3FILE9BQUEsS0FBWUEsT0FBQSxFQUFTO1lBQ3pDO1VBQ0Q7VUFDRCxRQUFRRCxZQUFBLENBQWFwSCxJQUFBLENBQUtwVyxNQUFBO2lCQUN4QjtjQUVFL1IsWUFBQSxDQUFhZ3hCLFFBQVE7Y0FDckJGLGVBQUEsR0FBa0Ivd0IsVUFBQSxDQUFXLE1BQUs7Z0JBQ2hDRCxNQUFBLENBQU8sSUFBSWpHLEtBQUEsQ0FBSyxVQUF1QjtjQUN6QyxHQUFDO2NBQ0Q7aUJBQ0Y7Y0FFRW1HLFlBQUEsQ0FBYTh3QixlQUFlO2NBQzVCMWdCLE9BQUEsQ0FBUW1mLFlBQUEsQ0FBYXBILElBQUEsQ0FBSzVyQixRQUFRO2NBQ2xDOztjQUVBeUQsWUFBQSxDQUFhZ3hCLFFBQVE7Y0FDckJoeEIsWUFBQSxDQUFhOHdCLGVBQWU7Y0FDNUJoeEIsTUFBQSxDQUFPLElBQUlqRyxLQUFBLENBQUssbUJBQWdDO2NBQ2hEOzs7O01BSVIsS0FBSzYxQixRQUFBLENBQVNqUyxHQUFBLENBQUlvUyxPQUFPO01BQ3pCVSxjQUFBLENBQWVDLEtBQUEsQ0FBTTVTLGdCQUFBLENBQWlCLFdBQVdpUyxPQUFBLENBQVFZLFNBQVM7TUFDbEUsS0FBS0osTUFBQSxDQUFPVCxXQUFBLENBQ1Y7UUFDRUgsU0FBQTtRQUNBRCxPQUFBO1FBQ0FySDtNQUN3QixHQUMxQixDQUFDb0ksY0FBQSxDQUFlVSxLQUFLLENBQUM7SUFFMUIsQ0FBQyxFQUFFQyxPQUFBLENBQVEsTUFBSztNQUNkLElBQUlyQixPQUFBLEVBQVM7UUFDWCxLQUFLUyxvQkFBQSxDQUFxQlQsT0FBTztNQUNsQztJQUNILENBQUM7O0FBRUo7U0NoR2VzQixRQUFBLEVBQU87RUFDckIsT0FBT25pQixNQUFBO0FBQ1Q7QUFFTSxTQUFVb2lCLG1CQUFtQngxQixHQUFBLEVBQVc7RUFDNUN1MUIsT0FBQSxDQUFPLEVBQUdqM0IsUUFBQSxDQUFTQyxJQUFBLEdBQU95QixHQUFBO0FBQzVCO1NDOUJnQnkxQixVQUFBLEVBQVM7RUFDdkIsT0FDRSxPQUFPRixPQUFBLENBQU8sRUFBRyx5QkFBeUIsZUFDMUMsT0FBT0EsT0FBQSxDQUFPLEVBQUcscUJBQXFCO0FBRTFDO0FBRU8sZUFBZUcsd0JBQUEsRUFBdUI7RUFDM0MsSUFBSSxFQUFDOTJCLFNBQUEsYUFBQUEsU0FBQSxLQUFTLGtCQUFUQSxTQUFBLENBQVcrMkIsYUFBQSxHQUFlO0lBQzdCLE9BQU87RUFDUjtFQUNELElBQUk7SUFDRixNQUFNQyxZQUFBLEdBQWUsTUFBTWgzQixTQUFBLENBQVUrMkIsYUFBQSxDQUFjdFgsS0FBQTtJQUNuRCxPQUFPdVgsWUFBQSxDQUFhQyxNQUFBO0VBQ3JCLFNBQU94M0IsRUFBQSxFQUFOO0lBQ0EsT0FBTztFQUNSO0FBQ0g7U0FFZ0J5M0IsNEJBQUEsRUFBMkI7O0VBQ3pDLFNBQU96M0IsRUFBQSxHQUFBTyxTQUFBLEtBQVMsUUFBVEEsU0FBQSxLQUFTLGtCQUFUQSxTQUFBLENBQVcrMkIsYUFBQSxNQUFhLFFBQUF0M0IsRUFBQSx1QkFBQUEsRUFBQSxDQUFFMDNCLFVBQUEsS0FBYztBQUNqRDtTQUVnQkMsc0JBQUEsRUFBcUI7RUFDbkMsT0FBT1AsU0FBQSxDQUFTLElBQU1yM0IsSUFBQSxHQUFvQztBQUM1RDtBQ0RPLElBQU02M0IsT0FBQSxHQUFVO0FBQ3ZCLElBQU1DLFVBQUEsR0FBYTtBQUNuQixJQUFNQyxtQkFBQSxHQUFzQjtBQUM1QixJQUFNQyxlQUFBLEdBQWtCO0FBYXhCLElBQU1DLFNBQUEsR0FBTixNQUFlO0VBQ2I1NEIsWUFBNkJ1RCxPQUFBLEVBQW1CO0lBQW5CLEtBQU9BLE9BQUEsR0FBUEEsT0FBQTs7RUFFN0JzMUIsVUFBQSxFQUFTO0lBQ1AsT0FBTyxJQUFJL3pCLE9BQUEsQ0FBVyxDQUFDaVMsT0FBQSxFQUFTdFEsTUFBQSxLQUFVO01BQ3hDLEtBQUtsRCxPQUFBLENBQVFnaEIsZ0JBQUEsQ0FBaUIsV0FBVyxNQUFLO1FBQzVDeE4sT0FBQSxDQUFRLEtBQUt4VCxPQUFBLENBQVF5VCxNQUFNO01BQzdCLENBQUM7TUFDRCxLQUFLelQsT0FBQSxDQUFRZ2hCLGdCQUFBLENBQWlCLFNBQVMsTUFBSztRQUMxQzlkLE1BQUEsQ0FBTyxLQUFLbEQsT0FBQSxDQUFRNUUsS0FBSztNQUMzQixDQUFDO0lBQ0gsQ0FBQzs7QUFFSjtBQUVELFNBQVNtNkIsZUFBZUMsRUFBQSxFQUFpQkMsV0FBQSxFQUFvQjtFQUMzRCxPQUFPRCxFQUFBLENBQ0pFLFdBQUEsQ0FBWSxDQUFDUCxtQkFBbUIsR0FBR00sV0FBQSxHQUFjLGNBQWMsVUFBVSxFQUN6RUUsV0FBQSxDQUFZUixtQkFBbUI7QUFDcEM7U0FPZ0JTLGdCQUFBLEVBQWU7RUFDN0IsTUFBTTUxQixPQUFBLEdBQVU2MUIsU0FBQSxDQUFVQyxjQUFBLENBQWViLE9BQU87RUFDaEQsT0FBTyxJQUFJSSxTQUFBLENBQWdCcjFCLE9BQU8sRUFBRXMxQixTQUFBLENBQVM7QUFDL0M7U0FFZ0JTLGNBQUEsRUFBYTtFQUMzQixNQUFNLzFCLE9BQUEsR0FBVTYxQixTQUFBLENBQVVHLElBQUEsQ0FBS2YsT0FBQSxFQUFTQyxVQUFVO0VBQ2xELE9BQU8sSUFBSTN6QixPQUFBLENBQVEsQ0FBQ2lTLE9BQUEsRUFBU3RRLE1BQUEsS0FBVTtJQUNyQ2xELE9BQUEsQ0FBUWdoQixnQkFBQSxDQUFpQixTQUFTLE1BQUs7TUFDckM5ZCxNQUFBLENBQU9sRCxPQUFBLENBQVE1RSxLQUFLO0lBQ3RCLENBQUM7SUFFRDRFLE9BQUEsQ0FBUWdoQixnQkFBQSxDQUFpQixpQkFBaUIsTUFBSztNQUM3QyxNQUFNd1UsRUFBQSxHQUFLeDFCLE9BQUEsQ0FBUXlULE1BQUE7TUFFbkIsSUFBSTtRQUNGK2hCLEVBQUEsQ0FBR1MsaUJBQUEsQ0FBa0JkLG1CQUFBLEVBQXFCO1VBQUVlLE9BQUEsRUFBU2Q7UUFBZSxDQUFFO01BQ3ZFLFNBQVEveUIsQ0FBQSxFQUFQO1FBQ0FhLE1BQUEsQ0FBT2IsQ0FBQztNQUNUO0lBQ0gsQ0FBQztJQUVEckMsT0FBQSxDQUFRZ2hCLGdCQUFBLENBQWlCLFdBQVcsWUFBVztNQUM3QyxNQUFNd1UsRUFBQSxHQUFrQngxQixPQUFBLENBQVF5VCxNQUFBO01BTWhDLElBQUksQ0FBQytoQixFQUFBLENBQUdXLGdCQUFBLENBQWlCQyxRQUFBLENBQVNqQixtQkFBbUIsR0FBRztRQUV0REssRUFBQSxDQUFHMUIsS0FBQSxDQUFLO1FBQ1IsTUFBTThCLGVBQUEsQ0FBZTtRQUNyQnBpQixPQUFBLENBQVEsTUFBTXVpQixhQUFBLENBQWEsQ0FBRTtNQUM5QixPQUFNO1FBQ0x2aUIsT0FBQSxDQUFRZ2lCLEVBQUU7TUFDWDtJQUNILENBQUM7RUFDSCxDQUFDO0FBQ0g7QUFFTyxlQUFlYSxXQUNwQmIsRUFBQSxFQUNBNTBCLEdBQUEsRUFDQXNPLEtBQUEsRUFBZ0M7RUFFaEMsTUFBTWxQLE9BQUEsR0FBVXUxQixjQUFBLENBQWVDLEVBQUEsRUFBSSxJQUFJLEVBQUVjLEdBQUEsQ0FBSTtJQUMzQyxDQUFDbEIsZUFBQSxHQUFrQngwQixHQUFBO0lBQ25Cc087RUFDRDtFQUNELE9BQU8sSUFBSW1tQixTQUFBLENBQWdCcjFCLE9BQU8sRUFBRXMxQixTQUFBLENBQVM7QUFDL0M7QUFFQSxlQUFlaUIsVUFDYmYsRUFBQSxFQUNBNTBCLEdBQUEsRUFBVztFQUVYLE1BQU1aLE9BQUEsR0FBVXUxQixjQUFBLENBQWVDLEVBQUEsRUFBSSxLQUFLLEVBQUUvMkIsR0FBQSxDQUFJbUMsR0FBRztFQUNqRCxNQUFNMnFCLElBQUEsR0FBTyxNQUFNLElBQUk4SixTQUFBLENBQWdDcjFCLE9BQU8sRUFBRXMxQixTQUFBLENBQVM7RUFDekUsT0FBTy9KLElBQUEsS0FBUyxTQUFZLE9BQU9BLElBQUEsQ0FBS3JjLEtBQUE7QUFDMUM7QUFFZ0IsU0FBQXNuQixjQUFjaEIsRUFBQSxFQUFpQjUwQixHQUFBLEVBQVc7RUFDeEQsTUFBTVosT0FBQSxHQUFVdTFCLGNBQUEsQ0FBZUMsRUFBQSxFQUFJLElBQUksRUFBRWhvQixNQUFBLENBQU81TSxHQUFHO0VBQ25ELE9BQU8sSUFBSXkwQixTQUFBLENBQWdCcjFCLE9BQU8sRUFBRXMxQixTQUFBLENBQVM7QUFDL0M7QUFFTyxJQUFNbUIsb0JBQUEsR0FBdUI7QUFDN0IsSUFBTUMsd0JBQUEsR0FBMkI7QUFFeEMsSUFBTUMseUJBQUEsR0FBTixNQUErQjtFQXFCN0JsNkIsWUFBQTtJQWxCQSxLQUFBcVMsSUFBQSxHQUE2QjtJQUVwQixLQUFxQmtDLHFCQUFBLEdBQUc7SUFFaEIsS0FBU2tmLFNBQUEsR0FBOEM7SUFDdkQsS0FBVUMsVUFBQSxHQUE0QztJQUcvRCxLQUFTQyxTQUFBLEdBQWU7SUFDeEIsS0FBYXdHLGFBQUEsR0FBRztJQUVoQixLQUFRcEUsUUFBQSxHQUFvQjtJQUM1QixLQUFNcUUsTUFBQSxHQUFrQjtJQUN4QixLQUE4QkMsOEJBQUEsR0FBRztJQUNqQyxLQUFtQkMsbUJBQUEsR0FBeUI7SUFNbEQsS0FBS0MsNEJBQUEsR0FDSCxLQUFLQyxnQ0FBQSxDQUFnQyxFQUFHeGMsSUFBQSxDQUN0QyxNQUFPLElBQ1AsTUFBTyxFQUFDOztFQUlkLE1BQU15YyxRQUFBLEVBQU87SUFDWCxJQUFJLEtBQUsxQixFQUFBLEVBQUk7TUFDWCxPQUFPLEtBQUtBLEVBQUE7SUFDYjtJQUNELEtBQUtBLEVBQUEsR0FBSyxNQUFNTyxhQUFBLENBQWE7SUFDN0IsT0FBTyxLQUFLUCxFQUFBOztFQUdkLE1BQU0yQixhQUFnQkMsRUFBQSxFQUFtQztJQUN2RCxJQUFJQyxXQUFBLEdBQWM7SUFFbEIsT0FBTyxNQUFNO01BQ1gsSUFBSTtRQUNGLE1BQU03QixFQUFBLEdBQUssTUFBTSxLQUFLMEIsT0FBQSxDQUFPO1FBQzdCLE9BQU8sTUFBTUUsRUFBQSxDQUFHNUIsRUFBRTtNQUNuQixTQUFRbnpCLENBQUEsRUFBUDtRQUNBLElBQUlnMUIsV0FBQSxLQUFnQlgsd0JBQUEsRUFBMEI7VUFDNUMsTUFBTXIwQixDQUFBO1FBQ1A7UUFDRCxJQUFJLEtBQUttekIsRUFBQSxFQUFJO1VBQ1gsS0FBS0EsRUFBQSxDQUFHMUIsS0FBQSxDQUFLO1VBQ2IsS0FBSzBCLEVBQUEsR0FBSztRQUNYO01BRUY7SUFDRjs7RUFPSyxNQUFNeUIsaUNBQUEsRUFBZ0M7SUFDNUMsT0FBT3hDLFNBQUEsQ0FBUyxJQUFLLEtBQUs2QyxrQkFBQSxDQUFrQixJQUFLLEtBQUtDLGdCQUFBLENBQWdCOztFQU1oRSxNQUFNRCxtQkFBQSxFQUFrQjtJQUM5QixLQUFLOUUsUUFBQSxHQUFXTixRQUFBLENBQVN6akIsWUFBQSxDQUFhdW1CLHFCQUFBLENBQXFCLENBQUc7SUFFOUQsS0FBS3hDLFFBQUEsQ0FBU1csVUFBQSxDQUFVLGNBRXRCLE9BQU9xRSxPQUFBLEVBQWlCak0sSUFBQSxLQUEyQjtNQUNqRCxNQUFNaUYsSUFBQSxHQUFPLE1BQU0sS0FBS2lILEtBQUEsQ0FBSztNQUM3QixPQUFPO1FBQ0xDLFlBQUEsRUFBY2xILElBQUEsQ0FBS3BmLFFBQUEsQ0FBU21hLElBQUEsQ0FBSzNxQixHQUFHOztJQUV4QyxDQUFDO0lBR0gsS0FBSzR4QixRQUFBLENBQVNXLFVBQUEsQ0FBVSxRQUV0QixPQUFPcUUsT0FBQSxFQUFpQkcsS0FBQSxLQUFzQjtNQUM1QyxPQUFPO0lBQ1QsQ0FBQzs7RUFXRyxNQUFNSixpQkFBQSxFQUFnQjs7SUFFNUIsS0FBS1IsbUJBQUEsR0FBc0IsTUFBTXJDLHVCQUFBLENBQXVCO0lBQ3hELElBQUksQ0FBQyxLQUFLcUMsbUJBQUEsRUFBcUI7TUFDN0I7SUFDRDtJQUNELEtBQUtGLE1BQUEsR0FBUyxJQUFJckQsTUFBQSxDQUFPLEtBQUt1RCxtQkFBbUI7SUFFakQsTUFBTWEsT0FBQSxHQUFVLE1BQU0sS0FBS2YsTUFBQSxDQUFPOUMsS0FBQSxDQUFLLFFBRXJDLElBQUU7SUFHSixJQUFJLENBQUM2RCxPQUFBLEVBQVM7TUFDWjtJQUNEO0lBQ0QsTUFDRXY2QixFQUFBLEdBQUF1NkIsT0FBQSxDQUFRLFFBQUUsUUFBQXY2QixFQUFBLHVCQUFBQSxFQUFBLENBQUUyMEIsU0FBQSxPQUNacmtCLEVBQUEsR0FBQWlxQixPQUFBLENBQVEsUUFBRSxRQUFBanFCLEVBQUEsdUJBQUFBLEVBQUEsQ0FBRXVCLEtBQUEsQ0FBTWtDLFFBQUEsQ0FBZ0MsZ0JBQ2xEO01BQ0EsS0FBSzBsQiw4QkFBQSxHQUFpQztJQUN2Qzs7RUFZSyxNQUFNZSxvQkFBb0JqM0IsR0FBQSxFQUFXO0lBQzNDLElBQ0UsQ0FBQyxLQUFLaTJCLE1BQUEsSUFDTixDQUFDLEtBQUtFLG1CQUFBLElBQ05qQywyQkFBQSxDQUEyQixNQUFPLEtBQUtpQyxtQkFBQSxFQUN2QztNQUNBO0lBQ0Q7SUFDRCxJQUFJO01BQ0YsTUFBTSxLQUFLRixNQUFBLENBQU85QyxLQUFBLENBRWhCO1FBQUVuekI7TUFBRyxHQUVMLEtBQUtrMkIsOEJBQUEsR0FDRixNQUNBO0lBRU4sU0FBT3o1QixFQUFBLEVBQU4sQ0FFRDs7RUFHSCxNQUFNMlIsYUFBQSxFQUFZO0lBQ2hCLElBQUk7TUFDRixJQUFJLENBQUM2bUIsU0FBQSxFQUFXO1FBQ2QsT0FBTztNQUNSO01BQ0QsTUFBTUwsRUFBQSxHQUFLLE1BQU1PLGFBQUEsQ0FBYTtNQUM5QixNQUFNTSxVQUFBLENBQVdiLEVBQUEsRUFBSXBHLHFCQUFBLEVBQXVCLEdBQUc7TUFDL0MsTUFBTW9ILGFBQUEsQ0FBY2hCLEVBQUEsRUFBSXBHLHFCQUFxQjtNQUM3QyxPQUFPO0lBQ1IsU0FBQy94QixFQUFBLEdBQU07SUFDUixPQUFPOztFQUdELE1BQU15NkIsa0JBQWtCQyxLQUFBLEVBQTBCO0lBQ3hELEtBQUtuQixhQUFBO0lBQ0wsSUFBSTtNQUNGLE1BQU1tQixLQUFBLENBQUs7SUFDWixVQUFTO01BQ1IsS0FBS25CLGFBQUE7SUFDTjs7RUFHSCxNQUFNM25CLEtBQUtyTyxHQUFBLEVBQWFzTyxLQUFBLEVBQXVCO0lBQzdDLE9BQU8sS0FBSzRvQixpQkFBQSxDQUFrQixZQUFXO01BQ3ZDLE1BQU0sS0FBS1gsWUFBQSxDQUFjM0IsRUFBQSxJQUFvQmEsVUFBQSxDQUFXYixFQUFBLEVBQUk1MEIsR0FBQSxFQUFLc08sS0FBSyxDQUFDO01BQ3ZFLEtBQUtpaEIsVUFBQSxDQUFXdnZCLEdBQUEsSUFBT3NPLEtBQUE7TUFDdkIsT0FBTyxLQUFLMm9CLG1CQUFBLENBQW9CajNCLEdBQUc7SUFDckMsQ0FBQzs7RUFHSCxNQUFNdU8sS0FBaUN2TyxHQUFBLEVBQVc7SUFDaEQsTUFBTTZoQixHQUFBLEdBQU8sTUFBTSxLQUFLMFUsWUFBQSxDQUFjM0IsRUFBQSxJQUNwQ2UsU0FBQSxDQUFVZixFQUFBLEVBQUk1MEIsR0FBRyxDQUFDO0lBRXBCLEtBQUt1dkIsVUFBQSxDQUFXdnZCLEdBQUEsSUFBTzZoQixHQUFBO0lBQ3ZCLE9BQU9BLEdBQUE7O0VBR1QsTUFBTXJULFFBQVF4TyxHQUFBLEVBQVc7SUFDdkIsT0FBTyxLQUFLazNCLGlCQUFBLENBQWtCLFlBQVc7TUFDdkMsTUFBTSxLQUFLWCxZQUFBLENBQWMzQixFQUFBLElBQW9CZ0IsYUFBQSxDQUFjaEIsRUFBQSxFQUFJNTBCLEdBQUcsQ0FBQztNQUNuRSxPQUFPLEtBQUt1dkIsVUFBQSxDQUFXdnZCLEdBQUE7TUFDdkIsT0FBTyxLQUFLaTNCLG1CQUFBLENBQW9CajNCLEdBQUc7SUFDckMsQ0FBQzs7RUFHSyxNQUFNNjJCLE1BQUEsRUFBSztJQUVqQixNQUFNaGtCLE1BQUEsR0FBUyxNQUFNLEtBQUswakIsWUFBQSxDQUFjM0IsRUFBQSxJQUFtQjtNQUN6RCxNQUFNd0MsYUFBQSxHQUFnQnpDLGNBQUEsQ0FBZUMsRUFBQSxFQUFJLEtBQUssRUFBRXlDLE1BQUEsQ0FBTTtNQUN0RCxPQUFPLElBQUk1QyxTQUFBLENBQTZCMkMsYUFBYSxFQUFFMUMsU0FBQSxDQUFTO0lBQ2xFLENBQUM7SUFFRCxJQUFJLENBQUM3aEIsTUFBQSxFQUFRO01BQ1gsT0FBTztJQUNSO0lBR0QsSUFBSSxLQUFLbWpCLGFBQUEsS0FBa0IsR0FBRztNQUM1QixPQUFPO0lBQ1I7SUFFRCxNQUFNcEcsSUFBQSxHQUFPO0lBQ2IsTUFBTTBILFlBQUEsR0FBZSxtQkFBSTNQLEdBQUEsQ0FBRztJQUM1QixJQUFJOVUsTUFBQSxDQUFPcFAsTUFBQSxLQUFXLEdBQUc7TUFDdkIsV0FBVztRQUFFOHpCLFNBQUEsRUFBV3YzQixHQUFBO1FBQUtzTztNQUFLLEtBQU11RSxNQUFBLEVBQVE7UUFDOUN5a0IsWUFBQSxDQUFhclgsR0FBQSxDQUFJamdCLEdBQUc7UUFDcEIsSUFBSUosSUFBQSxDQUFLQyxTQUFBLENBQVUsS0FBSzB2QixVQUFBLENBQVd2dkIsR0FBQSxDQUFJLE1BQU1KLElBQUEsQ0FBS0MsU0FBQSxDQUFVeU8sS0FBSyxHQUFHO1VBQ2xFLEtBQUsyaEIsZUFBQSxDQUFnQmp3QixHQUFBLEVBQUtzTyxLQUF5QjtVQUNuRHNoQixJQUFBLENBQUs5YyxJQUFBLENBQUs5UyxHQUFHO1FBQ2Q7TUFDRjtJQUNGO0lBRUQsV0FBV3czQixRQUFBLElBQVlyOEIsTUFBQSxDQUFPeTBCLElBQUEsQ0FBSyxLQUFLTCxVQUFVLEdBQUc7TUFDbkQsSUFBSSxLQUFLQSxVQUFBLENBQVdpSSxRQUFBLEtBQWEsQ0FBQ0YsWUFBQSxDQUFhclAsR0FBQSxDQUFJdVAsUUFBUSxHQUFHO1FBRTVELEtBQUt2SCxlQUFBLENBQWdCdUgsUUFBQSxFQUFVLElBQUk7UUFDbkM1SCxJQUFBLENBQUs5YyxJQUFBLENBQUswa0IsUUFBUTtNQUNuQjtJQUNGO0lBQ0QsT0FBTzVILElBQUE7O0VBR0RLLGdCQUNOandCLEdBQUEsRUFDQTZ2QixRQUFBLEVBQWlDO0lBRWpDLEtBQUtOLFVBQUEsQ0FBV3Z2QixHQUFBLElBQU82dkIsUUFBQTtJQUN2QixNQUFNUCxTQUFBLEdBQVksS0FBS0EsU0FBQSxDQUFVdHZCLEdBQUE7SUFDakMsSUFBSXN2QixTQUFBLEVBQVc7TUFDYixXQUFXaUIsUUFBQSxJQUFZaGpCLEtBQUEsQ0FBTWlqQixJQUFBLENBQUtsQixTQUFTLEdBQUc7UUFDNUNpQixRQUFBLENBQVNWLFFBQVE7TUFDbEI7SUFDRjs7RUFHS1ksYUFBQSxFQUFZO0lBQ2xCLEtBQUtOLFdBQUEsQ0FBVztJQUVoQixLQUFLWCxTQUFBLEdBQVlrQixXQUFBLENBQ2YsWUFBWSxLQUFLbUcsS0FBQSxDQUFLLEdBQ3RCaEIsb0JBQW9COztFQUloQjFGLFlBQUEsRUFBVztJQUNqQixJQUFJLEtBQUtYLFNBQUEsRUFBVztNQUNsQm9CLGFBQUEsQ0FBYyxLQUFLcEIsU0FBUztNQUM1QixLQUFLQSxTQUFBLEdBQVk7SUFDbEI7O0VBR0gvZ0IsYUFBYXpPLEdBQUEsRUFBYXV3QixRQUFBLEVBQThCO0lBQ3RELElBQUlwMUIsTUFBQSxDQUFPeTBCLElBQUEsQ0FBSyxLQUFLTixTQUFTLEVBQUU3ckIsTUFBQSxLQUFXLEdBQUc7TUFDNUMsS0FBS2d0QixZQUFBLENBQVk7SUFDbEI7SUFDRCxJQUFJLENBQUMsS0FBS25CLFNBQUEsQ0FBVXR2QixHQUFBLEdBQU07TUFDeEIsS0FBS3N2QixTQUFBLENBQVV0dkIsR0FBQSxJQUFPLG1CQUFJMm5CLEdBQUEsQ0FBRztNQUU3QixLQUFLLEtBQUtwWixJQUFBLENBQUt2TyxHQUFHO0lBQ25CO0lBQ0QsS0FBS3N2QixTQUFBLENBQVV0dkIsR0FBQSxFQUFLaWdCLEdBQUEsQ0FBSXNRLFFBQVE7O0VBR2xDM2hCLGdCQUFnQjVPLEdBQUEsRUFBYXV3QixRQUFBLEVBQThCO0lBQ3pELElBQUksS0FBS2pCLFNBQUEsQ0FBVXR2QixHQUFBLEdBQU07TUFDdkIsS0FBS3N2QixTQUFBLENBQVV0dkIsR0FBQSxFQUFLNE0sTUFBQSxDQUFPMmpCLFFBQVE7TUFFbkMsSUFBSSxLQUFLakIsU0FBQSxDQUFVdHZCLEdBQUEsRUFBSyt3QixJQUFBLEtBQVMsR0FBRztRQUNsQyxPQUFPLEtBQUt6QixTQUFBLENBQVV0dkIsR0FBQTtNQUN2QjtJQUNGO0lBRUQsSUFBSTdFLE1BQUEsQ0FBT3kwQixJQUFBLENBQUssS0FBS04sU0FBUyxFQUFFN3JCLE1BQUEsS0FBVyxHQUFHO01BQzVDLEtBQUswc0IsV0FBQSxDQUFXO0lBQ2pCOzs7QUEvUkk0Rix5QkFBQSxDQUFJN25CLElBQUEsR0FBWTtBQXlTbEIsSUFBTXBmLHlCQUFBLEdBQXlDaW5DLHlCQUFBO0FDell0QyxTQUFBMEIsb0JBQ2QxOEIsSUFBQSxFQUNBcUUsT0FBQSxFQUFtQztFQUVuQyxPQUFPRSxrQkFBQSxDQUlMdkUsSUFBQSxFQUdBLHdDQUFBb0Usa0JBQUEsQ0FBbUJwRSxJQUFBLEVBQU1xRSxPQUFPLENBQUM7QUFFckM7QUFzQmdCLFNBQUFzNEIsdUJBQ2QzOEIsSUFBQSxFQUNBcUUsT0FBQSxFQUFzQztFQUV0QyxPQUFPRSxrQkFBQSxDQUlMdkUsSUFBQSxFQUdBLDJDQUFBb0Usa0JBQUEsQ0FBbUJwRSxJQUFBLEVBQU1xRSxPQUFPLENBQUM7QUFFckM7QUFFZ0IsU0FBQXU0QixzQkFDZDU4QixJQUFBLEVBQ0FxRSxPQUFBLEVBQXFDO0VBRXJDLE9BQU9FLGtCQUFBLENBSUx2RSxJQUFBLEVBR0EsMkNBQUFvRSxrQkFBQSxDQUFtQnBFLElBQUEsRUFBTXFFLE9BQU8sQ0FBQztBQUVyQztBQy9GTyxJQUFNdzRCLGNBQUEsR0FBaUI7QUFDdkIsSUFBTUMsbUJBQUEsR0FBc0I7QUFDNUIsSUFBTUMsZ0JBQUEsR0FBbUI7SUFRbkJDLGFBQUEsU0FBYTtFQUl4Qmw4QixZQUE2QmQsSUFBQSxFQUFrQjtJQUFsQixLQUFJQSxJQUFBLEdBQUpBLElBQUE7SUFIckIsS0FBT2k5QixPQUFBLEdBQUdGLGdCQUFBO0lBQ2xCLEtBQUFHLFFBQUEsR0FBVyxtQkFBSXJxQixHQUFBLENBQUc7O0VBSWxCc3FCLE9BQ0VDLFNBQUEsRUFDQUMsVUFBQSxFQUFnQztJQUVoQyxNQUFNN2UsRUFBQSxHQUFLLEtBQUt5ZSxPQUFBO0lBQ2hCLEtBQUtDLFFBQUEsQ0FBU2pxQixHQUFBLENBQ1p1TCxFQUFBLEVBQ0EsSUFBSThlLFVBQUEsQ0FBV0YsU0FBQSxFQUFXLEtBQUtwOUIsSUFBQSxDQUFLUyxJQUFBLEVBQU00OEIsVUFBQSxJQUFjLEVBQUUsQ0FBQztJQUU3RCxLQUFLSixPQUFBO0lBQ0wsT0FBT3plLEVBQUE7O0VBR1QrZSxNQUFNQyxXQUFBLEVBQW9COztJQUN4QixNQUFNaGYsRUFBQSxHQUFLZ2YsV0FBQSxJQUFlVCxnQkFBQTtJQUMxQixPQUFLcjdCLEVBQUEsUUFBS3c3QixRQUFBLENBQVNwNkIsR0FBQSxDQUFJMGIsRUFBRSxPQUFDLFFBQUE5YyxFQUFBLHVCQUFBQSxFQUFBLENBQUVtUSxNQUFBLENBQU07SUFDbEMsS0FBS3FyQixRQUFBLENBQVNyckIsTUFBQSxDQUFPMk0sRUFBRTs7RUFHekJ2VyxZQUFZdTFCLFdBQUEsRUFBb0I7O0lBQzlCLE1BQU1oZixFQUFBLEdBQUtnZixXQUFBLElBQWVULGdCQUFBO0lBQzFCLFNBQU9yN0IsRUFBQSxRQUFLdzdCLFFBQUEsQ0FBU3A2QixHQUFBLENBQUkwYixFQUFFLE9BQUcsUUFBQTljLEVBQUEsdUJBQUFBLEVBQUEsQ0FBQXVHLFdBQUEsQ0FBVyxNQUFNOztFQUdqRCxNQUFNMFosUUFBUTZiLFdBQUEsRUFBNkI7O0lBQ3pDLE1BQU1oZixFQUFBLEdBQWNnZixXQUFBLElBQTBCVCxnQkFBQTtJQUM5QyxPQUFLcjdCLEVBQUEsUUFBS3c3QixRQUFBLENBQVNwNkIsR0FBQSxDQUFJMGIsRUFBRSxPQUFDLFFBQUE5YyxFQUFBLHVCQUFBQSxFQUFBLENBQUVpZ0IsT0FBQSxDQUFPO0lBQ25DLE9BQU87O0FBRVY7SUE2Q1kyYixVQUFBLFNBQVU7RUFVckJ4OEIsWUFDRTI4QixhQUFBLEVBQ0FqOUIsT0FBQSxFQUNpQm9FLE1BQUEsRUFBMkI7SUFBM0IsS0FBTUEsTUFBQSxHQUFOQSxNQUFBO0lBVlgsS0FBT2lILE9BQUEsR0FBa0I7SUFDekIsS0FBTzZ4QixPQUFBLEdBQUc7SUFDVixLQUFhQyxhQUFBLEdBQWtCO0lBQ3RCLEtBQVlDLFlBQUEsR0FBRyxNQUFXO01BQ3pDLEtBQUtqYyxPQUFBLENBQU87SUFDZDtJQU9FLE1BQU15YixTQUFBLEdBQ0osT0FBT0ssYUFBQSxLQUFrQixXQUNyQjVtQixRQUFBLENBQVNnbkIsY0FBQSxDQUFlSixhQUFhLElBQ3JDQSxhQUFBO0lBQ052OEIsT0FBQSxDQUFRazhCLFNBQUEsRUFBUyxrQkFBZ0M7TUFBRTU4QjtJQUFPLENBQUU7SUFFNUQsS0FBSzQ4QixTQUFBLEdBQVlBLFNBQUE7SUFDakIsS0FBS1UsU0FBQSxHQUFZLEtBQUtsNUIsTUFBQSxDQUFPb3hCLElBQUEsS0FBUztJQUN0QyxJQUFJLEtBQUs4SCxTQUFBLEVBQVc7TUFDbEIsS0FBS25jLE9BQUEsQ0FBTztJQUNiLE9BQU07TUFDTCxLQUFLeWIsU0FBQSxDQUFVL1gsZ0JBQUEsQ0FBaUIsU0FBUyxLQUFLdVksWUFBWTtJQUMzRDs7RUFHSDMxQixZQUFBLEVBQVc7SUFDVCxLQUFLODFCLGNBQUEsQ0FBYztJQUNuQixPQUFPLEtBQUtKLGFBQUE7O0VBR2Q5ckIsT0FBQSxFQUFNO0lBQ0osS0FBS2tzQixjQUFBLENBQWM7SUFDbkIsS0FBS0wsT0FBQSxHQUFVO0lBQ2YsSUFBSSxLQUFLN3hCLE9BQUEsRUFBUztNQUNoQnBFLFlBQUEsQ0FBYSxLQUFLb0UsT0FBTztNQUN6QixLQUFLQSxPQUFBLEdBQVU7SUFDaEI7SUFDRCxLQUFLdXhCLFNBQUEsQ0FBVXJILG1CQUFBLENBQW9CLFNBQVMsS0FBSzZILFlBQVk7O0VBRy9EamMsUUFBQSxFQUFPO0lBQ0wsS0FBS29jLGNBQUEsQ0FBYztJQUNuQixJQUFJLEtBQUtseUIsT0FBQSxFQUFTO01BQ2hCO0lBQ0Q7SUFFRCxLQUFLQSxPQUFBLEdBQVU0SyxNQUFBLENBQU9qUCxVQUFBLENBQVcsTUFBSztNQUNwQyxLQUFLbTJCLGFBQUEsR0FBZ0JLLGdDQUFBLENBQWlDLEVBQUU7TUFDeEQsTUFBTTtRQUFFenNCLFFBQUE7UUFBVSxvQkFBb0Iwc0I7TUFBZSxJQUFLLEtBQUtyNUIsTUFBQTtNQUMvRCxJQUFJMk0sUUFBQSxFQUFVO1FBQ1osSUFBSTtVQUNGQSxRQUFBLENBQVMsS0FBS29zQixhQUFhO1FBQzVCLFNBQVFqM0IsQ0FBQSxFQUFQLENBQVU7TUFDYjtNQUVELEtBQUttRixPQUFBLEdBQVU0SyxNQUFBLENBQU9qUCxVQUFBLENBQVcsTUFBSztRQUNwQyxLQUFLcUUsT0FBQSxHQUFVO1FBQ2YsS0FBSzh4QixhQUFBLEdBQWdCO1FBQ3JCLElBQUlNLGVBQUEsRUFBaUI7VUFDbkIsSUFBSTtZQUNGQSxlQUFBLENBQWU7VUFDaEIsU0FBUXYzQixDQUFBLEVBQVAsQ0FBVTtRQUNiO1FBRUQsSUFBSSxLQUFLbzNCLFNBQUEsRUFBVztVQUNsQixLQUFLbmMsT0FBQSxDQUFPO1FBQ2I7U0FDQW1iLG1CQUFtQjtPQUNyQkQsY0FBYzs7RUFHWGtCLGVBQUEsRUFBYztJQUNwQixJQUFJLEtBQUtMLE9BQUEsRUFBUztNQUNoQixNQUFNLElBQUlwOEIsS0FBQSxDQUFNLHFDQUFxQztJQUN0RDs7QUFFSjtBQUVELFNBQVMwOEIsaUNBQWlDRSxHQUFBLEVBQVc7RUFDbkQsTUFBTUMsS0FBQSxHQUFRO0VBQ2QsTUFBTUMsWUFBQSxHQUNKO0VBQ0YsU0FBU25rQixDQUFBLEdBQUksR0FBR0EsQ0FBQSxHQUFJaWtCLEdBQUEsRUFBS2prQixDQUFBLElBQUs7SUFDNUJra0IsS0FBQSxDQUFNcG1CLElBQUEsQ0FDSnFtQixZQUFBLENBQWFsa0IsTUFBQSxDQUFPblgsSUFBQSxDQUFLOGQsS0FBQSxDQUFNOWQsSUFBQSxDQUFLK2QsTUFBQSxDQUFNLElBQUtzZCxZQUFBLENBQWExMUIsTUFBTSxDQUFDLENBQUM7RUFFdkU7RUFDRCxPQUFPeTFCLEtBQUEsQ0FBTTVtQixJQUFBLENBQUssRUFBRTtBQUN0QjtBQ3JMTyxJQUFNOG1CLGdCQUFBLEdBQW1CMWQscUJBQUEsQ0FBZ0MsS0FBSztBQUNyRSxJQUFNMmQscUJBQUEsR0FBd0IsSUFBSTk3QixLQUFBLENBQU0sS0FBTyxHQUFLO0FBQ3BELElBQU0rN0IsY0FBQSxHQUFpQjtJQWdCVkMsbUJBQUEsU0FBbUI7RUFBaEMxOUIsWUFBQTs7SUFDVSxLQUFZMjlCLFlBQUEsR0FBRztJQUNmLEtBQU94QixPQUFBLEdBQUc7SUFNRCxLQUFBeUIsdUJBQUEsR0FBMEIsQ0FBQyxHQUFDaDlCLEVBQUEsR0FBQWszQixPQUFBLENBQU8sRUFBRzV3QixVQUFBLE1BQVUsUUFBQXRHLEVBQUEsdUJBQUFBLEVBQUEsQ0FBRXk3QixNQUFBOztFQUVuRXdCLEtBQUszK0IsSUFBQSxFQUFvQjQrQixFQUFBLEdBQUssSUFBRTtJQUM5QjE5QixPQUFBLENBQVEyOUIsbUJBQUEsQ0FBb0JELEVBQUUsR0FBRzUrQixJQUFBLEVBQUk7SUFFckMsSUFBSSxLQUFLOCtCLHdCQUFBLENBQXlCRixFQUFFLEtBQUs3MkIsSUFBQSxDQUFLNndCLE9BQUEsQ0FBTyxFQUFHNXdCLFVBQVUsR0FBRztNQUNuRSxPQUFPcEMsT0FBQSxDQUFRaVMsT0FBQSxDQUFRK2dCLE9BQUEsQ0FBTyxFQUFHNXdCLFVBQXdCO0lBQzFEO0lBQ0QsT0FBTyxJQUFJcEMsT0FBQSxDQUFtQixDQUFDaVMsT0FBQSxFQUFTdFEsTUFBQSxLQUFVO01BQ2hELE1BQU03QixjQUFBLEdBQWlCa3pCLE9BQUEsQ0FBTyxFQUFHcHhCLFVBQUEsQ0FBVyxNQUFLO1FBQy9DRCxNQUFBLENBQU96SCxZQUFBLENBQWFFLElBQUEsRUFBSSx5QkFBdUM7TUFDakUsR0FBR3MrQixxQkFBQSxDQUFzQng3QixHQUFBLENBQUcsQ0FBRTtNQUU5QjgxQixPQUFBLENBQU8sRUFBR3lGLGdCQUFBLElBQW9CLE1BQUs7UUFDakN6RixPQUFBLENBQU8sRUFBR254QixZQUFBLENBQWEvQixjQUFjO1FBQ3JDLE9BQU9rekIsT0FBQSxDQUFPLEVBQUd5RixnQkFBQTtRQUVqQixNQUFNVSxTQUFBLEdBQVluRyxPQUFBLENBQU8sRUFBRzV3QixVQUFBO1FBRTVCLElBQUksQ0FBQysyQixTQUFBLElBQWEsQ0FBQ2gzQixJQUFBLENBQUtnM0IsU0FBUyxHQUFHO1VBQ2xDeDNCLE1BQUEsQ0FBT3pILFlBQUEsQ0FBYUUsSUFBQSxFQUFJLGlCQUErQjtVQUN2RDtRQUNEO1FBSUQsTUFBTW05QixNQUFBLEdBQVM0QixTQUFBLENBQVU1QixNQUFBO1FBQ3pCNEIsU0FBQSxDQUFVNUIsTUFBQSxHQUFTLENBQUNDLFNBQUEsRUFBV3g0QixNQUFBLEtBQVU7VUFDdkMsTUFBTW82QixRQUFBLEdBQVc3QixNQUFBLENBQU9DLFNBQUEsRUFBV3g0QixNQUFNO1VBQ3pDLEtBQUtxNEIsT0FBQTtVQUNMLE9BQU8rQixRQUFBO1FBQ1Q7UUFFQSxLQUFLUCxZQUFBLEdBQWVHLEVBQUE7UUFDcEIvbUIsT0FBQSxDQUFRa25CLFNBQVM7TUFDbkI7TUFFQSxNQUFNMTdCLEdBQUEsR0FBTSxHQUFHazdCLGNBQUEsUUFBa0J0bUMsV0FBQSxDQUFBK00sV0FBQSxFQUFZO1FBQzNDdWIsTUFBQSxFQUFROGQsZ0JBQUE7UUFDUmxCLE1BQUEsRUFBUTtRQUNSeUI7TUFDRDtNQUVEemUsT0FBQSxDQUFrQjljLEdBQUcsRUFBRW1lLEtBQUEsQ0FBTSxNQUFLO1FBQ2hDL1osWUFBQSxDQUFhL0IsY0FBYztRQUMzQjZCLE1BQUEsQ0FBT3pILFlBQUEsQ0FBYUUsSUFBQSxFQUFJLGlCQUErQjtNQUN6RCxDQUFDO0lBQ0gsQ0FBQzs7RUFHSGkvQixtQkFBQSxFQUFrQjtJQUNoQixLQUFLaEMsT0FBQTs7RUFHQzZCLHlCQUF5QkYsRUFBQSxFQUFVOztJQVF6QyxPQUNFLENBQUMsR0FBQ2w5QixFQUFBLEdBQUFrM0IsT0FBQSxDQUFPLEVBQUc1d0IsVUFBQSxNQUFZLFFBQUF0RyxFQUFBLHVCQUFBQSxFQUFBLENBQUF5N0IsTUFBQSxNQUN2QnlCLEVBQUEsS0FBTyxLQUFLSCxZQUFBLElBQ1gsS0FBS3hCLE9BQUEsR0FBVSxLQUNmLEtBQUt5Qix1QkFBQTs7QUFHWjtBQUVELFNBQVNHLG9CQUFvQkQsRUFBQSxFQUFVO0VBQ3JDLE9BQU9BLEVBQUEsQ0FBR2wyQixNQUFBLElBQVUsS0FBSyx5QkFBeUIyTixJQUFBLENBQUt1b0IsRUFBRTtBQUMzRDtJQUVhTSx1QkFBQSxTQUF1QjtFQUNsQyxNQUFNUCxLQUFLMytCLElBQUEsRUFBa0I7SUFDM0IsT0FBTyxJQUFJZzlCLGFBQUEsQ0FBY2g5QixJQUFJOztFQUcvQmkvQixtQkFBQSxFQUFrQjtBQUNuQjtBQ3ZHTSxJQUFNRSx1QkFBQSxHQUEwQjtBQUV2QyxJQUFNQyxjQUFBLEdBQXNDO0VBQzFDQyxLQUFBLEVBQU87RUFDUGxzQixJQUFBLEVBQU07O0lBYUs3Z0IsaUJBQUEsU0FBaUI7RUF1QzVCd08sWUFDRXFnQixVQUFBLEVBQ0FzYyxhQUFBLEVBQ2lCSixVQUFBLEdBQUFqOUIsTUFBQSxDQUFBQyxNQUFBLEtBQ1orK0IsY0FBYyxHQUNsQjtJQUZnQixLQUFVL0IsVUFBQSxHQUFWQSxVQUFBO0lBbkNWLEtBQUlscUIsSUFBQSxHQUFHZ3NCLHVCQUFBO0lBQ1IsS0FBU0csU0FBQSxHQUFHO0lBQ1osS0FBUU4sUUFBQSxHQUFrQjtJQUdqQixLQUFBTyxvQkFBQSxHQUF1QixtQkFBSTNTLEdBQUEsQ0FBRztJQUN2QyxLQUFhNFMsYUFBQSxHQUEyQjtJQUt4QyxLQUFTVCxTQUFBLEdBQXFCO0lBNEJwQyxLQUFLLytCLElBQUEsR0FBTzhmLFNBQUEsQ0FBVXFCLFVBQVU7SUFDaEMsS0FBS3NlLFdBQUEsR0FBYyxLQUFLcEMsVUFBQSxDQUFXckgsSUFBQSxLQUFTO0lBQzVDOTBCLE9BQUEsQ0FDRSxPQUFPMlYsUUFBQSxLQUFhLGFBQ3BCLEtBQUs3VyxJQUFBLEVBQUk7SUFHWCxNQUFNbzlCLFNBQUEsR0FDSixPQUFPSyxhQUFBLEtBQWtCLFdBQ3JCNW1CLFFBQUEsQ0FBU2duQixjQUFBLENBQWVKLGFBQWEsSUFDckNBLGFBQUE7SUFDTnY4QixPQUFBLENBQVFrOEIsU0FBQSxFQUFXLEtBQUtwOUIsSUFBQSxFQUFJO0lBRTVCLEtBQUtvOUIsU0FBQSxHQUFZQSxTQUFBO0lBQ2pCLEtBQUtDLFVBQUEsQ0FBVzlyQixRQUFBLEdBQVcsS0FBS211QixpQkFBQSxDQUFrQixLQUFLckMsVUFBQSxDQUFXOXJCLFFBQVE7SUFFMUUsS0FBS291QixnQkFBQSxHQUFtQixLQUFLMy9CLElBQUEsQ0FBS3liLFFBQUEsQ0FBU0MsaUNBQUEsR0FDdkMsSUFBSXdqQix1QkFBQSxDQUF1QixJQUMzQixJQUFJVixtQkFBQSxDQUFtQjtJQUUzQixLQUFLb0IscUJBQUEsQ0FBcUI7O0VBUzVCLE1BQU14ZSxPQUFBLEVBQU07SUFDVixLQUFLeWUsa0JBQUEsQ0FBa0I7SUFDdkIsTUFBTXJoQixFQUFBLEdBQUssTUFBTSxLQUFLMmUsTUFBQSxDQUFNO0lBQzVCLE1BQU00QixTQUFBLEdBQVksS0FBS2Usb0JBQUEsQ0FBb0I7SUFFM0MsTUFBTTk3QixRQUFBLEdBQVcrNkIsU0FBQSxDQUFVOTJCLFdBQUEsQ0FBWXVXLEVBQUU7SUFDekMsSUFBSXhhLFFBQUEsRUFBVTtNQUNaLE9BQU9BLFFBQUE7SUFDUjtJQUVELE9BQU8sSUFBSTRCLE9BQUEsQ0FBZ0JpUyxPQUFBLElBQVU7TUFDbkMsTUFBTWtvQixXQUFBLEdBQWUvMUIsS0FBQSxJQUF1QjtRQUMxQyxJQUFJLENBQUNBLEtBQUEsRUFBTztVQUNWO1FBQ0Q7UUFDRCxLQUFLdTFCLG9CQUFBLENBQXFCMXRCLE1BQUEsQ0FBT2t1QixXQUFXO1FBQzVDbG9CLE9BQUEsQ0FBUTdOLEtBQUs7TUFDZjtNQUVBLEtBQUt1MUIsb0JBQUEsQ0FBcUJyYSxHQUFBLENBQUk2YSxXQUFXO01BQ3pDLElBQUksS0FBS04sV0FBQSxFQUFhO1FBQ3BCVixTQUFBLENBQVVwZCxPQUFBLENBQVFuRCxFQUFFO01BQ3JCO0lBQ0gsQ0FBQzs7RUFRSDJlLE9BQUEsRUFBTTtJQUNKLElBQUk7TUFDRixLQUFLMEMsa0JBQUEsQ0FBa0I7SUFDeEIsU0FBUW41QixDQUFBLEVBQVA7TUFJQSxPQUFPZCxPQUFBLENBQVEyQixNQUFBLENBQU9iLENBQUM7SUFDeEI7SUFFRCxJQUFJLEtBQUs4NEIsYUFBQSxFQUFlO01BQ3RCLE9BQU8sS0FBS0EsYUFBQTtJQUNiO0lBRUQsS0FBS0EsYUFBQSxHQUFnQixLQUFLUSxpQkFBQSxDQUFpQixFQUFHeGUsS0FBQSxDQUFNOWEsQ0FBQSxJQUFJO01BQ3RELEtBQUs4NEIsYUFBQSxHQUFnQjtNQUNyQixNQUFNOTRCLENBQUE7SUFDUixDQUFDO0lBRUQsT0FBTyxLQUFLODRCLGFBQUE7O0VBSWRTLE9BQUEsRUFBTTtJQUNKLEtBQUtKLGtCQUFBLENBQWtCO0lBQ3ZCLElBQUksS0FBS2IsUUFBQSxLQUFhLE1BQU07TUFDMUIsS0FBS2Msb0JBQUEsQ0FBb0IsRUFBR3ZDLEtBQUEsQ0FBTSxLQUFLeUIsUUFBUTtJQUNoRDs7RUFNSGtCLE1BQUEsRUFBSztJQUNILEtBQUtMLGtCQUFBLENBQWtCO0lBQ3ZCLEtBQUtQLFNBQUEsR0FBWTtJQUNqQixLQUFLSyxnQkFBQSxDQUFpQlYsa0JBQUEsQ0FBa0I7SUFDeEMsSUFBSSxDQUFDLEtBQUtRLFdBQUEsRUFBYTtNQUNyQixLQUFLckMsU0FBQSxDQUFVK0MsVUFBQSxDQUFXQyxPQUFBLENBQVFDLElBQUEsSUFBTztRQUN2QyxLQUFLakQsU0FBQSxDQUFVa0QsV0FBQSxDQUFZRCxJQUFJO01BQ2pDLENBQUM7SUFDRjs7RUFHS1Qsc0JBQUEsRUFBcUI7SUFDM0IxK0IsT0FBQSxDQUFRLENBQUMsS0FBS204QixVQUFBLENBQVdrRCxPQUFBLEVBQVMsS0FBS3ZnQyxJQUFBLEVBQUk7SUFDM0NrQixPQUFBLENBQ0UsS0FBS3UrQixXQUFBLElBQWUsQ0FBQyxLQUFLckMsU0FBQSxDQUFVb0QsYUFBQSxDQUFhLEdBQ2pELEtBQUt4Z0MsSUFBQSxFQUFJO0lBR1hrQixPQUFBLENBQ0UsT0FBTzJWLFFBQUEsS0FBYSxhQUNwQixLQUFLN1csSUFBQSxFQUFJOztFQUtMMC9CLGtCQUNOZSxRQUFBLEVBQTRDO0lBRTVDLE9BQU96MkIsS0FBQSxJQUFRO01BQ2IsS0FBS3UxQixvQkFBQSxDQUFxQmEsT0FBQSxDQUFRNUssUUFBQSxJQUFZQSxRQUFBLENBQVN4ckIsS0FBSyxDQUFDO01BQzdELElBQUksT0FBT3kyQixRQUFBLEtBQWEsWUFBWTtRQUNsQ0EsUUFBQSxDQUFTejJCLEtBQUs7TUFDZixXQUFVLE9BQU95MkIsUUFBQSxLQUFhLFVBQVU7UUFDdkMsTUFBTUMsVUFBQSxHQUFhOUgsT0FBQSxDQUFPLEVBQUc2SCxRQUFBO1FBQzdCLElBQUksT0FBT0MsVUFBQSxLQUFlLFlBQVk7VUFDcENBLFVBQUEsQ0FBVzEyQixLQUFLO1FBQ2pCO01BQ0Y7SUFDSDs7RUFHTTYxQixtQkFBQSxFQUFrQjtJQUN4QjMrQixPQUFBLENBQVEsQ0FBQyxLQUFLbytCLFNBQUEsRUFBVyxLQUFLdC9CLElBQUEsRUFBSTs7RUFHNUIsTUFBTWdnQyxrQkFBQSxFQUFpQjtJQUM3QixNQUFNLEtBQUtXLElBQUEsQ0FBSTtJQUNmLElBQUksQ0FBQyxLQUFLM0IsUUFBQSxFQUFVO01BQ2xCLElBQUk1QixTQUFBLEdBQVksS0FBS0EsU0FBQTtNQUNyQixJQUFJLENBQUMsS0FBS3FDLFdBQUEsRUFBYTtRQUNyQixNQUFNbUIsZUFBQSxHQUFrQi9wQixRQUFBLENBQVN3SixhQUFBLENBQWMsS0FBSztRQUNwRCtjLFNBQUEsQ0FBVTFjLFdBQUEsQ0FBWWtnQixlQUFlO1FBQ3JDeEQsU0FBQSxHQUFZd0QsZUFBQTtNQUNiO01BRUQsS0FBSzVCLFFBQUEsR0FBVyxLQUFLYyxvQkFBQSxDQUFvQixFQUFHM0MsTUFBQSxDQUMxQ0MsU0FBQSxFQUNBLEtBQUtDLFVBQVU7SUFFbEI7SUFFRCxPQUFPLEtBQUsyQixRQUFBOztFQUdOLE1BQU0yQixLQUFBLEVBQUk7SUFDaEJ6L0IsT0FBQSxDQUNFVyxjQUFBLENBQWMsS0FBTSxDQUFDaTNCLFNBQUEsQ0FBUyxHQUM5QixLQUFLOTRCLElBQUEsRUFBSTtJQUlYLE1BQU02Z0MsUUFBQSxDQUFRO0lBQ2QsS0FBSzlCLFNBQUEsR0FBWSxNQUFNLEtBQUtZLGdCQUFBLENBQWlCaEIsSUFBQSxDQUMzQyxLQUFLMytCLElBQUEsRUFDTCxLQUFLQSxJQUFBLENBQUtvRixZQUFBLElBQWdCLE1BQVM7SUFHckMsTUFBTWlELE9BQUEsR0FBVSxNQUFNUyxrQkFBQSxDQUFtQixLQUFLOUksSUFBSTtJQUNsRGtCLE9BQUEsQ0FBUW1ILE9BQUEsRUFBUyxLQUFLckksSUFBQSxFQUFJO0lBQzFCLEtBQUtxOUIsVUFBQSxDQUFXa0QsT0FBQSxHQUFVbDRCLE9BQUE7O0VBR3BCeTNCLHFCQUFBLEVBQW9CO0lBQzFCNStCLE9BQUEsQ0FBUSxLQUFLNjlCLFNBQUEsRUFBVyxLQUFLLytCLElBQUEsRUFBSTtJQUNqQyxPQUFPLEtBQUsrK0IsU0FBQTs7QUFFZjtBQUVELFNBQVM4QixTQUFBLEVBQVE7RUFDZixJQUFJeGlCLFFBQUEsR0FBZ0M7RUFDcEMsT0FBTyxJQUFJelksT0FBQSxDQUFjaVMsT0FBQSxJQUFVO0lBQ2pDLElBQUloQixRQUFBLENBQVN1TyxVQUFBLEtBQWUsWUFBWTtNQUN0Q3ZOLE9BQUEsQ0FBTztNQUNQO0lBQ0Q7SUFLRHdHLFFBQUEsR0FBV0EsQ0FBQSxLQUFNeEcsT0FBQSxDQUFPO0lBQ3hCcEIsTUFBQSxDQUFPNE8sZ0JBQUEsQ0FBaUIsUUFBUWhILFFBQVE7RUFDMUMsQ0FBQyxFQUFFbUQsS0FBQSxDQUFNOWEsQ0FBQSxJQUFJO0lBQ1gsSUFBSTJYLFFBQUEsRUFBVTtNQUNaNUgsTUFBQSxDQUFPc2YsbUJBQUEsQ0FBb0IsUUFBUTFYLFFBQVE7SUFDNUM7SUFFRCxNQUFNM1gsQ0FBQTtFQUNSLENBQUM7QUFDSDtBQ3BQQSxJQUFNbzZCLHNCQUFBLEdBQU4sTUFBNEI7RUFDMUJoZ0MsWUFDV3duQixjQUFBLEVBQ1F5WSxjQUFBLEVBQXNDO0lBRDlDLEtBQWN6WSxjQUFBLEdBQWRBLGNBQUE7SUFDUSxLQUFjeVksY0FBQSxHQUFkQSxjQUFBOztFQUduQkMsUUFBUXpZLGdCQUFBLEVBQXdCO0lBQzlCLE1BQU0wWSxjQUFBLEdBQWlCL3VDLG1CQUFBLENBQW9CbTJCLGlCQUFBLENBQ3pDLEtBQUtDLGNBQUEsRUFDTEMsZ0JBQWdCO0lBRWxCLE9BQU8sS0FBS3dZLGNBQUEsQ0FBZUUsY0FBYzs7QUFFNUM7QUFrQ00sZUFBZXRyQyxzQkFDcEJxSyxJQUFBLEVBQ0E0SCxXQUFBLEVBQ0FzNUIsV0FBQSxFQUFnQztFQUVoQyxNQUFNemUsWUFBQSxHQUFlM0MsU0FBQSxDQUFVOWYsSUFBSTtFQUNuQyxNQUFNc29CLGNBQUEsR0FBaUIsTUFBTTZZLGtCQUFBLENBQzNCMWUsWUFBQSxFQUNBN2EsV0FBQSxNQUNBM1AsV0FBQSxDQUFBNlIsa0JBQUEsRUFBbUJvM0IsV0FBMEMsQ0FBQztFQUVoRSxPQUFPLElBQUlKLHNCQUFBLENBQXVCeFksY0FBQSxFQUFnQmxCLElBQUEsSUFDaEQ3eEIsb0JBQUEsQ0FBcUJrdEIsWUFBQSxFQUFjMkUsSUFBSSxDQUFDO0FBRTVDO0FBY08sZUFBZWh6QixvQkFDcEJ3VixJQUFBLEVBQ0FoQyxXQUFBLEVBQ0FzNUIsV0FBQSxFQUFnQztFQUVoQyxNQUFNbjNCLFlBQUEsT0FBZTlSLFdBQUEsQ0FBQTZSLGtCQUFBLEVBQW1CRixJQUFJO0VBQzVDLE1BQU1rakIsbUJBQUEsQ0FBb0IsT0FBTy9pQixZQUFBLEVBQVk7RUFDN0MsTUFBTXVlLGNBQUEsR0FBaUIsTUFBTTZZLGtCQUFBLENBQzNCcDNCLFlBQUEsQ0FBYS9KLElBQUEsRUFDYjRILFdBQUEsTUFDQTNQLFdBQUEsQ0FBQTZSLGtCQUFBLEVBQW1CbzNCLFdBQTBDLENBQUM7RUFFaEUsT0FBTyxJQUFJSixzQkFBQSxDQUF1QnhZLGNBQUEsRUFBZ0JsQixJQUFBLElBQ2hEanpCLGtCQUFBLENBQW1CNFYsWUFBQSxFQUFjcWQsSUFBSSxDQUFDO0FBRTFDO0FBZ0JPLGVBQWV2eUIsOEJBQ3BCK1UsSUFBQSxFQUNBaEMsV0FBQSxFQUNBczVCLFdBQUEsRUFBZ0M7RUFFaEMsTUFBTW4zQixZQUFBLE9BQWU5UixXQUFBLENBQUE2UixrQkFBQSxFQUFtQkYsSUFBSTtFQUM1QyxNQUFNMGUsY0FBQSxHQUFpQixNQUFNNlksa0JBQUEsQ0FDM0JwM0IsWUFBQSxDQUFhL0osSUFBQSxFQUNiNEgsV0FBQSxNQUNBM1AsV0FBQSxDQUFBNlIsa0JBQUEsRUFBbUJvM0IsV0FBMEMsQ0FBQztFQUVoRSxPQUFPLElBQUlKLHNCQUFBLENBQXVCeFksY0FBQSxFQUFnQmxCLElBQUEsSUFDaER4eUIsNEJBQUEsQ0FBNkJtVixZQUFBLEVBQWNxZCxJQUFJLENBQUM7QUFFcEQ7QUFNTyxlQUFlK1osbUJBQ3BCbmhDLElBQUEsRUFDQXFmLE9BQUEsRUFDQXlDLFFBQUEsRUFBcUM7O0VBRXJDLE1BQU1zZixjQUFBLEdBQWlCLE1BQU10ZixRQUFBLENBQVNWLE1BQUEsQ0FBTTtFQUU1QyxJQUFJO0lBQ0ZsZ0IsT0FBQSxDQUNFLE9BQU9rZ0MsY0FBQSxLQUFtQixVQUMxQnBoQyxJQUFBLEVBQUk7SUFHTmtCLE9BQUEsQ0FDRTRnQixRQUFBLENBQVMzTyxJQUFBLEtBQVNnc0IsdUJBQUEsRUFDbEJuL0IsSUFBQSxFQUFJO0lBSU4sSUFBSXFoQyxnQkFBQTtJQUVKLElBQUksT0FBT2hpQixPQUFBLEtBQVksVUFBVTtNQUMvQmdpQixnQkFBQSxHQUFtQjtRQUNqQno1QixXQUFBLEVBQWF5WDs7SUFFaEIsT0FBTTtNQUNMZ2lCLGdCQUFBLEdBQW1CaGlCLE9BQUE7SUFDcEI7SUFFRCxJQUFJLGFBQWFnaUIsZ0JBQUEsRUFBa0I7TUFDakMsTUFBTXJQLE9BQUEsR0FBVXFQLGdCQUFBLENBQWlCclAsT0FBQTtNQUVqQyxJQUFJLGlCQUFpQnFQLGdCQUFBLEVBQWtCO1FBQ3JDbmdDLE9BQUEsQ0FDRTh3QixPQUFBLENBQVE3ZSxJQUFBLEtBQUksVUFDWm5ULElBQUEsRUFBSTtRQUdOLE1BQU1nRSxRQUFBLEdBQVcsTUFBTXl1QixtQkFBQSxDQUFvQnp5QixJQUFBLEVBQU07VUFDL0NvTixPQUFBLEVBQVM0a0IsT0FBQSxDQUFRdkksVUFBQTtVQUNqQjZYLG1CQUFBLEVBQXFCO1lBQ25CMTVCLFdBQUEsRUFBYXk1QixnQkFBQSxDQUFpQno1QixXQUFBO1lBQzlCdzVCO1VBQ0Q7UUFDRjtRQUNELE9BQU9wOUIsUUFBQSxDQUFTdTlCLGdCQUFBLENBQWlCN1ksV0FBQTtNQUNsQyxPQUFNO1FBQ0x4bkIsT0FBQSxDQUNFOHdCLE9BQUEsQ0FBUTdlLElBQUEsS0FBSSxVQUNablQsSUFBQSxFQUFJO1FBR04sTUFBTTh0QixlQUFBLEtBQ0pwc0IsRUFBQSxHQUFBMi9CLGdCQUFBLENBQWlCRyxlQUFBLE1BQWUsUUFBQTkvQixFQUFBLHVCQUFBQSxFQUFBLENBQUV3TSxHQUFBLEtBQ2xDbXpCLGdCQUFBLENBQWlCSSxjQUFBO1FBQ25CdmdDLE9BQUEsQ0FBUTRzQixlQUFBLEVBQWlCOXRCLElBQUEsRUFBSTtRQUM3QixNQUFNZ0UsUUFBQSxHQUFXLE1BQU0wNEIsbUJBQUEsQ0FBb0IxOEIsSUFBQSxFQUFNO1VBQy9DNHhCLG9CQUFBLEVBQXNCSSxPQUFBLENBQVF2SSxVQUFBO1VBQzlCcUUsZUFBQTtVQUNBNFQsZUFBQSxFQUFpQjtZQUNmTjtVQUNEO1FBQ0Y7UUFDRCxPQUFPcDlCLFFBQUEsQ0FBUzI5QixpQkFBQSxDQUFrQmpaLFdBQUE7TUFDbkM7SUFDRixPQUFNO01BQ0wsTUFBTTtRQUFFQTtNQUFXLElBQUssTUFBTWIseUJBQUEsQ0FBMEI3bkIsSUFBQSxFQUFNO1FBQzVENEgsV0FBQSxFQUFheTVCLGdCQUFBLENBQWlCejVCLFdBQUE7UUFDOUJ3NUI7TUFDRDtNQUNELE9BQU8xWSxXQUFBO0lBQ1I7RUFDRixVQUFTO0lBQ1I1RyxRQUFBLENBQVNtZSxNQUFBLENBQU07RUFDaEI7QUFDSDtBQXdCTyxlQUFlOXBDLGtCQUNwQnlULElBQUEsRUFDQTZmLFVBQUEsRUFBK0I7RUFFL0IsTUFBTTBELE9BQUEsS0FBTWwxQixXQUFBLENBQUE2UixrQkFBQSxFQUFtQkYsSUFBSSxHQUFtQjZmLFVBQVU7QUFDbEU7SUNyT2F0M0IsaUJBQUEsU0FBaUI7RUFjNUIyTyxZQUFZZCxJQUFBLEVBQVU7SUFQYixLQUFBaVAsVUFBQSxHQUFhOWMsaUJBQUEsQ0FBa0JxM0IsV0FBQTtJQVF0QyxLQUFLeHBCLElBQUEsR0FBTzhmLFNBQUEsQ0FBVTlmLElBQUk7O0VBa0M1QjRoQyxrQkFDRUMsWUFBQSxFQUNBQyxtQkFBQSxFQUF3QztJQUV4QyxPQUFPWCxrQkFBQSxDQUNMLEtBQUtuaEMsSUFBQSxFQUNMNmhDLFlBQUEsTUFDQTVwQyxXQUFBLENBQUE2UixrQkFBQSxFQUFtQmc0QixtQkFBa0QsQ0FBQzs7RUErQjFFLE9BQU9yWSxXQUNMbkIsY0FBQSxFQUNBQyxnQkFBQSxFQUF3QjtJQUV4QixPQUFPcjJCLG1CQUFBLENBQW9CbTJCLGlCQUFBLENBQ3pCQyxjQUFBLEVBQ0FDLGdCQUFnQjs7RUFRcEIsT0FBT3VDLHFCQUNMQyxjQUFBLEVBQThCO0lBRTlCLE1BQU10QixVQUFBLEdBQWFzQixjQUFBO0lBQ25CLE9BQU81NEIsaUJBQUEsQ0FBa0JtNUIsMEJBQUEsQ0FBMkI3QixVQUFVOztFQW1DaEUsT0FBT3dCLG9CQUFvQnhyQixLQUFBLEVBQW9CO0lBQzdDLE9BQU90TixpQkFBQSxDQUFrQm01QiwwQkFBQSxDQUN0QjdyQixLQUFBLENBQU1vSSxVQUFBLElBQWMsRUFBRTs7RUFJbkIsT0FBT3lqQiwyQkFBMkI7SUFDeEN4akIsY0FBQSxFQUFnQm9qQjtFQUFhLEdBQ0w7SUFDeEIsSUFBSSxDQUFDQSxhQUFBLEVBQWU7TUFDbEIsT0FBTztJQUNSO0lBQ0QsTUFBTTtNQUFFdGpCLFdBQUE7TUFBYW9nQjtJQUFjLElBQ2pDa0QsYUFBQTtJQUNGLElBQUl0akIsV0FBQSxJQUFlb2dCLGNBQUEsRUFBZ0I7TUFDakMsT0FBTzkxQixtQkFBQSxDQUFvQnMyQixrQkFBQSxDQUN6QjVnQixXQUFBLEVBQ0FvZ0IsY0FBYztJQUVqQjtJQUNELE9BQU87OztBQTlKTzcxQixpQkFBQSxDQUFBcTNCLFdBQUEsR0FBd0M7QUFFeENyM0IsaUJBQUEsQ0FBQTR2QyxvQkFBQSxHQUFtRDtBQzlCckQsU0FBQUMscUJBQ2RoaUMsSUFBQSxFQUNBaWlDLGdCQUFBLEVBQW1EO0VBRW5ELElBQUlBLGdCQUFBLEVBQWtCO0lBQ3BCLE9BQU9udkIsWUFBQSxDQUFhbXZCLGdCQUFnQjtFQUNyQztFQUVEL2dDLE9BQUEsQ0FBUWxCLElBQUEsQ0FBS21iLHNCQUFBLEVBQXdCbmIsSUFBQSxFQUFJO0VBRXpDLE9BQU9BLElBQUEsQ0FBS21iLHNCQUFBO0FBQ2Q7QUNRQSxJQUFNK21CLGFBQUEsR0FBTixjQUE0QjV3QyxjQUFBLENBQWM7RUFDeEN3UCxZQUFxQjhELE1BQUEsRUFBcUI7SUFDeEMsTUFBSztJQURjLEtBQU1BLE1BQUEsR0FBTkEsTUFBQTs7RUFJckIyZ0Isb0JBQW9CdmxCLElBQUEsRUFBa0I7SUFDcEMsT0FBT2duQixhQUFBLENBQWNobkIsSUFBQSxFQUFNLEtBQUttaUMsZ0JBQUEsQ0FBZ0IsQ0FBRTs7RUFHcEQxYyxlQUNFemxCLElBQUEsRUFDQW9OLE9BQUEsRUFBZTtJQUVmLE9BQU80WixhQUFBLENBQWNobkIsSUFBQSxFQUFNLEtBQUttaUMsZ0JBQUEsQ0FBaUIvMEIsT0FBTyxDQUFDOztFQUczRHVZLDZCQUE2QjNsQixJQUFBLEVBQWtCO0lBQzdDLE9BQU9nbkIsYUFBQSxDQUFjaG5CLElBQUEsRUFBTSxLQUFLbWlDLGdCQUFBLENBQWdCLENBQUU7O0VBRzVDQSxpQkFBaUIvMEIsT0FBQSxFQUFnQjtJQUN2QyxNQUFNL0ksT0FBQSxHQUFnQztNQUNwQ3NqQixVQUFBLEVBQVksS0FBSy9pQixNQUFBLENBQU8raUIsVUFBQTtNQUN4QnlhLFNBQUEsRUFBVyxLQUFLeDlCLE1BQUEsQ0FBT3c5QixTQUFBO01BQ3ZCeGEsUUFBQSxFQUFVLEtBQUtoakIsTUFBQSxDQUFPZ2pCLFFBQUE7TUFDdEJ0akIsUUFBQSxFQUFVLEtBQUtNLE1BQUEsQ0FBT04sUUFBQTtNQUN0QjRpQixZQUFBLEVBQWMsS0FBS3RpQixNQUFBLENBQU9zaUIsWUFBQTtNQUMxQkgsaUJBQUEsRUFBbUI7TUFDbkJzYixtQkFBQSxFQUFxQjs7SUFHdkIsSUFBSWoxQixPQUFBLEVBQVM7TUFDWC9JLE9BQUEsQ0FBUStJLE9BQUEsR0FBVUEsT0FBQTtJQUNuQjtJQUVELE9BQU8vSSxPQUFBOztBQUVWO0FBRUssU0FBVWkrQixRQUNkMTlCLE1BQUEsRUFBcUI7RUFFckIsT0FBTzZvQixxQkFBQSxDQUNMN29CLE1BQUEsQ0FBTzVFLElBQUEsRUFDUCxJQUFJa2lDLGFBQUEsQ0FBY3Q5QixNQUFNLEdBQ3hCQSxNQUFBLENBQU80RyxlQUFlO0FBRTFCO0FBRU0sU0FBVSsyQixRQUNkMzlCLE1BQUEsRUFBcUI7RUFFckIsTUFBTTtJQUFFNUUsSUFBQTtJQUFNNEo7RUFBSSxJQUFLaEYsTUFBQTtFQUN2QjFELE9BQUEsQ0FBUTBJLElBQUEsRUFBTTVKLElBQUEsRUFBSTtFQUNsQixPQUFPc3RCLGVBQUEsQ0FDTDFqQixJQUFBLEVBQ0EsSUFBSXM0QixhQUFBLENBQWN0OUIsTUFBTSxHQUN4QkEsTUFBQSxDQUFPNEcsZUFBZTtBQUUxQjtBQUVPLGVBQWVnM0IsTUFDcEI1OUIsTUFBQSxFQUFxQjtFQUVyQixNQUFNO0lBQUU1RSxJQUFBO0lBQU00SjtFQUFJLElBQUtoRixNQUFBO0VBQ3ZCMUQsT0FBQSxDQUFRMEksSUFBQSxFQUFNNUosSUFBQSxFQUFJO0VBQ2xCLE9BQU9tdEIsT0FBQSxDQUFVdmpCLElBQUEsRUFBTSxJQUFJczRCLGFBQUEsQ0FBY3Q5QixNQUFNLEdBQUdBLE1BQUEsQ0FBTzRHLGVBQWU7QUFDMUU7SUNwRXNCaTNCLDhCQUFBLFNBQThCO0VBU2xEM2hDLFlBQ3FCZCxJQUFBLEVBQ25CNk8sTUFBQSxFQUNtQndQLFFBQUEsRUFDVHpVLElBQUEsRUFDUzRCLGVBQUEsR0FBa0IsT0FBSztJQUp2QixLQUFJeEwsSUFBQSxHQUFKQSxJQUFBO0lBRUEsS0FBUXFlLFFBQUEsR0FBUkEsUUFBQTtJQUNULEtBQUl6VSxJQUFBLEdBQUpBLElBQUE7SUFDUyxLQUFlNEIsZUFBQSxHQUFmQSxlQUFBO0lBWGIsS0FBY2szQixjQUFBLEdBQTBCO0lBQ3hDLEtBQVlDLFlBQUEsR0FBd0I7SUFZMUMsS0FBSzl6QixNQUFBLEdBQVMyRCxLQUFBLENBQU1DLE9BQUEsQ0FBUTVELE1BQU0sSUFBSUEsTUFBQSxHQUFTLENBQUNBLE1BQU07O0VBS3hEOFMsUUFBQSxFQUFPO0lBQ0wsT0FBTyxJQUFJL2IsT0FBQSxDQUNULE9BQU9pUyxPQUFBLEVBQVN0USxNQUFBLEtBQVU7TUFDeEIsS0FBS203QixjQUFBLEdBQWlCO1FBQUU3cUIsT0FBQTtRQUFTdFE7TUFBTTtNQUV2QyxJQUFJO1FBQ0YsS0FBS283QixZQUFBLEdBQWUsTUFBTSxLQUFLdGtCLFFBQUEsQ0FBU3BDLFdBQUEsQ0FBWSxLQUFLamMsSUFBSTtRQUM3RCxNQUFNLEtBQUs0aUMsV0FBQSxDQUFXO1FBQ3RCLEtBQUtELFlBQUEsQ0FBYUUsZ0JBQUEsQ0FBaUIsSUFBSTtNQUN4QyxTQUFRbjhCLENBQUEsRUFBUDtRQUNBLEtBQUthLE1BQUEsQ0FBT2IsQ0FBVTtNQUN2QjtJQUNILENBQUM7O0VBSUwsTUFBTW84QixZQUFZMU8sS0FBQSxFQUFnQjtJQUNoQyxNQUFNO01BQUUyTyxXQUFBO01BQWFYLFNBQUE7TUFBV3hhLFFBQUE7TUFBVXRqQixRQUFBO01BQVU3RSxLQUFBO01BQU8wVDtJQUFJLElBQUtpaEIsS0FBQTtJQUNwRSxJQUFJMzBCLEtBQUEsRUFBTztNQUNULEtBQUs4SCxNQUFBLENBQU85SCxLQUFLO01BQ2pCO0lBQ0Q7SUFFRCxNQUFNbUYsTUFBQSxHQUF3QjtNQUM1QjVFLElBQUEsRUFBTSxLQUFLQSxJQUFBO01BQ1gybkIsVUFBQSxFQUFZb2IsV0FBQTtNQUNaWCxTQUFBO01BQ0E5OUIsUUFBQSxFQUFVQSxRQUFBLElBQVk7TUFDdEJzakIsUUFBQSxFQUFVQSxRQUFBLElBQVk7TUFDdEJoZSxJQUFBLEVBQU0sS0FBS0EsSUFBQTtNQUNYNEIsZUFBQSxFQUFpQixLQUFLQTs7SUFHeEIsSUFBSTtNQUNGLEtBQUtxTSxPQUFBLENBQVEsTUFBTSxLQUFLbXJCLFVBQUEsQ0FBVzd2QixJQUFJLEVBQUV2TyxNQUFNLENBQUM7SUFDakQsU0FBUThCLENBQUEsRUFBUDtNQUNBLEtBQUthLE1BQUEsQ0FBT2IsQ0FBVTtJQUN2Qjs7RUFHSHU4QixRQUFReGpDLEtBQUEsRUFBb0I7SUFDMUIsS0FBSzhILE1BQUEsQ0FBTzlILEtBQUs7O0VBR1h1akMsV0FBVzd2QixJQUFBLEVBQW1CO0lBQ3BDLFFBQVFBLElBQUE7V0FDK0I7V0FDckM7UUFDRSxPQUFPbXZCLE9BQUE7V0FDeUI7V0FDbEM7UUFDRSxPQUFPRSxLQUFBO1dBQzJCO1dBQ3BDO1FBQ0UsT0FBT0QsT0FBQTs7UUFFUDdpQyxLQUFBLENBQU0sS0FBS00sSUFBQSxFQUFJOzs7RUFJWDZYLFFBQVF1UCxJQUFBLEVBQW1DO0lBQ25EN2xCLFdBQUEsQ0FBWSxLQUFLbWhDLGNBQUEsRUFBZ0IsK0JBQStCO0lBQ2hFLEtBQUtBLGNBQUEsQ0FBZTdxQixPQUFBLENBQVF1UCxJQUFJO0lBQ2hDLEtBQUs4YixvQkFBQSxDQUFvQjs7RUFHakIzN0IsT0FBTzlILEtBQUEsRUFBWTtJQUMzQjhCLFdBQUEsQ0FBWSxLQUFLbWhDLGNBQUEsRUFBZ0IsK0JBQStCO0lBQ2hFLEtBQUtBLGNBQUEsQ0FBZW43QixNQUFBLENBQU85SCxLQUFLO0lBQ2hDLEtBQUt5akMsb0JBQUEsQ0FBb0I7O0VBR25CQSxxQkFBQSxFQUFvQjtJQUMxQixJQUFJLEtBQUtQLFlBQUEsRUFBYztNQUNyQixLQUFLQSxZQUFBLENBQWFRLGtCQUFBLENBQW1CLElBQUk7SUFDMUM7SUFFRCxLQUFLVCxjQUFBLEdBQWlCO0lBQ3RCLEtBQUtVLE9BQUEsQ0FBTzs7QUFJZjtBQzlGTSxJQUFNQywwQkFBQSxHQUE2QixJQUFJN2dDLEtBQUEsQ0FBTSxLQUFNLEdBQUs7QUFnQ3hELGVBQWU1TSxnQkFDcEJvSyxJQUFBLEVBQ0EySSxRQUFBLEVBQ0EwVixRQUFBLEVBQWdDO0VBRWhDLE1BQU1vRSxZQUFBLEdBQWUzQyxTQUFBLENBQVU5ZixJQUFJO0VBQ25DVSxpQkFBQSxDQUFrQlYsSUFBQSxFQUFNMkksUUFBQSxFQUFVb2hCLHFCQUFxQjtFQUN2RCxNQUFNdVosZ0JBQUEsR0FBbUJ0QixvQkFBQSxDQUFxQnZmLFlBQUEsRUFBY3BFLFFBQVE7RUFDcEUsTUFBTVcsTUFBQSxHQUFTLElBQUl1a0IsY0FBQSxDQUNqQjlnQixZQUFBLEVBQVksa0JBRVo5WixRQUFBLEVBQ0EyNkIsZ0JBQWdCO0VBRWxCLE9BQU90a0IsTUFBQSxDQUFPd2tCLGNBQUEsQ0FBYztBQUM5QjtBQTZCTyxlQUFlMXVDLHdCQUNwQjhVLElBQUEsRUFDQWpCLFFBQUEsRUFDQTBWLFFBQUEsRUFBZ0M7RUFFaEMsTUFBTXRVLFlBQUEsT0FBZTlSLFdBQUEsQ0FBQTZSLGtCQUFBLEVBQW1CRixJQUFJO0VBQzVDbEosaUJBQUEsQ0FBa0JxSixZQUFBLENBQWEvSixJQUFBLEVBQU0ySSxRQUFBLEVBQVVvaEIscUJBQXFCO0VBQ3BFLE1BQU11WixnQkFBQSxHQUFtQnRCLG9CQUFBLENBQXFCajRCLFlBQUEsQ0FBYS9KLElBQUEsRUFBTXFlLFFBQVE7RUFDekUsTUFBTVcsTUFBQSxHQUFTLElBQUl1a0IsY0FBQSxDQUNqQng1QixZQUFBLENBQWEvSixJQUFBLEVBQUksa0JBRWpCMkksUUFBQSxFQUNBMjZCLGdCQUFBLEVBQ0F2NUIsWUFBWTtFQUVkLE9BQU9pVixNQUFBLENBQU93a0IsY0FBQSxDQUFjO0FBQzlCO0FBMkJPLGVBQWVudkMsY0FDcEJ1VixJQUFBLEVBQ0FqQixRQUFBLEVBQ0EwVixRQUFBLEVBQWdDO0VBRWhDLE1BQU10VSxZQUFBLE9BQWU5UixXQUFBLENBQUE2UixrQkFBQSxFQUFtQkYsSUFBSTtFQUM1Q2xKLGlCQUFBLENBQWtCcUosWUFBQSxDQUFhL0osSUFBQSxFQUFNMkksUUFBQSxFQUFVb2hCLHFCQUFxQjtFQUNwRSxNQUFNdVosZ0JBQUEsR0FBbUJ0QixvQkFBQSxDQUFxQmo0QixZQUFBLENBQWEvSixJQUFBLEVBQU1xZSxRQUFRO0VBRXpFLE1BQU1XLE1BQUEsR0FBUyxJQUFJdWtCLGNBQUEsQ0FDakJ4NUIsWUFBQSxDQUFhL0osSUFBQSxFQUFJLGdCQUVqQjJJLFFBQUEsRUFDQTI2QixnQkFBQSxFQUNBdjVCLFlBQVk7RUFFZCxPQUFPaVYsTUFBQSxDQUFPd2tCLGNBQUEsQ0FBYztBQUM5QjtBQU9BLElBQU1ELGNBQUEsR0FBTixjQUE2QmQsOEJBQUEsQ0FBOEI7RUFPekQzaEMsWUFDRWQsSUFBQSxFQUNBNk8sTUFBQSxFQUNpQmxHLFFBQUEsRUFDakIwVixRQUFBLEVBQ0F6VSxJQUFBLEVBQW1CO0lBRW5CLE1BQU01SixJQUFBLEVBQU02TyxNQUFBLEVBQVF3UCxRQUFBLEVBQVV6VSxJQUFJO0lBSmpCLEtBQVFqQixRQUFBLEdBQVJBLFFBQUE7SUFOWCxLQUFVODZCLFVBQUEsR0FBcUI7SUFDL0IsS0FBTUMsTUFBQSxHQUFrQjtJQVU5QixJQUFJSCxjQUFBLENBQWVJLGtCQUFBLEVBQW9CO01BQ3JDSixjQUFBLENBQWVJLGtCQUFBLENBQW1CQyxNQUFBLENBQU07SUFDekM7SUFFREwsY0FBQSxDQUFlSSxrQkFBQSxHQUFxQjs7RUFHdEMsTUFBTUgsZUFBQSxFQUFjO0lBQ2xCLE1BQU0xckIsTUFBQSxHQUFTLE1BQU0sS0FBSzZKLE9BQUEsQ0FBTztJQUNqQ3pnQixPQUFBLENBQVE0VyxNQUFBLEVBQVEsS0FBSzlYLElBQUEsRUFBSTtJQUN6QixPQUFPOFgsTUFBQTs7RUFHVCxNQUFNOHFCLFlBQUEsRUFBVztJQUNmcmhDLFdBQUEsQ0FDRSxLQUFLc04sTUFBQSxDQUFPbkcsTUFBQSxLQUFXLEdBQ3ZCLHdDQUF3QztJQUUxQyxNQUFNdXVCLE9BQUEsR0FBVVUsZ0JBQUEsQ0FBZ0I7SUFDaEMsS0FBSzhMLFVBQUEsR0FBYSxNQUFNLEtBQUtwbEIsUUFBQSxDQUFTd2xCLFVBQUEsQ0FDcEMsS0FBSzdqQyxJQUFBLEVBQ0wsS0FBSzJJLFFBQUEsRUFDTCxLQUFLa0csTUFBQSxDQUFPLElBQ1pvb0IsT0FBTztJQUVULEtBQUt3TSxVQUFBLENBQVdLLGVBQUEsR0FBa0I3TSxPQUFBO0lBU2xDLEtBQUs1WSxRQUFBLENBQVMwbEIsaUJBQUEsQ0FBa0IsS0FBSy9qQyxJQUFJLEVBQUV3aEIsS0FBQSxDQUFNOWEsQ0FBQSxJQUFJO01BQ25ELEtBQUthLE1BQUEsQ0FBT2IsQ0FBQztJQUNmLENBQUM7SUFFRCxLQUFLMlgsUUFBQSxDQUFTMmxCLDRCQUFBLENBQTZCLEtBQUtoa0MsSUFBQSxFQUFNaWtDLFdBQUEsSUFBYztNQUNsRSxJQUFJLENBQUNBLFdBQUEsRUFBYTtRQUNoQixLQUFLMThCLE1BQUEsQ0FDSHpILFlBQUEsQ0FBYSxLQUFLRSxJQUFBLEVBQTRDO01BRWpFO0lBQ0gsQ0FBQztJQUdELEtBQUtra0Msb0JBQUEsQ0FBb0I7O0VBRzNCLElBQUlqTixRQUFBLEVBQU87O0lBQ1QsU0FBT3YxQixFQUFBLFFBQUsraEMsVUFBQSxNQUFZLFFBQUEvaEMsRUFBQSx1QkFBQUEsRUFBQSxDQUFBb2lDLGVBQUEsS0FBbUI7O0VBRzdDRixPQUFBLEVBQU07SUFDSixLQUFLcjhCLE1BQUEsQ0FBT3pILFlBQUEsQ0FBYSxLQUFLRSxJQUFBLEVBQTBDOztFQUcxRW9qQyxRQUFBLEVBQU87SUFDTCxJQUFJLEtBQUtLLFVBQUEsRUFBWTtNQUNuQixLQUFLQSxVQUFBLENBQVd0TCxLQUFBLENBQUs7SUFDdEI7SUFFRCxJQUFJLEtBQUt1TCxNQUFBLEVBQVE7TUFDZmp0QixNQUFBLENBQU9oUCxZQUFBLENBQWEsS0FBS2k4QixNQUFNO0lBQ2hDO0lBRUQsS0FBS0QsVUFBQSxHQUFhO0lBQ2xCLEtBQUtDLE1BQUEsR0FBUztJQUNkSCxjQUFBLENBQWVJLGtCQUFBLEdBQXFCOztFQUc5Qk8scUJBQUEsRUFBb0I7SUFDMUIsTUFBTTdQLElBQUEsR0FBT0EsQ0FBQSxLQUFXOztNQUN0QixLQUFJcmlCLEVBQUEsSUFBQXRRLEVBQUEsUUFBSytoQyxVQUFBLE1BQVksUUFBQS9oQyxFQUFBLHVCQUFBQSxFQUFBLENBQUErVSxNQUFBLE1BQVEsUUFBQXpFLEVBQUEsdUJBQUFBLEVBQUEsQ0FBQW15QixNQUFBLEVBQVE7UUFNbkMsS0FBS1QsTUFBQSxHQUFTanRCLE1BQUEsQ0FBT2pQLFVBQUEsQ0FBVyxNQUFLO1VBQ25DLEtBQUtrOEIsTUFBQSxHQUFTO1VBQ2QsS0FBS244QixNQUFBLENBQ0h6SCxZQUFBLENBQWEsS0FBS0UsSUFBQSxFQUF5QztRQUUvRCxHQUFDO1FBQ0Q7TUFDRDtNQUVELEtBQUswakMsTUFBQSxHQUFTanRCLE1BQUEsQ0FBT2pQLFVBQUEsQ0FBVzZzQixJQUFBLEVBQU1nUCwwQkFBQSxDQUEyQnZnQyxHQUFBLENBQUcsQ0FBRTtJQUN4RTtJQUVBdXhCLElBQUEsQ0FBSTs7O0FBeEdTa1AsY0FBQSxDQUFrQkksa0JBQUEsR0FBMEI7QUM3SzdELElBQU1TLG9CQUFBLEdBQXVCO0FBSTdCLElBQU1DLGtCQUFBLEdBR0YsbUJBQUl4eEIsR0FBQSxDQUFHO0FBRUwsSUFBT3l4QixjQUFBLEdBQVAsY0FBOEI3Qiw4QkFBQSxDQUE4QjtFQUdoRTNoQyxZQUNFZCxJQUFBLEVBQ0FxZSxRQUFBLEVBQ0E3UyxlQUFBLEdBQWtCLE9BQUs7SUFFdkIsTUFDRXhMLElBQUEsRUFDQSxDLHVFQUtDLEVBQ0RxZSxRQUFBLEVBQ0EsUUFDQTdTLGVBQWU7SUFqQm5CLEtBQU95ckIsT0FBQSxHQUFHOztFQXlCVixNQUFNdFYsUUFBQSxFQUFPO0lBQ1gsSUFBSTRpQixZQUFBLEdBQWVGLGtCQUFBLENBQW1CdmhDLEdBQUEsQ0FBSSxLQUFLOUMsSUFBQSxDQUFLMlQsSUFBQSxDQUFJLENBQUU7SUFDMUQsSUFBSSxDQUFDNHdCLFlBQUEsRUFBYztNQUNqQixJQUFJO1FBQ0YsTUFBTUMsa0JBQUEsR0FBcUIsTUFBTUMsaUNBQUEsQ0FDL0IsS0FBS3BtQixRQUFBLEVBQ0wsS0FBS3JlLElBQUk7UUFFWCxNQUFNOFgsTUFBQSxHQUFTMHNCLGtCQUFBLEdBQXFCLE1BQU0sTUFBTTdpQixPQUFBLENBQU8sSUFBSztRQUM1RDRpQixZQUFBLEdBQWVBLENBQUEsS0FBTTMrQixPQUFBLENBQVFpUyxPQUFBLENBQVFDLE1BQU07TUFDNUMsU0FBUXBSLENBQUEsRUFBUDtRQUNBNjlCLFlBQUEsR0FBZUEsQ0FBQSxLQUFNMytCLE9BQUEsQ0FBUTJCLE1BQUEsQ0FBT2IsQ0FBQztNQUN0QztNQUVEMjlCLGtCQUFBLENBQW1CcHhCLEdBQUEsQ0FBSSxLQUFLalQsSUFBQSxDQUFLMlQsSUFBQSxDQUFJLEdBQUk0d0IsWUFBWTtJQUN0RDtJQUlELElBQUksQ0FBQyxLQUFLLzRCLGVBQUEsRUFBaUI7TUFDekI2NEIsa0JBQUEsQ0FBbUJweEIsR0FBQSxDQUFJLEtBQUtqVCxJQUFBLENBQUsyVCxJQUFBLENBQUksR0FBSSxNQUFNL04sT0FBQSxDQUFRaVMsT0FBQSxDQUFRLElBQUksQ0FBQztJQUNyRTtJQUVELE9BQU8wc0IsWUFBQSxDQUFZOztFQUdyQixNQUFNekIsWUFBWTFPLEtBQUEsRUFBZ0I7SUFDaEMsSUFBSUEsS0FBQSxDQUFNamhCLElBQUEsS0FBSSxxQkFBeUM7TUFDckQsT0FBTyxNQUFNMnZCLFdBQUEsQ0FBWTFPLEtBQUs7SUFDL0IsV0FBVUEsS0FBQSxDQUFNamhCLElBQUEsS0FBSSxXQUE0QjtNQUUvQyxLQUFLMEUsT0FBQSxDQUFRLElBQUk7TUFDakI7SUFDRDtJQUVELElBQUl1YyxLQUFBLENBQU02QyxPQUFBLEVBQVM7TUFDakIsTUFBTXJ0QixJQUFBLEdBQU8sTUFBTSxLQUFLNUosSUFBQSxDQUFLdWUsa0JBQUEsQ0FBbUI2VixLQUFBLENBQU02QyxPQUFPO01BQzdELElBQUlydEIsSUFBQSxFQUFNO1FBQ1IsS0FBS0EsSUFBQSxHQUFPQSxJQUFBO1FBQ1osT0FBTyxNQUFNazVCLFdBQUEsQ0FBWTFPLEtBQUs7TUFDL0IsT0FBTTtRQUNMLEtBQUt2YyxPQUFBLENBQVEsSUFBSTtNQUNsQjtJQUNGOztFQUdILE1BQU0rcUIsWUFBQSxFQUFXO0VBRWpCUSxRQUFBLEVBQU87QUFDUjtBQUVNLGVBQWVxQixrQ0FDcEJwbUIsUUFBQSxFQUNBcmUsSUFBQSxFQUFrQjtFQUVsQixNQUFNaUYsR0FBQSxHQUFNeS9CLGtCQUFBLENBQW1CMWtDLElBQUk7RUFDbkMsTUFBTWdVLFdBQUEsR0FBYzJ3QixtQkFBQSxDQUFvQnRtQixRQUFRO0VBQ2hELElBQUksRUFBRSxNQUFNckssV0FBQSxDQUFZWCxZQUFBLENBQVksSUFBSztJQUN2QyxPQUFPO0VBQ1I7RUFDRCxNQUFNbXhCLGtCQUFBLEdBQXNCLE9BQU14d0IsV0FBQSxDQUFZUixJQUFBLENBQUt2TyxHQUFHLE9BQU87RUFDN0QsTUFBTStPLFdBQUEsQ0FBWVAsT0FBQSxDQUFReE8sR0FBRztFQUM3QixPQUFPdS9CLGtCQUFBO0FBQ1Q7QUFFTyxlQUFlSSwwQkFDcEJ2bUIsUUFBQSxFQUNBcmUsSUFBQSxFQUFrQjtFQUVsQixPQUFPMmtDLG1CQUFBLENBQW9CdG1CLFFBQVEsRUFBRS9LLElBQUEsQ0FBS294QixrQkFBQSxDQUFtQjFrQyxJQUFJLEdBQUcsTUFBTTtBQUM1RTtTQUVnQjZrQyx1QkFBQSxFQUFzQjtFQUNwQ1Isa0JBQUEsQ0FBbUJuRSxLQUFBLENBQUs7QUFDMUI7QUFFZ0IsU0FBQW5qQix3QkFDZC9jLElBQUEsRUFDQThYLE1BQUEsRUFBb0Q7RUFFcER1c0Isa0JBQUEsQ0FBbUJweEIsR0FBQSxDQUFJalQsSUFBQSxDQUFLMlQsSUFBQSxDQUFJLEdBQUltRSxNQUFNO0FBQzVDO0FBRUEsU0FBUzZzQixvQkFDUHRtQixRQUFBLEVBQXVDO0VBRXZDLE9BQU92TCxZQUFBLENBQWF1TCxRQUFBLENBQVNDLG9CQUFvQjtBQUNuRDtBQUVBLFNBQVNvbUIsbUJBQW1CMWtDLElBQUEsRUFBa0I7RUFDNUMsT0FBTzhULG1CQUFBLENBQ0xzd0Isb0JBQUEsRUFDQXBrQyxJQUFBLENBQUtrRCxNQUFBLENBQU9nQyxNQUFBLEVBQ1psRixJQUFBLENBQUtTLElBQUk7QUFFYjtTQzdFZ0I1SyxtQkFDZG1LLElBQUEsRUFDQTJJLFFBQUEsRUFDQTBWLFFBQUEsRUFBZ0M7RUFFaEMsT0FBT3ltQixtQkFBQSxDQUFvQjlrQyxJQUFBLEVBQU0ySSxRQUFBLEVBQVUwVixRQUFRO0FBQ3JEO0FBRU8sZUFBZXltQixvQkFDcEI5a0MsSUFBQSxFQUNBMkksUUFBQSxFQUNBMFYsUUFBQSxFQUFnQztFQUVoQyxNQUFNb0UsWUFBQSxHQUFlM0MsU0FBQSxDQUFVOWYsSUFBSTtFQUNuQ1UsaUJBQUEsQ0FBa0JWLElBQUEsRUFBTTJJLFFBQUEsRUFBVW9oQixxQkFBcUI7RUFJdkQsTUFBTXRILFlBQUEsQ0FBYXZILHNCQUFBO0VBQ25CLE1BQU1vb0IsZ0JBQUEsR0FBbUJ0QixvQkFBQSxDQUFxQnZmLFlBQUEsRUFBY3BFLFFBQVE7RUFDcEUsTUFBTXVtQix5QkFBQSxDQUEwQnRCLGdCQUFBLEVBQWtCN2dCLFlBQVk7RUFFOUQsT0FBTzZnQixnQkFBQSxDQUFpQnlCLGFBQUEsQ0FDdEJ0aUIsWUFBQSxFQUNBOVosUUFBQSxFQUFRO0FBR1o7U0FvQ2dCNVQsMkJBQ2Q2VSxJQUFBLEVBQ0FqQixRQUFBLEVBQ0EwVixRQUFBLEVBQWdDO0VBRWhDLE9BQU8ybUIsMkJBQUEsQ0FDTHA3QixJQUFBLEVBQ0FqQixRQUFBLEVBQ0EwVixRQUFRO0FBRVo7QUFDTyxlQUFlMm1CLDRCQUNwQnA3QixJQUFBLEVBQ0FqQixRQUFBLEVBQ0EwVixRQUFBLEVBQWdDO0VBRWhDLE1BQU10VSxZQUFBLE9BQWU5UixXQUFBLENBQUE2UixrQkFBQSxFQUFtQkYsSUFBSTtFQUM1Q2xKLGlCQUFBLENBQWtCcUosWUFBQSxDQUFhL0osSUFBQSxFQUFNMkksUUFBQSxFQUFVb2hCLHFCQUFxQjtFQUlwRSxNQUFNaGdCLFlBQUEsQ0FBYS9KLElBQUEsQ0FBS2tiLHNCQUFBO0VBRXhCLE1BQU1vb0IsZ0JBQUEsR0FBbUJ0QixvQkFBQSxDQUFxQmo0QixZQUFBLENBQWEvSixJQUFBLEVBQU1xZSxRQUFRO0VBQ3pFLE1BQU11bUIseUJBQUEsQ0FBMEJ0QixnQkFBQSxFQUFrQnY1QixZQUFBLENBQWEvSixJQUFJO0VBRW5FLE1BQU1pM0IsT0FBQSxHQUFVLE1BQU1nTyxzQkFBQSxDQUF1Qmw3QixZQUFZO0VBQ3pELE9BQU91NUIsZ0JBQUEsQ0FBaUJ5QixhQUFBLENBQ3RCaDdCLFlBQUEsQ0FBYS9KLElBQUEsRUFDYjJJLFFBQUEsRUFBUSxxQkFFUnN1QixPQUFPO0FBRVg7U0FnQ2dCM2lDLGlCQUNkc1YsSUFBQSxFQUNBakIsUUFBQSxFQUNBMFYsUUFBQSxFQUFnQztFQUVoQyxPQUFPNm1CLGlCQUFBLENBQWtCdDdCLElBQUEsRUFBTWpCLFFBQUEsRUFBVTBWLFFBQVE7QUFDbkQ7QUFDTyxlQUFlNm1CLGtCQUNwQnQ3QixJQUFBLEVBQ0FqQixRQUFBLEVBQ0EwVixRQUFBLEVBQWdDO0VBRWhDLE1BQU10VSxZQUFBLE9BQWU5UixXQUFBLENBQUE2UixrQkFBQSxFQUFtQkYsSUFBSTtFQUM1Q2xKLGlCQUFBLENBQWtCcUosWUFBQSxDQUFhL0osSUFBQSxFQUFNMkksUUFBQSxFQUFVb2hCLHFCQUFxQjtFQUlwRSxNQUFNaGdCLFlBQUEsQ0FBYS9KLElBQUEsQ0FBS2tiLHNCQUFBO0VBRXhCLE1BQU1vb0IsZ0JBQUEsR0FBbUJ0QixvQkFBQSxDQUFxQmo0QixZQUFBLENBQWEvSixJQUFBLEVBQU1xZSxRQUFRO0VBQ3pFLE1BQU15TyxtQkFBQSxDQUFvQixPQUFPL2lCLFlBQUEsRUFBY3BCLFFBQUEsQ0FBU3NHLFVBQVU7RUFDbEUsTUFBTTIxQix5QkFBQSxDQUEwQnRCLGdCQUFBLEVBQWtCdjVCLFlBQUEsQ0FBYS9KLElBQUk7RUFFbkUsTUFBTWkzQixPQUFBLEdBQVUsTUFBTWdPLHNCQUFBLENBQXVCbDdCLFlBQVk7RUFDekQsT0FBT3U1QixnQkFBQSxDQUFpQnlCLGFBQUEsQ0FDdEJoN0IsWUFBQSxDQUFhL0osSUFBQSxFQUNiMkksUUFBQSxFQUFRLG1CQUVSc3VCLE9BQU87QUFFWDtBQTBDTyxlQUFlcGpDLGtCQUNwQm1NLElBQUEsRUFDQXFlLFFBQUEsRUFBZ0M7RUFFaEMsTUFBTXlCLFNBQUEsQ0FBVTlmLElBQUksRUFBRWtiLHNCQUFBO0VBQ3RCLE9BQU9pcUIsa0JBQUEsQ0FBbUJubEMsSUFBQSxFQUFNcWUsUUFBQSxFQUFVLEtBQUs7QUFDakQ7QUFFTyxlQUFlOG1CLG1CQUNwQm5sQyxJQUFBLEVBQ0FvbEMsY0FBQSxFQUNBNTVCLGVBQUEsR0FBa0IsT0FBSztFQUV2QixNQUFNaVgsWUFBQSxHQUFlM0MsU0FBQSxDQUFVOWYsSUFBSTtFQUNuQyxNQUFNcWUsUUFBQSxHQUFXMmpCLG9CQUFBLENBQXFCdmYsWUFBQSxFQUFjMmlCLGNBQWM7RUFDbEUsTUFBTXBtQixNQUFBLEdBQVMsSUFBSXNsQixjQUFBLENBQWU3aEIsWUFBQSxFQUFjcEUsUUFBQSxFQUFVN1MsZUFBZTtFQUN6RSxNQUFNc00sTUFBQSxHQUFTLE1BQU1rSCxNQUFBLENBQU8yQyxPQUFBLENBQU87RUFFbkMsSUFBSTdKLE1BQUEsSUFBVSxDQUFDdE0sZUFBQSxFQUFpQjtJQUM5QixPQUFPc00sTUFBQSxDQUFPbE8sSUFBQSxDQUFLa0ksZ0JBQUE7SUFDbkIsTUFBTTJRLFlBQUEsQ0FBYWpVLHFCQUFBLENBQXNCc0osTUFBQSxDQUFPbE8sSUFBb0I7SUFDcEUsTUFBTTZZLFlBQUEsQ0FBYXRGLGdCQUFBLENBQWlCLE1BQU1pb0IsY0FBYztFQUN6RDtFQUVELE9BQU90dEIsTUFBQTtBQUNUO0FBRUEsZUFBZW10Qix1QkFBdUJyN0IsSUFBQSxFQUFrQjtFQUN0RCxNQUFNcXRCLE9BQUEsR0FBVVUsZ0JBQUEsQ0FBaUIsR0FBRy90QixJQUFBLENBQUtzRSxHQUFBLEtBQVE7RUFDakR0RSxJQUFBLENBQUtrSSxnQkFBQSxHQUFtQm1sQixPQUFBO0VBQ3hCLE1BQU1ydEIsSUFBQSxDQUFLNUosSUFBQSxDQUFLbWQsZ0JBQUEsQ0FBaUJ2VCxJQUFJO0VBQ3JDLE1BQU1BLElBQUEsQ0FBSzVKLElBQUEsQ0FBS3dPLHFCQUFBLENBQXNCNUUsSUFBSTtFQUMxQyxPQUFPcXRCLE9BQUE7QUFDVDtBQzlSQSxJQUFNb08sbUNBQUEsR0FBc0MsS0FBSyxLQUFLO0lBRXpDQyxnQkFBQSxTQUFnQjtFQU8zQnhrQyxZQUE2QmQsSUFBQSxFQUFrQjtJQUFsQixLQUFJQSxJQUFBLEdBQUpBLElBQUE7SUFOWixLQUFBdWxDLGVBQUEsR0FBK0IsbUJBQUkzWSxHQUFBLENBQUc7SUFDdEMsS0FBQTRZLFNBQUEsR0FBb0MsbUJBQUk1WSxHQUFBLENBQUc7SUFDbEQsS0FBbUI2WSxtQkFBQSxHQUFxQjtJQUN4QyxLQUEyQkMsMkJBQUEsR0FBRztJQUNoQyxLQUFBQyxzQkFBQSxHQUF5QnA4QixJQUFBLENBQUtnRCxHQUFBLENBQUc7O0VBSXpDczJCLGlCQUFpQitDLGlCQUFBLEVBQW9DO0lBQ25ELEtBQUtKLFNBQUEsQ0FBVXRnQixHQUFBLENBQUkwZ0IsaUJBQWlCO0lBRXBDLElBQ0UsS0FBS0gsbUJBQUEsSUFDTCxLQUFLSSxrQkFBQSxDQUFtQixLQUFLSixtQkFBQSxFQUFxQkcsaUJBQWlCLEdBQ25FO01BQ0EsS0FBS0UsY0FBQSxDQUFlLEtBQUtMLG1CQUFBLEVBQXFCRyxpQkFBaUI7TUFDL0QsS0FBS0csZ0JBQUEsQ0FBaUIsS0FBS04sbUJBQW1CO01BQzlDLEtBQUtBLG1CQUFBLEdBQXNCO0lBQzVCOztFQUdIdEMsbUJBQW1CeUMsaUJBQUEsRUFBb0M7SUFDckQsS0FBS0osU0FBQSxDQUFVM3pCLE1BQUEsQ0FBTyt6QixpQkFBaUI7O0VBR3pDSSxRQUFRNVIsS0FBQSxFQUFnQjtJQUV0QixJQUFJLEtBQUs2UixtQkFBQSxDQUFvQjdSLEtBQUssR0FBRztNQUNuQyxPQUFPO0lBQ1I7SUFFRCxJQUFJOFIsT0FBQSxHQUFVO0lBQ2QsS0FBS1YsU0FBQSxDQUFVcEYsT0FBQSxDQUFRK0YsUUFBQSxJQUFXO01BQ2hDLElBQUksS0FBS04sa0JBQUEsQ0FBbUJ6UixLQUFBLEVBQU8rUixRQUFRLEdBQUc7UUFDNUNELE9BQUEsR0FBVTtRQUNWLEtBQUtKLGNBQUEsQ0FBZTFSLEtBQUEsRUFBTytSLFFBQVE7UUFDbkMsS0FBS0osZ0JBQUEsQ0FBaUIzUixLQUFLO01BQzVCO0lBQ0gsQ0FBQztJQUVELElBQUksS0FBS3NSLDJCQUFBLElBQStCLENBQUNVLGVBQUEsQ0FBZ0JoUyxLQUFLLEdBQUc7TUFHL0QsT0FBTzhSLE9BQUE7SUFDUjtJQUVELEtBQUtSLDJCQUFBLEdBQThCO0lBR25DLElBQUksQ0FBQ1EsT0FBQSxFQUFTO01BQ1osS0FBS1QsbUJBQUEsR0FBc0JyUixLQUFBO01BQzNCOFIsT0FBQSxHQUFVO0lBQ1g7SUFFRCxPQUFPQSxPQUFBOztFQUdESixlQUFlMVIsS0FBQSxFQUFrQitSLFFBQUEsRUFBMkI7O0lBQ2xFLElBQUkvUixLQUFBLENBQU0zMEIsS0FBQSxJQUFTLENBQUM0bUMsbUJBQUEsQ0FBb0JqUyxLQUFLLEdBQUc7TUFDOUMsTUFBTW4wQixJQUFBLEtBQ0h5QixFQUFBLEdBQUEweUIsS0FBQSxDQUFNMzBCLEtBQUEsQ0FBTVEsSUFBQSxNQUFJLFFBQUF5QixFQUFBLHVCQUFBQSxFQUFBLENBQUU0RSxLQUFBLENBQU0sT0FBTyxFQUFFO01BRXBDNi9CLFFBQUEsQ0FBU2xELE9BQUEsQ0FBUW5qQyxZQUFBLENBQWEsS0FBS0UsSUFBQSxFQUFNQyxJQUFJLENBQUM7SUFDL0MsT0FBTTtNQUNMa21DLFFBQUEsQ0FBU3JELFdBQUEsQ0FBWTFPLEtBQUs7SUFDM0I7O0VBR0t5UixtQkFDTnpSLEtBQUEsRUFDQStSLFFBQUEsRUFBMkI7SUFFM0IsTUFBTUcsY0FBQSxHQUNKSCxRQUFBLENBQVNsUCxPQUFBLEtBQVksUUFDcEIsQ0FBQyxDQUFDN0MsS0FBQSxDQUFNNkMsT0FBQSxJQUFXN0MsS0FBQSxDQUFNNkMsT0FBQSxLQUFZa1AsUUFBQSxDQUFTbFAsT0FBQTtJQUNqRCxPQUFPa1AsUUFBQSxDQUFTdDNCLE1BQUEsQ0FBTzRHLFFBQUEsQ0FBUzJlLEtBQUEsQ0FBTWpoQixJQUFJLEtBQUttekIsY0FBQTs7RUFHekNMLG9CQUFvQjdSLEtBQUEsRUFBZ0I7SUFDMUMsSUFDRTdxQixJQUFBLENBQUtnRCxHQUFBLENBQUcsSUFBSyxLQUFLbzVCLHNCQUFBLElBQ2xCTixtQ0FBQSxFQUNBO01BQ0EsS0FBS0UsZUFBQSxDQUFnQnJGLEtBQUEsQ0FBSztJQUMzQjtJQUVELE9BQU8sS0FBS3FGLGVBQUEsQ0FBZ0JyWSxHQUFBLENBQUlxWixRQUFBLENBQVNuUyxLQUFLLENBQUM7O0VBR3pDMlIsaUJBQWlCM1IsS0FBQSxFQUFnQjtJQUN2QyxLQUFLbVIsZUFBQSxDQUFnQnJnQixHQUFBLENBQUlxaEIsUUFBQSxDQUFTblMsS0FBSyxDQUFDO0lBQ3hDLEtBQUt1UixzQkFBQSxHQUF5QnA4QixJQUFBLENBQUtnRCxHQUFBLENBQUc7O0FBRXpDO0FBRUQsU0FBU2c2QixTQUFTNy9CLENBQUEsRUFBWTtFQUM1QixPQUFPLENBQUNBLENBQUEsQ0FBRXlNLElBQUEsRUFBTXpNLENBQUEsQ0FBRXV3QixPQUFBLEVBQVN2d0IsQ0FBQSxDQUFFMDdCLFNBQUEsRUFBVzE3QixDQUFBLENBQUVwQyxRQUFRLEVBQUV1SyxNQUFBLENBQU8yM0IsQ0FBQSxJQUFLQSxDQUFDLEVBQUVqdkIsSUFBQSxDQUFLLEdBQUc7QUFDN0U7QUFFQSxTQUFTOHVCLG9CQUFvQjtFQUFFbHpCLElBQUE7RUFBTTFUO0FBQUssR0FBYTtFQUNyRCxPQUNFMFQsSUFBQSxLQUE4QixjQUM5QjFULEtBQUEsS0FBSyxRQUFMQSxLQUFBLEtBQUssa0JBQUxBLEtBQUEsQ0FBT1EsSUFBQSxNQUFTLFFBQVE7QUFFNUI7QUFFQSxTQUFTbW1DLGdCQUFnQmhTLEtBQUEsRUFBZ0I7RUFDdkMsUUFBUUEsS0FBQSxDQUFNamhCLElBQUE7U0FDNEI7U0FDSDtTQUNyQztNQUNFLE9BQU87U0FDVDtNQUNFLE9BQU9rekIsbUJBQUEsQ0FBb0JqUyxLQUFLOztNQUVoQyxPQUFPOztBQUViO0FDeEhPLGVBQWVxUyxrQkFDcEJ6bUMsSUFBQSxFQUNBcUUsT0FBQSxHQUFtQyxJQUFFO0VBRXJDLE9BQU9FLGtCQUFBLENBQ0x2RSxJQUFBLEVBR0EsdUJBQUFxRSxPQUFPO0FBRVg7QUNoQkEsSUFBTXFpQyxnQkFBQSxHQUFtQjtBQUN6QixJQUFNQyxVQUFBLEdBQWE7QUFFWixlQUFlQyxnQkFBZ0I1bUMsSUFBQSxFQUFrQjtFQUV0RCxJQUFJQSxJQUFBLENBQUtrRCxNQUFBLENBQU9FLFFBQUEsRUFBVTtJQUN4QjtFQUNEO0VBRUQsTUFBTTtJQUFFeWpDO0VBQWlCLElBQUssTUFBTUosaUJBQUEsQ0FBa0J6bUMsSUFBSTtFQUUxRCxXQUFXOG1DLE1BQUEsSUFBVUQsaUJBQUEsRUFBbUI7SUFDdEMsSUFBSTtNQUNGLElBQUlFLFdBQUEsQ0FBWUQsTUFBTSxHQUFHO1FBQ3ZCO01BQ0Q7SUFDRixTQUFPcGxDLEVBQUEsRUFBTixDQUVEO0VBQ0Y7RUFHRGhDLEtBQUEsQ0FBTU0sSUFBQSxFQUFJO0FBQ1o7QUFFQSxTQUFTK21DLFlBQVkzWixRQUFBLEVBQWdCO0VBQ25DLE1BQU00WixVQUFBLEdBQWF4bEMsY0FBQSxDQUFjO0VBQ2pDLE1BQU07SUFBRU8sUUFBQTtJQUFVa2xDO0VBQVEsSUFBSyxJQUFJQyxHQUFBLENBQUlGLFVBQVU7RUFDakQsSUFBSTVaLFFBQUEsQ0FBUzlwQixVQUFBLENBQVcscUJBQXFCLEdBQUc7SUFDOUMsTUFBTTZqQyxLQUFBLEdBQVEsSUFBSUQsR0FBQSxDQUFJOVosUUFBUTtJQUU5QixJQUFJK1osS0FBQSxDQUFNRixRQUFBLEtBQWEsTUFBTUEsUUFBQSxLQUFhLElBQUk7TUFFNUMsT0FDRWxsQyxRQUFBLEtBQWEsdUJBQ2JxckIsUUFBQSxDQUFTM21CLE9BQUEsQ0FBUSx1QkFBdUIsRUFBRSxNQUN4Q3VnQyxVQUFBLENBQVd2Z0MsT0FBQSxDQUFRLHVCQUF1QixFQUFFO0lBRWpEO0lBRUQsT0FBTzFFLFFBQUEsS0FBYSx1QkFBdUJvbEMsS0FBQSxDQUFNRixRQUFBLEtBQWFBLFFBQUE7RUFDL0Q7RUFFRCxJQUFJLENBQUNOLFVBQUEsQ0FBV3R3QixJQUFBLENBQUt0VSxRQUFRLEdBQUc7SUFDOUIsT0FBTztFQUNSO0VBRUQsSUFBSTJrQyxnQkFBQSxDQUFpQnJ3QixJQUFBLENBQUsrVyxRQUFRLEdBQUc7SUFHbkMsT0FBTzZaLFFBQUEsS0FBYTdaLFFBQUE7RUFDckI7RUFHRCxNQUFNZ2Esb0JBQUEsR0FBdUJoYSxRQUFBLENBQVMzbUIsT0FBQSxDQUFRLE9BQU8sS0FBSztFQUcxRCxNQUFNd1AsRUFBQSxHQUFLLElBQUlveEIsTUFBQSxDQUNiLFlBQVlELG9CQUFBLEdBQXVCLE1BQU1BLG9CQUFBLEdBQXVCLE1BQ2hFLEdBQUc7RUFFTCxPQUFPbnhCLEVBQUEsQ0FBR0ksSUFBQSxDQUFLNHdCLFFBQVE7QUFDekI7QUM3REEsSUFBTUssZUFBQSxHQUFrQixJQUFJOWtDLEtBQUEsQ0FBTSxLQUFPLEdBQUs7QUFNOUMsU0FBUytrQyx5QkFBQSxFQUF3QjtFQUkvQixNQUFNQyxNQUFBLEdBQVM1TyxPQUFBLENBQU8sRUFBRzZPLE1BQUE7RUFFekIsSUFBSUQsTUFBQSxhQUFBQSxNQUFBLEtBQU0sa0JBQU5BLE1BQUEsQ0FBUUUsQ0FBQSxFQUFHO0lBRWIsV0FBV0MsSUFBQSxJQUFRdm5DLE1BQUEsQ0FBT3kwQixJQUFBLENBQUsyUyxNQUFBLENBQU9FLENBQUMsR0FBRztNQUV4Q0YsTUFBQSxDQUFPRSxDQUFBLENBQUVDLElBQUEsRUFBTUMsQ0FBQSxHQUFJSixNQUFBLENBQU9FLENBQUEsQ0FBRUMsSUFBQSxFQUFNQyxDQUFBLElBQUs7TUFFdkNKLE1BQUEsQ0FBT0UsQ0FBQSxDQUFFQyxJQUFBLEVBQU1FLENBQUEsR0FBSUwsTUFBQSxDQUFPRSxDQUFBLENBQUVDLElBQUEsRUFBTUUsQ0FBQSxJQUFLO01BRXZDTCxNQUFBLENBQU9FLENBQUEsQ0FBRUMsSUFBQSxFQUFNQyxDQUFBLEdBQUksQ0FBQyxHQUFHSixNQUFBLENBQU9FLENBQUEsQ0FBRUMsSUFBQSxFQUFNRSxDQUFDO01BRXZDLElBQUlMLE1BQUEsQ0FBT00sRUFBQSxFQUFJO1FBQ2IsU0FBUzd0QixDQUFBLEdBQUksR0FBR0EsQ0FBQSxHQUFJdXRCLE1BQUEsQ0FBT00sRUFBQSxDQUFHcC9CLE1BQUEsRUFBUXVSLENBQUEsSUFBSztVQUV6Q3V0QixNQUFBLENBQU9NLEVBQUEsQ0FBRzd0QixDQUFBLElBQUs7UUFDaEI7TUFDRjtJQUNGO0VBQ0Y7QUFDSDtBQUVBLFNBQVM4dEIsU0FBUy9uQyxJQUFBLEVBQWtCO0VBQ2xDLE9BQU8sSUFBSTRGLE9BQUEsQ0FBOEIsQ0FBQ2lTLE9BQUEsRUFBU3RRLE1BQUEsS0FBVTs7SUFFM0QsU0FBU3lnQyxlQUFBLEVBQWM7TUFHckJULHdCQUFBLENBQXdCO01BQ3hCVSxJQUFBLENBQUt0SixJQUFBLENBQUssZ0JBQWdCO1FBQ3hCcHRCLFFBQUEsRUFBVUEsQ0FBQSxLQUFLO1VBQ2JzRyxPQUFBLENBQVFvd0IsSUFBQSxDQUFLQyxPQUFBLENBQVFDLFVBQUEsQ0FBVSxDQUFFOztRQUVuQ0MsU0FBQSxFQUFXQSxDQUFBLEtBQUs7VUFPZGIsd0JBQUEsQ0FBd0I7VUFDeEJoZ0MsTUFBQSxDQUFPekgsWUFBQSxDQUFhRSxJQUFBLEVBQUkseUJBQXVDOztRQUVqRXE0QixPQUFBLEVBQVNpUCxlQUFBLENBQWdCeGtDLEdBQUEsQ0FBRztNQUM3Qjs7SUFHSCxLQUFJa1AsRUFBQSxJQUFBdFEsRUFBQSxHQUFBazNCLE9BQUEsQ0FBTyxFQUFHcVAsSUFBQSxNQUFNLFFBQUF2bUMsRUFBQSx1QkFBQUEsRUFBQSxDQUFBd21DLE9BQUEsTUFBUyxRQUFBbDJCLEVBQUEsdUJBQUFBLEVBQUEsQ0FBQXEyQixNQUFBLEVBQVE7TUFFbkN4d0IsT0FBQSxDQUFRb3dCLElBQUEsQ0FBS0MsT0FBQSxDQUFRQyxVQUFBLENBQVUsQ0FBRTtJQUNsQyxXQUFVLENBQUMsR0FBQ2wyQixFQUFBLEdBQUEybUIsT0FBQSxDQUFPLEVBQUdxUCxJQUFBLE1BQUksUUFBQWgyQixFQUFBLHVCQUFBQSxFQUFBLENBQUUwc0IsSUFBQSxHQUFNO01BRWpDcUosY0FBQSxDQUFjO0lBQ2YsT0FBTTtNQU1MLE1BQU1NLE1BQUEsR0FBUzNuQixxQkFBQSxDQUF5QixXQUFXO01BRW5EaVksT0FBQSxDQUFPLEVBQUcwUCxNQUFBLElBQVUsTUFBSztRQUV2QixJQUFJLENBQUMsQ0FBQ0wsSUFBQSxDQUFLdEosSUFBQSxFQUFNO1VBQ2ZxSixjQUFBLENBQWM7UUFDZixPQUFNO1VBRUx6Z0MsTUFBQSxDQUFPekgsWUFBQSxDQUFhRSxJQUFBLEVBQUkseUJBQXVDO1FBQ2hFO01BQ0g7TUFFQSxPQUFPbWdCLE9BQUEsQ0FDSSw0Q0FBNENtb0IsTUFBQSxFQUFRLEVBQzVEOW1CLEtBQUEsQ0FBTTlhLENBQUEsSUFBS2EsTUFBQSxDQUFPYixDQUFDLENBQUM7SUFDeEI7RUFDSCxDQUFDLEVBQUU4YSxLQUFBLENBQU0vaEIsS0FBQSxJQUFRO0lBRWY4b0MsZ0JBQUEsR0FBbUI7SUFDbkIsTUFBTTlvQyxLQUFBO0VBQ1IsQ0FBQztBQUNIO0FBRUEsSUFBSThvQyxnQkFBQSxHQUF5RDtBQUN2RCxTQUFVQyxVQUFVeG9DLElBQUEsRUFBa0I7RUFDMUN1b0MsZ0JBQUEsR0FBbUJBLGdCQUFBLElBQW9CUixRQUFBLENBQVMvbkMsSUFBSTtFQUNwRCxPQUFPdW9DLGdCQUFBO0FBQ1Q7QUMzRkEsSUFBTUUsWUFBQSxHQUFlLElBQUlqbUMsS0FBQSxDQUFNLEtBQU0sSUFBSztBQUMxQyxJQUFNa21DLFdBQUEsR0FBYztBQUNwQixJQUFNQyxvQkFBQSxHQUF1QjtBQUU3QixJQUFNQyxpQkFBQSxHQUFvQjtFQUN4QnZrQixLQUFBLEVBQU87SUFDTEUsUUFBQSxFQUFVO0lBQ1Z0TixHQUFBLEVBQUs7SUFDTHVOLEtBQUEsRUFBTztJQUNQcWtCLE1BQUEsRUFBUTtFQUNUO0VBQ0QsZUFBZTtFQUNmQyxRQUFBLEVBQVU7O0FBS1osSUFBTUMsZ0JBQUEsR0FBbUIsbUJBQUlsMkIsR0FBQSxDQUFJLENBQy9CLG1DQUF5QixHQUFHLEdBQzVCLENBQUMsa0RBQWtELEdBQUcsR0FDdEQsQ0FBQywrQ0FBK0MsR0FBRyxFQUNwRDtBQUVELFNBQVNtMkIsYUFBYWhwQyxJQUFBLEVBQWtCO0VBQ3RDLE1BQU1rRCxNQUFBLEdBQVNsRCxJQUFBLENBQUtrRCxNQUFBO0VBQ3BCaEMsT0FBQSxDQUFRZ0MsTUFBQSxDQUFPdVosVUFBQSxFQUFZemMsSUFBQSxFQUFJO0VBQy9CLE1BQU1xRCxHQUFBLEdBQU1ILE1BQUEsQ0FBT0UsUUFBQSxHQUNmSCxZQUFBLENBQWFDLE1BQUEsRUFBUXlsQyxvQkFBb0IsSUFDekMsV0FBVzNvQyxJQUFBLENBQUtrRCxNQUFBLENBQU91WixVQUFBLElBQWNpc0IsV0FBQTtFQUV6QyxNQUFNOWpDLE1BQUEsR0FBaUM7SUFDckNNLE1BQUEsRUFBUWhDLE1BQUEsQ0FBT2dDLE1BQUE7SUFDZjFFLE9BQUEsRUFBU1IsSUFBQSxDQUFLUyxJQUFBO0lBQ2QrbEMsQ0FBQSxFQUFHbm5DLFVBQUEsQ0FBQUM7O0VBRUwsTUFBTTJwQyxHQUFBLEdBQU1GLGdCQUFBLENBQWlCam1DLEdBQUEsQ0FBSTlDLElBQUEsQ0FBS2tELE1BQUEsQ0FBT29DLE9BQU87RUFDcEQsSUFBSTJqQyxHQUFBLEVBQUs7SUFDUHJrQyxNQUFBLENBQU9xa0MsR0FBQSxHQUFNQSxHQUFBO0VBQ2Q7RUFDRCxNQUFNN3hCLFVBQUEsR0FBYXBYLElBQUEsQ0FBS29mLGNBQUEsQ0FBYztFQUN0QyxJQUFJaEksVUFBQSxDQUFXMU8sTUFBQSxFQUFRO0lBQ3JCOUQsTUFBQSxDQUFPc2tDLEVBQUEsR0FBSzl4QixVQUFBLENBQVdHLElBQUEsQ0FBSyxHQUFHO0VBQ2hDO0VBQ0QsT0FBTyxHQUFHbFUsR0FBQSxRQUFPcEwsV0FBQSxDQUFBK00sV0FBQSxFQUFZSixNQUFNLEVBQUU1RCxLQUFBLENBQU0sQ0FBQztBQUM5QztBQUVPLGVBQWVtb0MsWUFDcEJucEMsSUFBQSxFQUFrQjtFQUVsQixNQUFNb3BDLE9BQUEsR0FBVSxNQUFNWixTQUFBLENBQXFCeG9DLElBQUk7RUFDL0MsTUFBTXFwQyxLQUFBLEdBQU96USxPQUFBLENBQU8sRUFBR3FQLElBQUE7RUFDdkIvbUMsT0FBQSxDQUFRbW9DLEtBQUEsRUFBTXJwQyxJQUFBLEVBQUk7RUFDbEIsT0FBT29wQyxPQUFBLENBQVEvTyxJQUFBLENBQ2I7SUFDRWlQLEtBQUEsRUFBT3p5QixRQUFBLENBQVNsUyxJQUFBO0lBQ2hCdEIsR0FBQSxFQUFLMmxDLFlBQUEsQ0FBYWhwQyxJQUFJO0lBQ3RCdXBDLHFCQUFBLEVBQXVCRixLQUFBLENBQUtuQixPQUFBLENBQVFzQiwyQkFBQTtJQUNwQ0MsVUFBQSxFQUFZYixpQkFBQTtJQUNaYyxTQUFBLEVBQVc7RUFDWixHQUNBQyxNQUFBLElBQ0MsSUFBSS9qQyxPQUFBLENBQVEsT0FBT2lTLE9BQUEsRUFBU3RRLE1BQUEsS0FBVTtJQUNwQyxNQUFNb2lDLE1BQUEsQ0FBT0MsT0FBQSxDQUFRO01BRW5CQyxjQUFBLEVBQWdCO0lBQ2pCO0lBRUQsTUFBTUMsWUFBQSxHQUFlaHFDLFlBQUEsQ0FDbkJFLElBQUEsRUFBSTtJQUtOLE1BQU0rcEMsaUJBQUEsR0FBb0JuUixPQUFBLENBQU8sRUFBR3B4QixVQUFBLENBQVcsTUFBSztNQUNsREQsTUFBQSxDQUFPdWlDLFlBQVk7SUFDckIsR0FBR3JCLFlBQUEsQ0FBYTNsQyxHQUFBLENBQUcsQ0FBRTtJQUVyQixTQUFTa25DLHFCQUFBLEVBQW9CO01BQzNCcFIsT0FBQSxDQUFPLEVBQUdueEIsWUFBQSxDQUFhc2lDLGlCQUFpQjtNQUN4Q2x5QixPQUFBLENBQVE4eEIsTUFBTTs7SUFJaEJBLE1BQUEsQ0FBT00sSUFBQSxDQUFLRCxvQkFBb0IsRUFBRWxyQixJQUFBLENBQUtrckIsb0JBQUEsRUFBc0IsTUFBSztNQUNoRXppQyxNQUFBLENBQU91aUMsWUFBWTtJQUNyQixDQUFDO0dBQ0YsQ0FBQztBQUVSO0FDekZBLElBQU1JLGtCQUFBLEdBQXFCO0VBQ3pCdm9DLFFBQUEsRUFBVTtFQUNWd29DLFNBQUEsRUFBVztFQUNYQyxTQUFBLEVBQVc7RUFDWEMsT0FBQSxFQUFTOztBQUdYLElBQU1DLGFBQUEsR0FBZ0I7QUFDdEIsSUFBTUMsY0FBQSxHQUFpQjtBQUN2QixJQUFNQyxZQUFBLEdBQWU7QUFFckIsSUFBTUMsaUJBQUEsR0FBb0I7SUFFYkMsU0FBQSxTQUFTO0VBR3BCNXBDLFlBQXFCNnBDLE9BQUEsRUFBcUI7SUFBckIsS0FBTWwwQixNQUFBLEdBQU5rMEIsT0FBQTtJQUZyQixLQUFlN0csZUFBQSxHQUFrQjs7RUFJakMzTCxNQUFBLEVBQUs7SUFDSCxJQUFJLEtBQUsxaEIsTUFBQSxFQUFRO01BQ2YsSUFBSTtRQUNGLEtBQUtBLE1BQUEsQ0FBTzBoQixLQUFBLENBQUs7TUFDbEIsU0FBUXp4QixDQUFBLEVBQVAsQ0FBVTtJQUNiOztBQUVKO0FBRWUsU0FBQWtrQyxNQUNkNXFDLElBQUEsRUFDQXFELEdBQUEsRUFDQTZRLEtBQUEsRUFDQXNRLEtBQUEsR0FBUThsQixhQUFBLEVBQ1J6QixNQUFBLEdBQVMwQixjQUFBLEVBQWM7RUFFdkIsTUFBTXR6QixHQUFBLEdBQU1sVSxJQUFBLENBQUt5SixHQUFBLEVBQUtpSyxNQUFBLENBQU9vMEIsTUFBQSxDQUFPQyxXQUFBLEdBQWNqQyxNQUFBLElBQVUsR0FBRyxDQUFDLEVBQUV6OUIsUUFBQSxDQUFRO0VBQzFFLE1BQU15WixJQUFBLEdBQU85aEIsSUFBQSxDQUFLeUosR0FBQSxFQUFLaUssTUFBQSxDQUFPbzBCLE1BQUEsQ0FBT0UsVUFBQSxHQUFhdm1CLEtBQUEsSUFBUyxHQUFHLENBQUMsRUFBRXBaLFFBQUEsQ0FBUTtFQUN6RSxJQUFJMHNCLE1BQUEsR0FBUztFQUViLE1BQU16WSxPQUFBLEdBQ0RqZixNQUFBLENBQUFDLE1BQUEsQ0FBQUQsTUFBQSxDQUFBQyxNQUFBLEtBQUE2cEMsa0JBQWtCO0lBQ3JCMWxCLEtBQUEsRUFBT0EsS0FBQSxDQUFNcFosUUFBQSxDQUFRO0lBQ3JCeTlCLE1BQUEsRUFBUUEsTUFBQSxDQUFPejlCLFFBQUEsQ0FBUTtJQUN2QjZMLEdBQUE7SUFDQTROO0VBQUk7RUFLTixNQUFNclAsRUFBQSxPQUFLdmQsV0FBQSxDQUFBbWUsS0FBQSxFQUFLLEVBQUc1UCxXQUFBLENBQVc7RUFFOUIsSUFBSTBOLEtBQUEsRUFBTTtJQUNSNGpCLE1BQUEsR0FBUy9oQixZQUFBLENBQWFQLEVBQUUsSUFBSWcxQixZQUFBLEdBQWV0MkIsS0FBQTtFQUM1QztFQUVELElBQUl5QixVQUFBLENBQVdILEVBQUUsR0FBRztJQUVsQm5TLEdBQUEsR0FBTUEsR0FBQSxJQUFPb25DLGlCQUFBO0lBR2JwckIsT0FBQSxDQUFRMnJCLFVBQUEsR0FBYTtFQUN0QjtFQUVELE1BQU1DLGFBQUEsR0FBZ0I3cUMsTUFBQSxDQUFPOHFDLE9BQUEsQ0FBUTdyQixPQUFPLEVBQUU4ckIsTUFBQSxDQUM1QyxDQUFDQyxLQUFBLEVBQU8sQ0FBQ25tQyxHQUFBLEVBQUtzTyxLQUFLLE1BQU0sR0FBRzYzQixLQUFBLEdBQVFubUMsR0FBQSxJQUFPc08sS0FBQSxLQUMzQyxFQUFFO0VBR0osSUFBSWlELGdCQUFBLENBQWlCaEIsRUFBRSxLQUFLc2lCLE1BQUEsS0FBVyxTQUFTO0lBQzlDdVQsa0JBQUEsQ0FBbUJob0MsR0FBQSxJQUFPLElBQUl5MEIsTUFBTTtJQUNwQyxPQUFPLElBQUk0UyxTQUFBLENBQVUsSUFBSTtFQUMxQjtFQUlELE1BQU1ZLE1BQUEsR0FBUzcwQixNQUFBLENBQU80akIsSUFBQSxDQUFLaDNCLEdBQUEsSUFBTyxJQUFJeTBCLE1BQUEsRUFBUW1ULGFBQWE7RUFDM0QvcEMsT0FBQSxDQUFRb3FDLE1BQUEsRUFBUXRyQyxJQUFBLEVBQUk7RUFHcEIsSUFBSTtJQUNGc3JDLE1BQUEsQ0FBT0MsS0FBQSxDQUFLO0VBQ2IsU0FBUTdrQyxDQUFBLEVBQVAsQ0FBVTtFQUVaLE9BQU8sSUFBSWdrQyxTQUFBLENBQVVZLE1BQU07QUFDN0I7QUFFQSxTQUFTRCxtQkFBbUJob0MsR0FBQSxFQUFheTBCLE1BQUEsRUFBYztFQUNyRCxNQUFNMVgsRUFBQSxHQUFLdkosUUFBQSxDQUFTd0osYUFBQSxDQUFjLEdBQUc7RUFDckNELEVBQUEsQ0FBR3hlLElBQUEsR0FBT3lCLEdBQUE7RUFDVitjLEVBQUEsQ0FBRzBYLE1BQUEsR0FBU0EsTUFBQTtFQUNaLE1BQU0wVCxLQUFBLEdBQVEzMEIsUUFBQSxDQUFTNDBCLFdBQUEsQ0FBWSxZQUFZO0VBQy9DRCxLQUFBLENBQU1FLGNBQUEsQ0FDSixTQUNBLE1BQ0EsTUFDQWoxQixNQUFBLEVBQ0EsR0FDQSxHQUNBLEdBQ0EsR0FDQSxHQUNBLE9BQ0EsT0FDQSxPQUNBLE9BQ0EsR0FDQSxJQUFJO0VBRU4ySixFQUFBLENBQUd1ckIsYUFBQSxDQUFjSCxLQUFLO0FBQ3hCO0FDdkdBLElBQU1JLFdBQUEsR0FBYztBQU9wQixJQUFNQyxvQkFBQSxHQUF1QjtBQU83QixJQUFNQyw4QkFBQSxHQUFpQ0Msa0JBQUEsQ0FBbUIsS0FBSztBQWdCeEQsZUFBZUMsZ0JBQ3BCaHNDLElBQUEsRUFDQTJJLFFBQUEsRUFDQXNqQyxRQUFBLEVBQ0FDLFdBQUEsRUFDQWpWLE9BQUEsRUFDQWtWLGdCQUFBLEVBQXlDO0VBRXpDanJDLE9BQUEsQ0FBUWxCLElBQUEsQ0FBS2tELE1BQUEsQ0FBT3VaLFVBQUEsRUFBWXpjLElBQUEsRUFBSTtFQUNwQ2tCLE9BQUEsQ0FBUWxCLElBQUEsQ0FBS2tELE1BQUEsQ0FBT2dDLE1BQUEsRUFBUWxGLElBQUEsRUFBSTtFQUVoQyxNQUFNNEUsTUFBQSxHQUF1QjtJQUMzQk0sTUFBQSxFQUFRbEYsSUFBQSxDQUFLa0QsTUFBQSxDQUFPZ0MsTUFBQTtJQUNwQjFFLE9BQUEsRUFBU1IsSUFBQSxDQUFLUyxJQUFBO0lBQ2R3ckMsUUFBQTtJQUNBQyxXQUFBO0lBQ0ExRixDQUFBLEVBQUdubkMsVUFBQSxDQUFBQyxXQUFBO0lBQ0gyM0I7O0VBR0YsSUFBSXR1QixRQUFBLFlBQW9Cb2hCLHFCQUFBLEVBQXVCO0lBQzdDcGhCLFFBQUEsQ0FBU3VoQixrQkFBQSxDQUFtQmxxQixJQUFBLENBQUtvRixZQUFZO0lBQzdDUixNQUFBLENBQU9xSyxVQUFBLEdBQWF0RyxRQUFBLENBQVNzRyxVQUFBLElBQWM7SUFDM0MsSUFBSSxLQUFDaFgsV0FBQSxDQUFBbTBDLE9BQUEsRUFBUXpqQyxRQUFBLENBQVMwaEIsbUJBQUEsQ0FBbUIsQ0FBRSxHQUFHO01BQzVDemxCLE1BQUEsQ0FBT3FsQixnQkFBQSxHQUFtQnBsQixJQUFBLENBQUtDLFNBQUEsQ0FBVTZELFFBQUEsQ0FBUzBoQixtQkFBQSxDQUFtQixDQUFFO0lBQ3hFO0lBR0QsV0FBVyxDQUFDcGxCLEdBQUEsRUFBS3NPLEtBQUssS0FBS25ULE1BQUEsQ0FBTzhxQyxPQUFBLENBQVFpQixnQkFBQSxJQUFvQixFQUFFLEdBQUc7TUFDakV2bkMsTUFBQSxDQUFPSyxHQUFBLElBQU9zTyxLQUFBO0lBQ2Y7RUFDRjtFQUVELElBQUk1SyxRQUFBLFlBQW9CMmhCLGlCQUFBLEVBQW1CO0lBQ3pDLE1BQU1DLE1BQUEsR0FBUzVoQixRQUFBLENBQVMraEIsU0FBQSxDQUFTLEVBQUc3YixNQUFBLENBQU80YixLQUFBLElBQVNBLEtBQUEsS0FBVSxFQUFFO0lBQ2hFLElBQUlGLE1BQUEsQ0FBTzdoQixNQUFBLEdBQVMsR0FBRztNQUNyQjlELE1BQUEsQ0FBTzJsQixNQUFBLEdBQVNBLE1BQUEsQ0FBT2hULElBQUEsQ0FBSyxHQUFHO0lBQ2hDO0VBQ0Y7RUFFRCxJQUFJdlgsSUFBQSxDQUFLc0UsUUFBQSxFQUFVO0lBQ2pCTSxNQUFBLENBQU95bkMsR0FBQSxHQUFNcnNDLElBQUEsQ0FBS3NFLFFBQUE7RUFDbkI7RUFLRCxNQUFNZ29DLFVBQUEsR0FBYTFuQyxNQUFBO0VBQ25CLFdBQVdLLEdBQUEsSUFBTzdFLE1BQUEsQ0FBT3kwQixJQUFBLENBQUt5WCxVQUFVLEdBQUc7SUFDekMsSUFBSUEsVUFBQSxDQUFXcm5DLEdBQUEsTUFBUyxRQUFXO01BQ2pDLE9BQU9xbkMsVUFBQSxDQUFXcm5DLEdBQUE7SUFDbkI7RUFDRjtFQUdELE1BQU0wYSxhQUFBLEdBQWdCLE1BQU0zZixJQUFBLENBQUs0ZixpQkFBQSxDQUFpQjtFQUNsRCxNQUFNMnNCLHFCQUFBLEdBQXdCNXNCLGFBQUEsR0FDMUIsSUFBSW1zQiw4QkFBQSxJQUFrQ0Msa0JBQUEsQ0FBbUJwc0IsYUFBYSxNQUN0RTtFQUdKLE9BQU8sR0FBRzZzQixjQUFBLENBQWV4c0MsSUFBSSxTQUFLL0gsV0FBQSxDQUFBK00sV0FBQSxFQUFZc25DLFVBQVUsRUFBRXRyQyxLQUFBLENBQ3hELENBQUMsSUFDQ3VyQyxxQkFBQTtBQUNOO0FBRUEsU0FBU0MsZUFBZTtFQUFFdHBDO0FBQU0sR0FBZ0I7RUFDOUMsSUFBSSxDQUFDQSxNQUFBLENBQU9FLFFBQUEsRUFBVTtJQUNwQixPQUFPLFdBQVdGLE1BQUEsQ0FBT3VaLFVBQUEsSUFBY212QixXQUFBO0VBQ3hDO0VBRUQsT0FBTzNvQyxZQUFBLENBQWFDLE1BQUEsRUFBUTJvQyxvQkFBb0I7QUFDbEQ7QUN6RkEsSUFBTVksdUJBQUEsR0FBMEI7QUFXaEMsSUFBTUMsNEJBQUEsR0FBTixNQUFrQztFQUFsQzVyQyxZQUFBO0lBQ21CLEtBQWE2ckMsYUFBQSxHQUFxQztJQUNsRCxLQUFPekUsT0FBQSxHQUF3QztJQUMvQyxLQUF3QjBFLHdCQUFBLEdBQWtDO0lBRWxFLEtBQW9CdHVCLG9CQUFBLEdBQUd0ckIseUJBQUE7SUF5SGhDLEtBQW1Ca3FCLG1CQUFBLEdBQUdpb0Isa0JBQUE7SUFFdEIsS0FBdUJwb0IsdUJBQUEsR0FBR0EsdUJBQUE7O0VBdkgxQixNQUFNOG1CLFdBQ0o3akMsSUFBQSxFQUNBMkksUUFBQSxFQUNBc2pDLFFBQUEsRUFDQWhWLE9BQUEsRUFBZ0I7O0lBRWhCMTFCLFdBQUEsRUFDRUcsRUFBQSxRQUFLaXJDLGFBQUEsQ0FBYzNzQyxJQUFBLENBQUsyVCxJQUFBLENBQUksUUFBSyxRQUFBalMsRUFBQSx1QkFBQUEsRUFBQSxDQUFBZ1AsT0FBQSxFQUNqQyw4Q0FBOEM7SUFHaEQsTUFBTXJOLEdBQUEsR0FBTSxNQUFNMm9DLGVBQUEsQ0FDaEJoc0MsSUFBQSxFQUNBMkksUUFBQSxFQUNBc2pDLFFBQUEsRUFDQXpxQyxjQUFBLENBQWMsR0FDZHkxQixPQUFPO0lBRVQsT0FBTzJULEtBQUEsQ0FBTTVxQyxJQUFBLEVBQU1xRCxHQUFBLEVBQUtzMEIsZ0JBQUEsQ0FBZ0IsQ0FBRTs7RUFHNUMsTUFBTW9OLGNBQ0ova0MsSUFBQSxFQUNBMkksUUFBQSxFQUNBc2pDLFFBQUEsRUFDQWhWLE9BQUEsRUFBZ0I7SUFFaEIsTUFBTSxLQUFLOE0saUJBQUEsQ0FBa0IvakMsSUFBSTtJQUNqQyxNQUFNcUQsR0FBQSxHQUFNLE1BQU0yb0MsZUFBQSxDQUNoQmhzQyxJQUFBLEVBQ0EySSxRQUFBLEVBQ0FzakMsUUFBQSxFQUNBenFDLGNBQUEsQ0FBYyxHQUNkeTFCLE9BQU87SUFFVDRCLGtCQUFBLENBQW1CeDFCLEdBQUc7SUFDdEIsT0FBTyxJQUFJdUMsT0FBQSxDQUFRLE1BQU8sRUFBQzs7RUFHN0JxVyxZQUFZamMsSUFBQSxFQUFrQjtJQUM1QixNQUFNaUYsR0FBQSxHQUFNakYsSUFBQSxDQUFLMlQsSUFBQSxDQUFJO0lBQ3JCLElBQUksS0FBS2c1QixhQUFBLENBQWMxbkMsR0FBQSxHQUFNO01BQzNCLE1BQU07UUFBRXlMLE9BQUE7UUFBUzVLLE9BQUEsRUFBQSttQztNQUFPLElBQUssS0FBS0YsYUFBQSxDQUFjMW5DLEdBQUE7TUFDaEQsSUFBSXlMLE9BQUEsRUFBUztRQUNYLE9BQU85SyxPQUFBLENBQVFpUyxPQUFBLENBQVFuSCxPQUFPO01BQy9CLE9BQU07UUFDTG5QLFdBQUEsQ0FBWXNyQyxRQUFBLEVBQVMsMENBQTBDO1FBQy9ELE9BQU9BLFFBQUE7TUFDUjtJQUNGO0lBRUQsTUFBTS9tQyxPQUFBLEdBQVUsS0FBS2duQyxpQkFBQSxDQUFrQjlzQyxJQUFJO0lBQzNDLEtBQUsyc0MsYUFBQSxDQUFjMW5DLEdBQUEsSUFBTztNQUFFYTtJQUFPO0lBSW5DQSxPQUFBLENBQVEwYixLQUFBLENBQU0sTUFBSztNQUNqQixPQUFPLEtBQUttckIsYUFBQSxDQUFjMW5DLEdBQUE7SUFDNUIsQ0FBQztJQUVELE9BQU9hLE9BQUE7O0VBR0QsTUFBTWduQyxrQkFBa0I5c0MsSUFBQSxFQUFrQjtJQUNoRCxNQUFNMnBDLE1BQUEsR0FBUyxNQUFNUixXQUFBLENBQVlucEMsSUFBSTtJQUNyQyxNQUFNMFEsT0FBQSxHQUFVLElBQUk0MEIsZ0JBQUEsQ0FBaUJ0bEMsSUFBSTtJQUN6QzJwQyxNQUFBLENBQU9vRCxRQUFBLENBQ0wsYUFDQ0MsV0FBQSxJQUFxQztNQUNwQzlyQyxPQUFBLENBQVE4ckMsV0FBQSxLQUFXLFFBQVhBLFdBQUEsS0FBVyxrQkFBWEEsV0FBQSxDQUFhQyxTQUFBLEVBQVdqdEMsSUFBQSxFQUFJO01BR3BDLE1BQU1rbUMsT0FBQSxHQUFVeDFCLE9BQUEsQ0FBUXMxQixPQUFBLENBQVFnSCxXQUFBLENBQVlDLFNBQVM7TUFDckQsT0FBTztRQUFFenpCLE1BQUEsRUFBUTBzQixPQUFBLEdBQTBCLFFBQW1CO01BQUE7SUFDaEUsR0FDQStCLElBQUEsQ0FBS0MsT0FBQSxDQUFRc0IsMkJBQTJCO0lBRzFDLEtBQUttRCxhQUFBLENBQWMzc0MsSUFBQSxDQUFLMlQsSUFBQSxDQUFJLEtBQU07TUFBRWpEO0lBQU87SUFDM0MsS0FBS3czQixPQUFBLENBQVFsb0MsSUFBQSxDQUFLMlQsSUFBQSxDQUFJLEtBQU1nMkIsTUFBQTtJQUM1QixPQUFPajVCLE9BQUE7O0VBR1RzekIsNkJBQ0Voa0MsSUFBQSxFQUNBNGUsRUFBQSxFQUFtQztJQUVuQyxNQUFNK3FCLE1BQUEsR0FBUyxLQUFLekIsT0FBQSxDQUFRbG9DLElBQUEsQ0FBSzJULElBQUEsQ0FBSTtJQUNyQ2cyQixNQUFBLENBQU91RCxJQUFBLENBQ0xULHVCQUFBLEVBQ0E7TUFBRXQ1QixJQUFBLEVBQU1zNUI7SUFBdUIsR0FDL0IzMEIsTUFBQSxJQUFTOztNQUNQLE1BQU1tc0IsV0FBQSxJQUFjdmlDLEVBQUEsR0FBQW9XLE1BQUEsS0FBTSxRQUFOQSxNQUFBLEtBQU0sa0JBQU5BLE1BQUEsQ0FBUyxRQUFLLFFBQUFwVyxFQUFBLHVCQUFBQSxFQUFBLENBQUErcUMsdUJBQUE7TUFDbEMsSUFBSXhJLFdBQUEsS0FBZ0IsUUFBVztRQUM3QnJsQixFQUFBLENBQUcsQ0FBQyxDQUFDcWxCLFdBQVc7TUFDakI7TUFFRHZrQyxLQUFBLENBQU1NLElBQUEsRUFBSTtJQUNaLEdBQ0Fpb0MsSUFBQSxDQUFLQyxPQUFBLENBQVFzQiwyQkFBMkI7O0VBSTVDekYsa0JBQWtCL2pDLElBQUEsRUFBa0I7SUFDbEMsTUFBTWlGLEdBQUEsR0FBTWpGLElBQUEsQ0FBSzJULElBQUEsQ0FBSTtJQUNyQixJQUFJLENBQUMsS0FBS2k1Qix3QkFBQSxDQUF5QjNuQyxHQUFBLEdBQU07TUFDdkMsS0FBSzJuQyx3QkFBQSxDQUF5QjNuQyxHQUFBLElBQU8yaEMsZUFBQSxDQUFnQjVtQyxJQUFJO0lBQzFEO0lBRUQsT0FBTyxLQUFLNHNDLHdCQUFBLENBQXlCM25DLEdBQUE7O0VBR3ZDLElBQUkrVyx1QkFBQSxFQUFzQjtJQUV4QixPQUFPakYsZ0JBQUEsQ0FBZ0IsS0FBTWpCLFNBQUEsQ0FBUyxLQUFNUSxNQUFBLENBQU07O0FBTXJEO0FBV00sSUFBTXZqQiw0QkFBQSxHQUNYMjVDLDRCQUFBO0lDaExvQlMsd0JBQUEsU0FBd0I7RUFDNUNyc0MsWUFBK0Irc0IsUUFBQSxFQUFrQjtJQUFsQixLQUFRQSxRQUFBLEdBQVJBLFFBQUE7O0VBRS9Cd0UsU0FDRXJ5QixJQUFBLEVBQ0FneUIsT0FBQSxFQUNBNWpCLFdBQUEsRUFBMkI7SUFFM0IsUUFBUTRqQixPQUFBLENBQVE3ZSxJQUFBO1dBQ2Q7UUFDRSxPQUFPLEtBQUtpNkIsZUFBQSxDQUFnQnB0QyxJQUFBLEVBQU1neUIsT0FBQSxDQUFRdkksVUFBQSxFQUFZcmIsV0FBVztXQUNuRTtRQUNFLE9BQU8sS0FBS2kvQixlQUFBLENBQWdCcnRDLElBQUEsRUFBTWd5QixPQUFBLENBQVF2SSxVQUFVOztRQUVwRCxPQUFPcm9CLFNBQUEsQ0FBVSxtQ0FBbUM7OztBQWEzRDtBQ2RLLElBQU9rc0MsNkJBQUEsR0FBUCxjQUNJSCx3QkFBQSxDQUF3QjtFQUdoQ3JzQyxZQUFxQzJvQixVQUFBLEVBQStCO0lBQ2xFLE1BQUs7SUFEOEIsS0FBVUEsVUFBQSxHQUFWQSxVQUFBOztFQUtyQyxPQUFPOGpCLGdCQUNMOWpCLFVBQUEsRUFBK0I7SUFFL0IsT0FBTyxJQUFJNmpCLDZCQUFBLENBQThCN2pCLFVBQVU7O0VBSXJEMmpCLGdCQUNFcHRDLElBQUEsRUFDQW9OLE9BQUEsRUFDQWdCLFdBQUEsRUFBMkI7SUFFM0IsT0FBT3NrQixzQkFBQSxDQUF1QjF5QixJQUFBLEVBQU07TUFDbENvTixPQUFBO01BQ0FnQixXQUFBO01BQ0FvL0IscUJBQUEsRUFBdUIsS0FBSy9qQixVQUFBLENBQVdoQix3QkFBQSxDQUF3QjtJQUNoRTs7RUFJSDRrQixnQkFDRXJ0QyxJQUFBLEVBQ0E0eEIsb0JBQUEsRUFBNEI7SUFFNUIsT0FBTytLLHNCQUFBLENBQXVCMzhCLElBQUEsRUFBTTtNQUNsQzR4QixvQkFBQTtNQUNBNGIscUJBQUEsRUFBdUIsS0FBSy9qQixVQUFBLENBQVdoQix3QkFBQSxDQUF3QjtJQUNoRTs7QUFFSjtJQU9ZcjJCLHlCQUFBLFNBQXlCO0VBQ3BDME8sWUFBQTtFQVlBLE9BQU9LLFVBQVVzb0IsVUFBQSxFQUErQjtJQUM5QyxPQUFPNmpCLDZCQUFBLENBQThCQyxlQUFBLENBQWdCOWpCLFVBQVU7OztBQU0xRHIzQix5QkFBQSxDQUFTcTdDLFNBQUEsR0FBRztJQzFEUmg3Qyx3QkFBQSxTQUF3QjtFQVduQyxPQUFPaTdDLHVCQUNMbG1CLE1BQUEsRUFDQW1tQixlQUFBLEVBQXVCO0lBRXZCLE9BQU9DLDRCQUFBLENBQTZCQyxXQUFBLENBQVlybUIsTUFBQSxFQUFRbW1CLGVBQWU7O0VBWXpFLE9BQU9HLG1CQUNMQyxZQUFBLEVBQ0FKLGVBQUEsRUFBdUI7SUFFdkIsT0FBT0MsNEJBQUEsQ0FBNkJJLGlCQUFBLENBQ2xDRCxZQUFBLEVBQ0FKLGVBQWU7O0VBYW5CLGFBQWFNLGVBQ1hqYyxPQUFBLEVBQTJCOztJQUUzQixNQUFNa2MsVUFBQSxHQUFhbGMsT0FBQTtJQUNuQjl3QixPQUFBLENBQ0UsU0FBT1EsRUFBQSxHQUFBd3NDLFVBQUEsQ0FBV3RrQyxJQUFBLE1BQUksUUFBQWxJLEVBQUEsdUJBQUFBLEVBQUEsQ0FBRTFCLElBQUEsTUFBUyxhQUFXO0lBRzlDLE1BQU1nRSxRQUFBLEdBQVcsTUFBTTJ1QixrQkFBQSxDQUFtQnViLFVBQUEsQ0FBV3RrQyxJQUFBLENBQUs1SixJQUFBLEVBQU07TUFDOURvTixPQUFBLEVBQVM4Z0MsVUFBQSxDQUFXemtCLFVBQUE7TUFDcEIwa0Isa0JBQUEsRUFBb0I7SUFDckI7SUFDRCxPQUFPejdDLFVBQUEsQ0FBVzA3QyxtQ0FBQSxDQUNoQnBxQyxRQUFBLEVBQ0FrcUMsVUFBQSxDQUFXdGtDLElBQUEsQ0FBSzVKLElBQUk7OztBQU9qQnZOLHdCQUFBLENBQUFnN0MsU0FBQSxHQUFrQztBQUdyQyxJQUFPRyw0QkFBQSxHQUFQLGNBQ0lULHdCQUFBLENBQXdCO0VBR2hDcnNDLFlBQ1d1dEMsR0FBQSxFQUNBTixZQUFBLEVBQ0F2bUIsTUFBQSxFQUFtQjtJQUU1QixNQUFLO0lBSkksS0FBRzZtQixHQUFBLEdBQUhBLEdBQUE7SUFDQSxLQUFZTixZQUFBLEdBQVpBLFlBQUE7SUFDQSxLQUFNdm1CLE1BQUEsR0FBTkEsTUFBQTs7RUFNWCxPQUFPcW1CLFlBQ0xybUIsTUFBQSxFQUNBNm1CLEdBQUEsRUFBVztJQUVYLE9BQU8sSUFBSVQsNEJBQUEsQ0FBNkJTLEdBQUEsRUFBSyxRQUFXN21CLE1BQU07O0VBSWhFLE9BQU93bUIsa0JBQ0xELFlBQUEsRUFDQU0sR0FBQSxFQUFXO0lBRVgsT0FBTyxJQUFJVCw0QkFBQSxDQUE2QlMsR0FBQSxFQUFLTixZQUFZOztFQUkzRCxNQUFNWCxnQkFDSnB0QyxJQUFBLEVBQ0FvTixPQUFBLEVBQ0FnQixXQUFBLEVBQTJCO0lBRTNCbE4sT0FBQSxDQUNFLE9BQU8sS0FBS3NtQixNQUFBLEtBQVcsYUFDdkJ4bkIsSUFBQSxFQUFJO0lBR04sT0FBTzR5QixxQkFBQSxDQUFzQjV5QixJQUFBLEVBQU07TUFDakNvTixPQUFBO01BQ0FnQixXQUFBO01BQ0FrZ0Msb0JBQUEsRUFBc0IsS0FBSzltQixNQUFBLENBQU8rbUIseUJBQUEsQ0FBMEIsS0FBS0YsR0FBRztJQUNyRTs7RUFJSCxNQUFNaEIsZ0JBQ0pydEMsSUFBQSxFQUNBNHhCLG9CQUFBLEVBQTRCO0lBRTVCMXdCLE9BQUEsQ0FDRSxLQUFLNnNDLFlBQUEsS0FBaUIsVUFBYSxLQUFLTSxHQUFBLEtBQVEsUUFDaERydUMsSUFBQSxFQUFJO0lBR04sTUFBTXN1QyxvQkFBQSxHQUF1QjtNQUFFL2xCLGdCQUFBLEVBQWtCLEtBQUs4bEI7SUFBRztJQUN6RCxPQUFPelIscUJBQUEsQ0FBc0I1OEIsSUFBQSxFQUFNO01BQ2pDNHhCLG9CQUFBO01BQ0E5RCxlQUFBLEVBQWlCLEtBQUtpZ0IsWUFBQTtNQUN0Qk87SUFDRDs7QUFFSjtJQVNZNTdDLFVBQUEsU0FBVTtFQXdCckJvTyxZQUNFMHRDLFNBQUEsRUFDQUMsZ0JBQUEsRUFDQUMsVUFBQSxFQUNBQyxtQkFBQSxFQUNBQyw0QkFBQSxFQUNpQmxtQixXQUFBLEVBQ0Exb0IsSUFBQSxFQUFrQjtJQURsQixLQUFXMG9CLFdBQUEsR0FBWEEsV0FBQTtJQUNBLEtBQUkxb0IsSUFBQSxHQUFKQSxJQUFBO0lBRWpCLEtBQUt3dUMsU0FBQSxHQUFZQSxTQUFBO0lBQ2pCLEtBQUtDLGdCQUFBLEdBQW1CQSxnQkFBQTtJQUN4QixLQUFLQyxVQUFBLEdBQWFBLFVBQUE7SUFDbEIsS0FBS0MsbUJBQUEsR0FBc0JBLG1CQUFBO0lBQzNCLEtBQUtDLDRCQUFBLEdBQStCQSw0QkFBQTs7RUFJdEMsT0FBT1Isb0NBQ0xwcUMsUUFBQSxFQUNBaEUsSUFBQSxFQUFrQjtJQUVsQixPQUFPLElBQUl0TixVQUFBLENBQ1RzUixRQUFBLENBQVM2cUMsZUFBQSxDQUFnQkMsZUFBQSxFQUN6QjlxQyxRQUFBLENBQVM2cUMsZUFBQSxDQUFnQkosZ0JBQUEsRUFDekJ6cUMsUUFBQSxDQUFTNnFDLGVBQUEsQ0FBZ0JFLHNCQUFBLEVBQ3pCL3FDLFFBQUEsQ0FBUzZxQyxlQUFBLENBQWdCRyxTQUFBLEVBQ3pCLElBQUl6bEMsSUFBQSxDQUFLdkYsUUFBQSxDQUFTNnFDLGVBQUEsQ0FBZ0JJLHNCQUFzQixFQUFFdGxDLFdBQUEsQ0FBVyxHQUNyRTNGLFFBQUEsQ0FBUzZxQyxlQUFBLENBQWdCbm1CLFdBQUEsRUFDekIxb0IsSUFBSTs7RUFLUnV1QywwQkFBMEJGLEdBQUEsRUFBVztJQUNuQyxPQUFPO01BQUUzbEIsV0FBQSxFQUFhLEtBQUtBLFdBQUE7TUFBYUgsZ0JBQUEsRUFBa0I4bEI7SUFBRzs7RUFhL0RhLGtCQUFrQkMsV0FBQSxFQUFzQkMsTUFBQSxFQUFlOztJQUNyRCxJQUFJQyxXQUFBLEdBQWM7SUFDbEIsSUFBSUMsY0FBQSxDQUFlSCxXQUFXLEtBQUtHLGNBQUEsQ0FBZUYsTUFBTSxHQUFHO01BQ3pEQyxXQUFBLEdBQWM7SUFDZjtJQUNELElBQUlBLFdBQUEsRUFBYTtNQUNmLElBQUlDLGNBQUEsQ0FBZUgsV0FBVyxHQUFHO1FBQy9CQSxXQUFBLEtBQWN6dEMsRUFBQSxRQUFLMUIsSUFBQSxDQUFLMEwsV0FBQSxNQUFhLFFBQUFoSyxFQUFBLHVCQUFBQSxFQUFBLENBQUFpRyxLQUFBLEtBQVM7TUFDL0M7TUFDRCxJQUFJMm5DLGNBQUEsQ0FBZUYsTUFBTSxHQUFHO1FBQzFCQSxNQUFBLEdBQVMsS0FBS3B2QyxJQUFBLENBQUtTLElBQUE7TUFDcEI7SUFDRjtJQUNELE9BQU8sa0JBQWtCMnVDLE1BQUEsSUFBVUQsV0FBQSxXQUFzQixLQUFLWCxTQUFBLFdBQW9CWSxNQUFBLGNBQW9CLEtBQUtYLGdCQUFBLFdBQTJCLEtBQUtDLFVBQUE7O0FBRTlJO0FBR0QsU0FBU1ksZUFBZUMsS0FBQSxFQUFjO0VBQ3BDLE9BQU8sT0FBT0EsS0FBQSxLQUFVLGdCQUFlQSxLQUFBLGFBQUFBLEtBQUEsS0FBSyxrQkFBTEEsS0FBQSxDQUFPN21DLE1BQUEsTUFBVztBQUMzRDs7O0lDdFBhOG1DLFdBQUEsU0FBVztFQUl0QjF1QyxZQUE2QmQsSUFBQSxFQUFrQjtJQUFsQixLQUFJQSxJQUFBLEdBQUpBLElBQUE7SUFIWixLQUFBeXZDLGlCQUFBLEdBQ2YsbUJBQUk1OEIsR0FBQSxDQUFHOztFQUlUNjhCLE9BQUEsRUFBTTs7SUFDSixLQUFLQyxvQkFBQSxDQUFvQjtJQUN6QixTQUFPanVDLEVBQUEsUUFBSzFCLElBQUEsQ0FBSzBMLFdBQUEsTUFBYSxRQUFBaEssRUFBQSx1QkFBQUEsRUFBQSxDQUFBd00sR0FBQSxLQUFPOztFQUd2QyxNQUFNa0MsU0FDSnZHLFlBQUEsRUFBc0I7SUFFdEIsS0FBSzhsQyxvQkFBQSxDQUFvQjtJQUN6QixNQUFNLEtBQUszdkMsSUFBQSxDQUFLa2Isc0JBQUE7SUFDaEIsSUFBSSxDQUFDLEtBQUtsYixJQUFBLENBQUswTCxXQUFBLEVBQWE7TUFDMUIsT0FBTztJQUNSO0lBRUQsTUFBTWdFLFdBQUEsR0FBYyxNQUFNLEtBQUsxUCxJQUFBLENBQUswTCxXQUFBLENBQVloWSxVQUFBLENBQVdtVyxZQUFZO0lBQ3ZFLE9BQU87TUFBRTZGO0lBQVc7O0VBR3RCa2dDLHFCQUFxQnBhLFFBQUEsRUFBdUI7SUFDMUMsS0FBS21hLG9CQUFBLENBQW9CO0lBQ3pCLElBQUksS0FBS0YsaUJBQUEsQ0FBa0J2aUIsR0FBQSxDQUFJc0ksUUFBUSxHQUFHO01BQ3hDO0lBQ0Q7SUFFRCxNQUFNdFgsV0FBQSxHQUFjLEtBQUtsZSxJQUFBLENBQUt2TCxnQkFBQSxDQUFpQm1WLElBQUEsSUFBTztNQUNwRDRyQixRQUFBLEVBQ0c1ckIsSUFBQSxLQUE0QixRQUE1QkEsSUFBQSx1QkFBQUEsSUFBQSxDQUE4QjBDLGVBQUEsQ0FBZ0JvRCxXQUFBLEtBQWUsSUFBSTtJQUV0RSxDQUFDO0lBQ0QsS0FBSysvQixpQkFBQSxDQUFrQng4QixHQUFBLENBQUl1aUIsUUFBQSxFQUFVdFgsV0FBVztJQUNoRCxLQUFLMnhCLHNCQUFBLENBQXNCOztFQUc3QkMsd0JBQXdCdGEsUUFBQSxFQUF1QjtJQUM3QyxLQUFLbWEsb0JBQUEsQ0FBb0I7SUFDekIsTUFBTXp4QixXQUFBLEdBQWMsS0FBS3V4QixpQkFBQSxDQUFrQjNzQyxHQUFBLENBQUkweUIsUUFBUTtJQUN2RCxJQUFJLENBQUN0WCxXQUFBLEVBQWE7TUFDaEI7SUFDRDtJQUVELEtBQUt1eEIsaUJBQUEsQ0FBa0I1OUIsTUFBQSxDQUFPMmpCLFFBQVE7SUFDdEN0WCxXQUFBLENBQVc7SUFDWCxLQUFLMnhCLHNCQUFBLENBQXNCOztFQUdyQkYscUJBQUEsRUFBb0I7SUFDMUJ6dUMsT0FBQSxDQUNFLEtBQUtsQixJQUFBLENBQUtrYixzQkFBQSxFQUFzQjs7RUFLNUIyMEIsdUJBQUEsRUFBc0I7SUFDNUIsSUFBSSxLQUFLSixpQkFBQSxDQUFrQnpaLElBQUEsR0FBTyxHQUFHO01BQ25DLEtBQUtoMkIsSUFBQSxDQUFLd1Isc0JBQUEsQ0FBc0I7SUFDakMsT0FBTTtNQUNMLEtBQUt4UixJQUFBLENBQUt5UixxQkFBQSxDQUFxQjtJQUNoQzs7QUFFSjtBQ3ZERCxTQUFTcytCLHNCQUNQNTRCLGNBQUEsRUFBOEI7RUFFOUIsUUFBUUEsY0FBQTtTQUNOO01BQ0UsT0FBTztTQUNUO01BQ0UsT0FBTztTQUNUO01BQ0UsT0FBTztTQUNUO01BQ0UsT0FBTzs7TUFFUCxPQUFPOztBQUViO0FBR00sU0FBVTY0QixhQUFhNzRCLGNBQUEsRUFBOEI7RUFDekQsSUFBQTlYLFVBQUEsQ0FBQTR3QyxrQkFBQSxFQUNFLElBQUlDLGdCQUFBLENBQUFDLFNBQUEsQ0FBUyxRQUVYLENBQUMvUyxTQUFBLEVBQVc7SUFBRS9kLE9BQUEsRUFBU3FEO0VBQUksTUFBa0M7SUFDM0QsTUFBTXRJLEdBQUEsR0FBTWdqQixTQUFBLENBQVVnVCxXQUFBLENBQVksS0FBSyxFQUFFNXdCLFlBQUEsQ0FBWTtJQUNyRCxNQUFNbkYsd0JBQUEsR0FDSitpQixTQUFBLENBQVVnVCxXQUFBLENBQXlCLFdBQVc7SUFDaEQsTUFBTTkxQix1QkFBQSxHQUNKOGlCLFNBQUEsQ0FBVWdULFdBQUEsQ0FBa0Msb0JBQW9CO0lBQ2xFLE1BQU07TUFBRWxyQyxNQUFBO01BQVF1WDtJQUFVLElBQUtyQyxHQUFBLENBQUlpRixPQUFBO0lBRW5DbmUsT0FBQSxDQUNFZ0UsTUFBQSxJQUFVLENBQUNBLE1BQUEsQ0FBT3VRLFFBQUEsQ0FBUyxHQUFHLEdBRTlCO01BQUVqVixPQUFBLEVBQVM0WixHQUFBLENBQUkzWjtJQUFJLENBQUU7SUFHdkIsTUFBTXlDLE1BQUEsR0FBeUI7TUFDN0JnQyxNQUFBO01BQ0F1WCxVQUFBO01BQ0F0RixjQUFBO01BQ0E3UixPQUFBLEVBQStCO01BQy9CbUssWUFBQSxFQUEwQztNQUMxQ3ZJLFNBQUEsRUFBbUM7TUFDbkMwVSxnQkFBQSxFQUFrQjFFLGlCQUFBLENBQWtCQyxjQUFjOztJQUdwRCxNQUFNK0ssWUFBQSxHQUFlLElBQUkvSCxRQUFBLENBQ3ZCQyxHQUFBLEVBQ0FDLHdCQUFBLEVBQ0FDLHVCQUFBLEVBQ0FwWCxNQUFNO0lBRVIrZix1QkFBQSxDQUF3QmYsWUFBQSxFQUFjUSxJQUFJO0lBRTFDLE9BQU9SLFlBQUE7RUFDVCxHQUVELFVBS0VtdUIsb0JBQUEsQ0FBZ0QsWUFLaERDLDBCQUFBLENBQ0MsQ0FBQ2xULFNBQUEsRUFBV21ULG1CQUFBLEVBQXFCQyxTQUFBLEtBQWE7SUFDNUMsTUFBTUMsb0JBQUEsR0FBdUJyVCxTQUFBLENBQVVnVCxXQUFBLENBQVc7SUFHbERLLG9CQUFBLENBQXFCanRDLFVBQUEsQ0FBVTtHQUNoQyxDQUNGO0VBR0wsSUFBQW5FLFVBQUEsQ0FBQTR3QyxrQkFBQSxFQUNFLElBQUlDLGdCQUFBLENBQUFDLFNBQUEsQ0FFRixpQkFBQS9TLFNBQUEsSUFBWTtJQUNWLE1BQU1wOUIsSUFBQSxHQUFPOGYsU0FBQSxDQUNYc2QsU0FBQSxDQUFVZ1QsV0FBQSxDQUFXLFFBQXNCNXdCLFlBQUEsQ0FBWSxDQUFHO0lBRTVELFFBQVFxRCxLQUFBLElBQVEsSUFBSTJzQixXQUFBLENBQVkzc0IsS0FBSSxHQUFHN2lCLElBQUk7RUFDN0MsR0FFRCxXQUFDcXdDLG9CQUFBLENBQW9CLFdBQTRCO0VBR3BELElBQUFoeEMsVUFBQSxDQUFBcXhDLGVBQUEsRUFBZ0Jqd0MsSUFBQSxFQUFNOGdCLE9BQUEsRUFBU3d1QixxQkFBQSxDQUFzQjU0QixjQUFjLENBQUM7RUFFcEUsSUFBQTlYLFVBQUEsQ0FBQXF4QyxlQUFBLEVBQWdCandDLElBQUEsRUFBTThnQixPQUFBLEVBQVMsU0FBa0I7QUFDbkQ7QUNsR0EsSUFBTW92Qix3QkFBQSxHQUEyQixJQUFJO0FBQ3JDLElBQU1DLGlCQUFBLE9BQ0ozNEMsV0FBQSxDQUFBNDRDLHNCQUFBLEVBQXVCLG1CQUFtQixLQUFLRix3QkFBQTtBQUVqRCxJQUFJRyxpQkFBQSxHQUErQztBQUVuRCxJQUFNQyxpQkFBQSxHQUFxQjF0QyxHQUFBLElBQWdCLE1BQU91RyxJQUFBLElBQXFCO0VBQ3JFLE1BQU1vbkMsYUFBQSxHQUFnQnBuQyxJQUFBLEtBQVMsTUFBTUEsSUFBQSxDQUFLalcsZ0JBQUEsQ0FBZ0I7RUFDMUQsTUFBTXM5QyxVQUFBLEdBQ0pELGFBQUEsS0FDQyxJQUFJem5DLElBQUEsQ0FBSSxFQUFHRyxPQUFBLENBQU8sSUFBS0gsSUFBQSxDQUFLNEIsS0FBQSxDQUFNNmxDLGFBQUEsQ0FBY3RtQyxZQUFZLEtBQUs7RUFDcEUsSUFBSXVtQyxVQUFBLElBQWNBLFVBQUEsR0FBYUwsaUJBQUEsRUFBbUI7SUFDaEQ7RUFDRDtFQUVELE1BQU14akMsT0FBQSxHQUFVNGpDLGFBQUEsS0FBYSxRQUFiQSxhQUFBLHVCQUFBQSxhQUFBLENBQWVobkMsS0FBQTtFQUMvQixJQUFJOG1DLGlCQUFBLEtBQXNCMWpDLE9BQUEsRUFBUztJQUNqQztFQUNEO0VBQ0QwakMsaUJBQUEsR0FBb0IxakMsT0FBQTtFQUNwQixNQUFNeEosS0FBQSxDQUFNUCxHQUFBLEVBQUs7SUFDZm1CLE1BQUEsRUFBUTRJLE9BQUEsR0FBVSxTQUFTO0lBQzNCdEosT0FBQSxFQUFTc0osT0FBQSxHQUNMO01BQ0UsaUJBQWlCLFVBQVVBLE9BQUE7SUFDNUIsSUFDRDtFQUNMO0FBQ0g7QUFVZ0IsU0FBQTNaLFFBQVEybUIsR0FBQSxPQUFtQi9hLFVBQUEsQ0FBQTZ4QyxNQUFBLEVBQU0sR0FBRTtFQUNqRCxNQUFNdm9DLFFBQUEsT0FBV3RKLFVBQUEsQ0FBQXNqQixZQUFBLEVBQWF2SSxHQUFBLEVBQUssTUFBTTtFQUV6QyxJQUFJelIsUUFBQSxDQUFTaWEsYUFBQSxDQUFhLEdBQUk7SUFDNUIsT0FBT2phLFFBQUEsQ0FBUzZXLFlBQUEsQ0FBWTtFQUM3QjtFQUVELE1BQU14ZixJQUFBLEdBQU9oTSxjQUFBLENBQWVvbUIsR0FBQSxFQUFLO0lBQy9CMEIscUJBQUEsRUFBdUIvb0IsNEJBQUE7SUFDdkJpaEIsV0FBQSxFQUFhLENBQ1hqZ0IseUJBQUEsRUFDQWpCLHVCQUFBLEVBQ0FFLHlCQUFBO0VBRUg7RUFFRCxNQUFNbStDLGdCQUFBLE9BQW1CbDVDLFdBQUEsQ0FBQTQ0QyxzQkFBQSxFQUF1QixrQkFBa0I7RUFDbEUsSUFBSU0sZ0JBQUEsRUFBa0I7SUFDcEIsTUFBTUMsVUFBQSxHQUFhTCxpQkFBQSxDQUFrQkksZ0JBQWdCO0lBQ3JEdCtDLHNCQUFBLENBQXVCbU4sSUFBQSxFQUFNb3hDLFVBQUEsRUFBWSxNQUN2Q0EsVUFBQSxDQUFXcHhDLElBQUEsQ0FBSzBMLFdBQVcsQ0FBQztJQUU5QmpYLGdCQUFBLENBQWlCdUwsSUFBQSxFQUFNNEosSUFBQSxJQUFRd25DLFVBQUEsQ0FBV3huQyxJQUFJLENBQUM7RUFDaEQ7RUFFRCxNQUFNeW5DLGdCQUFBLE9BQW1CcDVDLFdBQUEsQ0FBQXE1QyxzQkFBQSxFQUF1QixNQUFNO0VBQ3RELElBQUlELGdCQUFBLEVBQWtCO0lBQ3BCbCtDLG1CQUFBLENBQW9CNk0sSUFBQSxFQUFNLFVBQVVxeEMsZ0JBQUEsRUFBa0I7RUFDdkQ7RUFFRCxPQUFPcnhDLElBQUE7QUFDVDtBQUVBZ3dDLFlBQUEsQ0FBWTs7O0FDeEdaLElBQUF1QixZQUFBLEdBQU9DLE9BQUE7QUFDUCxJQUFBQyxXQUFBLEdBQU9ELE9BQUE7QUFDUCxJQUFBRSxjQUFBLEdBQU9GLE9BQUE7QUFDUCxJQUFBRyxhQUFBLEdBQU9ILE9BQUE7QUFDUCxJQUFBSSxpQkFBQSxHQUFPSixPQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9