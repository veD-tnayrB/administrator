System.register([], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["clsx","1.2.1"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/clsx.1.2.1.js
var clsx_1_2_1_exports = {};
__export(clsx_1_2_1_exports, {
  clsx: () => clsx,
  default: () => clsx_1_2_1_default
});
module.exports = __toCommonJS(clsx_1_2_1_exports);

// node_modules/clsx/dist/clsx.m.js
function r(e) {
  var t,
    f,
    n = "";
  if ("string" == typeof e || "number" == typeof e) n += e;else if ("object" == typeof e) if (Array.isArray(e)) for (t = 0; t < e.length; t++) e[t] && (f = r(e[t])) && (n && (n += " "), n += f);else for (t in e) e[t] && (n && (n += " "), n += t);
  return n;
}
function clsx() {
  for (var e, t, f = 0, n = ""; f < arguments.length;) (e = arguments[f++]) && (t = r(e)) && (n && (n += " "), n += t);
  return n;
}
var clsx_m_default = clsx;

// .beyond/uimport/temp/clsx.1.2.1.js
var clsx_1_2_1_default = clsx_m_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2Nsc3guMS4yLjEuanMiLCIuLi9ub2RlX21vZHVsZXMvY2xzeC9kaXN0L2Nsc3gubS5qcyJdLCJuYW1lcyI6WyJjbHN4XzFfMl8xX2V4cG9ydHMiLCJfX2V4cG9ydCIsImNsc3giLCJkZWZhdWx0IiwiY2xzeF8xXzJfMV9kZWZhdWx0IiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsInIiLCJlIiwidCIsImYiLCJuIiwiQXJyYXkiLCJpc0FycmF5IiwibGVuZ3RoIiwiYXJndW1lbnRzIiwiY2xzeF9tX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLGtCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsa0JBQUE7RUFBQUUsSUFBQSxFQUFBQSxDQUFBLEtBQUFBLElBQUE7RUFBQUMsT0FBQSxFQUFBQSxDQUFBLEtBQUFDO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsa0JBQUE7OztBQ0FBLFNBQVNRLEVBQUVDLENBQUEsRUFBRTtFQUFDLElBQUlDLENBQUE7SUFBRUMsQ0FBQTtJQUFFQyxDQUFBLEdBQUU7RUFBRyxJQUFHLFlBQVUsT0FBT0gsQ0FBQSxJQUFHLFlBQVUsT0FBT0EsQ0FBQSxFQUFFRyxDQUFBLElBQUdILENBQUEsVUFBVSxZQUFVLE9BQU9BLENBQUEsRUFBRSxJQUFHSSxLQUFBLENBQU1DLE9BQUEsQ0FBUUwsQ0FBQyxHQUFFLEtBQUlDLENBQUEsR0FBRSxHQUFFQSxDQUFBLEdBQUVELENBQUEsQ0FBRU0sTUFBQSxFQUFPTCxDQUFBLElBQUlELENBQUEsQ0FBRUMsQ0FBQSxNQUFLQyxDQUFBLEdBQUVILENBQUEsQ0FBRUMsQ0FBQSxDQUFFQyxDQUFBLENBQUUsT0FBS0UsQ0FBQSxLQUFJQSxDQUFBLElBQUcsTUFBS0EsQ0FBQSxJQUFHRCxDQUFBLE9BQVEsS0FBSUQsQ0FBQSxJQUFLRCxDQUFBLEVBQUVBLENBQUEsQ0FBRUMsQ0FBQSxNQUFLRSxDQUFBLEtBQUlBLENBQUEsSUFBRyxNQUFLQSxDQUFBLElBQUdGLENBQUE7RUFBRyxPQUFPRSxDQUFBO0FBQUM7QUFBUSxTQUFTVixLQUFBLEVBQU07RUFBQyxTQUFRTyxDQUFBLEVBQUVDLENBQUEsRUFBRUMsQ0FBQSxHQUFFLEdBQUVDLENBQUEsR0FBRSxJQUFHRCxDQUFBLEdBQUVLLFNBQUEsQ0FBVUQsTUFBQSxHQUFRLENBQUNOLENBQUEsR0FBRU8sU0FBQSxDQUFVTCxDQUFBLFNBQVFELENBQUEsR0FBRUYsQ0FBQSxDQUFFQyxDQUFDLE9BQUtHLENBQUEsS0FBSUEsQ0FBQSxJQUFHLE1BQUtBLENBQUEsSUFBR0YsQ0FBQTtFQUFHLE9BQU9FLENBQUE7QUFBQztBQUFDLElBQU9LLGNBQUEsR0FBUWYsSUFBQTs7O0FER2pYLElBQU9FLGtCQUFBLEdBQVFhLGNBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=