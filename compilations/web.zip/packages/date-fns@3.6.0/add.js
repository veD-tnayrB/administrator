System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/constructFrom","date-fns@3.6.0/addDays","date-fns@3.6.0/addMonths"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/addDays', dep), dep => dependencies.set('date-fns@3.6.0/addMonths', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/add.3.6.0.js
var add_3_6_0_exports = {};
__export(add_3_6_0_exports, {
  add: () => add,
  default: () => add_3_6_0_default
});
module.exports = __toCommonJS(add_3_6_0_exports);

// node_modules/date-fns/add.mjs
var import_addDays = require("date-fns@3.6.0/addDays");
var import_addMonths = require("date-fns@3.6.0/addMonths");
var import_constructFrom = require("date-fns@3.6.0/constructFrom");
var import_toDate = require("date-fns@3.6.0/toDate");
function add(date, duration) {
  const {
    years = 0,
    months = 0,
    weeks = 0,
    days = 0,
    hours = 0,
    minutes = 0,
    seconds = 0
  } = duration;
  const _date = (0, import_toDate.toDate)(date);
  const dateWithMonths = months || years ? (0, import_addMonths.addMonths)(_date, months + years * 12) : _date;
  const dateWithDays = days || weeks ? (0, import_addDays.addDays)(dateWithMonths, days + weeks * 7) : dateWithMonths;
  const minutesToAdd = minutes + hours * 60;
  const secondsToAdd = seconds + minutesToAdd * 60;
  const msToAdd = secondsToAdd * 1e3;
  const finalDate = (0, import_constructFrom.constructFrom)(date, dateWithDays.getTime() + msToAdd);
  return finalDate;
}
var add_default = add;

// .beyond/uimport/temp/date-fns/add.3.6.0.js
var add_3_6_0_default = add_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2FkZC4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9hZGQubWpzIl0sIm5hbWVzIjpbImFkZF8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJhZGQiLCJkZWZhdWx0IiwiYWRkXzNfNl8wX2RlZmF1bHQiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2FkZERheXMiLCJyZXF1aXJlIiwiaW1wb3J0X2FkZE1vbnRocyIsImltcG9ydF9jb25zdHJ1Y3RGcm9tIiwiaW1wb3J0X3RvRGF0ZSIsImRhdGUiLCJkdXJhdGlvbiIsInllYXJzIiwibW9udGhzIiwid2Vla3MiLCJkYXlzIiwiaG91cnMiLCJtaW51dGVzIiwic2Vjb25kcyIsIl9kYXRlIiwidG9EYXRlIiwiZGF0ZVdpdGhNb250aHMiLCJhZGRNb250aHMiLCJkYXRlV2l0aERheXMiLCJhZGREYXlzIiwibWludXRlc1RvQWRkIiwic2Vjb25kc1RvQWRkIiwibXNUb0FkZCIsImZpbmFsRGF0ZSIsImNvbnN0cnVjdEZyb20iLCJnZXRUaW1lIiwiYWRkX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLGlCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsaUJBQUE7RUFBQUUsR0FBQSxFQUFBQSxDQUFBLEtBQUFBLEdBQUE7RUFBQUMsT0FBQSxFQUFBQSxDQUFBLEtBQUFDO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsaUJBQUE7OztBQ0FBLElBQUFRLGNBQUEsR0FBd0JDLE9BQUE7QUFDeEIsSUFBQUMsZ0JBQUEsR0FBMEJELE9BQUE7QUFDMUIsSUFBQUUsb0JBQUEsR0FBOEJGLE9BQUE7QUFDOUIsSUFBQUcsYUFBQSxHQUF1QkgsT0FBQTtBQTBDaEIsU0FBU1AsSUFBSVcsSUFBQSxFQUFNQyxRQUFBLEVBQVU7RUFDbEMsTUFBTTtJQUNKQyxLQUFBLEdBQVE7SUFDUkMsTUFBQSxHQUFTO0lBQ1RDLEtBQUEsR0FBUTtJQUNSQyxJQUFBLEdBQU87SUFDUEMsS0FBQSxHQUFRO0lBQ1JDLE9BQUEsR0FBVTtJQUNWQyxPQUFBLEdBQVU7RUFDWixJQUFJUCxRQUFBO0VBR0osTUFBTVEsS0FBQSxPQUFRVixhQUFBLENBQUFXLE1BQUEsRUFBT1YsSUFBSTtFQUN6QixNQUFNVyxjQUFBLEdBQ0pSLE1BQUEsSUFBVUQsS0FBQSxPQUFRTCxnQkFBQSxDQUFBZSxTQUFBLEVBQVVILEtBQUEsRUFBT04sTUFBQSxHQUFTRCxLQUFBLEdBQVEsRUFBRSxJQUFJTyxLQUFBO0VBRzVELE1BQU1JLFlBQUEsR0FDSlIsSUFBQSxJQUFRRCxLQUFBLE9BQVFULGNBQUEsQ0FBQW1CLE9BQUEsRUFBUUgsY0FBQSxFQUFnQk4sSUFBQSxHQUFPRCxLQUFBLEdBQVEsQ0FBQyxJQUFJTyxjQUFBO0VBRzlELE1BQU1JLFlBQUEsR0FBZVIsT0FBQSxHQUFVRCxLQUFBLEdBQVE7RUFDdkMsTUFBTVUsWUFBQSxHQUFlUixPQUFBLEdBQVVPLFlBQUEsR0FBZTtFQUM5QyxNQUFNRSxPQUFBLEdBQVVELFlBQUEsR0FBZTtFQUMvQixNQUFNRSxTQUFBLE9BQVlwQixvQkFBQSxDQUFBcUIsYUFBQSxFQUFjbkIsSUFBQSxFQUFNYSxZQUFBLENBQWFPLE9BQUEsQ0FBUSxJQUFJSCxPQUFPO0VBRXRFLE9BQU9DLFNBQUE7QUFDVDtBQUdBLElBQU9HLFdBQUEsR0FBUWhDLEdBQUE7OztBRHhFZixJQUFPRSxpQkFBQSxHQUFROEIsV0FBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==