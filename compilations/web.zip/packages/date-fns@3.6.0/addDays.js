System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/constructFrom"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/addDays.3.6.0.js
var addDays_3_6_0_exports = {};
__export(addDays_3_6_0_exports, {
  addDays: () => addDays,
  default: () => addDays_3_6_0_default
});
module.exports = __toCommonJS(addDays_3_6_0_exports);

// node_modules/date-fns/addDays.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
var import_constructFrom = require("date-fns@3.6.0/constructFrom");
function addDays(date, amount) {
  const _date = (0, import_toDate.toDate)(date);
  if (isNaN(amount)) return (0, import_constructFrom.constructFrom)(date, NaN);
  if (!amount) {
    return _date;
  }
  _date.setDate(_date.getDate() + amount);
  return _date;
}
var addDays_default = addDays;

// .beyond/uimport/temp/date-fns/addDays.3.6.0.js
var addDays_3_6_0_default = addDays_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2FkZERheXMuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvYWRkRGF5cy5tanMiXSwibmFtZXMiOlsiYWRkRGF5c18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJhZGREYXlzIiwiZGVmYXVsdCIsImFkZERheXNfM182XzBfZGVmYXVsdCIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfdG9EYXRlIiwicmVxdWlyZSIsImltcG9ydF9jb25zdHJ1Y3RGcm9tIiwiZGF0ZSIsImFtb3VudCIsIl9kYXRlIiwidG9EYXRlIiwiaXNOYU4iLCJjb25zdHJ1Y3RGcm9tIiwiTmFOIiwic2V0RGF0ZSIsImdldERhdGUiLCJhZGREYXlzX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLHFCQUFBO0FBQUFDLFFBQUEsQ0FBQUQscUJBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFBLE9BQUE7RUFBQUMsT0FBQSxFQUFBQSxDQUFBLEtBQUFDO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAscUJBQUE7OztBQ0FBLElBQUFRLGFBQUEsR0FBdUJDLE9BQUE7QUFDdkIsSUFBQUMsb0JBQUEsR0FBOEJELE9BQUE7QUFzQnZCLFNBQVNQLFFBQVFTLElBQUEsRUFBTUMsTUFBQSxFQUFRO0VBQ3BDLE1BQU1DLEtBQUEsT0FBUUwsYUFBQSxDQUFBTSxNQUFBLEVBQU9ILElBQUk7RUFDekIsSUFBSUksS0FBQSxDQUFNSCxNQUFNLEdBQUcsV0FBT0Ysb0JBQUEsQ0FBQU0sYUFBQSxFQUFjTCxJQUFBLEVBQU1NLEdBQUc7RUFDakQsSUFBSSxDQUFDTCxNQUFBLEVBQVE7SUFFWCxPQUFPQyxLQUFBO0VBQ1Q7RUFDQUEsS0FBQSxDQUFNSyxPQUFBLENBQVFMLEtBQUEsQ0FBTU0sT0FBQSxDQUFRLElBQUlQLE1BQU07RUFDdEMsT0FBT0MsS0FBQTtBQUNUO0FBR0EsSUFBT08sZUFBQSxHQUFRbEIsT0FBQTs7O0FEaENmLElBQU9FLHFCQUFBLEdBQVFnQixlQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9