System.register(["date-fns@3.6.0/constructFrom","date-fns@3.6.0/toDate","date-fns@3.6.0/startOfWeek","date-fns@3.6.0/startOfISOWeek","date-fns@3.6.0/getISOWeekYear","date-fns@3.6.0/constants","date-fns@3.6.0/startOfDay","date-fns@3.6.0/differenceInCalendarDays","date-fns@3.6.0/startOfISOWeekYear","date-fns@3.6.0/setISOWeekYear"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfWeek', dep), dep => dependencies.set('date-fns@3.6.0/startOfISOWeek', dep), dep => dependencies.set('date-fns@3.6.0/getISOWeekYear', dep), dep => dependencies.set('date-fns@3.6.0/constants', dep), dep => dependencies.set('date-fns@3.6.0/startOfDay', dep), dep => dependencies.set('date-fns@3.6.0/differenceInCalendarDays', dep), dep => dependencies.set('date-fns@3.6.0/startOfISOWeekYear', dep), dep => dependencies.set('date-fns@3.6.0/setISOWeekYear', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/addISOWeekYears.3.6.0.js
var addISOWeekYears_3_6_0_exports = {};
__export(addISOWeekYears_3_6_0_exports, {
  addISOWeekYears: () => addISOWeekYears,
  default: () => addISOWeekYears_3_6_0_default
});
module.exports = __toCommonJS(addISOWeekYears_3_6_0_exports);

// node_modules/date-fns/addISOWeekYears.mjs
var import_getISOWeekYear = require("date-fns@3.6.0/getISOWeekYear");
var import_setISOWeekYear = require("date-fns@3.6.0/setISOWeekYear");
function addISOWeekYears(date, amount) {
  return (0, import_setISOWeekYear.setISOWeekYear)(date, (0, import_getISOWeekYear.getISOWeekYear)(date) + amount);
}
var addISOWeekYears_default = addISOWeekYears;

// .beyond/uimport/temp/date-fns/addISOWeekYears.3.6.0.js
var addISOWeekYears_3_6_0_default = addISOWeekYears_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2FkZElTT1dlZWtZZWFycy4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9hZGRJU09XZWVrWWVhcnMubWpzIl0sIm5hbWVzIjpbImFkZElTT1dlZWtZZWFyc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJhZGRJU09XZWVrWWVhcnMiLCJkZWZhdWx0IiwiYWRkSVNPV2Vla1llYXJzXzNfNl8wX2RlZmF1bHQiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2dldElTT1dlZWtZZWFyIiwicmVxdWlyZSIsImltcG9ydF9zZXRJU09XZWVrWWVhciIsImRhdGUiLCJhbW91bnQiLCJzZXRJU09XZWVrWWVhciIsImdldElTT1dlZWtZZWFyIiwiYWRkSVNPV2Vla1llYXJzX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLDZCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsNkJBQUE7RUFBQUUsZUFBQSxFQUFBQSxDQUFBLEtBQUFBLGVBQUE7RUFBQUMsT0FBQSxFQUFBQSxDQUFBLEtBQUFDO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsNkJBQUE7OztBQ0FBLElBQUFRLHFCQUFBLEdBQStCQyxPQUFBO0FBQy9CLElBQUFDLHFCQUFBLEdBQStCRCxPQUFBO0FBd0J4QixTQUFTUCxnQkFBZ0JTLElBQUEsRUFBTUMsTUFBQSxFQUFRO0VBQzVDLFdBQU9GLHFCQUFBLENBQUFHLGNBQUEsRUFBZUYsSUFBQSxNQUFNSCxxQkFBQSxDQUFBTSxjQUFBLEVBQWVILElBQUksSUFBSUMsTUFBTTtBQUMzRDtBQUdBLElBQU9HLHVCQUFBLEdBQVFiLGVBQUE7OztBRDNCZixJQUFPRSw2QkFBQSxHQUFRVyx1QkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==