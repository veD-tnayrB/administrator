System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/constructFrom"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/addMilliseconds.3.6.0.js
var addMilliseconds_3_6_0_exports = {};
__export(addMilliseconds_3_6_0_exports, {
  addMilliseconds: () => addMilliseconds,
  default: () => addMilliseconds_3_6_0_default
});
module.exports = __toCommonJS(addMilliseconds_3_6_0_exports);

// node_modules/date-fns/addMilliseconds.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
var import_constructFrom = require("date-fns@3.6.0/constructFrom");
function addMilliseconds(date, amount) {
  const timestamp = +(0, import_toDate.toDate)(date);
  return (0, import_constructFrom.constructFrom)(date, timestamp + amount);
}
var addMilliseconds_default = addMilliseconds;

// .beyond/uimport/temp/date-fns/addMilliseconds.3.6.0.js
var addMilliseconds_3_6_0_default = addMilliseconds_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2FkZE1pbGxpc2Vjb25kcy4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9hZGRNaWxsaXNlY29uZHMubWpzIl0sIm5hbWVzIjpbImFkZE1pbGxpc2Vjb25kc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJhZGRNaWxsaXNlY29uZHMiLCJkZWZhdWx0IiwiYWRkTWlsbGlzZWNvbmRzXzNfNl8wX2RlZmF1bHQiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X3RvRGF0ZSIsInJlcXVpcmUiLCJpbXBvcnRfY29uc3RydWN0RnJvbSIsImRhdGUiLCJhbW91bnQiLCJ0aW1lc3RhbXAiLCJ0b0RhdGUiLCJjb25zdHJ1Y3RGcm9tIiwiYWRkTWlsbGlzZWNvbmRzX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLDZCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsNkJBQUE7RUFBQUUsZUFBQSxFQUFBQSxDQUFBLEtBQUFBLGVBQUE7RUFBQUMsT0FBQSxFQUFBQSxDQUFBLEtBQUFDO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsNkJBQUE7OztBQ0FBLElBQUFRLGFBQUEsR0FBdUJDLE9BQUE7QUFDdkIsSUFBQUMsb0JBQUEsR0FBOEJELE9BQUE7QUFzQnZCLFNBQVNQLGdCQUFnQlMsSUFBQSxFQUFNQyxNQUFBLEVBQVE7RUFDNUMsTUFBTUMsU0FBQSxHQUFZLEtBQUNMLGFBQUEsQ0FBQU0sTUFBQSxFQUFPSCxJQUFJO0VBQzlCLFdBQU9ELG9CQUFBLENBQUFLLGFBQUEsRUFBY0osSUFBQSxFQUFNRSxTQUFBLEdBQVlELE1BQU07QUFDL0M7QUFHQSxJQUFPSSx1QkFBQSxHQUFRZCxlQUFBOzs7QUQxQmYsSUFBT0UsNkJBQUEsR0FBUVksdUJBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=