System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/constructFrom"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/addMonths.3.6.0.js
var addMonths_3_6_0_exports = {};
__export(addMonths_3_6_0_exports, {
  addMonths: () => addMonths,
  default: () => addMonths_3_6_0_default
});
module.exports = __toCommonJS(addMonths_3_6_0_exports);

// node_modules/date-fns/addMonths.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
var import_constructFrom = require("date-fns@3.6.0/constructFrom");
function addMonths(date, amount) {
  const _date = (0, import_toDate.toDate)(date);
  if (isNaN(amount)) return (0, import_constructFrom.constructFrom)(date, NaN);
  if (!amount) {
    return _date;
  }
  const dayOfMonth = _date.getDate();
  const endOfDesiredMonth = (0, import_constructFrom.constructFrom)(date, _date.getTime());
  endOfDesiredMonth.setMonth(_date.getMonth() + amount + 1, 0);
  const daysInMonth = endOfDesiredMonth.getDate();
  if (dayOfMonth >= daysInMonth) {
    return endOfDesiredMonth;
  } else {
    _date.setFullYear(endOfDesiredMonth.getFullYear(), endOfDesiredMonth.getMonth(), dayOfMonth);
    return _date;
  }
}
var addMonths_default = addMonths;

// .beyond/uimport/temp/date-fns/addMonths.3.6.0.js
var addMonths_3_6_0_default = addMonths_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2FkZE1vbnRocy4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9hZGRNb250aHMubWpzIl0sIm5hbWVzIjpbImFkZE1vbnRoc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJhZGRNb250aHMiLCJkZWZhdWx0IiwiYWRkTW9udGhzXzNfNl8wX2RlZmF1bHQiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X3RvRGF0ZSIsInJlcXVpcmUiLCJpbXBvcnRfY29uc3RydWN0RnJvbSIsImRhdGUiLCJhbW91bnQiLCJfZGF0ZSIsInRvRGF0ZSIsImlzTmFOIiwiY29uc3RydWN0RnJvbSIsIk5hTiIsImRheU9mTW9udGgiLCJnZXREYXRlIiwiZW5kT2ZEZXNpcmVkTW9udGgiLCJnZXRUaW1lIiwic2V0TW9udGgiLCJnZXRNb250aCIsImRheXNJbk1vbnRoIiwic2V0RnVsbFllYXIiLCJnZXRGdWxsWWVhciIsImFkZE1vbnRoc19kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSx1QkFBQTtBQUFBQyxRQUFBLENBQUFELHVCQUFBO0VBQUFFLFNBQUEsRUFBQUEsQ0FBQSxLQUFBQSxTQUFBO0VBQUFDLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQztBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLHVCQUFBOzs7QUNBQSxJQUFBUSxhQUFBLEdBQXVCQyxPQUFBO0FBQ3ZCLElBQUFDLG9CQUFBLEdBQThCRCxPQUFBO0FBMEJ2QixTQUFTUCxVQUFVUyxJQUFBLEVBQU1DLE1BQUEsRUFBUTtFQUN0QyxNQUFNQyxLQUFBLE9BQVFMLGFBQUEsQ0FBQU0sTUFBQSxFQUFPSCxJQUFJO0VBQ3pCLElBQUlJLEtBQUEsQ0FBTUgsTUFBTSxHQUFHLFdBQU9GLG9CQUFBLENBQUFNLGFBQUEsRUFBY0wsSUFBQSxFQUFNTSxHQUFHO0VBQ2pELElBQUksQ0FBQ0wsTUFBQSxFQUFRO0lBRVgsT0FBT0MsS0FBQTtFQUNUO0VBQ0EsTUFBTUssVUFBQSxHQUFhTCxLQUFBLENBQU1NLE9BQUEsQ0FBUTtFQVVqQyxNQUFNQyxpQkFBQSxPQUFvQlYsb0JBQUEsQ0FBQU0sYUFBQSxFQUFjTCxJQUFBLEVBQU1FLEtBQUEsQ0FBTVEsT0FBQSxDQUFRLENBQUM7RUFDN0RELGlCQUFBLENBQWtCRSxRQUFBLENBQVNULEtBQUEsQ0FBTVUsUUFBQSxDQUFTLElBQUlYLE1BQUEsR0FBUyxHQUFHLENBQUM7RUFDM0QsTUFBTVksV0FBQSxHQUFjSixpQkFBQSxDQUFrQkQsT0FBQSxDQUFRO0VBQzlDLElBQUlELFVBQUEsSUFBY00sV0FBQSxFQUFhO0lBRzdCLE9BQU9KLGlCQUFBO0VBQ1QsT0FBTztJQVFMUCxLQUFBLENBQU1ZLFdBQUEsQ0FDSkwsaUJBQUEsQ0FBa0JNLFdBQUEsQ0FBWSxHQUM5Qk4saUJBQUEsQ0FBa0JHLFFBQUEsQ0FBUyxHQUMzQkwsVUFDRjtJQUNBLE9BQU9MLEtBQUE7RUFDVDtBQUNGO0FBR0EsSUFBT2MsaUJBQUEsR0FBUXpCLFNBQUE7OztBRGxFZixJQUFPRSx1QkFBQSxHQUFRdUIsaUJBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=