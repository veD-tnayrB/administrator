System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/constructFrom","date-fns@3.6.0/addMonths"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/addMonths', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/addQuarters.3.6.0.js
var addQuarters_3_6_0_exports = {};
__export(addQuarters_3_6_0_exports, {
  addQuarters: () => addQuarters,
  default: () => addQuarters_3_6_0_default
});
module.exports = __toCommonJS(addQuarters_3_6_0_exports);

// node_modules/date-fns/addQuarters.mjs
var import_addMonths = require("date-fns@3.6.0/addMonths");
function addQuarters(date, amount) {
  const months = amount * 3;
  return (0, import_addMonths.addMonths)(date, months);
}
var addQuarters_default = addQuarters;

// .beyond/uimport/temp/date-fns/addQuarters.3.6.0.js
var addQuarters_3_6_0_default = addQuarters_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2FkZFF1YXJ0ZXJzLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2FkZFF1YXJ0ZXJzLm1qcyJdLCJuYW1lcyI6WyJhZGRRdWFydGVyc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJhZGRRdWFydGVycyIsImRlZmF1bHQiLCJhZGRRdWFydGVyc18zXzZfMF9kZWZhdWx0IiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF9hZGRNb250aHMiLCJyZXF1aXJlIiwiZGF0ZSIsImFtb3VudCIsIm1vbnRocyIsImFkZE1vbnRocyIsImFkZFF1YXJ0ZXJzX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLHlCQUFBO0FBQUFDLFFBQUEsQ0FBQUQseUJBQUE7RUFBQUUsV0FBQSxFQUFBQSxDQUFBLEtBQUFBLFdBQUE7RUFBQUMsT0FBQSxFQUFBQSxDQUFBLEtBQUFDO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAseUJBQUE7OztBQ0FBLElBQUFRLGdCQUFBLEdBQTBCQyxPQUFBO0FBc0JuQixTQUFTUCxZQUFZUSxJQUFBLEVBQU1DLE1BQUEsRUFBUTtFQUN4QyxNQUFNQyxNQUFBLEdBQVNELE1BQUEsR0FBUztFQUN4QixXQUFPSCxnQkFBQSxDQUFBSyxTQUFBLEVBQVVILElBQUEsRUFBTUUsTUFBTTtBQUMvQjtBQUdBLElBQU9FLG1CQUFBLEdBQVFaLFdBQUE7OztBRHpCZixJQUFPRSx5QkFBQSxHQUFRVSxtQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==