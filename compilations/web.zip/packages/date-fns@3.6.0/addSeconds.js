System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/constructFrom","date-fns@3.6.0/addMilliseconds"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/addMilliseconds', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/addSeconds.3.6.0.js
var addSeconds_3_6_0_exports = {};
__export(addSeconds_3_6_0_exports, {
  addSeconds: () => addSeconds,
  default: () => addSeconds_3_6_0_default
});
module.exports = __toCommonJS(addSeconds_3_6_0_exports);

// node_modules/date-fns/addSeconds.mjs
var import_addMilliseconds = require("date-fns@3.6.0/addMilliseconds");
function addSeconds(date, amount) {
  return (0, import_addMilliseconds.addMilliseconds)(date, amount * 1e3);
}
var addSeconds_default = addSeconds;

// .beyond/uimport/temp/date-fns/addSeconds.3.6.0.js
var addSeconds_3_6_0_default = addSeconds_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2FkZFNlY29uZHMuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvYWRkU2Vjb25kcy5tanMiXSwibmFtZXMiOlsiYWRkU2Vjb25kc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJhZGRTZWNvbmRzIiwiZGVmYXVsdCIsImFkZFNlY29uZHNfM182XzBfZGVmYXVsdCIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfYWRkTWlsbGlzZWNvbmRzIiwicmVxdWlyZSIsImRhdGUiLCJhbW91bnQiLCJhZGRNaWxsaXNlY29uZHMiLCJhZGRTZWNvbmRzX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLHdCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsd0JBQUE7RUFBQUUsVUFBQSxFQUFBQSxDQUFBLEtBQUFBLFVBQUE7RUFBQUMsT0FBQSxFQUFBQSxDQUFBLEtBQUFDO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsd0JBQUE7OztBQ0FBLElBQUFRLHNCQUFBLEdBQWdDQyxPQUFBO0FBc0J6QixTQUFTUCxXQUFXUSxJQUFBLEVBQU1DLE1BQUEsRUFBUTtFQUN2QyxXQUFPSCxzQkFBQSxDQUFBSSxlQUFBLEVBQWdCRixJQUFBLEVBQU1DLE1BQUEsR0FBUyxHQUFJO0FBQzVDO0FBR0EsSUFBT0Usa0JBQUEsR0FBUVgsVUFBQTs7O0FEeEJmLElBQU9FLHdCQUFBLEdBQVFTLGtCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9