System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/max","date-fns@3.6.0/min"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/max', dep), dep => dependencies.set('date-fns@3.6.0/min', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/clamp.3.6.0.js
var clamp_3_6_0_exports = {};
__export(clamp_3_6_0_exports, {
  clamp: () => clamp,
  default: () => clamp_3_6_0_default
});
module.exports = __toCommonJS(clamp_3_6_0_exports);

// node_modules/date-fns/clamp.mjs
var import_max = require("date-fns@3.6.0/max");
var import_min = require("date-fns@3.6.0/min");
function clamp(date, interval) {
  return (0, import_min.min)([(0, import_max.max)([date, interval.start]), interval.end]);
}
var clamp_default = clamp;

// .beyond/uimport/temp/date-fns/clamp.3.6.0.js
var clamp_3_6_0_default = clamp_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2NsYW1wLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2NsYW1wLm1qcyJdLCJuYW1lcyI6WyJjbGFtcF8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJjbGFtcCIsImRlZmF1bHQiLCJjbGFtcF8zXzZfMF9kZWZhdWx0IiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF9tYXgiLCJyZXF1aXJlIiwiaW1wb3J0X21pbiIsImRhdGUiLCJpbnRlcnZhbCIsIm1pbiIsIm1heCIsInN0YXJ0IiwiZW5kIiwiY2xhbXBfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsbUJBQUE7QUFBQUMsUUFBQSxDQUFBRCxtQkFBQTtFQUFBRSxLQUFBLEVBQUFBLENBQUEsS0FBQUEsS0FBQTtFQUFBQyxPQUFBLEVBQUFBLENBQUEsS0FBQUM7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCxtQkFBQTs7O0FDQUEsSUFBQVEsVUFBQSxHQUFvQkMsT0FBQTtBQUNwQixJQUFBQyxVQUFBLEdBQW9CRCxPQUFBO0FBOEJiLFNBQVNQLE1BQU1TLElBQUEsRUFBTUMsUUFBQSxFQUFVO0VBQ3BDLFdBQU9GLFVBQUEsQ0FBQUcsR0FBQSxFQUFJLEtBQUNMLFVBQUEsQ0FBQU0sR0FBQSxFQUFJLENBQUNILElBQUEsRUFBTUMsUUFBQSxDQUFTRyxLQUFLLENBQUMsR0FBR0gsUUFBQSxDQUFTSSxHQUFHLENBQUM7QUFDeEQ7QUFHQSxJQUFPQyxhQUFBLEdBQVFmLEtBQUE7OztBRGpDZixJQUFPRSxtQkFBQSxHQUFRYSxhQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9