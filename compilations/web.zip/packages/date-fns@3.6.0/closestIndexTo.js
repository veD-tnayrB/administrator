System.register(["date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/closestIndexTo.3.6.0.js
var closestIndexTo_3_6_0_exports = {};
__export(closestIndexTo_3_6_0_exports, {
  closestIndexTo: () => closestIndexTo,
  default: () => closestIndexTo_3_6_0_default
});
module.exports = __toCommonJS(closestIndexTo_3_6_0_exports);

// node_modules/date-fns/closestIndexTo.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function closestIndexTo(dateToCompare, dates) {
  const date = (0, import_toDate.toDate)(dateToCompare);
  if (isNaN(Number(date))) return NaN;
  const timeToCompare = date.getTime();
  let result;
  let minDistance;
  dates.forEach(function (dirtyDate, index) {
    const currentDate = (0, import_toDate.toDate)(dirtyDate);
    if (isNaN(Number(currentDate))) {
      result = NaN;
      minDistance = NaN;
      return;
    }
    const distance = Math.abs(timeToCompare - currentDate.getTime());
    if (result == null || distance < minDistance) {
      result = index;
      minDistance = distance;
    }
  });
  return result;
}
var closestIndexTo_default = closestIndexTo;

// .beyond/uimport/temp/date-fns/closestIndexTo.3.6.0.js
var closestIndexTo_3_6_0_default = closestIndexTo_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2Nsb3Nlc3RJbmRleFRvLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2Nsb3Nlc3RJbmRleFRvLm1qcyJdLCJuYW1lcyI6WyJjbG9zZXN0SW5kZXhUb18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJjbG9zZXN0SW5kZXhUbyIsImRlZmF1bHQiLCJjbG9zZXN0SW5kZXhUb18zXzZfMF9kZWZhdWx0IiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF90b0RhdGUiLCJyZXF1aXJlIiwiZGF0ZVRvQ29tcGFyZSIsImRhdGVzIiwiZGF0ZSIsInRvRGF0ZSIsImlzTmFOIiwiTnVtYmVyIiwiTmFOIiwidGltZVRvQ29tcGFyZSIsImdldFRpbWUiLCJyZXN1bHQiLCJtaW5EaXN0YW5jZSIsImZvckVhY2giLCJkaXJ0eURhdGUiLCJpbmRleCIsImN1cnJlbnREYXRlIiwiZGlzdGFuY2UiLCJNYXRoIiwiYWJzIiwiY2xvc2VzdEluZGV4VG9fZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsNEJBQUE7QUFBQUMsUUFBQSxDQUFBRCw0QkFBQTtFQUFBRSxjQUFBLEVBQUFBLENBQUEsS0FBQUEsY0FBQTtFQUFBQyxPQUFBLEVBQUFBLENBQUEsS0FBQUM7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCw0QkFBQTs7O0FDQUEsSUFBQVEsYUFBQSxHQUF1QkMsT0FBQTtBQTRCaEIsU0FBU1AsZUFBZVEsYUFBQSxFQUFlQyxLQUFBLEVBQU87RUFDbkQsTUFBTUMsSUFBQSxPQUFPSixhQUFBLENBQUFLLE1BQUEsRUFBT0gsYUFBYTtFQUVqQyxJQUFJSSxLQUFBLENBQU1DLE1BQUEsQ0FBT0gsSUFBSSxDQUFDLEdBQUcsT0FBT0ksR0FBQTtFQUVoQyxNQUFNQyxhQUFBLEdBQWdCTCxJQUFBLENBQUtNLE9BQUEsQ0FBUTtFQUVuQyxJQUFJQyxNQUFBO0VBQ0osSUFBSUMsV0FBQTtFQUNKVCxLQUFBLENBQU1VLE9BQUEsQ0FBUSxVQUFVQyxTQUFBLEVBQVdDLEtBQUEsRUFBTztJQUN4QyxNQUFNQyxXQUFBLE9BQWNoQixhQUFBLENBQUFLLE1BQUEsRUFBT1MsU0FBUztJQUVwQyxJQUFJUixLQUFBLENBQU1DLE1BQUEsQ0FBT1MsV0FBVyxDQUFDLEdBQUc7TUFDOUJMLE1BQUEsR0FBU0gsR0FBQTtNQUNUSSxXQUFBLEdBQWNKLEdBQUE7TUFDZDtJQUNGO0lBRUEsTUFBTVMsUUFBQSxHQUFXQyxJQUFBLENBQUtDLEdBQUEsQ0FBSVYsYUFBQSxHQUFnQk8sV0FBQSxDQUFZTixPQUFBLENBQVEsQ0FBQztJQUMvRCxJQUFJQyxNQUFBLElBQVUsUUFBUU0sUUFBQSxHQUFXTCxXQUFBLEVBQWE7TUFDNUNELE1BQUEsR0FBU0ksS0FBQTtNQUNUSCxXQUFBLEdBQWNLLFFBQUE7SUFDaEI7RUFDRixDQUFDO0VBRUQsT0FBT04sTUFBQTtBQUNUO0FBR0EsSUFBT1Msc0JBQUEsR0FBUTFCLGNBQUE7OztBRHREZixJQUFPRSw0QkFBQSxHQUFRd0Isc0JBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=