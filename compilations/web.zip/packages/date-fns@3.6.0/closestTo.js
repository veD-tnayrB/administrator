System.register(["date-fns@3.6.0/constructFrom","date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/closestTo.3.6.0.js
var closestTo_3_6_0_exports = {};
__export(closestTo_3_6_0_exports, {
  closestTo: () => closestTo,
  default: () => closestTo_3_6_0_default
});
module.exports = __toCommonJS(closestTo_3_6_0_exports);

// node_modules/date-fns/closestTo.mjs
var import_constructFrom = require("date-fns@3.6.0/constructFrom");
var import_toDate = require("date-fns@3.6.0/toDate");
function closestTo(dateToCompare, dates) {
  const date = (0, import_toDate.toDate)(dateToCompare);
  if (isNaN(Number(date))) return (0, import_constructFrom.constructFrom)(dateToCompare, NaN);
  const timeToCompare = date.getTime();
  let result;
  let minDistance;
  dates.forEach(dirtyDate => {
    const currentDate = (0, import_toDate.toDate)(dirtyDate);
    if (isNaN(Number(currentDate))) {
      result = (0, import_constructFrom.constructFrom)(dateToCompare, NaN);
      minDistance = NaN;
      return;
    }
    const distance = Math.abs(timeToCompare - currentDate.getTime());
    if (result == null || distance < minDistance) {
      result = currentDate;
      minDistance = distance;
    }
  });
  return result;
}
var closestTo_default = closestTo;

// .beyond/uimport/temp/date-fns/closestTo.3.6.0.js
var closestTo_3_6_0_default = closestTo_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2Nsb3Nlc3RUby4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9jbG9zZXN0VG8ubWpzIl0sIm5hbWVzIjpbImNsb3Nlc3RUb18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJjbG9zZXN0VG8iLCJkZWZhdWx0IiwiY2xvc2VzdFRvXzNfNl8wX2RlZmF1bHQiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2NvbnN0cnVjdEZyb20iLCJyZXF1aXJlIiwiaW1wb3J0X3RvRGF0ZSIsImRhdGVUb0NvbXBhcmUiLCJkYXRlcyIsImRhdGUiLCJ0b0RhdGUiLCJpc05hTiIsIk51bWJlciIsImNvbnN0cnVjdEZyb20iLCJOYU4iLCJ0aW1lVG9Db21wYXJlIiwiZ2V0VGltZSIsInJlc3VsdCIsIm1pbkRpc3RhbmNlIiwiZm9yRWFjaCIsImRpcnR5RGF0ZSIsImN1cnJlbnREYXRlIiwiZGlzdGFuY2UiLCJNYXRoIiwiYWJzIiwiY2xvc2VzdFRvX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLHVCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsdUJBQUE7RUFBQUUsU0FBQSxFQUFBQSxDQUFBLEtBQUFBLFNBQUE7RUFBQUMsT0FBQSxFQUFBQSxDQUFBLEtBQUFDO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsdUJBQUE7OztBQ0FBLElBQUFRLG9CQUFBLEdBQThCQyxPQUFBO0FBQzlCLElBQUFDLGFBQUEsR0FBdUJELE9BQUE7QUEwQmhCLFNBQVNQLFVBQVVTLGFBQUEsRUFBZUMsS0FBQSxFQUFPO0VBQzlDLE1BQU1DLElBQUEsT0FBT0gsYUFBQSxDQUFBSSxNQUFBLEVBQU9ILGFBQWE7RUFFakMsSUFBSUksS0FBQSxDQUFNQyxNQUFBLENBQU9ILElBQUksQ0FBQyxHQUFHLFdBQU9MLG9CQUFBLENBQUFTLGFBQUEsRUFBY04sYUFBQSxFQUFlTyxHQUFHO0VBRWhFLE1BQU1DLGFBQUEsR0FBZ0JOLElBQUEsQ0FBS08sT0FBQSxDQUFRO0VBRW5DLElBQUlDLE1BQUE7RUFDSixJQUFJQyxXQUFBO0VBQ0pWLEtBQUEsQ0FBTVcsT0FBQSxDQUFTQyxTQUFBLElBQWM7SUFDM0IsTUFBTUMsV0FBQSxPQUFjZixhQUFBLENBQUFJLE1BQUEsRUFBT1UsU0FBUztJQUVwQyxJQUFJVCxLQUFBLENBQU1DLE1BQUEsQ0FBT1MsV0FBVyxDQUFDLEdBQUc7TUFDOUJKLE1BQUEsT0FBU2Isb0JBQUEsQ0FBQVMsYUFBQSxFQUFjTixhQUFBLEVBQWVPLEdBQUc7TUFDekNJLFdBQUEsR0FBY0osR0FBQTtNQUNkO0lBQ0Y7SUFFQSxNQUFNUSxRQUFBLEdBQVdDLElBQUEsQ0FBS0MsR0FBQSxDQUFJVCxhQUFBLEdBQWdCTSxXQUFBLENBQVlMLE9BQUEsQ0FBUSxDQUFDO0lBQy9ELElBQUlDLE1BQUEsSUFBVSxRQUFRSyxRQUFBLEdBQVdKLFdBQUEsRUFBYTtNQUM1Q0QsTUFBQSxHQUFTSSxXQUFBO01BQ1RILFdBQUEsR0FBY0ksUUFBQTtJQUNoQjtFQUNGLENBQUM7RUFFRCxPQUFPTCxNQUFBO0FBQ1Q7QUFHQSxJQUFPUSxpQkFBQSxHQUFRM0IsU0FBQTs7O0FEckRmLElBQU9FLHVCQUFBLEdBQVF5QixpQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==