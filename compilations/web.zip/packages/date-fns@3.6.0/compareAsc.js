System.register(["date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/compareAsc.3.6.0.js
var compareAsc_3_6_0_exports = {};
__export(compareAsc_3_6_0_exports, {
  compareAsc: () => compareAsc,
  default: () => compareAsc_3_6_0_default
});
module.exports = __toCommonJS(compareAsc_3_6_0_exports);

// node_modules/date-fns/compareAsc.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function compareAsc(dateLeft, dateRight) {
  const _dateLeft = (0, import_toDate.toDate)(dateLeft);
  const _dateRight = (0, import_toDate.toDate)(dateRight);
  const diff = _dateLeft.getTime() - _dateRight.getTime();
  if (diff < 0) {
    return -1;
  } else if (diff > 0) {
    return 1;
  } else {
    return diff;
  }
}
var compareAsc_default = compareAsc;

// .beyond/uimport/temp/date-fns/compareAsc.3.6.0.js
var compareAsc_3_6_0_default = compareAsc_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2NvbXBhcmVBc2MuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvY29tcGFyZUFzYy5tanMiXSwibmFtZXMiOlsiY29tcGFyZUFzY18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJjb21wYXJlQXNjIiwiZGVmYXVsdCIsImNvbXBhcmVBc2NfM182XzBfZGVmYXVsdCIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfdG9EYXRlIiwicmVxdWlyZSIsImRhdGVMZWZ0IiwiZGF0ZVJpZ2h0IiwiX2RhdGVMZWZ0IiwidG9EYXRlIiwiX2RhdGVSaWdodCIsImRpZmYiLCJnZXRUaW1lIiwiY29tcGFyZUFzY19kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSx3QkFBQTtBQUFBQyxRQUFBLENBQUFELHdCQUFBO0VBQUFFLFVBQUEsRUFBQUEsQ0FBQSxLQUFBQSxVQUFBO0VBQUFDLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQztBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLHdCQUFBOzs7QUNBQSxJQUFBUSxhQUFBLEdBQXVCQyxPQUFBO0FBb0NoQixTQUFTUCxXQUFXUSxRQUFBLEVBQVVDLFNBQUEsRUFBVztFQUM5QyxNQUFNQyxTQUFBLE9BQVlKLGFBQUEsQ0FBQUssTUFBQSxFQUFPSCxRQUFRO0VBQ2pDLE1BQU1JLFVBQUEsT0FBYU4sYUFBQSxDQUFBSyxNQUFBLEVBQU9GLFNBQVM7RUFFbkMsTUFBTUksSUFBQSxHQUFPSCxTQUFBLENBQVVJLE9BQUEsQ0FBUSxJQUFJRixVQUFBLENBQVdFLE9BQUEsQ0FBUTtFQUV0RCxJQUFJRCxJQUFBLEdBQU8sR0FBRztJQUNaLE9BQU87RUFDVCxXQUFXQSxJQUFBLEdBQU8sR0FBRztJQUNuQixPQUFPO0VBRVQsT0FBTztJQUNMLE9BQU9BLElBQUE7RUFDVDtBQUNGO0FBR0EsSUFBT0Usa0JBQUEsR0FBUWYsVUFBQTs7O0FEbERmLElBQU9FLHdCQUFBLEdBQVFhLGtCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9