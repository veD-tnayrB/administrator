System.register(["date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/compareDesc.3.6.0.js
var compareDesc_3_6_0_exports = {};
__export(compareDesc_3_6_0_exports, {
  compareDesc: () => compareDesc,
  default: () => compareDesc_3_6_0_default
});
module.exports = __toCommonJS(compareDesc_3_6_0_exports);

// node_modules/date-fns/compareDesc.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function compareDesc(dateLeft, dateRight) {
  const _dateLeft = (0, import_toDate.toDate)(dateLeft);
  const _dateRight = (0, import_toDate.toDate)(dateRight);
  const diff = _dateLeft.getTime() - _dateRight.getTime();
  if (diff > 0) {
    return -1;
  } else if (diff < 0) {
    return 1;
  } else {
    return diff;
  }
}
var compareDesc_default = compareDesc;

// .beyond/uimport/temp/date-fns/compareDesc.3.6.0.js
var compareDesc_3_6_0_default = compareDesc_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2NvbXBhcmVEZXNjLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2NvbXBhcmVEZXNjLm1qcyJdLCJuYW1lcyI6WyJjb21wYXJlRGVzY18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJjb21wYXJlRGVzYyIsImRlZmF1bHQiLCJjb21wYXJlRGVzY18zXzZfMF9kZWZhdWx0IiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF90b0RhdGUiLCJyZXF1aXJlIiwiZGF0ZUxlZnQiLCJkYXRlUmlnaHQiLCJfZGF0ZUxlZnQiLCJ0b0RhdGUiLCJfZGF0ZVJpZ2h0IiwiZGlmZiIsImdldFRpbWUiLCJjb21wYXJlRGVzY19kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSx5QkFBQTtBQUFBQyxRQUFBLENBQUFELHlCQUFBO0VBQUFFLFdBQUEsRUFBQUEsQ0FBQSxLQUFBQSxXQUFBO0VBQUFDLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQztBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLHlCQUFBOzs7QUNBQSxJQUFBUSxhQUFBLEdBQXVCQyxPQUFBO0FBb0NoQixTQUFTUCxZQUFZUSxRQUFBLEVBQVVDLFNBQUEsRUFBVztFQUMvQyxNQUFNQyxTQUFBLE9BQVlKLGFBQUEsQ0FBQUssTUFBQSxFQUFPSCxRQUFRO0VBQ2pDLE1BQU1JLFVBQUEsT0FBYU4sYUFBQSxDQUFBSyxNQUFBLEVBQU9GLFNBQVM7RUFFbkMsTUFBTUksSUFBQSxHQUFPSCxTQUFBLENBQVVJLE9BQUEsQ0FBUSxJQUFJRixVQUFBLENBQVdFLE9BQUEsQ0FBUTtFQUV0RCxJQUFJRCxJQUFBLEdBQU8sR0FBRztJQUNaLE9BQU87RUFDVCxXQUFXQSxJQUFBLEdBQU8sR0FBRztJQUNuQixPQUFPO0VBRVQsT0FBTztJQUNMLE9BQU9BLElBQUE7RUFDVDtBQUNGO0FBR0EsSUFBT0UsbUJBQUEsR0FBUWYsV0FBQTs7O0FEbERmLElBQU9FLHlCQUFBLEdBQVFhLG1CQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9