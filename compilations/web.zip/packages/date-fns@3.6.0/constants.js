System.register([], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/constants.3.6.0.js
var constants_3_6_0_exports = {};
__export(constants_3_6_0_exports, {
  daysInWeek: () => daysInWeek,
  daysInYear: () => daysInYear,
  maxTime: () => maxTime,
  millisecondsInDay: () => millisecondsInDay,
  millisecondsInHour: () => millisecondsInHour,
  millisecondsInMinute: () => millisecondsInMinute,
  millisecondsInSecond: () => millisecondsInSecond,
  millisecondsInWeek: () => millisecondsInWeek,
  minTime: () => minTime,
  minutesInDay: () => minutesInDay,
  minutesInHour: () => minutesInHour,
  minutesInMonth: () => minutesInMonth,
  minutesInYear: () => minutesInYear,
  monthsInQuarter: () => monthsInQuarter,
  monthsInYear: () => monthsInYear,
  quartersInYear: () => quartersInYear,
  secondsInDay: () => secondsInDay,
  secondsInHour: () => secondsInHour,
  secondsInMinute: () => secondsInMinute,
  secondsInMonth: () => secondsInMonth,
  secondsInQuarter: () => secondsInQuarter,
  secondsInWeek: () => secondsInWeek,
  secondsInYear: () => secondsInYear
});
module.exports = __toCommonJS(constants_3_6_0_exports);

// node_modules/date-fns/constants.mjs
var daysInWeek = 7;
var daysInYear = 365.2425;
var maxTime = Math.pow(10, 8) * 24 * 60 * 60 * 1e3;
var minTime = -maxTime;
var millisecondsInWeek = 6048e5;
var millisecondsInDay = 864e5;
var millisecondsInMinute = 6e4;
var millisecondsInHour = 36e5;
var millisecondsInSecond = 1e3;
var minutesInYear = 525600;
var minutesInMonth = 43200;
var minutesInDay = 1440;
var minutesInHour = 60;
var monthsInQuarter = 3;
var monthsInYear = 12;
var quartersInYear = 4;
var secondsInHour = 3600;
var secondsInMinute = 60;
var secondsInDay = secondsInHour * 24;
var secondsInWeek = secondsInDay * 7;
var secondsInYear = secondsInDay * daysInYear;
var secondsInMonth = secondsInYear / 12;
var secondsInQuarter = secondsInMonth * 3;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2NvbnN0YW50cy4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9jb25zdGFudHMubWpzIl0sIm5hbWVzIjpbImNvbnN0YW50c18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkYXlzSW5XZWVrIiwiZGF5c0luWWVhciIsIm1heFRpbWUiLCJtaWxsaXNlY29uZHNJbkRheSIsIm1pbGxpc2Vjb25kc0luSG91ciIsIm1pbGxpc2Vjb25kc0luTWludXRlIiwibWlsbGlzZWNvbmRzSW5TZWNvbmQiLCJtaWxsaXNlY29uZHNJbldlZWsiLCJtaW5UaW1lIiwibWludXRlc0luRGF5IiwibWludXRlc0luSG91ciIsIm1pbnV0ZXNJbk1vbnRoIiwibWludXRlc0luWWVhciIsIm1vbnRoc0luUXVhcnRlciIsIm1vbnRoc0luWWVhciIsInF1YXJ0ZXJzSW5ZZWFyIiwic2Vjb25kc0luRGF5Iiwic2Vjb25kc0luSG91ciIsInNlY29uZHNJbk1pbnV0ZSIsInNlY29uZHNJbk1vbnRoIiwic2Vjb25kc0luUXVhcnRlciIsInNlY29uZHNJbldlZWsiLCJzZWNvbmRzSW5ZZWFyIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsIk1hdGgiLCJwb3ciXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLHVCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsdUJBQUE7RUFBQUUsVUFBQSxFQUFBQSxDQUFBLEtBQUFBLFVBQUE7RUFBQUMsVUFBQSxFQUFBQSxDQUFBLEtBQUFBLFVBQUE7RUFBQUMsT0FBQSxFQUFBQSxDQUFBLEtBQUFBLE9BQUE7RUFBQUMsaUJBQUEsRUFBQUEsQ0FBQSxLQUFBQSxpQkFBQTtFQUFBQyxrQkFBQSxFQUFBQSxDQUFBLEtBQUFBLGtCQUFBO0VBQUFDLG9CQUFBLEVBQUFBLENBQUEsS0FBQUEsb0JBQUE7RUFBQUMsb0JBQUEsRUFBQUEsQ0FBQSxLQUFBQSxvQkFBQTtFQUFBQyxrQkFBQSxFQUFBQSxDQUFBLEtBQUFBLGtCQUFBO0VBQUFDLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQSxPQUFBO0VBQUFDLFlBQUEsRUFBQUEsQ0FBQSxLQUFBQSxZQUFBO0VBQUFDLGFBQUEsRUFBQUEsQ0FBQSxLQUFBQSxhQUFBO0VBQUFDLGNBQUEsRUFBQUEsQ0FBQSxLQUFBQSxjQUFBO0VBQUFDLGFBQUEsRUFBQUEsQ0FBQSxLQUFBQSxhQUFBO0VBQUFDLGVBQUEsRUFBQUEsQ0FBQSxLQUFBQSxlQUFBO0VBQUFDLFlBQUEsRUFBQUEsQ0FBQSxLQUFBQSxZQUFBO0VBQUFDLGNBQUEsRUFBQUEsQ0FBQSxLQUFBQSxjQUFBO0VBQUFDLFlBQUEsRUFBQUEsQ0FBQSxLQUFBQSxZQUFBO0VBQUFDLGFBQUEsRUFBQUEsQ0FBQSxLQUFBQSxhQUFBO0VBQUFDLGVBQUEsRUFBQUEsQ0FBQSxLQUFBQSxlQUFBO0VBQUFDLGNBQUEsRUFBQUEsQ0FBQSxLQUFBQSxjQUFBO0VBQUFDLGdCQUFBLEVBQUFBLENBQUEsS0FBQUEsZ0JBQUE7RUFBQUMsYUFBQSxFQUFBQSxDQUFBLEtBQUFBLGFBQUE7RUFBQUMsYUFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQTNCLHVCQUFBOzs7QUNzQk8sSUFBTUUsVUFBQSxHQUFhO0FBZW5CLElBQU1DLFVBQUEsR0FBYTtBQWdCbkIsSUFBTUMsT0FBQSxHQUFVd0IsSUFBQSxDQUFLQyxHQUFBLENBQUksSUFBSSxDQUFDLElBQUksS0FBSyxLQUFLLEtBQUs7QUFnQmpELElBQU1uQixPQUFBLEdBQVUsQ0FBQ04sT0FBQTtBQU9qQixJQUFNSyxrQkFBQSxHQUFxQjtBQU8zQixJQUFNSixpQkFBQSxHQUFvQjtBQU8xQixJQUFNRSxvQkFBQSxHQUF1QjtBQU83QixJQUFNRCxrQkFBQSxHQUFxQjtBQU8zQixJQUFNRSxvQkFBQSxHQUF1QjtBQU83QixJQUFNTSxhQUFBLEdBQWdCO0FBT3RCLElBQU1ELGNBQUEsR0FBaUI7QUFPdkIsSUFBTUYsWUFBQSxHQUFlO0FBT3JCLElBQU1DLGFBQUEsR0FBZ0I7QUFPdEIsSUFBTUcsZUFBQSxHQUFrQjtBQU94QixJQUFNQyxZQUFBLEdBQWU7QUFPckIsSUFBTUMsY0FBQSxHQUFpQjtBQU92QixJQUFNRSxhQUFBLEdBQWdCO0FBT3RCLElBQU1DLGVBQUEsR0FBa0I7QUFPeEIsSUFBTUYsWUFBQSxHQUFlQyxhQUFBLEdBQWdCO0FBT3JDLElBQU1JLGFBQUEsR0FBZ0JMLFlBQUEsR0FBZTtBQU9yQyxJQUFNTSxhQUFBLEdBQWdCTixZQUFBLEdBQWVmLFVBQUE7QUFPckMsSUFBTWtCLGNBQUEsR0FBaUJHLGFBQUEsR0FBZ0I7QUFPdkMsSUFBTUYsZ0JBQUEsR0FBbUJELGNBQUEsR0FBaUIiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=