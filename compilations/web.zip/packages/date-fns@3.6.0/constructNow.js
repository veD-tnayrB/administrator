System.register(["date-fns@3.6.0/constructFrom"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constructFrom', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/constructNow.3.6.0.js
var constructNow_3_6_0_exports = {};
__export(constructNow_3_6_0_exports, {
  constructNow: () => constructNow,
  default: () => constructNow_3_6_0_default
});
module.exports = __toCommonJS(constructNow_3_6_0_exports);

// node_modules/date-fns/constructNow.mjs
var import_constructFrom = require("date-fns@3.6.0/constructFrom");
function constructNow(date) {
  return (0, import_constructFrom.constructFrom)(date, Date.now());
}
var constructNow_default = constructNow;

// .beyond/uimport/temp/date-fns/constructNow.3.6.0.js
var constructNow_3_6_0_default = constructNow_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2NvbnN0cnVjdE5vdy4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9jb25zdHJ1Y3ROb3cubWpzIl0sIm5hbWVzIjpbImNvbnN0cnVjdE5vd18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJjb25zdHJ1Y3ROb3ciLCJkZWZhdWx0IiwiY29uc3RydWN0Tm93XzNfNl8wX2RlZmF1bHQiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2NvbnN0cnVjdEZyb20iLCJyZXF1aXJlIiwiZGF0ZSIsImNvbnN0cnVjdEZyb20iLCJEYXRlIiwibm93IiwiY29uc3RydWN0Tm93X2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLDBCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsMEJBQUE7RUFBQUUsWUFBQSxFQUFBQSxDQUFBLEtBQUFBLFlBQUE7RUFBQUMsT0FBQSxFQUFBQSxDQUFBLEtBQUFDO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsMEJBQUE7OztBQ0FBLElBQUFRLG9CQUFBLEdBQThCQyxPQUFBO0FBZ0N2QixTQUFTUCxhQUFhUSxJQUFBLEVBQU07RUFDakMsV0FBT0Ysb0JBQUEsQ0FBQUcsYUFBQSxFQUFjRCxJQUFBLEVBQU1FLElBQUEsQ0FBS0MsR0FBQSxDQUFJLENBQUM7QUFDdkM7QUFHQSxJQUFPQyxvQkFBQSxHQUFRWixZQUFBOzs7QURsQ2YsSUFBT0UsMEJBQUEsR0FBUVUsb0JBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=