System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/constructFrom","date-fns@3.6.0/addDays","date-fns@3.6.0/constants","date-fns@3.6.0/startOfDay","date-fns@3.6.0/differenceInCalendarDays","date-fns@3.6.0/isSameDay","date-fns@3.6.0/isDate","date-fns@3.6.0/isValid","date-fns@3.6.0/isWeekend"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/addDays', dep), dep => dependencies.set('date-fns@3.6.0/constants', dep), dep => dependencies.set('date-fns@3.6.0/startOfDay', dep), dep => dependencies.set('date-fns@3.6.0/differenceInCalendarDays', dep), dep => dependencies.set('date-fns@3.6.0/isSameDay', dep), dep => dependencies.set('date-fns@3.6.0/isDate', dep), dep => dependencies.set('date-fns@3.6.0/isValid', dep), dep => dependencies.set('date-fns@3.6.0/isWeekend', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/differenceInBusinessDays.3.6.0.js
var differenceInBusinessDays_3_6_0_exports = {};
__export(differenceInBusinessDays_3_6_0_exports, {
  default: () => differenceInBusinessDays_3_6_0_default,
  differenceInBusinessDays: () => differenceInBusinessDays
});
module.exports = __toCommonJS(differenceInBusinessDays_3_6_0_exports);

// node_modules/date-fns/differenceInBusinessDays.mjs
var import_addDays = require("date-fns@3.6.0/addDays");
var import_differenceInCalendarDays = require("date-fns@3.6.0/differenceInCalendarDays");
var import_isSameDay = require("date-fns@3.6.0/isSameDay");
var import_isValid = require("date-fns@3.6.0/isValid");
var import_isWeekend = require("date-fns@3.6.0/isWeekend");
var import_toDate = require("date-fns@3.6.0/toDate");
function differenceInBusinessDays(dateLeft, dateRight) {
  const _dateLeft = (0, import_toDate.toDate)(dateLeft);
  let _dateRight = (0, import_toDate.toDate)(dateRight);
  if (!(0, import_isValid.isValid)(_dateLeft) || !(0, import_isValid.isValid)(_dateRight)) return NaN;
  const calendarDifference = (0, import_differenceInCalendarDays.differenceInCalendarDays)(_dateLeft, _dateRight);
  const sign = calendarDifference < 0 ? -1 : 1;
  const weeks = Math.trunc(calendarDifference / 7);
  let result = weeks * 5;
  _dateRight = (0, import_addDays.addDays)(_dateRight, weeks * 7);
  while (!(0, import_isSameDay.isSameDay)(_dateLeft, _dateRight)) {
    result += (0, import_isWeekend.isWeekend)(_dateRight) ? 0 : sign;
    _dateRight = (0, import_addDays.addDays)(_dateRight, sign);
  }
  return result === 0 ? 0 : result;
}
var differenceInBusinessDays_default = differenceInBusinessDays;

// .beyond/uimport/temp/date-fns/differenceInBusinessDays.3.6.0.js
var differenceInBusinessDays_3_6_0_default = differenceInBusinessDays_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2RpZmZlcmVuY2VJbkJ1c2luZXNzRGF5cy4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9kaWZmZXJlbmNlSW5CdXNpbmVzc0RheXMubWpzIl0sIm5hbWVzIjpbImRpZmZlcmVuY2VJbkJ1c2luZXNzRGF5c18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZGlmZmVyZW5jZUluQnVzaW5lc3NEYXlzXzNfNl8wX2RlZmF1bHQiLCJkaWZmZXJlbmNlSW5CdXNpbmVzc0RheXMiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2FkZERheXMiLCJyZXF1aXJlIiwiaW1wb3J0X2RpZmZlcmVuY2VJbkNhbGVuZGFyRGF5cyIsImltcG9ydF9pc1NhbWVEYXkiLCJpbXBvcnRfaXNWYWxpZCIsImltcG9ydF9pc1dlZWtlbmQiLCJpbXBvcnRfdG9EYXRlIiwiZGF0ZUxlZnQiLCJkYXRlUmlnaHQiLCJfZGF0ZUxlZnQiLCJ0b0RhdGUiLCJfZGF0ZVJpZ2h0IiwiaXNWYWxpZCIsIk5hTiIsImNhbGVuZGFyRGlmZmVyZW5jZSIsImRpZmZlcmVuY2VJbkNhbGVuZGFyRGF5cyIsInNpZ24iLCJ3ZWVrcyIsIk1hdGgiLCJ0cnVuYyIsInJlc3VsdCIsImFkZERheXMiLCJpc1NhbWVEYXkiLCJpc1dlZWtlbmQiLCJkaWZmZXJlbmNlSW5CdXNpbmVzc0RheXNfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsc0NBQUE7QUFBQUMsUUFBQSxDQUFBRCxzQ0FBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsc0NBQUE7RUFBQUMsd0JBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLHNDQUFBOzs7QUNBQSxJQUFBUSxjQUFBLEdBQXdCQyxPQUFBO0FBQ3hCLElBQUFDLCtCQUFBLEdBQXlDRCxPQUFBO0FBQ3pDLElBQUFFLGdCQUFBLEdBQTBCRixPQUFBO0FBQzFCLElBQUFHLGNBQUEsR0FBd0JILE9BQUE7QUFDeEIsSUFBQUksZ0JBQUEsR0FBMEJKLE9BQUE7QUFDMUIsSUFBQUssYUFBQSxHQUF1QkwsT0FBQTtBQXFEaEIsU0FBU0wseUJBQXlCVyxRQUFBLEVBQVVDLFNBQUEsRUFBVztFQUM1RCxNQUFNQyxTQUFBLE9BQVlILGFBQUEsQ0FBQUksTUFBQSxFQUFPSCxRQUFRO0VBQ2pDLElBQUlJLFVBQUEsT0FBYUwsYUFBQSxDQUFBSSxNQUFBLEVBQU9GLFNBQVM7RUFFakMsSUFBSSxLQUFDSixjQUFBLENBQUFRLE9BQUEsRUFBUUgsU0FBUyxLQUFLLEtBQUNMLGNBQUEsQ0FBQVEsT0FBQSxFQUFRRCxVQUFVLEdBQUcsT0FBT0UsR0FBQTtFQUV4RCxNQUFNQyxrQkFBQSxPQUFxQlosK0JBQUEsQ0FBQWEsd0JBQUEsRUFBeUJOLFNBQUEsRUFBV0UsVUFBVTtFQUN6RSxNQUFNSyxJQUFBLEdBQU9GLGtCQUFBLEdBQXFCLElBQUksS0FBSztFQUUzQyxNQUFNRyxLQUFBLEdBQVFDLElBQUEsQ0FBS0MsS0FBQSxDQUFNTCxrQkFBQSxHQUFxQixDQUFDO0VBRS9DLElBQUlNLE1BQUEsR0FBU0gsS0FBQSxHQUFRO0VBQ3JCTixVQUFBLE9BQWFYLGNBQUEsQ0FBQXFCLE9BQUEsRUFBUVYsVUFBQSxFQUFZTSxLQUFBLEdBQVEsQ0FBQztFQUcxQyxPQUFPLEtBQUNkLGdCQUFBLENBQUFtQixTQUFBLEVBQVViLFNBQUEsRUFBV0UsVUFBVSxHQUFHO0lBRXhDUyxNQUFBLFFBQVVmLGdCQUFBLENBQUFrQixTQUFBLEVBQVVaLFVBQVUsSUFBSSxJQUFJSyxJQUFBO0lBQ3RDTCxVQUFBLE9BQWFYLGNBQUEsQ0FBQXFCLE9BQUEsRUFBUVYsVUFBQSxFQUFZSyxJQUFJO0VBQ3ZDO0VBR0EsT0FBT0ksTUFBQSxLQUFXLElBQUksSUFBSUEsTUFBQTtBQUM1QjtBQUdBLElBQU9JLGdDQUFBLEdBQVE1Qix3QkFBQTs7O0FEakZmLElBQU9ELHNDQUFBLEdBQVE2QixnQ0FBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==