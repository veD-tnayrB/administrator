System.register(["date-fns@3.6.0/constants","date-fns@3.6.0/toDate","date-fns@3.6.0/startOfDay"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constants', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfDay', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/differenceInCalendarDays.3.6.0.js
var differenceInCalendarDays_3_6_0_exports = {};
__export(differenceInCalendarDays_3_6_0_exports, {
  default: () => differenceInCalendarDays_3_6_0_default,
  differenceInCalendarDays: () => differenceInCalendarDays
});
module.exports = __toCommonJS(differenceInCalendarDays_3_6_0_exports);

// node_modules/date-fns/_lib/getTimezoneOffsetInMilliseconds.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function getTimezoneOffsetInMilliseconds(date) {
  const _date = (0, import_toDate.toDate)(date);
  const utcDate = new Date(Date.UTC(_date.getFullYear(), _date.getMonth(), _date.getDate(), _date.getHours(), _date.getMinutes(), _date.getSeconds(), _date.getMilliseconds()));
  utcDate.setUTCFullYear(_date.getFullYear());
  return +date - +utcDate;
}

// node_modules/date-fns/differenceInCalendarDays.mjs
var import_constants = require("date-fns@3.6.0/constants");
var import_startOfDay = require("date-fns@3.6.0/startOfDay");
function differenceInCalendarDays(dateLeft, dateRight) {
  const startOfDayLeft = (0, import_startOfDay.startOfDay)(dateLeft);
  const startOfDayRight = (0, import_startOfDay.startOfDay)(dateRight);
  const timestampLeft = +startOfDayLeft - getTimezoneOffsetInMilliseconds(startOfDayLeft);
  const timestampRight = +startOfDayRight - getTimezoneOffsetInMilliseconds(startOfDayRight);
  return Math.round((timestampLeft - timestampRight) / import_constants.millisecondsInDay);
}
var differenceInCalendarDays_default = differenceInCalendarDays;

// .beyond/uimport/temp/date-fns/differenceInCalendarDays.3.6.0.js
var differenceInCalendarDays_3_6_0_default = differenceInCalendarDays_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2RpZmZlcmVuY2VJbkNhbGVuZGFyRGF5cy4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9fbGliL2dldFRpbWV6b25lT2Zmc2V0SW5NaWxsaXNlY29uZHMubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2RpZmZlcmVuY2VJbkNhbGVuZGFyRGF5cy5tanMiXSwibmFtZXMiOlsiZGlmZmVyZW5jZUluQ2FsZW5kYXJEYXlzXzNfNl8wX2V4cG9ydHMiLCJfX2V4cG9ydCIsImRlZmF1bHQiLCJkaWZmZXJlbmNlSW5DYWxlbmRhckRheXNfM182XzBfZGVmYXVsdCIsImRpZmZlcmVuY2VJbkNhbGVuZGFyRGF5cyIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfdG9EYXRlIiwicmVxdWlyZSIsImdldFRpbWV6b25lT2Zmc2V0SW5NaWxsaXNlY29uZHMiLCJkYXRlIiwiX2RhdGUiLCJ0b0RhdGUiLCJ1dGNEYXRlIiwiRGF0ZSIsIlVUQyIsImdldEZ1bGxZZWFyIiwiZ2V0TW9udGgiLCJnZXREYXRlIiwiZ2V0SG91cnMiLCJnZXRNaW51dGVzIiwiZ2V0U2Vjb25kcyIsImdldE1pbGxpc2Vjb25kcyIsInNldFVUQ0Z1bGxZZWFyIiwiaW1wb3J0X2NvbnN0YW50cyIsImltcG9ydF9zdGFydE9mRGF5IiwiZGF0ZUxlZnQiLCJkYXRlUmlnaHQiLCJzdGFydE9mRGF5TGVmdCIsInN0YXJ0T2ZEYXkiLCJzdGFydE9mRGF5UmlnaHQiLCJ0aW1lc3RhbXBMZWZ0IiwidGltZXN0YW1wUmlnaHQiLCJNYXRoIiwicm91bmQiLCJtaWxsaXNlY29uZHNJbkRheSIsImRpZmZlcmVuY2VJbkNhbGVuZGFyRGF5c19kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSxzQ0FBQTtBQUFBQyxRQUFBLENBQUFELHNDQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyxzQ0FBQTtFQUFBQyx3QkFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsc0NBQUE7OztBQ0FBLElBQUFRLGFBQUEsR0FBdUJDLE9BQUE7QUFhaEIsU0FBU0MsZ0NBQWdDQyxJQUFBLEVBQU07RUFDcEQsTUFBTUMsS0FBQSxPQUFRSixhQUFBLENBQUFLLE1BQUEsRUFBT0YsSUFBSTtFQUN6QixNQUFNRyxPQUFBLEdBQVUsSUFBSUMsSUFBQSxDQUNsQkEsSUFBQSxDQUFLQyxHQUFBLENBQ0hKLEtBQUEsQ0FBTUssV0FBQSxDQUFZLEdBQ2xCTCxLQUFBLENBQU1NLFFBQUEsQ0FBUyxHQUNmTixLQUFBLENBQU1PLE9BQUEsQ0FBUSxHQUNkUCxLQUFBLENBQU1RLFFBQUEsQ0FBUyxHQUNmUixLQUFBLENBQU1TLFVBQUEsQ0FBVyxHQUNqQlQsS0FBQSxDQUFNVSxVQUFBLENBQVcsR0FDakJWLEtBQUEsQ0FBTVcsZUFBQSxDQUFnQixDQUN4QixDQUNGO0VBQ0FULE9BQUEsQ0FBUVUsY0FBQSxDQUFlWixLQUFBLENBQU1LLFdBQUEsQ0FBWSxDQUFDO0VBQzFDLE9BQU8sQ0FBQ04sSUFBQSxHQUFPLENBQUNHLE9BQUE7QUFDbEI7OztBQzVCQSxJQUFBVyxnQkFBQSxHQUFrQ2hCLE9BQUE7QUFDbEMsSUFBQWlCLGlCQUFBLEdBQTJCakIsT0FBQTtBQW1DcEIsU0FBU0wseUJBQXlCdUIsUUFBQSxFQUFVQyxTQUFBLEVBQVc7RUFDNUQsTUFBTUMsY0FBQSxPQUFpQkgsaUJBQUEsQ0FBQUksVUFBQSxFQUFXSCxRQUFRO0VBQzFDLE1BQU1JLGVBQUEsT0FBa0JMLGlCQUFBLENBQUFJLFVBQUEsRUFBV0YsU0FBUztFQUU1QyxNQUFNSSxhQUFBLEdBQ0osQ0FBQ0gsY0FBQSxHQUFpQm5CLCtCQUFBLENBQWdDbUIsY0FBYztFQUNsRSxNQUFNSSxjQUFBLEdBQ0osQ0FBQ0YsZUFBQSxHQUFrQnJCLCtCQUFBLENBQWdDcUIsZUFBZTtFQUtwRSxPQUFPRyxJQUFBLENBQUtDLEtBQUEsRUFBT0gsYUFBQSxHQUFnQkMsY0FBQSxJQUFrQlIsZ0JBQUEsQ0FBQVcsaUJBQWlCO0FBQ3hFO0FBR0EsSUFBT0MsZ0NBQUEsR0FBUWpDLHdCQUFBOzs7QUZqRGYsSUFBT0Qsc0NBQUEsR0FBUWtDLGdDQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9