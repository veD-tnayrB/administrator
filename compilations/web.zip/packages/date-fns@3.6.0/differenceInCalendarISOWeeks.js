System.register(["date-fns@3.6.0/constants","date-fns@3.6.0/toDate","date-fns@3.6.0/startOfWeek","date-fns@3.6.0/startOfISOWeek"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constants', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfWeek', dep), dep => dependencies.set('date-fns@3.6.0/startOfISOWeek', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/differenceInCalendarISOWeeks.3.6.0.js
var differenceInCalendarISOWeeks_3_6_0_exports = {};
__export(differenceInCalendarISOWeeks_3_6_0_exports, {
  default: () => differenceInCalendarISOWeeks_3_6_0_default,
  differenceInCalendarISOWeeks: () => differenceInCalendarISOWeeks
});
module.exports = __toCommonJS(differenceInCalendarISOWeeks_3_6_0_exports);

// node_modules/date-fns/_lib/getTimezoneOffsetInMilliseconds.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function getTimezoneOffsetInMilliseconds(date) {
  const _date = (0, import_toDate.toDate)(date);
  const utcDate = new Date(Date.UTC(_date.getFullYear(), _date.getMonth(), _date.getDate(), _date.getHours(), _date.getMinutes(), _date.getSeconds(), _date.getMilliseconds()));
  utcDate.setUTCFullYear(_date.getFullYear());
  return +date - +utcDate;
}

// node_modules/date-fns/differenceInCalendarISOWeeks.mjs
var import_constants = require("date-fns@3.6.0/constants");
var import_startOfISOWeek = require("date-fns@3.6.0/startOfISOWeek");
function differenceInCalendarISOWeeks(dateLeft, dateRight) {
  const startOfISOWeekLeft = (0, import_startOfISOWeek.startOfISOWeek)(dateLeft);
  const startOfISOWeekRight = (0, import_startOfISOWeek.startOfISOWeek)(dateRight);
  const timestampLeft = +startOfISOWeekLeft - getTimezoneOffsetInMilliseconds(startOfISOWeekLeft);
  const timestampRight = +startOfISOWeekRight - getTimezoneOffsetInMilliseconds(startOfISOWeekRight);
  return Math.round((timestampLeft - timestampRight) / import_constants.millisecondsInWeek);
}
var differenceInCalendarISOWeeks_default = differenceInCalendarISOWeeks;

// .beyond/uimport/temp/date-fns/differenceInCalendarISOWeeks.3.6.0.js
var differenceInCalendarISOWeeks_3_6_0_default = differenceInCalendarISOWeeks_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2RpZmZlcmVuY2VJbkNhbGVuZGFySVNPV2Vla3MuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvX2xpYi9nZXRUaW1lem9uZU9mZnNldEluTWlsbGlzZWNvbmRzLm1qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9kaWZmZXJlbmNlSW5DYWxlbmRhcklTT1dlZWtzLm1qcyJdLCJuYW1lcyI6WyJkaWZmZXJlbmNlSW5DYWxlbmRhcklTT1dlZWtzXzNfNl8wX2V4cG9ydHMiLCJfX2V4cG9ydCIsImRlZmF1bHQiLCJkaWZmZXJlbmNlSW5DYWxlbmRhcklTT1dlZWtzXzNfNl8wX2RlZmF1bHQiLCJkaWZmZXJlbmNlSW5DYWxlbmRhcklTT1dlZWtzIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF90b0RhdGUiLCJyZXF1aXJlIiwiZ2V0VGltZXpvbmVPZmZzZXRJbk1pbGxpc2Vjb25kcyIsImRhdGUiLCJfZGF0ZSIsInRvRGF0ZSIsInV0Y0RhdGUiLCJEYXRlIiwiVVRDIiwiZ2V0RnVsbFllYXIiLCJnZXRNb250aCIsImdldERhdGUiLCJnZXRIb3VycyIsImdldE1pbnV0ZXMiLCJnZXRTZWNvbmRzIiwiZ2V0TWlsbGlzZWNvbmRzIiwic2V0VVRDRnVsbFllYXIiLCJpbXBvcnRfY29uc3RhbnRzIiwiaW1wb3J0X3N0YXJ0T2ZJU09XZWVrIiwiZGF0ZUxlZnQiLCJkYXRlUmlnaHQiLCJzdGFydE9mSVNPV2Vla0xlZnQiLCJzdGFydE9mSVNPV2VlayIsInN0YXJ0T2ZJU09XZWVrUmlnaHQiLCJ0aW1lc3RhbXBMZWZ0IiwidGltZXN0YW1wUmlnaHQiLCJNYXRoIiwicm91bmQiLCJtaWxsaXNlY29uZHNJbldlZWsiLCJkaWZmZXJlbmNlSW5DYWxlbmRhcklTT1dlZWtzX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLDBDQUFBO0FBQUFDLFFBQUEsQ0FBQUQsMENBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLDBDQUFBO0VBQUFDLDRCQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCwwQ0FBQTs7O0FDQUEsSUFBQVEsYUFBQSxHQUF1QkMsT0FBQTtBQWFoQixTQUFTQyxnQ0FBZ0NDLElBQUEsRUFBTTtFQUNwRCxNQUFNQyxLQUFBLE9BQVFKLGFBQUEsQ0FBQUssTUFBQSxFQUFPRixJQUFJO0VBQ3pCLE1BQU1HLE9BQUEsR0FBVSxJQUFJQyxJQUFBLENBQ2xCQSxJQUFBLENBQUtDLEdBQUEsQ0FDSEosS0FBQSxDQUFNSyxXQUFBLENBQVksR0FDbEJMLEtBQUEsQ0FBTU0sUUFBQSxDQUFTLEdBQ2ZOLEtBQUEsQ0FBTU8sT0FBQSxDQUFRLEdBQ2RQLEtBQUEsQ0FBTVEsUUFBQSxDQUFTLEdBQ2ZSLEtBQUEsQ0FBTVMsVUFBQSxDQUFXLEdBQ2pCVCxLQUFBLENBQU1VLFVBQUEsQ0FBVyxHQUNqQlYsS0FBQSxDQUFNVyxlQUFBLENBQWdCLENBQ3hCLENBQ0Y7RUFDQVQsT0FBQSxDQUFRVSxjQUFBLENBQWVaLEtBQUEsQ0FBTUssV0FBQSxDQUFZLENBQUM7RUFDMUMsT0FBTyxDQUFDTixJQUFBLEdBQU8sQ0FBQ0csT0FBQTtBQUNsQjs7O0FDNUJBLElBQUFXLGdCQUFBLEdBQW1DaEIsT0FBQTtBQUNuQyxJQUFBaUIscUJBQUEsR0FBK0JqQixPQUFBO0FBNEJ4QixTQUFTTCw2QkFBNkJ1QixRQUFBLEVBQVVDLFNBQUEsRUFBVztFQUNoRSxNQUFNQyxrQkFBQSxPQUFxQkgscUJBQUEsQ0FBQUksY0FBQSxFQUFlSCxRQUFRO0VBQ2xELE1BQU1JLG1CQUFBLE9BQXNCTCxxQkFBQSxDQUFBSSxjQUFBLEVBQWVGLFNBQVM7RUFFcEQsTUFBTUksYUFBQSxHQUNKLENBQUNILGtCQUFBLEdBQXFCbkIsK0JBQUEsQ0FBZ0NtQixrQkFBa0I7RUFDMUUsTUFBTUksY0FBQSxHQUNKLENBQUNGLG1CQUFBLEdBQXNCckIsK0JBQUEsQ0FBZ0NxQixtQkFBbUI7RUFLNUUsT0FBT0csSUFBQSxDQUFLQyxLQUFBLEVBQU9ILGFBQUEsR0FBZ0JDLGNBQUEsSUFBa0JSLGdCQUFBLENBQUFXLGtCQUFrQjtBQUN6RTtBQUdBLElBQU9DLG9DQUFBLEdBQVFqQyw0QkFBQTs7O0FGMUNmLElBQU9ELDBDQUFBLEdBQVFrQyxvQ0FBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==