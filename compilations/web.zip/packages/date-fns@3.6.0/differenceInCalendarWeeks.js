System.register(["date-fns@3.6.0/constants","date-fns@3.6.0/toDate","date-fns@3.6.0/startOfWeek"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constants', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfWeek', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/differenceInCalendarWeeks.3.6.0.js
var differenceInCalendarWeeks_3_6_0_exports = {};
__export(differenceInCalendarWeeks_3_6_0_exports, {
  default: () => differenceInCalendarWeeks_3_6_0_default,
  differenceInCalendarWeeks: () => differenceInCalendarWeeks
});
module.exports = __toCommonJS(differenceInCalendarWeeks_3_6_0_exports);

// node_modules/date-fns/_lib/getTimezoneOffsetInMilliseconds.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function getTimezoneOffsetInMilliseconds(date) {
  const _date = (0, import_toDate.toDate)(date);
  const utcDate = new Date(Date.UTC(_date.getFullYear(), _date.getMonth(), _date.getDate(), _date.getHours(), _date.getMinutes(), _date.getSeconds(), _date.getMilliseconds()));
  utcDate.setUTCFullYear(_date.getFullYear());
  return +date - +utcDate;
}

// node_modules/date-fns/differenceInCalendarWeeks.mjs
var import_constants = require("date-fns@3.6.0/constants");
var import_startOfWeek = require("date-fns@3.6.0/startOfWeek");
function differenceInCalendarWeeks(dateLeft, dateRight, options) {
  const startOfWeekLeft = (0, import_startOfWeek.startOfWeek)(dateLeft, options);
  const startOfWeekRight = (0, import_startOfWeek.startOfWeek)(dateRight, options);
  const timestampLeft = +startOfWeekLeft - getTimezoneOffsetInMilliseconds(startOfWeekLeft);
  const timestampRight = +startOfWeekRight - getTimezoneOffsetInMilliseconds(startOfWeekRight);
  return Math.round((timestampLeft - timestampRight) / import_constants.millisecondsInWeek);
}
var differenceInCalendarWeeks_default = differenceInCalendarWeeks;

// .beyond/uimport/temp/date-fns/differenceInCalendarWeeks.3.6.0.js
var differenceInCalendarWeeks_3_6_0_default = differenceInCalendarWeeks_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2RpZmZlcmVuY2VJbkNhbGVuZGFyV2Vla3MuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvX2xpYi9nZXRUaW1lem9uZU9mZnNldEluTWlsbGlzZWNvbmRzLm1qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9kaWZmZXJlbmNlSW5DYWxlbmRhcldlZWtzLm1qcyJdLCJuYW1lcyI6WyJkaWZmZXJlbmNlSW5DYWxlbmRhcldlZWtzXzNfNl8wX2V4cG9ydHMiLCJfX2V4cG9ydCIsImRlZmF1bHQiLCJkaWZmZXJlbmNlSW5DYWxlbmRhcldlZWtzXzNfNl8wX2RlZmF1bHQiLCJkaWZmZXJlbmNlSW5DYWxlbmRhcldlZWtzIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF90b0RhdGUiLCJyZXF1aXJlIiwiZ2V0VGltZXpvbmVPZmZzZXRJbk1pbGxpc2Vjb25kcyIsImRhdGUiLCJfZGF0ZSIsInRvRGF0ZSIsInV0Y0RhdGUiLCJEYXRlIiwiVVRDIiwiZ2V0RnVsbFllYXIiLCJnZXRNb250aCIsImdldERhdGUiLCJnZXRIb3VycyIsImdldE1pbnV0ZXMiLCJnZXRTZWNvbmRzIiwiZ2V0TWlsbGlzZWNvbmRzIiwic2V0VVRDRnVsbFllYXIiLCJpbXBvcnRfY29uc3RhbnRzIiwiaW1wb3J0X3N0YXJ0T2ZXZWVrIiwiZGF0ZUxlZnQiLCJkYXRlUmlnaHQiLCJvcHRpb25zIiwic3RhcnRPZldlZWtMZWZ0Iiwic3RhcnRPZldlZWsiLCJzdGFydE9mV2Vla1JpZ2h0IiwidGltZXN0YW1wTGVmdCIsInRpbWVzdGFtcFJpZ2h0IiwiTWF0aCIsInJvdW5kIiwibWlsbGlzZWNvbmRzSW5XZWVrIiwiZGlmZmVyZW5jZUluQ2FsZW5kYXJXZWVrc19kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSx1Q0FBQTtBQUFBQyxRQUFBLENBQUFELHVDQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyx1Q0FBQTtFQUFBQyx5QkFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsdUNBQUE7OztBQ0FBLElBQUFRLGFBQUEsR0FBdUJDLE9BQUE7QUFhaEIsU0FBU0MsZ0NBQWdDQyxJQUFBLEVBQU07RUFDcEQsTUFBTUMsS0FBQSxPQUFRSixhQUFBLENBQUFLLE1BQUEsRUFBT0YsSUFBSTtFQUN6QixNQUFNRyxPQUFBLEdBQVUsSUFBSUMsSUFBQSxDQUNsQkEsSUFBQSxDQUFLQyxHQUFBLENBQ0hKLEtBQUEsQ0FBTUssV0FBQSxDQUFZLEdBQ2xCTCxLQUFBLENBQU1NLFFBQUEsQ0FBUyxHQUNmTixLQUFBLENBQU1PLE9BQUEsQ0FBUSxHQUNkUCxLQUFBLENBQU1RLFFBQUEsQ0FBUyxHQUNmUixLQUFBLENBQU1TLFVBQUEsQ0FBVyxHQUNqQlQsS0FBQSxDQUFNVSxVQUFBLENBQVcsR0FDakJWLEtBQUEsQ0FBTVcsZUFBQSxDQUFnQixDQUN4QixDQUNGO0VBQ0FULE9BQUEsQ0FBUVUsY0FBQSxDQUFlWixLQUFBLENBQU1LLFdBQUEsQ0FBWSxDQUFDO0VBQzFDLE9BQU8sQ0FBQ04sSUFBQSxHQUFPLENBQUNHLE9BQUE7QUFDbEI7OztBQzVCQSxJQUFBVyxnQkFBQSxHQUFtQ2hCLE9BQUE7QUFDbkMsSUFBQWlCLGtCQUFBLEdBQTRCakIsT0FBQTtBQXlDckIsU0FBU0wsMEJBQTBCdUIsUUFBQSxFQUFVQyxTQUFBLEVBQVdDLE9BQUEsRUFBUztFQUN0RSxNQUFNQyxlQUFBLE9BQWtCSixrQkFBQSxDQUFBSyxXQUFBLEVBQVlKLFFBQUEsRUFBVUUsT0FBTztFQUNyRCxNQUFNRyxnQkFBQSxPQUFtQk4sa0JBQUEsQ0FBQUssV0FBQSxFQUFZSCxTQUFBLEVBQVdDLE9BQU87RUFFdkQsTUFBTUksYUFBQSxHQUNKLENBQUNILGVBQUEsR0FBa0JwQiwrQkFBQSxDQUFnQ29CLGVBQWU7RUFDcEUsTUFBTUksY0FBQSxHQUNKLENBQUNGLGdCQUFBLEdBQW1CdEIsK0JBQUEsQ0FBZ0NzQixnQkFBZ0I7RUFLdEUsT0FBT0csSUFBQSxDQUFLQyxLQUFBLEVBQU9ILGFBQUEsR0FBZ0JDLGNBQUEsSUFBa0JULGdCQUFBLENBQUFZLGtCQUFrQjtBQUN6RTtBQUdBLElBQU9DLGlDQUFBLEdBQVFsQyx5QkFBQTs7O0FGdkRmLElBQU9ELHVDQUFBLEdBQVFtQyxpQ0FBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==