System.register(["date-fns@3.6.0/constants","date-fns@3.6.0/toDate","date-fns@3.6.0/startOfDay","date-fns@3.6.0/differenceInCalendarDays"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constants', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfDay', dep), dep => dependencies.set('date-fns@3.6.0/differenceInCalendarDays', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/differenceInDays.3.6.0.js
var differenceInDays_3_6_0_exports = {};
__export(differenceInDays_3_6_0_exports, {
  default: () => differenceInDays_3_6_0_default,
  differenceInDays: () => differenceInDays
});
module.exports = __toCommonJS(differenceInDays_3_6_0_exports);

// node_modules/date-fns/differenceInDays.mjs
var import_differenceInCalendarDays = require("date-fns@3.6.0/differenceInCalendarDays");
var import_toDate = require("date-fns@3.6.0/toDate");
function differenceInDays(dateLeft, dateRight) {
  const _dateLeft = (0, import_toDate.toDate)(dateLeft);
  const _dateRight = (0, import_toDate.toDate)(dateRight);
  const sign = compareLocalAsc(_dateLeft, _dateRight);
  const difference = Math.abs((0, import_differenceInCalendarDays.differenceInCalendarDays)(_dateLeft, _dateRight));
  _dateLeft.setDate(_dateLeft.getDate() - sign * difference);
  const isLastDayNotFull = Number(compareLocalAsc(_dateLeft, _dateRight) === -sign);
  const result = sign * (difference - isLastDayNotFull);
  return result === 0 ? 0 : result;
}
function compareLocalAsc(dateLeft, dateRight) {
  const diff = dateLeft.getFullYear() - dateRight.getFullYear() || dateLeft.getMonth() - dateRight.getMonth() || dateLeft.getDate() - dateRight.getDate() || dateLeft.getHours() - dateRight.getHours() || dateLeft.getMinutes() - dateRight.getMinutes() || dateLeft.getSeconds() - dateRight.getSeconds() || dateLeft.getMilliseconds() - dateRight.getMilliseconds();
  if (diff < 0) {
    return -1;
  } else if (diff > 0) {
    return 1;
  } else {
    return diff;
  }
}
var differenceInDays_default = differenceInDays;

// .beyond/uimport/temp/date-fns/differenceInDays.3.6.0.js
var differenceInDays_3_6_0_default = differenceInDays_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2RpZmZlcmVuY2VJbkRheXMuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvZGlmZmVyZW5jZUluRGF5cy5tanMiXSwibmFtZXMiOlsiZGlmZmVyZW5jZUluRGF5c18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZGlmZmVyZW5jZUluRGF5c18zXzZfMF9kZWZhdWx0IiwiZGlmZmVyZW5jZUluRGF5cyIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfZGlmZmVyZW5jZUluQ2FsZW5kYXJEYXlzIiwicmVxdWlyZSIsImltcG9ydF90b0RhdGUiLCJkYXRlTGVmdCIsImRhdGVSaWdodCIsIl9kYXRlTGVmdCIsInRvRGF0ZSIsIl9kYXRlUmlnaHQiLCJzaWduIiwiY29tcGFyZUxvY2FsQXNjIiwiZGlmZmVyZW5jZSIsIk1hdGgiLCJhYnMiLCJkaWZmZXJlbmNlSW5DYWxlbmRhckRheXMiLCJzZXREYXRlIiwiZ2V0RGF0ZSIsImlzTGFzdERheU5vdEZ1bGwiLCJOdW1iZXIiLCJyZXN1bHQiLCJkaWZmIiwiZ2V0RnVsbFllYXIiLCJnZXRNb250aCIsImdldEhvdXJzIiwiZ2V0TWludXRlcyIsImdldFNlY29uZHMiLCJnZXRNaWxsaXNlY29uZHMiLCJkaWZmZXJlbmNlSW5EYXlzX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLDhCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsOEJBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLDhCQUFBO0VBQUFDLGdCQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCw4QkFBQTs7O0FDQUEsSUFBQVEsK0JBQUEsR0FBeUNDLE9BQUE7QUFDekMsSUFBQUMsYUFBQSxHQUF1QkQsT0FBQTtBQXdEaEIsU0FBU0wsaUJBQWlCTyxRQUFBLEVBQVVDLFNBQUEsRUFBVztFQUNwRCxNQUFNQyxTQUFBLE9BQVlILGFBQUEsQ0FBQUksTUFBQSxFQUFPSCxRQUFRO0VBQ2pDLE1BQU1JLFVBQUEsT0FBYUwsYUFBQSxDQUFBSSxNQUFBLEVBQU9GLFNBQVM7RUFFbkMsTUFBTUksSUFBQSxHQUFPQyxlQUFBLENBQWdCSixTQUFBLEVBQVdFLFVBQVU7RUFDbEQsTUFBTUcsVUFBQSxHQUFhQyxJQUFBLENBQUtDLEdBQUEsS0FBSVosK0JBQUEsQ0FBQWEsd0JBQUEsRUFBeUJSLFNBQUEsRUFBV0UsVUFBVSxDQUFDO0VBRTNFRixTQUFBLENBQVVTLE9BQUEsQ0FBUVQsU0FBQSxDQUFVVSxPQUFBLENBQVEsSUFBSVAsSUFBQSxHQUFPRSxVQUFVO0VBSXpELE1BQU1NLGdCQUFBLEdBQW1CQyxNQUFBLENBQ3ZCUixlQUFBLENBQWdCSixTQUFBLEVBQVdFLFVBQVUsTUFBTSxDQUFDQyxJQUM5QztFQUNBLE1BQU1VLE1BQUEsR0FBU1YsSUFBQSxJQUFRRSxVQUFBLEdBQWFNLGdCQUFBO0VBRXBDLE9BQU9FLE1BQUEsS0FBVyxJQUFJLElBQUlBLE1BQUE7QUFDNUI7QUFNQSxTQUFTVCxnQkFBZ0JOLFFBQUEsRUFBVUMsU0FBQSxFQUFXO0VBQzVDLE1BQU1lLElBQUEsR0FDSmhCLFFBQUEsQ0FBU2lCLFdBQUEsQ0FBWSxJQUFJaEIsU0FBQSxDQUFVZ0IsV0FBQSxDQUFZLEtBQy9DakIsUUFBQSxDQUFTa0IsUUFBQSxDQUFTLElBQUlqQixTQUFBLENBQVVpQixRQUFBLENBQVMsS0FDekNsQixRQUFBLENBQVNZLE9BQUEsQ0FBUSxJQUFJWCxTQUFBLENBQVVXLE9BQUEsQ0FBUSxLQUN2Q1osUUFBQSxDQUFTbUIsUUFBQSxDQUFTLElBQUlsQixTQUFBLENBQVVrQixRQUFBLENBQVMsS0FDekNuQixRQUFBLENBQVNvQixVQUFBLENBQVcsSUFBSW5CLFNBQUEsQ0FBVW1CLFVBQUEsQ0FBVyxLQUM3Q3BCLFFBQUEsQ0FBU3FCLFVBQUEsQ0FBVyxJQUFJcEIsU0FBQSxDQUFVb0IsVUFBQSxDQUFXLEtBQzdDckIsUUFBQSxDQUFTc0IsZUFBQSxDQUFnQixJQUFJckIsU0FBQSxDQUFVcUIsZUFBQSxDQUFnQjtFQUV6RCxJQUFJTixJQUFBLEdBQU8sR0FBRztJQUNaLE9BQU87RUFDVCxXQUFXQSxJQUFBLEdBQU8sR0FBRztJQUNuQixPQUFPO0VBRVQsT0FBTztJQUNMLE9BQU9BLElBQUE7RUFDVDtBQUNGO0FBR0EsSUFBT08sd0JBQUEsR0FBUTlCLGdCQUFBOzs7QURsR2YsSUFBT0QsOEJBQUEsR0FBUStCLHdCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9