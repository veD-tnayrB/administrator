System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/compareAsc","date-fns@3.6.0/constructFrom","date-fns@3.6.0/startOfWeek","date-fns@3.6.0/startOfISOWeek","date-fns@3.6.0/getISOWeekYear","date-fns@3.6.0/differenceInCalendarISOWeekYears","date-fns@3.6.0/constants","date-fns@3.6.0/startOfDay","date-fns@3.6.0/differenceInCalendarDays","date-fns@3.6.0/startOfISOWeekYear","date-fns@3.6.0/setISOWeekYear","date-fns@3.6.0/addISOWeekYears","date-fns@3.6.0/subISOWeekYears"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/compareAsc', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/startOfWeek', dep), dep => dependencies.set('date-fns@3.6.0/startOfISOWeek', dep), dep => dependencies.set('date-fns@3.6.0/getISOWeekYear', dep), dep => dependencies.set('date-fns@3.6.0/differenceInCalendarISOWeekYears', dep), dep => dependencies.set('date-fns@3.6.0/constants', dep), dep => dependencies.set('date-fns@3.6.0/startOfDay', dep), dep => dependencies.set('date-fns@3.6.0/differenceInCalendarDays', dep), dep => dependencies.set('date-fns@3.6.0/startOfISOWeekYear', dep), dep => dependencies.set('date-fns@3.6.0/setISOWeekYear', dep), dep => dependencies.set('date-fns@3.6.0/addISOWeekYears', dep), dep => dependencies.set('date-fns@3.6.0/subISOWeekYears', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/differenceInISOWeekYears.3.6.0.js
var differenceInISOWeekYears_3_6_0_exports = {};
__export(differenceInISOWeekYears_3_6_0_exports, {
  default: () => differenceInISOWeekYears_3_6_0_default,
  differenceInISOWeekYears: () => differenceInISOWeekYears
});
module.exports = __toCommonJS(differenceInISOWeekYears_3_6_0_exports);

// node_modules/date-fns/differenceInISOWeekYears.mjs
var import_compareAsc = require("date-fns@3.6.0/compareAsc");
var import_differenceInCalendarISOWeekYears = require("date-fns@3.6.0/differenceInCalendarISOWeekYears");
var import_subISOWeekYears = require("date-fns@3.6.0/subISOWeekYears");
var import_toDate = require("date-fns@3.6.0/toDate");
function differenceInISOWeekYears(dateLeft, dateRight) {
  let _dateLeft = (0, import_toDate.toDate)(dateLeft);
  const _dateRight = (0, import_toDate.toDate)(dateRight);
  const sign = (0, import_compareAsc.compareAsc)(_dateLeft, _dateRight);
  const difference = Math.abs((0, import_differenceInCalendarISOWeekYears.differenceInCalendarISOWeekYears)(_dateLeft, _dateRight));
  _dateLeft = (0, import_subISOWeekYears.subISOWeekYears)(_dateLeft, sign * difference);
  const isLastISOWeekYearNotFull = Number((0, import_compareAsc.compareAsc)(_dateLeft, _dateRight) === -sign);
  const result = sign * (difference - isLastISOWeekYearNotFull);
  return result === 0 ? 0 : result;
}
var differenceInISOWeekYears_default = differenceInISOWeekYears;

// .beyond/uimport/temp/date-fns/differenceInISOWeekYears.3.6.0.js
var differenceInISOWeekYears_3_6_0_default = differenceInISOWeekYears_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2RpZmZlcmVuY2VJbklTT1dlZWtZZWFycy4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9kaWZmZXJlbmNlSW5JU09XZWVrWWVhcnMubWpzIl0sIm5hbWVzIjpbImRpZmZlcmVuY2VJbklTT1dlZWtZZWFyc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZGlmZmVyZW5jZUluSVNPV2Vla1llYXJzXzNfNl8wX2RlZmF1bHQiLCJkaWZmZXJlbmNlSW5JU09XZWVrWWVhcnMiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2NvbXBhcmVBc2MiLCJyZXF1aXJlIiwiaW1wb3J0X2RpZmZlcmVuY2VJbkNhbGVuZGFySVNPV2Vla1llYXJzIiwiaW1wb3J0X3N1YklTT1dlZWtZZWFycyIsImltcG9ydF90b0RhdGUiLCJkYXRlTGVmdCIsImRhdGVSaWdodCIsIl9kYXRlTGVmdCIsInRvRGF0ZSIsIl9kYXRlUmlnaHQiLCJzaWduIiwiY29tcGFyZUFzYyIsImRpZmZlcmVuY2UiLCJNYXRoIiwiYWJzIiwiZGlmZmVyZW5jZUluQ2FsZW5kYXJJU09XZWVrWWVhcnMiLCJzdWJJU09XZWVrWWVhcnMiLCJpc0xhc3RJU09XZWVrWWVhck5vdEZ1bGwiLCJOdW1iZXIiLCJyZXN1bHQiLCJkaWZmZXJlbmNlSW5JU09XZWVrWWVhcnNfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsc0NBQUE7QUFBQUMsUUFBQSxDQUFBRCxzQ0FBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsc0NBQUE7RUFBQUMsd0JBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLHNDQUFBOzs7QUNBQSxJQUFBUSxpQkFBQSxHQUEyQkMsT0FBQTtBQUMzQixJQUFBQyx1Q0FBQSxHQUFpREQsT0FBQTtBQUNqRCxJQUFBRSxzQkFBQSxHQUFnQ0YsT0FBQTtBQUNoQyxJQUFBRyxhQUFBLEdBQXVCSCxPQUFBO0FBMkJoQixTQUFTTCx5QkFBeUJTLFFBQUEsRUFBVUMsU0FBQSxFQUFXO0VBQzVELElBQUlDLFNBQUEsT0FBWUgsYUFBQSxDQUFBSSxNQUFBLEVBQU9ILFFBQVE7RUFDL0IsTUFBTUksVUFBQSxPQUFhTCxhQUFBLENBQUFJLE1BQUEsRUFBT0YsU0FBUztFQUVuQyxNQUFNSSxJQUFBLE9BQU9WLGlCQUFBLENBQUFXLFVBQUEsRUFBV0osU0FBQSxFQUFXRSxVQUFVO0VBQzdDLE1BQU1HLFVBQUEsR0FBYUMsSUFBQSxDQUFLQyxHQUFBLEtBQ3RCWix1Q0FBQSxDQUFBYSxnQ0FBQSxFQUFpQ1IsU0FBQSxFQUFXRSxVQUFVLENBQ3hEO0VBQ0FGLFNBQUEsT0FBWUosc0JBQUEsQ0FBQWEsZUFBQSxFQUFnQlQsU0FBQSxFQUFXRyxJQUFBLEdBQU9FLFVBQVU7RUFLeEQsTUFBTUssd0JBQUEsR0FBMkJDLE1BQUEsS0FDL0JsQixpQkFBQSxDQUFBVyxVQUFBLEVBQVdKLFNBQUEsRUFBV0UsVUFBVSxNQUFNLENBQUNDLElBQ3pDO0VBQ0EsTUFBTVMsTUFBQSxHQUFTVCxJQUFBLElBQVFFLFVBQUEsR0FBYUssd0JBQUE7RUFFcEMsT0FBT0UsTUFBQSxLQUFXLElBQUksSUFBSUEsTUFBQTtBQUM1QjtBQUdBLElBQU9DLGdDQUFBLEdBQVF4Qix3QkFBQTs7O0FEakRmLElBQU9ELHNDQUFBLEdBQVF5QixnQ0FBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==