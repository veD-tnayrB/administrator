System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/compareAsc","date-fns@3.6.0/differenceInCalendarMonths","date-fns@3.6.0/endOfDay","date-fns@3.6.0/endOfMonth","date-fns@3.6.0/isLastDayOfMonth"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/compareAsc', dep), dep => dependencies.set('date-fns@3.6.0/differenceInCalendarMonths', dep), dep => dependencies.set('date-fns@3.6.0/endOfDay', dep), dep => dependencies.set('date-fns@3.6.0/endOfMonth', dep), dep => dependencies.set('date-fns@3.6.0/isLastDayOfMonth', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/differenceInMonths.3.6.0.js
var differenceInMonths_3_6_0_exports = {};
__export(differenceInMonths_3_6_0_exports, {
  default: () => differenceInMonths_3_6_0_default,
  differenceInMonths: () => differenceInMonths
});
module.exports = __toCommonJS(differenceInMonths_3_6_0_exports);

// node_modules/date-fns/differenceInMonths.mjs
var import_compareAsc = require("date-fns@3.6.0/compareAsc");
var import_differenceInCalendarMonths = require("date-fns@3.6.0/differenceInCalendarMonths");
var import_isLastDayOfMonth = require("date-fns@3.6.0/isLastDayOfMonth");
var import_toDate = require("date-fns@3.6.0/toDate");
function differenceInMonths(dateLeft, dateRight) {
  const _dateLeft = (0, import_toDate.toDate)(dateLeft);
  const _dateRight = (0, import_toDate.toDate)(dateRight);
  const sign = (0, import_compareAsc.compareAsc)(_dateLeft, _dateRight);
  const difference = Math.abs((0, import_differenceInCalendarMonths.differenceInCalendarMonths)(_dateLeft, _dateRight));
  let result;
  if (difference < 1) {
    result = 0;
  } else {
    if (_dateLeft.getMonth() === 1 && _dateLeft.getDate() > 27) {
      _dateLeft.setDate(30);
    }
    _dateLeft.setMonth(_dateLeft.getMonth() - sign * difference);
    let isLastMonthNotFull = (0, import_compareAsc.compareAsc)(_dateLeft, _dateRight) === -sign;
    if ((0, import_isLastDayOfMonth.isLastDayOfMonth)((0, import_toDate.toDate)(dateLeft)) && difference === 1 && (0, import_compareAsc.compareAsc)(dateLeft, _dateRight) === 1) {
      isLastMonthNotFull = false;
    }
    result = sign * (difference - Number(isLastMonthNotFull));
  }
  return result === 0 ? 0 : result;
}
var differenceInMonths_default = differenceInMonths;

// .beyond/uimport/temp/date-fns/differenceInMonths.3.6.0.js
var differenceInMonths_3_6_0_default = differenceInMonths_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2RpZmZlcmVuY2VJbk1vbnRocy4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9kaWZmZXJlbmNlSW5Nb250aHMubWpzIl0sIm5hbWVzIjpbImRpZmZlcmVuY2VJbk1vbnRoc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZGlmZmVyZW5jZUluTW9udGhzXzNfNl8wX2RlZmF1bHQiLCJkaWZmZXJlbmNlSW5Nb250aHMiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2NvbXBhcmVBc2MiLCJyZXF1aXJlIiwiaW1wb3J0X2RpZmZlcmVuY2VJbkNhbGVuZGFyTW9udGhzIiwiaW1wb3J0X2lzTGFzdERheU9mTW9udGgiLCJpbXBvcnRfdG9EYXRlIiwiZGF0ZUxlZnQiLCJkYXRlUmlnaHQiLCJfZGF0ZUxlZnQiLCJ0b0RhdGUiLCJfZGF0ZVJpZ2h0Iiwic2lnbiIsImNvbXBhcmVBc2MiLCJkaWZmZXJlbmNlIiwiTWF0aCIsImFicyIsImRpZmZlcmVuY2VJbkNhbGVuZGFyTW9udGhzIiwicmVzdWx0IiwiZ2V0TW9udGgiLCJnZXREYXRlIiwic2V0RGF0ZSIsInNldE1vbnRoIiwiaXNMYXN0TW9udGhOb3RGdWxsIiwiaXNMYXN0RGF5T2ZNb250aCIsIk51bWJlciIsImRpZmZlcmVuY2VJbk1vbnRoc19kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSxnQ0FBQTtBQUFBQyxRQUFBLENBQUFELGdDQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyxnQ0FBQTtFQUFBQyxrQkFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsZ0NBQUE7OztBQ0FBLElBQUFRLGlCQUFBLEdBQTJCQyxPQUFBO0FBQzNCLElBQUFDLGlDQUFBLEdBQTJDRCxPQUFBO0FBQzNDLElBQUFFLHVCQUFBLEdBQWlDRixPQUFBO0FBQ2pDLElBQUFHLGFBQUEsR0FBdUJILE9BQUE7QUFzQmhCLFNBQVNMLG1CQUFtQlMsUUFBQSxFQUFVQyxTQUFBLEVBQVc7RUFDdEQsTUFBTUMsU0FBQSxPQUFZSCxhQUFBLENBQUFJLE1BQUEsRUFBT0gsUUFBUTtFQUNqQyxNQUFNSSxVQUFBLE9BQWFMLGFBQUEsQ0FBQUksTUFBQSxFQUFPRixTQUFTO0VBRW5DLE1BQU1JLElBQUEsT0FBT1YsaUJBQUEsQ0FBQVcsVUFBQSxFQUFXSixTQUFBLEVBQVdFLFVBQVU7RUFDN0MsTUFBTUcsVUFBQSxHQUFhQyxJQUFBLENBQUtDLEdBQUEsS0FDdEJaLGlDQUFBLENBQUFhLDBCQUFBLEVBQTJCUixTQUFBLEVBQVdFLFVBQVUsQ0FDbEQ7RUFDQSxJQUFJTyxNQUFBO0VBR0osSUFBSUosVUFBQSxHQUFhLEdBQUc7SUFDbEJJLE1BQUEsR0FBUztFQUNYLE9BQU87SUFDTCxJQUFJVCxTQUFBLENBQVVVLFFBQUEsQ0FBUyxNQUFNLEtBQUtWLFNBQUEsQ0FBVVcsT0FBQSxDQUFRLElBQUksSUFBSTtNQUcxRFgsU0FBQSxDQUFVWSxPQUFBLENBQVEsRUFBRTtJQUN0QjtJQUVBWixTQUFBLENBQVVhLFFBQUEsQ0FBU2IsU0FBQSxDQUFVVSxRQUFBLENBQVMsSUFBSVAsSUFBQSxHQUFPRSxVQUFVO0lBSTNELElBQUlTLGtCQUFBLE9BQXFCckIsaUJBQUEsQ0FBQVcsVUFBQSxFQUFXSixTQUFBLEVBQVdFLFVBQVUsTUFBTSxDQUFDQyxJQUFBO0lBR2hFLFFBQ0VQLHVCQUFBLENBQUFtQixnQkFBQSxNQUFpQmxCLGFBQUEsQ0FBQUksTUFBQSxFQUFPSCxRQUFRLENBQUMsS0FDakNPLFVBQUEsS0FBZSxTQUNmWixpQkFBQSxDQUFBVyxVQUFBLEVBQVdOLFFBQUEsRUFBVUksVUFBVSxNQUFNLEdBQ3JDO01BQ0FZLGtCQUFBLEdBQXFCO0lBQ3ZCO0lBRUFMLE1BQUEsR0FBU04sSUFBQSxJQUFRRSxVQUFBLEdBQWFXLE1BQUEsQ0FBT0Ysa0JBQWtCO0VBQ3pEO0VBR0EsT0FBT0wsTUFBQSxLQUFXLElBQUksSUFBSUEsTUFBQTtBQUM1QjtBQUdBLElBQU9RLDBCQUFBLEdBQVE1QixrQkFBQTs7O0FEakVmLElBQU9ELGdDQUFBLEdBQVE2QiwwQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==