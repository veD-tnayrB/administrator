System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/compareAsc","date-fns@3.6.0/differenceInCalendarMonths","date-fns@3.6.0/endOfDay","date-fns@3.6.0/endOfMonth","date-fns@3.6.0/isLastDayOfMonth","date-fns@3.6.0/differenceInMonths"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/compareAsc', dep), dep => dependencies.set('date-fns@3.6.0/differenceInCalendarMonths', dep), dep => dependencies.set('date-fns@3.6.0/endOfDay', dep), dep => dependencies.set('date-fns@3.6.0/endOfMonth', dep), dep => dependencies.set('date-fns@3.6.0/isLastDayOfMonth', dep), dep => dependencies.set('date-fns@3.6.0/differenceInMonths', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/differenceInQuarters.3.6.0.js
var differenceInQuarters_3_6_0_exports = {};
__export(differenceInQuarters_3_6_0_exports, {
  default: () => differenceInQuarters_3_6_0_default,
  differenceInQuarters: () => differenceInQuarters
});
module.exports = __toCommonJS(differenceInQuarters_3_6_0_exports);

// node_modules/date-fns/_lib/getRoundingMethod.mjs
function getRoundingMethod(method) {
  return number => {
    const round = method ? Math[method] : Math.trunc;
    const result = round(number);
    return result === 0 ? 0 : result;
  };
}

// node_modules/date-fns/differenceInQuarters.mjs
var import_differenceInMonths = require("date-fns@3.6.0/differenceInMonths");
function differenceInQuarters(dateLeft, dateRight, options) {
  const diff = (0, import_differenceInMonths.differenceInMonths)(dateLeft, dateRight) / 3;
  return getRoundingMethod(options?.roundingMethod)(diff);
}
var differenceInQuarters_default = differenceInQuarters;

// .beyond/uimport/temp/date-fns/differenceInQuarters.3.6.0.js
var differenceInQuarters_3_6_0_default = differenceInQuarters_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2RpZmZlcmVuY2VJblF1YXJ0ZXJzLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL19saWIvZ2V0Um91bmRpbmdNZXRob2QubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2RpZmZlcmVuY2VJblF1YXJ0ZXJzLm1qcyJdLCJuYW1lcyI6WyJkaWZmZXJlbmNlSW5RdWFydGVyc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZGlmZmVyZW5jZUluUXVhcnRlcnNfM182XzBfZGVmYXVsdCIsImRpZmZlcmVuY2VJblF1YXJ0ZXJzIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImdldFJvdW5kaW5nTWV0aG9kIiwibWV0aG9kIiwibnVtYmVyIiwicm91bmQiLCJNYXRoIiwidHJ1bmMiLCJyZXN1bHQiLCJpbXBvcnRfZGlmZmVyZW5jZUluTW9udGhzIiwicmVxdWlyZSIsImRhdGVMZWZ0IiwiZGF0ZVJpZ2h0Iiwib3B0aW9ucyIsImRpZmYiLCJkaWZmZXJlbmNlSW5Nb250aHMiLCJyb3VuZGluZ01ldGhvZCIsImRpZmZlcmVuY2VJblF1YXJ0ZXJzX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLGtDQUFBO0FBQUFDLFFBQUEsQ0FBQUQsa0NBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLGtDQUFBO0VBQUFDLG9CQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCxrQ0FBQTs7O0FDQU8sU0FBU1Esa0JBQWtCQyxNQUFBLEVBQVE7RUFDeEMsT0FBUUMsTUFBQSxJQUFXO0lBQ2pCLE1BQU1DLEtBQUEsR0FBUUYsTUFBQSxHQUFTRyxJQUFBLENBQUtILE1BQUEsSUFBVUcsSUFBQSxDQUFLQyxLQUFBO0lBQzNDLE1BQU1DLE1BQUEsR0FBU0gsS0FBQSxDQUFNRCxNQUFNO0lBRTNCLE9BQU9JLE1BQUEsS0FBVyxJQUFJLElBQUlBLE1BQUE7RUFDNUI7QUFDRjs7O0FDTkEsSUFBQUMseUJBQUEsR0FBbUNDLE9BQUE7QUEyQjVCLFNBQVNaLHFCQUFxQmEsUUFBQSxFQUFVQyxTQUFBLEVBQVdDLE9BQUEsRUFBUztFQUNqRSxNQUFNQyxJQUFBLE9BQU9MLHlCQUFBLENBQUFNLGtCQUFBLEVBQW1CSixRQUFBLEVBQVVDLFNBQVMsSUFBSTtFQUN2RCxPQUFPVixpQkFBQSxDQUFrQlcsT0FBQSxFQUFTRyxjQUFjLEVBQUVGLElBQUk7QUFDeEQ7QUFHQSxJQUFPRyw0QkFBQSxHQUFRbkIsb0JBQUE7OztBRi9CZixJQUFPRCxrQ0FBQSxHQUFRb0IsNEJBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=