System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/differenceInMilliseconds"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/differenceInMilliseconds', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/differenceInSeconds.3.6.0.js
var differenceInSeconds_3_6_0_exports = {};
__export(differenceInSeconds_3_6_0_exports, {
  default: () => differenceInSeconds_3_6_0_default,
  differenceInSeconds: () => differenceInSeconds
});
module.exports = __toCommonJS(differenceInSeconds_3_6_0_exports);

// node_modules/date-fns/_lib/getRoundingMethod.mjs
function getRoundingMethod(method) {
  return number => {
    const round = method ? Math[method] : Math.trunc;
    const result = round(number);
    return result === 0 ? 0 : result;
  };
}

// node_modules/date-fns/differenceInSeconds.mjs
var import_differenceInMilliseconds = require("date-fns@3.6.0/differenceInMilliseconds");
function differenceInSeconds(dateLeft, dateRight, options) {
  const diff = (0, import_differenceInMilliseconds.differenceInMilliseconds)(dateLeft, dateRight) / 1e3;
  return getRoundingMethod(options?.roundingMethod)(diff);
}
var differenceInSeconds_default = differenceInSeconds;

// .beyond/uimport/temp/date-fns/differenceInSeconds.3.6.0.js
var differenceInSeconds_3_6_0_default = differenceInSeconds_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2RpZmZlcmVuY2VJblNlY29uZHMuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvX2xpYi9nZXRSb3VuZGluZ01ldGhvZC5tanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvZGlmZmVyZW5jZUluU2Vjb25kcy5tanMiXSwibmFtZXMiOlsiZGlmZmVyZW5jZUluU2Vjb25kc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZGlmZmVyZW5jZUluU2Vjb25kc18zXzZfMF9kZWZhdWx0IiwiZGlmZmVyZW5jZUluU2Vjb25kcyIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJnZXRSb3VuZGluZ01ldGhvZCIsIm1ldGhvZCIsIm51bWJlciIsInJvdW5kIiwiTWF0aCIsInRydW5jIiwicmVzdWx0IiwiaW1wb3J0X2RpZmZlcmVuY2VJbk1pbGxpc2Vjb25kcyIsInJlcXVpcmUiLCJkYXRlTGVmdCIsImRhdGVSaWdodCIsIm9wdGlvbnMiLCJkaWZmIiwiZGlmZmVyZW5jZUluTWlsbGlzZWNvbmRzIiwicm91bmRpbmdNZXRob2QiLCJkaWZmZXJlbmNlSW5TZWNvbmRzX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLGlDQUFBO0FBQUFDLFFBQUEsQ0FBQUQsaUNBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLGlDQUFBO0VBQUFDLG1CQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCxpQ0FBQTs7O0FDQU8sU0FBU1Esa0JBQWtCQyxNQUFBLEVBQVE7RUFDeEMsT0FBUUMsTUFBQSxJQUFXO0lBQ2pCLE1BQU1DLEtBQUEsR0FBUUYsTUFBQSxHQUFTRyxJQUFBLENBQUtILE1BQUEsSUFBVUcsSUFBQSxDQUFLQyxLQUFBO0lBQzNDLE1BQU1DLE1BQUEsR0FBU0gsS0FBQSxDQUFNRCxNQUFNO0lBRTNCLE9BQU9JLE1BQUEsS0FBVyxJQUFJLElBQUlBLE1BQUE7RUFDNUI7QUFDRjs7O0FDTkEsSUFBQUMsK0JBQUEsR0FBeUNDLE9BQUE7QUErQmxDLFNBQVNaLG9CQUFvQmEsUUFBQSxFQUFVQyxTQUFBLEVBQVdDLE9BQUEsRUFBUztFQUNoRSxNQUFNQyxJQUFBLE9BQU9MLCtCQUFBLENBQUFNLHdCQUFBLEVBQXlCSixRQUFBLEVBQVVDLFNBQVMsSUFBSTtFQUM3RCxPQUFPVixpQkFBQSxDQUFrQlcsT0FBQSxFQUFTRyxjQUFjLEVBQUVGLElBQUk7QUFDeEQ7QUFHQSxJQUFPRywyQkFBQSxHQUFRbkIsbUJBQUE7OztBRm5DZixJQUFPRCxpQ0FBQSxHQUFRb0IsMkJBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=