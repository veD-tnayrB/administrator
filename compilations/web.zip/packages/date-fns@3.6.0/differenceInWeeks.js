System.register(["date-fns@3.6.0/constants","date-fns@3.6.0/toDate","date-fns@3.6.0/startOfDay","date-fns@3.6.0/differenceInCalendarDays","date-fns@3.6.0/differenceInDays"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constants', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfDay', dep), dep => dependencies.set('date-fns@3.6.0/differenceInCalendarDays', dep), dep => dependencies.set('date-fns@3.6.0/differenceInDays', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/differenceInWeeks.3.6.0.js
var differenceInWeeks_3_6_0_exports = {};
__export(differenceInWeeks_3_6_0_exports, {
  default: () => differenceInWeeks_3_6_0_default,
  differenceInWeeks: () => differenceInWeeks
});
module.exports = __toCommonJS(differenceInWeeks_3_6_0_exports);

// node_modules/date-fns/_lib/getRoundingMethod.mjs
function getRoundingMethod(method) {
  return number => {
    const round = method ? Math[method] : Math.trunc;
    const result = round(number);
    return result === 0 ? 0 : result;
  };
}

// node_modules/date-fns/differenceInWeeks.mjs
var import_differenceInDays = require("date-fns@3.6.0/differenceInDays");
function differenceInWeeks(dateLeft, dateRight, options) {
  const diff = (0, import_differenceInDays.differenceInDays)(dateLeft, dateRight) / 7;
  return getRoundingMethod(options?.roundingMethod)(diff);
}
var differenceInWeeks_default = differenceInWeeks;

// .beyond/uimport/temp/date-fns/differenceInWeeks.3.6.0.js
var differenceInWeeks_3_6_0_default = differenceInWeeks_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2RpZmZlcmVuY2VJbldlZWtzLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL19saWIvZ2V0Um91bmRpbmdNZXRob2QubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2RpZmZlcmVuY2VJbldlZWtzLm1qcyJdLCJuYW1lcyI6WyJkaWZmZXJlbmNlSW5XZWVrc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZGlmZmVyZW5jZUluV2Vla3NfM182XzBfZGVmYXVsdCIsImRpZmZlcmVuY2VJbldlZWtzIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImdldFJvdW5kaW5nTWV0aG9kIiwibWV0aG9kIiwibnVtYmVyIiwicm91bmQiLCJNYXRoIiwidHJ1bmMiLCJyZXN1bHQiLCJpbXBvcnRfZGlmZmVyZW5jZUluRGF5cyIsInJlcXVpcmUiLCJkYXRlTGVmdCIsImRhdGVSaWdodCIsIm9wdGlvbnMiLCJkaWZmIiwiZGlmZmVyZW5jZUluRGF5cyIsInJvdW5kaW5nTWV0aG9kIiwiZGlmZmVyZW5jZUluV2Vla3NfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsK0JBQUE7QUFBQUMsUUFBQSxDQUFBRCwrQkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsK0JBQUE7RUFBQUMsaUJBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLCtCQUFBOzs7QUNBTyxTQUFTUSxrQkFBa0JDLE1BQUEsRUFBUTtFQUN4QyxPQUFRQyxNQUFBLElBQVc7SUFDakIsTUFBTUMsS0FBQSxHQUFRRixNQUFBLEdBQVNHLElBQUEsQ0FBS0gsTUFBQSxJQUFVRyxJQUFBLENBQUtDLEtBQUE7SUFDM0MsTUFBTUMsTUFBQSxHQUFTSCxLQUFBLENBQU1ELE1BQU07SUFFM0IsT0FBT0ksTUFBQSxLQUFXLElBQUksSUFBSUEsTUFBQTtFQUM1QjtBQUNGOzs7QUNOQSxJQUFBQyx1QkFBQSxHQUFpQ0MsT0FBQTtBQWdEMUIsU0FBU1osa0JBQWtCYSxRQUFBLEVBQVVDLFNBQUEsRUFBV0MsT0FBQSxFQUFTO0VBQzlELE1BQU1DLElBQUEsT0FBT0wsdUJBQUEsQ0FBQU0sZ0JBQUEsRUFBaUJKLFFBQUEsRUFBVUMsU0FBUyxJQUFJO0VBQ3JELE9BQU9WLGlCQUFBLENBQWtCVyxPQUFBLEVBQVNHLGNBQWMsRUFBRUYsSUFBSTtBQUN4RDtBQUdBLElBQU9HLHlCQUFBLEdBQVFuQixpQkFBQTs7O0FGcERmLElBQU9ELCtCQUFBLEdBQVFvQix5QkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==