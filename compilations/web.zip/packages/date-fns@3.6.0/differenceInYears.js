System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/compareAsc","date-fns@3.6.0/differenceInCalendarYears"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/compareAsc', dep), dep => dependencies.set('date-fns@3.6.0/differenceInCalendarYears', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/differenceInYears.3.6.0.js
var differenceInYears_3_6_0_exports = {};
__export(differenceInYears_3_6_0_exports, {
  default: () => differenceInYears_3_6_0_default,
  differenceInYears: () => differenceInYears
});
module.exports = __toCommonJS(differenceInYears_3_6_0_exports);

// node_modules/date-fns/differenceInYears.mjs
var import_compareAsc = require("date-fns@3.6.0/compareAsc");
var import_differenceInCalendarYears = require("date-fns@3.6.0/differenceInCalendarYears");
var import_toDate = require("date-fns@3.6.0/toDate");
function differenceInYears(dateLeft, dateRight) {
  const _dateLeft = (0, import_toDate.toDate)(dateLeft);
  const _dateRight = (0, import_toDate.toDate)(dateRight);
  const sign = (0, import_compareAsc.compareAsc)(_dateLeft, _dateRight);
  const difference = Math.abs((0, import_differenceInCalendarYears.differenceInCalendarYears)(_dateLeft, _dateRight));
  _dateLeft.setFullYear(1584);
  _dateRight.setFullYear(1584);
  const isLastYearNotFull = (0, import_compareAsc.compareAsc)(_dateLeft, _dateRight) === -sign;
  const result = sign * (difference - +isLastYearNotFull);
  return result === 0 ? 0 : result;
}
var differenceInYears_default = differenceInYears;

// .beyond/uimport/temp/date-fns/differenceInYears.3.6.0.js
var differenceInYears_3_6_0_default = differenceInYears_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2RpZmZlcmVuY2VJblllYXJzLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2RpZmZlcmVuY2VJblllYXJzLm1qcyJdLCJuYW1lcyI6WyJkaWZmZXJlbmNlSW5ZZWFyc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZGlmZmVyZW5jZUluWWVhcnNfM182XzBfZGVmYXVsdCIsImRpZmZlcmVuY2VJblllYXJzIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF9jb21wYXJlQXNjIiwicmVxdWlyZSIsImltcG9ydF9kaWZmZXJlbmNlSW5DYWxlbmRhclllYXJzIiwiaW1wb3J0X3RvRGF0ZSIsImRhdGVMZWZ0IiwiZGF0ZVJpZ2h0IiwiX2RhdGVMZWZ0IiwidG9EYXRlIiwiX2RhdGVSaWdodCIsInNpZ24iLCJjb21wYXJlQXNjIiwiZGlmZmVyZW5jZSIsIk1hdGgiLCJhYnMiLCJkaWZmZXJlbmNlSW5DYWxlbmRhclllYXJzIiwic2V0RnVsbFllYXIiLCJpc0xhc3RZZWFyTm90RnVsbCIsInJlc3VsdCIsImRpZmZlcmVuY2VJblllYXJzX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLCtCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsK0JBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLCtCQUFBO0VBQUFDLGlCQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCwrQkFBQTs7O0FDQUEsSUFBQVEsaUJBQUEsR0FBMkJDLE9BQUE7QUFDM0IsSUFBQUMsZ0NBQUEsR0FBMENELE9BQUE7QUFDMUMsSUFBQUUsYUFBQSxHQUF1QkYsT0FBQTtBQXNCaEIsU0FBU0wsa0JBQWtCUSxRQUFBLEVBQVVDLFNBQUEsRUFBVztFQUNyRCxNQUFNQyxTQUFBLE9BQVlILGFBQUEsQ0FBQUksTUFBQSxFQUFPSCxRQUFRO0VBQ2pDLE1BQU1JLFVBQUEsT0FBYUwsYUFBQSxDQUFBSSxNQUFBLEVBQU9GLFNBQVM7RUFFbkMsTUFBTUksSUFBQSxPQUFPVCxpQkFBQSxDQUFBVSxVQUFBLEVBQVdKLFNBQUEsRUFBV0UsVUFBVTtFQUM3QyxNQUFNRyxVQUFBLEdBQWFDLElBQUEsQ0FBS0MsR0FBQSxLQUFJWCxnQ0FBQSxDQUFBWSx5QkFBQSxFQUEwQlIsU0FBQSxFQUFXRSxVQUFVLENBQUM7RUFJNUVGLFNBQUEsQ0FBVVMsV0FBQSxDQUFZLElBQUk7RUFDMUJQLFVBQUEsQ0FBV08sV0FBQSxDQUFZLElBQUk7RUFJM0IsTUFBTUMsaUJBQUEsT0FBb0JoQixpQkFBQSxDQUFBVSxVQUFBLEVBQVdKLFNBQUEsRUFBV0UsVUFBVSxNQUFNLENBQUNDLElBQUE7RUFDakUsTUFBTVEsTUFBQSxHQUFTUixJQUFBLElBQVFFLFVBQUEsR0FBYSxDQUFDSyxpQkFBQTtFQUdyQyxPQUFPQyxNQUFBLEtBQVcsSUFBSSxJQUFJQSxNQUFBO0FBQzVCO0FBR0EsSUFBT0MseUJBQUEsR0FBUXRCLGlCQUFBOzs7QUQzQ2YsSUFBT0QsK0JBQUEsR0FBUXVCLHlCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9