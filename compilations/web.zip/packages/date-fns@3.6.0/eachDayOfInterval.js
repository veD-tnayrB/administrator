System.register(["date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/eachDayOfInterval.3.6.0.js
var eachDayOfInterval_3_6_0_exports = {};
__export(eachDayOfInterval_3_6_0_exports, {
  default: () => eachDayOfInterval_3_6_0_default,
  eachDayOfInterval: () => eachDayOfInterval
});
module.exports = __toCommonJS(eachDayOfInterval_3_6_0_exports);

// node_modules/date-fns/eachDayOfInterval.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function eachDayOfInterval(interval, options) {
  const startDate = (0, import_toDate.toDate)(interval.start);
  const endDate = (0, import_toDate.toDate)(interval.end);
  let reversed = +startDate > +endDate;
  const endTime = reversed ? +startDate : +endDate;
  const currentDate = reversed ? endDate : startDate;
  currentDate.setHours(0, 0, 0, 0);
  let step = options?.step ?? 1;
  if (!step) return [];
  if (step < 0) {
    step = -step;
    reversed = !reversed;
  }
  const dates = [];
  while (+currentDate <= endTime) {
    dates.push((0, import_toDate.toDate)(currentDate));
    currentDate.setDate(currentDate.getDate() + step);
    currentDate.setHours(0, 0, 0, 0);
  }
  return reversed ? dates.reverse() : dates;
}
var eachDayOfInterval_default = eachDayOfInterval;

// .beyond/uimport/temp/date-fns/eachDayOfInterval.3.6.0.js
var eachDayOfInterval_3_6_0_default = eachDayOfInterval_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2VhY2hEYXlPZkludGVydmFsLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2VhY2hEYXlPZkludGVydmFsLm1qcyJdLCJuYW1lcyI6WyJlYWNoRGF5T2ZJbnRlcnZhbF8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZWFjaERheU9mSW50ZXJ2YWxfM182XzBfZGVmYXVsdCIsImVhY2hEYXlPZkludGVydmFsIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF90b0RhdGUiLCJyZXF1aXJlIiwiaW50ZXJ2YWwiLCJvcHRpb25zIiwic3RhcnREYXRlIiwidG9EYXRlIiwic3RhcnQiLCJlbmREYXRlIiwiZW5kIiwicmV2ZXJzZWQiLCJlbmRUaW1lIiwiY3VycmVudERhdGUiLCJzZXRIb3VycyIsInN0ZXAiLCJkYXRlcyIsInB1c2giLCJzZXREYXRlIiwiZ2V0RGF0ZSIsInJldmVyc2UiLCJlYWNoRGF5T2ZJbnRlcnZhbF9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSwrQkFBQTtBQUFBQyxRQUFBLENBQUFELCtCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQywrQkFBQTtFQUFBQyxpQkFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsK0JBQUE7OztBQ0FBLElBQUFRLGFBQUEsR0FBdUJDLE9BQUE7QUFtQ2hCLFNBQVNMLGtCQUFrQk0sUUFBQSxFQUFVQyxPQUFBLEVBQVM7RUFDbkQsTUFBTUMsU0FBQSxPQUFZSixhQUFBLENBQUFLLE1BQUEsRUFBT0gsUUFBQSxDQUFTSSxLQUFLO0VBQ3ZDLE1BQU1DLE9BQUEsT0FBVVAsYUFBQSxDQUFBSyxNQUFBLEVBQU9ILFFBQUEsQ0FBU00sR0FBRztFQUVuQyxJQUFJQyxRQUFBLEdBQVcsQ0FBQ0wsU0FBQSxHQUFZLENBQUNHLE9BQUE7RUFDN0IsTUFBTUcsT0FBQSxHQUFVRCxRQUFBLEdBQVcsQ0FBQ0wsU0FBQSxHQUFZLENBQUNHLE9BQUE7RUFDekMsTUFBTUksV0FBQSxHQUFjRixRQUFBLEdBQVdGLE9BQUEsR0FBVUgsU0FBQTtFQUN6Q08sV0FBQSxDQUFZQyxRQUFBLENBQVMsR0FBRyxHQUFHLEdBQUcsQ0FBQztFQUUvQixJQUFJQyxJQUFBLEdBQU9WLE9BQUEsRUFBU1UsSUFBQSxJQUFRO0VBQzVCLElBQUksQ0FBQ0EsSUFBQSxFQUFNLE9BQU8sRUFBQztFQUNuQixJQUFJQSxJQUFBLEdBQU8sR0FBRztJQUNaQSxJQUFBLEdBQU8sQ0FBQ0EsSUFBQTtJQUNSSixRQUFBLEdBQVcsQ0FBQ0EsUUFBQTtFQUNkO0VBRUEsTUFBTUssS0FBQSxHQUFRLEVBQUM7RUFFZixPQUFPLENBQUNILFdBQUEsSUFBZUQsT0FBQSxFQUFTO0lBQzlCSSxLQUFBLENBQU1DLElBQUEsS0FBS2YsYUFBQSxDQUFBSyxNQUFBLEVBQU9NLFdBQVcsQ0FBQztJQUM5QkEsV0FBQSxDQUFZSyxPQUFBLENBQVFMLFdBQUEsQ0FBWU0sT0FBQSxDQUFRLElBQUlKLElBQUk7SUFDaERGLFdBQUEsQ0FBWUMsUUFBQSxDQUFTLEdBQUcsR0FBRyxHQUFHLENBQUM7RUFDakM7RUFFQSxPQUFPSCxRQUFBLEdBQVdLLEtBQUEsQ0FBTUksT0FBQSxDQUFRLElBQUlKLEtBQUE7QUFDdEM7QUFHQSxJQUFPSyx5QkFBQSxHQUFRdkIsaUJBQUE7OztBRDVEZixJQUFPRCwrQkFBQSxHQUFRd0IseUJBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=