System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/constructFrom","date-fns@3.6.0/addMilliseconds","date-fns@3.6.0/constants","date-fns@3.6.0/addHours"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/addMilliseconds', dep), dep => dependencies.set('date-fns@3.6.0/constants', dep), dep => dependencies.set('date-fns@3.6.0/addHours', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/eachHourOfInterval.3.6.0.js
var eachHourOfInterval_3_6_0_exports = {};
__export(eachHourOfInterval_3_6_0_exports, {
  default: () => eachHourOfInterval_3_6_0_default,
  eachHourOfInterval: () => eachHourOfInterval
});
module.exports = __toCommonJS(eachHourOfInterval_3_6_0_exports);

// node_modules/date-fns/eachHourOfInterval.mjs
var import_addHours = require("date-fns@3.6.0/addHours");
var import_toDate = require("date-fns@3.6.0/toDate");
function eachHourOfInterval(interval, options) {
  const startDate = (0, import_toDate.toDate)(interval.start);
  const endDate = (0, import_toDate.toDate)(interval.end);
  let reversed = +startDate > +endDate;
  const endTime = reversed ? +startDate : +endDate;
  let currentDate = reversed ? endDate : startDate;
  currentDate.setMinutes(0, 0, 0);
  let step = options?.step ?? 1;
  if (!step) return [];
  if (step < 0) {
    step = -step;
    reversed = !reversed;
  }
  const dates = [];
  while (+currentDate <= endTime) {
    dates.push((0, import_toDate.toDate)(currentDate));
    currentDate = (0, import_addHours.addHours)(currentDate, step);
  }
  return reversed ? dates.reverse() : dates;
}
var eachHourOfInterval_default = eachHourOfInterval;

// .beyond/uimport/temp/date-fns/eachHourOfInterval.3.6.0.js
var eachHourOfInterval_3_6_0_default = eachHourOfInterval_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2VhY2hIb3VyT2ZJbnRlcnZhbC4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9lYWNoSG91ck9mSW50ZXJ2YWwubWpzIl0sIm5hbWVzIjpbImVhY2hIb3VyT2ZJbnRlcnZhbF8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZWFjaEhvdXJPZkludGVydmFsXzNfNl8wX2RlZmF1bHQiLCJlYWNoSG91ck9mSW50ZXJ2YWwiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2FkZEhvdXJzIiwicmVxdWlyZSIsImltcG9ydF90b0RhdGUiLCJpbnRlcnZhbCIsIm9wdGlvbnMiLCJzdGFydERhdGUiLCJ0b0RhdGUiLCJzdGFydCIsImVuZERhdGUiLCJlbmQiLCJyZXZlcnNlZCIsImVuZFRpbWUiLCJjdXJyZW50RGF0ZSIsInNldE1pbnV0ZXMiLCJzdGVwIiwiZGF0ZXMiLCJwdXNoIiwiYWRkSG91cnMiLCJyZXZlcnNlIiwiZWFjaEhvdXJPZkludGVydmFsX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLGdDQUFBO0FBQUFDLFFBQUEsQ0FBQUQsZ0NBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLGdDQUFBO0VBQUFDLGtCQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCxnQ0FBQTs7O0FDQUEsSUFBQVEsZUFBQSxHQUF5QkMsT0FBQTtBQUN6QixJQUFBQyxhQUFBLEdBQXVCRCxPQUFBO0FBa0NoQixTQUFTTCxtQkFBbUJPLFFBQUEsRUFBVUMsT0FBQSxFQUFTO0VBQ3BELE1BQU1DLFNBQUEsT0FBWUgsYUFBQSxDQUFBSSxNQUFBLEVBQU9ILFFBQUEsQ0FBU0ksS0FBSztFQUN2QyxNQUFNQyxPQUFBLE9BQVVOLGFBQUEsQ0FBQUksTUFBQSxFQUFPSCxRQUFBLENBQVNNLEdBQUc7RUFFbkMsSUFBSUMsUUFBQSxHQUFXLENBQUNMLFNBQUEsR0FBWSxDQUFDRyxPQUFBO0VBQzdCLE1BQU1HLE9BQUEsR0FBVUQsUUFBQSxHQUFXLENBQUNMLFNBQUEsR0FBWSxDQUFDRyxPQUFBO0VBQ3pDLElBQUlJLFdBQUEsR0FBY0YsUUFBQSxHQUFXRixPQUFBLEdBQVVILFNBQUE7RUFDdkNPLFdBQUEsQ0FBWUMsVUFBQSxDQUFXLEdBQUcsR0FBRyxDQUFDO0VBRTlCLElBQUlDLElBQUEsR0FBT1YsT0FBQSxFQUFTVSxJQUFBLElBQVE7RUFDNUIsSUFBSSxDQUFDQSxJQUFBLEVBQU0sT0FBTyxFQUFDO0VBQ25CLElBQUlBLElBQUEsR0FBTyxHQUFHO0lBQ1pBLElBQUEsR0FBTyxDQUFDQSxJQUFBO0lBQ1JKLFFBQUEsR0FBVyxDQUFDQSxRQUFBO0VBQ2Q7RUFFQSxNQUFNSyxLQUFBLEdBQVEsRUFBQztFQUVmLE9BQU8sQ0FBQ0gsV0FBQSxJQUFlRCxPQUFBLEVBQVM7SUFDOUJJLEtBQUEsQ0FBTUMsSUFBQSxLQUFLZCxhQUFBLENBQUFJLE1BQUEsRUFBT00sV0FBVyxDQUFDO0lBQzlCQSxXQUFBLE9BQWNaLGVBQUEsQ0FBQWlCLFFBQUEsRUFBU0wsV0FBQSxFQUFhRSxJQUFJO0VBQzFDO0VBRUEsT0FBT0osUUFBQSxHQUFXSyxLQUFBLENBQU1HLE9BQUEsQ0FBUSxJQUFJSCxLQUFBO0FBQ3RDO0FBR0EsSUFBT0ksMEJBQUEsR0FBUXZCLGtCQUFBOzs7QUQzRGYsSUFBT0QsZ0NBQUEsR0FBUXdCLDBCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9