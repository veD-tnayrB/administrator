System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/constructFrom","date-fns@3.6.0/addMilliseconds","date-fns@3.6.0/constants","date-fns@3.6.0/addMinutes","date-fns@3.6.0/startOfMinute"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/addMilliseconds', dep), dep => dependencies.set('date-fns@3.6.0/constants', dep), dep => dependencies.set('date-fns@3.6.0/addMinutes', dep), dep => dependencies.set('date-fns@3.6.0/startOfMinute', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/eachMinuteOfInterval.3.6.0.js
var eachMinuteOfInterval_3_6_0_exports = {};
__export(eachMinuteOfInterval_3_6_0_exports, {
  default: () => eachMinuteOfInterval_3_6_0_default,
  eachMinuteOfInterval: () => eachMinuteOfInterval
});
module.exports = __toCommonJS(eachMinuteOfInterval_3_6_0_exports);

// node_modules/date-fns/eachMinuteOfInterval.mjs
var import_addMinutes = require("date-fns@3.6.0/addMinutes");
var import_startOfMinute = require("date-fns@3.6.0/startOfMinute");
var import_toDate = require("date-fns@3.6.0/toDate");
function eachMinuteOfInterval(interval, options) {
  const startDate = (0, import_startOfMinute.startOfMinute)((0, import_toDate.toDate)(interval.start));
  const endDate = (0, import_toDate.toDate)(interval.end);
  let reversed = +startDate > +endDate;
  const endTime = reversed ? +startDate : +endDate;
  let currentDate = reversed ? endDate : startDate;
  let step = options?.step ?? 1;
  if (!step) return [];
  if (step < 0) {
    step = -step;
    reversed = !reversed;
  }
  const dates = [];
  while (+currentDate <= endTime) {
    dates.push((0, import_toDate.toDate)(currentDate));
    currentDate = (0, import_addMinutes.addMinutes)(currentDate, step);
  }
  return reversed ? dates.reverse() : dates;
}
var eachMinuteOfInterval_default = eachMinuteOfInterval;

// .beyond/uimport/temp/date-fns/eachMinuteOfInterval.3.6.0.js
var eachMinuteOfInterval_3_6_0_default = eachMinuteOfInterval_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2VhY2hNaW51dGVPZkludGVydmFsLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2VhY2hNaW51dGVPZkludGVydmFsLm1qcyJdLCJuYW1lcyI6WyJlYWNoTWludXRlT2ZJbnRlcnZhbF8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZWFjaE1pbnV0ZU9mSW50ZXJ2YWxfM182XzBfZGVmYXVsdCIsImVhY2hNaW51dGVPZkludGVydmFsIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF9hZGRNaW51dGVzIiwicmVxdWlyZSIsImltcG9ydF9zdGFydE9mTWludXRlIiwiaW1wb3J0X3RvRGF0ZSIsImludGVydmFsIiwib3B0aW9ucyIsInN0YXJ0RGF0ZSIsInN0YXJ0T2ZNaW51dGUiLCJ0b0RhdGUiLCJzdGFydCIsImVuZERhdGUiLCJlbmQiLCJyZXZlcnNlZCIsImVuZFRpbWUiLCJjdXJyZW50RGF0ZSIsInN0ZXAiLCJkYXRlcyIsInB1c2giLCJhZGRNaW51dGVzIiwicmV2ZXJzZSIsImVhY2hNaW51dGVPZkludGVydmFsX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLGtDQUFBO0FBQUFDLFFBQUEsQ0FBQUQsa0NBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLGtDQUFBO0VBQUFDLG9CQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCxrQ0FBQTs7O0FDQUEsSUFBQVEsaUJBQUEsR0FBMkJDLE9BQUE7QUFDM0IsSUFBQUMsb0JBQUEsR0FBOEJELE9BQUE7QUFDOUIsSUFBQUUsYUFBQSxHQUF1QkYsT0FBQTtBQWtDaEIsU0FBU0wscUJBQXFCUSxRQUFBLEVBQVVDLE9BQUEsRUFBUztFQUN0RCxNQUFNQyxTQUFBLE9BQVlKLG9CQUFBLENBQUFLLGFBQUEsTUFBY0osYUFBQSxDQUFBSyxNQUFBLEVBQU9KLFFBQUEsQ0FBU0ssS0FBSyxDQUFDO0VBQ3RELE1BQU1DLE9BQUEsT0FBVVAsYUFBQSxDQUFBSyxNQUFBLEVBQU9KLFFBQUEsQ0FBU08sR0FBRztFQUVuQyxJQUFJQyxRQUFBLEdBQVcsQ0FBQ04sU0FBQSxHQUFZLENBQUNJLE9BQUE7RUFDN0IsTUFBTUcsT0FBQSxHQUFVRCxRQUFBLEdBQVcsQ0FBQ04sU0FBQSxHQUFZLENBQUNJLE9BQUE7RUFDekMsSUFBSUksV0FBQSxHQUFjRixRQUFBLEdBQVdGLE9BQUEsR0FBVUosU0FBQTtFQUV2QyxJQUFJUyxJQUFBLEdBQU9WLE9BQUEsRUFBU1UsSUFBQSxJQUFRO0VBQzVCLElBQUksQ0FBQ0EsSUFBQSxFQUFNLE9BQU8sRUFBQztFQUNuQixJQUFJQSxJQUFBLEdBQU8sR0FBRztJQUNaQSxJQUFBLEdBQU8sQ0FBQ0EsSUFBQTtJQUNSSCxRQUFBLEdBQVcsQ0FBQ0EsUUFBQTtFQUNkO0VBRUEsTUFBTUksS0FBQSxHQUFRLEVBQUM7RUFFZixPQUFPLENBQUNGLFdBQUEsSUFBZUQsT0FBQSxFQUFTO0lBQzlCRyxLQUFBLENBQU1DLElBQUEsS0FBS2QsYUFBQSxDQUFBSyxNQUFBLEVBQU9NLFdBQVcsQ0FBQztJQUM5QkEsV0FBQSxPQUFjZCxpQkFBQSxDQUFBa0IsVUFBQSxFQUFXSixXQUFBLEVBQWFDLElBQUk7RUFDNUM7RUFFQSxPQUFPSCxRQUFBLEdBQVdJLEtBQUEsQ0FBTUcsT0FBQSxDQUFRLElBQUlILEtBQUE7QUFDdEM7QUFHQSxJQUFPSSw0QkFBQSxHQUFReEIsb0JBQUE7OztBRDNEZixJQUFPRCxrQ0FBQSxHQUFReUIsNEJBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=