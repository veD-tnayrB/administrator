System.register(["date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/eachMonthOfInterval.3.6.0.js
var eachMonthOfInterval_3_6_0_exports = {};
__export(eachMonthOfInterval_3_6_0_exports, {
  default: () => eachMonthOfInterval_3_6_0_default,
  eachMonthOfInterval: () => eachMonthOfInterval
});
module.exports = __toCommonJS(eachMonthOfInterval_3_6_0_exports);

// node_modules/date-fns/eachMonthOfInterval.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function eachMonthOfInterval(interval, options) {
  const startDate = (0, import_toDate.toDate)(interval.start);
  const endDate = (0, import_toDate.toDate)(interval.end);
  let reversed = +startDate > +endDate;
  const endTime = reversed ? +startDate : +endDate;
  const currentDate = reversed ? endDate : startDate;
  currentDate.setHours(0, 0, 0, 0);
  currentDate.setDate(1);
  let step = options?.step ?? 1;
  if (!step) return [];
  if (step < 0) {
    step = -step;
    reversed = !reversed;
  }
  const dates = [];
  while (+currentDate <= endTime) {
    dates.push((0, import_toDate.toDate)(currentDate));
    currentDate.setMonth(currentDate.getMonth() + step);
  }
  return reversed ? dates.reverse() : dates;
}
var eachMonthOfInterval_default = eachMonthOfInterval;

// .beyond/uimport/temp/date-fns/eachMonthOfInterval.3.6.0.js
var eachMonthOfInterval_3_6_0_default = eachMonthOfInterval_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2VhY2hNb250aE9mSW50ZXJ2YWwuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvZWFjaE1vbnRoT2ZJbnRlcnZhbC5tanMiXSwibmFtZXMiOlsiZWFjaE1vbnRoT2ZJbnRlcnZhbF8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZWFjaE1vbnRoT2ZJbnRlcnZhbF8zXzZfMF9kZWZhdWx0IiwiZWFjaE1vbnRoT2ZJbnRlcnZhbCIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfdG9EYXRlIiwicmVxdWlyZSIsImludGVydmFsIiwib3B0aW9ucyIsInN0YXJ0RGF0ZSIsInRvRGF0ZSIsInN0YXJ0IiwiZW5kRGF0ZSIsImVuZCIsInJldmVyc2VkIiwiZW5kVGltZSIsImN1cnJlbnREYXRlIiwic2V0SG91cnMiLCJzZXREYXRlIiwic3RlcCIsImRhdGVzIiwicHVzaCIsInNldE1vbnRoIiwiZ2V0TW9udGgiLCJyZXZlcnNlIiwiZWFjaE1vbnRoT2ZJbnRlcnZhbF9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSxpQ0FBQTtBQUFBQyxRQUFBLENBQUFELGlDQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyxpQ0FBQTtFQUFBQyxtQkFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsaUNBQUE7OztBQ0FBLElBQUFRLGFBQUEsR0FBdUJDLE9BQUE7QUFvQ2hCLFNBQVNMLG9CQUFvQk0sUUFBQSxFQUFVQyxPQUFBLEVBQVM7RUFDckQsTUFBTUMsU0FBQSxPQUFZSixhQUFBLENBQUFLLE1BQUEsRUFBT0gsUUFBQSxDQUFTSSxLQUFLO0VBQ3ZDLE1BQU1DLE9BQUEsT0FBVVAsYUFBQSxDQUFBSyxNQUFBLEVBQU9ILFFBQUEsQ0FBU00sR0FBRztFQUVuQyxJQUFJQyxRQUFBLEdBQVcsQ0FBQ0wsU0FBQSxHQUFZLENBQUNHLE9BQUE7RUFDN0IsTUFBTUcsT0FBQSxHQUFVRCxRQUFBLEdBQVcsQ0FBQ0wsU0FBQSxHQUFZLENBQUNHLE9BQUE7RUFDekMsTUFBTUksV0FBQSxHQUFjRixRQUFBLEdBQVdGLE9BQUEsR0FBVUgsU0FBQTtFQUN6Q08sV0FBQSxDQUFZQyxRQUFBLENBQVMsR0FBRyxHQUFHLEdBQUcsQ0FBQztFQUMvQkQsV0FBQSxDQUFZRSxPQUFBLENBQVEsQ0FBQztFQUVyQixJQUFJQyxJQUFBLEdBQU9YLE9BQUEsRUFBU1csSUFBQSxJQUFRO0VBQzVCLElBQUksQ0FBQ0EsSUFBQSxFQUFNLE9BQU8sRUFBQztFQUNuQixJQUFJQSxJQUFBLEdBQU8sR0FBRztJQUNaQSxJQUFBLEdBQU8sQ0FBQ0EsSUFBQTtJQUNSTCxRQUFBLEdBQVcsQ0FBQ0EsUUFBQTtFQUNkO0VBRUEsTUFBTU0sS0FBQSxHQUFRLEVBQUM7RUFFZixPQUFPLENBQUNKLFdBQUEsSUFBZUQsT0FBQSxFQUFTO0lBQzlCSyxLQUFBLENBQU1DLElBQUEsS0FBS2hCLGFBQUEsQ0FBQUssTUFBQSxFQUFPTSxXQUFXLENBQUM7SUFDOUJBLFdBQUEsQ0FBWU0sUUFBQSxDQUFTTixXQUFBLENBQVlPLFFBQUEsQ0FBUyxJQUFJSixJQUFJO0VBQ3BEO0VBRUEsT0FBT0wsUUFBQSxHQUFXTSxLQUFBLENBQU1JLE9BQUEsQ0FBUSxJQUFJSixLQUFBO0FBQ3RDO0FBR0EsSUFBT0ssMkJBQUEsR0FBUXhCLG1CQUFBOzs7QUQ3RGYsSUFBT0QsaUNBQUEsR0FBUXlCLDJCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9