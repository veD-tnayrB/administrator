System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/constructFrom","date-fns@3.6.0/addMonths","date-fns@3.6.0/addQuarters","date-fns@3.6.0/startOfQuarter"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/addMonths', dep), dep => dependencies.set('date-fns@3.6.0/addQuarters', dep), dep => dependencies.set('date-fns@3.6.0/startOfQuarter', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/eachQuarterOfInterval.3.6.0.js
var eachQuarterOfInterval_3_6_0_exports = {};
__export(eachQuarterOfInterval_3_6_0_exports, {
  default: () => eachQuarterOfInterval_3_6_0_default,
  eachQuarterOfInterval: () => eachQuarterOfInterval
});
module.exports = __toCommonJS(eachQuarterOfInterval_3_6_0_exports);

// node_modules/date-fns/eachQuarterOfInterval.mjs
var import_addQuarters = require("date-fns@3.6.0/addQuarters");
var import_startOfQuarter = require("date-fns@3.6.0/startOfQuarter");
var import_toDate = require("date-fns@3.6.0/toDate");
function eachQuarterOfInterval(interval, options) {
  const startDate = (0, import_toDate.toDate)(interval.start);
  const endDate = (0, import_toDate.toDate)(interval.end);
  let reversed = +startDate > +endDate;
  const endTime = reversed ? +(0, import_startOfQuarter.startOfQuarter)(startDate) : +(0, import_startOfQuarter.startOfQuarter)(endDate);
  let currentDate = reversed ? (0, import_startOfQuarter.startOfQuarter)(endDate) : (0, import_startOfQuarter.startOfQuarter)(startDate);
  let step = options?.step ?? 1;
  if (!step) return [];
  if (step < 0) {
    step = -step;
    reversed = !reversed;
  }
  const dates = [];
  while (+currentDate <= endTime) {
    dates.push((0, import_toDate.toDate)(currentDate));
    currentDate = (0, import_addQuarters.addQuarters)(currentDate, step);
  }
  return reversed ? dates.reverse() : dates;
}
var eachQuarterOfInterval_default = eachQuarterOfInterval;

// .beyond/uimport/temp/date-fns/eachQuarterOfInterval.3.6.0.js
var eachQuarterOfInterval_3_6_0_default = eachQuarterOfInterval_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2VhY2hRdWFydGVyT2ZJbnRlcnZhbC4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9lYWNoUXVhcnRlck9mSW50ZXJ2YWwubWpzIl0sIm5hbWVzIjpbImVhY2hRdWFydGVyT2ZJbnRlcnZhbF8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZWFjaFF1YXJ0ZXJPZkludGVydmFsXzNfNl8wX2RlZmF1bHQiLCJlYWNoUXVhcnRlck9mSW50ZXJ2YWwiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2FkZFF1YXJ0ZXJzIiwicmVxdWlyZSIsImltcG9ydF9zdGFydE9mUXVhcnRlciIsImltcG9ydF90b0RhdGUiLCJpbnRlcnZhbCIsIm9wdGlvbnMiLCJzdGFydERhdGUiLCJ0b0RhdGUiLCJzdGFydCIsImVuZERhdGUiLCJlbmQiLCJyZXZlcnNlZCIsImVuZFRpbWUiLCJzdGFydE9mUXVhcnRlciIsImN1cnJlbnREYXRlIiwic3RlcCIsImRhdGVzIiwicHVzaCIsImFkZFF1YXJ0ZXJzIiwicmV2ZXJzZSIsImVhY2hRdWFydGVyT2ZJbnRlcnZhbF9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSxtQ0FBQTtBQUFBQyxRQUFBLENBQUFELG1DQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyxtQ0FBQTtFQUFBQyxxQkFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsbUNBQUE7OztBQ0FBLElBQUFRLGtCQUFBLEdBQTRCQyxPQUFBO0FBQzVCLElBQUFDLHFCQUFBLEdBQStCRCxPQUFBO0FBQy9CLElBQUFFLGFBQUEsR0FBdUJGLE9BQUE7QUFnQ2hCLFNBQVNMLHNCQUFzQlEsUUFBQSxFQUFVQyxPQUFBLEVBQVM7RUFDdkQsTUFBTUMsU0FBQSxPQUFZSCxhQUFBLENBQUFJLE1BQUEsRUFBT0gsUUFBQSxDQUFTSSxLQUFLO0VBQ3ZDLE1BQU1DLE9BQUEsT0FBVU4sYUFBQSxDQUFBSSxNQUFBLEVBQU9ILFFBQUEsQ0FBU00sR0FBRztFQUVuQyxJQUFJQyxRQUFBLEdBQVcsQ0FBQ0wsU0FBQSxHQUFZLENBQUNHLE9BQUE7RUFDN0IsTUFBTUcsT0FBQSxHQUFVRCxRQUFBLEdBQ1osS0FBQ1QscUJBQUEsQ0FBQVcsY0FBQSxFQUFlUCxTQUFTLElBQ3pCLEtBQUNKLHFCQUFBLENBQUFXLGNBQUEsRUFBZUosT0FBTztFQUMzQixJQUFJSyxXQUFBLEdBQWNILFFBQUEsT0FDZFQscUJBQUEsQ0FBQVcsY0FBQSxFQUFlSixPQUFPLFFBQ3RCUCxxQkFBQSxDQUFBVyxjQUFBLEVBQWVQLFNBQVM7RUFFNUIsSUFBSVMsSUFBQSxHQUFPVixPQUFBLEVBQVNVLElBQUEsSUFBUTtFQUM1QixJQUFJLENBQUNBLElBQUEsRUFBTSxPQUFPLEVBQUM7RUFDbkIsSUFBSUEsSUFBQSxHQUFPLEdBQUc7SUFDWkEsSUFBQSxHQUFPLENBQUNBLElBQUE7SUFDUkosUUFBQSxHQUFXLENBQUNBLFFBQUE7RUFDZDtFQUVBLE1BQU1LLEtBQUEsR0FBUSxFQUFDO0VBRWYsT0FBTyxDQUFDRixXQUFBLElBQWVGLE9BQUEsRUFBUztJQUM5QkksS0FBQSxDQUFNQyxJQUFBLEtBQUtkLGFBQUEsQ0FBQUksTUFBQSxFQUFPTyxXQUFXLENBQUM7SUFDOUJBLFdBQUEsT0FBY2Qsa0JBQUEsQ0FBQWtCLFdBQUEsRUFBWUosV0FBQSxFQUFhQyxJQUFJO0VBQzdDO0VBRUEsT0FBT0osUUFBQSxHQUFXSyxLQUFBLENBQU1HLE9BQUEsQ0FBUSxJQUFJSCxLQUFBO0FBQ3RDO0FBR0EsSUFBT0ksNkJBQUEsR0FBUXhCLHFCQUFBOzs7QUQ3RGYsSUFBT0QsbUNBQUEsR0FBUXlCLDZCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9