System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/constructFrom","date-fns@3.6.0/addDays","date-fns@3.6.0/addWeeks","date-fns@3.6.0/startOfWeek"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/addDays', dep), dep => dependencies.set('date-fns@3.6.0/addWeeks', dep), dep => dependencies.set('date-fns@3.6.0/startOfWeek', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/eachWeekOfInterval.3.6.0.js
var eachWeekOfInterval_3_6_0_exports = {};
__export(eachWeekOfInterval_3_6_0_exports, {
  default: () => eachWeekOfInterval_3_6_0_default,
  eachWeekOfInterval: () => eachWeekOfInterval
});
module.exports = __toCommonJS(eachWeekOfInterval_3_6_0_exports);

// node_modules/date-fns/eachWeekOfInterval.mjs
var import_addWeeks = require("date-fns@3.6.0/addWeeks");
var import_startOfWeek = require("date-fns@3.6.0/startOfWeek");
var import_toDate = require("date-fns@3.6.0/toDate");
function eachWeekOfInterval(interval, options) {
  const startDate = (0, import_toDate.toDate)(interval.start);
  const endDate = (0, import_toDate.toDate)(interval.end);
  let reversed = +startDate > +endDate;
  const startDateWeek = reversed ? (0, import_startOfWeek.startOfWeek)(endDate, options) : (0, import_startOfWeek.startOfWeek)(startDate, options);
  const endDateWeek = reversed ? (0, import_startOfWeek.startOfWeek)(startDate, options) : (0, import_startOfWeek.startOfWeek)(endDate, options);
  startDateWeek.setHours(15);
  endDateWeek.setHours(15);
  const endTime = +endDateWeek.getTime();
  let currentDate = startDateWeek;
  let step = options?.step ?? 1;
  if (!step) return [];
  if (step < 0) {
    step = -step;
    reversed = !reversed;
  }
  const dates = [];
  while (+currentDate <= endTime) {
    currentDate.setHours(0);
    dates.push((0, import_toDate.toDate)(currentDate));
    currentDate = (0, import_addWeeks.addWeeks)(currentDate, step);
    currentDate.setHours(15);
  }
  return reversed ? dates.reverse() : dates;
}
var eachWeekOfInterval_default = eachWeekOfInterval;

// .beyond/uimport/temp/date-fns/eachWeekOfInterval.3.6.0.js
var eachWeekOfInterval_3_6_0_default = eachWeekOfInterval_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2VhY2hXZWVrT2ZJbnRlcnZhbC4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9lYWNoV2Vla09mSW50ZXJ2YWwubWpzIl0sIm5hbWVzIjpbImVhY2hXZWVrT2ZJbnRlcnZhbF8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZWFjaFdlZWtPZkludGVydmFsXzNfNl8wX2RlZmF1bHQiLCJlYWNoV2Vla09mSW50ZXJ2YWwiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2FkZFdlZWtzIiwicmVxdWlyZSIsImltcG9ydF9zdGFydE9mV2VlayIsImltcG9ydF90b0RhdGUiLCJpbnRlcnZhbCIsIm9wdGlvbnMiLCJzdGFydERhdGUiLCJ0b0RhdGUiLCJzdGFydCIsImVuZERhdGUiLCJlbmQiLCJyZXZlcnNlZCIsInN0YXJ0RGF0ZVdlZWsiLCJzdGFydE9mV2VlayIsImVuZERhdGVXZWVrIiwic2V0SG91cnMiLCJlbmRUaW1lIiwiZ2V0VGltZSIsImN1cnJlbnREYXRlIiwic3RlcCIsImRhdGVzIiwicHVzaCIsImFkZFdlZWtzIiwicmV2ZXJzZSIsImVhY2hXZWVrT2ZJbnRlcnZhbF9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSxnQ0FBQTtBQUFBQyxRQUFBLENBQUFELGdDQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyxnQ0FBQTtFQUFBQyxrQkFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsZ0NBQUE7OztBQ0FBLElBQUFRLGVBQUEsR0FBeUJDLE9BQUE7QUFDekIsSUFBQUMsa0JBQUEsR0FBNEJELE9BQUE7QUFDNUIsSUFBQUUsYUFBQSxHQUF1QkYsT0FBQTtBQXNDaEIsU0FBU0wsbUJBQW1CUSxRQUFBLEVBQVVDLE9BQUEsRUFBUztFQUNwRCxNQUFNQyxTQUFBLE9BQVlILGFBQUEsQ0FBQUksTUFBQSxFQUFPSCxRQUFBLENBQVNJLEtBQUs7RUFDdkMsTUFBTUMsT0FBQSxPQUFVTixhQUFBLENBQUFJLE1BQUEsRUFBT0gsUUFBQSxDQUFTTSxHQUFHO0VBRW5DLElBQUlDLFFBQUEsR0FBVyxDQUFDTCxTQUFBLEdBQVksQ0FBQ0csT0FBQTtFQUM3QixNQUFNRyxhQUFBLEdBQWdCRCxRQUFBLE9BQ2xCVCxrQkFBQSxDQUFBVyxXQUFBLEVBQVlKLE9BQUEsRUFBU0osT0FBTyxRQUM1Qkgsa0JBQUEsQ0FBQVcsV0FBQSxFQUFZUCxTQUFBLEVBQVdELE9BQU87RUFDbEMsTUFBTVMsV0FBQSxHQUFjSCxRQUFBLE9BQ2hCVCxrQkFBQSxDQUFBVyxXQUFBLEVBQVlQLFNBQUEsRUFBV0QsT0FBTyxRQUM5Qkgsa0JBQUEsQ0FBQVcsV0FBQSxFQUFZSixPQUFBLEVBQVNKLE9BQU87RUFHaENPLGFBQUEsQ0FBY0csUUFBQSxDQUFTLEVBQUU7RUFDekJELFdBQUEsQ0FBWUMsUUFBQSxDQUFTLEVBQUU7RUFFdkIsTUFBTUMsT0FBQSxHQUFVLENBQUNGLFdBQUEsQ0FBWUcsT0FBQSxDQUFRO0VBQ3JDLElBQUlDLFdBQUEsR0FBY04sYUFBQTtFQUVsQixJQUFJTyxJQUFBLEdBQU9kLE9BQUEsRUFBU2MsSUFBQSxJQUFRO0VBQzVCLElBQUksQ0FBQ0EsSUFBQSxFQUFNLE9BQU8sRUFBQztFQUNuQixJQUFJQSxJQUFBLEdBQU8sR0FBRztJQUNaQSxJQUFBLEdBQU8sQ0FBQ0EsSUFBQTtJQUNSUixRQUFBLEdBQVcsQ0FBQ0EsUUFBQTtFQUNkO0VBRUEsTUFBTVMsS0FBQSxHQUFRLEVBQUM7RUFFZixPQUFPLENBQUNGLFdBQUEsSUFBZUYsT0FBQSxFQUFTO0lBQzlCRSxXQUFBLENBQVlILFFBQUEsQ0FBUyxDQUFDO0lBQ3RCSyxLQUFBLENBQU1DLElBQUEsS0FBS2xCLGFBQUEsQ0FBQUksTUFBQSxFQUFPVyxXQUFXLENBQUM7SUFDOUJBLFdBQUEsT0FBY2xCLGVBQUEsQ0FBQXNCLFFBQUEsRUFBU0osV0FBQSxFQUFhQyxJQUFJO0lBQ3hDRCxXQUFBLENBQVlILFFBQUEsQ0FBUyxFQUFFO0VBQ3pCO0VBRUEsT0FBT0osUUFBQSxHQUFXUyxLQUFBLENBQU1HLE9BQUEsQ0FBUSxJQUFJSCxLQUFBO0FBQ3RDO0FBR0EsSUFBT0ksMEJBQUEsR0FBUTVCLGtCQUFBOzs7QUQ1RWYsSUFBT0QsZ0NBQUEsR0FBUTZCLDBCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9