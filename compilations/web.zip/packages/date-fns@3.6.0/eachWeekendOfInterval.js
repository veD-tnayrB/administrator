System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/eachDayOfInterval","date-fns@3.6.0/isWeekend"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/eachDayOfInterval', dep), dep => dependencies.set('date-fns@3.6.0/isWeekend', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/eachWeekendOfInterval.3.6.0.js
var eachWeekendOfInterval_3_6_0_exports = {};
__export(eachWeekendOfInterval_3_6_0_exports, {
  default: () => eachWeekendOfInterval_3_6_0_default,
  eachWeekendOfInterval: () => eachWeekendOfInterval
});
module.exports = __toCommonJS(eachWeekendOfInterval_3_6_0_exports);

// node_modules/date-fns/eachWeekendOfInterval.mjs
var import_eachDayOfInterval = require("date-fns@3.6.0/eachDayOfInterval");
var import_isWeekend = require("date-fns@3.6.0/isWeekend");
function eachWeekendOfInterval(interval) {
  const dateInterval = (0, import_eachDayOfInterval.eachDayOfInterval)(interval);
  const weekends = [];
  let index = 0;
  while (index < dateInterval.length) {
    const date = dateInterval[index++];
    if ((0, import_isWeekend.isWeekend)(date)) weekends.push(date);
  }
  return weekends;
}
var eachWeekendOfInterval_default = eachWeekendOfInterval;

// .beyond/uimport/temp/date-fns/eachWeekendOfInterval.3.6.0.js
var eachWeekendOfInterval_3_6_0_default = eachWeekendOfInterval_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2VhY2hXZWVrZW5kT2ZJbnRlcnZhbC4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9lYWNoV2Vla2VuZE9mSW50ZXJ2YWwubWpzIl0sIm5hbWVzIjpbImVhY2hXZWVrZW5kT2ZJbnRlcnZhbF8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZWFjaFdlZWtlbmRPZkludGVydmFsXzNfNl8wX2RlZmF1bHQiLCJlYWNoV2Vla2VuZE9mSW50ZXJ2YWwiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2VhY2hEYXlPZkludGVydmFsIiwicmVxdWlyZSIsImltcG9ydF9pc1dlZWtlbmQiLCJpbnRlcnZhbCIsImRhdGVJbnRlcnZhbCIsImVhY2hEYXlPZkludGVydmFsIiwid2Vla2VuZHMiLCJpbmRleCIsImxlbmd0aCIsImRhdGUiLCJpc1dlZWtlbmQiLCJwdXNoIiwiZWFjaFdlZWtlbmRPZkludGVydmFsX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLG1DQUFBO0FBQUFDLFFBQUEsQ0FBQUQsbUNBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLG1DQUFBO0VBQUFDLHFCQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCxtQ0FBQTs7O0FDQUEsSUFBQVEsd0JBQUEsR0FBa0NDLE9BQUE7QUFDbEMsSUFBQUMsZ0JBQUEsR0FBMEJELE9BQUE7QUE2Qm5CLFNBQVNMLHNCQUFzQk8sUUFBQSxFQUFVO0VBQzlDLE1BQU1DLFlBQUEsT0FBZUosd0JBQUEsQ0FBQUssaUJBQUEsRUFBa0JGLFFBQVE7RUFDL0MsTUFBTUcsUUFBQSxHQUFXLEVBQUM7RUFDbEIsSUFBSUMsS0FBQSxHQUFRO0VBQ1osT0FBT0EsS0FBQSxHQUFRSCxZQUFBLENBQWFJLE1BQUEsRUFBUTtJQUNsQyxNQUFNQyxJQUFBLEdBQU9MLFlBQUEsQ0FBYUcsS0FBQTtJQUMxQixRQUFJTCxnQkFBQSxDQUFBUSxTQUFBLEVBQVVELElBQUksR0FBR0gsUUFBQSxDQUFTSyxJQUFBLENBQUtGLElBQUk7RUFDekM7RUFDQSxPQUFPSCxRQUFBO0FBQ1Q7QUFHQSxJQUFPTSw2QkFBQSxHQUFRaEIscUJBQUE7OztBRHZDZixJQUFPRCxtQ0FBQSxHQUFRaUIsNkJBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=