System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/eachDayOfInterval","date-fns@3.6.0/isWeekend","date-fns@3.6.0/eachWeekendOfInterval","date-fns@3.6.0/endOfYear","date-fns@3.6.0/constructFrom","date-fns@3.6.0/startOfYear"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/eachDayOfInterval', dep), dep => dependencies.set('date-fns@3.6.0/isWeekend', dep), dep => dependencies.set('date-fns@3.6.0/eachWeekendOfInterval', dep), dep => dependencies.set('date-fns@3.6.0/endOfYear', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/startOfYear', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/eachWeekendOfYear.3.6.0.js
var eachWeekendOfYear_3_6_0_exports = {};
__export(eachWeekendOfYear_3_6_0_exports, {
  default: () => eachWeekendOfYear_3_6_0_default,
  eachWeekendOfYear: () => eachWeekendOfYear
});
module.exports = __toCommonJS(eachWeekendOfYear_3_6_0_exports);

// node_modules/date-fns/eachWeekendOfYear.mjs
var import_eachWeekendOfInterval = require("date-fns@3.6.0/eachWeekendOfInterval");
var import_endOfYear = require("date-fns@3.6.0/endOfYear");
var import_startOfYear = require("date-fns@3.6.0/startOfYear");
function eachWeekendOfYear(date) {
  const start = (0, import_startOfYear.startOfYear)(date);
  const end = (0, import_endOfYear.endOfYear)(date);
  return (0, import_eachWeekendOfInterval.eachWeekendOfInterval)({
    start,
    end
  });
}
var eachWeekendOfYear_default = eachWeekendOfYear;

// .beyond/uimport/temp/date-fns/eachWeekendOfYear.3.6.0.js
var eachWeekendOfYear_3_6_0_default = eachWeekendOfYear_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2VhY2hXZWVrZW5kT2ZZZWFyLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2VhY2hXZWVrZW5kT2ZZZWFyLm1qcyJdLCJuYW1lcyI6WyJlYWNoV2Vla2VuZE9mWWVhcl8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZWFjaFdlZWtlbmRPZlllYXJfM182XzBfZGVmYXVsdCIsImVhY2hXZWVrZW5kT2ZZZWFyIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF9lYWNoV2Vla2VuZE9mSW50ZXJ2YWwiLCJyZXF1aXJlIiwiaW1wb3J0X2VuZE9mWWVhciIsImltcG9ydF9zdGFydE9mWWVhciIsImRhdGUiLCJzdGFydCIsInN0YXJ0T2ZZZWFyIiwiZW5kIiwiZW5kT2ZZZWFyIiwiZWFjaFdlZWtlbmRPZkludGVydmFsIiwiZWFjaFdlZWtlbmRPZlllYXJfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsK0JBQUE7QUFBQUMsUUFBQSxDQUFBRCwrQkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsK0JBQUE7RUFBQUMsaUJBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLCtCQUFBOzs7QUNBQSxJQUFBUSw0QkFBQSxHQUFzQ0MsT0FBQTtBQUN0QyxJQUFBQyxnQkFBQSxHQUEwQkQsT0FBQTtBQUMxQixJQUFBRSxrQkFBQSxHQUE0QkYsT0FBQTtBQTJCckIsU0FBU0wsa0JBQWtCUSxJQUFBLEVBQU07RUFDdEMsTUFBTUMsS0FBQSxPQUFRRixrQkFBQSxDQUFBRyxXQUFBLEVBQVlGLElBQUk7RUFDOUIsTUFBTUcsR0FBQSxPQUFNTCxnQkFBQSxDQUFBTSxTQUFBLEVBQVVKLElBQUk7RUFDMUIsV0FBT0osNEJBQUEsQ0FBQVMscUJBQUEsRUFBc0I7SUFBRUosS0FBQTtJQUFPRTtFQUFJLENBQUM7QUFDN0M7QUFHQSxJQUFPRyx5QkFBQSxHQUFRZCxpQkFBQTs7O0FEakNmLElBQU9ELCtCQUFBLEdBQVFlLHlCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9