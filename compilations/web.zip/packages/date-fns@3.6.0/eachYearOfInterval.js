System.register(["date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/eachYearOfInterval.3.6.0.js
var eachYearOfInterval_3_6_0_exports = {};
__export(eachYearOfInterval_3_6_0_exports, {
  default: () => eachYearOfInterval_3_6_0_default,
  eachYearOfInterval: () => eachYearOfInterval
});
module.exports = __toCommonJS(eachYearOfInterval_3_6_0_exports);

// node_modules/date-fns/eachYearOfInterval.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function eachYearOfInterval(interval, options) {
  const startDate = (0, import_toDate.toDate)(interval.start);
  const endDate = (0, import_toDate.toDate)(interval.end);
  let reversed = +startDate > +endDate;
  const endTime = reversed ? +startDate : +endDate;
  const currentDate = reversed ? endDate : startDate;
  currentDate.setHours(0, 0, 0, 0);
  currentDate.setMonth(0, 1);
  let step = options?.step ?? 1;
  if (!step) return [];
  if (step < 0) {
    step = -step;
    reversed = !reversed;
  }
  const dates = [];
  while (+currentDate <= endTime) {
    dates.push((0, import_toDate.toDate)(currentDate));
    currentDate.setFullYear(currentDate.getFullYear() + step);
  }
  return reversed ? dates.reverse() : dates;
}
var eachYearOfInterval_default = eachYearOfInterval;

// .beyond/uimport/temp/date-fns/eachYearOfInterval.3.6.0.js
var eachYearOfInterval_3_6_0_default = eachYearOfInterval_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2VhY2hZZWFyT2ZJbnRlcnZhbC4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9lYWNoWWVhck9mSW50ZXJ2YWwubWpzIl0sIm5hbWVzIjpbImVhY2hZZWFyT2ZJbnRlcnZhbF8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZWFjaFllYXJPZkludGVydmFsXzNfNl8wX2RlZmF1bHQiLCJlYWNoWWVhck9mSW50ZXJ2YWwiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X3RvRGF0ZSIsInJlcXVpcmUiLCJpbnRlcnZhbCIsIm9wdGlvbnMiLCJzdGFydERhdGUiLCJ0b0RhdGUiLCJzdGFydCIsImVuZERhdGUiLCJlbmQiLCJyZXZlcnNlZCIsImVuZFRpbWUiLCJjdXJyZW50RGF0ZSIsInNldEhvdXJzIiwic2V0TW9udGgiLCJzdGVwIiwiZGF0ZXMiLCJwdXNoIiwic2V0RnVsbFllYXIiLCJnZXRGdWxsWWVhciIsInJldmVyc2UiLCJlYWNoWWVhck9mSW50ZXJ2YWxfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsZ0NBQUE7QUFBQUMsUUFBQSxDQUFBRCxnQ0FBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsZ0NBQUE7RUFBQUMsa0JBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLGdDQUFBOzs7QUNBQSxJQUFBUSxhQUFBLEdBQXVCQyxPQUFBO0FBaUNoQixTQUFTTCxtQkFBbUJNLFFBQUEsRUFBVUMsT0FBQSxFQUFTO0VBQ3BELE1BQU1DLFNBQUEsT0FBWUosYUFBQSxDQUFBSyxNQUFBLEVBQU9ILFFBQUEsQ0FBU0ksS0FBSztFQUN2QyxNQUFNQyxPQUFBLE9BQVVQLGFBQUEsQ0FBQUssTUFBQSxFQUFPSCxRQUFBLENBQVNNLEdBQUc7RUFFbkMsSUFBSUMsUUFBQSxHQUFXLENBQUNMLFNBQUEsR0FBWSxDQUFDRyxPQUFBO0VBQzdCLE1BQU1HLE9BQUEsR0FBVUQsUUFBQSxHQUFXLENBQUNMLFNBQUEsR0FBWSxDQUFDRyxPQUFBO0VBQ3pDLE1BQU1JLFdBQUEsR0FBY0YsUUFBQSxHQUFXRixPQUFBLEdBQVVILFNBQUE7RUFDekNPLFdBQUEsQ0FBWUMsUUFBQSxDQUFTLEdBQUcsR0FBRyxHQUFHLENBQUM7RUFDL0JELFdBQUEsQ0FBWUUsUUFBQSxDQUFTLEdBQUcsQ0FBQztFQUV6QixJQUFJQyxJQUFBLEdBQU9YLE9BQUEsRUFBU1csSUFBQSxJQUFRO0VBQzVCLElBQUksQ0FBQ0EsSUFBQSxFQUFNLE9BQU8sRUFBQztFQUNuQixJQUFJQSxJQUFBLEdBQU8sR0FBRztJQUNaQSxJQUFBLEdBQU8sQ0FBQ0EsSUFBQTtJQUNSTCxRQUFBLEdBQVcsQ0FBQ0EsUUFBQTtFQUNkO0VBRUEsTUFBTU0sS0FBQSxHQUFRLEVBQUM7RUFFZixPQUFPLENBQUNKLFdBQUEsSUFBZUQsT0FBQSxFQUFTO0lBQzlCSyxLQUFBLENBQU1DLElBQUEsS0FBS2hCLGFBQUEsQ0FBQUssTUFBQSxFQUFPTSxXQUFXLENBQUM7SUFDOUJBLFdBQUEsQ0FBWU0sV0FBQSxDQUFZTixXQUFBLENBQVlPLFdBQUEsQ0FBWSxJQUFJSixJQUFJO0VBQzFEO0VBRUEsT0FBT0wsUUFBQSxHQUFXTSxLQUFBLENBQU1JLE9BQUEsQ0FBUSxJQUFJSixLQUFBO0FBQ3RDO0FBR0EsSUFBT0ssMEJBQUEsR0FBUXhCLGtCQUFBOzs7QUQxRGYsSUFBT0QsZ0NBQUEsR0FBUXlCLDBCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9