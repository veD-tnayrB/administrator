System.register(["date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/endOfQuarter.3.6.0.js
var endOfQuarter_3_6_0_exports = {};
__export(endOfQuarter_3_6_0_exports, {
  default: () => endOfQuarter_3_6_0_default,
  endOfQuarter: () => endOfQuarter
});
module.exports = __toCommonJS(endOfQuarter_3_6_0_exports);

// node_modules/date-fns/endOfQuarter.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function endOfQuarter(date) {
  const _date = (0, import_toDate.toDate)(date);
  const currentMonth = _date.getMonth();
  const month = currentMonth - currentMonth % 3 + 3;
  _date.setMonth(month, 0);
  _date.setHours(23, 59, 59, 999);
  return _date;
}
var endOfQuarter_default = endOfQuarter;

// .beyond/uimport/temp/date-fns/endOfQuarter.3.6.0.js
var endOfQuarter_3_6_0_default = endOfQuarter_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2VuZE9mUXVhcnRlci4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9lbmRPZlF1YXJ0ZXIubWpzIl0sIm5hbWVzIjpbImVuZE9mUXVhcnRlcl8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZW5kT2ZRdWFydGVyXzNfNl8wX2RlZmF1bHQiLCJlbmRPZlF1YXJ0ZXIiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X3RvRGF0ZSIsInJlcXVpcmUiLCJkYXRlIiwiX2RhdGUiLCJ0b0RhdGUiLCJjdXJyZW50TW9udGgiLCJnZXRNb250aCIsIm1vbnRoIiwic2V0TW9udGgiLCJzZXRIb3VycyIsImVuZE9mUXVhcnRlcl9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSwwQkFBQTtBQUFBQyxRQUFBLENBQUFELDBCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQywwQkFBQTtFQUFBQyxZQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCwwQkFBQTs7O0FDQUEsSUFBQVEsYUFBQSxHQUF1QkMsT0FBQTtBQXNCaEIsU0FBU0wsYUFBYU0sSUFBQSxFQUFNO0VBQ2pDLE1BQU1DLEtBQUEsT0FBUUgsYUFBQSxDQUFBSSxNQUFBLEVBQU9GLElBQUk7RUFDekIsTUFBTUcsWUFBQSxHQUFlRixLQUFBLENBQU1HLFFBQUEsQ0FBUztFQUNwQyxNQUFNQyxLQUFBLEdBQVFGLFlBQUEsR0FBZ0JBLFlBQUEsR0FBZSxJQUFLO0VBQ2xERixLQUFBLENBQU1LLFFBQUEsQ0FBU0QsS0FBQSxFQUFPLENBQUM7RUFDdkJKLEtBQUEsQ0FBTU0sUUFBQSxDQUFTLElBQUksSUFBSSxJQUFJLEdBQUc7RUFDOUIsT0FBT04sS0FBQTtBQUNUO0FBR0EsSUFBT08sb0JBQUEsR0FBUWQsWUFBQTs7O0FEN0JmLElBQU9ELDBCQUFBLEdBQVFlLG9CQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9