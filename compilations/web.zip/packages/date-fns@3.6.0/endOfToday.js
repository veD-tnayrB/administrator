System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/endOfDay"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/endOfDay', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/endOfToday.3.6.0.js
var endOfToday_3_6_0_exports = {};
__export(endOfToday_3_6_0_exports, {
  default: () => endOfToday_3_6_0_default,
  endOfToday: () => endOfToday
});
module.exports = __toCommonJS(endOfToday_3_6_0_exports);

// node_modules/date-fns/endOfToday.mjs
var import_endOfDay = require("date-fns@3.6.0/endOfDay");
function endOfToday() {
  return (0, import_endOfDay.endOfDay)(Date.now());
}
var endOfToday_default = endOfToday;

// .beyond/uimport/temp/date-fns/endOfToday.3.6.0.js
var endOfToday_3_6_0_default = endOfToday_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2VuZE9mVG9kYXkuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvZW5kT2ZUb2RheS5tanMiXSwibmFtZXMiOlsiZW5kT2ZUb2RheV8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZW5kT2ZUb2RheV8zXzZfMF9kZWZhdWx0IiwiZW5kT2ZUb2RheSIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfZW5kT2ZEYXkiLCJyZXF1aXJlIiwiZW5kT2ZEYXkiLCJEYXRlIiwibm93IiwiZW5kT2ZUb2RheV9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSx3QkFBQTtBQUFBQyxRQUFBLENBQUFELHdCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyx3QkFBQTtFQUFBQyxVQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCx3QkFBQTs7O0FDQUEsSUFBQVEsZUFBQSxHQUF5QkMsT0FBQTtBQW9CbEIsU0FBU0wsV0FBQSxFQUFhO0VBQzNCLFdBQU9JLGVBQUEsQ0FBQUUsUUFBQSxFQUFTQyxJQUFBLENBQUtDLEdBQUEsQ0FBSSxDQUFDO0FBQzVCO0FBR0EsSUFBT0Msa0JBQUEsR0FBUVQsVUFBQTs7O0FEdEJmLElBQU9ELHdCQUFBLEdBQVFVLGtCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9