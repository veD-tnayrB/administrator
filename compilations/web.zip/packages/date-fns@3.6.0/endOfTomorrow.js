System.register([], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/endOfTomorrow.3.6.0.js
var endOfTomorrow_3_6_0_exports = {};
__export(endOfTomorrow_3_6_0_exports, {
  default: () => endOfTomorrow_3_6_0_default,
  endOfTomorrow: () => endOfTomorrow
});
module.exports = __toCommonJS(endOfTomorrow_3_6_0_exports);

// node_modules/date-fns/endOfTomorrow.mjs
function endOfTomorrow() {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();
  const day = now.getDate();
  const date = new Date(0);
  date.setFullYear(year, month, day + 1);
  date.setHours(23, 59, 59, 999);
  return date;
}
var endOfTomorrow_default = endOfTomorrow;

// .beyond/uimport/temp/date-fns/endOfTomorrow.3.6.0.js
var endOfTomorrow_3_6_0_default = endOfTomorrow_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2VuZE9mVG9tb3Jyb3cuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvZW5kT2ZUb21vcnJvdy5tanMiXSwibmFtZXMiOlsiZW5kT2ZUb21vcnJvd18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZW5kT2ZUb21vcnJvd18zXzZfMF9kZWZhdWx0IiwiZW5kT2ZUb21vcnJvdyIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJub3ciLCJEYXRlIiwieWVhciIsImdldEZ1bGxZZWFyIiwibW9udGgiLCJnZXRNb250aCIsImRheSIsImdldERhdGUiLCJkYXRlIiwic2V0RnVsbFllYXIiLCJzZXRIb3VycyIsImVuZE9mVG9tb3Jyb3dfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsMkJBQUE7QUFBQUMsUUFBQSxDQUFBRCwyQkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsMkJBQUE7RUFBQUMsYUFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsMkJBQUE7OztBQ2tCTyxTQUFTSSxjQUFBLEVBQWdCO0VBQzlCLE1BQU1JLEdBQUEsR0FBTSxJQUFJQyxJQUFBLENBQUs7RUFDckIsTUFBTUMsSUFBQSxHQUFPRixHQUFBLENBQUlHLFdBQUEsQ0FBWTtFQUM3QixNQUFNQyxLQUFBLEdBQVFKLEdBQUEsQ0FBSUssUUFBQSxDQUFTO0VBQzNCLE1BQU1DLEdBQUEsR0FBTU4sR0FBQSxDQUFJTyxPQUFBLENBQVE7RUFFeEIsTUFBTUMsSUFBQSxHQUFPLElBQUlQLElBQUEsQ0FBSyxDQUFDO0VBQ3ZCTyxJQUFBLENBQUtDLFdBQUEsQ0FBWVAsSUFBQSxFQUFNRSxLQUFBLEVBQU9FLEdBQUEsR0FBTSxDQUFDO0VBQ3JDRSxJQUFBLENBQUtFLFFBQUEsQ0FBUyxJQUFJLElBQUksSUFBSSxHQUFHO0VBQzdCLE9BQU9GLElBQUE7QUFDVDtBQUdBLElBQU9HLHFCQUFBLEdBQVFmLGFBQUE7OztBRDVCZixJQUFPRCwyQkFBQSxHQUFRZ0IscUJBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=