System.register([], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/endOfYesterday.3.6.0.js
var endOfYesterday_3_6_0_exports = {};
__export(endOfYesterday_3_6_0_exports, {
  default: () => endOfYesterday_3_6_0_default,
  endOfYesterday: () => endOfYesterday
});
module.exports = __toCommonJS(endOfYesterday_3_6_0_exports);

// node_modules/date-fns/endOfYesterday.mjs
function endOfYesterday() {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();
  const day = now.getDate();
  const date = new Date(0);
  date.setFullYear(year, month, day - 1);
  date.setHours(23, 59, 59, 999);
  return date;
}
var endOfYesterday_default = endOfYesterday;

// .beyond/uimport/temp/date-fns/endOfYesterday.3.6.0.js
var endOfYesterday_3_6_0_default = endOfYesterday_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2VuZE9mWWVzdGVyZGF5LjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2VuZE9mWWVzdGVyZGF5Lm1qcyJdLCJuYW1lcyI6WyJlbmRPZlllc3RlcmRheV8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZW5kT2ZZZXN0ZXJkYXlfM182XzBfZGVmYXVsdCIsImVuZE9mWWVzdGVyZGF5IiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsIm5vdyIsIkRhdGUiLCJ5ZWFyIiwiZ2V0RnVsbFllYXIiLCJtb250aCIsImdldE1vbnRoIiwiZGF5IiwiZ2V0RGF0ZSIsImRhdGUiLCJzZXRGdWxsWWVhciIsInNldEhvdXJzIiwiZW5kT2ZZZXN0ZXJkYXlfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsNEJBQUE7QUFBQUMsUUFBQSxDQUFBRCw0QkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsNEJBQUE7RUFBQUMsY0FBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsNEJBQUE7OztBQ2tCTyxTQUFTSSxlQUFBLEVBQWlCO0VBQy9CLE1BQU1JLEdBQUEsR0FBTSxJQUFJQyxJQUFBLENBQUs7RUFDckIsTUFBTUMsSUFBQSxHQUFPRixHQUFBLENBQUlHLFdBQUEsQ0FBWTtFQUM3QixNQUFNQyxLQUFBLEdBQVFKLEdBQUEsQ0FBSUssUUFBQSxDQUFTO0VBQzNCLE1BQU1DLEdBQUEsR0FBTU4sR0FBQSxDQUFJTyxPQUFBLENBQVE7RUFFeEIsTUFBTUMsSUFBQSxHQUFPLElBQUlQLElBQUEsQ0FBSyxDQUFDO0VBQ3ZCTyxJQUFBLENBQUtDLFdBQUEsQ0FBWVAsSUFBQSxFQUFNRSxLQUFBLEVBQU9FLEdBQUEsR0FBTSxDQUFDO0VBQ3JDRSxJQUFBLENBQUtFLFFBQUEsQ0FBUyxJQUFJLElBQUksSUFBSSxHQUFHO0VBQzdCLE9BQU9GLElBQUE7QUFDVDtBQUdBLElBQU9HLHNCQUFBLEdBQVFmLGNBQUE7OztBRDVCZixJQUFPRCw0QkFBQSxHQUFRZ0Isc0JBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=