System.register(["date-fns@3.6.0/locale/en-US","date-fns@3.6.0/toDate","date-fns@3.6.0/compareAsc","date-fns@3.6.0/constants"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/locale/en-US', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/compareAsc', dep), dep => dependencies.set('date-fns@3.6.0/constants', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/formatDistanceStrict.3.6.0.js
var formatDistanceStrict_3_6_0_exports = {};
__export(formatDistanceStrict_3_6_0_exports, {
  default: () => formatDistanceStrict_3_6_0_default,
  formatDistanceStrict: () => formatDistanceStrict
});
module.exports = __toCommonJS(formatDistanceStrict_3_6_0_exports);

// node_modules/date-fns/_lib/defaultLocale.mjs
var import_en_US = require("date-fns@3.6.0/locale/en-US");

// node_modules/date-fns/_lib/defaultOptions.mjs
var defaultOptions = {};
function getDefaultOptions() {
  return defaultOptions;
}
function setDefaultOptions(newOptions) {
  defaultOptions = newOptions;
}

// node_modules/date-fns/_lib/getRoundingMethod.mjs
function getRoundingMethod(method) {
  return number => {
    const round = method ? Math[method] : Math.trunc;
    const result = round(number);
    return result === 0 ? 0 : result;
  };
}

// node_modules/date-fns/_lib/getTimezoneOffsetInMilliseconds.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function getTimezoneOffsetInMilliseconds(date) {
  const _date = (0, import_toDate.toDate)(date);
  const utcDate = new Date(Date.UTC(_date.getFullYear(), _date.getMonth(), _date.getDate(), _date.getHours(), _date.getMinutes(), _date.getSeconds(), _date.getMilliseconds()));
  utcDate.setUTCFullYear(_date.getFullYear());
  return +date - +utcDate;
}

// node_modules/date-fns/formatDistanceStrict.mjs
var import_compareAsc = require("date-fns@3.6.0/compareAsc");
var import_constants = require("date-fns@3.6.0/constants");
var import_toDate2 = require("date-fns@3.6.0/toDate");
function formatDistanceStrict(date, baseDate, options) {
  const defaultOptions2 = getDefaultOptions();
  const locale = options?.locale ?? defaultOptions2.locale ?? import_en_US.enUS;
  const comparison = (0, import_compareAsc.compareAsc)(date, baseDate);
  if (isNaN(comparison)) {
    throw new RangeError("Invalid time value");
  }
  const localizeOptions = Object.assign({}, options, {
    addSuffix: options?.addSuffix,
    comparison
  });
  let dateLeft;
  let dateRight;
  if (comparison > 0) {
    dateLeft = (0, import_toDate2.toDate)(baseDate);
    dateRight = (0, import_toDate2.toDate)(date);
  } else {
    dateLeft = (0, import_toDate2.toDate)(date);
    dateRight = (0, import_toDate2.toDate)(baseDate);
  }
  const roundingMethod = getRoundingMethod(options?.roundingMethod ?? "round");
  const milliseconds = dateRight.getTime() - dateLeft.getTime();
  const minutes = milliseconds / import_constants.millisecondsInMinute;
  const timezoneOffset = getTimezoneOffsetInMilliseconds(dateRight) - getTimezoneOffsetInMilliseconds(dateLeft);
  const dstNormalizedMinutes = (milliseconds - timezoneOffset) / import_constants.millisecondsInMinute;
  const defaultUnit = options?.unit;
  let unit;
  if (!defaultUnit) {
    if (minutes < 1) {
      unit = "second";
    } else if (minutes < 60) {
      unit = "minute";
    } else if (minutes < import_constants.minutesInDay) {
      unit = "hour";
    } else if (dstNormalizedMinutes < import_constants.minutesInMonth) {
      unit = "day";
    } else if (dstNormalizedMinutes < import_constants.minutesInYear) {
      unit = "month";
    } else {
      unit = "year";
    }
  } else {
    unit = defaultUnit;
  }
  if (unit === "second") {
    const seconds = roundingMethod(milliseconds / 1e3);
    return locale.formatDistance("xSeconds", seconds, localizeOptions);
  } else if (unit === "minute") {
    const roundedMinutes = roundingMethod(minutes);
    return locale.formatDistance("xMinutes", roundedMinutes, localizeOptions);
  } else if (unit === "hour") {
    const hours = roundingMethod(minutes / 60);
    return locale.formatDistance("xHours", hours, localizeOptions);
  } else if (unit === "day") {
    const days = roundingMethod(dstNormalizedMinutes / import_constants.minutesInDay);
    return locale.formatDistance("xDays", days, localizeOptions);
  } else if (unit === "month") {
    const months = roundingMethod(dstNormalizedMinutes / import_constants.minutesInMonth);
    return months === 12 && defaultUnit !== "month" ? locale.formatDistance("xYears", 1, localizeOptions) : locale.formatDistance("xMonths", months, localizeOptions);
  } else {
    const years = roundingMethod(dstNormalizedMinutes / import_constants.minutesInYear);
    return locale.formatDistance("xYears", years, localizeOptions);
  }
}
var formatDistanceStrict_default = formatDistanceStrict;

// .beyond/uimport/temp/date-fns/formatDistanceStrict.3.6.0.js
var formatDistanceStrict_3_6_0_default = formatDistanceStrict_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2Zvcm1hdERpc3RhbmNlU3RyaWN0LjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL19saWIvZGVmYXVsdExvY2FsZS5tanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvX2xpYi9kZWZhdWx0T3B0aW9ucy5tanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvX2xpYi9nZXRSb3VuZGluZ01ldGhvZC5tanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvX2xpYi9nZXRUaW1lem9uZU9mZnNldEluTWlsbGlzZWNvbmRzLm1qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9mb3JtYXREaXN0YW5jZVN0cmljdC5tanMiXSwibmFtZXMiOlsiZm9ybWF0RGlzdGFuY2VTdHJpY3RfM182XzBfZXhwb3J0cyIsIl9fZXhwb3J0IiwiZGVmYXVsdCIsImZvcm1hdERpc3RhbmNlU3RyaWN0XzNfNl8wX2RlZmF1bHQiLCJmb3JtYXREaXN0YW5jZVN0cmljdCIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfZW5fVVMiLCJyZXF1aXJlIiwiZGVmYXVsdE9wdGlvbnMiLCJnZXREZWZhdWx0T3B0aW9ucyIsInNldERlZmF1bHRPcHRpb25zIiwibmV3T3B0aW9ucyIsImdldFJvdW5kaW5nTWV0aG9kIiwibWV0aG9kIiwibnVtYmVyIiwicm91bmQiLCJNYXRoIiwidHJ1bmMiLCJyZXN1bHQiLCJpbXBvcnRfdG9EYXRlIiwiZ2V0VGltZXpvbmVPZmZzZXRJbk1pbGxpc2Vjb25kcyIsImRhdGUiLCJfZGF0ZSIsInRvRGF0ZSIsInV0Y0RhdGUiLCJEYXRlIiwiVVRDIiwiZ2V0RnVsbFllYXIiLCJnZXRNb250aCIsImdldERhdGUiLCJnZXRIb3VycyIsImdldE1pbnV0ZXMiLCJnZXRTZWNvbmRzIiwiZ2V0TWlsbGlzZWNvbmRzIiwic2V0VVRDRnVsbFllYXIiLCJpbXBvcnRfY29tcGFyZUFzYyIsImltcG9ydF9jb25zdGFudHMiLCJpbXBvcnRfdG9EYXRlMiIsImJhc2VEYXRlIiwib3B0aW9ucyIsImRlZmF1bHRPcHRpb25zMiIsImxvY2FsZSIsImVuVVMiLCJjb21wYXJpc29uIiwiY29tcGFyZUFzYyIsImlzTmFOIiwiUmFuZ2VFcnJvciIsImxvY2FsaXplT3B0aW9ucyIsIk9iamVjdCIsImFzc2lnbiIsImFkZFN1ZmZpeCIsImRhdGVMZWZ0IiwiZGF0ZVJpZ2h0Iiwicm91bmRpbmdNZXRob2QiLCJtaWxsaXNlY29uZHMiLCJnZXRUaW1lIiwibWludXRlcyIsIm1pbGxpc2Vjb25kc0luTWludXRlIiwidGltZXpvbmVPZmZzZXQiLCJkc3ROb3JtYWxpemVkTWludXRlcyIsImRlZmF1bHRVbml0IiwidW5pdCIsIm1pbnV0ZXNJbkRheSIsIm1pbnV0ZXNJbk1vbnRoIiwibWludXRlc0luWWVhciIsInNlY29uZHMiLCJmb3JtYXREaXN0YW5jZSIsInJvdW5kZWRNaW51dGVzIiwiaG91cnMiLCJkYXlzIiwibW9udGhzIiwieWVhcnMiLCJmb3JtYXREaXN0YW5jZVN0cmljdF9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSxrQ0FBQTtBQUFBQyxRQUFBLENBQUFELGtDQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyxrQ0FBQTtFQUFBQyxvQkFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsa0NBQUE7OztBQ0FBLElBQUFRLFlBQUEsR0FBc0NDLE9BQUE7OztBQ0F0QyxJQUFJQyxjQUFBLEdBQWlCLENBQUM7QUFFZixTQUFTQyxrQkFBQSxFQUFvQjtFQUNsQyxPQUFPRCxjQUFBO0FBQ1Q7QUFFTyxTQUFTRSxrQkFBa0JDLFVBQUEsRUFBWTtFQUM1Q0gsY0FBQSxHQUFpQkcsVUFBQTtBQUNuQjs7O0FDUk8sU0FBU0Msa0JBQWtCQyxNQUFBLEVBQVE7RUFDeEMsT0FBUUMsTUFBQSxJQUFXO0lBQ2pCLE1BQU1DLEtBQUEsR0FBUUYsTUFBQSxHQUFTRyxJQUFBLENBQUtILE1BQUEsSUFBVUcsSUFBQSxDQUFLQyxLQUFBO0lBQzNDLE1BQU1DLE1BQUEsR0FBU0gsS0FBQSxDQUFNRCxNQUFNO0lBRTNCLE9BQU9JLE1BQUEsS0FBVyxJQUFJLElBQUlBLE1BQUE7RUFDNUI7QUFDRjs7O0FDUEEsSUFBQUMsYUFBQSxHQUF1QlosT0FBQTtBQWFoQixTQUFTYSxnQ0FBZ0NDLElBQUEsRUFBTTtFQUNwRCxNQUFNQyxLQUFBLE9BQVFILGFBQUEsQ0FBQUksTUFBQSxFQUFPRixJQUFJO0VBQ3pCLE1BQU1HLE9BQUEsR0FBVSxJQUFJQyxJQUFBLENBQ2xCQSxJQUFBLENBQUtDLEdBQUEsQ0FDSEosS0FBQSxDQUFNSyxXQUFBLENBQVksR0FDbEJMLEtBQUEsQ0FBTU0sUUFBQSxDQUFTLEdBQ2ZOLEtBQUEsQ0FBTU8sT0FBQSxDQUFRLEdBQ2RQLEtBQUEsQ0FBTVEsUUFBQSxDQUFTLEdBQ2ZSLEtBQUEsQ0FBTVMsVUFBQSxDQUFXLEdBQ2pCVCxLQUFBLENBQU1VLFVBQUEsQ0FBVyxHQUNqQlYsS0FBQSxDQUFNVyxlQUFBLENBQWdCLENBQ3hCLENBQ0Y7RUFDQVQsT0FBQSxDQUFRVSxjQUFBLENBQWVaLEtBQUEsQ0FBTUssV0FBQSxDQUFZLENBQUM7RUFDMUMsT0FBTyxDQUFDTixJQUFBLEdBQU8sQ0FBQ0csT0FBQTtBQUNsQjs7O0FDeEJBLElBQUFXLGlCQUFBLEdBQTJCNUIsT0FBQTtBQUMzQixJQUFBNkIsZ0JBQUEsR0FLTzdCLE9BQUE7QUFDUCxJQUFBOEIsY0FBQSxHQUF1QjlCLE9BQUE7QUEwRmhCLFNBQVNMLHFCQUFxQm1CLElBQUEsRUFBTWlCLFFBQUEsRUFBVUMsT0FBQSxFQUFTO0VBQzVELE1BQU1DLGVBQUEsR0FBaUIvQixpQkFBQSxDQUFrQjtFQUN6QyxNQUFNZ0MsTUFBQSxHQUFTRixPQUFBLEVBQVNFLE1BQUEsSUFBVUQsZUFBQSxDQUFlQyxNQUFBLElBQVVuQyxZQUFBLENBQUFvQyxJQUFBO0VBRTNELE1BQU1DLFVBQUEsT0FBYVIsaUJBQUEsQ0FBQVMsVUFBQSxFQUFXdkIsSUFBQSxFQUFNaUIsUUFBUTtFQUU1QyxJQUFJTyxLQUFBLENBQU1GLFVBQVUsR0FBRztJQUNyQixNQUFNLElBQUlHLFVBQUEsQ0FBVyxvQkFBb0I7RUFDM0M7RUFFQSxNQUFNQyxlQUFBLEdBQWtCQyxNQUFBLENBQU9DLE1BQUEsQ0FBTyxDQUFDLEdBQUdWLE9BQUEsRUFBUztJQUNqRFcsU0FBQSxFQUFXWCxPQUFBLEVBQVNXLFNBQUE7SUFDcEJQO0VBQ0YsQ0FBQztFQUVELElBQUlRLFFBQUE7RUFDSixJQUFJQyxTQUFBO0VBQ0osSUFBSVQsVUFBQSxHQUFhLEdBQUc7SUFDbEJRLFFBQUEsT0FBV2QsY0FBQSxDQUFBZCxNQUFBLEVBQU9lLFFBQVE7SUFDMUJjLFNBQUEsT0FBWWYsY0FBQSxDQUFBZCxNQUFBLEVBQU9GLElBQUk7RUFDekIsT0FBTztJQUNMOEIsUUFBQSxPQUFXZCxjQUFBLENBQUFkLE1BQUEsRUFBT0YsSUFBSTtJQUN0QitCLFNBQUEsT0FBWWYsY0FBQSxDQUFBZCxNQUFBLEVBQU9lLFFBQVE7RUFDN0I7RUFFQSxNQUFNZSxjQUFBLEdBQWlCekMsaUJBQUEsQ0FBa0IyQixPQUFBLEVBQVNjLGNBQUEsSUFBa0IsT0FBTztFQUUzRSxNQUFNQyxZQUFBLEdBQWVGLFNBQUEsQ0FBVUcsT0FBQSxDQUFRLElBQUlKLFFBQUEsQ0FBU0ksT0FBQSxDQUFRO0VBQzVELE1BQU1DLE9BQUEsR0FBVUYsWUFBQSxHQUFlbEIsZ0JBQUEsQ0FBQXFCLG9CQUFBO0VBRS9CLE1BQU1DLGNBQUEsR0FDSnRDLCtCQUFBLENBQWdDZ0MsU0FBUyxJQUN6Q2hDLCtCQUFBLENBQWdDK0IsUUFBUTtFQUkxQyxNQUFNUSxvQkFBQSxJQUNITCxZQUFBLEdBQWVJLGNBQUEsSUFBa0J0QixnQkFBQSxDQUFBcUIsb0JBQUE7RUFFcEMsTUFBTUcsV0FBQSxHQUFjckIsT0FBQSxFQUFTc0IsSUFBQTtFQUM3QixJQUFJQSxJQUFBO0VBQ0osSUFBSSxDQUFDRCxXQUFBLEVBQWE7SUFDaEIsSUFBSUosT0FBQSxHQUFVLEdBQUc7TUFDZkssSUFBQSxHQUFPO0lBQ1QsV0FBV0wsT0FBQSxHQUFVLElBQUk7TUFDdkJLLElBQUEsR0FBTztJQUNULFdBQVdMLE9BQUEsR0FBVXBCLGdCQUFBLENBQUEwQixZQUFBLEVBQWM7TUFDakNELElBQUEsR0FBTztJQUNULFdBQVdGLG9CQUFBLEdBQXVCdkIsZ0JBQUEsQ0FBQTJCLGNBQUEsRUFBZ0I7TUFDaERGLElBQUEsR0FBTztJQUNULFdBQVdGLG9CQUFBLEdBQXVCdkIsZ0JBQUEsQ0FBQTRCLGFBQUEsRUFBZTtNQUMvQ0gsSUFBQSxHQUFPO0lBQ1QsT0FBTztNQUNMQSxJQUFBLEdBQU87SUFDVDtFQUNGLE9BQU87SUFDTEEsSUFBQSxHQUFPRCxXQUFBO0VBQ1Q7RUFHQSxJQUFJQyxJQUFBLEtBQVMsVUFBVTtJQUNyQixNQUFNSSxPQUFBLEdBQVVaLGNBQUEsQ0FBZUMsWUFBQSxHQUFlLEdBQUk7SUFDbEQsT0FBT2IsTUFBQSxDQUFPeUIsY0FBQSxDQUFlLFlBQVlELE9BQUEsRUFBU2xCLGVBQWU7RUFHbkUsV0FBV2MsSUFBQSxLQUFTLFVBQVU7SUFDNUIsTUFBTU0sY0FBQSxHQUFpQmQsY0FBQSxDQUFlRyxPQUFPO0lBQzdDLE9BQU9mLE1BQUEsQ0FBT3lCLGNBQUEsQ0FBZSxZQUFZQyxjQUFBLEVBQWdCcEIsZUFBZTtFQUcxRSxXQUFXYyxJQUFBLEtBQVMsUUFBUTtJQUMxQixNQUFNTyxLQUFBLEdBQVFmLGNBQUEsQ0FBZUcsT0FBQSxHQUFVLEVBQUU7SUFDekMsT0FBT2YsTUFBQSxDQUFPeUIsY0FBQSxDQUFlLFVBQVVFLEtBQUEsRUFBT3JCLGVBQWU7RUFHL0QsV0FBV2MsSUFBQSxLQUFTLE9BQU87SUFDekIsTUFBTVEsSUFBQSxHQUFPaEIsY0FBQSxDQUFlTSxvQkFBQSxHQUF1QnZCLGdCQUFBLENBQUEwQixZQUFZO0lBQy9ELE9BQU9yQixNQUFBLENBQU95QixjQUFBLENBQWUsU0FBU0csSUFBQSxFQUFNdEIsZUFBZTtFQUc3RCxXQUFXYyxJQUFBLEtBQVMsU0FBUztJQUMzQixNQUFNUyxNQUFBLEdBQVNqQixjQUFBLENBQWVNLG9CQUFBLEdBQXVCdkIsZ0JBQUEsQ0FBQTJCLGNBQWM7SUFDbkUsT0FBT08sTUFBQSxLQUFXLE1BQU1WLFdBQUEsS0FBZ0IsVUFDcENuQixNQUFBLENBQU95QixjQUFBLENBQWUsVUFBVSxHQUFHbkIsZUFBZSxJQUNsRE4sTUFBQSxDQUFPeUIsY0FBQSxDQUFlLFdBQVdJLE1BQUEsRUFBUXZCLGVBQWU7RUFHOUQsT0FBTztJQUNMLE1BQU13QixLQUFBLEdBQVFsQixjQUFBLENBQWVNLG9CQUFBLEdBQXVCdkIsZ0JBQUEsQ0FBQTRCLGFBQWE7SUFDakUsT0FBT3ZCLE1BQUEsQ0FBT3lCLGNBQUEsQ0FBZSxVQUFVSyxLQUFBLEVBQU94QixlQUFlO0VBQy9EO0FBQ0Y7QUFHQSxJQUFPeUIsNEJBQUEsR0FBUXRFLG9CQUFBOzs7QUxoTWYsSUFBT0Qsa0NBQUEsR0FBUXVFLDRCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9