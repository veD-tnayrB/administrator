System.register(["date-fns@3.6.0/locale/en-US"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/locale/en-US', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/formatDuration.3.6.0.js
var formatDuration_3_6_0_exports = {};
__export(formatDuration_3_6_0_exports, {
  default: () => formatDuration_3_6_0_default,
  formatDuration: () => formatDuration
});
module.exports = __toCommonJS(formatDuration_3_6_0_exports);

// node_modules/date-fns/_lib/defaultLocale.mjs
var import_en_US = require("date-fns@3.6.0/locale/en-US");

// node_modules/date-fns/_lib/defaultOptions.mjs
var defaultOptions = {};
function getDefaultOptions() {
  return defaultOptions;
}
function setDefaultOptions(newOptions) {
  defaultOptions = newOptions;
}

// node_modules/date-fns/formatDuration.mjs
var defaultFormat = ["years", "months", "weeks", "days", "hours", "minutes", "seconds"];
function formatDuration(duration, options) {
  const defaultOptions2 = getDefaultOptions();
  const locale = options?.locale ?? defaultOptions2.locale ?? import_en_US.enUS;
  const format = options?.format ?? defaultFormat;
  const zero = options?.zero ?? false;
  const delimiter = options?.delimiter ?? " ";
  if (!locale.formatDistance) {
    return "";
  }
  const result = format.reduce((acc, unit) => {
    const token = `x${unit.replace(/(^.)/, m => m.toUpperCase())}`;
    const value = duration[unit];
    if (value !== void 0 && (zero || duration[unit])) {
      return acc.concat(locale.formatDistance(token, value));
    }
    return acc;
  }, []).join(delimiter);
  return result;
}
var formatDuration_default = formatDuration;

// .beyond/uimport/temp/date-fns/formatDuration.3.6.0.js
var formatDuration_3_6_0_default = formatDuration_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2Zvcm1hdER1cmF0aW9uLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL19saWIvZGVmYXVsdExvY2FsZS5tanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvX2xpYi9kZWZhdWx0T3B0aW9ucy5tanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvZm9ybWF0RHVyYXRpb24ubWpzIl0sIm5hbWVzIjpbImZvcm1hdER1cmF0aW9uXzNfNl8wX2V4cG9ydHMiLCJfX2V4cG9ydCIsImRlZmF1bHQiLCJmb3JtYXREdXJhdGlvbl8zXzZfMF9kZWZhdWx0IiwiZm9ybWF0RHVyYXRpb24iLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2VuX1VTIiwicmVxdWlyZSIsImRlZmF1bHRPcHRpb25zIiwiZ2V0RGVmYXVsdE9wdGlvbnMiLCJzZXREZWZhdWx0T3B0aW9ucyIsIm5ld09wdGlvbnMiLCJkZWZhdWx0Rm9ybWF0IiwiZHVyYXRpb24iLCJvcHRpb25zIiwiZGVmYXVsdE9wdGlvbnMyIiwibG9jYWxlIiwiZW5VUyIsImZvcm1hdCIsInplcm8iLCJkZWxpbWl0ZXIiLCJmb3JtYXREaXN0YW5jZSIsInJlc3VsdCIsInJlZHVjZSIsImFjYyIsInVuaXQiLCJ0b2tlbiIsInJlcGxhY2UiLCJtIiwidG9VcHBlckNhc2UiLCJ2YWx1ZSIsImNvbmNhdCIsImpvaW4iLCJmb3JtYXREdXJhdGlvbl9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSw0QkFBQTtBQUFBQyxRQUFBLENBQUFELDRCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyw0QkFBQTtFQUFBQyxjQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCw0QkFBQTs7O0FDQUEsSUFBQVEsWUFBQSxHQUFzQ0MsT0FBQTs7O0FDQXRDLElBQUlDLGNBQUEsR0FBaUIsQ0FBQztBQUVmLFNBQVNDLGtCQUFBLEVBQW9CO0VBQ2xDLE9BQU9ELGNBQUE7QUFDVDtBQUVPLFNBQVNFLGtCQUFrQkMsVUFBQSxFQUFZO0VBQzVDSCxjQUFBLEdBQWlCRyxVQUFBO0FBQ25COzs7QUNEQSxJQUFNQyxhQUFBLEdBQWdCLENBQ3BCLFNBQ0EsVUFDQSxTQUNBLFFBQ0EsU0FDQSxXQUNBLFVBQ0Y7QUE4RE8sU0FBU1YsZUFBZVcsUUFBQSxFQUFVQyxPQUFBLEVBQVM7RUFDaEQsTUFBTUMsZUFBQSxHQUFpQk4saUJBQUEsQ0FBa0I7RUFDekMsTUFBTU8sTUFBQSxHQUFTRixPQUFBLEVBQVNFLE1BQUEsSUFBVUQsZUFBQSxDQUFlQyxNQUFBLElBQVVWLFlBQUEsQ0FBQVcsSUFBQTtFQUMzRCxNQUFNQyxNQUFBLEdBQVNKLE9BQUEsRUFBU0ksTUFBQSxJQUFVTixhQUFBO0VBQ2xDLE1BQU1PLElBQUEsR0FBT0wsT0FBQSxFQUFTSyxJQUFBLElBQVE7RUFDOUIsTUFBTUMsU0FBQSxHQUFZTixPQUFBLEVBQVNNLFNBQUEsSUFBYTtFQUV4QyxJQUFJLENBQUNKLE1BQUEsQ0FBT0ssY0FBQSxFQUFnQjtJQUMxQixPQUFPO0VBQ1Q7RUFFQSxNQUFNQyxNQUFBLEdBQVNKLE1BQUEsQ0FDWkssTUFBQSxDQUFPLENBQUNDLEdBQUEsRUFBS0MsSUFBQSxLQUFTO0lBQ3JCLE1BQU1DLEtBQUEsR0FBUSxJQUFJRCxJQUFBLENBQUtFLE9BQUEsQ0FBUSxRQUFTQyxDQUFBLElBQU1BLENBQUEsQ0FBRUMsV0FBQSxDQUFZLENBQUM7SUFDN0QsTUFBTUMsS0FBQSxHQUFRakIsUUFBQSxDQUFTWSxJQUFBO0lBQ3ZCLElBQUlLLEtBQUEsS0FBVSxXQUFjWCxJQUFBLElBQVFOLFFBQUEsQ0FBU1ksSUFBQSxJQUFRO01BQ25ELE9BQU9ELEdBQUEsQ0FBSU8sTUFBQSxDQUFPZixNQUFBLENBQU9LLGNBQUEsQ0FBZUssS0FBQSxFQUFPSSxLQUFLLENBQUM7SUFDdkQ7SUFDQSxPQUFPTixHQUFBO0VBQ1QsR0FBRyxFQUFFLEVBQ0pRLElBQUEsQ0FBS1osU0FBUztFQUVqQixPQUFPRSxNQUFBO0FBQ1Q7QUFHQSxJQUFPVyxzQkFBQSxHQUFRL0IsY0FBQTs7O0FIcEdmLElBQU9ELDRCQUFBLEdBQVFnQyxzQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==