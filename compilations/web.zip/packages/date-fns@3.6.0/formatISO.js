System.register(["date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/formatISO.3.6.0.js
var formatISO_3_6_0_exports = {};
__export(formatISO_3_6_0_exports, {
  default: () => formatISO_3_6_0_default,
  formatISO: () => formatISO
});
module.exports = __toCommonJS(formatISO_3_6_0_exports);

// node_modules/date-fns/_lib/addLeadingZeros.mjs
function addLeadingZeros(number, targetLength) {
  const sign = number < 0 ? "-" : "";
  const output = Math.abs(number).toString().padStart(targetLength, "0");
  return sign + output;
}

// node_modules/date-fns/formatISO.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function formatISO(date, options) {
  const _date = (0, import_toDate.toDate)(date);
  if (isNaN(_date.getTime())) {
    throw new RangeError("Invalid time value");
  }
  const format = options?.format ?? "extended";
  const representation = options?.representation ?? "complete";
  let result = "";
  let tzOffset = "";
  const dateDelimiter = format === "extended" ? "-" : "";
  const timeDelimiter = format === "extended" ? ":" : "";
  if (representation !== "time") {
    const day = addLeadingZeros(_date.getDate(), 2);
    const month = addLeadingZeros(_date.getMonth() + 1, 2);
    const year = addLeadingZeros(_date.getFullYear(), 4);
    result = `${year}${dateDelimiter}${month}${dateDelimiter}${day}`;
  }
  if (representation !== "date") {
    const offset = _date.getTimezoneOffset();
    if (offset !== 0) {
      const absoluteOffset = Math.abs(offset);
      const hourOffset = addLeadingZeros(Math.trunc(absoluteOffset / 60), 2);
      const minuteOffset = addLeadingZeros(absoluteOffset % 60, 2);
      const sign = offset < 0 ? "+" : "-";
      tzOffset = `${sign}${hourOffset}:${minuteOffset}`;
    } else {
      tzOffset = "Z";
    }
    const hour = addLeadingZeros(_date.getHours(), 2);
    const minute = addLeadingZeros(_date.getMinutes(), 2);
    const second = addLeadingZeros(_date.getSeconds(), 2);
    const separator = result === "" ? "" : "T";
    const time = [hour, minute, second].join(timeDelimiter);
    result = `${result}${separator}${time}${tzOffset}`;
  }
  return result;
}
var formatISO_default = formatISO;

// .beyond/uimport/temp/date-fns/formatISO.3.6.0.js
var formatISO_3_6_0_default = formatISO_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2Zvcm1hdElTTy4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9fbGliL2FkZExlYWRpbmdaZXJvcy5tanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvZm9ybWF0SVNPLm1qcyJdLCJuYW1lcyI6WyJmb3JtYXRJU09fM182XzBfZXhwb3J0cyIsIl9fZXhwb3J0IiwiZGVmYXVsdCIsImZvcm1hdElTT18zXzZfMF9kZWZhdWx0IiwiZm9ybWF0SVNPIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImFkZExlYWRpbmdaZXJvcyIsIm51bWJlciIsInRhcmdldExlbmd0aCIsInNpZ24iLCJvdXRwdXQiLCJNYXRoIiwiYWJzIiwidG9TdHJpbmciLCJwYWRTdGFydCIsImltcG9ydF90b0RhdGUiLCJyZXF1aXJlIiwiZGF0ZSIsIm9wdGlvbnMiLCJfZGF0ZSIsInRvRGF0ZSIsImlzTmFOIiwiZ2V0VGltZSIsIlJhbmdlRXJyb3IiLCJmb3JtYXQiLCJyZXByZXNlbnRhdGlvbiIsInJlc3VsdCIsInR6T2Zmc2V0IiwiZGF0ZURlbGltaXRlciIsInRpbWVEZWxpbWl0ZXIiLCJkYXkiLCJnZXREYXRlIiwibW9udGgiLCJnZXRNb250aCIsInllYXIiLCJnZXRGdWxsWWVhciIsIm9mZnNldCIsImdldFRpbWV6b25lT2Zmc2V0IiwiYWJzb2x1dGVPZmZzZXQiLCJob3VyT2Zmc2V0IiwidHJ1bmMiLCJtaW51dGVPZmZzZXQiLCJob3VyIiwiZ2V0SG91cnMiLCJtaW51dGUiLCJnZXRNaW51dGVzIiwic2Vjb25kIiwiZ2V0U2Vjb25kcyIsInNlcGFyYXRvciIsInRpbWUiLCJqb2luIiwiZm9ybWF0SVNPX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLHVCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsdUJBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLHVCQUFBO0VBQUFDLFNBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLHVCQUFBOzs7QUNBTyxTQUFTUSxnQkFBZ0JDLE1BQUEsRUFBUUMsWUFBQSxFQUFjO0VBQ3BELE1BQU1DLElBQUEsR0FBT0YsTUFBQSxHQUFTLElBQUksTUFBTTtFQUNoQyxNQUFNRyxNQUFBLEdBQVNDLElBQUEsQ0FBS0MsR0FBQSxDQUFJTCxNQUFNLEVBQUVNLFFBQUEsQ0FBUyxFQUFFQyxRQUFBLENBQVNOLFlBQUEsRUFBYyxHQUFHO0VBQ3JFLE9BQU9DLElBQUEsR0FBT0MsTUFBQTtBQUNoQjs7O0FDSkEsSUFBQUssYUFBQSxHQUF1QkMsT0FBQTtBQTRDaEIsU0FBU2QsVUFBVWUsSUFBQSxFQUFNQyxPQUFBLEVBQVM7RUFDdkMsTUFBTUMsS0FBQSxPQUFRSixhQUFBLENBQUFLLE1BQUEsRUFBT0gsSUFBSTtFQUV6QixJQUFJSSxLQUFBLENBQU1GLEtBQUEsQ0FBTUcsT0FBQSxDQUFRLENBQUMsR0FBRztJQUMxQixNQUFNLElBQUlDLFVBQUEsQ0FBVyxvQkFBb0I7RUFDM0M7RUFFQSxNQUFNQyxNQUFBLEdBQVNOLE9BQUEsRUFBU00sTUFBQSxJQUFVO0VBQ2xDLE1BQU1DLGNBQUEsR0FBaUJQLE9BQUEsRUFBU08sY0FBQSxJQUFrQjtFQUVsRCxJQUFJQyxNQUFBLEdBQVM7RUFDYixJQUFJQyxRQUFBLEdBQVc7RUFFZixNQUFNQyxhQUFBLEdBQWdCSixNQUFBLEtBQVcsYUFBYSxNQUFNO0VBQ3BELE1BQU1LLGFBQUEsR0FBZ0JMLE1BQUEsS0FBVyxhQUFhLE1BQU07RUFHcEQsSUFBSUMsY0FBQSxLQUFtQixRQUFRO0lBQzdCLE1BQU1LLEdBQUEsR0FBTXhCLGVBQUEsQ0FBZ0JhLEtBQUEsQ0FBTVksT0FBQSxDQUFRLEdBQUcsQ0FBQztJQUM5QyxNQUFNQyxLQUFBLEdBQVExQixlQUFBLENBQWdCYSxLQUFBLENBQU1jLFFBQUEsQ0FBUyxJQUFJLEdBQUcsQ0FBQztJQUNyRCxNQUFNQyxJQUFBLEdBQU81QixlQUFBLENBQWdCYSxLQUFBLENBQU1nQixXQUFBLENBQVksR0FBRyxDQUFDO0lBR25EVCxNQUFBLEdBQVMsR0FBR1EsSUFBQSxHQUFPTixhQUFBLEdBQWdCSSxLQUFBLEdBQVFKLGFBQUEsR0FBZ0JFLEdBQUE7RUFDN0Q7RUFHQSxJQUFJTCxjQUFBLEtBQW1CLFFBQVE7SUFFN0IsTUFBTVcsTUFBQSxHQUFTakIsS0FBQSxDQUFNa0IsaUJBQUEsQ0FBa0I7SUFFdkMsSUFBSUQsTUFBQSxLQUFXLEdBQUc7TUFDaEIsTUFBTUUsY0FBQSxHQUFpQjNCLElBQUEsQ0FBS0MsR0FBQSxDQUFJd0IsTUFBTTtNQUN0QyxNQUFNRyxVQUFBLEdBQWFqQyxlQUFBLENBQWdCSyxJQUFBLENBQUs2QixLQUFBLENBQU1GLGNBQUEsR0FBaUIsRUFBRSxHQUFHLENBQUM7TUFDckUsTUFBTUcsWUFBQSxHQUFlbkMsZUFBQSxDQUFnQmdDLGNBQUEsR0FBaUIsSUFBSSxDQUFDO01BRTNELE1BQU03QixJQUFBLEdBQU8yQixNQUFBLEdBQVMsSUFBSSxNQUFNO01BRWhDVCxRQUFBLEdBQVcsR0FBR2xCLElBQUEsR0FBTzhCLFVBQUEsSUFBY0UsWUFBQTtJQUNyQyxPQUFPO01BQ0xkLFFBQUEsR0FBVztJQUNiO0lBRUEsTUFBTWUsSUFBQSxHQUFPcEMsZUFBQSxDQUFnQmEsS0FBQSxDQUFNd0IsUUFBQSxDQUFTLEdBQUcsQ0FBQztJQUNoRCxNQUFNQyxNQUFBLEdBQVN0QyxlQUFBLENBQWdCYSxLQUFBLENBQU0wQixVQUFBLENBQVcsR0FBRyxDQUFDO0lBQ3BELE1BQU1DLE1BQUEsR0FBU3hDLGVBQUEsQ0FBZ0JhLEtBQUEsQ0FBTTRCLFVBQUEsQ0FBVyxHQUFHLENBQUM7SUFHcEQsTUFBTUMsU0FBQSxHQUFZdEIsTUFBQSxLQUFXLEtBQUssS0FBSztJQUd2QyxNQUFNdUIsSUFBQSxHQUFPLENBQUNQLElBQUEsRUFBTUUsTUFBQSxFQUFRRSxNQUFNLEVBQUVJLElBQUEsQ0FBS3JCLGFBQWE7SUFHdERILE1BQUEsR0FBUyxHQUFHQSxNQUFBLEdBQVNzQixTQUFBLEdBQVlDLElBQUEsR0FBT3RCLFFBQUE7RUFDMUM7RUFFQSxPQUFPRCxNQUFBO0FBQ1Q7QUFHQSxJQUFPeUIsaUJBQUEsR0FBUWpELFNBQUE7OztBRnRHZixJQUFPRCx1QkFBQSxHQUFRa0QsaUJBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=