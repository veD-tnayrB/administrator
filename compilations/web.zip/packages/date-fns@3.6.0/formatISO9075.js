System.register(["date-fns@3.6.0/isDate","date-fns@3.6.0/toDate","date-fns@3.6.0/isValid"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/isDate', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/isValid', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/formatISO9075.3.6.0.js
var formatISO9075_3_6_0_exports = {};
__export(formatISO9075_3_6_0_exports, {
  default: () => formatISO9075_3_6_0_default,
  formatISO9075: () => formatISO9075
});
module.exports = __toCommonJS(formatISO9075_3_6_0_exports);

// node_modules/date-fns/_lib/addLeadingZeros.mjs
function addLeadingZeros(number, targetLength) {
  const sign = number < 0 ? "-" : "";
  const output = Math.abs(number).toString().padStart(targetLength, "0");
  return sign + output;
}

// node_modules/date-fns/formatISO9075.mjs
var import_isValid = require("date-fns@3.6.0/isValid");
var import_toDate = require("date-fns@3.6.0/toDate");
function formatISO9075(date, options) {
  const _date = (0, import_toDate.toDate)(date);
  if (!(0, import_isValid.isValid)(_date)) {
    throw new RangeError("Invalid time value");
  }
  const format = options?.format ?? "extended";
  const representation = options?.representation ?? "complete";
  let result = "";
  const dateDelimiter = format === "extended" ? "-" : "";
  const timeDelimiter = format === "extended" ? ":" : "";
  if (representation !== "time") {
    const day = addLeadingZeros(_date.getDate(), 2);
    const month = addLeadingZeros(_date.getMonth() + 1, 2);
    const year = addLeadingZeros(_date.getFullYear(), 4);
    result = `${year}${dateDelimiter}${month}${dateDelimiter}${day}`;
  }
  if (representation !== "date") {
    const hour = addLeadingZeros(_date.getHours(), 2);
    const minute = addLeadingZeros(_date.getMinutes(), 2);
    const second = addLeadingZeros(_date.getSeconds(), 2);
    const separator = result === "" ? "" : " ";
    result = `${result}${separator}${hour}${timeDelimiter}${minute}${timeDelimiter}${second}`;
  }
  return result;
}
var formatISO9075_default = formatISO9075;

// .beyond/uimport/temp/date-fns/formatISO9075.3.6.0.js
var formatISO9075_3_6_0_default = formatISO9075_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2Zvcm1hdElTTzkwNzUuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvX2xpYi9hZGRMZWFkaW5nWmVyb3MubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2Zvcm1hdElTTzkwNzUubWpzIl0sIm5hbWVzIjpbImZvcm1hdElTTzkwNzVfM182XzBfZXhwb3J0cyIsIl9fZXhwb3J0IiwiZGVmYXVsdCIsImZvcm1hdElTTzkwNzVfM182XzBfZGVmYXVsdCIsImZvcm1hdElTTzkwNzUiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiYWRkTGVhZGluZ1plcm9zIiwibnVtYmVyIiwidGFyZ2V0TGVuZ3RoIiwic2lnbiIsIm91dHB1dCIsIk1hdGgiLCJhYnMiLCJ0b1N0cmluZyIsInBhZFN0YXJ0IiwiaW1wb3J0X2lzVmFsaWQiLCJyZXF1aXJlIiwiaW1wb3J0X3RvRGF0ZSIsImRhdGUiLCJvcHRpb25zIiwiX2RhdGUiLCJ0b0RhdGUiLCJpc1ZhbGlkIiwiUmFuZ2VFcnJvciIsImZvcm1hdCIsInJlcHJlc2VudGF0aW9uIiwicmVzdWx0IiwiZGF0ZURlbGltaXRlciIsInRpbWVEZWxpbWl0ZXIiLCJkYXkiLCJnZXREYXRlIiwibW9udGgiLCJnZXRNb250aCIsInllYXIiLCJnZXRGdWxsWWVhciIsImhvdXIiLCJnZXRIb3VycyIsIm1pbnV0ZSIsImdldE1pbnV0ZXMiLCJzZWNvbmQiLCJnZXRTZWNvbmRzIiwic2VwYXJhdG9yIiwiZm9ybWF0SVNPOTA3NV9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSwyQkFBQTtBQUFBQyxRQUFBLENBQUFELDJCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQywyQkFBQTtFQUFBQyxhQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCwyQkFBQTs7O0FDQU8sU0FBU1EsZ0JBQWdCQyxNQUFBLEVBQVFDLFlBQUEsRUFBYztFQUNwRCxNQUFNQyxJQUFBLEdBQU9GLE1BQUEsR0FBUyxJQUFJLE1BQU07RUFDaEMsTUFBTUcsTUFBQSxHQUFTQyxJQUFBLENBQUtDLEdBQUEsQ0FBSUwsTUFBTSxFQUFFTSxRQUFBLENBQVMsRUFBRUMsUUFBQSxDQUFTTixZQUFBLEVBQWMsR0FBRztFQUNyRSxPQUFPQyxJQUFBLEdBQU9DLE1BQUE7QUFDaEI7OztBQ0pBLElBQUFLLGNBQUEsR0FBd0JDLE9BQUE7QUFDeEIsSUFBQUMsYUFBQSxHQUF1QkQsT0FBQTtBQTRDaEIsU0FBU2QsY0FBY2dCLElBQUEsRUFBTUMsT0FBQSxFQUFTO0VBQzNDLE1BQU1DLEtBQUEsT0FBUUgsYUFBQSxDQUFBSSxNQUFBLEVBQU9ILElBQUk7RUFFekIsSUFBSSxLQUFDSCxjQUFBLENBQUFPLE9BQUEsRUFBUUYsS0FBSyxHQUFHO0lBQ25CLE1BQU0sSUFBSUcsVUFBQSxDQUFXLG9CQUFvQjtFQUMzQztFQUVBLE1BQU1DLE1BQUEsR0FBU0wsT0FBQSxFQUFTSyxNQUFBLElBQVU7RUFDbEMsTUFBTUMsY0FBQSxHQUFpQk4sT0FBQSxFQUFTTSxjQUFBLElBQWtCO0VBRWxELElBQUlDLE1BQUEsR0FBUztFQUViLE1BQU1DLGFBQUEsR0FBZ0JILE1BQUEsS0FBVyxhQUFhLE1BQU07RUFDcEQsTUFBTUksYUFBQSxHQUFnQkosTUFBQSxLQUFXLGFBQWEsTUFBTTtFQUdwRCxJQUFJQyxjQUFBLEtBQW1CLFFBQVE7SUFDN0IsTUFBTUksR0FBQSxHQUFNdkIsZUFBQSxDQUFnQmMsS0FBQSxDQUFNVSxPQUFBLENBQVEsR0FBRyxDQUFDO0lBQzlDLE1BQU1DLEtBQUEsR0FBUXpCLGVBQUEsQ0FBZ0JjLEtBQUEsQ0FBTVksUUFBQSxDQUFTLElBQUksR0FBRyxDQUFDO0lBQ3JELE1BQU1DLElBQUEsR0FBTzNCLGVBQUEsQ0FBZ0JjLEtBQUEsQ0FBTWMsV0FBQSxDQUFZLEdBQUcsQ0FBQztJQUduRFIsTUFBQSxHQUFTLEdBQUdPLElBQUEsR0FBT04sYUFBQSxHQUFnQkksS0FBQSxHQUFRSixhQUFBLEdBQWdCRSxHQUFBO0VBQzdEO0VBR0EsSUFBSUosY0FBQSxLQUFtQixRQUFRO0lBQzdCLE1BQU1VLElBQUEsR0FBTzdCLGVBQUEsQ0FBZ0JjLEtBQUEsQ0FBTWdCLFFBQUEsQ0FBUyxHQUFHLENBQUM7SUFDaEQsTUFBTUMsTUFBQSxHQUFTL0IsZUFBQSxDQUFnQmMsS0FBQSxDQUFNa0IsVUFBQSxDQUFXLEdBQUcsQ0FBQztJQUNwRCxNQUFNQyxNQUFBLEdBQVNqQyxlQUFBLENBQWdCYyxLQUFBLENBQU1vQixVQUFBLENBQVcsR0FBRyxDQUFDO0lBR3BELE1BQU1DLFNBQUEsR0FBWWYsTUFBQSxLQUFXLEtBQUssS0FBSztJQUd2Q0EsTUFBQSxHQUFTLEdBQUdBLE1BQUEsR0FBU2UsU0FBQSxHQUFZTixJQUFBLEdBQU9QLGFBQUEsR0FBZ0JTLE1BQUEsR0FBU1QsYUFBQSxHQUFnQlcsTUFBQTtFQUNuRjtFQUVBLE9BQU9iLE1BQUE7QUFDVDtBQUdBLElBQU9nQixxQkFBQSxHQUFReEMsYUFBQTs7O0FGcEZmLElBQU9ELDJCQUFBLEdBQVF5QyxxQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==