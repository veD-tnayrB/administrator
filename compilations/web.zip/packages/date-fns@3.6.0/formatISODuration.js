System.register([], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/formatISODuration.3.6.0.js
var formatISODuration_3_6_0_exports = {};
__export(formatISODuration_3_6_0_exports, {
  default: () => formatISODuration_3_6_0_default,
  formatISODuration: () => formatISODuration
});
module.exports = __toCommonJS(formatISODuration_3_6_0_exports);

// node_modules/date-fns/formatISODuration.mjs
function formatISODuration(duration) {
  const {
    years = 0,
    months = 0,
    days = 0,
    hours = 0,
    minutes = 0,
    seconds = 0
  } = duration;
  return `P${years}Y${months}M${days}DT${hours}H${minutes}M${seconds}S`;
}
var formatISODuration_default = formatISODuration;

// .beyond/uimport/temp/date-fns/formatISODuration.3.6.0.js
var formatISODuration_3_6_0_default = formatISODuration_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2Zvcm1hdElTT0R1cmF0aW9uLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2Zvcm1hdElTT0R1cmF0aW9uLm1qcyJdLCJuYW1lcyI6WyJmb3JtYXRJU09EdXJhdGlvbl8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZm9ybWF0SVNPRHVyYXRpb25fM182XzBfZGVmYXVsdCIsImZvcm1hdElTT0R1cmF0aW9uIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImR1cmF0aW9uIiwieWVhcnMiLCJtb250aHMiLCJkYXlzIiwiaG91cnMiLCJtaW51dGVzIiwic2Vjb25kcyIsImZvcm1hdElTT0R1cmF0aW9uX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLCtCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsK0JBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLCtCQUFBO0VBQUFDLGlCQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCwrQkFBQTs7O0FDd0JPLFNBQVNJLGtCQUFrQkksUUFBQSxFQUFVO0VBQzFDLE1BQU07SUFDSkMsS0FBQSxHQUFRO0lBQ1JDLE1BQUEsR0FBUztJQUNUQyxJQUFBLEdBQU87SUFDUEMsS0FBQSxHQUFRO0lBQ1JDLE9BQUEsR0FBVTtJQUNWQyxPQUFBLEdBQVU7RUFDWixJQUFJTixRQUFBO0VBRUosT0FBTyxJQUFJQyxLQUFBLElBQVNDLE1BQUEsSUFBVUMsSUFBQSxLQUFTQyxLQUFBLElBQVNDLE9BQUEsSUFBV0MsT0FBQTtBQUM3RDtBQUdBLElBQU9DLHlCQUFBLEdBQVFYLGlCQUFBOzs7QURuQ2YsSUFBT0QsK0JBQUEsR0FBUVkseUJBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=