System.register(["date-fns@3.6.0/isDate","date-fns@3.6.0/toDate","date-fns@3.6.0/isValid"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/isDate', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/isValid', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/formatRFC3339.3.6.0.js
var formatRFC3339_3_6_0_exports = {};
__export(formatRFC3339_3_6_0_exports, {
  default: () => formatRFC3339_3_6_0_default,
  formatRFC3339: () => formatRFC3339
});
module.exports = __toCommonJS(formatRFC3339_3_6_0_exports);

// node_modules/date-fns/_lib/addLeadingZeros.mjs
function addLeadingZeros(number, targetLength) {
  const sign = number < 0 ? "-" : "";
  const output = Math.abs(number).toString().padStart(targetLength, "0");
  return sign + output;
}

// node_modules/date-fns/formatRFC3339.mjs
var import_isValid = require("date-fns@3.6.0/isValid");
var import_toDate = require("date-fns@3.6.0/toDate");
function formatRFC3339(date, options) {
  const _date = (0, import_toDate.toDate)(date);
  if (!(0, import_isValid.isValid)(_date)) {
    throw new RangeError("Invalid time value");
  }
  const fractionDigits = options?.fractionDigits ?? 0;
  const day = addLeadingZeros(_date.getDate(), 2);
  const month = addLeadingZeros(_date.getMonth() + 1, 2);
  const year = _date.getFullYear();
  const hour = addLeadingZeros(_date.getHours(), 2);
  const minute = addLeadingZeros(_date.getMinutes(), 2);
  const second = addLeadingZeros(_date.getSeconds(), 2);
  let fractionalSecond = "";
  if (fractionDigits > 0) {
    const milliseconds = _date.getMilliseconds();
    const fractionalSeconds = Math.trunc(milliseconds * Math.pow(10, fractionDigits - 3));
    fractionalSecond = "." + addLeadingZeros(fractionalSeconds, fractionDigits);
  }
  let offset = "";
  const tzOffset = _date.getTimezoneOffset();
  if (tzOffset !== 0) {
    const absoluteOffset = Math.abs(tzOffset);
    const hourOffset = addLeadingZeros(Math.trunc(absoluteOffset / 60), 2);
    const minuteOffset = addLeadingZeros(absoluteOffset % 60, 2);
    const sign = tzOffset < 0 ? "+" : "-";
    offset = `${sign}${hourOffset}:${minuteOffset}`;
  } else {
    offset = "Z";
  }
  return `${year}-${month}-${day}T${hour}:${minute}:${second}${fractionalSecond}${offset}`;
}
var formatRFC3339_default = formatRFC3339;

// .beyond/uimport/temp/date-fns/formatRFC3339.3.6.0.js
var formatRFC3339_3_6_0_default = formatRFC3339_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2Zvcm1hdFJGQzMzMzkuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvX2xpYi9hZGRMZWFkaW5nWmVyb3MubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2Zvcm1hdFJGQzMzMzkubWpzIl0sIm5hbWVzIjpbImZvcm1hdFJGQzMzMzlfM182XzBfZXhwb3J0cyIsIl9fZXhwb3J0IiwiZGVmYXVsdCIsImZvcm1hdFJGQzMzMzlfM182XzBfZGVmYXVsdCIsImZvcm1hdFJGQzMzMzkiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiYWRkTGVhZGluZ1plcm9zIiwibnVtYmVyIiwidGFyZ2V0TGVuZ3RoIiwic2lnbiIsIm91dHB1dCIsIk1hdGgiLCJhYnMiLCJ0b1N0cmluZyIsInBhZFN0YXJ0IiwiaW1wb3J0X2lzVmFsaWQiLCJyZXF1aXJlIiwiaW1wb3J0X3RvRGF0ZSIsImRhdGUiLCJvcHRpb25zIiwiX2RhdGUiLCJ0b0RhdGUiLCJpc1ZhbGlkIiwiUmFuZ2VFcnJvciIsImZyYWN0aW9uRGlnaXRzIiwiZGF5IiwiZ2V0RGF0ZSIsIm1vbnRoIiwiZ2V0TW9udGgiLCJ5ZWFyIiwiZ2V0RnVsbFllYXIiLCJob3VyIiwiZ2V0SG91cnMiLCJtaW51dGUiLCJnZXRNaW51dGVzIiwic2Vjb25kIiwiZ2V0U2Vjb25kcyIsImZyYWN0aW9uYWxTZWNvbmQiLCJtaWxsaXNlY29uZHMiLCJnZXRNaWxsaXNlY29uZHMiLCJmcmFjdGlvbmFsU2Vjb25kcyIsInRydW5jIiwicG93Iiwib2Zmc2V0IiwidHpPZmZzZXQiLCJnZXRUaW1lem9uZU9mZnNldCIsImFic29sdXRlT2Zmc2V0IiwiaG91ck9mZnNldCIsIm1pbnV0ZU9mZnNldCIsImZvcm1hdFJGQzMzMzlfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsMkJBQUE7QUFBQUMsUUFBQSxDQUFBRCwyQkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsMkJBQUE7RUFBQUMsYUFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsMkJBQUE7OztBQ0FPLFNBQVNRLGdCQUFnQkMsTUFBQSxFQUFRQyxZQUFBLEVBQWM7RUFDcEQsTUFBTUMsSUFBQSxHQUFPRixNQUFBLEdBQVMsSUFBSSxNQUFNO0VBQ2hDLE1BQU1HLE1BQUEsR0FBU0MsSUFBQSxDQUFLQyxHQUFBLENBQUlMLE1BQU0sRUFBRU0sUUFBQSxDQUFTLEVBQUVDLFFBQUEsQ0FBU04sWUFBQSxFQUFjLEdBQUc7RUFDckUsT0FBT0MsSUFBQSxHQUFPQyxNQUFBO0FBQ2hCOzs7QUNKQSxJQUFBSyxjQUFBLEdBQXdCQyxPQUFBO0FBQ3hCLElBQUFDLGFBQUEsR0FBdUJELE9BQUE7QUFvQ2hCLFNBQVNkLGNBQWNnQixJQUFBLEVBQU1DLE9BQUEsRUFBUztFQUMzQyxNQUFNQyxLQUFBLE9BQVFILGFBQUEsQ0FBQUksTUFBQSxFQUFPSCxJQUFJO0VBRXpCLElBQUksS0FBQ0gsY0FBQSxDQUFBTyxPQUFBLEVBQVFGLEtBQUssR0FBRztJQUNuQixNQUFNLElBQUlHLFVBQUEsQ0FBVyxvQkFBb0I7RUFDM0M7RUFFQSxNQUFNQyxjQUFBLEdBQWlCTCxPQUFBLEVBQVNLLGNBQUEsSUFBa0I7RUFFbEQsTUFBTUMsR0FBQSxHQUFNbkIsZUFBQSxDQUFnQmMsS0FBQSxDQUFNTSxPQUFBLENBQVEsR0FBRyxDQUFDO0VBQzlDLE1BQU1DLEtBQUEsR0FBUXJCLGVBQUEsQ0FBZ0JjLEtBQUEsQ0FBTVEsUUFBQSxDQUFTLElBQUksR0FBRyxDQUFDO0VBQ3JELE1BQU1DLElBQUEsR0FBT1QsS0FBQSxDQUFNVSxXQUFBLENBQVk7RUFFL0IsTUFBTUMsSUFBQSxHQUFPekIsZUFBQSxDQUFnQmMsS0FBQSxDQUFNWSxRQUFBLENBQVMsR0FBRyxDQUFDO0VBQ2hELE1BQU1DLE1BQUEsR0FBUzNCLGVBQUEsQ0FBZ0JjLEtBQUEsQ0FBTWMsVUFBQSxDQUFXLEdBQUcsQ0FBQztFQUNwRCxNQUFNQyxNQUFBLEdBQVM3QixlQUFBLENBQWdCYyxLQUFBLENBQU1nQixVQUFBLENBQVcsR0FBRyxDQUFDO0VBRXBELElBQUlDLGdCQUFBLEdBQW1CO0VBQ3ZCLElBQUliLGNBQUEsR0FBaUIsR0FBRztJQUN0QixNQUFNYyxZQUFBLEdBQWVsQixLQUFBLENBQU1tQixlQUFBLENBQWdCO0lBQzNDLE1BQU1DLGlCQUFBLEdBQW9CN0IsSUFBQSxDQUFLOEIsS0FBQSxDQUM3QkgsWUFBQSxHQUFlM0IsSUFBQSxDQUFLK0IsR0FBQSxDQUFJLElBQUlsQixjQUFBLEdBQWlCLENBQUMsQ0FDaEQ7SUFDQWEsZ0JBQUEsR0FBbUIsTUFBTS9CLGVBQUEsQ0FBZ0JrQyxpQkFBQSxFQUFtQmhCLGNBQWM7RUFDNUU7RUFFQSxJQUFJbUIsTUFBQSxHQUFTO0VBQ2IsTUFBTUMsUUFBQSxHQUFXeEIsS0FBQSxDQUFNeUIsaUJBQUEsQ0FBa0I7RUFFekMsSUFBSUQsUUFBQSxLQUFhLEdBQUc7SUFDbEIsTUFBTUUsY0FBQSxHQUFpQm5DLElBQUEsQ0FBS0MsR0FBQSxDQUFJZ0MsUUFBUTtJQUN4QyxNQUFNRyxVQUFBLEdBQWF6QyxlQUFBLENBQWdCSyxJQUFBLENBQUs4QixLQUFBLENBQU1LLGNBQUEsR0FBaUIsRUFBRSxHQUFHLENBQUM7SUFDckUsTUFBTUUsWUFBQSxHQUFlMUMsZUFBQSxDQUFnQndDLGNBQUEsR0FBaUIsSUFBSSxDQUFDO0lBRTNELE1BQU1yQyxJQUFBLEdBQU9tQyxRQUFBLEdBQVcsSUFBSSxNQUFNO0lBRWxDRCxNQUFBLEdBQVMsR0FBR2xDLElBQUEsR0FBT3NDLFVBQUEsSUFBY0MsWUFBQTtFQUNuQyxPQUFPO0lBQ0xMLE1BQUEsR0FBUztFQUNYO0VBRUEsT0FBTyxHQUFHZCxJQUFBLElBQVFGLEtBQUEsSUFBU0YsR0FBQSxJQUFPTSxJQUFBLElBQVFFLE1BQUEsSUFBVUUsTUFBQSxHQUFTRSxnQkFBQSxHQUFtQk0sTUFBQTtBQUNsRjtBQUdBLElBQU9NLHFCQUFBLEdBQVEvQyxhQUFBOzs7QUYvRWYsSUFBT0QsMkJBQUEsR0FBUWdELHFCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9