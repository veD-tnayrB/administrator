System.register(["date-fns@3.6.0/constants","date-fns@3.6.0/toDate","date-fns@3.6.0/startOfDay","date-fns@3.6.0/differenceInCalendarDays","date-fns@3.6.0/locale/en-US","date-fns@3.6.0/constructFrom","date-fns@3.6.0/startOfYear","date-fns@3.6.0/getDayOfYear","date-fns@3.6.0/startOfWeek","date-fns@3.6.0/startOfISOWeek","date-fns@3.6.0/getISOWeekYear","date-fns@3.6.0/startOfISOWeekYear","date-fns@3.6.0/getISOWeek","date-fns@3.6.0/getWeekYear","date-fns@3.6.0/startOfWeekYear","date-fns@3.6.0/getWeek","date-fns@3.6.0/isDate","date-fns@3.6.0/isValid","date-fns@3.6.0/format"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constants', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfDay', dep), dep => dependencies.set('date-fns@3.6.0/differenceInCalendarDays', dep), dep => dependencies.set('date-fns@3.6.0/locale/en-US', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/startOfYear', dep), dep => dependencies.set('date-fns@3.6.0/getDayOfYear', dep), dep => dependencies.set('date-fns@3.6.0/startOfWeek', dep), dep => dependencies.set('date-fns@3.6.0/startOfISOWeek', dep), dep => dependencies.set('date-fns@3.6.0/getISOWeekYear', dep), dep => dependencies.set('date-fns@3.6.0/startOfISOWeekYear', dep), dep => dependencies.set('date-fns@3.6.0/getISOWeek', dep), dep => dependencies.set('date-fns@3.6.0/getWeekYear', dep), dep => dependencies.set('date-fns@3.6.0/startOfWeekYear', dep), dep => dependencies.set('date-fns@3.6.0/getWeek', dep), dep => dependencies.set('date-fns@3.6.0/isDate', dep), dep => dependencies.set('date-fns@3.6.0/isValid', dep), dep => dependencies.set('date-fns@3.6.0/format', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/formatRelative.3.6.0.js
var formatRelative_3_6_0_exports = {};
__export(formatRelative_3_6_0_exports, {
  default: () => formatRelative_3_6_0_default,
  formatRelative: () => formatRelative
});
module.exports = __toCommonJS(formatRelative_3_6_0_exports);

// node_modules/date-fns/_lib/defaultLocale.mjs
var import_en_US = require("date-fns@3.6.0/locale/en-US");

// node_modules/date-fns/_lib/defaultOptions.mjs
var defaultOptions = {};
function getDefaultOptions() {
  return defaultOptions;
}
function setDefaultOptions(newOptions) {
  defaultOptions = newOptions;
}

// node_modules/date-fns/formatRelative.mjs
var import_differenceInCalendarDays = require("date-fns@3.6.0/differenceInCalendarDays");
var import_format = require("date-fns@3.6.0/format");
var import_toDate = require("date-fns@3.6.0/toDate");
function formatRelative(date, baseDate, options) {
  const _date = (0, import_toDate.toDate)(date);
  const _baseDate = (0, import_toDate.toDate)(baseDate);
  const defaultOptions2 = getDefaultOptions();
  const locale = options?.locale ?? defaultOptions2.locale ?? import_en_US.enUS;
  const weekStartsOn = options?.weekStartsOn ?? options?.locale?.options?.weekStartsOn ?? defaultOptions2.weekStartsOn ?? defaultOptions2.locale?.options?.weekStartsOn ?? 0;
  const diff = (0, import_differenceInCalendarDays.differenceInCalendarDays)(_date, _baseDate);
  if (isNaN(diff)) {
    throw new RangeError("Invalid time value");
  }
  let token;
  if (diff < -6) {
    token = "other";
  } else if (diff < -1) {
    token = "lastWeek";
  } else if (diff < 0) {
    token = "yesterday";
  } else if (diff < 1) {
    token = "today";
  } else if (diff < 2) {
    token = "tomorrow";
  } else if (diff < 7) {
    token = "nextWeek";
  } else {
    token = "other";
  }
  const formatStr = locale.formatRelative(token, _date, _baseDate, {
    locale,
    weekStartsOn
  });
  return (0, import_format.format)(_date, formatStr, {
    locale,
    weekStartsOn
  });
}
var formatRelative_default = formatRelative;

// .beyond/uimport/temp/date-fns/formatRelative.3.6.0.js
var formatRelative_3_6_0_default = formatRelative_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2Zvcm1hdFJlbGF0aXZlLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL19saWIvZGVmYXVsdExvY2FsZS5tanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvX2xpYi9kZWZhdWx0T3B0aW9ucy5tanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvZm9ybWF0UmVsYXRpdmUubWpzIl0sIm5hbWVzIjpbImZvcm1hdFJlbGF0aXZlXzNfNl8wX2V4cG9ydHMiLCJfX2V4cG9ydCIsImRlZmF1bHQiLCJmb3JtYXRSZWxhdGl2ZV8zXzZfMF9kZWZhdWx0IiwiZm9ybWF0UmVsYXRpdmUiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2VuX1VTIiwicmVxdWlyZSIsImRlZmF1bHRPcHRpb25zIiwiZ2V0RGVmYXVsdE9wdGlvbnMiLCJzZXREZWZhdWx0T3B0aW9ucyIsIm5ld09wdGlvbnMiLCJpbXBvcnRfZGlmZmVyZW5jZUluQ2FsZW5kYXJEYXlzIiwiaW1wb3J0X2Zvcm1hdCIsImltcG9ydF90b0RhdGUiLCJkYXRlIiwiYmFzZURhdGUiLCJvcHRpb25zIiwiX2RhdGUiLCJ0b0RhdGUiLCJfYmFzZURhdGUiLCJkZWZhdWx0T3B0aW9uczIiLCJsb2NhbGUiLCJlblVTIiwid2Vla1N0YXJ0c09uIiwiZGlmZiIsImRpZmZlcmVuY2VJbkNhbGVuZGFyRGF5cyIsImlzTmFOIiwiUmFuZ2VFcnJvciIsInRva2VuIiwiZm9ybWF0U3RyIiwiZm9ybWF0IiwiZm9ybWF0UmVsYXRpdmVfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsNEJBQUE7QUFBQUMsUUFBQSxDQUFBRCw0QkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsNEJBQUE7RUFBQUMsY0FBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsNEJBQUE7OztBQ0FBLElBQUFRLFlBQUEsR0FBc0NDLE9BQUE7OztBQ0F0QyxJQUFJQyxjQUFBLEdBQWlCLENBQUM7QUFFZixTQUFTQyxrQkFBQSxFQUFvQjtFQUNsQyxPQUFPRCxjQUFBO0FBQ1Q7QUFFTyxTQUFTRSxrQkFBa0JDLFVBQUEsRUFBWTtFQUM1Q0gsY0FBQSxHQUFpQkcsVUFBQTtBQUNuQjs7O0FDUkEsSUFBQUMsK0JBQUEsR0FBeUNMLE9BQUE7QUFDekMsSUFBQU0sYUFBQSxHQUF1Qk4sT0FBQTtBQUN2QixJQUFBTyxhQUFBLEdBQXVCUCxPQUFBO0FBNENoQixTQUFTTCxlQUFlYSxJQUFBLEVBQU1DLFFBQUEsRUFBVUMsT0FBQSxFQUFTO0VBQ3RELE1BQU1DLEtBQUEsT0FBUUosYUFBQSxDQUFBSyxNQUFBLEVBQU9KLElBQUk7RUFDekIsTUFBTUssU0FBQSxPQUFZTixhQUFBLENBQUFLLE1BQUEsRUFBT0gsUUFBUTtFQUVqQyxNQUFNSyxlQUFBLEdBQWlCWixpQkFBQSxDQUFrQjtFQUN6QyxNQUFNYSxNQUFBLEdBQVNMLE9BQUEsRUFBU0ssTUFBQSxJQUFVRCxlQUFBLENBQWVDLE1BQUEsSUFBVWhCLFlBQUEsQ0FBQWlCLElBQUE7RUFDM0QsTUFBTUMsWUFBQSxHQUNKUCxPQUFBLEVBQVNPLFlBQUEsSUFDVFAsT0FBQSxFQUFTSyxNQUFBLEVBQVFMLE9BQUEsRUFBU08sWUFBQSxJQUMxQkgsZUFBQSxDQUFlRyxZQUFBLElBQ2ZILGVBQUEsQ0FBZUMsTUFBQSxFQUFRTCxPQUFBLEVBQVNPLFlBQUEsSUFDaEM7RUFFRixNQUFNQyxJQUFBLE9BQU9iLCtCQUFBLENBQUFjLHdCQUFBLEVBQXlCUixLQUFBLEVBQU9FLFNBQVM7RUFFdEQsSUFBSU8sS0FBQSxDQUFNRixJQUFJLEdBQUc7SUFDZixNQUFNLElBQUlHLFVBQUEsQ0FBVyxvQkFBb0I7RUFDM0M7RUFFQSxJQUFJQyxLQUFBO0VBQ0osSUFBSUosSUFBQSxHQUFPLElBQUk7SUFDYkksS0FBQSxHQUFRO0VBQ1YsV0FBV0osSUFBQSxHQUFPLElBQUk7SUFDcEJJLEtBQUEsR0FBUTtFQUNWLFdBQVdKLElBQUEsR0FBTyxHQUFHO0lBQ25CSSxLQUFBLEdBQVE7RUFDVixXQUFXSixJQUFBLEdBQU8sR0FBRztJQUNuQkksS0FBQSxHQUFRO0VBQ1YsV0FBV0osSUFBQSxHQUFPLEdBQUc7SUFDbkJJLEtBQUEsR0FBUTtFQUNWLFdBQVdKLElBQUEsR0FBTyxHQUFHO0lBQ25CSSxLQUFBLEdBQVE7RUFDVixPQUFPO0lBQ0xBLEtBQUEsR0FBUTtFQUNWO0VBRUEsTUFBTUMsU0FBQSxHQUFZUixNQUFBLENBQU9wQixjQUFBLENBQWUyQixLQUFBLEVBQU9YLEtBQUEsRUFBT0UsU0FBQSxFQUFXO0lBQy9ERSxNQUFBO0lBQ0FFO0VBQ0YsQ0FBQztFQUNELFdBQU9YLGFBQUEsQ0FBQWtCLE1BQUEsRUFBT2IsS0FBQSxFQUFPWSxTQUFBLEVBQVc7SUFBRVIsTUFBQTtJQUFRRTtFQUFhLENBQUM7QUFDMUQ7QUFHQSxJQUFPUSxzQkFBQSxHQUFROUIsY0FBQTs7O0FIdkZmLElBQU9ELDRCQUFBLEdBQVErQixzQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==