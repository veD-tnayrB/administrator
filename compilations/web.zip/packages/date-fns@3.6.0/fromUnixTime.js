System.register(["date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/fromUnixTime.3.6.0.js
var fromUnixTime_3_6_0_exports = {};
__export(fromUnixTime_3_6_0_exports, {
  default: () => fromUnixTime_3_6_0_default,
  fromUnixTime: () => fromUnixTime
});
module.exports = __toCommonJS(fromUnixTime_3_6_0_exports);

// node_modules/date-fns/fromUnixTime.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function fromUnixTime(unixTime) {
  return (0, import_toDate.toDate)(unixTime * 1e3);
}
var fromUnixTime_default = fromUnixTime;

// .beyond/uimport/temp/date-fns/fromUnixTime.3.6.0.js
var fromUnixTime_3_6_0_default = fromUnixTime_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2Zyb21Vbml4VGltZS4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9mcm9tVW5peFRpbWUubWpzIl0sIm5hbWVzIjpbImZyb21Vbml4VGltZV8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZnJvbVVuaXhUaW1lXzNfNl8wX2RlZmF1bHQiLCJmcm9tVW5peFRpbWUiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X3RvRGF0ZSIsInJlcXVpcmUiLCJ1bml4VGltZSIsInRvRGF0ZSIsImZyb21Vbml4VGltZV9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSwwQkFBQTtBQUFBQyxRQUFBLENBQUFELDBCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQywwQkFBQTtFQUFBQyxZQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCwwQkFBQTs7O0FDQUEsSUFBQVEsYUFBQSxHQUF1QkMsT0FBQTtBQW1CaEIsU0FBU0wsYUFBYU0sUUFBQSxFQUFVO0VBQ3JDLFdBQU9GLGFBQUEsQ0FBQUcsTUFBQSxFQUFPRCxRQUFBLEdBQVcsR0FBSTtBQUMvQjtBQUdBLElBQU9FLG9CQUFBLEdBQVFSLFlBQUE7OztBRHJCZixJQUFPRCwwQkFBQSxHQUFRUyxvQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==