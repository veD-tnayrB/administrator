System.register(["date-fns@3.6.0/constants","date-fns@3.6.0/toDate","date-fns@3.6.0/startOfDay","date-fns@3.6.0/differenceInCalendarDays","date-fns@3.6.0/constructFrom","date-fns@3.6.0/startOfYear"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constants', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfDay', dep), dep => dependencies.set('date-fns@3.6.0/differenceInCalendarDays', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/startOfYear', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/getDayOfYear.3.6.0.js
var getDayOfYear_3_6_0_exports = {};
__export(getDayOfYear_3_6_0_exports, {
  default: () => getDayOfYear_3_6_0_default,
  getDayOfYear: () => getDayOfYear
});
module.exports = __toCommonJS(getDayOfYear_3_6_0_exports);

// node_modules/date-fns/getDayOfYear.mjs
var import_differenceInCalendarDays = require("date-fns@3.6.0/differenceInCalendarDays");
var import_startOfYear = require("date-fns@3.6.0/startOfYear");
var import_toDate = require("date-fns@3.6.0/toDate");
function getDayOfYear(date) {
  const _date = (0, import_toDate.toDate)(date);
  const diff = (0, import_differenceInCalendarDays.differenceInCalendarDays)(_date, (0, import_startOfYear.startOfYear)(_date));
  const dayOfYear = diff + 1;
  return dayOfYear;
}
var getDayOfYear_default = getDayOfYear;

// .beyond/uimport/temp/date-fns/getDayOfYear.3.6.0.js
var getDayOfYear_3_6_0_default = getDayOfYear_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2dldERheU9mWWVhci4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9nZXREYXlPZlllYXIubWpzIl0sIm5hbWVzIjpbImdldERheU9mWWVhcl8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZ2V0RGF5T2ZZZWFyXzNfNl8wX2RlZmF1bHQiLCJnZXREYXlPZlllYXIiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2RpZmZlcmVuY2VJbkNhbGVuZGFyRGF5cyIsInJlcXVpcmUiLCJpbXBvcnRfc3RhcnRPZlllYXIiLCJpbXBvcnRfdG9EYXRlIiwiZGF0ZSIsIl9kYXRlIiwidG9EYXRlIiwiZGlmZiIsImRpZmZlcmVuY2VJbkNhbGVuZGFyRGF5cyIsInN0YXJ0T2ZZZWFyIiwiZGF5T2ZZZWFyIiwiZ2V0RGF5T2ZZZWFyX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLDBCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsMEJBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLDBCQUFBO0VBQUFDLFlBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLDBCQUFBOzs7QUNBQSxJQUFBUSwrQkFBQSxHQUF5Q0MsT0FBQTtBQUN6QyxJQUFBQyxrQkFBQSxHQUE0QkQsT0FBQTtBQUM1QixJQUFBRSxhQUFBLEdBQXVCRixPQUFBO0FBcUJoQixTQUFTTCxhQUFhUSxJQUFBLEVBQU07RUFDakMsTUFBTUMsS0FBQSxPQUFRRixhQUFBLENBQUFHLE1BQUEsRUFBT0YsSUFBSTtFQUN6QixNQUFNRyxJQUFBLE9BQU9QLCtCQUFBLENBQUFRLHdCQUFBLEVBQXlCSCxLQUFBLE1BQU9ILGtCQUFBLENBQUFPLFdBQUEsRUFBWUosS0FBSyxDQUFDO0VBQy9ELE1BQU1LLFNBQUEsR0FBWUgsSUFBQSxHQUFPO0VBQ3pCLE9BQU9HLFNBQUE7QUFDVDtBQUdBLElBQU9DLG9CQUFBLEdBQVFmLFlBQUE7OztBRDVCZixJQUFPRCwwQkFBQSxHQUFRZ0Isb0JBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=