System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/constructFrom"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/getDaysInMonth.3.6.0.js
var getDaysInMonth_3_6_0_exports = {};
__export(getDaysInMonth_3_6_0_exports, {
  default: () => getDaysInMonth_3_6_0_default,
  getDaysInMonth: () => getDaysInMonth
});
module.exports = __toCommonJS(getDaysInMonth_3_6_0_exports);

// node_modules/date-fns/getDaysInMonth.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
var import_constructFrom = require("date-fns@3.6.0/constructFrom");
function getDaysInMonth(date) {
  const _date = (0, import_toDate.toDate)(date);
  const year = _date.getFullYear();
  const monthIndex = _date.getMonth();
  const lastDayOfMonth = (0, import_constructFrom.constructFrom)(date, 0);
  lastDayOfMonth.setFullYear(year, monthIndex + 1, 0);
  lastDayOfMonth.setHours(0, 0, 0, 0);
  return lastDayOfMonth.getDate();
}
var getDaysInMonth_default = getDaysInMonth;

// .beyond/uimport/temp/date-fns/getDaysInMonth.3.6.0.js
var getDaysInMonth_3_6_0_default = getDaysInMonth_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2dldERheXNJbk1vbnRoLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2dldERheXNJbk1vbnRoLm1qcyJdLCJuYW1lcyI6WyJnZXREYXlzSW5Nb250aF8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZ2V0RGF5c0luTW9udGhfM182XzBfZGVmYXVsdCIsImdldERheXNJbk1vbnRoIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF90b0RhdGUiLCJyZXF1aXJlIiwiaW1wb3J0X2NvbnN0cnVjdEZyb20iLCJkYXRlIiwiX2RhdGUiLCJ0b0RhdGUiLCJ5ZWFyIiwiZ2V0RnVsbFllYXIiLCJtb250aEluZGV4IiwiZ2V0TW9udGgiLCJsYXN0RGF5T2ZNb250aCIsImNvbnN0cnVjdEZyb20iLCJzZXRGdWxsWWVhciIsInNldEhvdXJzIiwiZ2V0RGF0ZSIsImdldERheXNJbk1vbnRoX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLDRCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsNEJBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLDRCQUFBO0VBQUFDLGNBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLDRCQUFBOzs7QUNBQSxJQUFBUSxhQUFBLEdBQXVCQyxPQUFBO0FBQ3ZCLElBQUFDLG9CQUFBLEdBQThCRCxPQUFBO0FBcUJ2QixTQUFTTCxlQUFlTyxJQUFBLEVBQU07RUFDbkMsTUFBTUMsS0FBQSxPQUFRSixhQUFBLENBQUFLLE1BQUEsRUFBT0YsSUFBSTtFQUN6QixNQUFNRyxJQUFBLEdBQU9GLEtBQUEsQ0FBTUcsV0FBQSxDQUFZO0VBQy9CLE1BQU1DLFVBQUEsR0FBYUosS0FBQSxDQUFNSyxRQUFBLENBQVM7RUFDbEMsTUFBTUMsY0FBQSxPQUFpQlIsb0JBQUEsQ0FBQVMsYUFBQSxFQUFjUixJQUFBLEVBQU0sQ0FBQztFQUM1Q08sY0FBQSxDQUFlRSxXQUFBLENBQVlOLElBQUEsRUFBTUUsVUFBQSxHQUFhLEdBQUcsQ0FBQztFQUNsREUsY0FBQSxDQUFlRyxRQUFBLENBQVMsR0FBRyxHQUFHLEdBQUcsQ0FBQztFQUNsQyxPQUFPSCxjQUFBLENBQWVJLE9BQUEsQ0FBUTtBQUNoQztBQUdBLElBQU9DLHNCQUFBLEdBQVFuQixjQUFBOzs7QUQ5QmYsSUFBT0QsNEJBQUEsR0FBUW9CLHNCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9