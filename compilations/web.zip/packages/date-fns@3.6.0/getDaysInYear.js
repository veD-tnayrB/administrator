System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/isLeapYear"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/isLeapYear', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/getDaysInYear.3.6.0.js
var getDaysInYear_3_6_0_exports = {};
__export(getDaysInYear_3_6_0_exports, {
  default: () => getDaysInYear_3_6_0_default,
  getDaysInYear: () => getDaysInYear
});
module.exports = __toCommonJS(getDaysInYear_3_6_0_exports);

// node_modules/date-fns/getDaysInYear.mjs
var import_isLeapYear = require("date-fns@3.6.0/isLeapYear");
var import_toDate = require("date-fns@3.6.0/toDate");
function getDaysInYear(date) {
  const _date = (0, import_toDate.toDate)(date);
  if (String(new Date(_date)) === "Invalid Date") {
    return NaN;
  }
  return (0, import_isLeapYear.isLeapYear)(_date) ? 366 : 365;
}
var getDaysInYear_default = getDaysInYear;

// .beyond/uimport/temp/date-fns/getDaysInYear.3.6.0.js
var getDaysInYear_3_6_0_default = getDaysInYear_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2dldERheXNJblllYXIuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvZ2V0RGF5c0luWWVhci5tanMiXSwibmFtZXMiOlsiZ2V0RGF5c0luWWVhcl8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZ2V0RGF5c0luWWVhcl8zXzZfMF9kZWZhdWx0IiwiZ2V0RGF5c0luWWVhciIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfaXNMZWFwWWVhciIsInJlcXVpcmUiLCJpbXBvcnRfdG9EYXRlIiwiZGF0ZSIsIl9kYXRlIiwidG9EYXRlIiwiU3RyaW5nIiwiRGF0ZSIsIk5hTiIsImlzTGVhcFllYXIiLCJnZXREYXlzSW5ZZWFyX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLDJCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsMkJBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLDJCQUFBO0VBQUFDLGFBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLDJCQUFBOzs7QUNBQSxJQUFBUSxpQkFBQSxHQUEyQkMsT0FBQTtBQUMzQixJQUFBQyxhQUFBLEdBQXVCRCxPQUFBO0FBcUJoQixTQUFTTCxjQUFjTyxJQUFBLEVBQU07RUFDbEMsTUFBTUMsS0FBQSxPQUFRRixhQUFBLENBQUFHLE1BQUEsRUFBT0YsSUFBSTtFQUV6QixJQUFJRyxNQUFBLENBQU8sSUFBSUMsSUFBQSxDQUFLSCxLQUFLLENBQUMsTUFBTSxnQkFBZ0I7SUFDOUMsT0FBT0ksR0FBQTtFQUNUO0VBRUEsV0FBT1IsaUJBQUEsQ0FBQVMsVUFBQSxFQUFXTCxLQUFLLElBQUksTUFBTTtBQUNuQztBQUdBLElBQU9NLHFCQUFBLEdBQVFkLGFBQUE7OztBRDlCZixJQUFPRCwyQkFBQSxHQUFRZSxxQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==