System.register([], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/getDefaultOptions.3.6.0.js
var getDefaultOptions_3_6_0_exports = {};
__export(getDefaultOptions_3_6_0_exports, {
  default: () => getDefaultOptions_3_6_0_default,
  getDefaultOptions: () => getDefaultOptions2
});
module.exports = __toCommonJS(getDefaultOptions_3_6_0_exports);

// node_modules/date-fns/_lib/defaultOptions.mjs
var defaultOptions = {};
function getDefaultOptions() {
  return defaultOptions;
}
function setDefaultOptions(newOptions) {
  defaultOptions = newOptions;
}

// node_modules/date-fns/getDefaultOptions.mjs
function getDefaultOptions2() {
  return Object.assign({}, getDefaultOptions());
}
var getDefaultOptions_default = getDefaultOptions2;

// .beyond/uimport/temp/date-fns/getDefaultOptions.3.6.0.js
var getDefaultOptions_3_6_0_default = getDefaultOptions_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2dldERlZmF1bHRPcHRpb25zLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL19saWIvZGVmYXVsdE9wdGlvbnMubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2dldERlZmF1bHRPcHRpb25zLm1qcyJdLCJuYW1lcyI6WyJnZXREZWZhdWx0T3B0aW9uc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZ2V0RGVmYXVsdE9wdGlvbnNfM182XzBfZGVmYXVsdCIsImdldERlZmF1bHRPcHRpb25zIiwiZ2V0RGVmYXVsdE9wdGlvbnMyIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImRlZmF1bHRPcHRpb25zIiwic2V0RGVmYXVsdE9wdGlvbnMiLCJuZXdPcHRpb25zIiwiT2JqZWN0IiwiYXNzaWduIiwiZ2V0RGVmYXVsdE9wdGlvbnNfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsK0JBQUE7QUFBQUMsUUFBQSxDQUFBRCwrQkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsK0JBQUE7RUFBQUMsaUJBQUEsRUFBQUEsQ0FBQSxLQUFBQztBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFSLCtCQUFBOzs7QUNBQSxJQUFJUyxjQUFBLEdBQWlCLENBQUM7QUFFZixTQUFTTCxrQkFBQSxFQUFvQjtFQUNsQyxPQUFPSyxjQUFBO0FBQ1Q7QUFFTyxTQUFTQyxrQkFBa0JDLFVBQUEsRUFBWTtFQUM1Q0YsY0FBQSxHQUFpQkUsVUFBQTtBQUNuQjs7O0FDa0JPLFNBQVNOLG1CQUFBLEVBQW9CO0VBQ2xDLE9BQU9PLE1BQUEsQ0FBT0MsTUFBQSxDQUFPLENBQUMsR0FBR1QsaUJBQUEsQ0FBMEIsQ0FBQztBQUN0RDtBQUdBLElBQU9VLHlCQUFBLEdBQVFULGtCQUFBOzs7QUY1QmYsSUFBT0YsK0JBQUEsR0FBUVcseUJBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=