System.register(["date-fns@3.6.0/constructFrom","date-fns@3.6.0/toDate","date-fns@3.6.0/startOfWeek","date-fns@3.6.0/startOfISOWeek"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfWeek', dep), dep => dependencies.set('date-fns@3.6.0/startOfISOWeek', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/getISOWeekYear.3.6.0.js
var getISOWeekYear_3_6_0_exports = {};
__export(getISOWeekYear_3_6_0_exports, {
  default: () => getISOWeekYear_3_6_0_default,
  getISOWeekYear: () => getISOWeekYear
});
module.exports = __toCommonJS(getISOWeekYear_3_6_0_exports);

// node_modules/date-fns/getISOWeekYear.mjs
var import_constructFrom = require("date-fns@3.6.0/constructFrom");
var import_startOfISOWeek = require("date-fns@3.6.0/startOfISOWeek");
var import_toDate = require("date-fns@3.6.0/toDate");
function getISOWeekYear(date) {
  const _date = (0, import_toDate.toDate)(date);
  const year = _date.getFullYear();
  const fourthOfJanuaryOfNextYear = (0, import_constructFrom.constructFrom)(date, 0);
  fourthOfJanuaryOfNextYear.setFullYear(year + 1, 0, 4);
  fourthOfJanuaryOfNextYear.setHours(0, 0, 0, 0);
  const startOfNextYear = (0, import_startOfISOWeek.startOfISOWeek)(fourthOfJanuaryOfNextYear);
  const fourthOfJanuaryOfThisYear = (0, import_constructFrom.constructFrom)(date, 0);
  fourthOfJanuaryOfThisYear.setFullYear(year, 0, 4);
  fourthOfJanuaryOfThisYear.setHours(0, 0, 0, 0);
  const startOfThisYear = (0, import_startOfISOWeek.startOfISOWeek)(fourthOfJanuaryOfThisYear);
  if (_date.getTime() >= startOfNextYear.getTime()) {
    return year + 1;
  } else if (_date.getTime() >= startOfThisYear.getTime()) {
    return year;
  } else {
    return year - 1;
  }
}
var getISOWeekYear_default = getISOWeekYear;

// .beyond/uimport/temp/date-fns/getISOWeekYear.3.6.0.js
var getISOWeekYear_3_6_0_default = getISOWeekYear_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2dldElTT1dlZWtZZWFyLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2dldElTT1dlZWtZZWFyLm1qcyJdLCJuYW1lcyI6WyJnZXRJU09XZWVrWWVhcl8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZ2V0SVNPV2Vla1llYXJfM182XzBfZGVmYXVsdCIsImdldElTT1dlZWtZZWFyIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF9jb25zdHJ1Y3RGcm9tIiwicmVxdWlyZSIsImltcG9ydF9zdGFydE9mSVNPV2VlayIsImltcG9ydF90b0RhdGUiLCJkYXRlIiwiX2RhdGUiLCJ0b0RhdGUiLCJ5ZWFyIiwiZ2V0RnVsbFllYXIiLCJmb3VydGhPZkphbnVhcnlPZk5leHRZZWFyIiwiY29uc3RydWN0RnJvbSIsInNldEZ1bGxZZWFyIiwic2V0SG91cnMiLCJzdGFydE9mTmV4dFllYXIiLCJzdGFydE9mSVNPV2VlayIsImZvdXJ0aE9mSmFudWFyeU9mVGhpc1llYXIiLCJzdGFydE9mVGhpc1llYXIiLCJnZXRUaW1lIiwiZ2V0SVNPV2Vla1llYXJfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsNEJBQUE7QUFBQUMsUUFBQSxDQUFBRCw0QkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsNEJBQUE7RUFBQUMsY0FBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsNEJBQUE7OztBQ0FBLElBQUFRLG9CQUFBLEdBQThCQyxPQUFBO0FBQzlCLElBQUFDLHFCQUFBLEdBQStCRCxPQUFBO0FBQy9CLElBQUFFLGFBQUEsR0FBdUJGLE9BQUE7QUF3QmhCLFNBQVNMLGVBQWVRLElBQUEsRUFBTTtFQUNuQyxNQUFNQyxLQUFBLE9BQVFGLGFBQUEsQ0FBQUcsTUFBQSxFQUFPRixJQUFJO0VBQ3pCLE1BQU1HLElBQUEsR0FBT0YsS0FBQSxDQUFNRyxXQUFBLENBQVk7RUFFL0IsTUFBTUMseUJBQUEsT0FBNEJULG9CQUFBLENBQUFVLGFBQUEsRUFBY04sSUFBQSxFQUFNLENBQUM7RUFDdkRLLHlCQUFBLENBQTBCRSxXQUFBLENBQVlKLElBQUEsR0FBTyxHQUFHLEdBQUcsQ0FBQztFQUNwREUseUJBQUEsQ0FBMEJHLFFBQUEsQ0FBUyxHQUFHLEdBQUcsR0FBRyxDQUFDO0VBQzdDLE1BQU1DLGVBQUEsT0FBa0JYLHFCQUFBLENBQUFZLGNBQUEsRUFBZUwseUJBQXlCO0VBRWhFLE1BQU1NLHlCQUFBLE9BQTRCZixvQkFBQSxDQUFBVSxhQUFBLEVBQWNOLElBQUEsRUFBTSxDQUFDO0VBQ3ZEVyx5QkFBQSxDQUEwQkosV0FBQSxDQUFZSixJQUFBLEVBQU0sR0FBRyxDQUFDO0VBQ2hEUSx5QkFBQSxDQUEwQkgsUUFBQSxDQUFTLEdBQUcsR0FBRyxHQUFHLENBQUM7RUFDN0MsTUFBTUksZUFBQSxPQUFrQmQscUJBQUEsQ0FBQVksY0FBQSxFQUFlQyx5QkFBeUI7RUFFaEUsSUFBSVYsS0FBQSxDQUFNWSxPQUFBLENBQVEsS0FBS0osZUFBQSxDQUFnQkksT0FBQSxDQUFRLEdBQUc7SUFDaEQsT0FBT1YsSUFBQSxHQUFPO0VBQ2hCLFdBQVdGLEtBQUEsQ0FBTVksT0FBQSxDQUFRLEtBQUtELGVBQUEsQ0FBZ0JDLE9BQUEsQ0FBUSxHQUFHO0lBQ3ZELE9BQU9WLElBQUE7RUFDVCxPQUFPO0lBQ0wsT0FBT0EsSUFBQSxHQUFPO0VBQ2hCO0FBQ0Y7QUFHQSxJQUFPVyxzQkFBQSxHQUFRdEIsY0FBQTs7O0FEL0NmLElBQU9ELDRCQUFBLEdBQVF1QixzQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==