System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/constants"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/constants', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/getOverlappingDaysInIntervals.3.6.0.js
var getOverlappingDaysInIntervals_3_6_0_exports = {};
__export(getOverlappingDaysInIntervals_3_6_0_exports, {
  default: () => getOverlappingDaysInIntervals_3_6_0_default,
  getOverlappingDaysInIntervals: () => getOverlappingDaysInIntervals
});
module.exports = __toCommonJS(getOverlappingDaysInIntervals_3_6_0_exports);

// node_modules/date-fns/_lib/getTimezoneOffsetInMilliseconds.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function getTimezoneOffsetInMilliseconds(date) {
  const _date = (0, import_toDate.toDate)(date);
  const utcDate = new Date(Date.UTC(_date.getFullYear(), _date.getMonth(), _date.getDate(), _date.getHours(), _date.getMinutes(), _date.getSeconds(), _date.getMilliseconds()));
  utcDate.setUTCFullYear(_date.getFullYear());
  return +date - +utcDate;
}

// node_modules/date-fns/getOverlappingDaysInIntervals.mjs
var import_constants = require("date-fns@3.6.0/constants");
var import_toDate2 = require("date-fns@3.6.0/toDate");
function getOverlappingDaysInIntervals(intervalLeft, intervalRight) {
  const [leftStart, leftEnd] = [+(0, import_toDate2.toDate)(intervalLeft.start), +(0, import_toDate2.toDate)(intervalLeft.end)].sort((a, b) => a - b);
  const [rightStart, rightEnd] = [+(0, import_toDate2.toDate)(intervalRight.start), +(0, import_toDate2.toDate)(intervalRight.end)].sort((a, b) => a - b);
  const isOverlapping = leftStart < rightEnd && rightStart < leftEnd;
  if (!isOverlapping) return 0;
  const overlapLeft = rightStart < leftStart ? leftStart : rightStart;
  const left = overlapLeft - getTimezoneOffsetInMilliseconds(overlapLeft);
  const overlapRight = rightEnd > leftEnd ? leftEnd : rightEnd;
  const right = overlapRight - getTimezoneOffsetInMilliseconds(overlapRight);
  return Math.ceil((right - left) / import_constants.millisecondsInDay);
}
var getOverlappingDaysInIntervals_default = getOverlappingDaysInIntervals;

// .beyond/uimport/temp/date-fns/getOverlappingDaysInIntervals.3.6.0.js
var getOverlappingDaysInIntervals_3_6_0_default = getOverlappingDaysInIntervals_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2dldE92ZXJsYXBwaW5nRGF5c0luSW50ZXJ2YWxzLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL19saWIvZ2V0VGltZXpvbmVPZmZzZXRJbk1pbGxpc2Vjb25kcy5tanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvZ2V0T3ZlcmxhcHBpbmdEYXlzSW5JbnRlcnZhbHMubWpzIl0sIm5hbWVzIjpbImdldE92ZXJsYXBwaW5nRGF5c0luSW50ZXJ2YWxzXzNfNl8wX2V4cG9ydHMiLCJfX2V4cG9ydCIsImRlZmF1bHQiLCJnZXRPdmVybGFwcGluZ0RheXNJbkludGVydmFsc18zXzZfMF9kZWZhdWx0IiwiZ2V0T3ZlcmxhcHBpbmdEYXlzSW5JbnRlcnZhbHMiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X3RvRGF0ZSIsInJlcXVpcmUiLCJnZXRUaW1lem9uZU9mZnNldEluTWlsbGlzZWNvbmRzIiwiZGF0ZSIsIl9kYXRlIiwidG9EYXRlIiwidXRjRGF0ZSIsIkRhdGUiLCJVVEMiLCJnZXRGdWxsWWVhciIsImdldE1vbnRoIiwiZ2V0RGF0ZSIsImdldEhvdXJzIiwiZ2V0TWludXRlcyIsImdldFNlY29uZHMiLCJnZXRNaWxsaXNlY29uZHMiLCJzZXRVVENGdWxsWWVhciIsImltcG9ydF9jb25zdGFudHMiLCJpbXBvcnRfdG9EYXRlMiIsImludGVydmFsTGVmdCIsImludGVydmFsUmlnaHQiLCJsZWZ0U3RhcnQiLCJsZWZ0RW5kIiwic3RhcnQiLCJlbmQiLCJzb3J0IiwiYSIsImIiLCJyaWdodFN0YXJ0IiwicmlnaHRFbmQiLCJpc092ZXJsYXBwaW5nIiwib3ZlcmxhcExlZnQiLCJsZWZ0Iiwib3ZlcmxhcFJpZ2h0IiwicmlnaHQiLCJNYXRoIiwiY2VpbCIsIm1pbGxpc2Vjb25kc0luRGF5IiwiZ2V0T3ZlcmxhcHBpbmdEYXlzSW5JbnRlcnZhbHNfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsMkNBQUE7QUFBQUMsUUFBQSxDQUFBRCwyQ0FBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsMkNBQUE7RUFBQUMsNkJBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLDJDQUFBOzs7QUNBQSxJQUFBUSxhQUFBLEdBQXVCQyxPQUFBO0FBYWhCLFNBQVNDLGdDQUFnQ0MsSUFBQSxFQUFNO0VBQ3BELE1BQU1DLEtBQUEsT0FBUUosYUFBQSxDQUFBSyxNQUFBLEVBQU9GLElBQUk7RUFDekIsTUFBTUcsT0FBQSxHQUFVLElBQUlDLElBQUEsQ0FDbEJBLElBQUEsQ0FBS0MsR0FBQSxDQUNISixLQUFBLENBQU1LLFdBQUEsQ0FBWSxHQUNsQkwsS0FBQSxDQUFNTSxRQUFBLENBQVMsR0FDZk4sS0FBQSxDQUFNTyxPQUFBLENBQVEsR0FDZFAsS0FBQSxDQUFNUSxRQUFBLENBQVMsR0FDZlIsS0FBQSxDQUFNUyxVQUFBLENBQVcsR0FDakJULEtBQUEsQ0FBTVUsVUFBQSxDQUFXLEdBQ2pCVixLQUFBLENBQU1XLGVBQUEsQ0FBZ0IsQ0FDeEIsQ0FDRjtFQUNBVCxPQUFBLENBQVFVLGNBQUEsQ0FBZVosS0FBQSxDQUFNSyxXQUFBLENBQVksQ0FBQztFQUMxQyxPQUFPLENBQUNOLElBQUEsR0FBTyxDQUFDRyxPQUFBO0FBQ2xCOzs7QUMzQkEsSUFBQVcsZ0JBQUEsR0FBa0NoQixPQUFBO0FBQ2xDLElBQUFpQixjQUFBLEdBQXVCakIsT0FBQTtBQXVDaEIsU0FBU0wsOEJBQThCdUIsWUFBQSxFQUFjQyxhQUFBLEVBQWU7RUFDekUsTUFBTSxDQUFDQyxTQUFBLEVBQVdDLE9BQU8sSUFBSSxDQUMzQixLQUFDSixjQUFBLENBQUFiLE1BQUEsRUFBT2MsWUFBQSxDQUFhSSxLQUFLLEdBQzFCLEtBQUNMLGNBQUEsQ0FBQWIsTUFBQSxFQUFPYyxZQUFBLENBQWFLLEdBQUcsRUFDMUIsQ0FBRUMsSUFBQSxDQUFLLENBQUNDLENBQUEsRUFBR0MsQ0FBQSxLQUFNRCxDQUFBLEdBQUlDLENBQUM7RUFDdEIsTUFBTSxDQUFDQyxVQUFBLEVBQVlDLFFBQVEsSUFBSSxDQUM3QixLQUFDWCxjQUFBLENBQUFiLE1BQUEsRUFBT2UsYUFBQSxDQUFjRyxLQUFLLEdBQzNCLEtBQUNMLGNBQUEsQ0FBQWIsTUFBQSxFQUFPZSxhQUFBLENBQWNJLEdBQUcsRUFDM0IsQ0FBRUMsSUFBQSxDQUFLLENBQUNDLENBQUEsRUFBR0MsQ0FBQSxLQUFNRCxDQUFBLEdBQUlDLENBQUM7RUFHdEIsTUFBTUcsYUFBQSxHQUFnQlQsU0FBQSxHQUFZUSxRQUFBLElBQVlELFVBQUEsR0FBYU4sT0FBQTtFQUMzRCxJQUFJLENBQUNRLGFBQUEsRUFBZSxPQUFPO0VBRzNCLE1BQU1DLFdBQUEsR0FBY0gsVUFBQSxHQUFhUCxTQUFBLEdBQVlBLFNBQUEsR0FBWU8sVUFBQTtFQUN6RCxNQUFNSSxJQUFBLEdBQU9ELFdBQUEsR0FBYzdCLCtCQUFBLENBQWdDNkIsV0FBVztFQUN0RSxNQUFNRSxZQUFBLEdBQWVKLFFBQUEsR0FBV1AsT0FBQSxHQUFVQSxPQUFBLEdBQVVPLFFBQUE7RUFDcEQsTUFBTUssS0FBQSxHQUFRRCxZQUFBLEdBQWUvQiwrQkFBQSxDQUFnQytCLFlBQVk7RUFHekUsT0FBT0UsSUFBQSxDQUFLQyxJQUFBLEVBQU1GLEtBQUEsR0FBUUYsSUFBQSxJQUFRZixnQkFBQSxDQUFBb0IsaUJBQWlCO0FBQ3JEO0FBR0EsSUFBT0MscUNBQUEsR0FBUTFDLDZCQUFBOzs7QUYvRGYsSUFBT0QsMkNBQUEsR0FBUTJDLHFDQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9