System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/getDate","date-fns@3.6.0/getDay","date-fns@3.6.0/startOfMonth"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/getDate', dep), dep => dependencies.set('date-fns@3.6.0/getDay', dep), dep => dependencies.set('date-fns@3.6.0/startOfMonth', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/getWeekOfMonth.3.6.0.js
var getWeekOfMonth_3_6_0_exports = {};
__export(getWeekOfMonth_3_6_0_exports, {
  default: () => getWeekOfMonth_3_6_0_default,
  getWeekOfMonth: () => getWeekOfMonth
});
module.exports = __toCommonJS(getWeekOfMonth_3_6_0_exports);

// node_modules/date-fns/_lib/defaultOptions.mjs
var defaultOptions = {};
function getDefaultOptions() {
  return defaultOptions;
}
function setDefaultOptions(newOptions) {
  defaultOptions = newOptions;
}

// node_modules/date-fns/getWeekOfMonth.mjs
var import_getDate = require("date-fns@3.6.0/getDate");
var import_getDay = require("date-fns@3.6.0/getDay");
var import_startOfMonth = require("date-fns@3.6.0/startOfMonth");
function getWeekOfMonth(date, options) {
  const defaultOptions2 = getDefaultOptions();
  const weekStartsOn = options?.weekStartsOn ?? options?.locale?.options?.weekStartsOn ?? defaultOptions2.weekStartsOn ?? defaultOptions2.locale?.options?.weekStartsOn ?? 0;
  const currentDayOfMonth = (0, import_getDate.getDate)(date);
  if (isNaN(currentDayOfMonth)) return NaN;
  const startWeekDay = (0, import_getDay.getDay)((0, import_startOfMonth.startOfMonth)(date));
  let lastDayOfFirstWeek = weekStartsOn - startWeekDay;
  if (lastDayOfFirstWeek <= 0) lastDayOfFirstWeek += 7;
  const remainingDaysAfterFirstWeek = currentDayOfMonth - lastDayOfFirstWeek;
  return Math.ceil(remainingDaysAfterFirstWeek / 7) + 1;
}
var getWeekOfMonth_default = getWeekOfMonth;

// .beyond/uimport/temp/date-fns/getWeekOfMonth.3.6.0.js
var getWeekOfMonth_3_6_0_default = getWeekOfMonth_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2dldFdlZWtPZk1vbnRoLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL19saWIvZGVmYXVsdE9wdGlvbnMubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2dldFdlZWtPZk1vbnRoLm1qcyJdLCJuYW1lcyI6WyJnZXRXZWVrT2ZNb250aF8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZ2V0V2Vla09mTW9udGhfM182XzBfZGVmYXVsdCIsImdldFdlZWtPZk1vbnRoIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImRlZmF1bHRPcHRpb25zIiwiZ2V0RGVmYXVsdE9wdGlvbnMiLCJzZXREZWZhdWx0T3B0aW9ucyIsIm5ld09wdGlvbnMiLCJpbXBvcnRfZ2V0RGF0ZSIsInJlcXVpcmUiLCJpbXBvcnRfZ2V0RGF5IiwiaW1wb3J0X3N0YXJ0T2ZNb250aCIsImRhdGUiLCJvcHRpb25zIiwiZGVmYXVsdE9wdGlvbnMyIiwid2Vla1N0YXJ0c09uIiwibG9jYWxlIiwiY3VycmVudERheU9mTW9udGgiLCJnZXREYXRlIiwiaXNOYU4iLCJOYU4iLCJzdGFydFdlZWtEYXkiLCJnZXREYXkiLCJzdGFydE9mTW9udGgiLCJsYXN0RGF5T2ZGaXJzdFdlZWsiLCJyZW1haW5pbmdEYXlzQWZ0ZXJGaXJzdFdlZWsiLCJNYXRoIiwiY2VpbCIsImdldFdlZWtPZk1vbnRoX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLDRCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsNEJBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLDRCQUFBO0VBQUFDLGNBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLDRCQUFBOzs7QUNBQSxJQUFJUSxjQUFBLEdBQWlCLENBQUM7QUFFZixTQUFTQyxrQkFBQSxFQUFvQjtFQUNsQyxPQUFPRCxjQUFBO0FBQ1Q7QUFFTyxTQUFTRSxrQkFBa0JDLFVBQUEsRUFBWTtFQUM1Q0gsY0FBQSxHQUFpQkcsVUFBQTtBQUNuQjs7O0FDUkEsSUFBQUMsY0FBQSxHQUF3QkMsT0FBQTtBQUN4QixJQUFBQyxhQUFBLEdBQXVCRCxPQUFBO0FBQ3ZCLElBQUFFLG1CQUFBLEdBQTZCRixPQUFBO0FBMkJ0QixTQUFTVCxlQUFlWSxJQUFBLEVBQU1DLE9BQUEsRUFBUztFQUM1QyxNQUFNQyxlQUFBLEdBQWlCVCxpQkFBQSxDQUFrQjtFQUN6QyxNQUFNVSxZQUFBLEdBQ0pGLE9BQUEsRUFBU0UsWUFBQSxJQUNURixPQUFBLEVBQVNHLE1BQUEsRUFBUUgsT0FBQSxFQUFTRSxZQUFBLElBQzFCRCxlQUFBLENBQWVDLFlBQUEsSUFDZkQsZUFBQSxDQUFlRSxNQUFBLEVBQVFILE9BQUEsRUFBU0UsWUFBQSxJQUNoQztFQUVGLE1BQU1FLGlCQUFBLE9BQW9CVCxjQUFBLENBQUFVLE9BQUEsRUFBUU4sSUFBSTtFQUN0QyxJQUFJTyxLQUFBLENBQU1GLGlCQUFpQixHQUFHLE9BQU9HLEdBQUE7RUFFckMsTUFBTUMsWUFBQSxPQUFlWCxhQUFBLENBQUFZLE1BQUEsTUFBT1gsbUJBQUEsQ0FBQVksWUFBQSxFQUFhWCxJQUFJLENBQUM7RUFFOUMsSUFBSVksa0JBQUEsR0FBcUJULFlBQUEsR0FBZU0sWUFBQTtFQUN4QyxJQUFJRyxrQkFBQSxJQUFzQixHQUFHQSxrQkFBQSxJQUFzQjtFQUVuRCxNQUFNQywyQkFBQSxHQUE4QlIsaUJBQUEsR0FBb0JPLGtCQUFBO0VBQ3hELE9BQU9FLElBQUEsQ0FBS0MsSUFBQSxDQUFLRiwyQkFBQSxHQUE4QixDQUFDLElBQUk7QUFDdEQ7QUFHQSxJQUFPRyxzQkFBQSxHQUFRNUIsY0FBQTs7O0FGaERmLElBQU9ELDRCQUFBLEdBQVE2QixzQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==