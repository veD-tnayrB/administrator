System.register(["date-fns@3.6.0/constructFrom","date-fns@3.6.0/toDate","date-fns@3.6.0/startOfWeek"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfWeek', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/getWeekYear.3.6.0.js
var getWeekYear_3_6_0_exports = {};
__export(getWeekYear_3_6_0_exports, {
  default: () => getWeekYear_3_6_0_default,
  getWeekYear: () => getWeekYear
});
module.exports = __toCommonJS(getWeekYear_3_6_0_exports);

// node_modules/date-fns/_lib/defaultOptions.mjs
var defaultOptions = {};
function getDefaultOptions() {
  return defaultOptions;
}
function setDefaultOptions(newOptions) {
  defaultOptions = newOptions;
}

// node_modules/date-fns/getWeekYear.mjs
var import_constructFrom = require("date-fns@3.6.0/constructFrom");
var import_startOfWeek = require("date-fns@3.6.0/startOfWeek");
var import_toDate = require("date-fns@3.6.0/toDate");
function getWeekYear(date, options) {
  const _date = (0, import_toDate.toDate)(date);
  const year = _date.getFullYear();
  const defaultOptions2 = getDefaultOptions();
  const firstWeekContainsDate = options?.firstWeekContainsDate ?? options?.locale?.options?.firstWeekContainsDate ?? defaultOptions2.firstWeekContainsDate ?? defaultOptions2.locale?.options?.firstWeekContainsDate ?? 1;
  const firstWeekOfNextYear = (0, import_constructFrom.constructFrom)(date, 0);
  firstWeekOfNextYear.setFullYear(year + 1, 0, firstWeekContainsDate);
  firstWeekOfNextYear.setHours(0, 0, 0, 0);
  const startOfNextYear = (0, import_startOfWeek.startOfWeek)(firstWeekOfNextYear, options);
  const firstWeekOfThisYear = (0, import_constructFrom.constructFrom)(date, 0);
  firstWeekOfThisYear.setFullYear(year, 0, firstWeekContainsDate);
  firstWeekOfThisYear.setHours(0, 0, 0, 0);
  const startOfThisYear = (0, import_startOfWeek.startOfWeek)(firstWeekOfThisYear, options);
  if (_date.getTime() >= startOfNextYear.getTime()) {
    return year + 1;
  } else if (_date.getTime() >= startOfThisYear.getTime()) {
    return year;
  } else {
    return year - 1;
  }
}
var getWeekYear_default = getWeekYear;

// .beyond/uimport/temp/date-fns/getWeekYear.3.6.0.js
var getWeekYear_3_6_0_default = getWeekYear_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2dldFdlZWtZZWFyLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL19saWIvZGVmYXVsdE9wdGlvbnMubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2dldFdlZWtZZWFyLm1qcyJdLCJuYW1lcyI6WyJnZXRXZWVrWWVhcl8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZ2V0V2Vla1llYXJfM182XzBfZGVmYXVsdCIsImdldFdlZWtZZWFyIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImRlZmF1bHRPcHRpb25zIiwiZ2V0RGVmYXVsdE9wdGlvbnMiLCJzZXREZWZhdWx0T3B0aW9ucyIsIm5ld09wdGlvbnMiLCJpbXBvcnRfY29uc3RydWN0RnJvbSIsInJlcXVpcmUiLCJpbXBvcnRfc3RhcnRPZldlZWsiLCJpbXBvcnRfdG9EYXRlIiwiZGF0ZSIsIm9wdGlvbnMiLCJfZGF0ZSIsInRvRGF0ZSIsInllYXIiLCJnZXRGdWxsWWVhciIsImRlZmF1bHRPcHRpb25zMiIsImZpcnN0V2Vla0NvbnRhaW5zRGF0ZSIsImxvY2FsZSIsImZpcnN0V2Vla09mTmV4dFllYXIiLCJjb25zdHJ1Y3RGcm9tIiwic2V0RnVsbFllYXIiLCJzZXRIb3VycyIsInN0YXJ0T2ZOZXh0WWVhciIsInN0YXJ0T2ZXZWVrIiwiZmlyc3RXZWVrT2ZUaGlzWWVhciIsInN0YXJ0T2ZUaGlzWWVhciIsImdldFRpbWUiLCJnZXRXZWVrWWVhcl9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSx5QkFBQTtBQUFBQyxRQUFBLENBQUFELHlCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyx5QkFBQTtFQUFBQyxXQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCx5QkFBQTs7O0FDQUEsSUFBSVEsY0FBQSxHQUFpQixDQUFDO0FBRWYsU0FBU0Msa0JBQUEsRUFBb0I7RUFDbEMsT0FBT0QsY0FBQTtBQUNUO0FBRU8sU0FBU0Usa0JBQWtCQyxVQUFBLEVBQVk7RUFDNUNILGNBQUEsR0FBaUJHLFVBQUE7QUFDbkI7OztBQ1JBLElBQUFDLG9CQUFBLEdBQThCQyxPQUFBO0FBQzlCLElBQUFDLGtCQUFBLEdBQTRCRCxPQUFBO0FBQzVCLElBQUFFLGFBQUEsR0FBdUJGLE9BQUE7QUEyQ2hCLFNBQVNULFlBQVlZLElBQUEsRUFBTUMsT0FBQSxFQUFTO0VBQ3pDLE1BQU1DLEtBQUEsT0FBUUgsYUFBQSxDQUFBSSxNQUFBLEVBQU9ILElBQUk7RUFDekIsTUFBTUksSUFBQSxHQUFPRixLQUFBLENBQU1HLFdBQUEsQ0FBWTtFQUUvQixNQUFNQyxlQUFBLEdBQWlCYixpQkFBQSxDQUFrQjtFQUN6QyxNQUFNYyxxQkFBQSxHQUNKTixPQUFBLEVBQVNNLHFCQUFBLElBQ1ROLE9BQUEsRUFBU08sTUFBQSxFQUFRUCxPQUFBLEVBQVNNLHFCQUFBLElBQzFCRCxlQUFBLENBQWVDLHFCQUFBLElBQ2ZELGVBQUEsQ0FBZUUsTUFBQSxFQUFRUCxPQUFBLEVBQVNNLHFCQUFBLElBQ2hDO0VBRUYsTUFBTUUsbUJBQUEsT0FBc0JiLG9CQUFBLENBQUFjLGFBQUEsRUFBY1YsSUFBQSxFQUFNLENBQUM7RUFDakRTLG1CQUFBLENBQW9CRSxXQUFBLENBQVlQLElBQUEsR0FBTyxHQUFHLEdBQUdHLHFCQUFxQjtFQUNsRUUsbUJBQUEsQ0FBb0JHLFFBQUEsQ0FBUyxHQUFHLEdBQUcsR0FBRyxDQUFDO0VBQ3ZDLE1BQU1DLGVBQUEsT0FBa0JmLGtCQUFBLENBQUFnQixXQUFBLEVBQVlMLG1CQUFBLEVBQXFCUixPQUFPO0VBRWhFLE1BQU1jLG1CQUFBLE9BQXNCbkIsb0JBQUEsQ0FBQWMsYUFBQSxFQUFjVixJQUFBLEVBQU0sQ0FBQztFQUNqRGUsbUJBQUEsQ0FBb0JKLFdBQUEsQ0FBWVAsSUFBQSxFQUFNLEdBQUdHLHFCQUFxQjtFQUM5RFEsbUJBQUEsQ0FBb0JILFFBQUEsQ0FBUyxHQUFHLEdBQUcsR0FBRyxDQUFDO0VBQ3ZDLE1BQU1JLGVBQUEsT0FBa0JsQixrQkFBQSxDQUFBZ0IsV0FBQSxFQUFZQyxtQkFBQSxFQUFxQmQsT0FBTztFQUVoRSxJQUFJQyxLQUFBLENBQU1lLE9BQUEsQ0FBUSxLQUFLSixlQUFBLENBQWdCSSxPQUFBLENBQVEsR0FBRztJQUNoRCxPQUFPYixJQUFBLEdBQU87RUFDaEIsV0FBV0YsS0FBQSxDQUFNZSxPQUFBLENBQVEsS0FBS0QsZUFBQSxDQUFnQkMsT0FBQSxDQUFRLEdBQUc7SUFDdkQsT0FBT2IsSUFBQTtFQUNULE9BQU87SUFDTCxPQUFPQSxJQUFBLEdBQU87RUFDaEI7QUFDRjtBQUdBLElBQU9jLG1CQUFBLEdBQVE5QixXQUFBOzs7QUYxRWYsSUFBT0QseUJBQUEsR0FBUStCLG1CQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9