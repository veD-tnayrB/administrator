System.register(["date-fns@3.6.0/constants","date-fns@3.6.0/toDate","date-fns@3.6.0/startOfWeek","date-fns@3.6.0/differenceInCalendarWeeks","date-fns@3.6.0/lastDayOfMonth","date-fns@3.6.0/startOfMonth"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constants', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfWeek', dep), dep => dependencies.set('date-fns@3.6.0/differenceInCalendarWeeks', dep), dep => dependencies.set('date-fns@3.6.0/lastDayOfMonth', dep), dep => dependencies.set('date-fns@3.6.0/startOfMonth', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/getWeeksInMonth.3.6.0.js
var getWeeksInMonth_3_6_0_exports = {};
__export(getWeeksInMonth_3_6_0_exports, {
  default: () => getWeeksInMonth_3_6_0_default,
  getWeeksInMonth: () => getWeeksInMonth
});
module.exports = __toCommonJS(getWeeksInMonth_3_6_0_exports);

// node_modules/date-fns/getWeeksInMonth.mjs
var import_differenceInCalendarWeeks = require("date-fns@3.6.0/differenceInCalendarWeeks");
var import_lastDayOfMonth = require("date-fns@3.6.0/lastDayOfMonth");
var import_startOfMonth = require("date-fns@3.6.0/startOfMonth");
function getWeeksInMonth(date, options) {
  return (0, import_differenceInCalendarWeeks.differenceInCalendarWeeks)((0, import_lastDayOfMonth.lastDayOfMonth)(date), (0, import_startOfMonth.startOfMonth)(date), options) + 1;
}
var getWeeksInMonth_default = getWeeksInMonth;

// .beyond/uimport/temp/date-fns/getWeeksInMonth.3.6.0.js
var getWeeksInMonth_3_6_0_default = getWeeksInMonth_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2dldFdlZWtzSW5Nb250aC4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9nZXRXZWVrc0luTW9udGgubWpzIl0sIm5hbWVzIjpbImdldFdlZWtzSW5Nb250aF8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiZ2V0V2Vla3NJbk1vbnRoXzNfNl8wX2RlZmF1bHQiLCJnZXRXZWVrc0luTW9udGgiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2RpZmZlcmVuY2VJbkNhbGVuZGFyV2Vla3MiLCJyZXF1aXJlIiwiaW1wb3J0X2xhc3REYXlPZk1vbnRoIiwiaW1wb3J0X3N0YXJ0T2ZNb250aCIsImRhdGUiLCJvcHRpb25zIiwiZGlmZmVyZW5jZUluQ2FsZW5kYXJXZWVrcyIsImxhc3REYXlPZk1vbnRoIiwic3RhcnRPZk1vbnRoIiwiZ2V0V2Vla3NJbk1vbnRoX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLDZCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsNkJBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLDZCQUFBO0VBQUFDLGVBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLDZCQUFBOzs7QUNBQSxJQUFBUSxnQ0FBQSxHQUEwQ0MsT0FBQTtBQUMxQyxJQUFBQyxxQkFBQSxHQUErQkQsT0FBQTtBQUMvQixJQUFBRSxtQkFBQSxHQUE2QkYsT0FBQTtBQWdDdEIsU0FBU0wsZ0JBQWdCUSxJQUFBLEVBQU1DLE9BQUEsRUFBUztFQUM3QyxXQUNFTCxnQ0FBQSxDQUFBTSx5QkFBQSxNQUNFSixxQkFBQSxDQUFBSyxjQUFBLEVBQWVILElBQUksT0FDbkJELG1CQUFBLENBQUFLLFlBQUEsRUFBYUosSUFBSSxHQUNqQkMsT0FDRixJQUFJO0FBRVI7QUFHQSxJQUFPSSx1QkFBQSxHQUFRYixlQUFBOzs7QUQxQ2YsSUFBT0QsNkJBQUEsR0FBUWMsdUJBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=