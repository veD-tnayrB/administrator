System.register(["date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/interval.3.6.0.js
var interval_3_6_0_exports = {};
__export(interval_3_6_0_exports, {
  default: () => interval_3_6_0_default,
  interval: () => interval
});
module.exports = __toCommonJS(interval_3_6_0_exports);

// node_modules/date-fns/interval.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function interval(start, end, options) {
  const _start = (0, import_toDate.toDate)(start);
  if (isNaN(+_start)) throw new TypeError("Start date is invalid");
  const _end = (0, import_toDate.toDate)(end);
  if (isNaN(+_end)) throw new TypeError("End date is invalid");
  if (options?.assertPositive && +_start > +_end) throw new TypeError("End date must be after start date");
  return {
    start: _start,
    end: _end
  };
}
var interval_default = interval;

// .beyond/uimport/temp/date-fns/interval.3.6.0.js
var interval_3_6_0_default = interval_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2ludGVydmFsLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2ludGVydmFsLm1qcyJdLCJuYW1lcyI6WyJpbnRlcnZhbF8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiaW50ZXJ2YWxfM182XzBfZGVmYXVsdCIsImludGVydmFsIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF90b0RhdGUiLCJyZXF1aXJlIiwic3RhcnQiLCJlbmQiLCJvcHRpb25zIiwiX3N0YXJ0IiwidG9EYXRlIiwiaXNOYU4iLCJUeXBlRXJyb3IiLCJfZW5kIiwiYXNzZXJ0UG9zaXRpdmUiLCJpbnRlcnZhbF9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSxzQkFBQTtBQUFBQyxRQUFBLENBQUFELHNCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyxzQkFBQTtFQUFBQyxRQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCxzQkFBQTs7O0FDQUEsSUFBQVEsYUFBQSxHQUF1QkMsT0FBQTtBQTBCaEIsU0FBU0wsU0FBU00sS0FBQSxFQUFPQyxHQUFBLEVBQUtDLE9BQUEsRUFBUztFQUM1QyxNQUFNQyxNQUFBLE9BQVNMLGFBQUEsQ0FBQU0sTUFBQSxFQUFPSixLQUFLO0VBQzNCLElBQUlLLEtBQUEsQ0FBTSxDQUFDRixNQUFNLEdBQUcsTUFBTSxJQUFJRyxTQUFBLENBQVUsdUJBQXVCO0VBRS9ELE1BQU1DLElBQUEsT0FBT1QsYUFBQSxDQUFBTSxNQUFBLEVBQU9ILEdBQUc7RUFDdkIsSUFBSUksS0FBQSxDQUFNLENBQUNFLElBQUksR0FBRyxNQUFNLElBQUlELFNBQUEsQ0FBVSxxQkFBcUI7RUFFM0QsSUFBSUosT0FBQSxFQUFTTSxjQUFBLElBQWtCLENBQUNMLE1BQUEsR0FBUyxDQUFDSSxJQUFBLEVBQ3hDLE1BQU0sSUFBSUQsU0FBQSxDQUFVLG1DQUFtQztFQUV6RCxPQUFPO0lBQUVOLEtBQUEsRUFBT0csTUFBQTtJQUFRRixHQUFBLEVBQUtNO0VBQUs7QUFDcEM7QUFHQSxJQUFPRSxnQkFBQSxHQUFRZixRQUFBOzs7QURyQ2YsSUFBT0Qsc0JBQUEsR0FBUWdCLGdCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9