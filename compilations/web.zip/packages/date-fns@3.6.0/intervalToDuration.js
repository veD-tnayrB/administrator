System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/constructFrom","date-fns@3.6.0/addDays","date-fns@3.6.0/addMonths","date-fns@3.6.0/add","date-fns@3.6.0/constants","date-fns@3.6.0/startOfDay","date-fns@3.6.0/differenceInCalendarDays","date-fns@3.6.0/differenceInDays","date-fns@3.6.0/differenceInMilliseconds","date-fns@3.6.0/differenceInHours","date-fns@3.6.0/differenceInMinutes","date-fns@3.6.0/compareAsc","date-fns@3.6.0/differenceInCalendarMonths","date-fns@3.6.0/endOfDay","date-fns@3.6.0/endOfMonth","date-fns@3.6.0/isLastDayOfMonth","date-fns@3.6.0/differenceInMonths","date-fns@3.6.0/differenceInSeconds","date-fns@3.6.0/differenceInCalendarYears","date-fns@3.6.0/differenceInYears"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/addDays', dep), dep => dependencies.set('date-fns@3.6.0/addMonths', dep), dep => dependencies.set('date-fns@3.6.0/add', dep), dep => dependencies.set('date-fns@3.6.0/constants', dep), dep => dependencies.set('date-fns@3.6.0/startOfDay', dep), dep => dependencies.set('date-fns@3.6.0/differenceInCalendarDays', dep), dep => dependencies.set('date-fns@3.6.0/differenceInDays', dep), dep => dependencies.set('date-fns@3.6.0/differenceInMilliseconds', dep), dep => dependencies.set('date-fns@3.6.0/differenceInHours', dep), dep => dependencies.set('date-fns@3.6.0/differenceInMinutes', dep), dep => dependencies.set('date-fns@3.6.0/compareAsc', dep), dep => dependencies.set('date-fns@3.6.0/differenceInCalendarMonths', dep), dep => dependencies.set('date-fns@3.6.0/endOfDay', dep), dep => dependencies.set('date-fns@3.6.0/endOfMonth', dep), dep => dependencies.set('date-fns@3.6.0/isLastDayOfMonth', dep), dep => dependencies.set('date-fns@3.6.0/differenceInMonths', dep), dep => dependencies.set('date-fns@3.6.0/differenceInSeconds', dep), dep => dependencies.set('date-fns@3.6.0/differenceInCalendarYears', dep), dep => dependencies.set('date-fns@3.6.0/differenceInYears', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/intervalToDuration.3.6.0.js
var intervalToDuration_3_6_0_exports = {};
__export(intervalToDuration_3_6_0_exports, {
  default: () => intervalToDuration_3_6_0_default,
  intervalToDuration: () => intervalToDuration
});
module.exports = __toCommonJS(intervalToDuration_3_6_0_exports);

// node_modules/date-fns/intervalToDuration.mjs
var import_add = require("date-fns@3.6.0/add");
var import_differenceInDays = require("date-fns@3.6.0/differenceInDays");
var import_differenceInHours = require("date-fns@3.6.0/differenceInHours");
var import_differenceInMinutes = require("date-fns@3.6.0/differenceInMinutes");
var import_differenceInMonths = require("date-fns@3.6.0/differenceInMonths");
var import_differenceInSeconds = require("date-fns@3.6.0/differenceInSeconds");
var import_differenceInYears = require("date-fns@3.6.0/differenceInYears");
var import_toDate = require("date-fns@3.6.0/toDate");
function intervalToDuration(interval) {
  const start = (0, import_toDate.toDate)(interval.start);
  const end = (0, import_toDate.toDate)(interval.end);
  const duration = {};
  const years = (0, import_differenceInYears.differenceInYears)(end, start);
  if (years) duration.years = years;
  const remainingMonths = (0, import_add.add)(start, {
    years: duration.years
  });
  const months = (0, import_differenceInMonths.differenceInMonths)(end, remainingMonths);
  if (months) duration.months = months;
  const remainingDays = (0, import_add.add)(remainingMonths, {
    months: duration.months
  });
  const days = (0, import_differenceInDays.differenceInDays)(end, remainingDays);
  if (days) duration.days = days;
  const remainingHours = (0, import_add.add)(remainingDays, {
    days: duration.days
  });
  const hours = (0, import_differenceInHours.differenceInHours)(end, remainingHours);
  if (hours) duration.hours = hours;
  const remainingMinutes = (0, import_add.add)(remainingHours, {
    hours: duration.hours
  });
  const minutes = (0, import_differenceInMinutes.differenceInMinutes)(end, remainingMinutes);
  if (minutes) duration.minutes = minutes;
  const remainingSeconds = (0, import_add.add)(remainingMinutes, {
    minutes: duration.minutes
  });
  const seconds = (0, import_differenceInSeconds.differenceInSeconds)(end, remainingSeconds);
  if (seconds) duration.seconds = seconds;
  return duration;
}
var intervalToDuration_default = intervalToDuration;

// .beyond/uimport/temp/date-fns/intervalToDuration.3.6.0.js
var intervalToDuration_3_6_0_default = intervalToDuration_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2ludGVydmFsVG9EdXJhdGlvbi4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9pbnRlcnZhbFRvRHVyYXRpb24ubWpzIl0sIm5hbWVzIjpbImludGVydmFsVG9EdXJhdGlvbl8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiaW50ZXJ2YWxUb0R1cmF0aW9uXzNfNl8wX2RlZmF1bHQiLCJpbnRlcnZhbFRvRHVyYXRpb24iLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2FkZCIsInJlcXVpcmUiLCJpbXBvcnRfZGlmZmVyZW5jZUluRGF5cyIsImltcG9ydF9kaWZmZXJlbmNlSW5Ib3VycyIsImltcG9ydF9kaWZmZXJlbmNlSW5NaW51dGVzIiwiaW1wb3J0X2RpZmZlcmVuY2VJbk1vbnRocyIsImltcG9ydF9kaWZmZXJlbmNlSW5TZWNvbmRzIiwiaW1wb3J0X2RpZmZlcmVuY2VJblllYXJzIiwiaW1wb3J0X3RvRGF0ZSIsImludGVydmFsIiwic3RhcnQiLCJ0b0RhdGUiLCJlbmQiLCJkdXJhdGlvbiIsInllYXJzIiwiZGlmZmVyZW5jZUluWWVhcnMiLCJyZW1haW5pbmdNb250aHMiLCJhZGQiLCJtb250aHMiLCJkaWZmZXJlbmNlSW5Nb250aHMiLCJyZW1haW5pbmdEYXlzIiwiZGF5cyIsImRpZmZlcmVuY2VJbkRheXMiLCJyZW1haW5pbmdIb3VycyIsImhvdXJzIiwiZGlmZmVyZW5jZUluSG91cnMiLCJyZW1haW5pbmdNaW51dGVzIiwibWludXRlcyIsImRpZmZlcmVuY2VJbk1pbnV0ZXMiLCJyZW1haW5pbmdTZWNvbmRzIiwic2Vjb25kcyIsImRpZmZlcmVuY2VJblNlY29uZHMiLCJpbnRlcnZhbFRvRHVyYXRpb25fZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsZ0NBQUE7QUFBQUMsUUFBQSxDQUFBRCxnQ0FBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsZ0NBQUE7RUFBQUMsa0JBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLGdDQUFBOzs7QUNBQSxJQUFBUSxVQUFBLEdBQW9CQyxPQUFBO0FBQ3BCLElBQUFDLHVCQUFBLEdBQWlDRCxPQUFBO0FBQ2pDLElBQUFFLHdCQUFBLEdBQWtDRixPQUFBO0FBQ2xDLElBQUFHLDBCQUFBLEdBQW9DSCxPQUFBO0FBQ3BDLElBQUFJLHlCQUFBLEdBQW1DSixPQUFBO0FBQ25DLElBQUFLLDBCQUFBLEdBQW9DTCxPQUFBO0FBQ3BDLElBQUFNLHdCQUFBLEdBQWtDTixPQUFBO0FBQ2xDLElBQUFPLGFBQUEsR0FBdUJQLE9BQUE7QUF3QmhCLFNBQVNMLG1CQUFtQmEsUUFBQSxFQUFVO0VBQzNDLE1BQU1DLEtBQUEsT0FBUUYsYUFBQSxDQUFBRyxNQUFBLEVBQU9GLFFBQUEsQ0FBU0MsS0FBSztFQUNuQyxNQUFNRSxHQUFBLE9BQU1KLGFBQUEsQ0FBQUcsTUFBQSxFQUFPRixRQUFBLENBQVNHLEdBQUc7RUFFL0IsTUFBTUMsUUFBQSxHQUFXLENBQUM7RUFFbEIsTUFBTUMsS0FBQSxPQUFRUCx3QkFBQSxDQUFBUSxpQkFBQSxFQUFrQkgsR0FBQSxFQUFLRixLQUFLO0VBQzFDLElBQUlJLEtBQUEsRUFBT0QsUUFBQSxDQUFTQyxLQUFBLEdBQVFBLEtBQUE7RUFFNUIsTUFBTUUsZUFBQSxPQUFrQmhCLFVBQUEsQ0FBQWlCLEdBQUEsRUFBSVAsS0FBQSxFQUFPO0lBQUVJLEtBQUEsRUFBT0QsUUFBQSxDQUFTQztFQUFNLENBQUM7RUFFNUQsTUFBTUksTUFBQSxPQUFTYix5QkFBQSxDQUFBYyxrQkFBQSxFQUFtQlAsR0FBQSxFQUFLSSxlQUFlO0VBQ3RELElBQUlFLE1BQUEsRUFBUUwsUUFBQSxDQUFTSyxNQUFBLEdBQVNBLE1BQUE7RUFFOUIsTUFBTUUsYUFBQSxPQUFnQnBCLFVBQUEsQ0FBQWlCLEdBQUEsRUFBSUQsZUFBQSxFQUFpQjtJQUFFRSxNQUFBLEVBQVFMLFFBQUEsQ0FBU0s7RUFBTyxDQUFDO0VBRXRFLE1BQU1HLElBQUEsT0FBT25CLHVCQUFBLENBQUFvQixnQkFBQSxFQUFpQlYsR0FBQSxFQUFLUSxhQUFhO0VBQ2hELElBQUlDLElBQUEsRUFBTVIsUUFBQSxDQUFTUSxJQUFBLEdBQU9BLElBQUE7RUFFMUIsTUFBTUUsY0FBQSxPQUFpQnZCLFVBQUEsQ0FBQWlCLEdBQUEsRUFBSUcsYUFBQSxFQUFlO0lBQUVDLElBQUEsRUFBTVIsUUFBQSxDQUFTUTtFQUFLLENBQUM7RUFFakUsTUFBTUcsS0FBQSxPQUFRckIsd0JBQUEsQ0FBQXNCLGlCQUFBLEVBQWtCYixHQUFBLEVBQUtXLGNBQWM7RUFDbkQsSUFBSUMsS0FBQSxFQUFPWCxRQUFBLENBQVNXLEtBQUEsR0FBUUEsS0FBQTtFQUU1QixNQUFNRSxnQkFBQSxPQUFtQjFCLFVBQUEsQ0FBQWlCLEdBQUEsRUFBSU0sY0FBQSxFQUFnQjtJQUFFQyxLQUFBLEVBQU9YLFFBQUEsQ0FBU1c7RUFBTSxDQUFDO0VBRXRFLE1BQU1HLE9BQUEsT0FBVXZCLDBCQUFBLENBQUF3QixtQkFBQSxFQUFvQmhCLEdBQUEsRUFBS2MsZ0JBQWdCO0VBQ3pELElBQUlDLE9BQUEsRUFBU2QsUUFBQSxDQUFTYyxPQUFBLEdBQVVBLE9BQUE7RUFFaEMsTUFBTUUsZ0JBQUEsT0FBbUI3QixVQUFBLENBQUFpQixHQUFBLEVBQUlTLGdCQUFBLEVBQWtCO0lBQUVDLE9BQUEsRUFBU2QsUUFBQSxDQUFTYztFQUFRLENBQUM7RUFFNUUsTUFBTUcsT0FBQSxPQUFVeEIsMEJBQUEsQ0FBQXlCLG1CQUFBLEVBQW9CbkIsR0FBQSxFQUFLaUIsZ0JBQWdCO0VBQ3pELElBQUlDLE9BQUEsRUFBU2pCLFFBQUEsQ0FBU2lCLE9BQUEsR0FBVUEsT0FBQTtFQUVoQyxPQUFPakIsUUFBQTtBQUNUO0FBR0EsSUFBT21CLDBCQUFBLEdBQVFwQyxrQkFBQTs7O0FEbEVmLElBQU9ELGdDQUFBLEdBQVFxQywwQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==