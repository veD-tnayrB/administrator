System.register(["date-fns@3.6.0/constants","date-fns@3.6.0/toDate","date-fns@3.6.0/startOfDay","date-fns@3.6.0/differenceInCalendarDays","date-fns@3.6.0/differenceInCalendarMonths","date-fns@3.6.0/getQuarter","date-fns@3.6.0/differenceInCalendarQuarters","date-fns@3.6.0/startOfWeek","date-fns@3.6.0/differenceInCalendarWeeks","date-fns@3.6.0/differenceInCalendarYears","date-fns@3.6.0/differenceInMilliseconds","date-fns@3.6.0/differenceInHours","date-fns@3.6.0/differenceInMinutes","date-fns@3.6.0/differenceInSeconds"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constants', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfDay', dep), dep => dependencies.set('date-fns@3.6.0/differenceInCalendarDays', dep), dep => dependencies.set('date-fns@3.6.0/differenceInCalendarMonths', dep), dep => dependencies.set('date-fns@3.6.0/getQuarter', dep), dep => dependencies.set('date-fns@3.6.0/differenceInCalendarQuarters', dep), dep => dependencies.set('date-fns@3.6.0/startOfWeek', dep), dep => dependencies.set('date-fns@3.6.0/differenceInCalendarWeeks', dep), dep => dependencies.set('date-fns@3.6.0/differenceInCalendarYears', dep), dep => dependencies.set('date-fns@3.6.0/differenceInMilliseconds', dep), dep => dependencies.set('date-fns@3.6.0/differenceInHours', dep), dep => dependencies.set('date-fns@3.6.0/differenceInMinutes', dep), dep => dependencies.set('date-fns@3.6.0/differenceInSeconds', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/intlFormatDistance.3.6.0.js
var intlFormatDistance_3_6_0_exports = {};
__export(intlFormatDistance_3_6_0_exports, {
  default: () => intlFormatDistance_3_6_0_default,
  intlFormatDistance: () => intlFormatDistance
});
module.exports = __toCommonJS(intlFormatDistance_3_6_0_exports);

// node_modules/date-fns/intlFormatDistance.mjs
var import_constants = require("date-fns@3.6.0/constants");
var import_differenceInCalendarDays = require("date-fns@3.6.0/differenceInCalendarDays");
var import_differenceInCalendarMonths = require("date-fns@3.6.0/differenceInCalendarMonths");
var import_differenceInCalendarQuarters = require("date-fns@3.6.0/differenceInCalendarQuarters");
var import_differenceInCalendarWeeks = require("date-fns@3.6.0/differenceInCalendarWeeks");
var import_differenceInCalendarYears = require("date-fns@3.6.0/differenceInCalendarYears");
var import_differenceInHours = require("date-fns@3.6.0/differenceInHours");
var import_differenceInMinutes = require("date-fns@3.6.0/differenceInMinutes");
var import_differenceInSeconds = require("date-fns@3.6.0/differenceInSeconds");
var import_toDate = require("date-fns@3.6.0/toDate");
function intlFormatDistance(date, baseDate, options) {
  let value = 0;
  let unit;
  const dateLeft = (0, import_toDate.toDate)(date);
  const dateRight = (0, import_toDate.toDate)(baseDate);
  if (!options?.unit) {
    const diffInSeconds = (0, import_differenceInSeconds.differenceInSeconds)(dateLeft, dateRight);
    if (Math.abs(diffInSeconds) < import_constants.secondsInMinute) {
      value = (0, import_differenceInSeconds.differenceInSeconds)(dateLeft, dateRight);
      unit = "second";
    } else if (Math.abs(diffInSeconds) < import_constants.secondsInHour) {
      value = (0, import_differenceInMinutes.differenceInMinutes)(dateLeft, dateRight);
      unit = "minute";
    } else if (Math.abs(diffInSeconds) < import_constants.secondsInDay && Math.abs((0, import_differenceInCalendarDays.differenceInCalendarDays)(dateLeft, dateRight)) < 1) {
      value = (0, import_differenceInHours.differenceInHours)(dateLeft, dateRight);
      unit = "hour";
    } else if (Math.abs(diffInSeconds) < import_constants.secondsInWeek && (value = (0, import_differenceInCalendarDays.differenceInCalendarDays)(dateLeft, dateRight)) && Math.abs(value) < 7) {
      unit = "day";
    } else if (Math.abs(diffInSeconds) < import_constants.secondsInMonth) {
      value = (0, import_differenceInCalendarWeeks.differenceInCalendarWeeks)(dateLeft, dateRight);
      unit = "week";
    } else if (Math.abs(diffInSeconds) < import_constants.secondsInQuarter) {
      value = (0, import_differenceInCalendarMonths.differenceInCalendarMonths)(dateLeft, dateRight);
      unit = "month";
    } else if (Math.abs(diffInSeconds) < import_constants.secondsInYear) {
      if ((0, import_differenceInCalendarQuarters.differenceInCalendarQuarters)(dateLeft, dateRight) < 4) {
        value = (0, import_differenceInCalendarQuarters.differenceInCalendarQuarters)(dateLeft, dateRight);
        unit = "quarter";
      } else {
        value = (0, import_differenceInCalendarYears.differenceInCalendarYears)(dateLeft, dateRight);
        unit = "year";
      }
    } else {
      value = (0, import_differenceInCalendarYears.differenceInCalendarYears)(dateLeft, dateRight);
      unit = "year";
    }
  } else {
    unit = options?.unit;
    if (unit === "second") {
      value = (0, import_differenceInSeconds.differenceInSeconds)(dateLeft, dateRight);
    } else if (unit === "minute") {
      value = (0, import_differenceInMinutes.differenceInMinutes)(dateLeft, dateRight);
    } else if (unit === "hour") {
      value = (0, import_differenceInHours.differenceInHours)(dateLeft, dateRight);
    } else if (unit === "day") {
      value = (0, import_differenceInCalendarDays.differenceInCalendarDays)(dateLeft, dateRight);
    } else if (unit === "week") {
      value = (0, import_differenceInCalendarWeeks.differenceInCalendarWeeks)(dateLeft, dateRight);
    } else if (unit === "month") {
      value = (0, import_differenceInCalendarMonths.differenceInCalendarMonths)(dateLeft, dateRight);
    } else if (unit === "quarter") {
      value = (0, import_differenceInCalendarQuarters.differenceInCalendarQuarters)(dateLeft, dateRight);
    } else if (unit === "year") {
      value = (0, import_differenceInCalendarYears.differenceInCalendarYears)(dateLeft, dateRight);
    }
  }
  const rtf = new Intl.RelativeTimeFormat(options?.locale, {
    localeMatcher: options?.localeMatcher,
    numeric: options?.numeric || "auto",
    style: options?.style
  });
  return rtf.format(value, unit);
}
var intlFormatDistance_default = intlFormatDistance;

// .beyond/uimport/temp/date-fns/intlFormatDistance.3.6.0.js
var intlFormatDistance_3_6_0_default = intlFormatDistance_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2ludGxGb3JtYXREaXN0YW5jZS4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9pbnRsRm9ybWF0RGlzdGFuY2UubWpzIl0sIm5hbWVzIjpbImludGxGb3JtYXREaXN0YW5jZV8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiaW50bEZvcm1hdERpc3RhbmNlXzNfNl8wX2RlZmF1bHQiLCJpbnRsRm9ybWF0RGlzdGFuY2UiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2NvbnN0YW50cyIsInJlcXVpcmUiLCJpbXBvcnRfZGlmZmVyZW5jZUluQ2FsZW5kYXJEYXlzIiwiaW1wb3J0X2RpZmZlcmVuY2VJbkNhbGVuZGFyTW9udGhzIiwiaW1wb3J0X2RpZmZlcmVuY2VJbkNhbGVuZGFyUXVhcnRlcnMiLCJpbXBvcnRfZGlmZmVyZW5jZUluQ2FsZW5kYXJXZWVrcyIsImltcG9ydF9kaWZmZXJlbmNlSW5DYWxlbmRhclllYXJzIiwiaW1wb3J0X2RpZmZlcmVuY2VJbkhvdXJzIiwiaW1wb3J0X2RpZmZlcmVuY2VJbk1pbnV0ZXMiLCJpbXBvcnRfZGlmZmVyZW5jZUluU2Vjb25kcyIsImltcG9ydF90b0RhdGUiLCJkYXRlIiwiYmFzZURhdGUiLCJvcHRpb25zIiwidmFsdWUiLCJ1bml0IiwiZGF0ZUxlZnQiLCJ0b0RhdGUiLCJkYXRlUmlnaHQiLCJkaWZmSW5TZWNvbmRzIiwiZGlmZmVyZW5jZUluU2Vjb25kcyIsIk1hdGgiLCJhYnMiLCJzZWNvbmRzSW5NaW51dGUiLCJzZWNvbmRzSW5Ib3VyIiwiZGlmZmVyZW5jZUluTWludXRlcyIsInNlY29uZHNJbkRheSIsImRpZmZlcmVuY2VJbkNhbGVuZGFyRGF5cyIsImRpZmZlcmVuY2VJbkhvdXJzIiwic2Vjb25kc0luV2VlayIsInNlY29uZHNJbk1vbnRoIiwiZGlmZmVyZW5jZUluQ2FsZW5kYXJXZWVrcyIsInNlY29uZHNJblF1YXJ0ZXIiLCJkaWZmZXJlbmNlSW5DYWxlbmRhck1vbnRocyIsInNlY29uZHNJblllYXIiLCJkaWZmZXJlbmNlSW5DYWxlbmRhclF1YXJ0ZXJzIiwiZGlmZmVyZW5jZUluQ2FsZW5kYXJZZWFycyIsInJ0ZiIsIkludGwiLCJSZWxhdGl2ZVRpbWVGb3JtYXQiLCJsb2NhbGUiLCJsb2NhbGVNYXRjaGVyIiwibnVtZXJpYyIsInN0eWxlIiwiZm9ybWF0IiwiaW50bEZvcm1hdERpc3RhbmNlX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLGdDQUFBO0FBQUFDLFFBQUEsQ0FBQUQsZ0NBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLGdDQUFBO0VBQUFDLGtCQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCxnQ0FBQTs7O0FDQUEsSUFBQVEsZ0JBQUEsR0FRT0MsT0FBQTtBQUNQLElBQUFDLCtCQUFBLEdBQXlDRCxPQUFBO0FBQ3pDLElBQUFFLGlDQUFBLEdBQTJDRixPQUFBO0FBQzNDLElBQUFHLG1DQUFBLEdBQTZDSCxPQUFBO0FBQzdDLElBQUFJLGdDQUFBLEdBQTBDSixPQUFBO0FBQzFDLElBQUFLLGdDQUFBLEdBQTBDTCxPQUFBO0FBQzFDLElBQUFNLHdCQUFBLEdBQWtDTixPQUFBO0FBQ2xDLElBQUFPLDBCQUFBLEdBQW9DUCxPQUFBO0FBQ3BDLElBQUFRLDBCQUFBLEdBQW9DUixPQUFBO0FBQ3BDLElBQUFTLGFBQUEsR0FBdUJULE9BQUE7QUE2R2hCLFNBQVNMLG1CQUFtQmUsSUFBQSxFQUFNQyxRQUFBLEVBQVVDLE9BQUEsRUFBUztFQUMxRCxJQUFJQyxLQUFBLEdBQVE7RUFDWixJQUFJQyxJQUFBO0VBQ0osTUFBTUMsUUFBQSxPQUFXTixhQUFBLENBQUFPLE1BQUEsRUFBT04sSUFBSTtFQUM1QixNQUFNTyxTQUFBLE9BQVlSLGFBQUEsQ0FBQU8sTUFBQSxFQUFPTCxRQUFRO0VBRWpDLElBQUksQ0FBQ0MsT0FBQSxFQUFTRSxJQUFBLEVBQU07SUFFbEIsTUFBTUksYUFBQSxPQUFnQlYsMEJBQUEsQ0FBQVcsbUJBQUEsRUFBb0JKLFFBQUEsRUFBVUUsU0FBUztJQUU3RCxJQUFJRyxJQUFBLENBQUtDLEdBQUEsQ0FBSUgsYUFBYSxJQUFJbkIsZ0JBQUEsQ0FBQXVCLGVBQUEsRUFBaUI7TUFDN0NULEtBQUEsT0FBUUwsMEJBQUEsQ0FBQVcsbUJBQUEsRUFBb0JKLFFBQUEsRUFBVUUsU0FBUztNQUMvQ0gsSUFBQSxHQUFPO0lBQ1QsV0FBV00sSUFBQSxDQUFLQyxHQUFBLENBQUlILGFBQWEsSUFBSW5CLGdCQUFBLENBQUF3QixhQUFBLEVBQWU7TUFDbERWLEtBQUEsT0FBUU4sMEJBQUEsQ0FBQWlCLG1CQUFBLEVBQW9CVCxRQUFBLEVBQVVFLFNBQVM7TUFDL0NILElBQUEsR0FBTztJQUNULFdBQ0VNLElBQUEsQ0FBS0MsR0FBQSxDQUFJSCxhQUFhLElBQUluQixnQkFBQSxDQUFBMEIsWUFBQSxJQUMxQkwsSUFBQSxDQUFLQyxHQUFBLEtBQUlwQiwrQkFBQSxDQUFBeUIsd0JBQUEsRUFBeUJYLFFBQUEsRUFBVUUsU0FBUyxDQUFDLElBQUksR0FDMUQ7TUFDQUosS0FBQSxPQUFRUCx3QkFBQSxDQUFBcUIsaUJBQUEsRUFBa0JaLFFBQUEsRUFBVUUsU0FBUztNQUM3Q0gsSUFBQSxHQUFPO0lBQ1QsV0FDRU0sSUFBQSxDQUFLQyxHQUFBLENBQUlILGFBQWEsSUFBSW5CLGdCQUFBLENBQUE2QixhQUFBLEtBQ3pCZixLQUFBLE9BQVFaLCtCQUFBLENBQUF5Qix3QkFBQSxFQUF5QlgsUUFBQSxFQUFVRSxTQUFTLE1BQ3JERyxJQUFBLENBQUtDLEdBQUEsQ0FBSVIsS0FBSyxJQUFJLEdBQ2xCO01BQ0FDLElBQUEsR0FBTztJQUNULFdBQVdNLElBQUEsQ0FBS0MsR0FBQSxDQUFJSCxhQUFhLElBQUluQixnQkFBQSxDQUFBOEIsY0FBQSxFQUFnQjtNQUNuRGhCLEtBQUEsT0FBUVQsZ0NBQUEsQ0FBQTBCLHlCQUFBLEVBQTBCZixRQUFBLEVBQVVFLFNBQVM7TUFDckRILElBQUEsR0FBTztJQUNULFdBQVdNLElBQUEsQ0FBS0MsR0FBQSxDQUFJSCxhQUFhLElBQUluQixnQkFBQSxDQUFBZ0MsZ0JBQUEsRUFBa0I7TUFDckRsQixLQUFBLE9BQVFYLGlDQUFBLENBQUE4QiwwQkFBQSxFQUEyQmpCLFFBQUEsRUFBVUUsU0FBUztNQUN0REgsSUFBQSxHQUFPO0lBQ1QsV0FBV00sSUFBQSxDQUFLQyxHQUFBLENBQUlILGFBQWEsSUFBSW5CLGdCQUFBLENBQUFrQyxhQUFBLEVBQWU7TUFDbEQsUUFBSTlCLG1DQUFBLENBQUErQiw0QkFBQSxFQUE2Qm5CLFFBQUEsRUFBVUUsU0FBUyxJQUFJLEdBQUc7UUFFekRKLEtBQUEsT0FBUVYsbUNBQUEsQ0FBQStCLDRCQUFBLEVBQTZCbkIsUUFBQSxFQUFVRSxTQUFTO1FBQ3hESCxJQUFBLEdBQU87TUFDVCxPQUFPO1FBQ0xELEtBQUEsT0FBUVIsZ0NBQUEsQ0FBQThCLHlCQUFBLEVBQTBCcEIsUUFBQSxFQUFVRSxTQUFTO1FBQ3JESCxJQUFBLEdBQU87TUFDVDtJQUNGLE9BQU87TUFDTEQsS0FBQSxPQUFRUixnQ0FBQSxDQUFBOEIseUJBQUEsRUFBMEJwQixRQUFBLEVBQVVFLFNBQVM7TUFDckRILElBQUEsR0FBTztJQUNUO0VBQ0YsT0FBTztJQUVMQSxJQUFBLEdBQU9GLE9BQUEsRUFBU0UsSUFBQTtJQUNoQixJQUFJQSxJQUFBLEtBQVMsVUFBVTtNQUNyQkQsS0FBQSxPQUFRTCwwQkFBQSxDQUFBVyxtQkFBQSxFQUFvQkosUUFBQSxFQUFVRSxTQUFTO0lBQ2pELFdBQVdILElBQUEsS0FBUyxVQUFVO01BQzVCRCxLQUFBLE9BQVFOLDBCQUFBLENBQUFpQixtQkFBQSxFQUFvQlQsUUFBQSxFQUFVRSxTQUFTO0lBQ2pELFdBQVdILElBQUEsS0FBUyxRQUFRO01BQzFCRCxLQUFBLE9BQVFQLHdCQUFBLENBQUFxQixpQkFBQSxFQUFrQlosUUFBQSxFQUFVRSxTQUFTO0lBQy9DLFdBQVdILElBQUEsS0FBUyxPQUFPO01BQ3pCRCxLQUFBLE9BQVFaLCtCQUFBLENBQUF5Qix3QkFBQSxFQUF5QlgsUUFBQSxFQUFVRSxTQUFTO0lBQ3RELFdBQVdILElBQUEsS0FBUyxRQUFRO01BQzFCRCxLQUFBLE9BQVFULGdDQUFBLENBQUEwQix5QkFBQSxFQUEwQmYsUUFBQSxFQUFVRSxTQUFTO0lBQ3ZELFdBQVdILElBQUEsS0FBUyxTQUFTO01BQzNCRCxLQUFBLE9BQVFYLGlDQUFBLENBQUE4QiwwQkFBQSxFQUEyQmpCLFFBQUEsRUFBVUUsU0FBUztJQUN4RCxXQUFXSCxJQUFBLEtBQVMsV0FBVztNQUM3QkQsS0FBQSxPQUFRVixtQ0FBQSxDQUFBK0IsNEJBQUEsRUFBNkJuQixRQUFBLEVBQVVFLFNBQVM7SUFDMUQsV0FBV0gsSUFBQSxLQUFTLFFBQVE7TUFDMUJELEtBQUEsT0FBUVIsZ0NBQUEsQ0FBQThCLHlCQUFBLEVBQTBCcEIsUUFBQSxFQUFVRSxTQUFTO0lBQ3ZEO0VBQ0Y7RUFFQSxNQUFNbUIsR0FBQSxHQUFNLElBQUlDLElBQUEsQ0FBS0Msa0JBQUEsQ0FBbUIxQixPQUFBLEVBQVMyQixNQUFBLEVBQVE7SUFDdkRDLGFBQUEsRUFBZTVCLE9BQUEsRUFBUzRCLGFBQUE7SUFDeEJDLE9BQUEsRUFBUzdCLE9BQUEsRUFBUzZCLE9BQUEsSUFBVztJQUM3QkMsS0FBQSxFQUFPOUIsT0FBQSxFQUFTOEI7RUFDbEIsQ0FBQztFQUVELE9BQU9OLEdBQUEsQ0FBSU8sTUFBQSxDQUFPOUIsS0FBQSxFQUFPQyxJQUFJO0FBQy9CO0FBR0EsSUFBTzhCLDBCQUFBLEdBQVFqRCxrQkFBQTs7O0FEMU1mLElBQU9ELGdDQUFBLEdBQVFrRCwwQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==