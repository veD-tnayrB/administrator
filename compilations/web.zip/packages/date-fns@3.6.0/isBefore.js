System.register(["date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/isBefore.3.6.0.js
var isBefore_3_6_0_exports = {};
__export(isBefore_3_6_0_exports, {
  default: () => isBefore_3_6_0_default,
  isBefore: () => isBefore
});
module.exports = __toCommonJS(isBefore_3_6_0_exports);

// node_modules/date-fns/isBefore.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function isBefore(date, dateToCompare) {
  const _date = (0, import_toDate.toDate)(date);
  const _dateToCompare = (0, import_toDate.toDate)(dateToCompare);
  return +_date < +_dateToCompare;
}
var isBefore_default = isBefore;

// .beyond/uimport/temp/date-fns/isBefore.3.6.0.js
var isBefore_3_6_0_default = isBefore_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2lzQmVmb3JlLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2lzQmVmb3JlLm1qcyJdLCJuYW1lcyI6WyJpc0JlZm9yZV8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiaXNCZWZvcmVfM182XzBfZGVmYXVsdCIsImlzQmVmb3JlIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF90b0RhdGUiLCJyZXF1aXJlIiwiZGF0ZSIsImRhdGVUb0NvbXBhcmUiLCJfZGF0ZSIsInRvRGF0ZSIsIl9kYXRlVG9Db21wYXJlIiwiaXNCZWZvcmVfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsc0JBQUE7QUFBQUMsUUFBQSxDQUFBRCxzQkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsc0JBQUE7RUFBQUMsUUFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsc0JBQUE7OztBQ0FBLElBQUFRLGFBQUEsR0FBdUJDLE9BQUE7QUFzQmhCLFNBQVNMLFNBQVNNLElBQUEsRUFBTUMsYUFBQSxFQUFlO0VBQzVDLE1BQU1DLEtBQUEsT0FBUUosYUFBQSxDQUFBSyxNQUFBLEVBQU9ILElBQUk7RUFDekIsTUFBTUksY0FBQSxPQUFpQk4sYUFBQSxDQUFBSyxNQUFBLEVBQU9GLGFBQWE7RUFDM0MsT0FBTyxDQUFDQyxLQUFBLEdBQVEsQ0FBQ0UsY0FBQTtBQUNuQjtBQUdBLElBQU9DLGdCQUFBLEdBQVFYLFFBQUE7OztBRDFCZixJQUFPRCxzQkFBQSxHQUFRWSxnQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==