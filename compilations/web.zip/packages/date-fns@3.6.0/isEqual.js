System.register(["date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/isEqual.3.6.0.js
var isEqual_3_6_0_exports = {};
__export(isEqual_3_6_0_exports, {
  default: () => isEqual_3_6_0_default,
  isEqual: () => isEqual
});
module.exports = __toCommonJS(isEqual_3_6_0_exports);

// node_modules/date-fns/isEqual.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function isEqual(leftDate, rightDate) {
  const _dateLeft = (0, import_toDate.toDate)(leftDate);
  const _dateRight = (0, import_toDate.toDate)(rightDate);
  return +_dateLeft === +_dateRight;
}
var isEqual_default = isEqual;

// .beyond/uimport/temp/date-fns/isEqual.3.6.0.js
var isEqual_3_6_0_default = isEqual_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2lzRXF1YWwuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvaXNFcXVhbC5tanMiXSwibmFtZXMiOlsiaXNFcXVhbF8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiaXNFcXVhbF8zXzZfMF9kZWZhdWx0IiwiaXNFcXVhbCIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfdG9EYXRlIiwicmVxdWlyZSIsImxlZnREYXRlIiwicmlnaHREYXRlIiwiX2RhdGVMZWZ0IiwidG9EYXRlIiwiX2RhdGVSaWdodCIsImlzRXF1YWxfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEscUJBQUE7QUFBQUMsUUFBQSxDQUFBRCxxQkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMscUJBQUE7RUFBQUMsT0FBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAscUJBQUE7OztBQ0FBLElBQUFRLGFBQUEsR0FBdUJDLE9BQUE7QUF5QmhCLFNBQVNMLFFBQVFNLFFBQUEsRUFBVUMsU0FBQSxFQUFXO0VBQzNDLE1BQU1DLFNBQUEsT0FBWUosYUFBQSxDQUFBSyxNQUFBLEVBQU9ILFFBQVE7RUFDakMsTUFBTUksVUFBQSxPQUFhTixhQUFBLENBQUFLLE1BQUEsRUFBT0YsU0FBUztFQUNuQyxPQUFPLENBQUNDLFNBQUEsS0FBYyxDQUFDRSxVQUFBO0FBQ3pCO0FBR0EsSUFBT0MsZUFBQSxHQUFRWCxPQUFBOzs7QUQ3QmYsSUFBT0QscUJBQUEsR0FBUVksZUFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==