System.register([], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/isExists.3.6.0.js
var isExists_3_6_0_exports = {};
__export(isExists_3_6_0_exports, {
  default: () => isExists_3_6_0_default,
  isExists: () => isExists
});
module.exports = __toCommonJS(isExists_3_6_0_exports);

// node_modules/date-fns/isExists.mjs
function isExists(year, month, day) {
  const date = new Date(year, month, day);
  return date.getFullYear() === year && date.getMonth() === month && date.getDate() === day;
}
var isExists_default = isExists;

// .beyond/uimport/temp/date-fns/isExists.3.6.0.js
var isExists_3_6_0_default = isExists_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2lzRXhpc3RzLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2lzRXhpc3RzLm1qcyJdLCJuYW1lcyI6WyJpc0V4aXN0c18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiaXNFeGlzdHNfM182XzBfZGVmYXVsdCIsImlzRXhpc3RzIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsInllYXIiLCJtb250aCIsImRheSIsImRhdGUiLCJEYXRlIiwiZ2V0RnVsbFllYXIiLCJnZXRNb250aCIsImdldERhdGUiLCJpc0V4aXN0c19kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSxzQkFBQTtBQUFBQyxRQUFBLENBQUFELHNCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyxzQkFBQTtFQUFBQyxRQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCxzQkFBQTs7O0FDd0JPLFNBQVNJLFNBQVNJLElBQUEsRUFBTUMsS0FBQSxFQUFPQyxHQUFBLEVBQUs7RUFDekMsTUFBTUMsSUFBQSxHQUFPLElBQUlDLElBQUEsQ0FBS0osSUFBQSxFQUFNQyxLQUFBLEVBQU9DLEdBQUc7RUFDdEMsT0FDRUMsSUFBQSxDQUFLRSxXQUFBLENBQVksTUFBTUwsSUFBQSxJQUN2QkcsSUFBQSxDQUFLRyxRQUFBLENBQVMsTUFBTUwsS0FBQSxJQUNwQkUsSUFBQSxDQUFLSSxPQUFBLENBQVEsTUFBTUwsR0FBQTtBQUV2QjtBQUdBLElBQU9NLGdCQUFBLEdBQVFaLFFBQUE7OztBRC9CZixJQUFPRCxzQkFBQSxHQUFRYSxnQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==