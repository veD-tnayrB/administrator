System.register(["date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/isFirstDayOfMonth.3.6.0.js
var isFirstDayOfMonth_3_6_0_exports = {};
__export(isFirstDayOfMonth_3_6_0_exports, {
  default: () => isFirstDayOfMonth_3_6_0_default,
  isFirstDayOfMonth: () => isFirstDayOfMonth
});
module.exports = __toCommonJS(isFirstDayOfMonth_3_6_0_exports);

// node_modules/date-fns/isFirstDayOfMonth.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function isFirstDayOfMonth(date) {
  return (0, import_toDate.toDate)(date).getDate() === 1;
}
var isFirstDayOfMonth_default = isFirstDayOfMonth;

// .beyond/uimport/temp/date-fns/isFirstDayOfMonth.3.6.0.js
var isFirstDayOfMonth_3_6_0_default = isFirstDayOfMonth_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2lzRmlyc3REYXlPZk1vbnRoLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2lzRmlyc3REYXlPZk1vbnRoLm1qcyJdLCJuYW1lcyI6WyJpc0ZpcnN0RGF5T2ZNb250aF8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiaXNGaXJzdERheU9mTW9udGhfM182XzBfZGVmYXVsdCIsImlzRmlyc3REYXlPZk1vbnRoIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF90b0RhdGUiLCJyZXF1aXJlIiwiZGF0ZSIsInRvRGF0ZSIsImdldERhdGUiLCJpc0ZpcnN0RGF5T2ZNb250aF9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSwrQkFBQTtBQUFBQyxRQUFBLENBQUFELCtCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQywrQkFBQTtFQUFBQyxpQkFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsK0JBQUE7OztBQ0FBLElBQUFRLGFBQUEsR0FBdUJDLE9BQUE7QUFxQmhCLFNBQVNMLGtCQUFrQk0sSUFBQSxFQUFNO0VBQ3RDLFdBQU9GLGFBQUEsQ0FBQUcsTUFBQSxFQUFPRCxJQUFJLEVBQUVFLE9BQUEsQ0FBUSxNQUFNO0FBQ3BDO0FBR0EsSUFBT0MseUJBQUEsR0FBUVQsaUJBQUE7OztBRHZCZixJQUFPRCwrQkFBQSxHQUFRVSx5QkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==