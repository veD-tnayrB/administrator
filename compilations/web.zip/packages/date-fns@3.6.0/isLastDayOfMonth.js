System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/endOfDay","date-fns@3.6.0/endOfMonth"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/endOfDay', dep), dep => dependencies.set('date-fns@3.6.0/endOfMonth', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/isLastDayOfMonth.3.6.0.js
var isLastDayOfMonth_3_6_0_exports = {};
__export(isLastDayOfMonth_3_6_0_exports, {
  default: () => isLastDayOfMonth_3_6_0_default,
  isLastDayOfMonth: () => isLastDayOfMonth
});
module.exports = __toCommonJS(isLastDayOfMonth_3_6_0_exports);

// node_modules/date-fns/isLastDayOfMonth.mjs
var import_endOfDay = require("date-fns@3.6.0/endOfDay");
var import_endOfMonth = require("date-fns@3.6.0/endOfMonth");
var import_toDate = require("date-fns@3.6.0/toDate");
function isLastDayOfMonth(date) {
  const _date = (0, import_toDate.toDate)(date);
  return +(0, import_endOfDay.endOfDay)(_date) === +(0, import_endOfMonth.endOfMonth)(_date);
}
var isLastDayOfMonth_default = isLastDayOfMonth;

// .beyond/uimport/temp/date-fns/isLastDayOfMonth.3.6.0.js
var isLastDayOfMonth_3_6_0_default = isLastDayOfMonth_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2lzTGFzdERheU9mTW9udGguMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvaXNMYXN0RGF5T2ZNb250aC5tanMiXSwibmFtZXMiOlsiaXNMYXN0RGF5T2ZNb250aF8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiaXNMYXN0RGF5T2ZNb250aF8zXzZfMF9kZWZhdWx0IiwiaXNMYXN0RGF5T2ZNb250aCIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfZW5kT2ZEYXkiLCJyZXF1aXJlIiwiaW1wb3J0X2VuZE9mTW9udGgiLCJpbXBvcnRfdG9EYXRlIiwiZGF0ZSIsIl9kYXRlIiwidG9EYXRlIiwiZW5kT2ZEYXkiLCJlbmRPZk1vbnRoIiwiaXNMYXN0RGF5T2ZNb250aF9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSw4QkFBQTtBQUFBQyxRQUFBLENBQUFELDhCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyw4QkFBQTtFQUFBQyxnQkFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsOEJBQUE7OztBQ0FBLElBQUFRLGVBQUEsR0FBeUJDLE9BQUE7QUFDekIsSUFBQUMsaUJBQUEsR0FBMkJELE9BQUE7QUFDM0IsSUFBQUUsYUFBQSxHQUF1QkYsT0FBQTtBQXFCaEIsU0FBU0wsaUJBQWlCUSxJQUFBLEVBQU07RUFDckMsTUFBTUMsS0FBQSxPQUFRRixhQUFBLENBQUFHLE1BQUEsRUFBT0YsSUFBSTtFQUN6QixPQUFPLEtBQUNKLGVBQUEsQ0FBQU8sUUFBQSxFQUFTRixLQUFLLE1BQU0sS0FBQ0gsaUJBQUEsQ0FBQU0sVUFBQSxFQUFXSCxLQUFLO0FBQy9DO0FBR0EsSUFBT0ksd0JBQUEsR0FBUWIsZ0JBQUE7OztBRDFCZixJQUFPRCw4QkFBQSxHQUFRYyx3QkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==