System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/startOfDay"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfDay', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/isSameDay.3.6.0.js
var isSameDay_3_6_0_exports = {};
__export(isSameDay_3_6_0_exports, {
  default: () => isSameDay_3_6_0_default,
  isSameDay: () => isSameDay
});
module.exports = __toCommonJS(isSameDay_3_6_0_exports);

// node_modules/date-fns/isSameDay.mjs
var import_startOfDay = require("date-fns@3.6.0/startOfDay");
function isSameDay(dateLeft, dateRight) {
  const dateLeftStartOfDay = (0, import_startOfDay.startOfDay)(dateLeft);
  const dateRightStartOfDay = (0, import_startOfDay.startOfDay)(dateRight);
  return +dateLeftStartOfDay === +dateRightStartOfDay;
}
var isSameDay_default = isSameDay;

// .beyond/uimport/temp/date-fns/isSameDay.3.6.0.js
var isSameDay_3_6_0_default = isSameDay_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2lzU2FtZURheS4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9pc1NhbWVEYXkubWpzIl0sIm5hbWVzIjpbImlzU2FtZURheV8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiaXNTYW1lRGF5XzNfNl8wX2RlZmF1bHQiLCJpc1NhbWVEYXkiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X3N0YXJ0T2ZEYXkiLCJyZXF1aXJlIiwiZGF0ZUxlZnQiLCJkYXRlUmlnaHQiLCJkYXRlTGVmdFN0YXJ0T2ZEYXkiLCJzdGFydE9mRGF5IiwiZGF0ZVJpZ2h0U3RhcnRPZkRheSIsImlzU2FtZURheV9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSx1QkFBQTtBQUFBQyxRQUFBLENBQUFELHVCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyx1QkFBQTtFQUFBQyxTQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCx1QkFBQTs7O0FDQUEsSUFBQVEsaUJBQUEsR0FBMkJDLE9BQUE7QUFnQ3BCLFNBQVNMLFVBQVVNLFFBQUEsRUFBVUMsU0FBQSxFQUFXO0VBQzdDLE1BQU1DLGtCQUFBLE9BQXFCSixpQkFBQSxDQUFBSyxVQUFBLEVBQVdILFFBQVE7RUFDOUMsTUFBTUksbUJBQUEsT0FBc0JOLGlCQUFBLENBQUFLLFVBQUEsRUFBV0YsU0FBUztFQUVoRCxPQUFPLENBQUNDLGtCQUFBLEtBQXVCLENBQUNFLG1CQUFBO0FBQ2xDO0FBR0EsSUFBT0MsaUJBQUEsR0FBUVgsU0FBQTs7O0FEckNmLElBQU9ELHVCQUFBLEdBQVFZLGlCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9