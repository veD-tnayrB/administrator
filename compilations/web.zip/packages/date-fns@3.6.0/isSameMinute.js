System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/startOfMinute"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfMinute', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/isSameMinute.3.6.0.js
var isSameMinute_3_6_0_exports = {};
__export(isSameMinute_3_6_0_exports, {
  default: () => isSameMinute_3_6_0_default,
  isSameMinute: () => isSameMinute
});
module.exports = __toCommonJS(isSameMinute_3_6_0_exports);

// node_modules/date-fns/isSameMinute.mjs
var import_startOfMinute = require("date-fns@3.6.0/startOfMinute");
function isSameMinute(dateLeft, dateRight) {
  const dateLeftStartOfMinute = (0, import_startOfMinute.startOfMinute)(dateLeft);
  const dateRightStartOfMinute = (0, import_startOfMinute.startOfMinute)(dateRight);
  return +dateLeftStartOfMinute === +dateRightStartOfMinute;
}
var isSameMinute_default = isSameMinute;

// .beyond/uimport/temp/date-fns/isSameMinute.3.6.0.js
var isSameMinute_3_6_0_default = isSameMinute_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2lzU2FtZU1pbnV0ZS4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9pc1NhbWVNaW51dGUubWpzIl0sIm5hbWVzIjpbImlzU2FtZU1pbnV0ZV8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiaXNTYW1lTWludXRlXzNfNl8wX2RlZmF1bHQiLCJpc1NhbWVNaW51dGUiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X3N0YXJ0T2ZNaW51dGUiLCJyZXF1aXJlIiwiZGF0ZUxlZnQiLCJkYXRlUmlnaHQiLCJkYXRlTGVmdFN0YXJ0T2ZNaW51dGUiLCJzdGFydE9mTWludXRlIiwiZGF0ZVJpZ2h0U3RhcnRPZk1pbnV0ZSIsImlzU2FtZU1pbnV0ZV9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSwwQkFBQTtBQUFBQyxRQUFBLENBQUFELDBCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQywwQkFBQTtFQUFBQyxZQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCwwQkFBQTs7O0FDQUEsSUFBQVEsb0JBQUEsR0FBOEJDLE9BQUE7QUFpQ3ZCLFNBQVNMLGFBQWFNLFFBQUEsRUFBVUMsU0FBQSxFQUFXO0VBQ2hELE1BQU1DLHFCQUFBLE9BQXdCSixvQkFBQSxDQUFBSyxhQUFBLEVBQWNILFFBQVE7RUFDcEQsTUFBTUksc0JBQUEsT0FBeUJOLG9CQUFBLENBQUFLLGFBQUEsRUFBY0YsU0FBUztFQUV0RCxPQUFPLENBQUNDLHFCQUFBLEtBQTBCLENBQUNFLHNCQUFBO0FBQ3JDO0FBR0EsSUFBT0Msb0JBQUEsR0FBUVgsWUFBQTs7O0FEdENmLElBQU9ELDBCQUFBLEdBQVFZLG9CQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9