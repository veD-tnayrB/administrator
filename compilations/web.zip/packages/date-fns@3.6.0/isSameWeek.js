System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/startOfWeek"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfWeek', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/isSameWeek.3.6.0.js
var isSameWeek_3_6_0_exports = {};
__export(isSameWeek_3_6_0_exports, {
  default: () => isSameWeek_3_6_0_default,
  isSameWeek: () => isSameWeek
});
module.exports = __toCommonJS(isSameWeek_3_6_0_exports);

// node_modules/date-fns/isSameWeek.mjs
var import_startOfWeek = require("date-fns@3.6.0/startOfWeek");
function isSameWeek(dateLeft, dateRight, options) {
  const dateLeftStartOfWeek = (0, import_startOfWeek.startOfWeek)(dateLeft, options);
  const dateRightStartOfWeek = (0, import_startOfWeek.startOfWeek)(dateRight, options);
  return +dateLeftStartOfWeek === +dateRightStartOfWeek;
}
var isSameWeek_default = isSameWeek;

// .beyond/uimport/temp/date-fns/isSameWeek.3.6.0.js
var isSameWeek_3_6_0_default = isSameWeek_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2lzU2FtZVdlZWsuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvaXNTYW1lV2Vlay5tanMiXSwibmFtZXMiOlsiaXNTYW1lV2Vla18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiaXNTYW1lV2Vla18zXzZfMF9kZWZhdWx0IiwiaXNTYW1lV2VlayIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfc3RhcnRPZldlZWsiLCJyZXF1aXJlIiwiZGF0ZUxlZnQiLCJkYXRlUmlnaHQiLCJvcHRpb25zIiwiZGF0ZUxlZnRTdGFydE9mV2VlayIsInN0YXJ0T2ZXZWVrIiwiZGF0ZVJpZ2h0U3RhcnRPZldlZWsiLCJpc1NhbWVXZWVrX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLHdCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsd0JBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLHdCQUFBO0VBQUFDLFVBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLHdCQUFBOzs7QUNBQSxJQUFBUSxrQkFBQSxHQUE0QkMsT0FBQTtBQXdDckIsU0FBU0wsV0FBV00sUUFBQSxFQUFVQyxTQUFBLEVBQVdDLE9BQUEsRUFBUztFQUN2RCxNQUFNQyxtQkFBQSxPQUFzQkwsa0JBQUEsQ0FBQU0sV0FBQSxFQUFZSixRQUFBLEVBQVVFLE9BQU87RUFDekQsTUFBTUcsb0JBQUEsT0FBdUJQLGtCQUFBLENBQUFNLFdBQUEsRUFBWUgsU0FBQSxFQUFXQyxPQUFPO0VBRTNELE9BQU8sQ0FBQ0MsbUJBQUEsS0FBd0IsQ0FBQ0Usb0JBQUE7QUFDbkM7QUFHQSxJQUFPQyxrQkFBQSxHQUFRWixVQUFBOzs7QUQ3Q2YsSUFBT0Qsd0JBQUEsR0FBUWEsa0JBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=