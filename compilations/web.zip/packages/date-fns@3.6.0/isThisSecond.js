System.register(["date-fns@3.6.0/constructFrom","date-fns@3.6.0/constructNow","date-fns@3.6.0/toDate","date-fns@3.6.0/startOfSecond","date-fns@3.6.0/isSameSecond"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/constructNow', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfSecond', dep), dep => dependencies.set('date-fns@3.6.0/isSameSecond', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/isThisSecond.3.6.0.js
var isThisSecond_3_6_0_exports = {};
__export(isThisSecond_3_6_0_exports, {
  default: () => isThisSecond_3_6_0_default,
  isThisSecond: () => isThisSecond
});
module.exports = __toCommonJS(isThisSecond_3_6_0_exports);

// node_modules/date-fns/isThisSecond.mjs
var import_constructNow = require("date-fns@3.6.0/constructNow");
var import_isSameSecond = require("date-fns@3.6.0/isSameSecond");
function isThisSecond(date) {
  return (0, import_isSameSecond.isSameSecond)(date, (0, import_constructNow.constructNow)(date));
}
var isThisSecond_default = isThisSecond;

// .beyond/uimport/temp/date-fns/isThisSecond.3.6.0.js
var isThisSecond_3_6_0_default = isThisSecond_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2lzVGhpc1NlY29uZC4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9pc1RoaXNTZWNvbmQubWpzIl0sIm5hbWVzIjpbImlzVGhpc1NlY29uZF8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiaXNUaGlzU2Vjb25kXzNfNl8wX2RlZmF1bHQiLCJpc1RoaXNTZWNvbmQiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2NvbnN0cnVjdE5vdyIsInJlcXVpcmUiLCJpbXBvcnRfaXNTYW1lU2Vjb25kIiwiZGF0ZSIsImlzU2FtZVNlY29uZCIsImNvbnN0cnVjdE5vdyIsImlzVGhpc1NlY29uZF9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSwwQkFBQTtBQUFBQyxRQUFBLENBQUFELDBCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQywwQkFBQTtFQUFBQyxZQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCwwQkFBQTs7O0FDQUEsSUFBQVEsbUJBQUEsR0FBNkJDLE9BQUE7QUFDN0IsSUFBQUMsbUJBQUEsR0FBNkJELE9BQUE7QUF1QnRCLFNBQVNMLGFBQWFPLElBQUEsRUFBTTtFQUNqQyxXQUFPRCxtQkFBQSxDQUFBRSxZQUFBLEVBQWFELElBQUEsTUFBTUgsbUJBQUEsQ0FBQUssWUFBQSxFQUFhRixJQUFJLENBQUM7QUFDOUM7QUFHQSxJQUFPRyxvQkFBQSxHQUFRVixZQUFBOzs7QUQxQmYsSUFBT0QsMEJBQUEsR0FBUVcsb0JBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=