System.register(["date-fns@3.6.0/constructFrom","date-fns@3.6.0/constructNow","date-fns@3.6.0/toDate","date-fns@3.6.0/startOfWeek","date-fns@3.6.0/isSameWeek"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/constructNow', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfWeek', dep), dep => dependencies.set('date-fns@3.6.0/isSameWeek', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/isThisWeek.3.6.0.js
var isThisWeek_3_6_0_exports = {};
__export(isThisWeek_3_6_0_exports, {
  default: () => isThisWeek_3_6_0_default,
  isThisWeek: () => isThisWeek
});
module.exports = __toCommonJS(isThisWeek_3_6_0_exports);

// node_modules/date-fns/isThisWeek.mjs
var import_constructNow = require("date-fns@3.6.0/constructNow");
var import_isSameWeek = require("date-fns@3.6.0/isSameWeek");
function isThisWeek(date, options) {
  return (0, import_isSameWeek.isSameWeek)(date, (0, import_constructNow.constructNow)(date), options);
}
var isThisWeek_default = isThisWeek;

// .beyond/uimport/temp/date-fns/isThisWeek.3.6.0.js
var isThisWeek_3_6_0_default = isThisWeek_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2lzVGhpc1dlZWsuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvaXNUaGlzV2Vlay5tanMiXSwibmFtZXMiOlsiaXNUaGlzV2Vla18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiaXNUaGlzV2Vla18zXzZfMF9kZWZhdWx0IiwiaXNUaGlzV2VlayIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfY29uc3RydWN0Tm93IiwicmVxdWlyZSIsImltcG9ydF9pc1NhbWVXZWVrIiwiZGF0ZSIsIm9wdGlvbnMiLCJpc1NhbWVXZWVrIiwiY29uc3RydWN0Tm93IiwiaXNUaGlzV2Vla19kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSx3QkFBQTtBQUFBQyxRQUFBLENBQUFELHdCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyx3QkFBQTtFQUFBQyxVQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCx3QkFBQTs7O0FDQUEsSUFBQVEsbUJBQUEsR0FBNkJDLE9BQUE7QUFDN0IsSUFBQUMsaUJBQUEsR0FBMkJELE9BQUE7QUFpQ3BCLFNBQVNMLFdBQVdPLElBQUEsRUFBTUMsT0FBQSxFQUFTO0VBQ3hDLFdBQU9GLGlCQUFBLENBQUFHLFVBQUEsRUFBV0YsSUFBQSxNQUFNSCxtQkFBQSxDQUFBTSxZQUFBLEVBQWFILElBQUksR0FBR0MsT0FBTztBQUNyRDtBQUdBLElBQU9HLGtCQUFBLEdBQVFYLFVBQUE7OztBRHBDZixJQUFPRCx3QkFBQSxHQUFRWSxrQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==