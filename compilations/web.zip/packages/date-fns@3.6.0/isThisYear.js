System.register(["date-fns@3.6.0/constructFrom","date-fns@3.6.0/constructNow","date-fns@3.6.0/toDate","date-fns@3.6.0/isSameYear"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/constructNow', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/isSameYear', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/isThisYear.3.6.0.js
var isThisYear_3_6_0_exports = {};
__export(isThisYear_3_6_0_exports, {
  default: () => isThisYear_3_6_0_default,
  isThisYear: () => isThisYear
});
module.exports = __toCommonJS(isThisYear_3_6_0_exports);

// node_modules/date-fns/isThisYear.mjs
var import_constructNow = require("date-fns@3.6.0/constructNow");
var import_isSameYear = require("date-fns@3.6.0/isSameYear");
function isThisYear(date) {
  return (0, import_isSameYear.isSameYear)(date, (0, import_constructNow.constructNow)(date));
}
var isThisYear_default = isThisYear;

// .beyond/uimport/temp/date-fns/isThisYear.3.6.0.js
var isThisYear_3_6_0_default = isThisYear_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2lzVGhpc1llYXIuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvaXNUaGlzWWVhci5tanMiXSwibmFtZXMiOlsiaXNUaGlzWWVhcl8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiaXNUaGlzWWVhcl8zXzZfMF9kZWZhdWx0IiwiaXNUaGlzWWVhciIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfY29uc3RydWN0Tm93IiwicmVxdWlyZSIsImltcG9ydF9pc1NhbWVZZWFyIiwiZGF0ZSIsImlzU2FtZVllYXIiLCJjb25zdHJ1Y3ROb3ciLCJpc1RoaXNZZWFyX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLHdCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsd0JBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLHdCQUFBO0VBQUFDLFVBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLHdCQUFBOzs7QUNBQSxJQUFBUSxtQkFBQSxHQUE2QkMsT0FBQTtBQUM3QixJQUFBQyxpQkFBQSxHQUEyQkQsT0FBQTtBQXNCcEIsU0FBU0wsV0FBV08sSUFBQSxFQUFNO0VBQy9CLFdBQU9ELGlCQUFBLENBQUFFLFVBQUEsRUFBV0QsSUFBQSxNQUFNSCxtQkFBQSxDQUFBSyxZQUFBLEVBQWFGLElBQUksQ0FBQztBQUM1QztBQUdBLElBQU9HLGtCQUFBLEdBQVFWLFVBQUE7OztBRHpCZixJQUFPRCx3QkFBQSxHQUFRVyxrQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==