System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/constructFrom","date-fns@3.6.0/addDays","date-fns@3.6.0/constructNow","date-fns@3.6.0/startOfDay","date-fns@3.6.0/isSameDay"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/addDays', dep), dep => dependencies.set('date-fns@3.6.0/constructNow', dep), dep => dependencies.set('date-fns@3.6.0/startOfDay', dep), dep => dependencies.set('date-fns@3.6.0/isSameDay', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/isTomorrow.3.6.0.js
var isTomorrow_3_6_0_exports = {};
__export(isTomorrow_3_6_0_exports, {
  default: () => isTomorrow_3_6_0_default,
  isTomorrow: () => isTomorrow
});
module.exports = __toCommonJS(isTomorrow_3_6_0_exports);

// node_modules/date-fns/isTomorrow.mjs
var import_addDays = require("date-fns@3.6.0/addDays");
var import_constructNow = require("date-fns@3.6.0/constructNow");
var import_isSameDay = require("date-fns@3.6.0/isSameDay");
function isTomorrow(date) {
  return (0, import_isSameDay.isSameDay)(date, (0, import_addDays.addDays)((0, import_constructNow.constructNow)(date), 1));
}
var isTomorrow_default = isTomorrow;

// .beyond/uimport/temp/date-fns/isTomorrow.3.6.0.js
var isTomorrow_3_6_0_default = isTomorrow_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2lzVG9tb3Jyb3cuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvaXNUb21vcnJvdy5tanMiXSwibmFtZXMiOlsiaXNUb21vcnJvd18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiaXNUb21vcnJvd18zXzZfMF9kZWZhdWx0IiwiaXNUb21vcnJvdyIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfYWRkRGF5cyIsInJlcXVpcmUiLCJpbXBvcnRfY29uc3RydWN0Tm93IiwiaW1wb3J0X2lzU2FtZURheSIsImRhdGUiLCJpc1NhbWVEYXkiLCJhZGREYXlzIiwiY29uc3RydWN0Tm93IiwiaXNUb21vcnJvd19kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSx3QkFBQTtBQUFBQyxRQUFBLENBQUFELHdCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyx3QkFBQTtFQUFBQyxVQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCx3QkFBQTs7O0FDQUEsSUFBQVEsY0FBQSxHQUF3QkMsT0FBQTtBQUN4QixJQUFBQyxtQkFBQSxHQUE2QkQsT0FBQTtBQUM3QixJQUFBRSxnQkFBQSxHQUEwQkYsT0FBQTtBQXNCbkIsU0FBU0wsV0FBV1EsSUFBQSxFQUFNO0VBQy9CLFdBQU9ELGdCQUFBLENBQUFFLFNBQUEsRUFBVUQsSUFBQSxNQUFNSixjQUFBLENBQUFNLE9BQUEsTUFBUUosbUJBQUEsQ0FBQUssWUFBQSxFQUFhSCxJQUFJLEdBQUcsQ0FBQyxDQUFDO0FBQ3ZEO0FBR0EsSUFBT0ksa0JBQUEsR0FBUVosVUFBQTs7O0FEMUJmLElBQU9ELHdCQUFBLEdBQVFhLGtCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9