System.register(["date-fns@3.6.0/constructFrom","date-fns@3.6.0/constructNow","date-fns@3.6.0/toDate","date-fns@3.6.0/startOfDay","date-fns@3.6.0/isSameDay","date-fns@3.6.0/addDays","date-fns@3.6.0/subDays"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/constructNow', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfDay', dep), dep => dependencies.set('date-fns@3.6.0/isSameDay', dep), dep => dependencies.set('date-fns@3.6.0/addDays', dep), dep => dependencies.set('date-fns@3.6.0/subDays', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/isYesterday.3.6.0.js
var isYesterday_3_6_0_exports = {};
__export(isYesterday_3_6_0_exports, {
  default: () => isYesterday_3_6_0_default,
  isYesterday: () => isYesterday
});
module.exports = __toCommonJS(isYesterday_3_6_0_exports);

// node_modules/date-fns/isYesterday.mjs
var import_constructNow = require("date-fns@3.6.0/constructNow");
var import_isSameDay = require("date-fns@3.6.0/isSameDay");
var import_subDays = require("date-fns@3.6.0/subDays");
function isYesterday(date) {
  return (0, import_isSameDay.isSameDay)(date, (0, import_subDays.subDays)((0, import_constructNow.constructNow)(date), 1));
}
var isYesterday_default = isYesterday;

// .beyond/uimport/temp/date-fns/isYesterday.3.6.0.js
var isYesterday_3_6_0_default = isYesterday_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2lzWWVzdGVyZGF5LjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2lzWWVzdGVyZGF5Lm1qcyJdLCJuYW1lcyI6WyJpc1llc3RlcmRheV8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwiaXNZZXN0ZXJkYXlfM182XzBfZGVmYXVsdCIsImlzWWVzdGVyZGF5IiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF9jb25zdHJ1Y3ROb3ciLCJyZXF1aXJlIiwiaW1wb3J0X2lzU2FtZURheSIsImltcG9ydF9zdWJEYXlzIiwiZGF0ZSIsImlzU2FtZURheSIsInN1YkRheXMiLCJjb25zdHJ1Y3ROb3ciLCJpc1llc3RlcmRheV9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSx5QkFBQTtBQUFBQyxRQUFBLENBQUFELHlCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyx5QkFBQTtFQUFBQyxXQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCx5QkFBQTs7O0FDQUEsSUFBQVEsbUJBQUEsR0FBNkJDLE9BQUE7QUFDN0IsSUFBQUMsZ0JBQUEsR0FBMEJELE9BQUE7QUFDMUIsSUFBQUUsY0FBQSxHQUF3QkYsT0FBQTtBQXNCakIsU0FBU0wsWUFBWVEsSUFBQSxFQUFNO0VBQ2hDLFdBQU9GLGdCQUFBLENBQUFHLFNBQUEsRUFBVUQsSUFBQSxNQUFNRCxjQUFBLENBQUFHLE9BQUEsTUFBUU4sbUJBQUEsQ0FBQU8sWUFBQSxFQUFhSCxJQUFJLEdBQUcsQ0FBQyxDQUFDO0FBQ3ZEO0FBR0EsSUFBT0ksbUJBQUEsR0FBUVosV0FBQTs7O0FEMUJmLElBQU9ELHlCQUFBLEdBQVFhLG1CQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9