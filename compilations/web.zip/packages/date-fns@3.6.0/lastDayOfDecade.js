System.register(["date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/lastDayOfDecade.3.6.0.js
var lastDayOfDecade_3_6_0_exports = {};
__export(lastDayOfDecade_3_6_0_exports, {
  default: () => lastDayOfDecade_3_6_0_default,
  lastDayOfDecade: () => lastDayOfDecade
});
module.exports = __toCommonJS(lastDayOfDecade_3_6_0_exports);

// node_modules/date-fns/lastDayOfDecade.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function lastDayOfDecade(date) {
  const _date = (0, import_toDate.toDate)(date);
  const year = _date.getFullYear();
  const decade = 9 + Math.floor(year / 10) * 10;
  _date.setFullYear(decade + 1, 0, 0);
  _date.setHours(0, 0, 0, 0);
  return _date;
}
var lastDayOfDecade_default = lastDayOfDecade;

// .beyond/uimport/temp/date-fns/lastDayOfDecade.3.6.0.js
var lastDayOfDecade_3_6_0_default = lastDayOfDecade_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2xhc3REYXlPZkRlY2FkZS4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9sYXN0RGF5T2ZEZWNhZGUubWpzIl0sIm5hbWVzIjpbImxhc3REYXlPZkRlY2FkZV8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwibGFzdERheU9mRGVjYWRlXzNfNl8wX2RlZmF1bHQiLCJsYXN0RGF5T2ZEZWNhZGUiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X3RvRGF0ZSIsInJlcXVpcmUiLCJkYXRlIiwiX2RhdGUiLCJ0b0RhdGUiLCJ5ZWFyIiwiZ2V0RnVsbFllYXIiLCJkZWNhZGUiLCJNYXRoIiwiZmxvb3IiLCJzZXRGdWxsWWVhciIsInNldEhvdXJzIiwibGFzdERheU9mRGVjYWRlX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLDZCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsNkJBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLDZCQUFBO0VBQUFDLGVBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLDZCQUFBOzs7QUNBQSxJQUFBUSxhQUFBLEdBQXVCQyxPQUFBO0FBcUJoQixTQUFTTCxnQkFBZ0JNLElBQUEsRUFBTTtFQUlwQyxNQUFNQyxLQUFBLE9BQVFILGFBQUEsQ0FBQUksTUFBQSxFQUFPRixJQUFJO0VBQ3pCLE1BQU1HLElBQUEsR0FBT0YsS0FBQSxDQUFNRyxXQUFBLENBQVk7RUFDL0IsTUFBTUMsTUFBQSxHQUFTLElBQUlDLElBQUEsQ0FBS0MsS0FBQSxDQUFNSixJQUFBLEdBQU8sRUFBRSxJQUFJO0VBQzNDRixLQUFBLENBQU1PLFdBQUEsQ0FBWUgsTUFBQSxHQUFTLEdBQUcsR0FBRyxDQUFDO0VBQ2xDSixLQUFBLENBQU1RLFFBQUEsQ0FBUyxHQUFHLEdBQUcsR0FBRyxDQUFDO0VBQ3pCLE9BQU9SLEtBQUE7QUFDVDtBQUdBLElBQU9TLHVCQUFBLEdBQVFoQixlQUFBOzs7QUQvQmYsSUFBT0QsNkJBQUEsR0FBUWlCLHVCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9