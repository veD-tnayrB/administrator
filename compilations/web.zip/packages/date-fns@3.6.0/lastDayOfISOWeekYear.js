System.register(["date-fns@3.6.0/constructFrom","date-fns@3.6.0/toDate","date-fns@3.6.0/startOfWeek","date-fns@3.6.0/startOfISOWeek","date-fns@3.6.0/getISOWeekYear"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfWeek', dep), dep => dependencies.set('date-fns@3.6.0/startOfISOWeek', dep), dep => dependencies.set('date-fns@3.6.0/getISOWeekYear', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/lastDayOfISOWeekYear.3.6.0.js
var lastDayOfISOWeekYear_3_6_0_exports = {};
__export(lastDayOfISOWeekYear_3_6_0_exports, {
  default: () => lastDayOfISOWeekYear_3_6_0_default,
  lastDayOfISOWeekYear: () => lastDayOfISOWeekYear
});
module.exports = __toCommonJS(lastDayOfISOWeekYear_3_6_0_exports);

// node_modules/date-fns/lastDayOfISOWeekYear.mjs
var import_getISOWeekYear = require("date-fns@3.6.0/getISOWeekYear");
var import_startOfISOWeek = require("date-fns@3.6.0/startOfISOWeek");
var import_constructFrom = require("date-fns@3.6.0/constructFrom");
function lastDayOfISOWeekYear(date) {
  const year = (0, import_getISOWeekYear.getISOWeekYear)(date);
  const fourthOfJanuary = (0, import_constructFrom.constructFrom)(date, 0);
  fourthOfJanuary.setFullYear(year + 1, 0, 4);
  fourthOfJanuary.setHours(0, 0, 0, 0);
  const _date = (0, import_startOfISOWeek.startOfISOWeek)(fourthOfJanuary);
  _date.setDate(_date.getDate() - 1);
  return _date;
}
var lastDayOfISOWeekYear_default = lastDayOfISOWeekYear;

// .beyond/uimport/temp/date-fns/lastDayOfISOWeekYear.3.6.0.js
var lastDayOfISOWeekYear_3_6_0_default = lastDayOfISOWeekYear_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2xhc3REYXlPZklTT1dlZWtZZWFyLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xhc3REYXlPZklTT1dlZWtZZWFyLm1qcyJdLCJuYW1lcyI6WyJsYXN0RGF5T2ZJU09XZWVrWWVhcl8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwibGFzdERheU9mSVNPV2Vla1llYXJfM182XzBfZGVmYXVsdCIsImxhc3REYXlPZklTT1dlZWtZZWFyIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF9nZXRJU09XZWVrWWVhciIsInJlcXVpcmUiLCJpbXBvcnRfc3RhcnRPZklTT1dlZWsiLCJpbXBvcnRfY29uc3RydWN0RnJvbSIsImRhdGUiLCJ5ZWFyIiwiZ2V0SVNPV2Vla1llYXIiLCJmb3VydGhPZkphbnVhcnkiLCJjb25zdHJ1Y3RGcm9tIiwic2V0RnVsbFllYXIiLCJzZXRIb3VycyIsIl9kYXRlIiwic3RhcnRPZklTT1dlZWsiLCJzZXREYXRlIiwiZ2V0RGF0ZSIsImxhc3REYXlPZklTT1dlZWtZZWFyX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLGtDQUFBO0FBQUFDLFFBQUEsQ0FBQUQsa0NBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLGtDQUFBO0VBQUFDLG9CQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCxrQ0FBQTs7O0FDQUEsSUFBQVEscUJBQUEsR0FBK0JDLE9BQUE7QUFDL0IsSUFBQUMscUJBQUEsR0FBK0JELE9BQUE7QUFDL0IsSUFBQUUsb0JBQUEsR0FBOEJGLE9BQUE7QUF5QnZCLFNBQVNMLHFCQUFxQlEsSUFBQSxFQUFNO0VBQ3pDLE1BQU1DLElBQUEsT0FBT0wscUJBQUEsQ0FBQU0sY0FBQSxFQUFlRixJQUFJO0VBQ2hDLE1BQU1HLGVBQUEsT0FBa0JKLG9CQUFBLENBQUFLLGFBQUEsRUFBY0osSUFBQSxFQUFNLENBQUM7RUFDN0NHLGVBQUEsQ0FBZ0JFLFdBQUEsQ0FBWUosSUFBQSxHQUFPLEdBQUcsR0FBRyxDQUFDO0VBQzFDRSxlQUFBLENBQWdCRyxRQUFBLENBQVMsR0FBRyxHQUFHLEdBQUcsQ0FBQztFQUNuQyxNQUFNQyxLQUFBLE9BQVFULHFCQUFBLENBQUFVLGNBQUEsRUFBZUwsZUFBZTtFQUM1Q0ksS0FBQSxDQUFNRSxPQUFBLENBQVFGLEtBQUEsQ0FBTUcsT0FBQSxDQUFRLElBQUksQ0FBQztFQUNqQyxPQUFPSCxLQUFBO0FBQ1Q7QUFHQSxJQUFPSSw0QkFBQSxHQUFRbkIsb0JBQUE7OztBRG5DZixJQUFPRCxrQ0FBQSxHQUFRb0IsNEJBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=