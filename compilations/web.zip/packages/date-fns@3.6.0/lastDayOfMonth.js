System.register(["date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/lastDayOfMonth.3.6.0.js
var lastDayOfMonth_3_6_0_exports = {};
__export(lastDayOfMonth_3_6_0_exports, {
  default: () => lastDayOfMonth_3_6_0_default,
  lastDayOfMonth: () => lastDayOfMonth
});
module.exports = __toCommonJS(lastDayOfMonth_3_6_0_exports);

// node_modules/date-fns/lastDayOfMonth.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function lastDayOfMonth(date) {
  const _date = (0, import_toDate.toDate)(date);
  const month = _date.getMonth();
  _date.setFullYear(_date.getFullYear(), month + 1, 0);
  _date.setHours(0, 0, 0, 0);
  return _date;
}
var lastDayOfMonth_default = lastDayOfMonth;

// .beyond/uimport/temp/date-fns/lastDayOfMonth.3.6.0.js
var lastDayOfMonth_3_6_0_default = lastDayOfMonth_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2xhc3REYXlPZk1vbnRoLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xhc3REYXlPZk1vbnRoLm1qcyJdLCJuYW1lcyI6WyJsYXN0RGF5T2ZNb250aF8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwibGFzdERheU9mTW9udGhfM182XzBfZGVmYXVsdCIsImxhc3REYXlPZk1vbnRoIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF90b0RhdGUiLCJyZXF1aXJlIiwiZGF0ZSIsIl9kYXRlIiwidG9EYXRlIiwibW9udGgiLCJnZXRNb250aCIsInNldEZ1bGxZZWFyIiwiZ2V0RnVsbFllYXIiLCJzZXRIb3VycyIsImxhc3REYXlPZk1vbnRoX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLDRCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsNEJBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLDRCQUFBO0VBQUFDLGNBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLDRCQUFBOzs7QUNBQSxJQUFBUSxhQUFBLEdBQXVCQyxPQUFBO0FBc0JoQixTQUFTTCxlQUFlTSxJQUFBLEVBQU07RUFDbkMsTUFBTUMsS0FBQSxPQUFRSCxhQUFBLENBQUFJLE1BQUEsRUFBT0YsSUFBSTtFQUN6QixNQUFNRyxLQUFBLEdBQVFGLEtBQUEsQ0FBTUcsUUFBQSxDQUFTO0VBQzdCSCxLQUFBLENBQU1JLFdBQUEsQ0FBWUosS0FBQSxDQUFNSyxXQUFBLENBQVksR0FBR0gsS0FBQSxHQUFRLEdBQUcsQ0FBQztFQUNuREYsS0FBQSxDQUFNTSxRQUFBLENBQVMsR0FBRyxHQUFHLEdBQUcsQ0FBQztFQUN6QixPQUFPTixLQUFBO0FBQ1Q7QUFHQSxJQUFPTyxzQkFBQSxHQUFRZCxjQUFBOzs7QUQ1QmYsSUFBT0QsNEJBQUEsR0FBUWUsc0JBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=