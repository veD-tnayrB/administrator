System.register(["date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/lastDayOfYear.3.6.0.js
var lastDayOfYear_3_6_0_exports = {};
__export(lastDayOfYear_3_6_0_exports, {
  default: () => lastDayOfYear_3_6_0_default,
  lastDayOfYear: () => lastDayOfYear
});
module.exports = __toCommonJS(lastDayOfYear_3_6_0_exports);

// node_modules/date-fns/lastDayOfYear.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function lastDayOfYear(date) {
  const _date = (0, import_toDate.toDate)(date);
  const year = _date.getFullYear();
  _date.setFullYear(year + 1, 0, 0);
  _date.setHours(0, 0, 0, 0);
  return _date;
}
var lastDayOfYear_default = lastDayOfYear;

// .beyond/uimport/temp/date-fns/lastDayOfYear.3.6.0.js
var lastDayOfYear_3_6_0_default = lastDayOfYear_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2xhc3REYXlPZlllYXIuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvbGFzdERheU9mWWVhci5tanMiXSwibmFtZXMiOlsibGFzdERheU9mWWVhcl8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwibGFzdERheU9mWWVhcl8zXzZfMF9kZWZhdWx0IiwibGFzdERheU9mWWVhciIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfdG9EYXRlIiwicmVxdWlyZSIsImRhdGUiLCJfZGF0ZSIsInRvRGF0ZSIsInllYXIiLCJnZXRGdWxsWWVhciIsInNldEZ1bGxZZWFyIiwic2V0SG91cnMiLCJsYXN0RGF5T2ZZZWFyX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLDJCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsMkJBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLDJCQUFBO0VBQUFDLGFBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLDJCQUFBOzs7QUNBQSxJQUFBUSxhQUFBLEdBQXVCQyxPQUFBO0FBc0JoQixTQUFTTCxjQUFjTSxJQUFBLEVBQU07RUFDbEMsTUFBTUMsS0FBQSxPQUFRSCxhQUFBLENBQUFJLE1BQUEsRUFBT0YsSUFBSTtFQUN6QixNQUFNRyxJQUFBLEdBQU9GLEtBQUEsQ0FBTUcsV0FBQSxDQUFZO0VBQy9CSCxLQUFBLENBQU1JLFdBQUEsQ0FBWUYsSUFBQSxHQUFPLEdBQUcsR0FBRyxDQUFDO0VBQ2hDRixLQUFBLENBQU1LLFFBQUEsQ0FBUyxHQUFHLEdBQUcsR0FBRyxDQUFDO0VBQ3pCLE9BQU9MLEtBQUE7QUFDVDtBQUdBLElBQU9NLHFCQUFBLEdBQVFiLGFBQUE7OztBRDVCZixJQUFPRCwyQkFBQSxHQUFRYyxxQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==