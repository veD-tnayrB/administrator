System.register(["date-fns@3.6.0/isDate","date-fns@3.6.0/toDate","date-fns@3.6.0/isValid"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/isDate', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/isValid', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/lightFormat.3.6.0.js
var lightFormat_3_6_0_exports = {};
__export(lightFormat_3_6_0_exports, {
  default: () => lightFormat_3_6_0_default,
  lightFormat: () => lightFormat,
  lightFormatters: () => lightFormatters
});
module.exports = __toCommonJS(lightFormat_3_6_0_exports);

// node_modules/date-fns/_lib/addLeadingZeros.mjs
function addLeadingZeros(number, targetLength) {
  const sign = number < 0 ? "-" : "";
  const output = Math.abs(number).toString().padStart(targetLength, "0");
  return sign + output;
}

// node_modules/date-fns/_lib/format/lightFormatters.mjs
var lightFormatters = {
  y(date, token) {
    const signedYear = date.getFullYear();
    const year = signedYear > 0 ? signedYear : 1 - signedYear;
    return addLeadingZeros(token === "yy" ? year % 100 : year, token.length);
  },
  M(date, token) {
    const month = date.getMonth();
    return token === "M" ? String(month + 1) : addLeadingZeros(month + 1, 2);
  },
  d(date, token) {
    return addLeadingZeros(date.getDate(), token.length);
  },
  a(date, token) {
    const dayPeriodEnumValue = date.getHours() / 12 >= 1 ? "pm" : "am";
    switch (token) {
      case "a":
      case "aa":
        return dayPeriodEnumValue.toUpperCase();
      case "aaa":
        return dayPeriodEnumValue;
      case "aaaaa":
        return dayPeriodEnumValue[0];
      case "aaaa":
      default:
        return dayPeriodEnumValue === "am" ? "a.m." : "p.m.";
    }
  },
  h(date, token) {
    return addLeadingZeros(date.getHours() % 12 || 12, token.length);
  },
  H(date, token) {
    return addLeadingZeros(date.getHours(), token.length);
  },
  m(date, token) {
    return addLeadingZeros(date.getMinutes(), token.length);
  },
  s(date, token) {
    return addLeadingZeros(date.getSeconds(), token.length);
  },
  S(date, token) {
    const numberOfDigits = token.length;
    const milliseconds = date.getMilliseconds();
    const fractionalSeconds = Math.trunc(milliseconds * Math.pow(10, numberOfDigits - 3));
    return addLeadingZeros(fractionalSeconds, token.length);
  }
};

// node_modules/date-fns/lightFormat.mjs
var import_isValid = require("date-fns@3.6.0/isValid");
var import_toDate = require("date-fns@3.6.0/toDate");
var formattingTokensRegExp = /(\w)\1*|''|'(''|[^'])+('|$)|./g;
var escapedStringRegExp = /^'([^]*?)'?$/;
var doubleQuoteRegExp = /''/g;
var unescapedLatinCharacterRegExp = /[a-zA-Z]/;
function lightFormat(date, formatStr) {
  const _date = (0, import_toDate.toDate)(date);
  if (!(0, import_isValid.isValid)(_date)) {
    throw new RangeError("Invalid time value");
  }
  const tokens = formatStr.match(formattingTokensRegExp);
  if (!tokens) return "";
  const result = tokens.map(substring => {
    if (substring === "''") {
      return "'";
    }
    const firstCharacter = substring[0];
    if (firstCharacter === "'") {
      return cleanEscapedString(substring);
    }
    const formatter = lightFormatters[firstCharacter];
    if (formatter) {
      return formatter(_date, substring);
    }
    if (firstCharacter.match(unescapedLatinCharacterRegExp)) {
      throw new RangeError("Format string contains an unescaped latin alphabet character `" + firstCharacter + "`");
    }
    return substring;
  }).join("");
  return result;
}
function cleanEscapedString(input) {
  const matches = input.match(escapedStringRegExp);
  if (!matches) {
    return input;
  }
  return matches[1].replace(doubleQuoteRegExp, "'");
}
var lightFormat_default = lightFormat;

// .beyond/uimport/temp/date-fns/lightFormat.3.6.0.js
var lightFormat_3_6_0_default = lightFormat_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2xpZ2h0Rm9ybWF0LjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL19saWIvYWRkTGVhZGluZ1plcm9zLm1qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9fbGliL2Zvcm1hdC9saWdodEZvcm1hdHRlcnMubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xpZ2h0Rm9ybWF0Lm1qcyJdLCJuYW1lcyI6WyJsaWdodEZvcm1hdF8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwibGlnaHRGb3JtYXRfM182XzBfZGVmYXVsdCIsImxpZ2h0Rm9ybWF0IiwibGlnaHRGb3JtYXR0ZXJzIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImFkZExlYWRpbmdaZXJvcyIsIm51bWJlciIsInRhcmdldExlbmd0aCIsInNpZ24iLCJvdXRwdXQiLCJNYXRoIiwiYWJzIiwidG9TdHJpbmciLCJwYWRTdGFydCIsInkiLCJkYXRlIiwidG9rZW4iLCJzaWduZWRZZWFyIiwiZ2V0RnVsbFllYXIiLCJ5ZWFyIiwibGVuZ3RoIiwiTSIsIm1vbnRoIiwiZ2V0TW9udGgiLCJTdHJpbmciLCJkIiwiZ2V0RGF0ZSIsImEiLCJkYXlQZXJpb2RFbnVtVmFsdWUiLCJnZXRIb3VycyIsInRvVXBwZXJDYXNlIiwiaCIsIkgiLCJtIiwiZ2V0TWludXRlcyIsInMiLCJnZXRTZWNvbmRzIiwiUyIsIm51bWJlck9mRGlnaXRzIiwibWlsbGlzZWNvbmRzIiwiZ2V0TWlsbGlzZWNvbmRzIiwiZnJhY3Rpb25hbFNlY29uZHMiLCJ0cnVuYyIsInBvdyIsImltcG9ydF9pc1ZhbGlkIiwicmVxdWlyZSIsImltcG9ydF90b0RhdGUiLCJmb3JtYXR0aW5nVG9rZW5zUmVnRXhwIiwiZXNjYXBlZFN0cmluZ1JlZ0V4cCIsImRvdWJsZVF1b3RlUmVnRXhwIiwidW5lc2NhcGVkTGF0aW5DaGFyYWN0ZXJSZWdFeHAiLCJmb3JtYXRTdHIiLCJfZGF0ZSIsInRvRGF0ZSIsImlzVmFsaWQiLCJSYW5nZUVycm9yIiwidG9rZW5zIiwibWF0Y2giLCJyZXN1bHQiLCJtYXAiLCJzdWJzdHJpbmciLCJmaXJzdENoYXJhY3RlciIsImNsZWFuRXNjYXBlZFN0cmluZyIsImZvcm1hdHRlciIsImpvaW4iLCJpbnB1dCIsIm1hdGNoZXMiLCJyZXBsYWNlIiwibGlnaHRGb3JtYXRfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEseUJBQUE7QUFBQUMsUUFBQSxDQUFBRCx5QkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMseUJBQUE7RUFBQUMsV0FBQSxFQUFBQSxDQUFBLEtBQUFBLFdBQUE7RUFBQUMsZUFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVIseUJBQUE7OztBQ0FPLFNBQVNTLGdCQUFnQkMsTUFBQSxFQUFRQyxZQUFBLEVBQWM7RUFDcEQsTUFBTUMsSUFBQSxHQUFPRixNQUFBLEdBQVMsSUFBSSxNQUFNO0VBQ2hDLE1BQU1HLE1BQUEsR0FBU0MsSUFBQSxDQUFLQyxHQUFBLENBQUlMLE1BQU0sRUFBRU0sUUFBQSxDQUFTLEVBQUVDLFFBQUEsQ0FBU04sWUFBQSxFQUFjLEdBQUc7RUFDckUsT0FBT0MsSUFBQSxHQUFPQyxNQUFBO0FBQ2hCOzs7QUNXTyxJQUFNUixlQUFBLEdBQWtCO0VBRTdCYSxFQUFFQyxJQUFBLEVBQU1DLEtBQUEsRUFBTztJQVViLE1BQU1DLFVBQUEsR0FBYUYsSUFBQSxDQUFLRyxXQUFBLENBQVk7SUFFcEMsTUFBTUMsSUFBQSxHQUFPRixVQUFBLEdBQWEsSUFBSUEsVUFBQSxHQUFhLElBQUlBLFVBQUE7SUFDL0MsT0FBT1osZUFBQSxDQUFnQlcsS0FBQSxLQUFVLE9BQU9HLElBQUEsR0FBTyxNQUFNQSxJQUFBLEVBQU1ILEtBQUEsQ0FBTUksTUFBTTtFQUN6RTtFQUdBQyxFQUFFTixJQUFBLEVBQU1DLEtBQUEsRUFBTztJQUNiLE1BQU1NLEtBQUEsR0FBUVAsSUFBQSxDQUFLUSxRQUFBLENBQVM7SUFDNUIsT0FBT1AsS0FBQSxLQUFVLE1BQU1RLE1BQUEsQ0FBT0YsS0FBQSxHQUFRLENBQUMsSUFBSWpCLGVBQUEsQ0FBZ0JpQixLQUFBLEdBQVEsR0FBRyxDQUFDO0VBQ3pFO0VBR0FHLEVBQUVWLElBQUEsRUFBTUMsS0FBQSxFQUFPO0lBQ2IsT0FBT1gsZUFBQSxDQUFnQlUsSUFBQSxDQUFLVyxPQUFBLENBQVEsR0FBR1YsS0FBQSxDQUFNSSxNQUFNO0VBQ3JEO0VBR0FPLEVBQUVaLElBQUEsRUFBTUMsS0FBQSxFQUFPO0lBQ2IsTUFBTVksa0JBQUEsR0FBcUJiLElBQUEsQ0FBS2MsUUFBQSxDQUFTLElBQUksTUFBTSxJQUFJLE9BQU87SUFFOUQsUUFBUWIsS0FBQTtNQUFBLEtBQ0Q7TUFBQSxLQUNBO1FBQ0gsT0FBT1ksa0JBQUEsQ0FBbUJFLFdBQUEsQ0FBWTtNQUFBLEtBQ25DO1FBQ0gsT0FBT0Ysa0JBQUE7TUFBQSxLQUNKO1FBQ0gsT0FBT0Esa0JBQUEsQ0FBbUI7TUFBQSxLQUN2QjtNQUFBO1FBRUgsT0FBT0Esa0JBQUEsS0FBdUIsT0FBTyxTQUFTO0lBQUE7RUFFcEQ7RUFHQUcsRUFBRWhCLElBQUEsRUFBTUMsS0FBQSxFQUFPO0lBQ2IsT0FBT1gsZUFBQSxDQUFnQlUsSUFBQSxDQUFLYyxRQUFBLENBQVMsSUFBSSxNQUFNLElBQUliLEtBQUEsQ0FBTUksTUFBTTtFQUNqRTtFQUdBWSxFQUFFakIsSUFBQSxFQUFNQyxLQUFBLEVBQU87SUFDYixPQUFPWCxlQUFBLENBQWdCVSxJQUFBLENBQUtjLFFBQUEsQ0FBUyxHQUFHYixLQUFBLENBQU1JLE1BQU07RUFDdEQ7RUFHQWEsRUFBRWxCLElBQUEsRUFBTUMsS0FBQSxFQUFPO0lBQ2IsT0FBT1gsZUFBQSxDQUFnQlUsSUFBQSxDQUFLbUIsVUFBQSxDQUFXLEdBQUdsQixLQUFBLENBQU1JLE1BQU07RUFDeEQ7RUFHQWUsRUFBRXBCLElBQUEsRUFBTUMsS0FBQSxFQUFPO0lBQ2IsT0FBT1gsZUFBQSxDQUFnQlUsSUFBQSxDQUFLcUIsVUFBQSxDQUFXLEdBQUdwQixLQUFBLENBQU1JLE1BQU07RUFDeEQ7RUFHQWlCLEVBQUV0QixJQUFBLEVBQU1DLEtBQUEsRUFBTztJQUNiLE1BQU1zQixjQUFBLEdBQWlCdEIsS0FBQSxDQUFNSSxNQUFBO0lBQzdCLE1BQU1tQixZQUFBLEdBQWV4QixJQUFBLENBQUt5QixlQUFBLENBQWdCO0lBQzFDLE1BQU1DLGlCQUFBLEdBQW9CL0IsSUFBQSxDQUFLZ0MsS0FBQSxDQUM3QkgsWUFBQSxHQUFlN0IsSUFBQSxDQUFLaUMsR0FBQSxDQUFJLElBQUlMLGNBQUEsR0FBaUIsQ0FBQyxDQUNoRDtJQUNBLE9BQU9qQyxlQUFBLENBQWdCb0MsaUJBQUEsRUFBbUJ6QixLQUFBLENBQU1JLE1BQU07RUFDeEQ7QUFDRjs7O0FDM0ZBLElBQUF3QixjQUFBLEdBQXdCQyxPQUFBO0FBQ3hCLElBQUFDLGFBQUEsR0FBdUJELE9BQUE7QUFnQnZCLElBQU1FLHNCQUFBLEdBQXlCO0FBRS9CLElBQU1DLG1CQUFBLEdBQXNCO0FBQzVCLElBQU1DLGlCQUFBLEdBQW9CO0FBQzFCLElBQU1DLDZCQUFBLEdBQWdDO0FBaUUvQixTQUFTbEQsWUFBWWUsSUFBQSxFQUFNb0MsU0FBQSxFQUFXO0VBQzNDLE1BQU1DLEtBQUEsT0FBUU4sYUFBQSxDQUFBTyxNQUFBLEVBQU90QyxJQUFJO0VBRXpCLElBQUksS0FBQzZCLGNBQUEsQ0FBQVUsT0FBQSxFQUFRRixLQUFLLEdBQUc7SUFDbkIsTUFBTSxJQUFJRyxVQUFBLENBQVcsb0JBQW9CO0VBQzNDO0VBRUEsTUFBTUMsTUFBQSxHQUFTTCxTQUFBLENBQVVNLEtBQUEsQ0FBTVYsc0JBQXNCO0VBR3JELElBQUksQ0FBQ1MsTUFBQSxFQUFRLE9BQU87RUFFcEIsTUFBTUUsTUFBQSxHQUFTRixNQUFBLENBQ1pHLEdBQUEsQ0FBS0MsU0FBQSxJQUFjO0lBRWxCLElBQUlBLFNBQUEsS0FBYyxNQUFNO01BQ3RCLE9BQU87SUFDVDtJQUVBLE1BQU1DLGNBQUEsR0FBaUJELFNBQUEsQ0FBVTtJQUNqQyxJQUFJQyxjQUFBLEtBQW1CLEtBQUs7TUFDMUIsT0FBT0Msa0JBQUEsQ0FBbUJGLFNBQVM7SUFDckM7SUFFQSxNQUFNRyxTQUFBLEdBQVk5RCxlQUFBLENBQWdCNEQsY0FBQTtJQUNsQyxJQUFJRSxTQUFBLEVBQVc7TUFDYixPQUFPQSxTQUFBLENBQVVYLEtBQUEsRUFBT1EsU0FBUztJQUNuQztJQUVBLElBQUlDLGNBQUEsQ0FBZUosS0FBQSxDQUFNUCw2QkFBNkIsR0FBRztNQUN2RCxNQUFNLElBQUlLLFVBQUEsQ0FDUixtRUFDRU0sY0FBQSxHQUNBLEdBQ0o7SUFDRjtJQUVBLE9BQU9ELFNBQUE7RUFDVCxDQUFDLEVBQ0FJLElBQUEsQ0FBSyxFQUFFO0VBRVYsT0FBT04sTUFBQTtBQUNUO0FBRUEsU0FBU0ksbUJBQW1CRyxLQUFBLEVBQU87RUFDakMsTUFBTUMsT0FBQSxHQUFVRCxLQUFBLENBQU1SLEtBQUEsQ0FBTVQsbUJBQW1CO0VBRS9DLElBQUksQ0FBQ2tCLE9BQUEsRUFBUztJQUNaLE9BQU9ELEtBQUE7RUFDVDtFQUVBLE9BQU9DLE9BQUEsQ0FBUSxHQUFHQyxPQUFBLENBQVFsQixpQkFBQSxFQUFtQixHQUFHO0FBQ2xEO0FBR0EsSUFBT21CLG1CQUFBLEdBQVFwRSxXQUFBOzs7QUgxSWYsSUFBT0QseUJBQUEsR0FBUXFFLG1CQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9