System.register([], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/locale/ca.3.6.0.js
var ca_3_6_0_exports = {};
__export(ca_3_6_0_exports, {
  ca: () => ca,
  default: () => ca_3_6_0_default
});
module.exports = __toCommonJS(ca_3_6_0_exports);

// node_modules/date-fns/locale/ca/_lib/formatDistance.mjs
var formatDistanceLocale = {
  lessThanXSeconds: {
    one: "menys d'un segon",
    eleven: "menys d'onze segons",
    other: "menys de {{count}} segons"
  },
  xSeconds: {
    one: "1 segon",
    other: "{{count}} segons"
  },
  halfAMinute: "mig minut",
  lessThanXMinutes: {
    one: "menys d'un minut",
    eleven: "menys d'onze minuts",
    other: "menys de {{count}} minuts"
  },
  xMinutes: {
    one: "1 minut",
    other: "{{count}} minuts"
  },
  aboutXHours: {
    one: "aproximadament una hora",
    other: "aproximadament {{count}} hores"
  },
  xHours: {
    one: "1 hora",
    other: "{{count}} hores"
  },
  xDays: {
    one: "1 dia",
    other: "{{count}} dies"
  },
  aboutXWeeks: {
    one: "aproximadament una setmana",
    other: "aproximadament {{count}} setmanes"
  },
  xWeeks: {
    one: "1 setmana",
    other: "{{count}} setmanes"
  },
  aboutXMonths: {
    one: "aproximadament un mes",
    other: "aproximadament {{count}} mesos"
  },
  xMonths: {
    one: "1 mes",
    other: "{{count}} mesos"
  },
  aboutXYears: {
    one: "aproximadament un any",
    other: "aproximadament {{count}} anys"
  },
  xYears: {
    one: "1 any",
    other: "{{count}} anys"
  },
  overXYears: {
    one: "m\xE9s d'un any",
    eleven: "m\xE9s d'onze anys",
    other: "m\xE9s de {{count}} anys"
  },
  almostXYears: {
    one: "gaireb\xE9 un any",
    other: "gaireb\xE9 {{count}} anys"
  }
};
var formatDistance = (token, count, options) => {
  let result;
  const tokenValue = formatDistanceLocale[token];
  if (typeof tokenValue === "string") {
    result = tokenValue;
  } else if (count === 1) {
    result = tokenValue.one;
  } else if (count === 11 && tokenValue.eleven) {
    result = tokenValue.eleven;
  } else {
    result = tokenValue.other.replace("{{count}}", String(count));
  }
  if (options?.addSuffix) {
    if (options.comparison && options.comparison > 0) {
      return "en " + result;
    } else {
      return "fa " + result;
    }
  }
  return result;
};

// node_modules/date-fns/locale/_lib/buildFormatLongFn.mjs
function buildFormatLongFn(args) {
  return (options = {}) => {
    const width = options.width ? String(options.width) : args.defaultWidth;
    const format = args.formats[width] || args.formats[args.defaultWidth];
    return format;
  };
}

// node_modules/date-fns/locale/ca/_lib/formatLong.mjs
var dateFormats = {
  full: "EEEE, d 'de' MMMM y",
  long: "d 'de' MMMM y",
  medium: "d MMM y",
  short: "dd/MM/y"
};
var timeFormats = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
};
var dateTimeFormats = {
  full: "{{date}} 'a les' {{time}}",
  long: "{{date}} 'a les' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
};
var formatLong = {
  date: buildFormatLongFn({
    formats: dateFormats,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats,
    defaultWidth: "full"
  })
};

// node_modules/date-fns/locale/ca/_lib/formatRelative.mjs
var formatRelativeLocale = {
  lastWeek: "'el' eeee 'passat a la' LT",
  yesterday: "'ahir a la' p",
  today: "'avui a la' p",
  tomorrow: "'dem\xE0 a la' p",
  nextWeek: "eeee 'a la' p",
  other: "P"
};
var formatRelativeLocalePlural = {
  lastWeek: "'el' eeee 'passat a les' p",
  yesterday: "'ahir a les' p",
  today: "'avui a les' p",
  tomorrow: "'dem\xE0 a les' p",
  nextWeek: "eeee 'a les' p",
  other: "P"
};
var formatRelative = (token, date, _baseDate, _options) => {
  if (date.getHours() !== 1) {
    return formatRelativeLocalePlural[token];
  }
  return formatRelativeLocale[token];
};

// node_modules/date-fns/locale/_lib/buildLocalizeFn.mjs
function buildLocalizeFn(args) {
  return (value, options) => {
    const context = options?.context ? String(options.context) : "standalone";
    let valuesArray;
    if (context === "formatting" && args.formattingValues) {
      const defaultWidth = args.defaultFormattingWidth || args.defaultWidth;
      const width = options?.width ? String(options.width) : defaultWidth;
      valuesArray = args.formattingValues[width] || args.formattingValues[defaultWidth];
    } else {
      const defaultWidth = args.defaultWidth;
      const width = options?.width ? String(options.width) : args.defaultWidth;
      valuesArray = args.values[width] || args.values[defaultWidth];
    }
    const index = args.argumentCallback ? args.argumentCallback(value) : value;
    return valuesArray[index];
  };
}

// node_modules/date-fns/locale/ca/_lib/localize.mjs
var eraValues = {
  narrow: ["aC", "dC"],
  abbreviated: ["a. de C.", "d. de C."],
  wide: ["abans de Crist", "despr\xE9s de Crist"]
};
var quarterValues = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["T1", "T2", "T3", "T4"],
  wide: ["1r trimestre", "2n trimestre", "3r trimestre", "4t trimestre"]
};
var monthValues = {
  narrow: ["GN", "FB", "M\xC7", "AB", "MG", "JN", "JL", "AG", "ST", "OC", "NV", "DS"],
  abbreviated: ["gen.", "febr.", "mar\xE7", "abr.", "maig", "juny", "jul.", "ag.", "set.", "oct.", "nov.", "des."],
  wide: ["gener", "febrer", "mar\xE7", "abril", "maig", "juny", "juliol", "agost", "setembre", "octubre", "novembre", "desembre"]
};
var dayValues = {
  narrow: ["dg.", "dl.", "dt.", "dm.", "dj.", "dv.", "ds."],
  short: ["dg.", "dl.", "dt.", "dm.", "dj.", "dv.", "ds."],
  abbreviated: ["dg.", "dl.", "dt.", "dm.", "dj.", "dv.", "ds."],
  wide: ["diumenge", "dilluns", "dimarts", "dimecres", "dijous", "divendres", "dissabte"]
};
var dayPeriodValues = {
  narrow: {
    am: "am",
    pm: "pm",
    midnight: "mitjanit",
    noon: "migdia",
    morning: "mat\xED",
    afternoon: "tarda",
    evening: "vespre",
    night: "nit"
  },
  abbreviated: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "mitjanit",
    noon: "migdia",
    morning: "mat\xED",
    afternoon: "tarda",
    evening: "vespre",
    night: "nit"
  },
  wide: {
    am: "ante meridiem",
    pm: "post meridiem",
    midnight: "mitjanit",
    noon: "migdia",
    morning: "mat\xED",
    afternoon: "tarda",
    evening: "vespre",
    night: "nit"
  }
};
var formattingDayPeriodValues = {
  narrow: {
    am: "am",
    pm: "pm",
    midnight: "de la mitjanit",
    noon: "del migdia",
    morning: "del mat\xED",
    afternoon: "de la tarda",
    evening: "del vespre",
    night: "de la nit"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "de la mitjanit",
    noon: "del migdia",
    morning: "del mat\xED",
    afternoon: "de la tarda",
    evening: "del vespre",
    night: "de la nit"
  },
  wide: {
    am: "ante meridiem",
    pm: "post meridiem",
    midnight: "de la mitjanit",
    noon: "del migdia",
    morning: "del mat\xED",
    afternoon: "de la tarda",
    evening: "del vespre",
    night: "de la nit"
  }
};
var ordinalNumber = (dirtyNumber, _options) => {
  const number = Number(dirtyNumber);
  const rem100 = number % 100;
  if (rem100 > 20 || rem100 < 10) {
    switch (rem100 % 10) {
      case 1:
        return number + "r";
      case 2:
        return number + "n";
      case 3:
        return number + "r";
      case 4:
        return number + "t";
    }
  }
  return number + "\xE8";
};
var localize = {
  ordinalNumber,
  era: buildLocalizeFn({
    values: eraValues,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues,
    defaultWidth: "wide",
    argumentCallback: quarter => quarter - 1
  }),
  month: buildLocalizeFn({
    values: monthValues,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues,
    defaultFormattingWidth: "wide"
  })
};

// node_modules/date-fns/locale/_lib/buildMatchFn.mjs
function buildMatchFn(args) {
  return (string, options = {}) => {
    const width = options.width;
    const matchPattern = width && args.matchPatterns[width] || args.matchPatterns[args.defaultMatchWidth];
    const matchResult = string.match(matchPattern);
    if (!matchResult) {
      return null;
    }
    const matchedString = matchResult[0];
    const parsePatterns = width && args.parsePatterns[width] || args.parsePatterns[args.defaultParseWidth];
    const key = Array.isArray(parsePatterns) ? findIndex(parsePatterns, pattern => pattern.test(matchedString)) : findKey(parsePatterns, pattern => pattern.test(matchedString));
    let value;
    value = args.valueCallback ? args.valueCallback(key) : key;
    value = options.valueCallback ? options.valueCallback(value) : value;
    const rest = string.slice(matchedString.length);
    return {
      value,
      rest
    };
  };
}
function findKey(object, predicate) {
  for (const key in object) {
    if (Object.prototype.hasOwnProperty.call(object, key) && predicate(object[key])) {
      return key;
    }
  }
  return void 0;
}
function findIndex(array, predicate) {
  for (let key = 0; key < array.length; key++) {
    if (predicate(array[key])) {
      return key;
    }
  }
  return void 0;
}

// node_modules/date-fns/locale/_lib/buildMatchPatternFn.mjs
function buildMatchPatternFn(args) {
  return (string, options = {}) => {
    const matchResult = string.match(args.matchPattern);
    if (!matchResult) return null;
    const matchedString = matchResult[0];
    const parseResult = string.match(args.parsePattern);
    if (!parseResult) return null;
    let value = args.valueCallback ? args.valueCallback(parseResult[0]) : parseResult[0];
    value = options.valueCallback ? options.valueCallback(value) : value;
    const rest = string.slice(matchedString.length);
    return {
      value,
      rest
    };
  };
}

// node_modules/date-fns/locale/ca/_lib/match.mjs
var matchOrdinalNumberPattern = /^(\d+)(è|r|n|r|t)?/i;
var parseOrdinalNumberPattern = /\d+/i;
var matchEraPatterns = {
  narrow: /^(aC|dC)/i,
  abbreviated: /^(a. de C.|d. de C.)/i,
  wide: /^(abans de Crist|despr[eé]s de Crist)/i
};
var parseEraPatterns = {
  narrow: [/^aC/i, /^dC/i],
  abbreviated: [/^(a. de C.)/i, /^(d. de C.)/i],
  wide: [/^(abans de Crist)/i, /^(despr[eé]s de Crist)/i]
};
var matchQuarterPatterns = {
  narrow: /^[1234]/i,
  abbreviated: /^T[1234]/i,
  wide: /^[1234](è|r|n|r|t)? trimestre/i
};
var parseQuarterPatterns = {
  any: [/1/i, /2/i, /3/i, /4/i]
};
var matchMonthPatterns = {
  narrow: /^(GN|FB|MÇ|AB|MG|JN|JL|AG|ST|OC|NV|DS)/i,
  abbreviated: /^(gen.|febr.|març|abr.|maig|juny|jul.|ag.|set.|oct.|nov.|des.)/i,
  wide: /^(gener|febrer|març|abril|maig|juny|juliol|agost|setembre|octubre|novembre|desembre)/i
};
var parseMonthPatterns = {
  narrow: [/^GN/i, /^FB/i, /^MÇ/i, /^AB/i, /^MG/i, /^JN/i, /^JL/i, /^AG/i, /^ST/i, /^OC/i, /^NV/i, /^DS/i],
  abbreviated: [/^gen./i, /^febr./i, /^març/i, /^abr./i, /^maig/i, /^juny/i, /^jul./i, /^ag./i, /^set./i, /^oct./i, /^nov./i, /^des./i],
  wide: [/^gener/i, /^febrer/i, /^març/i, /^abril/i, /^maig/i, /^juny/i, /^juliol/i, /^agost/i, /^setembre/i, /^octubre/i, /^novembre/i, /^desembre/i]
};
var matchDayPatterns = {
  narrow: /^(dg\.|dl\.|dt\.|dm\.|dj\.|dv\.|ds\.)/i,
  short: /^(dg\.|dl\.|dt\.|dm\.|dj\.|dv\.|ds\.)/i,
  abbreviated: /^(dg\.|dl\.|dt\.|dm\.|dj\.|dv\.|ds\.)/i,
  wide: /^(diumenge|dilluns|dimarts|dimecres|dijous|divendres|dissabte)/i
};
var parseDayPatterns = {
  narrow: [/^dg./i, /^dl./i, /^dt./i, /^dm./i, /^dj./i, /^dv./i, /^ds./i],
  abbreviated: [/^dg./i, /^dl./i, /^dt./i, /^dm./i, /^dj./i, /^dv./i, /^ds./i],
  wide: [/^diumenge/i, /^dilluns/i, /^dimarts/i, /^dimecres/i, /^dijous/i, /^divendres/i, /^disssabte/i]
};
var matchDayPeriodPatterns = {
  narrow: /^(a|p|mn|md|(del|de la) (matí|tarda|vespre|nit))/i,
  abbreviated: /^([ap]\.?\s?m\.?|mitjanit|migdia|(del|de la) (matí|tarda|vespre|nit))/i,
  wide: /^(ante meridiem|post meridiem|mitjanit|migdia|(del|de la) (matí|tarda|vespre|nit))/i
};
var parseDayPeriodPatterns = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^mitjanit/i,
    noon: /^migdia/i,
    morning: /matí/i,
    afternoon: /tarda/i,
    evening: /vespre/i,
    night: /nit/i
  }
};
var match = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern,
    parsePattern: parseOrdinalNumberPattern,
    valueCallback: value => parseInt(value, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns,
    defaultParseWidth: "wide"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns,
    defaultParseWidth: "any",
    valueCallback: index => index + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns,
    defaultParseWidth: "wide"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns,
    defaultParseWidth: "wide"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPeriodPatterns,
    defaultParseWidth: "any"
  })
};

// node_modules/date-fns/locale/ca.mjs
var ca = {
  code: "ca",
  formatDistance,
  formatLong,
  formatRelative,
  localize,
  match,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
};
var ca_default = ca;

// .beyond/uimport/temp/date-fns/locale/ca.3.6.0.js
var ca_3_6_0_default = ca_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2xvY2FsZS9jYS4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9sb2NhbGUvY2EvX2xpYi9mb3JtYXREaXN0YW5jZS5tanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvbG9jYWxlL19saWIvYnVpbGRGb3JtYXRMb25nRm4ubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9jYS9fbGliL2Zvcm1hdExvbmcubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9jYS9fbGliL2Zvcm1hdFJlbGF0aXZlLm1qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9sb2NhbGUvX2xpYi9idWlsZExvY2FsaXplRm4ubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9jYS9fbGliL2xvY2FsaXplLm1qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9sb2NhbGUvX2xpYi9idWlsZE1hdGNoRm4ubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9fbGliL2J1aWxkTWF0Y2hQYXR0ZXJuRm4ubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9jYS9fbGliL21hdGNoLm1qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9sb2NhbGUvY2EubWpzIl0sIm5hbWVzIjpbImNhXzNfNl8wX2V4cG9ydHMiLCJfX2V4cG9ydCIsImNhIiwiZGVmYXVsdCIsImNhXzNfNl8wX2RlZmF1bHQiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiZm9ybWF0RGlzdGFuY2VMb2NhbGUiLCJsZXNzVGhhblhTZWNvbmRzIiwib25lIiwiZWxldmVuIiwib3RoZXIiLCJ4U2Vjb25kcyIsImhhbGZBTWludXRlIiwibGVzc1RoYW5YTWludXRlcyIsInhNaW51dGVzIiwiYWJvdXRYSG91cnMiLCJ4SG91cnMiLCJ4RGF5cyIsImFib3V0WFdlZWtzIiwieFdlZWtzIiwiYWJvdXRYTW9udGhzIiwieE1vbnRocyIsImFib3V0WFllYXJzIiwieFllYXJzIiwib3ZlclhZZWFycyIsImFsbW9zdFhZZWFycyIsImZvcm1hdERpc3RhbmNlIiwidG9rZW4iLCJjb3VudCIsIm9wdGlvbnMiLCJyZXN1bHQiLCJ0b2tlblZhbHVlIiwicmVwbGFjZSIsIlN0cmluZyIsImFkZFN1ZmZpeCIsImNvbXBhcmlzb24iLCJidWlsZEZvcm1hdExvbmdGbiIsImFyZ3MiLCJ3aWR0aCIsImRlZmF1bHRXaWR0aCIsImZvcm1hdCIsImZvcm1hdHMiLCJkYXRlRm9ybWF0cyIsImZ1bGwiLCJsb25nIiwibWVkaXVtIiwic2hvcnQiLCJ0aW1lRm9ybWF0cyIsImRhdGVUaW1lRm9ybWF0cyIsImZvcm1hdExvbmciLCJkYXRlIiwidGltZSIsImRhdGVUaW1lIiwiZm9ybWF0UmVsYXRpdmVMb2NhbGUiLCJsYXN0V2VlayIsInllc3RlcmRheSIsInRvZGF5IiwidG9tb3Jyb3ciLCJuZXh0V2VlayIsImZvcm1hdFJlbGF0aXZlTG9jYWxlUGx1cmFsIiwiZm9ybWF0UmVsYXRpdmUiLCJfYmFzZURhdGUiLCJfb3B0aW9ucyIsImdldEhvdXJzIiwiYnVpbGRMb2NhbGl6ZUZuIiwidmFsdWUiLCJjb250ZXh0IiwidmFsdWVzQXJyYXkiLCJmb3JtYXR0aW5nVmFsdWVzIiwiZGVmYXVsdEZvcm1hdHRpbmdXaWR0aCIsInZhbHVlcyIsImluZGV4IiwiYXJndW1lbnRDYWxsYmFjayIsImVyYVZhbHVlcyIsIm5hcnJvdyIsImFiYnJldmlhdGVkIiwid2lkZSIsInF1YXJ0ZXJWYWx1ZXMiLCJtb250aFZhbHVlcyIsImRheVZhbHVlcyIsImRheVBlcmlvZFZhbHVlcyIsImFtIiwicG0iLCJtaWRuaWdodCIsIm5vb24iLCJtb3JuaW5nIiwiYWZ0ZXJub29uIiwiZXZlbmluZyIsIm5pZ2h0IiwiZm9ybWF0dGluZ0RheVBlcmlvZFZhbHVlcyIsIm9yZGluYWxOdW1iZXIiLCJkaXJ0eU51bWJlciIsIm51bWJlciIsIk51bWJlciIsInJlbTEwMCIsImxvY2FsaXplIiwiZXJhIiwicXVhcnRlciIsIm1vbnRoIiwiZGF5IiwiZGF5UGVyaW9kIiwiYnVpbGRNYXRjaEZuIiwic3RyaW5nIiwibWF0Y2hQYXR0ZXJuIiwibWF0Y2hQYXR0ZXJucyIsImRlZmF1bHRNYXRjaFdpZHRoIiwibWF0Y2hSZXN1bHQiLCJtYXRjaCIsIm1hdGNoZWRTdHJpbmciLCJwYXJzZVBhdHRlcm5zIiwiZGVmYXVsdFBhcnNlV2lkdGgiLCJrZXkiLCJBcnJheSIsImlzQXJyYXkiLCJmaW5kSW5kZXgiLCJwYXR0ZXJuIiwidGVzdCIsImZpbmRLZXkiLCJ2YWx1ZUNhbGxiYWNrIiwicmVzdCIsInNsaWNlIiwibGVuZ3RoIiwib2JqZWN0IiwicHJlZGljYXRlIiwiT2JqZWN0IiwicHJvdG90eXBlIiwiaGFzT3duUHJvcGVydHkiLCJjYWxsIiwiYXJyYXkiLCJidWlsZE1hdGNoUGF0dGVybkZuIiwicGFyc2VSZXN1bHQiLCJwYXJzZVBhdHRlcm4iLCJtYXRjaE9yZGluYWxOdW1iZXJQYXR0ZXJuIiwicGFyc2VPcmRpbmFsTnVtYmVyUGF0dGVybiIsIm1hdGNoRXJhUGF0dGVybnMiLCJwYXJzZUVyYVBhdHRlcm5zIiwibWF0Y2hRdWFydGVyUGF0dGVybnMiLCJwYXJzZVF1YXJ0ZXJQYXR0ZXJucyIsImFueSIsIm1hdGNoTW9udGhQYXR0ZXJucyIsInBhcnNlTW9udGhQYXR0ZXJucyIsIm1hdGNoRGF5UGF0dGVybnMiLCJwYXJzZURheVBhdHRlcm5zIiwibWF0Y2hEYXlQZXJpb2RQYXR0ZXJucyIsInBhcnNlRGF5UGVyaW9kUGF0dGVybnMiLCJwYXJzZUludCIsImNvZGUiLCJ3ZWVrU3RhcnRzT24iLCJmaXJzdFdlZWtDb250YWluc0RhdGUiLCJjYV9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSxnQkFBQTtBQUFBQyxRQUFBLENBQUFELGdCQUFBO0VBQUFFLEVBQUEsRUFBQUEsQ0FBQSxLQUFBQSxFQUFBO0VBQUFDLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQztBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLGdCQUFBOzs7QUNXQSxJQUFNUSxvQkFBQSxHQUF1QjtFQUMzQkMsZ0JBQUEsRUFBa0I7SUFDaEJDLEdBQUEsRUFBSztJQUNMQyxNQUFBLEVBQVE7SUFDUkMsS0FBQSxFQUFPO0VBQ1Q7RUFFQUMsUUFBQSxFQUFVO0lBQ1JILEdBQUEsRUFBSztJQUNMRSxLQUFBLEVBQU87RUFDVDtFQUVBRSxXQUFBLEVBQWE7RUFFYkMsZ0JBQUEsRUFBa0I7SUFDaEJMLEdBQUEsRUFBSztJQUNMQyxNQUFBLEVBQVE7SUFDUkMsS0FBQSxFQUFPO0VBQ1Q7RUFFQUksUUFBQSxFQUFVO0lBQ1JOLEdBQUEsRUFBSztJQUNMRSxLQUFBLEVBQU87RUFDVDtFQUVBSyxXQUFBLEVBQWE7SUFDWFAsR0FBQSxFQUFLO0lBQ0xFLEtBQUEsRUFBTztFQUNUO0VBRUFNLE1BQUEsRUFBUTtJQUNOUixHQUFBLEVBQUs7SUFDTEUsS0FBQSxFQUFPO0VBQ1Q7RUFFQU8sS0FBQSxFQUFPO0lBQ0xULEdBQUEsRUFBSztJQUNMRSxLQUFBLEVBQU87RUFDVDtFQUVBUSxXQUFBLEVBQWE7SUFDWFYsR0FBQSxFQUFLO0lBQ0xFLEtBQUEsRUFBTztFQUNUO0VBRUFTLE1BQUEsRUFBUTtJQUNOWCxHQUFBLEVBQUs7SUFDTEUsS0FBQSxFQUFPO0VBQ1Q7RUFFQVUsWUFBQSxFQUFjO0lBQ1paLEdBQUEsRUFBSztJQUNMRSxLQUFBLEVBQU87RUFDVDtFQUVBVyxPQUFBLEVBQVM7SUFDUGIsR0FBQSxFQUFLO0lBQ0xFLEtBQUEsRUFBTztFQUNUO0VBRUFZLFdBQUEsRUFBYTtJQUNYZCxHQUFBLEVBQUs7SUFDTEUsS0FBQSxFQUFPO0VBQ1Q7RUFFQWEsTUFBQSxFQUFRO0lBQ05mLEdBQUEsRUFBSztJQUNMRSxLQUFBLEVBQU87RUFDVDtFQUVBYyxVQUFBLEVBQVk7SUFDVmhCLEdBQUEsRUFBSztJQUNMQyxNQUFBLEVBQVE7SUFDUkMsS0FBQSxFQUFPO0VBQ1Q7RUFFQWUsWUFBQSxFQUFjO0lBQ1pqQixHQUFBLEVBQUs7SUFDTEUsS0FBQSxFQUFPO0VBQ1Q7QUFDRjtBQUVPLElBQU1nQixjQUFBLEdBQWlCQSxDQUFDQyxLQUFBLEVBQU9DLEtBQUEsRUFBT0MsT0FBQSxLQUFZO0VBQ3ZELElBQUlDLE1BQUE7RUFFSixNQUFNQyxVQUFBLEdBQWF6QixvQkFBQSxDQUFxQnFCLEtBQUE7RUFDeEMsSUFBSSxPQUFPSSxVQUFBLEtBQWUsVUFBVTtJQUNsQ0QsTUFBQSxHQUFTQyxVQUFBO0VBQ1gsV0FBV0gsS0FBQSxLQUFVLEdBQUc7SUFDdEJFLE1BQUEsR0FBU0MsVUFBQSxDQUFXdkIsR0FBQTtFQUN0QixXQUFXb0IsS0FBQSxLQUFVLE1BQU1HLFVBQUEsQ0FBV3RCLE1BQUEsRUFBUTtJQUM1Q3FCLE1BQUEsR0FBU0MsVUFBQSxDQUFXdEIsTUFBQTtFQUN0QixPQUFPO0lBQ0xxQixNQUFBLEdBQVNDLFVBQUEsQ0FBV3JCLEtBQUEsQ0FBTXNCLE9BQUEsQ0FBUSxhQUFhQyxNQUFBLENBQU9MLEtBQUssQ0FBQztFQUM5RDtFQUVBLElBQUlDLE9BQUEsRUFBU0ssU0FBQSxFQUFXO0lBQ3RCLElBQUlMLE9BQUEsQ0FBUU0sVUFBQSxJQUFjTixPQUFBLENBQVFNLFVBQUEsR0FBYSxHQUFHO01BQ2hELE9BQU8sUUFBUUwsTUFBQTtJQUNqQixPQUFPO01BQ0wsT0FBTyxRQUFRQSxNQUFBO0lBQ2pCO0VBQ0Y7RUFFQSxPQUFPQSxNQUFBO0FBQ1Q7OztBQ3BITyxTQUFTTSxrQkFBa0JDLElBQUEsRUFBTTtFQUN0QyxPQUFPLENBQUNSLE9BQUEsR0FBVSxDQUFDLE1BQU07SUFFdkIsTUFBTVMsS0FBQSxHQUFRVCxPQUFBLENBQVFTLEtBQUEsR0FBUUwsTUFBQSxDQUFPSixPQUFBLENBQVFTLEtBQUssSUFBSUQsSUFBQSxDQUFLRSxZQUFBO0lBQzNELE1BQU1DLE1BQUEsR0FBU0gsSUFBQSxDQUFLSSxPQUFBLENBQVFILEtBQUEsS0FBVUQsSUFBQSxDQUFLSSxPQUFBLENBQVFKLElBQUEsQ0FBS0UsWUFBQTtJQUN4RCxPQUFPQyxNQUFBO0VBQ1Q7QUFDRjs7O0FDTEEsSUFBTUUsV0FBQSxHQUFjO0VBQ2xCQyxJQUFBLEVBQU07RUFDTkMsSUFBQSxFQUFNO0VBQ05DLE1BQUEsRUFBUTtFQUNSQyxLQUFBLEVBQU87QUFDVDtBQUVBLElBQU1DLFdBQUEsR0FBYztFQUNsQkosSUFBQSxFQUFNO0VBQ05DLElBQUEsRUFBTTtFQUNOQyxNQUFBLEVBQVE7RUFDUkMsS0FBQSxFQUFPO0FBQ1Q7QUFFQSxJQUFNRSxlQUFBLEdBQWtCO0VBQ3RCTCxJQUFBLEVBQU07RUFDTkMsSUFBQSxFQUFNO0VBQ05DLE1BQUEsRUFBUTtFQUNSQyxLQUFBLEVBQU87QUFDVDtBQUVPLElBQU1HLFVBQUEsR0FBYTtFQUN4QkMsSUFBQSxFQUFNZCxpQkFBQSxDQUFrQjtJQUN0QkssT0FBQSxFQUFTQyxXQUFBO0lBQ1RILFlBQUEsRUFBYztFQUNoQixDQUFDO0VBRURZLElBQUEsRUFBTWYsaUJBQUEsQ0FBa0I7SUFDdEJLLE9BQUEsRUFBU00sV0FBQTtJQUNUUixZQUFBLEVBQWM7RUFDaEIsQ0FBQztFQUVEYSxRQUFBLEVBQVVoQixpQkFBQSxDQUFrQjtJQUMxQkssT0FBQSxFQUFTTyxlQUFBO0lBQ1RULFlBQUEsRUFBYztFQUNoQixDQUFDO0FBQ0g7OztBQ3RDQSxJQUFNYyxvQkFBQSxHQUF1QjtFQUMzQkMsUUFBQSxFQUFVO0VBQ1ZDLFNBQUEsRUFBVztFQUNYQyxLQUFBLEVBQU87RUFDUEMsUUFBQSxFQUFVO0VBQ1ZDLFFBQUEsRUFBVTtFQUNWaEQsS0FBQSxFQUFPO0FBQ1Q7QUFFQSxJQUFNaUQsMEJBQUEsR0FBNkI7RUFDakNMLFFBQUEsRUFBVTtFQUNWQyxTQUFBLEVBQVc7RUFDWEMsS0FBQSxFQUFPO0VBQ1BDLFFBQUEsRUFBVTtFQUNWQyxRQUFBLEVBQVU7RUFDVmhELEtBQUEsRUFBTztBQUNUO0FBRU8sSUFBTWtELGNBQUEsR0FBaUJBLENBQUNqQyxLQUFBLEVBQU91QixJQUFBLEVBQU1XLFNBQUEsRUFBV0MsUUFBQSxLQUFhO0VBQ2xFLElBQUlaLElBQUEsQ0FBS2EsUUFBQSxDQUFTLE1BQU0sR0FBRztJQUN6QixPQUFPSiwwQkFBQSxDQUEyQmhDLEtBQUE7RUFDcEM7RUFDQSxPQUFPMEIsb0JBQUEsQ0FBcUIxQixLQUFBO0FBQzlCOzs7QUNrQk8sU0FBU3FDLGdCQUFnQjNCLElBQUEsRUFBTTtFQUNwQyxPQUFPLENBQUM0QixLQUFBLEVBQU9wQyxPQUFBLEtBQVk7SUFDekIsTUFBTXFDLE9BQUEsR0FBVXJDLE9BQUEsRUFBU3FDLE9BQUEsR0FBVWpDLE1BQUEsQ0FBT0osT0FBQSxDQUFRcUMsT0FBTyxJQUFJO0lBRTdELElBQUlDLFdBQUE7SUFDSixJQUFJRCxPQUFBLEtBQVksZ0JBQWdCN0IsSUFBQSxDQUFLK0IsZ0JBQUEsRUFBa0I7TUFDckQsTUFBTTdCLFlBQUEsR0FBZUYsSUFBQSxDQUFLZ0Msc0JBQUEsSUFBMEJoQyxJQUFBLENBQUtFLFlBQUE7TUFDekQsTUFBTUQsS0FBQSxHQUFRVCxPQUFBLEVBQVNTLEtBQUEsR0FBUUwsTUFBQSxDQUFPSixPQUFBLENBQVFTLEtBQUssSUFBSUMsWUFBQTtNQUV2RDRCLFdBQUEsR0FDRTlCLElBQUEsQ0FBSytCLGdCQUFBLENBQWlCOUIsS0FBQSxLQUFVRCxJQUFBLENBQUsrQixnQkFBQSxDQUFpQjdCLFlBQUE7SUFDMUQsT0FBTztNQUNMLE1BQU1BLFlBQUEsR0FBZUYsSUFBQSxDQUFLRSxZQUFBO01BQzFCLE1BQU1ELEtBQUEsR0FBUVQsT0FBQSxFQUFTUyxLQUFBLEdBQVFMLE1BQUEsQ0FBT0osT0FBQSxDQUFRUyxLQUFLLElBQUlELElBQUEsQ0FBS0UsWUFBQTtNQUU1RDRCLFdBQUEsR0FBYzlCLElBQUEsQ0FBS2lDLE1BQUEsQ0FBT2hDLEtBQUEsS0FBVUQsSUFBQSxDQUFLaUMsTUFBQSxDQUFPL0IsWUFBQTtJQUNsRDtJQUNBLE1BQU1nQyxLQUFBLEdBQVFsQyxJQUFBLENBQUttQyxnQkFBQSxHQUFtQm5DLElBQUEsQ0FBS21DLGdCQUFBLENBQWlCUCxLQUFLLElBQUlBLEtBQUE7SUFHckUsT0FBT0UsV0FBQSxDQUFZSSxLQUFBO0VBQ3JCO0FBQ0Y7OztBQ25EQSxJQUFNRSxTQUFBLEdBQVk7RUFDaEJDLE1BQUEsRUFBUSxDQUFDLE1BQU0sSUFBSTtFQUNuQkMsV0FBQSxFQUFhLENBQUMsWUFBWSxVQUFVO0VBQ3BDQyxJQUFBLEVBQU0sQ0FBQyxrQkFBa0IscUJBQWtCO0FBQzdDO0FBRUEsSUFBTUMsYUFBQSxHQUFnQjtFQUNwQkgsTUFBQSxFQUFRLENBQUMsS0FBSyxLQUFLLEtBQUssR0FBRztFQUMzQkMsV0FBQSxFQUFhLENBQUMsTUFBTSxNQUFNLE1BQU0sSUFBSTtFQUNwQ0MsSUFBQSxFQUFNLENBQUMsZ0JBQWdCLGdCQUFnQixnQkFBZ0IsY0FBYztBQUN2RTtBQVFBLElBQU1FLFdBQUEsR0FBYztFQUNsQkosTUFBQSxFQUFRLENBQ04sTUFDQSxNQUNBLFNBQ0EsTUFDQSxNQUNBLE1BQ0EsTUFDQSxNQUNBLE1BQ0EsTUFDQSxNQUNBLEtBQ0Y7RUFPQUMsV0FBQSxFQUFhLENBQ1gsUUFDQSxTQUNBLFdBQ0EsUUFDQSxRQUNBLFFBQ0EsUUFDQSxPQUNBLFFBQ0EsUUFDQSxRQUNBLE9BQ0Y7RUFFQUMsSUFBQSxFQUFNLENBQ0osU0FDQSxVQUNBLFdBQ0EsU0FDQSxRQUNBLFFBQ0EsVUFDQSxTQUNBLFlBQ0EsV0FDQSxZQUNBO0FBRUo7QUFhQSxJQUFNRyxTQUFBLEdBQVk7RUFDaEJMLE1BQUEsRUFBUSxDQUFDLE9BQU8sT0FBTyxPQUFPLE9BQU8sT0FBTyxPQUFPLEtBQUs7RUFDeEQ1QixLQUFBLEVBQU8sQ0FBQyxPQUFPLE9BQU8sT0FBTyxPQUFPLE9BQU8sT0FBTyxLQUFLO0VBQ3ZENkIsV0FBQSxFQUFhLENBQUMsT0FBTyxPQUFPLE9BQU8sT0FBTyxPQUFPLE9BQU8sS0FBSztFQUM3REMsSUFBQSxFQUFNLENBQ0osWUFDQSxXQUNBLFdBQ0EsWUFDQSxVQUNBLGFBQ0E7QUFFSjtBQUtBLElBQU1JLGVBQUEsR0FBa0I7RUFDdEJOLE1BQUEsRUFBUTtJQUNOTyxFQUFBLEVBQUk7SUFDSkMsRUFBQSxFQUFJO0lBQ0pDLFFBQUEsRUFBVTtJQUNWQyxJQUFBLEVBQU07SUFDTkMsT0FBQSxFQUFTO0lBQ1RDLFNBQUEsRUFBVztJQUNYQyxPQUFBLEVBQVM7SUFDVEMsS0FBQSxFQUFPO0VBQ1Q7RUFDQWIsV0FBQSxFQUFhO0lBQ1hNLEVBQUEsRUFBSTtJQUNKQyxFQUFBLEVBQUk7SUFDSkMsUUFBQSxFQUFVO0lBQ1ZDLElBQUEsRUFBTTtJQUNOQyxPQUFBLEVBQVM7SUFDVEMsU0FBQSxFQUFXO0lBQ1hDLE9BQUEsRUFBUztJQUNUQyxLQUFBLEVBQU87RUFDVDtFQUNBWixJQUFBLEVBQU07SUFDSkssRUFBQSxFQUFJO0lBQ0pDLEVBQUEsRUFBSTtJQUNKQyxRQUFBLEVBQVU7SUFDVkMsSUFBQSxFQUFNO0lBQ05DLE9BQUEsRUFBUztJQUNUQyxTQUFBLEVBQVc7SUFDWEMsT0FBQSxFQUFTO0lBQ1RDLEtBQUEsRUFBTztFQUNUO0FBQ0Y7QUFFQSxJQUFNQyx5QkFBQSxHQUE0QjtFQUNoQ2YsTUFBQSxFQUFRO0lBQ05PLEVBQUEsRUFBSTtJQUNKQyxFQUFBLEVBQUk7SUFDSkMsUUFBQSxFQUFVO0lBQ1ZDLElBQUEsRUFBTTtJQUNOQyxPQUFBLEVBQVM7SUFDVEMsU0FBQSxFQUFXO0lBQ1hDLE9BQUEsRUFBUztJQUNUQyxLQUFBLEVBQU87RUFDVDtFQUNBYixXQUFBLEVBQWE7SUFDWE0sRUFBQSxFQUFJO0lBQ0pDLEVBQUEsRUFBSTtJQUNKQyxRQUFBLEVBQVU7SUFDVkMsSUFBQSxFQUFNO0lBQ05DLE9BQUEsRUFBUztJQUNUQyxTQUFBLEVBQVc7SUFDWEMsT0FBQSxFQUFTO0lBQ1RDLEtBQUEsRUFBTztFQUNUO0VBQ0FaLElBQUEsRUFBTTtJQUNKSyxFQUFBLEVBQUk7SUFDSkMsRUFBQSxFQUFJO0lBQ0pDLFFBQUEsRUFBVTtJQUNWQyxJQUFBLEVBQU07SUFDTkMsT0FBQSxFQUFTO0lBQ1RDLFNBQUEsRUFBVztJQUNYQyxPQUFBLEVBQVM7SUFDVEMsS0FBQSxFQUFPO0VBQ1Q7QUFDRjtBQVFBLElBQU1FLGFBQUEsR0FBZ0JBLENBQUNDLFdBQUEsRUFBYTdCLFFBQUEsS0FBYTtFQUMvQyxNQUFNOEIsTUFBQSxHQUFTQyxNQUFBLENBQU9GLFdBQVc7RUFDakMsTUFBTUcsTUFBQSxHQUFTRixNQUFBLEdBQVM7RUFDeEIsSUFBSUUsTUFBQSxHQUFTLE1BQU1BLE1BQUEsR0FBUyxJQUFJO0lBQzlCLFFBQVFBLE1BQUEsR0FBUztNQUFBLEtBQ1Y7UUFDSCxPQUFPRixNQUFBLEdBQVM7TUFBQSxLQUNiO1FBQ0gsT0FBT0EsTUFBQSxHQUFTO01BQUEsS0FDYjtRQUNILE9BQU9BLE1BQUEsR0FBUztNQUFBLEtBQ2I7UUFDSCxPQUFPQSxNQUFBLEdBQVM7SUFBQTtFQUV0QjtFQUNBLE9BQU9BLE1BQUEsR0FBUztBQUNsQjtBQUVPLElBQU1HLFFBQUEsR0FBVztFQUN0QkwsYUFBQTtFQUVBTSxHQUFBLEVBQUtoQyxlQUFBLENBQWdCO0lBQ25CTSxNQUFBLEVBQVFHLFNBQUE7SUFDUmxDLFlBQUEsRUFBYztFQUNoQixDQUFDO0VBRUQwRCxPQUFBLEVBQVNqQyxlQUFBLENBQWdCO0lBQ3ZCTSxNQUFBLEVBQVFPLGFBQUE7SUFDUnRDLFlBQUEsRUFBYztJQUNkaUMsZ0JBQUEsRUFBbUJ5QixPQUFBLElBQVlBLE9BQUEsR0FBVTtFQUMzQyxDQUFDO0VBRURDLEtBQUEsRUFBT2xDLGVBQUEsQ0FBZ0I7SUFDckJNLE1BQUEsRUFBUVEsV0FBQTtJQUNSdkMsWUFBQSxFQUFjO0VBQ2hCLENBQUM7RUFFRDRELEdBQUEsRUFBS25DLGVBQUEsQ0FBZ0I7SUFDbkJNLE1BQUEsRUFBUVMsU0FBQTtJQUNSeEMsWUFBQSxFQUFjO0VBQ2hCLENBQUM7RUFFRDZELFNBQUEsRUFBV3BDLGVBQUEsQ0FBZ0I7SUFDekJNLE1BQUEsRUFBUVUsZUFBQTtJQUNSekMsWUFBQSxFQUFjO0lBQ2Q2QixnQkFBQSxFQUFrQnFCLHlCQUFBO0lBQ2xCcEIsc0JBQUEsRUFBd0I7RUFDMUIsQ0FBQztBQUNIOzs7QUN2T08sU0FBU2dDLGFBQWFoRSxJQUFBLEVBQU07RUFDakMsT0FBTyxDQUFDaUUsTUFBQSxFQUFRekUsT0FBQSxHQUFVLENBQUMsTUFBTTtJQUMvQixNQUFNUyxLQUFBLEdBQVFULE9BQUEsQ0FBUVMsS0FBQTtJQUV0QixNQUFNaUUsWUFBQSxHQUNIakUsS0FBQSxJQUFTRCxJQUFBLENBQUttRSxhQUFBLENBQWNsRSxLQUFBLEtBQzdCRCxJQUFBLENBQUttRSxhQUFBLENBQWNuRSxJQUFBLENBQUtvRSxpQkFBQTtJQUMxQixNQUFNQyxXQUFBLEdBQWNKLE1BQUEsQ0FBT0ssS0FBQSxDQUFNSixZQUFZO0lBRTdDLElBQUksQ0FBQ0csV0FBQSxFQUFhO01BQ2hCLE9BQU87SUFDVDtJQUNBLE1BQU1FLGFBQUEsR0FBZ0JGLFdBQUEsQ0FBWTtJQUVsQyxNQUFNRyxhQUFBLEdBQ0h2RSxLQUFBLElBQVNELElBQUEsQ0FBS3dFLGFBQUEsQ0FBY3ZFLEtBQUEsS0FDN0JELElBQUEsQ0FBS3dFLGFBQUEsQ0FBY3hFLElBQUEsQ0FBS3lFLGlCQUFBO0lBRTFCLE1BQU1DLEdBQUEsR0FBTUMsS0FBQSxDQUFNQyxPQUFBLENBQVFKLGFBQWEsSUFDbkNLLFNBQUEsQ0FBVUwsYUFBQSxFQUFnQk0sT0FBQSxJQUFZQSxPQUFBLENBQVFDLElBQUEsQ0FBS1IsYUFBYSxDQUFDLElBRWpFUyxPQUFBLENBQVFSLGFBQUEsRUFBZ0JNLE9BQUEsSUFBWUEsT0FBQSxDQUFRQyxJQUFBLENBQUtSLGFBQWEsQ0FBQztJQUVuRSxJQUFJM0MsS0FBQTtJQUVKQSxLQUFBLEdBQVE1QixJQUFBLENBQUtpRixhQUFBLEdBQWdCakYsSUFBQSxDQUFLaUYsYUFBQSxDQUFjUCxHQUFHLElBQUlBLEdBQUE7SUFDdkQ5QyxLQUFBLEdBQVFwQyxPQUFBLENBQVF5RixhQUFBLEdBRVp6RixPQUFBLENBQVF5RixhQUFBLENBQWNyRCxLQUFLLElBQzNCQSxLQUFBO0lBRUosTUFBTXNELElBQUEsR0FBT2pCLE1BQUEsQ0FBT2tCLEtBQUEsQ0FBTVosYUFBQSxDQUFjYSxNQUFNO0lBRTlDLE9BQU87TUFBRXhELEtBQUE7TUFBT3NEO0lBQUs7RUFDdkI7QUFDRjtBQUVBLFNBQVNGLFFBQVFLLE1BQUEsRUFBUUMsU0FBQSxFQUFXO0VBQ2xDLFdBQVdaLEdBQUEsSUFBT1csTUFBQSxFQUFRO0lBQ3hCLElBQ0VFLE1BQUEsQ0FBT0MsU0FBQSxDQUFVQyxjQUFBLENBQWVDLElBQUEsQ0FBS0wsTUFBQSxFQUFRWCxHQUFHLEtBQ2hEWSxTQUFBLENBQVVELE1BQUEsQ0FBT1gsR0FBQSxDQUFJLEdBQ3JCO01BQ0EsT0FBT0EsR0FBQTtJQUNUO0VBQ0Y7RUFDQSxPQUFPO0FBQ1Q7QUFFQSxTQUFTRyxVQUFVYyxLQUFBLEVBQU9MLFNBQUEsRUFBVztFQUNuQyxTQUFTWixHQUFBLEdBQU0sR0FBR0EsR0FBQSxHQUFNaUIsS0FBQSxDQUFNUCxNQUFBLEVBQVFWLEdBQUEsSUFBTztJQUMzQyxJQUFJWSxTQUFBLENBQVVLLEtBQUEsQ0FBTWpCLEdBQUEsQ0FBSSxHQUFHO01BQ3pCLE9BQU9BLEdBQUE7SUFDVDtFQUNGO0VBQ0EsT0FBTztBQUNUOzs7QUN4RE8sU0FBU2tCLG9CQUFvQjVGLElBQUEsRUFBTTtFQUN4QyxPQUFPLENBQUNpRSxNQUFBLEVBQVF6RSxPQUFBLEdBQVUsQ0FBQyxNQUFNO0lBQy9CLE1BQU02RSxXQUFBLEdBQWNKLE1BQUEsQ0FBT0ssS0FBQSxDQUFNdEUsSUFBQSxDQUFLa0UsWUFBWTtJQUNsRCxJQUFJLENBQUNHLFdBQUEsRUFBYSxPQUFPO0lBQ3pCLE1BQU1FLGFBQUEsR0FBZ0JGLFdBQUEsQ0FBWTtJQUVsQyxNQUFNd0IsV0FBQSxHQUFjNUIsTUFBQSxDQUFPSyxLQUFBLENBQU10RSxJQUFBLENBQUs4RixZQUFZO0lBQ2xELElBQUksQ0FBQ0QsV0FBQSxFQUFhLE9BQU87SUFDekIsSUFBSWpFLEtBQUEsR0FBUTVCLElBQUEsQ0FBS2lGLGFBQUEsR0FDYmpGLElBQUEsQ0FBS2lGLGFBQUEsQ0FBY1ksV0FBQSxDQUFZLEVBQUUsSUFDakNBLFdBQUEsQ0FBWTtJQUdoQmpFLEtBQUEsR0FBUXBDLE9BQUEsQ0FBUXlGLGFBQUEsR0FBZ0J6RixPQUFBLENBQVF5RixhQUFBLENBQWNyRCxLQUFLLElBQUlBLEtBQUE7SUFFL0QsTUFBTXNELElBQUEsR0FBT2pCLE1BQUEsQ0FBT2tCLEtBQUEsQ0FBTVosYUFBQSxDQUFjYSxNQUFNO0lBRTlDLE9BQU87TUFBRXhELEtBQUE7TUFBT3NEO0lBQUs7RUFDdkI7QUFDRjs7O0FDaEJBLElBQU1hLHlCQUFBLEdBQTRCO0FBQ2xDLElBQU1DLHlCQUFBLEdBQTRCO0FBRWxDLElBQU1DLGdCQUFBLEdBQW1CO0VBQ3ZCNUQsTUFBQSxFQUFRO0VBQ1JDLFdBQUEsRUFBYTtFQUNiQyxJQUFBLEVBQU07QUFDUjtBQUNBLElBQU0yRCxnQkFBQSxHQUFtQjtFQUN2QjdELE1BQUEsRUFBUSxDQUFDLFFBQVEsTUFBTTtFQUN2QkMsV0FBQSxFQUFhLENBQUMsZ0JBQWdCLGNBQWM7RUFDNUNDLElBQUEsRUFBTSxDQUFDLHNCQUFzQix5QkFBeUI7QUFDeEQ7QUFFQSxJQUFNNEQsb0JBQUEsR0FBdUI7RUFDM0I5RCxNQUFBLEVBQVE7RUFDUkMsV0FBQSxFQUFhO0VBQ2JDLElBQUEsRUFBTTtBQUNSO0FBQ0EsSUFBTTZELG9CQUFBLEdBQXVCO0VBQzNCQyxHQUFBLEVBQUssQ0FBQyxNQUFNLE1BQU0sTUFBTSxJQUFJO0FBQzlCO0FBRUEsSUFBTUMsa0JBQUEsR0FBcUI7RUFDekJqRSxNQUFBLEVBQVE7RUFDUkMsV0FBQSxFQUNFO0VBQ0ZDLElBQUEsRUFBTTtBQUNSO0FBQ0EsSUFBTWdFLGtCQUFBLEdBQXFCO0VBQ3pCbEUsTUFBQSxFQUFRLENBQ04sUUFDQSxRQUNBLFFBQ0EsUUFDQSxRQUNBLFFBQ0EsUUFDQSxRQUNBLFFBQ0EsUUFDQSxRQUNBLE9BQ0Y7RUFFQUMsV0FBQSxFQUFhLENBQ1gsVUFDQSxXQUNBLFVBQ0EsVUFDQSxVQUNBLFVBQ0EsVUFDQSxTQUNBLFVBQ0EsVUFDQSxVQUNBLFNBQ0Y7RUFFQUMsSUFBQSxFQUFNLENBQ0osV0FDQSxZQUNBLFVBQ0EsV0FDQSxVQUNBLFVBQ0EsWUFDQSxXQUNBLGNBQ0EsYUFDQSxjQUNBO0FBRUo7QUFFQSxJQUFNaUUsZ0JBQUEsR0FBbUI7RUFDdkJuRSxNQUFBLEVBQVE7RUFDUjVCLEtBQUEsRUFBTztFQUNQNkIsV0FBQSxFQUFhO0VBQ2JDLElBQUEsRUFBTTtBQUNSO0FBQ0EsSUFBTWtFLGdCQUFBLEdBQW1CO0VBQ3ZCcEUsTUFBQSxFQUFRLENBQUMsU0FBUyxTQUFTLFNBQVMsU0FBUyxTQUFTLFNBQVMsT0FBTztFQUV0RUMsV0FBQSxFQUFhLENBQUMsU0FBUyxTQUFTLFNBQVMsU0FBUyxTQUFTLFNBQVMsT0FBTztFQUUzRUMsSUFBQSxFQUFNLENBQ0osY0FDQSxhQUNBLGFBQ0EsY0FDQSxZQUNBLGVBQ0E7QUFFSjtBQUVBLElBQU1tRSxzQkFBQSxHQUF5QjtFQUM3QnJFLE1BQUEsRUFBUTtFQUNSQyxXQUFBLEVBQ0U7RUFDRkMsSUFBQSxFQUFNO0FBQ1I7QUFDQSxJQUFNb0Usc0JBQUEsR0FBeUI7RUFDN0JOLEdBQUEsRUFBSztJQUNIekQsRUFBQSxFQUFJO0lBQ0pDLEVBQUEsRUFBSTtJQUNKQyxRQUFBLEVBQVU7SUFDVkMsSUFBQSxFQUFNO0lBQ05DLE9BQUEsRUFBUztJQUNUQyxTQUFBLEVBQVc7SUFDWEMsT0FBQSxFQUFTO0lBQ1RDLEtBQUEsRUFBTztFQUNUO0FBQ0Y7QUFFTyxJQUFNbUIsS0FBQSxHQUFRO0VBQ25CakIsYUFBQSxFQUFldUMsbUJBQUEsQ0FBb0I7SUFDakMxQixZQUFBLEVBQWM2Qix5QkFBQTtJQUNkRCxZQUFBLEVBQWNFLHlCQUFBO0lBQ2RmLGFBQUEsRUFBZ0JyRCxLQUFBLElBQVVnRixRQUFBLENBQVNoRixLQUFBLEVBQU8sRUFBRTtFQUM5QyxDQUFDO0VBRUQrQixHQUFBLEVBQUtLLFlBQUEsQ0FBYTtJQUNoQkcsYUFBQSxFQUFlOEIsZ0JBQUE7SUFDZjdCLGlCQUFBLEVBQW1CO0lBQ25CSSxhQUFBLEVBQWUwQixnQkFBQTtJQUNmekIsaUJBQUEsRUFBbUI7RUFDckIsQ0FBQztFQUVEYixPQUFBLEVBQVNJLFlBQUEsQ0FBYTtJQUNwQkcsYUFBQSxFQUFlZ0Msb0JBQUE7SUFDZi9CLGlCQUFBLEVBQW1CO0lBQ25CSSxhQUFBLEVBQWU0QixvQkFBQTtJQUNmM0IsaUJBQUEsRUFBbUI7SUFDbkJRLGFBQUEsRUFBZ0IvQyxLQUFBLElBQVVBLEtBQUEsR0FBUTtFQUNwQyxDQUFDO0VBRUQyQixLQUFBLEVBQU9HLFlBQUEsQ0FBYTtJQUNsQkcsYUFBQSxFQUFlbUMsa0JBQUE7SUFDZmxDLGlCQUFBLEVBQW1CO0lBQ25CSSxhQUFBLEVBQWUrQixrQkFBQTtJQUNmOUIsaUJBQUEsRUFBbUI7RUFDckIsQ0FBQztFQUVEWCxHQUFBLEVBQUtFLFlBQUEsQ0FBYTtJQUNoQkcsYUFBQSxFQUFlcUMsZ0JBQUE7SUFDZnBDLGlCQUFBLEVBQW1CO0lBQ25CSSxhQUFBLEVBQWVpQyxnQkFBQTtJQUNmaEMsaUJBQUEsRUFBbUI7RUFDckIsQ0FBQztFQUVEVixTQUFBLEVBQVdDLFlBQUEsQ0FBYTtJQUN0QkcsYUFBQSxFQUFldUMsc0JBQUE7SUFDZnRDLGlCQUFBLEVBQW1CO0lBQ25CSSxhQUFBLEVBQWVtQyxzQkFBQTtJQUNmbEMsaUJBQUEsRUFBbUI7RUFDckIsQ0FBQztBQUNIOzs7QUNwSk8sSUFBTTlHLEVBQUEsR0FBSztFQUNoQmtKLElBQUEsRUFBTTtFQUNOeEgsY0FBQTtFQUNBdUIsVUFBQTtFQUNBVyxjQUFBO0VBQ0FtQyxRQUFBO0VBQ0FZLEtBQUE7RUFDQTlFLE9BQUEsRUFBUztJQUNQc0gsWUFBQSxFQUFjO0lBQ2RDLHFCQUFBLEVBQXVCO0VBQ3pCO0FBQ0Y7QUFHQSxJQUFPQyxVQUFBLEdBQVFySixFQUFBOzs7QVZ6QmYsSUFBT0UsZ0JBQUEsR0FBUW1KLFVBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=