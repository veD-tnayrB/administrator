System.register([], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/locale/da.3.6.0.js
var da_3_6_0_exports = {};
__export(da_3_6_0_exports, {
  da: () => da,
  default: () => da_3_6_0_default
});
module.exports = __toCommonJS(da_3_6_0_exports);

// node_modules/date-fns/locale/da/_lib/formatDistance.mjs
var formatDistanceLocale = {
  lessThanXSeconds: {
    one: "mindre end \xE9t sekund",
    other: "mindre end {{count}} sekunder"
  },
  xSeconds: {
    one: "1 sekund",
    other: "{{count}} sekunder"
  },
  halfAMinute: "\xE9t halvt minut",
  lessThanXMinutes: {
    one: "mindre end \xE9t minut",
    other: "mindre end {{count}} minutter"
  },
  xMinutes: {
    one: "1 minut",
    other: "{{count}} minutter"
  },
  aboutXHours: {
    one: "cirka 1 time",
    other: "cirka {{count}} timer"
  },
  xHours: {
    one: "1 time",
    other: "{{count}} timer"
  },
  xDays: {
    one: "1 dag",
    other: "{{count}} dage"
  },
  aboutXWeeks: {
    one: "cirka 1 uge",
    other: "cirka {{count}} uger"
  },
  xWeeks: {
    one: "1 uge",
    other: "{{count}} uger"
  },
  aboutXMonths: {
    one: "cirka 1 m\xE5ned",
    other: "cirka {{count}} m\xE5neder"
  },
  xMonths: {
    one: "1 m\xE5ned",
    other: "{{count}} m\xE5neder"
  },
  aboutXYears: {
    one: "cirka 1 \xE5r",
    other: "cirka {{count}} \xE5r"
  },
  xYears: {
    one: "1 \xE5r",
    other: "{{count}} \xE5r"
  },
  overXYears: {
    one: "over 1 \xE5r",
    other: "over {{count}} \xE5r"
  },
  almostXYears: {
    one: "n\xE6sten 1 \xE5r",
    other: "n\xE6sten {{count}} \xE5r"
  }
};
var formatDistance = (token, count, options) => {
  let result;
  const tokenValue = formatDistanceLocale[token];
  if (typeof tokenValue === "string") {
    result = tokenValue;
  } else if (count === 1) {
    result = tokenValue.one;
  } else {
    result = tokenValue.other.replace("{{count}}", String(count));
  }
  if (options?.addSuffix) {
    if (options.comparison && options.comparison > 0) {
      return "om " + result;
    } else {
      return result + " siden";
    }
  }
  return result;
};

// node_modules/date-fns/locale/_lib/buildFormatLongFn.mjs
function buildFormatLongFn(args) {
  return (options = {}) => {
    const width = options.width ? String(options.width) : args.defaultWidth;
    const format = args.formats[width] || args.formats[args.defaultWidth];
    return format;
  };
}

// node_modules/date-fns/locale/da/_lib/formatLong.mjs
var dateFormats = {
  full: "EEEE 'den' d. MMMM y",
  long: "d. MMMM y",
  medium: "d. MMM y",
  short: "dd/MM/y"
};
var timeFormats = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
};
var dateTimeFormats = {
  full: "{{date}} 'kl'. {{time}}",
  long: "{{date}} 'kl'. {{time}}",
  medium: "{{date}} {{time}}",
  short: "{{date}} {{time}}"
};
var formatLong = {
  date: buildFormatLongFn({
    formats: dateFormats,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats,
    defaultWidth: "full"
  })
};

// node_modules/date-fns/locale/da/_lib/formatRelative.mjs
var formatRelativeLocale = {
  lastWeek: "'sidste' eeee 'kl.' p",
  yesterday: "'i g\xE5r kl.' p",
  today: "'i dag kl.' p",
  tomorrow: "'i morgen kl.' p",
  nextWeek: "'p\xE5' eeee 'kl.' p",
  other: "P"
};
var formatRelative = (token, _date, _baseDate, _options) => formatRelativeLocale[token];

// node_modules/date-fns/locale/_lib/buildLocalizeFn.mjs
function buildLocalizeFn(args) {
  return (value, options) => {
    const context = options?.context ? String(options.context) : "standalone";
    let valuesArray;
    if (context === "formatting" && args.formattingValues) {
      const defaultWidth = args.defaultFormattingWidth || args.defaultWidth;
      const width = options?.width ? String(options.width) : defaultWidth;
      valuesArray = args.formattingValues[width] || args.formattingValues[defaultWidth];
    } else {
      const defaultWidth = args.defaultWidth;
      const width = options?.width ? String(options.width) : args.defaultWidth;
      valuesArray = args.values[width] || args.values[defaultWidth];
    }
    const index = args.argumentCallback ? args.argumentCallback(value) : value;
    return valuesArray[index];
  };
}

// node_modules/date-fns/locale/da/_lib/localize.mjs
var eraValues = {
  narrow: ["fvt", "vt"],
  abbreviated: ["f.v.t.", "v.t."],
  wide: ["f\xF8r vesterlandsk tidsregning", "vesterlandsk tidsregning"]
};
var quarterValues = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["1. kvt.", "2. kvt.", "3. kvt.", "4. kvt."],
  wide: ["1. kvartal", "2. kvartal", "3. kvartal", "4. kvartal"]
};
var monthValues = {
  narrow: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
  abbreviated: ["jan.", "feb.", "mar.", "apr.", "maj", "jun.", "jul.", "aug.", "sep.", "okt.", "nov.", "dec."],
  wide: ["januar", "februar", "marts", "april", "maj", "juni", "juli", "august", "september", "oktober", "november", "december"]
};
var dayValues = {
  narrow: ["S", "M", "T", "O", "T", "F", "L"],
  short: ["s\xF8", "ma", "ti", "on", "to", "fr", "l\xF8"],
  abbreviated: ["s\xF8n.", "man.", "tir.", "ons.", "tor.", "fre.", "l\xF8r."],
  wide: ["s\xF8ndag", "mandag", "tirsdag", "onsdag", "torsdag", "fredag", "l\xF8rdag"]
};
var dayPeriodValues = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "midnat",
    noon: "middag",
    morning: "morgen",
    afternoon: "eftermiddag",
    evening: "aften",
    night: "nat"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "midnat",
    noon: "middag",
    morning: "morgen",
    afternoon: "eftermiddag",
    evening: "aften",
    night: "nat"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "midnat",
    noon: "middag",
    morning: "morgen",
    afternoon: "eftermiddag",
    evening: "aften",
    night: "nat"
  }
};
var formattingDayPeriodValues = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "midnat",
    noon: "middag",
    morning: "om morgenen",
    afternoon: "om eftermiddagen",
    evening: "om aftenen",
    night: "om natten"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "midnat",
    noon: "middag",
    morning: "om morgenen",
    afternoon: "om eftermiddagen",
    evening: "om aftenen",
    night: "om natten"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "midnat",
    noon: "middag",
    morning: "om morgenen",
    afternoon: "om eftermiddagen",
    evening: "om aftenen",
    night: "om natten"
  }
};
var ordinalNumber = (dirtyNumber, _options) => {
  const number = Number(dirtyNumber);
  return number + ".";
};
var localize = {
  ordinalNumber,
  era: buildLocalizeFn({
    values: eraValues,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues,
    defaultWidth: "wide",
    argumentCallback: quarter => quarter - 1
  }),
  month: buildLocalizeFn({
    values: monthValues,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues,
    defaultFormattingWidth: "wide"
  })
};

// node_modules/date-fns/locale/_lib/buildMatchFn.mjs
function buildMatchFn(args) {
  return (string, options = {}) => {
    const width = options.width;
    const matchPattern = width && args.matchPatterns[width] || args.matchPatterns[args.defaultMatchWidth];
    const matchResult = string.match(matchPattern);
    if (!matchResult) {
      return null;
    }
    const matchedString = matchResult[0];
    const parsePatterns = width && args.parsePatterns[width] || args.parsePatterns[args.defaultParseWidth];
    const key = Array.isArray(parsePatterns) ? findIndex(parsePatterns, pattern => pattern.test(matchedString)) : findKey(parsePatterns, pattern => pattern.test(matchedString));
    let value;
    value = args.valueCallback ? args.valueCallback(key) : key;
    value = options.valueCallback ? options.valueCallback(value) : value;
    const rest = string.slice(matchedString.length);
    return {
      value,
      rest
    };
  };
}
function findKey(object, predicate) {
  for (const key in object) {
    if (Object.prototype.hasOwnProperty.call(object, key) && predicate(object[key])) {
      return key;
    }
  }
  return void 0;
}
function findIndex(array, predicate) {
  for (let key = 0; key < array.length; key++) {
    if (predicate(array[key])) {
      return key;
    }
  }
  return void 0;
}

// node_modules/date-fns/locale/_lib/buildMatchPatternFn.mjs
function buildMatchPatternFn(args) {
  return (string, options = {}) => {
    const matchResult = string.match(args.matchPattern);
    if (!matchResult) return null;
    const matchedString = matchResult[0];
    const parseResult = string.match(args.parsePattern);
    if (!parseResult) return null;
    let value = args.valueCallback ? args.valueCallback(parseResult[0]) : parseResult[0];
    value = options.valueCallback ? options.valueCallback(value) : value;
    const rest = string.slice(matchedString.length);
    return {
      value,
      rest
    };
  };
}

// node_modules/date-fns/locale/da/_lib/match.mjs
var matchOrdinalNumberPattern = /^(\d+)(\.)?/i;
var parseOrdinalNumberPattern = /\d+/i;
var matchEraPatterns = {
  narrow: /^(fKr|fvt|eKr|vt)/i,
  abbreviated: /^(f\.Kr\.?|f\.v\.t\.?|e\.Kr\.?|v\.t\.)/i,
  wide: /^(f.Kr.|før vesterlandsk tidsregning|e.Kr.|vesterlandsk tidsregning)/i
};
var parseEraPatterns = {
  any: [/^f/i, /^(v|e)/i]
};
var matchQuarterPatterns = {
  narrow: /^[1234]/i,
  abbreviated: /^[1234]. kvt\./i,
  wide: /^[1234]\.? kvartal/i
};
var parseQuarterPatterns = {
  any: [/1/i, /2/i, /3/i, /4/i]
};
var matchMonthPatterns = {
  narrow: /^[jfmasond]/i,
  abbreviated: /^(jan.|feb.|mar.|apr.|maj|jun.|jul.|aug.|sep.|okt.|nov.|dec.)/i,
  wide: /^(januar|februar|marts|april|maj|juni|juli|august|september|oktober|november|december)/i
};
var parseMonthPatterns = {
  narrow: [/^j/i, /^f/i, /^m/i, /^a/i, /^m/i, /^j/i, /^j/i, /^a/i, /^s/i, /^o/i, /^n/i, /^d/i],
  any: [/^ja/i, /^f/i, /^mar/i, /^ap/i, /^maj/i, /^jun/i, /^jul/i, /^au/i, /^s/i, /^o/i, /^n/i, /^d/i]
};
var matchDayPatterns = {
  narrow: /^[smtofl]/i,
  short: /^(søn.|man.|tir.|ons.|tor.|fre.|lør.)/i,
  abbreviated: /^(søn|man|tir|ons|tor|fre|lør)/i,
  wide: /^(søndag|mandag|tirsdag|onsdag|torsdag|fredag|lørdag)/i
};
var parseDayPatterns = {
  narrow: [/^s/i, /^m/i, /^t/i, /^o/i, /^t/i, /^f/i, /^l/i],
  any: [/^s/i, /^m/i, /^ti/i, /^o/i, /^to/i, /^f/i, /^l/i]
};
var matchDayPeriodPatterns = {
  narrow: /^(a|p|midnat|middag|(om) (morgenen|eftermiddagen|aftenen|natten))/i,
  any: /^([ap]\.?\s?m\.?|midnat|middag|(om) (morgenen|eftermiddagen|aftenen|natten))/i
};
var parseDayPeriodPatterns = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /midnat/i,
    noon: /middag/i,
    morning: /morgen/i,
    afternoon: /eftermiddag/i,
    evening: /aften/i,
    night: /nat/i
  }
};
var match = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern,
    parsePattern: parseOrdinalNumberPattern,
    valueCallback: value => parseInt(value, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns,
    defaultParseWidth: "any",
    valueCallback: index => index + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns,
    defaultParseWidth: "any"
  })
};

// node_modules/date-fns/locale/da.mjs
var da = {
  code: "da",
  formatDistance,
  formatLong,
  formatRelative,
  localize,
  match,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
};
var da_default = da;

// .beyond/uimport/temp/date-fns/locale/da.3.6.0.js
var da_3_6_0_default = da_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2xvY2FsZS9kYS4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9sb2NhbGUvZGEvX2xpYi9mb3JtYXREaXN0YW5jZS5tanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvbG9jYWxlL19saWIvYnVpbGRGb3JtYXRMb25nRm4ubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9kYS9fbGliL2Zvcm1hdExvbmcubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9kYS9fbGliL2Zvcm1hdFJlbGF0aXZlLm1qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9sb2NhbGUvX2xpYi9idWlsZExvY2FsaXplRm4ubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9kYS9fbGliL2xvY2FsaXplLm1qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9sb2NhbGUvX2xpYi9idWlsZE1hdGNoRm4ubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9fbGliL2J1aWxkTWF0Y2hQYXR0ZXJuRm4ubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9kYS9fbGliL21hdGNoLm1qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9sb2NhbGUvZGEubWpzIl0sIm5hbWVzIjpbImRhXzNfNl8wX2V4cG9ydHMiLCJfX2V4cG9ydCIsImRhIiwiZGVmYXVsdCIsImRhXzNfNl8wX2RlZmF1bHQiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiZm9ybWF0RGlzdGFuY2VMb2NhbGUiLCJsZXNzVGhhblhTZWNvbmRzIiwib25lIiwib3RoZXIiLCJ4U2Vjb25kcyIsImhhbGZBTWludXRlIiwibGVzc1RoYW5YTWludXRlcyIsInhNaW51dGVzIiwiYWJvdXRYSG91cnMiLCJ4SG91cnMiLCJ4RGF5cyIsImFib3V0WFdlZWtzIiwieFdlZWtzIiwiYWJvdXRYTW9udGhzIiwieE1vbnRocyIsImFib3V0WFllYXJzIiwieFllYXJzIiwib3ZlclhZZWFycyIsImFsbW9zdFhZZWFycyIsImZvcm1hdERpc3RhbmNlIiwidG9rZW4iLCJjb3VudCIsIm9wdGlvbnMiLCJyZXN1bHQiLCJ0b2tlblZhbHVlIiwicmVwbGFjZSIsIlN0cmluZyIsImFkZFN1ZmZpeCIsImNvbXBhcmlzb24iLCJidWlsZEZvcm1hdExvbmdGbiIsImFyZ3MiLCJ3aWR0aCIsImRlZmF1bHRXaWR0aCIsImZvcm1hdCIsImZvcm1hdHMiLCJkYXRlRm9ybWF0cyIsImZ1bGwiLCJsb25nIiwibWVkaXVtIiwic2hvcnQiLCJ0aW1lRm9ybWF0cyIsImRhdGVUaW1lRm9ybWF0cyIsImZvcm1hdExvbmciLCJkYXRlIiwidGltZSIsImRhdGVUaW1lIiwiZm9ybWF0UmVsYXRpdmVMb2NhbGUiLCJsYXN0V2VlayIsInllc3RlcmRheSIsInRvZGF5IiwidG9tb3Jyb3ciLCJuZXh0V2VlayIsImZvcm1hdFJlbGF0aXZlIiwiX2RhdGUiLCJfYmFzZURhdGUiLCJfb3B0aW9ucyIsImJ1aWxkTG9jYWxpemVGbiIsInZhbHVlIiwiY29udGV4dCIsInZhbHVlc0FycmF5IiwiZm9ybWF0dGluZ1ZhbHVlcyIsImRlZmF1bHRGb3JtYXR0aW5nV2lkdGgiLCJ2YWx1ZXMiLCJpbmRleCIsImFyZ3VtZW50Q2FsbGJhY2siLCJlcmFWYWx1ZXMiLCJuYXJyb3ciLCJhYmJyZXZpYXRlZCIsIndpZGUiLCJxdWFydGVyVmFsdWVzIiwibW9udGhWYWx1ZXMiLCJkYXlWYWx1ZXMiLCJkYXlQZXJpb2RWYWx1ZXMiLCJhbSIsInBtIiwibWlkbmlnaHQiLCJub29uIiwibW9ybmluZyIsImFmdGVybm9vbiIsImV2ZW5pbmciLCJuaWdodCIsImZvcm1hdHRpbmdEYXlQZXJpb2RWYWx1ZXMiLCJvcmRpbmFsTnVtYmVyIiwiZGlydHlOdW1iZXIiLCJudW1iZXIiLCJOdW1iZXIiLCJsb2NhbGl6ZSIsImVyYSIsInF1YXJ0ZXIiLCJtb250aCIsImRheSIsImRheVBlcmlvZCIsImJ1aWxkTWF0Y2hGbiIsInN0cmluZyIsIm1hdGNoUGF0dGVybiIsIm1hdGNoUGF0dGVybnMiLCJkZWZhdWx0TWF0Y2hXaWR0aCIsIm1hdGNoUmVzdWx0IiwibWF0Y2giLCJtYXRjaGVkU3RyaW5nIiwicGFyc2VQYXR0ZXJucyIsImRlZmF1bHRQYXJzZVdpZHRoIiwia2V5IiwiQXJyYXkiLCJpc0FycmF5IiwiZmluZEluZGV4IiwicGF0dGVybiIsInRlc3QiLCJmaW5kS2V5IiwidmFsdWVDYWxsYmFjayIsInJlc3QiLCJzbGljZSIsImxlbmd0aCIsIm9iamVjdCIsInByZWRpY2F0ZSIsIk9iamVjdCIsInByb3RvdHlwZSIsImhhc093blByb3BlcnR5IiwiY2FsbCIsImFycmF5IiwiYnVpbGRNYXRjaFBhdHRlcm5GbiIsInBhcnNlUmVzdWx0IiwicGFyc2VQYXR0ZXJuIiwibWF0Y2hPcmRpbmFsTnVtYmVyUGF0dGVybiIsInBhcnNlT3JkaW5hbE51bWJlclBhdHRlcm4iLCJtYXRjaEVyYVBhdHRlcm5zIiwicGFyc2VFcmFQYXR0ZXJucyIsImFueSIsIm1hdGNoUXVhcnRlclBhdHRlcm5zIiwicGFyc2VRdWFydGVyUGF0dGVybnMiLCJtYXRjaE1vbnRoUGF0dGVybnMiLCJwYXJzZU1vbnRoUGF0dGVybnMiLCJtYXRjaERheVBhdHRlcm5zIiwicGFyc2VEYXlQYXR0ZXJucyIsIm1hdGNoRGF5UGVyaW9kUGF0dGVybnMiLCJwYXJzZURheVBlcmlvZFBhdHRlcm5zIiwicGFyc2VJbnQiLCJjb2RlIiwid2Vla1N0YXJ0c09uIiwiZmlyc3RXZWVrQ29udGFpbnNEYXRlIiwiZGFfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsZ0JBQUE7QUFBQUMsUUFBQSxDQUFBRCxnQkFBQTtFQUFBRSxFQUFBLEVBQUFBLENBQUEsS0FBQUEsRUFBQTtFQUFBQyxPQUFBLEVBQUFBLENBQUEsS0FBQUM7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCxnQkFBQTs7O0FDQUEsSUFBTVEsb0JBQUEsR0FBdUI7RUFDM0JDLGdCQUFBLEVBQWtCO0lBQ2hCQyxHQUFBLEVBQUs7SUFDTEMsS0FBQSxFQUFPO0VBQ1Q7RUFFQUMsUUFBQSxFQUFVO0lBQ1JGLEdBQUEsRUFBSztJQUNMQyxLQUFBLEVBQU87RUFDVDtFQUVBRSxXQUFBLEVBQWE7RUFFYkMsZ0JBQUEsRUFBa0I7SUFDaEJKLEdBQUEsRUFBSztJQUNMQyxLQUFBLEVBQU87RUFDVDtFQUVBSSxRQUFBLEVBQVU7SUFDUkwsR0FBQSxFQUFLO0lBQ0xDLEtBQUEsRUFBTztFQUNUO0VBRUFLLFdBQUEsRUFBYTtJQUNYTixHQUFBLEVBQUs7SUFDTEMsS0FBQSxFQUFPO0VBQ1Q7RUFFQU0sTUFBQSxFQUFRO0lBQ05QLEdBQUEsRUFBSztJQUNMQyxLQUFBLEVBQU87RUFDVDtFQUVBTyxLQUFBLEVBQU87SUFDTFIsR0FBQSxFQUFLO0lBQ0xDLEtBQUEsRUFBTztFQUNUO0VBRUFRLFdBQUEsRUFBYTtJQUNYVCxHQUFBLEVBQUs7SUFDTEMsS0FBQSxFQUFPO0VBQ1Q7RUFFQVMsTUFBQSxFQUFRO0lBQ05WLEdBQUEsRUFBSztJQUNMQyxLQUFBLEVBQU87RUFDVDtFQUVBVSxZQUFBLEVBQWM7SUFDWlgsR0FBQSxFQUFLO0lBQ0xDLEtBQUEsRUFBTztFQUNUO0VBRUFXLE9BQUEsRUFBUztJQUNQWixHQUFBLEVBQUs7SUFDTEMsS0FBQSxFQUFPO0VBQ1Q7RUFFQVksV0FBQSxFQUFhO0lBQ1hiLEdBQUEsRUFBSztJQUNMQyxLQUFBLEVBQU87RUFDVDtFQUVBYSxNQUFBLEVBQVE7SUFDTmQsR0FBQSxFQUFLO0lBQ0xDLEtBQUEsRUFBTztFQUNUO0VBRUFjLFVBQUEsRUFBWTtJQUNWZixHQUFBLEVBQUs7SUFDTEMsS0FBQSxFQUFPO0VBQ1Q7RUFFQWUsWUFBQSxFQUFjO0lBQ1poQixHQUFBLEVBQUs7SUFDTEMsS0FBQSxFQUFPO0VBQ1Q7QUFDRjtBQUVPLElBQU1nQixjQUFBLEdBQWlCQSxDQUFDQyxLQUFBLEVBQU9DLEtBQUEsRUFBT0MsT0FBQSxLQUFZO0VBQ3ZELElBQUlDLE1BQUE7RUFFSixNQUFNQyxVQUFBLEdBQWF4QixvQkFBQSxDQUFxQm9CLEtBQUE7RUFDeEMsSUFBSSxPQUFPSSxVQUFBLEtBQWUsVUFBVTtJQUNsQ0QsTUFBQSxHQUFTQyxVQUFBO0VBQ1gsV0FBV0gsS0FBQSxLQUFVLEdBQUc7SUFDdEJFLE1BQUEsR0FBU0MsVUFBQSxDQUFXdEIsR0FBQTtFQUN0QixPQUFPO0lBQ0xxQixNQUFBLEdBQVNDLFVBQUEsQ0FBV3JCLEtBQUEsQ0FBTXNCLE9BQUEsQ0FBUSxhQUFhQyxNQUFBLENBQU9MLEtBQUssQ0FBQztFQUM5RDtFQUVBLElBQUlDLE9BQUEsRUFBU0ssU0FBQSxFQUFXO0lBQ3RCLElBQUlMLE9BQUEsQ0FBUU0sVUFBQSxJQUFjTixPQUFBLENBQVFNLFVBQUEsR0FBYSxHQUFHO01BQ2hELE9BQU8sUUFBUUwsTUFBQTtJQUNqQixPQUFPO01BQ0wsT0FBT0EsTUFBQSxHQUFTO0lBQ2xCO0VBQ0Y7RUFFQSxPQUFPQSxNQUFBO0FBQ1Q7OztBQ3BHTyxTQUFTTSxrQkFBa0JDLElBQUEsRUFBTTtFQUN0QyxPQUFPLENBQUNSLE9BQUEsR0FBVSxDQUFDLE1BQU07SUFFdkIsTUFBTVMsS0FBQSxHQUFRVCxPQUFBLENBQVFTLEtBQUEsR0FBUUwsTUFBQSxDQUFPSixPQUFBLENBQVFTLEtBQUssSUFBSUQsSUFBQSxDQUFLRSxZQUFBO0lBQzNELE1BQU1DLE1BQUEsR0FBU0gsSUFBQSxDQUFLSSxPQUFBLENBQVFILEtBQUEsS0FBVUQsSUFBQSxDQUFLSSxPQUFBLENBQVFKLElBQUEsQ0FBS0UsWUFBQTtJQUN4RCxPQUFPQyxNQUFBO0VBQ1Q7QUFDRjs7O0FDTEEsSUFBTUUsV0FBQSxHQUFjO0VBQ2xCQyxJQUFBLEVBQU07RUFDTkMsSUFBQSxFQUFNO0VBQ05DLE1BQUEsRUFBUTtFQUNSQyxLQUFBLEVBQU87QUFDVDtBQUVBLElBQU1DLFdBQUEsR0FBYztFQUNsQkosSUFBQSxFQUFNO0VBQ05DLElBQUEsRUFBTTtFQUNOQyxNQUFBLEVBQVE7RUFDUkMsS0FBQSxFQUFPO0FBQ1Q7QUFFQSxJQUFNRSxlQUFBLEdBQWtCO0VBQ3RCTCxJQUFBLEVBQU07RUFDTkMsSUFBQSxFQUFNO0VBQ05DLE1BQUEsRUFBUTtFQUNSQyxLQUFBLEVBQU87QUFDVDtBQUVPLElBQU1HLFVBQUEsR0FBYTtFQUN4QkMsSUFBQSxFQUFNZCxpQkFBQSxDQUFrQjtJQUN0QkssT0FBQSxFQUFTQyxXQUFBO0lBQ1RILFlBQUEsRUFBYztFQUNoQixDQUFDO0VBRURZLElBQUEsRUFBTWYsaUJBQUEsQ0FBa0I7SUFDdEJLLE9BQUEsRUFBU00sV0FBQTtJQUNUUixZQUFBLEVBQWM7RUFDaEIsQ0FBQztFQUVEYSxRQUFBLEVBQVVoQixpQkFBQSxDQUFrQjtJQUMxQkssT0FBQSxFQUFTTyxlQUFBO0lBQ1RULFlBQUEsRUFBYztFQUNoQixDQUFDO0FBQ0g7OztBQ3RDQSxJQUFNYyxvQkFBQSxHQUF1QjtFQUMzQkMsUUFBQSxFQUFVO0VBQ1ZDLFNBQUEsRUFBVztFQUNYQyxLQUFBLEVBQU87RUFDUEMsUUFBQSxFQUFVO0VBQ1ZDLFFBQUEsRUFBVTtFQUNWaEQsS0FBQSxFQUFPO0FBQ1Q7QUFFTyxJQUFNaUQsY0FBQSxHQUFpQkEsQ0FBQ2hDLEtBQUEsRUFBT2lDLEtBQUEsRUFBT0MsU0FBQSxFQUFXQyxRQUFBLEtBQ3REVCxvQkFBQSxDQUFxQjFCLEtBQUE7OztBQytCaEIsU0FBU29DLGdCQUFnQjFCLElBQUEsRUFBTTtFQUNwQyxPQUFPLENBQUMyQixLQUFBLEVBQU9uQyxPQUFBLEtBQVk7SUFDekIsTUFBTW9DLE9BQUEsR0FBVXBDLE9BQUEsRUFBU29DLE9BQUEsR0FBVWhDLE1BQUEsQ0FBT0osT0FBQSxDQUFRb0MsT0FBTyxJQUFJO0lBRTdELElBQUlDLFdBQUE7SUFDSixJQUFJRCxPQUFBLEtBQVksZ0JBQWdCNUIsSUFBQSxDQUFLOEIsZ0JBQUEsRUFBa0I7TUFDckQsTUFBTTVCLFlBQUEsR0FBZUYsSUFBQSxDQUFLK0Isc0JBQUEsSUFBMEIvQixJQUFBLENBQUtFLFlBQUE7TUFDekQsTUFBTUQsS0FBQSxHQUFRVCxPQUFBLEVBQVNTLEtBQUEsR0FBUUwsTUFBQSxDQUFPSixPQUFBLENBQVFTLEtBQUssSUFBSUMsWUFBQTtNQUV2RDJCLFdBQUEsR0FDRTdCLElBQUEsQ0FBSzhCLGdCQUFBLENBQWlCN0IsS0FBQSxLQUFVRCxJQUFBLENBQUs4QixnQkFBQSxDQUFpQjVCLFlBQUE7SUFDMUQsT0FBTztNQUNMLE1BQU1BLFlBQUEsR0FBZUYsSUFBQSxDQUFLRSxZQUFBO01BQzFCLE1BQU1ELEtBQUEsR0FBUVQsT0FBQSxFQUFTUyxLQUFBLEdBQVFMLE1BQUEsQ0FBT0osT0FBQSxDQUFRUyxLQUFLLElBQUlELElBQUEsQ0FBS0UsWUFBQTtNQUU1RDJCLFdBQUEsR0FBYzdCLElBQUEsQ0FBS2dDLE1BQUEsQ0FBTy9CLEtBQUEsS0FBVUQsSUFBQSxDQUFLZ0MsTUFBQSxDQUFPOUIsWUFBQTtJQUNsRDtJQUNBLE1BQU0rQixLQUFBLEdBQVFqQyxJQUFBLENBQUtrQyxnQkFBQSxHQUFtQmxDLElBQUEsQ0FBS2tDLGdCQUFBLENBQWlCUCxLQUFLLElBQUlBLEtBQUE7SUFHckUsT0FBT0UsV0FBQSxDQUFZSSxLQUFBO0VBQ3JCO0FBQ0Y7OztBQzdEQSxJQUFNRSxTQUFBLEdBQVk7RUFDaEJDLE1BQUEsRUFBUSxDQUFDLE9BQU8sSUFBSTtFQUNwQkMsV0FBQSxFQUFhLENBQUMsVUFBVSxNQUFNO0VBQzlCQyxJQUFBLEVBQU0sQ0FBQyxtQ0FBZ0MsMEJBQTBCO0FBQ25FO0FBRUEsSUFBTUMsYUFBQSxHQUFnQjtFQUNwQkgsTUFBQSxFQUFRLENBQUMsS0FBSyxLQUFLLEtBQUssR0FBRztFQUMzQkMsV0FBQSxFQUFhLENBQUMsV0FBVyxXQUFXLFdBQVcsU0FBUztFQUN4REMsSUFBQSxFQUFNLENBQUMsY0FBYyxjQUFjLGNBQWMsWUFBWTtBQUMvRDtBQUVBLElBQU1FLFdBQUEsR0FBYztFQUNsQkosTUFBQSxFQUFRLENBQUMsS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEdBQUc7RUFDbkVDLFdBQUEsRUFBYSxDQUNYLFFBQ0EsUUFDQSxRQUNBLFFBQ0EsT0FDQSxRQUNBLFFBQ0EsUUFDQSxRQUNBLFFBQ0EsUUFDQSxPQUNGO0VBRUFDLElBQUEsRUFBTSxDQUNKLFVBQ0EsV0FDQSxTQUNBLFNBQ0EsT0FDQSxRQUNBLFFBQ0EsVUFDQSxhQUNBLFdBQ0EsWUFDQTtBQUVKO0FBS0EsSUFBTUcsU0FBQSxHQUFZO0VBQ2hCTCxNQUFBLEVBQVEsQ0FBQyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxHQUFHO0VBQzFDM0IsS0FBQSxFQUFPLENBQUMsU0FBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sT0FBSTtFQUNoRDRCLFdBQUEsRUFBYSxDQUFDLFdBQVEsUUFBUSxRQUFRLFFBQVEsUUFBUSxRQUFRLFNBQU07RUFFcEVDLElBQUEsRUFBTSxDQUNKLGFBQ0EsVUFDQSxXQUNBLFVBQ0EsV0FDQSxVQUNBO0FBRUo7QUFFQSxJQUFNSSxlQUFBLEdBQWtCO0VBQ3RCTixNQUFBLEVBQVE7SUFDTk8sRUFBQSxFQUFJO0lBQ0pDLEVBQUEsRUFBSTtJQUNKQyxRQUFBLEVBQVU7SUFDVkMsSUFBQSxFQUFNO0lBQ05DLE9BQUEsRUFBUztJQUNUQyxTQUFBLEVBQVc7SUFDWEMsT0FBQSxFQUFTO0lBQ1RDLEtBQUEsRUFBTztFQUNUO0VBQ0FiLFdBQUEsRUFBYTtJQUNYTSxFQUFBLEVBQUk7SUFDSkMsRUFBQSxFQUFJO0lBQ0pDLFFBQUEsRUFBVTtJQUNWQyxJQUFBLEVBQU07SUFDTkMsT0FBQSxFQUFTO0lBQ1RDLFNBQUEsRUFBVztJQUNYQyxPQUFBLEVBQVM7SUFDVEMsS0FBQSxFQUFPO0VBQ1Q7RUFDQVosSUFBQSxFQUFNO0lBQ0pLLEVBQUEsRUFBSTtJQUNKQyxFQUFBLEVBQUk7SUFDSkMsUUFBQSxFQUFVO0lBQ1ZDLElBQUEsRUFBTTtJQUNOQyxPQUFBLEVBQVM7SUFDVEMsU0FBQSxFQUFXO0lBQ1hDLE9BQUEsRUFBUztJQUNUQyxLQUFBLEVBQU87RUFDVDtBQUNGO0FBRUEsSUFBTUMseUJBQUEsR0FBNEI7RUFDaENmLE1BQUEsRUFBUTtJQUNOTyxFQUFBLEVBQUk7SUFDSkMsRUFBQSxFQUFJO0lBQ0pDLFFBQUEsRUFBVTtJQUNWQyxJQUFBLEVBQU07SUFDTkMsT0FBQSxFQUFTO0lBQ1RDLFNBQUEsRUFBVztJQUNYQyxPQUFBLEVBQVM7SUFDVEMsS0FBQSxFQUFPO0VBQ1Q7RUFDQWIsV0FBQSxFQUFhO0lBQ1hNLEVBQUEsRUFBSTtJQUNKQyxFQUFBLEVBQUk7SUFDSkMsUUFBQSxFQUFVO0lBQ1ZDLElBQUEsRUFBTTtJQUNOQyxPQUFBLEVBQVM7SUFDVEMsU0FBQSxFQUFXO0lBQ1hDLE9BQUEsRUFBUztJQUNUQyxLQUFBLEVBQU87RUFDVDtFQUNBWixJQUFBLEVBQU07SUFDSkssRUFBQSxFQUFJO0lBQ0pDLEVBQUEsRUFBSTtJQUNKQyxRQUFBLEVBQVU7SUFDVkMsSUFBQSxFQUFNO0lBQ05DLE9BQUEsRUFBUztJQUNUQyxTQUFBLEVBQVc7SUFDWEMsT0FBQSxFQUFTO0lBQ1RDLEtBQUEsRUFBTztFQUNUO0FBQ0Y7QUFFQSxJQUFNRSxhQUFBLEdBQWdCQSxDQUFDQyxXQUFBLEVBQWE1QixRQUFBLEtBQWE7RUFDL0MsTUFBTTZCLE1BQUEsR0FBU0MsTUFBQSxDQUFPRixXQUFXO0VBQ2pDLE9BQU9DLE1BQUEsR0FBUztBQUNsQjtBQUVPLElBQU1FLFFBQUEsR0FBVztFQUN0QkosYUFBQTtFQUVBSyxHQUFBLEVBQUsvQixlQUFBLENBQWdCO0lBQ25CTSxNQUFBLEVBQVFHLFNBQUE7SUFDUmpDLFlBQUEsRUFBYztFQUNoQixDQUFDO0VBRUR3RCxPQUFBLEVBQVNoQyxlQUFBLENBQWdCO0lBQ3ZCTSxNQUFBLEVBQVFPLGFBQUE7SUFDUnJDLFlBQUEsRUFBYztJQUNkZ0MsZ0JBQUEsRUFBbUJ3QixPQUFBLElBQVlBLE9BQUEsR0FBVTtFQUMzQyxDQUFDO0VBRURDLEtBQUEsRUFBT2pDLGVBQUEsQ0FBZ0I7SUFDckJNLE1BQUEsRUFBUVEsV0FBQTtJQUNSdEMsWUFBQSxFQUFjO0VBQ2hCLENBQUM7RUFFRDBELEdBQUEsRUFBS2xDLGVBQUEsQ0FBZ0I7SUFDbkJNLE1BQUEsRUFBUVMsU0FBQTtJQUNSdkMsWUFBQSxFQUFjO0VBQ2hCLENBQUM7RUFFRDJELFNBQUEsRUFBV25DLGVBQUEsQ0FBZ0I7SUFDekJNLE1BQUEsRUFBUVUsZUFBQTtJQUNSeEMsWUFBQSxFQUFjO0lBQ2Q0QixnQkFBQSxFQUFrQnFCLHlCQUFBO0lBQ2xCcEIsc0JBQUEsRUFBd0I7RUFDMUIsQ0FBQztBQUNIOzs7QUN2S08sU0FBUytCLGFBQWE5RCxJQUFBLEVBQU07RUFDakMsT0FBTyxDQUFDK0QsTUFBQSxFQUFRdkUsT0FBQSxHQUFVLENBQUMsTUFBTTtJQUMvQixNQUFNUyxLQUFBLEdBQVFULE9BQUEsQ0FBUVMsS0FBQTtJQUV0QixNQUFNK0QsWUFBQSxHQUNIL0QsS0FBQSxJQUFTRCxJQUFBLENBQUtpRSxhQUFBLENBQWNoRSxLQUFBLEtBQzdCRCxJQUFBLENBQUtpRSxhQUFBLENBQWNqRSxJQUFBLENBQUtrRSxpQkFBQTtJQUMxQixNQUFNQyxXQUFBLEdBQWNKLE1BQUEsQ0FBT0ssS0FBQSxDQUFNSixZQUFZO0lBRTdDLElBQUksQ0FBQ0csV0FBQSxFQUFhO01BQ2hCLE9BQU87SUFDVDtJQUNBLE1BQU1FLGFBQUEsR0FBZ0JGLFdBQUEsQ0FBWTtJQUVsQyxNQUFNRyxhQUFBLEdBQ0hyRSxLQUFBLElBQVNELElBQUEsQ0FBS3NFLGFBQUEsQ0FBY3JFLEtBQUEsS0FDN0JELElBQUEsQ0FBS3NFLGFBQUEsQ0FBY3RFLElBQUEsQ0FBS3VFLGlCQUFBO0lBRTFCLE1BQU1DLEdBQUEsR0FBTUMsS0FBQSxDQUFNQyxPQUFBLENBQVFKLGFBQWEsSUFDbkNLLFNBQUEsQ0FBVUwsYUFBQSxFQUFnQk0sT0FBQSxJQUFZQSxPQUFBLENBQVFDLElBQUEsQ0FBS1IsYUFBYSxDQUFDLElBRWpFUyxPQUFBLENBQVFSLGFBQUEsRUFBZ0JNLE9BQUEsSUFBWUEsT0FBQSxDQUFRQyxJQUFBLENBQUtSLGFBQWEsQ0FBQztJQUVuRSxJQUFJMUMsS0FBQTtJQUVKQSxLQUFBLEdBQVEzQixJQUFBLENBQUsrRSxhQUFBLEdBQWdCL0UsSUFBQSxDQUFLK0UsYUFBQSxDQUFjUCxHQUFHLElBQUlBLEdBQUE7SUFDdkQ3QyxLQUFBLEdBQVFuQyxPQUFBLENBQVF1RixhQUFBLEdBRVp2RixPQUFBLENBQVF1RixhQUFBLENBQWNwRCxLQUFLLElBQzNCQSxLQUFBO0lBRUosTUFBTXFELElBQUEsR0FBT2pCLE1BQUEsQ0FBT2tCLEtBQUEsQ0FBTVosYUFBQSxDQUFjYSxNQUFNO0lBRTlDLE9BQU87TUFBRXZELEtBQUE7TUFBT3FEO0lBQUs7RUFDdkI7QUFDRjtBQUVBLFNBQVNGLFFBQVFLLE1BQUEsRUFBUUMsU0FBQSxFQUFXO0VBQ2xDLFdBQVdaLEdBQUEsSUFBT1csTUFBQSxFQUFRO0lBQ3hCLElBQ0VFLE1BQUEsQ0FBT0MsU0FBQSxDQUFVQyxjQUFBLENBQWVDLElBQUEsQ0FBS0wsTUFBQSxFQUFRWCxHQUFHLEtBQ2hEWSxTQUFBLENBQVVELE1BQUEsQ0FBT1gsR0FBQSxDQUFJLEdBQ3JCO01BQ0EsT0FBT0EsR0FBQTtJQUNUO0VBQ0Y7RUFDQSxPQUFPO0FBQ1Q7QUFFQSxTQUFTRyxVQUFVYyxLQUFBLEVBQU9MLFNBQUEsRUFBVztFQUNuQyxTQUFTWixHQUFBLEdBQU0sR0FBR0EsR0FBQSxHQUFNaUIsS0FBQSxDQUFNUCxNQUFBLEVBQVFWLEdBQUEsSUFBTztJQUMzQyxJQUFJWSxTQUFBLENBQVVLLEtBQUEsQ0FBTWpCLEdBQUEsQ0FBSSxHQUFHO01BQ3pCLE9BQU9BLEdBQUE7SUFDVDtFQUNGO0VBQ0EsT0FBTztBQUNUOzs7QUN4RE8sU0FBU2tCLG9CQUFvQjFGLElBQUEsRUFBTTtFQUN4QyxPQUFPLENBQUMrRCxNQUFBLEVBQVF2RSxPQUFBLEdBQVUsQ0FBQyxNQUFNO0lBQy9CLE1BQU0yRSxXQUFBLEdBQWNKLE1BQUEsQ0FBT0ssS0FBQSxDQUFNcEUsSUFBQSxDQUFLZ0UsWUFBWTtJQUNsRCxJQUFJLENBQUNHLFdBQUEsRUFBYSxPQUFPO0lBQ3pCLE1BQU1FLGFBQUEsR0FBZ0JGLFdBQUEsQ0FBWTtJQUVsQyxNQUFNd0IsV0FBQSxHQUFjNUIsTUFBQSxDQUFPSyxLQUFBLENBQU1wRSxJQUFBLENBQUs0RixZQUFZO0lBQ2xELElBQUksQ0FBQ0QsV0FBQSxFQUFhLE9BQU87SUFDekIsSUFBSWhFLEtBQUEsR0FBUTNCLElBQUEsQ0FBSytFLGFBQUEsR0FDYi9FLElBQUEsQ0FBSytFLGFBQUEsQ0FBY1ksV0FBQSxDQUFZLEVBQUUsSUFDakNBLFdBQUEsQ0FBWTtJQUdoQmhFLEtBQUEsR0FBUW5DLE9BQUEsQ0FBUXVGLGFBQUEsR0FBZ0J2RixPQUFBLENBQVF1RixhQUFBLENBQWNwRCxLQUFLLElBQUlBLEtBQUE7SUFFL0QsTUFBTXFELElBQUEsR0FBT2pCLE1BQUEsQ0FBT2tCLEtBQUEsQ0FBTVosYUFBQSxDQUFjYSxNQUFNO0lBRTlDLE9BQU87TUFBRXZELEtBQUE7TUFBT3FEO0lBQUs7RUFDdkI7QUFDRjs7O0FDaEJBLElBQU1hLHlCQUFBLEdBQTRCO0FBQ2xDLElBQU1DLHlCQUFBLEdBQTRCO0FBRWxDLElBQU1DLGdCQUFBLEdBQW1CO0VBQ3ZCM0QsTUFBQSxFQUFRO0VBQ1JDLFdBQUEsRUFBYTtFQUNiQyxJQUFBLEVBQU07QUFDUjtBQUNBLElBQU0wRCxnQkFBQSxHQUFtQjtFQUN2QkMsR0FBQSxFQUFLLENBQUMsT0FBTyxTQUFTO0FBQ3hCO0FBRUEsSUFBTUMsb0JBQUEsR0FBdUI7RUFDM0I5RCxNQUFBLEVBQVE7RUFDUkMsV0FBQSxFQUFhO0VBQ2JDLElBQUEsRUFBTTtBQUNSO0FBQ0EsSUFBTTZELG9CQUFBLEdBQXVCO0VBQzNCRixHQUFBLEVBQUssQ0FBQyxNQUFNLE1BQU0sTUFBTSxJQUFJO0FBQzlCO0FBRUEsSUFBTUcsa0JBQUEsR0FBcUI7RUFDekJoRSxNQUFBLEVBQVE7RUFDUkMsV0FBQSxFQUFhO0VBQ2JDLElBQUEsRUFBTTtBQUNSO0FBQ0EsSUFBTStELGtCQUFBLEdBQXFCO0VBQ3pCakUsTUFBQSxFQUFRLENBQ04sT0FDQSxPQUNBLE9BQ0EsT0FDQSxPQUNBLE9BQ0EsT0FDQSxPQUNBLE9BQ0EsT0FDQSxPQUNBLE1BQ0Y7RUFFQTZELEdBQUEsRUFBSyxDQUNILFFBQ0EsT0FDQSxTQUNBLFFBQ0EsU0FDQSxTQUNBLFNBQ0EsUUFDQSxPQUNBLE9BQ0EsT0FDQTtBQUVKO0FBRUEsSUFBTUssZ0JBQUEsR0FBbUI7RUFDdkJsRSxNQUFBLEVBQVE7RUFDUjNCLEtBQUEsRUFBTztFQUNQNEIsV0FBQSxFQUFhO0VBQ2JDLElBQUEsRUFBTTtBQUNSO0FBQ0EsSUFBTWlFLGdCQUFBLEdBQW1CO0VBQ3ZCbkUsTUFBQSxFQUFRLENBQUMsT0FBTyxPQUFPLE9BQU8sT0FBTyxPQUFPLE9BQU8sS0FBSztFQUN4RDZELEdBQUEsRUFBSyxDQUFDLE9BQU8sT0FBTyxRQUFRLE9BQU8sUUFBUSxPQUFPLEtBQUs7QUFDekQ7QUFFQSxJQUFNTyxzQkFBQSxHQUF5QjtFQUM3QnBFLE1BQUEsRUFBUTtFQUNSNkQsR0FBQSxFQUFLO0FBQ1A7QUFDQSxJQUFNUSxzQkFBQSxHQUF5QjtFQUM3QlIsR0FBQSxFQUFLO0lBQ0h0RCxFQUFBLEVBQUk7SUFDSkMsRUFBQSxFQUFJO0lBQ0pDLFFBQUEsRUFBVTtJQUNWQyxJQUFBLEVBQU07SUFDTkMsT0FBQSxFQUFTO0lBQ1RDLFNBQUEsRUFBVztJQUNYQyxPQUFBLEVBQVM7SUFDVEMsS0FBQSxFQUFPO0VBQ1Q7QUFDRjtBQUVPLElBQU1rQixLQUFBLEdBQVE7RUFDbkJoQixhQUFBLEVBQWVzQyxtQkFBQSxDQUFvQjtJQUNqQzFCLFlBQUEsRUFBYzZCLHlCQUFBO0lBQ2RELFlBQUEsRUFBY0UseUJBQUE7SUFDZGYsYUFBQSxFQUFnQnBELEtBQUEsSUFBVStFLFFBQUEsQ0FBUy9FLEtBQUEsRUFBTyxFQUFFO0VBQzlDLENBQUM7RUFFRDhCLEdBQUEsRUFBS0ssWUFBQSxDQUFhO0lBQ2hCRyxhQUFBLEVBQWU4QixnQkFBQTtJQUNmN0IsaUJBQUEsRUFBbUI7SUFDbkJJLGFBQUEsRUFBZTBCLGdCQUFBO0lBQ2Z6QixpQkFBQSxFQUFtQjtFQUNyQixDQUFDO0VBRURiLE9BQUEsRUFBU0ksWUFBQSxDQUFhO0lBQ3BCRyxhQUFBLEVBQWVpQyxvQkFBQTtJQUNmaEMsaUJBQUEsRUFBbUI7SUFDbkJJLGFBQUEsRUFBZTZCLG9CQUFBO0lBQ2Y1QixpQkFBQSxFQUFtQjtJQUNuQlEsYUFBQSxFQUFnQjlDLEtBQUEsSUFBVUEsS0FBQSxHQUFRO0VBQ3BDLENBQUM7RUFFRDBCLEtBQUEsRUFBT0csWUFBQSxDQUFhO0lBQ2xCRyxhQUFBLEVBQWVtQyxrQkFBQTtJQUNmbEMsaUJBQUEsRUFBbUI7SUFDbkJJLGFBQUEsRUFBZStCLGtCQUFBO0lBQ2Y5QixpQkFBQSxFQUFtQjtFQUNyQixDQUFDO0VBRURYLEdBQUEsRUFBS0UsWUFBQSxDQUFhO0lBQ2hCRyxhQUFBLEVBQWVxQyxnQkFBQTtJQUNmcEMsaUJBQUEsRUFBbUI7SUFDbkJJLGFBQUEsRUFBZWlDLGdCQUFBO0lBQ2ZoQyxpQkFBQSxFQUFtQjtFQUNyQixDQUFDO0VBRURWLFNBQUEsRUFBV0MsWUFBQSxDQUFhO0lBQ3RCRyxhQUFBLEVBQWV1QyxzQkFBQTtJQUNmdEMsaUJBQUEsRUFBbUI7SUFDbkJJLGFBQUEsRUFBZW1DLHNCQUFBO0lBQ2ZsQyxpQkFBQSxFQUFtQjtFQUNyQixDQUFDO0FBQ0g7OztBQ25ITyxJQUFNM0csRUFBQSxHQUFLO0VBQ2hCK0ksSUFBQSxFQUFNO0VBQ050SCxjQUFBO0VBQ0F1QixVQUFBO0VBQ0FVLGNBQUE7RUFDQWtDLFFBQUE7RUFDQVksS0FBQTtFQUNBNUUsT0FBQSxFQUFTO0lBQ1BvSCxZQUFBLEVBQWM7SUFDZEMscUJBQUEsRUFBdUI7RUFDekI7QUFDRjtBQUdBLElBQU9DLFVBQUEsR0FBUWxKLEVBQUE7OztBVjNCZixJQUFPRSxnQkFBQSxHQUFRZ0osVUFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==