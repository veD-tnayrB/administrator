System.register([], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/locale/gu.3.6.0.js
var gu_3_6_0_exports = {};
__export(gu_3_6_0_exports, {
  default: () => gu_3_6_0_default,
  gu: () => gu
});
module.exports = __toCommonJS(gu_3_6_0_exports);

// node_modules/date-fns/locale/gu/_lib/formatDistance.mjs
var formatDistanceLocale = {
  lessThanXSeconds: {
    one: "\u0AB9\u0AAE\u0AA3\u0ABE\u0A82",
    other: "\u200B\u0A86\u0AB6\u0AB0\u0AC7 {{count}} \u0AB8\u0AC7\u0A95\u0A82\u0AA1"
  },
  xSeconds: {
    one: "1 \u0AB8\u0AC7\u0A95\u0A82\u0AA1",
    other: "{{count}} \u0AB8\u0AC7\u0A95\u0A82\u0AA1"
  },
  halfAMinute: "\u0A85\u0AA1\u0AA7\u0AC0 \u0AAE\u0ABF\u0AA8\u0ABF\u0A9F",
  lessThanXMinutes: {
    one: "\u0A86 \u0AAE\u0ABF\u0AA8\u0ABF\u0A9F",
    other: "\u200B\u0A86\u0AB6\u0AB0\u0AC7 {{count}} \u0AAE\u0ABF\u0AA8\u0ABF\u0A9F"
  },
  xMinutes: {
    one: "1 \u0AAE\u0ABF\u0AA8\u0ABF\u0A9F",
    other: "{{count}} \u0AAE\u0ABF\u0AA8\u0ABF\u0A9F"
  },
  aboutXHours: {
    one: "\u200B\u0A86\u0AB6\u0AB0\u0AC7 1 \u0A95\u0AB2\u0ABE\u0A95",
    other: "\u200B\u0A86\u0AB6\u0AB0\u0AC7 {{count}} \u0A95\u0AB2\u0ABE\u0A95"
  },
  xHours: {
    one: "1 \u0A95\u0AB2\u0ABE\u0A95",
    other: "{{count}} \u0A95\u0AB2\u0ABE\u0A95"
  },
  xDays: {
    one: "1 \u0AA6\u0ABF\u0AB5\u0AB8",
    other: "{{count}} \u0AA6\u0ABF\u0AB5\u0AB8"
  },
  aboutXWeeks: {
    one: "\u0A86\u0AB6\u0AB0\u0AC7 1 \u0A85\u0AA0\u0AB5\u0ABE\u0AA1\u0ABF\u0AAF\u0AC1\u0A82",
    other: "\u0A86\u0AB6\u0AB0\u0AC7 {{count}} \u0A85\u0AA0\u0AB5\u0ABE\u0AA1\u0ABF\u0AAF\u0ABE"
  },
  xWeeks: {
    one: "1 \u0A85\u0AA0\u0AB5\u0ABE\u0AA1\u0ABF\u0AAF\u0AC1\u0A82",
    other: "{{count}} \u0A85\u0AA0\u0AB5\u0ABE\u0AA1\u0ABF\u0AAF\u0ABE"
  },
  aboutXMonths: {
    one: "\u0A86\u0AB6\u0AB0\u0AC7 1 \u0AAE\u0AB9\u0ABF\u0AA8\u0ACB",
    other: "\u0A86\u0AB6\u0AB0\u0AC7 {{count}} \u0AAE\u0AB9\u0ABF\u0AA8\u0ABE"
  },
  xMonths: {
    one: "1 \u0AAE\u0AB9\u0ABF\u0AA8\u0ACB",
    other: "{{count}} \u0AAE\u0AB9\u0ABF\u0AA8\u0ABE"
  },
  aboutXYears: {
    one: "\u0A86\u0AB6\u0AB0\u0AC7 1 \u0AB5\u0AB0\u0ACD\u0AB7",
    other: "\u0A86\u0AB6\u0AB0\u0AC7 {{count}} \u0AB5\u0AB0\u0ACD\u0AB7"
  },
  xYears: {
    one: "1 \u0AB5\u0AB0\u0ACD\u0AB7",
    other: "{{count}} \u0AB5\u0AB0\u0ACD\u0AB7"
  },
  overXYears: {
    one: "1 \u0AB5\u0AB0\u0ACD\u0AB7\u0AA5\u0AC0 \u0AB5\u0AA7\u0AC1",
    other: "{{count}} \u0AB5\u0AB0\u0ACD\u0AB7\u0AA5\u0AC0 \u0AB5\u0AA7\u0AC1"
  },
  almostXYears: {
    one: "\u0AB2\u0A97\u0AAD\u0A97 1 \u0AB5\u0AB0\u0ACD\u0AB7",
    other: "\u0AB2\u0A97\u0AAD\u0A97 {{count}} \u0AB5\u0AB0\u0ACD\u0AB7"
  }
};
var formatDistance = (token, count, options) => {
  let result;
  const tokenValue = formatDistanceLocale[token];
  if (typeof tokenValue === "string") {
    result = tokenValue;
  } else if (count === 1) {
    result = tokenValue.one;
  } else {
    result = tokenValue.other.replace("{{count}}", String(count));
  }
  if (options?.addSuffix) {
    if (options.comparison && options.comparison > 0) {
      return result + "\u0AAE\u0ABE\u0A82";
    } else {
      return result + " \u0AAA\u0AB9\u0AC7\u0AB2\u0ABE\u0A82";
    }
  }
  return result;
};

// node_modules/date-fns/locale/_lib/buildFormatLongFn.mjs
function buildFormatLongFn(args) {
  return (options = {}) => {
    const width = options.width ? String(options.width) : args.defaultWidth;
    const format = args.formats[width] || args.formats[args.defaultWidth];
    return format;
  };
}

// node_modules/date-fns/locale/gu/_lib/formatLong.mjs
var dateFormats = {
  full: "EEEE, d MMMM, y",
  long: "d MMMM, y",
  medium: "d MMM, y",
  short: "d/M/yy"
};
var timeFormats = {
  full: "hh:mm:ss a zzzz",
  long: "hh:mm:ss a z",
  medium: "hh:mm:ss a",
  short: "hh:mm a"
};
var dateTimeFormats = {
  full: "{{date}} {{time}}",
  long: "{{date}} {{time}}",
  medium: "{{date}} {{time}}",
  short: "{{date}} {{time}}"
};
var formatLong = {
  date: buildFormatLongFn({
    formats: dateFormats,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats,
    defaultWidth: "full"
  })
};

// node_modules/date-fns/locale/gu/_lib/formatRelative.mjs
var formatRelativeLocale = {
  lastWeek: "'\u0AAA\u0ABE\u0A9B\u0AB2\u0ABE' eeee p",
  yesterday: "'\u0A97\u0A88\u0A95\u0ABE\u0AB2\u0AC7' p",
  today: "'\u0A86\u0A9C\u0AC7' p",
  tomorrow: "'\u0A86\u0AB5\u0AA4\u0AC0\u0A95\u0ABE\u0AB2\u0AC7' p",
  nextWeek: "eeee p",
  other: "P"
};
var formatRelative = (token, _date, _baseDate, _options) => formatRelativeLocale[token];

// node_modules/date-fns/locale/_lib/buildLocalizeFn.mjs
function buildLocalizeFn(args) {
  return (value, options) => {
    const context = options?.context ? String(options.context) : "standalone";
    let valuesArray;
    if (context === "formatting" && args.formattingValues) {
      const defaultWidth = args.defaultFormattingWidth || args.defaultWidth;
      const width = options?.width ? String(options.width) : defaultWidth;
      valuesArray = args.formattingValues[width] || args.formattingValues[defaultWidth];
    } else {
      const defaultWidth = args.defaultWidth;
      const width = options?.width ? String(options.width) : args.defaultWidth;
      valuesArray = args.values[width] || args.values[defaultWidth];
    }
    const index = args.argumentCallback ? args.argumentCallback(value) : value;
    return valuesArray[index];
  };
}

// node_modules/date-fns/locale/gu/_lib/localize.mjs
var eraValues = {
  narrow: ["\u0A88\u0AB8\u0AAA\u0AC2", "\u0A88\u0AB8"],
  abbreviated: ["\u0A88.\u0AB8.\u0AAA\u0AC2\u0AB0\u0ACD\u0AB5\u0AC7", "\u0A88.\u0AB8."],
  wide: ["\u0A88\u0AB8\u0AB5\u0AC0\u0AB8\u0AA8 \u0AAA\u0AC2\u0AB0\u0ACD\u0AB5\u0AC7", "\u0A88\u0AB8\u0AB5\u0AC0\u0AB8\u0AA8"]
};
var quarterValues = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["Q1", "Q2", "Q3", "Q4"],
  wide: ["1\u0AB2\u0ACB \u0AA4\u0ACD\u0AB0\u0ABF\u0AAE\u0ABE\u0AB8", "2\u0A9C\u0ACB \u0AA4\u0ACD\u0AB0\u0ABF\u0AAE\u0ABE\u0AB8", "3\u0A9C\u0ACB \u0AA4\u0ACD\u0AB0\u0ABF\u0AAE\u0ABE\u0AB8", "4\u0AA5\u0ACB \u0AA4\u0ACD\u0AB0\u0ABF\u0AAE\u0ABE\u0AB8"]
};
var monthValues = {
  narrow: ["\u0A9C\u0ABE", "\u0AAB\u0AC7", "\u0AAE\u0ABE", "\u0A8F", "\u0AAE\u0AC7", "\u0A9C\u0AC2", "\u0A9C\u0AC1", "\u0A93", "\u0AB8", "\u0A93", "\u0AA8", "\u0AA1\u0ABF"],
  abbreviated: ["\u0A9C\u0ABE\u0AA8\u0ACD\u0AAF\u0AC1", "\u0AAB\u0AC7\u0AAC\u0ACD\u0AB0\u0AC1", "\u0AAE\u0ABE\u0AB0\u0ACD\u0A9A", "\u0A8F\u0AAA\u0ACD\u0AB0\u0ABF\u0AB2", "\u0AAE\u0AC7", "\u0A9C\u0AC2\u0AA8", "\u0A9C\u0AC1\u0AB2\u0ABE\u0A88", "\u0A91\u0A97\u0AB8\u0ACD\u0A9F", "\u0AB8\u0AAA\u0ACD\u0A9F\u0AC7", "\u0A93\u0A95\u0ACD\u0A9F\u0ACB", "\u0AA8\u0AB5\u0AC7", "\u0AA1\u0ABF\u0AB8\u0AC7"],
  wide: ["\u0A9C\u0ABE\u0AA8\u0ACD\u0AAF\u0AC1\u0A86\u0AB0\u0AC0", "\u0AAB\u0AC7\u0AAC\u0ACD\u0AB0\u0AC1\u0A86\u0AB0\u0AC0", "\u0AAE\u0ABE\u0AB0\u0ACD\u0A9A", "\u0A8F\u0AAA\u0ACD\u0AB0\u0ABF\u0AB2", "\u0AAE\u0AC7", "\u0A9C\u0AC2\u0AA8", "\u0A9C\u0AC1\u0AB2\u0ABE\u0A87", "\u0A93\u0A97\u0AB8\u0ACD\u0A9F", "\u0AB8\u0AAA\u0ACD\u0A9F\u0AC7\u0AAE\u0ACD\u0AAC\u0AB0", "\u0A93\u0A95\u0ACD\u0A9F\u0ACB\u0AAC\u0AB0", "\u0AA8\u0AB5\u0AC7\u0AAE\u0ACD\u0AAC\u0AB0", "\u0AA1\u0ABF\u0AB8\u0AC7\u0AAE\u0ACD\u0AAC\u0AB0"]
};
var dayValues = {
  narrow: ["\u0AB0", "\u0AB8\u0ACB", "\u0AAE\u0A82", "\u0AAC\u0AC1", "\u0A97\u0AC1", "\u0AB6\u0AC1", "\u0AB6"],
  short: ["\u0AB0", "\u0AB8\u0ACB", "\u0AAE\u0A82", "\u0AAC\u0AC1", "\u0A97\u0AC1", "\u0AB6\u0AC1", "\u0AB6"],
  abbreviated: ["\u0AB0\u0AB5\u0ABF", "\u0AB8\u0ACB\u0AAE", "\u0AAE\u0A82\u0A97\u0AB3", "\u0AAC\u0AC1\u0AA7", "\u0A97\u0AC1\u0AB0\u0AC1", "\u0AB6\u0AC1\u0A95\u0ACD\u0AB0", "\u0AB6\u0AA8\u0ABF"],
  wide: ["\u0AB0\u0AB5\u0ABF\u0AB5\u0ABE\u0AB0", "\u0AB8\u0ACB\u0AAE\u0AB5\u0ABE\u0AB0", "\u0AAE\u0A82\u0A97\u0AB3\u0AB5\u0ABE\u0AB0", "\u0AAC\u0AC1\u0AA7\u0AB5\u0ABE\u0AB0", "\u0A97\u0AC1\u0AB0\u0AC1\u0AB5\u0ABE\u0AB0", "\u0AB6\u0AC1\u0A95\u0ACD\u0AB0\u0AB5\u0ABE\u0AB0", "\u0AB6\u0AA8\u0ABF\u0AB5\u0ABE\u0AB0"]
};
var dayPeriodValues = {
  narrow: {
    am: "AM",
    pm: "PM",
    midnight: "\u0AAE.\u0AB0\u0ABE\u0AA4\u0ACD\u0AB0\u0ABF",
    noon: "\u0AAC.",
    morning: "\u0AB8\u0AB5\u0ABE\u0AB0\u0AC7",
    afternoon: "\u0AAC\u0AAA\u0ACB\u0AB0\u0AC7",
    evening: "\u0AB8\u0ABE\u0A82\u0A9C\u0AC7",
    night: "\u0AB0\u0ABE\u0AA4\u0ACD\u0AB0\u0AC7"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "\u200B\u0AAE\u0AA7\u0ACD\u0AAF\u0AB0\u0ABE\u0AA4\u0ACD\u0AB0\u0ABF",
    noon: "\u0AAC\u0AAA\u0ACB\u0AB0\u0AC7",
    morning: "\u0AB8\u0AB5\u0ABE\u0AB0\u0AC7",
    afternoon: "\u0AAC\u0AAA\u0ACB\u0AB0\u0AC7",
    evening: "\u0AB8\u0ABE\u0A82\u0A9C\u0AC7",
    night: "\u0AB0\u0ABE\u0AA4\u0ACD\u0AB0\u0AC7"
  },
  wide: {
    am: "AM",
    pm: "PM",
    midnight: "\u200B\u0AAE\u0AA7\u0ACD\u0AAF\u0AB0\u0ABE\u0AA4\u0ACD\u0AB0\u0ABF",
    noon: "\u0AAC\u0AAA\u0ACB\u0AB0\u0AC7",
    morning: "\u0AB8\u0AB5\u0ABE\u0AB0\u0AC7",
    afternoon: "\u0AAC\u0AAA\u0ACB\u0AB0\u0AC7",
    evening: "\u0AB8\u0ABE\u0A82\u0A9C\u0AC7",
    night: "\u0AB0\u0ABE\u0AA4\u0ACD\u0AB0\u0AC7"
  }
};
var formattingDayPeriodValues = {
  narrow: {
    am: "AM",
    pm: "PM",
    midnight: "\u0AAE.\u0AB0\u0ABE\u0AA4\u0ACD\u0AB0\u0ABF",
    noon: "\u0AAC\u0AAA\u0ACB\u0AB0\u0AC7",
    morning: "\u0AB8\u0AB5\u0ABE\u0AB0\u0AC7",
    afternoon: "\u0AAC\u0AAA\u0ACB\u0AB0\u0AC7",
    evening: "\u0AB8\u0ABE\u0A82\u0A9C\u0AC7",
    night: "\u0AB0\u0ABE\u0AA4\u0ACD\u0AB0\u0AC7"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "\u0AAE\u0AA7\u0ACD\u0AAF\u0AB0\u0ABE\u0AA4\u0ACD\u0AB0\u0ABF",
    noon: "\u0AAC\u0AAA\u0ACB\u0AB0\u0AC7",
    morning: "\u0AB8\u0AB5\u0ABE\u0AB0\u0AC7",
    afternoon: "\u0AAC\u0AAA\u0ACB\u0AB0\u0AC7",
    evening: "\u0AB8\u0ABE\u0A82\u0A9C\u0AC7",
    night: "\u0AB0\u0ABE\u0AA4\u0ACD\u0AB0\u0AC7"
  },
  wide: {
    am: "AM",
    pm: "PM",
    midnight: "\u200B\u0AAE\u0AA7\u0ACD\u0AAF\u0AB0\u0ABE\u0AA4\u0ACD\u0AB0\u0ABF",
    noon: "\u0AAC\u0AAA\u0ACB\u0AB0\u0AC7",
    morning: "\u0AB8\u0AB5\u0ABE\u0AB0\u0AC7",
    afternoon: "\u0AAC\u0AAA\u0ACB\u0AB0\u0AC7",
    evening: "\u0AB8\u0ABE\u0A82\u0A9C\u0AC7",
    night: "\u0AB0\u0ABE\u0AA4\u0ACD\u0AB0\u0AC7"
  }
};
var ordinalNumber = (dirtyNumber, _options) => {
  return String(dirtyNumber);
};
var localize = {
  ordinalNumber,
  era: buildLocalizeFn({
    values: eraValues,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues,
    defaultWidth: "wide",
    argumentCallback: quarter => quarter - 1
  }),
  month: buildLocalizeFn({
    values: monthValues,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues,
    defaultFormattingWidth: "wide"
  })
};

// node_modules/date-fns/locale/_lib/buildMatchFn.mjs
function buildMatchFn(args) {
  return (string, options = {}) => {
    const width = options.width;
    const matchPattern = width && args.matchPatterns[width] || args.matchPatterns[args.defaultMatchWidth];
    const matchResult = string.match(matchPattern);
    if (!matchResult) {
      return null;
    }
    const matchedString = matchResult[0];
    const parsePatterns = width && args.parsePatterns[width] || args.parsePatterns[args.defaultParseWidth];
    const key = Array.isArray(parsePatterns) ? findIndex(parsePatterns, pattern => pattern.test(matchedString)) : findKey(parsePatterns, pattern => pattern.test(matchedString));
    let value;
    value = args.valueCallback ? args.valueCallback(key) : key;
    value = options.valueCallback ? options.valueCallback(value) : value;
    const rest = string.slice(matchedString.length);
    return {
      value,
      rest
    };
  };
}
function findKey(object, predicate) {
  for (const key in object) {
    if (Object.prototype.hasOwnProperty.call(object, key) && predicate(object[key])) {
      return key;
    }
  }
  return void 0;
}
function findIndex(array, predicate) {
  for (let key = 0; key < array.length; key++) {
    if (predicate(array[key])) {
      return key;
    }
  }
  return void 0;
}

// node_modules/date-fns/locale/_lib/buildMatchPatternFn.mjs
function buildMatchPatternFn(args) {
  return (string, options = {}) => {
    const matchResult = string.match(args.matchPattern);
    if (!matchResult) return null;
    const matchedString = matchResult[0];
    const parseResult = string.match(args.parsePattern);
    if (!parseResult) return null;
    let value = args.valueCallback ? args.valueCallback(parseResult[0]) : parseResult[0];
    value = options.valueCallback ? options.valueCallback(value) : value;
    const rest = string.slice(matchedString.length);
    return {
      value,
      rest
    };
  };
}

// node_modules/date-fns/locale/gu/_lib/match.mjs
var matchOrdinalNumberPattern = /^(\d+)(લ|જ|થ|ઠ્ઠ|મ)?/i;
var parseOrdinalNumberPattern = /\d+/i;
var matchEraPatterns = {
  narrow: /^(ઈસપૂ|ઈસ)/i,
  abbreviated: /^(ઈ\.સ\.પૂર્વે|ઈ\.સ\.)/i,
  wide: /^(ઈસવીસન\sપૂર્વે|ઈસવીસન)/i
};
var parseEraPatterns = {
  any: [/^ઈસપૂ/i, /^ઈસ/i]
};
var matchQuarterPatterns = {
  narrow: /^[1234]/i,
  abbreviated: /^q[1234]/i,
  wide: /^[1234](લો|જો|થો)? ત્રિમાસ/i
};
var parseQuarterPatterns = {
  any: [/1/i, /2/i, /3/i, /4/i]
};
var matchMonthPatterns = {
  narrow: /^[જાફેમાએમેજૂજુઓસઓનડિ]/i,
  abbreviated: /^(જાન્યુ|ફેબ્રુ|માર્ચ|એપ્રિલ|મે|જૂન|જુલાઈ|ઑગસ્ટ|સપ્ટે|ઓક્ટો|નવે|ડિસે)/i,
  wide: /^(જાન્યુઆરી|ફેબ્રુઆરી|માર્ચ|એપ્રિલ|મે|જૂન|જુલાઇ|ઓગસ્ટ|સપ્ટેમ્બર|ઓક્ટોબર|નવેમ્બર|ડિસેમ્બર)/i
};
var parseMonthPatterns = {
  narrow: [/^જા/i, /^ફે/i, /^મા/i, /^એ/i, /^મે/i, /^જૂ/i, /^જુ/i, /^ઑગ/i, /^સ/i, /^ઓક્ટો/i, /^ન/i, /^ડિ/i],
  any: [/^જા/i, /^ફે/i, /^મા/i, /^એ/i, /^મે/i, /^જૂ/i, /^જુ/i, /^ઑગ/i, /^સ/i, /^ઓક્ટો/i, /^ન/i, /^ડિ/i]
};
var matchDayPatterns = {
  narrow: /^(ર|સો|મં|બુ|ગુ|શુ|શ)/i,
  short: /^(ર|સો|મં|બુ|ગુ|શુ|શ)/i,
  abbreviated: /^(રવિ|સોમ|મંગળ|બુધ|ગુરુ|શુક્ર|શનિ)/i,
  wide: /^(રવિવાર|સોમવાર|મંગળવાર|બુધવાર|ગુરુવાર|શુક્રવાર|શનિવાર)/i
};
var parseDayPatterns = {
  narrow: [/^ર/i, /^સો/i, /^મં/i, /^બુ/i, /^ગુ/i, /^શુ/i, /^શ/i],
  any: [/^ર/i, /^સો/i, /^મં/i, /^બુ/i, /^ગુ/i, /^શુ/i, /^શ/i]
};
var matchDayPeriodPatterns = {
  narrow: /^(a|p|મ\.?|સ|બ|સાં|રા)/i,
  any: /^(a|p|મ\.?|સ|બ|સાં|રા)/i
};
var parseDayPeriodPatterns = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^મ\.?/i,
    noon: /^બ/i,
    morning: /સ/i,
    afternoon: /બ/i,
    evening: /સાં/i,
    night: /રા/i
  }
};
var match = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern,
    parsePattern: parseOrdinalNumberPattern,
    valueCallback: value => parseInt(value, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns,
    defaultParseWidth: "any",
    valueCallback: index => index + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns,
    defaultParseWidth: "any"
  })
};

// node_modules/date-fns/locale/gu.mjs
var gu = {
  code: "gu",
  formatDistance,
  formatLong,
  formatRelative,
  localize,
  match,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
};
var gu_default = gu;

// .beyond/uimport/temp/date-fns/locale/gu.3.6.0.js
var gu_3_6_0_default = gu_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2xvY2FsZS9ndS4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9sb2NhbGUvZ3UvX2xpYi9mb3JtYXREaXN0YW5jZS5tanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvbG9jYWxlL19saWIvYnVpbGRGb3JtYXRMb25nRm4ubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9ndS9fbGliL2Zvcm1hdExvbmcubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9ndS9fbGliL2Zvcm1hdFJlbGF0aXZlLm1qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9sb2NhbGUvX2xpYi9idWlsZExvY2FsaXplRm4ubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9ndS9fbGliL2xvY2FsaXplLm1qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9sb2NhbGUvX2xpYi9idWlsZE1hdGNoRm4ubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9fbGliL2J1aWxkTWF0Y2hQYXR0ZXJuRm4ubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9ndS9fbGliL21hdGNoLm1qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9sb2NhbGUvZ3UubWpzIl0sIm5hbWVzIjpbImd1XzNfNl8wX2V4cG9ydHMiLCJfX2V4cG9ydCIsImRlZmF1bHQiLCJndV8zXzZfMF9kZWZhdWx0IiwiZ3UiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiZm9ybWF0RGlzdGFuY2VMb2NhbGUiLCJsZXNzVGhhblhTZWNvbmRzIiwib25lIiwib3RoZXIiLCJ4U2Vjb25kcyIsImhhbGZBTWludXRlIiwibGVzc1RoYW5YTWludXRlcyIsInhNaW51dGVzIiwiYWJvdXRYSG91cnMiLCJ4SG91cnMiLCJ4RGF5cyIsImFib3V0WFdlZWtzIiwieFdlZWtzIiwiYWJvdXRYTW9udGhzIiwieE1vbnRocyIsImFib3V0WFllYXJzIiwieFllYXJzIiwib3ZlclhZZWFycyIsImFsbW9zdFhZZWFycyIsImZvcm1hdERpc3RhbmNlIiwidG9rZW4iLCJjb3VudCIsIm9wdGlvbnMiLCJyZXN1bHQiLCJ0b2tlblZhbHVlIiwicmVwbGFjZSIsIlN0cmluZyIsImFkZFN1ZmZpeCIsImNvbXBhcmlzb24iLCJidWlsZEZvcm1hdExvbmdGbiIsImFyZ3MiLCJ3aWR0aCIsImRlZmF1bHRXaWR0aCIsImZvcm1hdCIsImZvcm1hdHMiLCJkYXRlRm9ybWF0cyIsImZ1bGwiLCJsb25nIiwibWVkaXVtIiwic2hvcnQiLCJ0aW1lRm9ybWF0cyIsImRhdGVUaW1lRm9ybWF0cyIsImZvcm1hdExvbmciLCJkYXRlIiwidGltZSIsImRhdGVUaW1lIiwiZm9ybWF0UmVsYXRpdmVMb2NhbGUiLCJsYXN0V2VlayIsInllc3RlcmRheSIsInRvZGF5IiwidG9tb3Jyb3ciLCJuZXh0V2VlayIsImZvcm1hdFJlbGF0aXZlIiwiX2RhdGUiLCJfYmFzZURhdGUiLCJfb3B0aW9ucyIsImJ1aWxkTG9jYWxpemVGbiIsInZhbHVlIiwiY29udGV4dCIsInZhbHVlc0FycmF5IiwiZm9ybWF0dGluZ1ZhbHVlcyIsImRlZmF1bHRGb3JtYXR0aW5nV2lkdGgiLCJ2YWx1ZXMiLCJpbmRleCIsImFyZ3VtZW50Q2FsbGJhY2siLCJlcmFWYWx1ZXMiLCJuYXJyb3ciLCJhYmJyZXZpYXRlZCIsIndpZGUiLCJxdWFydGVyVmFsdWVzIiwibW9udGhWYWx1ZXMiLCJkYXlWYWx1ZXMiLCJkYXlQZXJpb2RWYWx1ZXMiLCJhbSIsInBtIiwibWlkbmlnaHQiLCJub29uIiwibW9ybmluZyIsImFmdGVybm9vbiIsImV2ZW5pbmciLCJuaWdodCIsImZvcm1hdHRpbmdEYXlQZXJpb2RWYWx1ZXMiLCJvcmRpbmFsTnVtYmVyIiwiZGlydHlOdW1iZXIiLCJsb2NhbGl6ZSIsImVyYSIsInF1YXJ0ZXIiLCJtb250aCIsImRheSIsImRheVBlcmlvZCIsImJ1aWxkTWF0Y2hGbiIsInN0cmluZyIsIm1hdGNoUGF0dGVybiIsIm1hdGNoUGF0dGVybnMiLCJkZWZhdWx0TWF0Y2hXaWR0aCIsIm1hdGNoUmVzdWx0IiwibWF0Y2giLCJtYXRjaGVkU3RyaW5nIiwicGFyc2VQYXR0ZXJucyIsImRlZmF1bHRQYXJzZVdpZHRoIiwia2V5IiwiQXJyYXkiLCJpc0FycmF5IiwiZmluZEluZGV4IiwicGF0dGVybiIsInRlc3QiLCJmaW5kS2V5IiwidmFsdWVDYWxsYmFjayIsInJlc3QiLCJzbGljZSIsImxlbmd0aCIsIm9iamVjdCIsInByZWRpY2F0ZSIsIk9iamVjdCIsInByb3RvdHlwZSIsImhhc093blByb3BlcnR5IiwiY2FsbCIsImFycmF5IiwiYnVpbGRNYXRjaFBhdHRlcm5GbiIsInBhcnNlUmVzdWx0IiwicGFyc2VQYXR0ZXJuIiwibWF0Y2hPcmRpbmFsTnVtYmVyUGF0dGVybiIsInBhcnNlT3JkaW5hbE51bWJlclBhdHRlcm4iLCJtYXRjaEVyYVBhdHRlcm5zIiwicGFyc2VFcmFQYXR0ZXJucyIsImFueSIsIm1hdGNoUXVhcnRlclBhdHRlcm5zIiwicGFyc2VRdWFydGVyUGF0dGVybnMiLCJtYXRjaE1vbnRoUGF0dGVybnMiLCJwYXJzZU1vbnRoUGF0dGVybnMiLCJtYXRjaERheVBhdHRlcm5zIiwicGFyc2VEYXlQYXR0ZXJucyIsIm1hdGNoRGF5UGVyaW9kUGF0dGVybnMiLCJwYXJzZURheVBlcmlvZFBhdHRlcm5zIiwicGFyc2VJbnQiLCJjb2RlIiwid2Vla1N0YXJ0c09uIiwiZmlyc3RXZWVrQ29udGFpbnNEYXRlIiwiZ3VfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsZ0JBQUE7QUFBQUMsUUFBQSxDQUFBRCxnQkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsZ0JBQUE7RUFBQUMsRUFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsZ0JBQUE7OztBQ0NBLElBQU1RLG9CQUFBLEdBQXVCO0VBQzNCQyxnQkFBQSxFQUFrQjtJQUNoQkMsR0FBQSxFQUFLO0lBQ0xDLEtBQUEsRUFBTztFQUNUO0VBRUFDLFFBQUEsRUFBVTtJQUNSRixHQUFBLEVBQUs7SUFDTEMsS0FBQSxFQUFPO0VBQ1Q7RUFFQUUsV0FBQSxFQUFhO0VBRWJDLGdCQUFBLEVBQWtCO0lBQ2hCSixHQUFBLEVBQUs7SUFDTEMsS0FBQSxFQUFPO0VBQ1Q7RUFFQUksUUFBQSxFQUFVO0lBQ1JMLEdBQUEsRUFBSztJQUNMQyxLQUFBLEVBQU87RUFDVDtFQUVBSyxXQUFBLEVBQWE7SUFDWE4sR0FBQSxFQUFLO0lBQ0xDLEtBQUEsRUFBTztFQUNUO0VBRUFNLE1BQUEsRUFBUTtJQUNOUCxHQUFBLEVBQUs7SUFDTEMsS0FBQSxFQUFPO0VBQ1Q7RUFFQU8sS0FBQSxFQUFPO0lBQ0xSLEdBQUEsRUFBSztJQUNMQyxLQUFBLEVBQU87RUFDVDtFQUVBUSxXQUFBLEVBQWE7SUFDWFQsR0FBQSxFQUFLO0lBQ0xDLEtBQUEsRUFBTztFQUNUO0VBRUFTLE1BQUEsRUFBUTtJQUNOVixHQUFBLEVBQUs7SUFDTEMsS0FBQSxFQUFPO0VBQ1Q7RUFFQVUsWUFBQSxFQUFjO0lBQ1pYLEdBQUEsRUFBSztJQUNMQyxLQUFBLEVBQU87RUFDVDtFQUVBVyxPQUFBLEVBQVM7SUFDUFosR0FBQSxFQUFLO0lBQ0xDLEtBQUEsRUFBTztFQUNUO0VBRUFZLFdBQUEsRUFBYTtJQUNYYixHQUFBLEVBQUs7SUFDTEMsS0FBQSxFQUFPO0VBQ1Q7RUFFQWEsTUFBQSxFQUFRO0lBQ05kLEdBQUEsRUFBSztJQUNMQyxLQUFBLEVBQU87RUFDVDtFQUVBYyxVQUFBLEVBQVk7SUFDVmYsR0FBQSxFQUFLO0lBQ0xDLEtBQUEsRUFBTztFQUNUO0VBRUFlLFlBQUEsRUFBYztJQUNaaEIsR0FBQSxFQUFLO0lBQ0xDLEtBQUEsRUFBTztFQUNUO0FBQ0Y7QUFFTyxJQUFNZ0IsY0FBQSxHQUFpQkEsQ0FBQ0MsS0FBQSxFQUFPQyxLQUFBLEVBQU9DLE9BQUEsS0FBWTtFQUN2RCxJQUFJQyxNQUFBO0VBRUosTUFBTUMsVUFBQSxHQUFheEIsb0JBQUEsQ0FBcUJvQixLQUFBO0VBQ3hDLElBQUksT0FBT0ksVUFBQSxLQUFlLFVBQVU7SUFDbENELE1BQUEsR0FBU0MsVUFBQTtFQUNYLFdBQVdILEtBQUEsS0FBVSxHQUFHO0lBQ3RCRSxNQUFBLEdBQVNDLFVBQUEsQ0FBV3RCLEdBQUE7RUFDdEIsT0FBTztJQUNMcUIsTUFBQSxHQUFTQyxVQUFBLENBQVdyQixLQUFBLENBQU1zQixPQUFBLENBQVEsYUFBYUMsTUFBQSxDQUFPTCxLQUFLLENBQUM7RUFDOUQ7RUFFQSxJQUFJQyxPQUFBLEVBQVNLLFNBQUEsRUFBVztJQUN0QixJQUFJTCxPQUFBLENBQVFNLFVBQUEsSUFBY04sT0FBQSxDQUFRTSxVQUFBLEdBQWEsR0FBRztNQUNoRCxPQUFPTCxNQUFBLEdBQVM7SUFDbEIsT0FBTztNQUNMLE9BQU9BLE1BQUEsR0FBUztJQUNsQjtFQUNGO0VBRUEsT0FBT0EsTUFBQTtBQUNUOzs7QUNyR08sU0FBU00sa0JBQWtCQyxJQUFBLEVBQU07RUFDdEMsT0FBTyxDQUFDUixPQUFBLEdBQVUsQ0FBQyxNQUFNO0lBRXZCLE1BQU1TLEtBQUEsR0FBUVQsT0FBQSxDQUFRUyxLQUFBLEdBQVFMLE1BQUEsQ0FBT0osT0FBQSxDQUFRUyxLQUFLLElBQUlELElBQUEsQ0FBS0UsWUFBQTtJQUMzRCxNQUFNQyxNQUFBLEdBQVNILElBQUEsQ0FBS0ksT0FBQSxDQUFRSCxLQUFBLEtBQVVELElBQUEsQ0FBS0ksT0FBQSxDQUFRSixJQUFBLENBQUtFLFlBQUE7SUFDeEQsT0FBT0MsTUFBQTtFQUNUO0FBQ0Y7OztBQ0pBLElBQU1FLFdBQUEsR0FBYztFQUNsQkMsSUFBQSxFQUFNO0VBQ05DLElBQUEsRUFBTTtFQUNOQyxNQUFBLEVBQVE7RUFDUkMsS0FBQSxFQUFPO0FBQ1Q7QUFFQSxJQUFNQyxXQUFBLEdBQWM7RUFDbEJKLElBQUEsRUFBTTtFQUNOQyxJQUFBLEVBQU07RUFDTkMsTUFBQSxFQUFRO0VBQ1JDLEtBQUEsRUFBTztBQUNUO0FBRUEsSUFBTUUsZUFBQSxHQUFrQjtFQUN0QkwsSUFBQSxFQUFNO0VBQ05DLElBQUEsRUFBTTtFQUNOQyxNQUFBLEVBQVE7RUFDUkMsS0FBQSxFQUFPO0FBQ1Q7QUFFTyxJQUFNRyxVQUFBLEdBQWE7RUFDeEJDLElBQUEsRUFBTWQsaUJBQUEsQ0FBa0I7SUFDdEJLLE9BQUEsRUFBU0MsV0FBQTtJQUNUSCxZQUFBLEVBQWM7RUFDaEIsQ0FBQztFQUVEWSxJQUFBLEVBQU1mLGlCQUFBLENBQWtCO0lBQ3RCSyxPQUFBLEVBQVNNLFdBQUE7SUFDVFIsWUFBQSxFQUFjO0VBQ2hCLENBQUM7RUFFRGEsUUFBQSxFQUFVaEIsaUJBQUEsQ0FBa0I7SUFDMUJLLE9BQUEsRUFBU08sZUFBQTtJQUNUVCxZQUFBLEVBQWM7RUFDaEIsQ0FBQztBQUNIOzs7QUNyQ0EsSUFBTWMsb0JBQUEsR0FBdUI7RUFDM0JDLFFBQUEsRUFBVTtFQUNWQyxTQUFBLEVBQVc7RUFDWEMsS0FBQSxFQUFPO0VBQ1BDLFFBQUEsRUFBVTtFQUNWQyxRQUFBLEVBQVU7RUFDVmhELEtBQUEsRUFBTztBQUNUO0FBRU8sSUFBTWlELGNBQUEsR0FBaUJBLENBQUNoQyxLQUFBLEVBQU9pQyxLQUFBLEVBQU9DLFNBQUEsRUFBV0MsUUFBQSxLQUN0RFQsb0JBQUEsQ0FBcUIxQixLQUFBOzs7QUM2QmhCLFNBQVNvQyxnQkFBZ0IxQixJQUFBLEVBQU07RUFDcEMsT0FBTyxDQUFDMkIsS0FBQSxFQUFPbkMsT0FBQSxLQUFZO0lBQ3pCLE1BQU1vQyxPQUFBLEdBQVVwQyxPQUFBLEVBQVNvQyxPQUFBLEdBQVVoQyxNQUFBLENBQU9KLE9BQUEsQ0FBUW9DLE9BQU8sSUFBSTtJQUU3RCxJQUFJQyxXQUFBO0lBQ0osSUFBSUQsT0FBQSxLQUFZLGdCQUFnQjVCLElBQUEsQ0FBSzhCLGdCQUFBLEVBQWtCO01BQ3JELE1BQU01QixZQUFBLEdBQWVGLElBQUEsQ0FBSytCLHNCQUFBLElBQTBCL0IsSUFBQSxDQUFLRSxZQUFBO01BQ3pELE1BQU1ELEtBQUEsR0FBUVQsT0FBQSxFQUFTUyxLQUFBLEdBQVFMLE1BQUEsQ0FBT0osT0FBQSxDQUFRUyxLQUFLLElBQUlDLFlBQUE7TUFFdkQyQixXQUFBLEdBQ0U3QixJQUFBLENBQUs4QixnQkFBQSxDQUFpQjdCLEtBQUEsS0FBVUQsSUFBQSxDQUFLOEIsZ0JBQUEsQ0FBaUI1QixZQUFBO0lBQzFELE9BQU87TUFDTCxNQUFNQSxZQUFBLEdBQWVGLElBQUEsQ0FBS0UsWUFBQTtNQUMxQixNQUFNRCxLQUFBLEdBQVFULE9BQUEsRUFBU1MsS0FBQSxHQUFRTCxNQUFBLENBQU9KLE9BQUEsQ0FBUVMsS0FBSyxJQUFJRCxJQUFBLENBQUtFLFlBQUE7TUFFNUQyQixXQUFBLEdBQWM3QixJQUFBLENBQUtnQyxNQUFBLENBQU8vQixLQUFBLEtBQVVELElBQUEsQ0FBS2dDLE1BQUEsQ0FBTzlCLFlBQUE7SUFDbEQ7SUFDQSxNQUFNK0IsS0FBQSxHQUFRakMsSUFBQSxDQUFLa0MsZ0JBQUEsR0FBbUJsQyxJQUFBLENBQUtrQyxnQkFBQSxDQUFpQlAsS0FBSyxJQUFJQSxLQUFBO0lBR3JFLE9BQU9FLFdBQUEsQ0FBWUksS0FBQTtFQUNyQjtBQUNGOzs7QUMzREEsSUFBTUUsU0FBQSxHQUFZO0VBQ2hCQyxNQUFBLEVBQVEsQ0FBQyw0QkFBUSxjQUFJO0VBQ3JCQyxXQUFBLEVBQWEsQ0FBQyxzREFBYyxnQkFBTTtFQUNsQ0MsSUFBQSxFQUFNLENBQUMsNkVBQWlCLHNDQUFRO0FBQ2xDO0FBSUEsSUFBTUMsYUFBQSxHQUFnQjtFQUNwQkgsTUFBQSxFQUFRLENBQUMsS0FBSyxLQUFLLEtBQUssR0FBRztFQUMzQkMsV0FBQSxFQUFhLENBQUMsTUFBTSxNQUFNLE1BQU0sSUFBSTtFQUNwQ0MsSUFBQSxFQUFNLENBQUMsNERBQWUsNERBQWUsNERBQWUsMERBQWE7QUFDbkU7QUFTQSxJQUFNRSxXQUFBLEdBQWM7RUFDbEJKLE1BQUEsRUFBUSxDQUFDLGdCQUFNLGdCQUFNLGdCQUFNLFVBQUssZ0JBQU0sZ0JBQU0sZ0JBQU0sVUFBSyxVQUFLLFVBQUssVUFBSyxjQUFJO0VBRTFFQyxXQUFBLEVBQWEsQ0FDWCx3Q0FDQSx3Q0FDQSxrQ0FDQSx3Q0FDQSxnQkFDQSxzQkFDQSxrQ0FDQSxrQ0FDQSxrQ0FDQSxrQ0FDQSxzQkFDQSwyQkFDRjtFQUVBQyxJQUFBLEVBQU0sQ0FDSiwwREFDQSwwREFDQSxrQ0FDQSx3Q0FDQSxnQkFDQSxzQkFDQSxrQ0FDQSxrQ0FDQSwwREFDQSw4Q0FDQSw4Q0FDQTtBQUVKO0FBSUEsSUFBTUcsU0FBQSxHQUFZO0VBQ2hCTCxNQUFBLEVBQVEsQ0FBQyxVQUFLLGdCQUFNLGdCQUFNLGdCQUFNLGdCQUFNLGdCQUFNLFFBQUc7RUFDL0MzQixLQUFBLEVBQU8sQ0FBQyxVQUFLLGdCQUFNLGdCQUFNLGdCQUFNLGdCQUFNLGdCQUFNLFFBQUc7RUFDOUM0QixXQUFBLEVBQWEsQ0FBQyxzQkFBTyxzQkFBTyw0QkFBUSxzQkFBTyw0QkFBUSxrQ0FBUyxvQkFBSztFQUNqRUMsSUFBQSxFQUFNLENBQ0osd0NBQ0Esd0NBQ0EsOENBQ0Esd0NBQ0EsOENBQ0Esb0RBQ0E7QUFFSjtBQUlBLElBQU1JLGVBQUEsR0FBa0I7RUFDdEJOLE1BQUEsRUFBUTtJQUNOTyxFQUFBLEVBQUk7SUFDSkMsRUFBQSxFQUFJO0lBQ0pDLFFBQUEsRUFBVTtJQUNWQyxJQUFBLEVBQU07SUFDTkMsT0FBQSxFQUFTO0lBQ1RDLFNBQUEsRUFBVztJQUNYQyxPQUFBLEVBQVM7SUFDVEMsS0FBQSxFQUFPO0VBQ1Q7RUFDQWIsV0FBQSxFQUFhO0lBQ1hNLEVBQUEsRUFBSTtJQUNKQyxFQUFBLEVBQUk7SUFDSkMsUUFBQSxFQUFVO0lBQ1ZDLElBQUEsRUFBTTtJQUNOQyxPQUFBLEVBQVM7SUFDVEMsU0FBQSxFQUFXO0lBQ1hDLE9BQUEsRUFBUztJQUNUQyxLQUFBLEVBQU87RUFDVDtFQUNBWixJQUFBLEVBQU07SUFDSkssRUFBQSxFQUFJO0lBQ0pDLEVBQUEsRUFBSTtJQUNKQyxRQUFBLEVBQVU7SUFDVkMsSUFBQSxFQUFNO0lBQ05DLE9BQUEsRUFBUztJQUNUQyxTQUFBLEVBQVc7SUFDWEMsT0FBQSxFQUFTO0lBQ1RDLEtBQUEsRUFBTztFQUNUO0FBQ0Y7QUFFQSxJQUFNQyx5QkFBQSxHQUE0QjtFQUNoQ2YsTUFBQSxFQUFRO0lBQ05PLEVBQUEsRUFBSTtJQUNKQyxFQUFBLEVBQUk7SUFDSkMsUUFBQSxFQUFVO0lBQ1ZDLElBQUEsRUFBTTtJQUNOQyxPQUFBLEVBQVM7SUFDVEMsU0FBQSxFQUFXO0lBQ1hDLE9BQUEsRUFBUztJQUNUQyxLQUFBLEVBQU87RUFDVDtFQUNBYixXQUFBLEVBQWE7SUFDWE0sRUFBQSxFQUFJO0lBQ0pDLEVBQUEsRUFBSTtJQUNKQyxRQUFBLEVBQVU7SUFDVkMsSUFBQSxFQUFNO0lBQ05DLE9BQUEsRUFBUztJQUNUQyxTQUFBLEVBQVc7SUFDWEMsT0FBQSxFQUFTO0lBQ1RDLEtBQUEsRUFBTztFQUNUO0VBQ0FaLElBQUEsRUFBTTtJQUNKSyxFQUFBLEVBQUk7SUFDSkMsRUFBQSxFQUFJO0lBQ0pDLFFBQUEsRUFBVTtJQUNWQyxJQUFBLEVBQU07SUFDTkMsT0FBQSxFQUFTO0lBQ1RDLFNBQUEsRUFBVztJQUNYQyxPQUFBLEVBQVM7SUFDVEMsS0FBQSxFQUFPO0VBQ1Q7QUFDRjtBQUVBLElBQU1FLGFBQUEsR0FBZ0JBLENBQUNDLFdBQUEsRUFBYTVCLFFBQUEsS0FBYTtFQUMvQyxPQUFPN0IsTUFBQSxDQUFPeUQsV0FBVztBQUMzQjtBQUVPLElBQU1DLFFBQUEsR0FBVztFQUN0QkYsYUFBQTtFQUVBRyxHQUFBLEVBQUs3QixlQUFBLENBQWdCO0lBQ25CTSxNQUFBLEVBQVFHLFNBQUE7SUFDUmpDLFlBQUEsRUFBYztFQUNoQixDQUFDO0VBRURzRCxPQUFBLEVBQVM5QixlQUFBLENBQWdCO0lBQ3ZCTSxNQUFBLEVBQVFPLGFBQUE7SUFDUnJDLFlBQUEsRUFBYztJQUNkZ0MsZ0JBQUEsRUFBbUJzQixPQUFBLElBQVlBLE9BQUEsR0FBVTtFQUMzQyxDQUFDO0VBRURDLEtBQUEsRUFBTy9CLGVBQUEsQ0FBZ0I7SUFDckJNLE1BQUEsRUFBUVEsV0FBQTtJQUNSdEMsWUFBQSxFQUFjO0VBQ2hCLENBQUM7RUFFRHdELEdBQUEsRUFBS2hDLGVBQUEsQ0FBZ0I7SUFDbkJNLE1BQUEsRUFBUVMsU0FBQTtJQUNSdkMsWUFBQSxFQUFjO0VBQ2hCLENBQUM7RUFFRHlELFNBQUEsRUFBV2pDLGVBQUEsQ0FBZ0I7SUFDekJNLE1BQUEsRUFBUVUsZUFBQTtJQUNSeEMsWUFBQSxFQUFjO0lBQ2Q0QixnQkFBQSxFQUFrQnFCLHlCQUFBO0lBQ2xCcEIsc0JBQUEsRUFBd0I7RUFDMUIsQ0FBQztBQUNIOzs7QUNsTE8sU0FBUzZCLGFBQWE1RCxJQUFBLEVBQU07RUFDakMsT0FBTyxDQUFDNkQsTUFBQSxFQUFRckUsT0FBQSxHQUFVLENBQUMsTUFBTTtJQUMvQixNQUFNUyxLQUFBLEdBQVFULE9BQUEsQ0FBUVMsS0FBQTtJQUV0QixNQUFNNkQsWUFBQSxHQUNIN0QsS0FBQSxJQUFTRCxJQUFBLENBQUsrRCxhQUFBLENBQWM5RCxLQUFBLEtBQzdCRCxJQUFBLENBQUsrRCxhQUFBLENBQWMvRCxJQUFBLENBQUtnRSxpQkFBQTtJQUMxQixNQUFNQyxXQUFBLEdBQWNKLE1BQUEsQ0FBT0ssS0FBQSxDQUFNSixZQUFZO0lBRTdDLElBQUksQ0FBQ0csV0FBQSxFQUFhO01BQ2hCLE9BQU87SUFDVDtJQUNBLE1BQU1FLGFBQUEsR0FBZ0JGLFdBQUEsQ0FBWTtJQUVsQyxNQUFNRyxhQUFBLEdBQ0huRSxLQUFBLElBQVNELElBQUEsQ0FBS29FLGFBQUEsQ0FBY25FLEtBQUEsS0FDN0JELElBQUEsQ0FBS29FLGFBQUEsQ0FBY3BFLElBQUEsQ0FBS3FFLGlCQUFBO0lBRTFCLE1BQU1DLEdBQUEsR0FBTUMsS0FBQSxDQUFNQyxPQUFBLENBQVFKLGFBQWEsSUFDbkNLLFNBQUEsQ0FBVUwsYUFBQSxFQUFnQk0sT0FBQSxJQUFZQSxPQUFBLENBQVFDLElBQUEsQ0FBS1IsYUFBYSxDQUFDLElBRWpFUyxPQUFBLENBQVFSLGFBQUEsRUFBZ0JNLE9BQUEsSUFBWUEsT0FBQSxDQUFRQyxJQUFBLENBQUtSLGFBQWEsQ0FBQztJQUVuRSxJQUFJeEMsS0FBQTtJQUVKQSxLQUFBLEdBQVEzQixJQUFBLENBQUs2RSxhQUFBLEdBQWdCN0UsSUFBQSxDQUFLNkUsYUFBQSxDQUFjUCxHQUFHLElBQUlBLEdBQUE7SUFDdkQzQyxLQUFBLEdBQVFuQyxPQUFBLENBQVFxRixhQUFBLEdBRVpyRixPQUFBLENBQVFxRixhQUFBLENBQWNsRCxLQUFLLElBQzNCQSxLQUFBO0lBRUosTUFBTW1ELElBQUEsR0FBT2pCLE1BQUEsQ0FBT2tCLEtBQUEsQ0FBTVosYUFBQSxDQUFjYSxNQUFNO0lBRTlDLE9BQU87TUFBRXJELEtBQUE7TUFBT21EO0lBQUs7RUFDdkI7QUFDRjtBQUVBLFNBQVNGLFFBQVFLLE1BQUEsRUFBUUMsU0FBQSxFQUFXO0VBQ2xDLFdBQVdaLEdBQUEsSUFBT1csTUFBQSxFQUFRO0lBQ3hCLElBQ0VFLE1BQUEsQ0FBT0MsU0FBQSxDQUFVQyxjQUFBLENBQWVDLElBQUEsQ0FBS0wsTUFBQSxFQUFRWCxHQUFHLEtBQ2hEWSxTQUFBLENBQVVELE1BQUEsQ0FBT1gsR0FBQSxDQUFJLEdBQ3JCO01BQ0EsT0FBT0EsR0FBQTtJQUNUO0VBQ0Y7RUFDQSxPQUFPO0FBQ1Q7QUFFQSxTQUFTRyxVQUFVYyxLQUFBLEVBQU9MLFNBQUEsRUFBVztFQUNuQyxTQUFTWixHQUFBLEdBQU0sR0FBR0EsR0FBQSxHQUFNaUIsS0FBQSxDQUFNUCxNQUFBLEVBQVFWLEdBQUEsSUFBTztJQUMzQyxJQUFJWSxTQUFBLENBQVVLLEtBQUEsQ0FBTWpCLEdBQUEsQ0FBSSxHQUFHO01BQ3pCLE9BQU9BLEdBQUE7SUFDVDtFQUNGO0VBQ0EsT0FBTztBQUNUOzs7QUN4RE8sU0FBU2tCLG9CQUFvQnhGLElBQUEsRUFBTTtFQUN4QyxPQUFPLENBQUM2RCxNQUFBLEVBQVFyRSxPQUFBLEdBQVUsQ0FBQyxNQUFNO0lBQy9CLE1BQU15RSxXQUFBLEdBQWNKLE1BQUEsQ0FBT0ssS0FBQSxDQUFNbEUsSUFBQSxDQUFLOEQsWUFBWTtJQUNsRCxJQUFJLENBQUNHLFdBQUEsRUFBYSxPQUFPO0lBQ3pCLE1BQU1FLGFBQUEsR0FBZ0JGLFdBQUEsQ0FBWTtJQUVsQyxNQUFNd0IsV0FBQSxHQUFjNUIsTUFBQSxDQUFPSyxLQUFBLENBQU1sRSxJQUFBLENBQUswRixZQUFZO0lBQ2xELElBQUksQ0FBQ0QsV0FBQSxFQUFhLE9BQU87SUFDekIsSUFBSTlELEtBQUEsR0FBUTNCLElBQUEsQ0FBSzZFLGFBQUEsR0FDYjdFLElBQUEsQ0FBSzZFLGFBQUEsQ0FBY1ksV0FBQSxDQUFZLEVBQUUsSUFDakNBLFdBQUEsQ0FBWTtJQUdoQjlELEtBQUEsR0FBUW5DLE9BQUEsQ0FBUXFGLGFBQUEsR0FBZ0JyRixPQUFBLENBQVFxRixhQUFBLENBQWNsRCxLQUFLLElBQUlBLEtBQUE7SUFFL0QsTUFBTW1ELElBQUEsR0FBT2pCLE1BQUEsQ0FBT2tCLEtBQUEsQ0FBTVosYUFBQSxDQUFjYSxNQUFNO0lBRTlDLE9BQU87TUFBRXJELEtBQUE7TUFBT21EO0lBQUs7RUFDdkI7QUFDRjs7O0FDaEJBLElBQU1hLHlCQUFBLEdBQTRCO0FBQ2xDLElBQU1DLHlCQUFBLEdBQTRCO0FBRWxDLElBQU1DLGdCQUFBLEdBQW1CO0VBQ3ZCekQsTUFBQSxFQUFRO0VBQ1JDLFdBQUEsRUFBYTtFQUNiQyxJQUFBLEVBQU07QUFDUjtBQUNBLElBQU13RCxnQkFBQSxHQUFtQjtFQUN2QkMsR0FBQSxFQUFLLENBQUMsVUFBVSxNQUFNO0FBQ3hCO0FBRUEsSUFBTUMsb0JBQUEsR0FBdUI7RUFDM0I1RCxNQUFBLEVBQVE7RUFDUkMsV0FBQSxFQUFhO0VBQ2JDLElBQUEsRUFBTTtBQUNSO0FBQ0EsSUFBTTJELG9CQUFBLEdBQXVCO0VBQzNCRixHQUFBLEVBQUssQ0FBQyxNQUFNLE1BQU0sTUFBTSxJQUFJO0FBQzlCO0FBRUEsSUFBTUcsa0JBQUEsR0FBcUI7RUFFekI5RCxNQUFBLEVBQVE7RUFDUkMsV0FBQSxFQUNFO0VBQ0ZDLElBQUEsRUFBTTtBQUNSO0FBQ0EsSUFBTTZELGtCQUFBLEdBQXFCO0VBQ3pCL0QsTUFBQSxFQUFRLENBQ04sUUFDQSxRQUNBLFFBQ0EsT0FDQSxRQUNBLFFBQ0EsUUFDQSxRQUNBLE9BQ0EsV0FDQSxPQUNBLE9BQ0Y7RUFFQTJELEdBQUEsRUFBSyxDQUNILFFBQ0EsUUFDQSxRQUNBLE9BQ0EsUUFDQSxRQUNBLFFBQ0EsUUFDQSxPQUNBLFdBQ0EsT0FDQTtBQUVKO0FBRUEsSUFBTUssZ0JBQUEsR0FBbUI7RUFDdkJoRSxNQUFBLEVBQVE7RUFDUjNCLEtBQUEsRUFBTztFQUNQNEIsV0FBQSxFQUFhO0VBQ2JDLElBQUEsRUFBTTtBQUNSO0FBQ0EsSUFBTStELGdCQUFBLEdBQW1CO0VBQ3ZCakUsTUFBQSxFQUFRLENBQUMsT0FBTyxRQUFRLFFBQVEsUUFBUSxRQUFRLFFBQVEsS0FBSztFQUM3RDJELEdBQUEsRUFBSyxDQUFDLE9BQU8sUUFBUSxRQUFRLFFBQVEsUUFBUSxRQUFRLEtBQUs7QUFDNUQ7QUFFQSxJQUFNTyxzQkFBQSxHQUF5QjtFQUM3QmxFLE1BQUEsRUFBUTtFQUNSMkQsR0FBQSxFQUFLO0FBQ1A7QUFDQSxJQUFNUSxzQkFBQSxHQUF5QjtFQUM3QlIsR0FBQSxFQUFLO0lBQ0hwRCxFQUFBLEVBQUk7SUFDSkMsRUFBQSxFQUFJO0lBQ0pDLFFBQUEsRUFBVTtJQUNWQyxJQUFBLEVBQU07SUFDTkMsT0FBQSxFQUFTO0lBQ1RDLFNBQUEsRUFBVztJQUNYQyxPQUFBLEVBQVM7SUFDVEMsS0FBQSxFQUFPO0VBQ1Q7QUFDRjtBQUVPLElBQU1nQixLQUFBLEdBQVE7RUFDbkJkLGFBQUEsRUFBZW9DLG1CQUFBLENBQW9CO0lBQ2pDMUIsWUFBQSxFQUFjNkIseUJBQUE7SUFDZEQsWUFBQSxFQUFjRSx5QkFBQTtJQUNkZixhQUFBLEVBQWdCbEQsS0FBQSxJQUFVNkUsUUFBQSxDQUFTN0UsS0FBQSxFQUFPLEVBQUU7RUFDOUMsQ0FBQztFQUVENEIsR0FBQSxFQUFLSyxZQUFBLENBQWE7SUFDaEJHLGFBQUEsRUFBZThCLGdCQUFBO0lBQ2Y3QixpQkFBQSxFQUFtQjtJQUNuQkksYUFBQSxFQUFlMEIsZ0JBQUE7SUFDZnpCLGlCQUFBLEVBQW1CO0VBQ3JCLENBQUM7RUFFRGIsT0FBQSxFQUFTSSxZQUFBLENBQWE7SUFDcEJHLGFBQUEsRUFBZWlDLG9CQUFBO0lBQ2ZoQyxpQkFBQSxFQUFtQjtJQUNuQkksYUFBQSxFQUFlNkIsb0JBQUE7SUFDZjVCLGlCQUFBLEVBQW1CO0lBQ25CUSxhQUFBLEVBQWdCNUMsS0FBQSxJQUFVQSxLQUFBLEdBQVE7RUFDcEMsQ0FBQztFQUVEd0IsS0FBQSxFQUFPRyxZQUFBLENBQWE7SUFDbEJHLGFBQUEsRUFBZW1DLGtCQUFBO0lBQ2ZsQyxpQkFBQSxFQUFtQjtJQUNuQkksYUFBQSxFQUFlK0Isa0JBQUE7SUFDZjlCLGlCQUFBLEVBQW1CO0VBQ3JCLENBQUM7RUFFRFgsR0FBQSxFQUFLRSxZQUFBLENBQWE7SUFDaEJHLGFBQUEsRUFBZXFDLGdCQUFBO0lBQ2ZwQyxpQkFBQSxFQUFtQjtJQUNuQkksYUFBQSxFQUFlaUMsZ0JBQUE7SUFDZmhDLGlCQUFBLEVBQW1CO0VBQ3JCLENBQUM7RUFFRFYsU0FBQSxFQUFXQyxZQUFBLENBQWE7SUFDdEJHLGFBQUEsRUFBZXVDLHNCQUFBO0lBQ2Z0QyxpQkFBQSxFQUFtQjtJQUNuQkksYUFBQSxFQUFlbUMsc0JBQUE7SUFDZmxDLGlCQUFBLEVBQW1CO0VBQ3JCLENBQUM7QUFDSDs7O0FDeEhPLElBQU12RyxFQUFBLEdBQUs7RUFDaEIySSxJQUFBLEVBQU07RUFDTnBILGNBQUE7RUFDQXVCLFVBQUE7RUFDQVUsY0FBQTtFQUNBZ0MsUUFBQTtFQUNBWSxLQUFBO0VBQ0ExRSxPQUFBLEVBQVM7SUFDUGtILFlBQUEsRUFBYztJQUNkQyxxQkFBQSxFQUF1QjtFQUN6QjtBQUNGO0FBR0EsSUFBT0MsVUFBQSxHQUFROUksRUFBQTs7O0FWeEJmLElBQU9ELGdCQUFBLEdBQVErSSxVQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9