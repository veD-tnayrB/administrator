System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/startOfWeek","date-fns@3.6.0/isSameWeek"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfWeek', dep), dep => dependencies.set('date-fns@3.6.0/isSameWeek', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/locale/it-CH.3.6.0.js
var it_CH_3_6_0_exports = {};
__export(it_CH_3_6_0_exports, {
  default: () => it_CH_3_6_0_default,
  itCH: () => itCH
});
module.exports = __toCommonJS(it_CH_3_6_0_exports);

// node_modules/date-fns/locale/it/_lib/formatDistance.mjs
var formatDistanceLocale = {
  lessThanXSeconds: {
    one: "meno di un secondo",
    other: "meno di {{count}} secondi"
  },
  xSeconds: {
    one: "un secondo",
    other: "{{count}} secondi"
  },
  halfAMinute: "alcuni secondi",
  lessThanXMinutes: {
    one: "meno di un minuto",
    other: "meno di {{count}} minuti"
  },
  xMinutes: {
    one: "un minuto",
    other: "{{count}} minuti"
  },
  aboutXHours: {
    one: "circa un'ora",
    other: "circa {{count}} ore"
  },
  xHours: {
    one: "un'ora",
    other: "{{count}} ore"
  },
  xDays: {
    one: "un giorno",
    other: "{{count}} giorni"
  },
  aboutXWeeks: {
    one: "circa una settimana",
    other: "circa {{count}} settimane"
  },
  xWeeks: {
    one: "una settimana",
    other: "{{count}} settimane"
  },
  aboutXMonths: {
    one: "circa un mese",
    other: "circa {{count}} mesi"
  },
  xMonths: {
    one: "un mese",
    other: "{{count}} mesi"
  },
  aboutXYears: {
    one: "circa un anno",
    other: "circa {{count}} anni"
  },
  xYears: {
    one: "un anno",
    other: "{{count}} anni"
  },
  overXYears: {
    one: "pi\xF9 di un anno",
    other: "pi\xF9 di {{count}} anni"
  },
  almostXYears: {
    one: "quasi un anno",
    other: "quasi {{count}} anni"
  }
};
var formatDistance = (token, count, options) => {
  let result;
  const tokenValue = formatDistanceLocale[token];
  if (typeof tokenValue === "string") {
    result = tokenValue;
  } else if (count === 1) {
    result = tokenValue.one;
  } else {
    result = tokenValue.other.replace("{{count}}", count.toString());
  }
  if (options?.addSuffix) {
    if (options.comparison && options.comparison > 0) {
      return "tra " + result;
    } else {
      return result + " fa";
    }
  }
  return result;
};

// node_modules/date-fns/locale/it/_lib/formatRelative.mjs
var import_isSameWeek = require("date-fns@3.6.0/isSameWeek");
var weekdays = ["domenica", "luned\xEC", "marted\xEC", "mercoled\xEC", "gioved\xEC", "venerd\xEC", "sabato"];
function lastWeek(day) {
  switch (day) {
    case 0:
      return "'domenica scorsa alle' p";
    default:
      return "'" + weekdays[day] + " scorso alle' p";
  }
}
function thisWeek(day) {
  return "'" + weekdays[day] + " alle' p";
}
function nextWeek(day) {
  switch (day) {
    case 0:
      return "'domenica prossima alle' p";
    default:
      return "'" + weekdays[day] + " prossimo alle' p";
  }
}
var formatRelativeLocale = {
  lastWeek: (date, baseDate, options) => {
    const day = date.getDay();
    if ((0, import_isSameWeek.isSameWeek)(date, baseDate, options)) {
      return thisWeek(day);
    } else {
      return lastWeek(day);
    }
  },
  yesterday: "'ieri alle' p",
  today: "'oggi alle' p",
  tomorrow: "'domani alle' p",
  nextWeek: (date, baseDate, options) => {
    const day = date.getDay();
    if ((0, import_isSameWeek.isSameWeek)(date, baseDate, options)) {
      return thisWeek(day);
    } else {
      return nextWeek(day);
    }
  },
  other: "P"
};
var formatRelative = (token, date, baseDate, options) => {
  const format = formatRelativeLocale[token];
  if (typeof format === "function") {
    return format(date, baseDate, options);
  }
  return format;
};

// node_modules/date-fns/locale/_lib/buildLocalizeFn.mjs
function buildLocalizeFn(args) {
  return (value, options) => {
    const context = options?.context ? String(options.context) : "standalone";
    let valuesArray;
    if (context === "formatting" && args.formattingValues) {
      const defaultWidth = args.defaultFormattingWidth || args.defaultWidth;
      const width = options?.width ? String(options.width) : defaultWidth;
      valuesArray = args.formattingValues[width] || args.formattingValues[defaultWidth];
    } else {
      const defaultWidth = args.defaultWidth;
      const width = options?.width ? String(options.width) : args.defaultWidth;
      valuesArray = args.values[width] || args.values[defaultWidth];
    }
    const index = args.argumentCallback ? args.argumentCallback(value) : value;
    return valuesArray[index];
  };
}

// node_modules/date-fns/locale/it/_lib/localize.mjs
var eraValues = {
  narrow: ["aC", "dC"],
  abbreviated: ["a.C.", "d.C."],
  wide: ["avanti Cristo", "dopo Cristo"]
};
var quarterValues = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["T1", "T2", "T3", "T4"],
  wide: ["1\xBA trimestre", "2\xBA trimestre", "3\xBA trimestre", "4\xBA trimestre"]
};
var monthValues = {
  narrow: ["G", "F", "M", "A", "M", "G", "L", "A", "S", "O", "N", "D"],
  abbreviated: ["gen", "feb", "mar", "apr", "mag", "giu", "lug", "ago", "set", "ott", "nov", "dic"],
  wide: ["gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno", "luglio", "agosto", "settembre", "ottobre", "novembre", "dicembre"]
};
var dayValues = {
  narrow: ["D", "L", "M", "M", "G", "V", "S"],
  short: ["dom", "lun", "mar", "mer", "gio", "ven", "sab"],
  abbreviated: ["dom", "lun", "mar", "mer", "gio", "ven", "sab"],
  wide: ["domenica", "luned\xEC", "marted\xEC", "mercoled\xEC", "gioved\xEC", "venerd\xEC", "sabato"]
};
var dayPeriodValues = {
  narrow: {
    am: "m.",
    pm: "p.",
    midnight: "mezzanotte",
    noon: "mezzogiorno",
    morning: "mattina",
    afternoon: "pomeriggio",
    evening: "sera",
    night: "notte"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "mezzanotte",
    noon: "mezzogiorno",
    morning: "mattina",
    afternoon: "pomeriggio",
    evening: "sera",
    night: "notte"
  },
  wide: {
    am: "AM",
    pm: "PM",
    midnight: "mezzanotte",
    noon: "mezzogiorno",
    morning: "mattina",
    afternoon: "pomeriggio",
    evening: "sera",
    night: "notte"
  }
};
var formattingDayPeriodValues = {
  narrow: {
    am: "m.",
    pm: "p.",
    midnight: "mezzanotte",
    noon: "mezzogiorno",
    morning: "di mattina",
    afternoon: "del pomeriggio",
    evening: "di sera",
    night: "di notte"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "mezzanotte",
    noon: "mezzogiorno",
    morning: "di mattina",
    afternoon: "del pomeriggio",
    evening: "di sera",
    night: "di notte"
  },
  wide: {
    am: "AM",
    pm: "PM",
    midnight: "mezzanotte",
    noon: "mezzogiorno",
    morning: "di mattina",
    afternoon: "del pomeriggio",
    evening: "di sera",
    night: "di notte"
  }
};
var ordinalNumber = (dirtyNumber, _options) => {
  const number = Number(dirtyNumber);
  return String(number);
};
var localize = {
  ordinalNumber,
  era: buildLocalizeFn({
    values: eraValues,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues,
    defaultWidth: "wide",
    argumentCallback: quarter => quarter - 1
  }),
  month: buildLocalizeFn({
    values: monthValues,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues,
    defaultFormattingWidth: "wide"
  })
};

// node_modules/date-fns/locale/_lib/buildMatchFn.mjs
function buildMatchFn(args) {
  return (string, options = {}) => {
    const width = options.width;
    const matchPattern = width && args.matchPatterns[width] || args.matchPatterns[args.defaultMatchWidth];
    const matchResult = string.match(matchPattern);
    if (!matchResult) {
      return null;
    }
    const matchedString = matchResult[0];
    const parsePatterns = width && args.parsePatterns[width] || args.parsePatterns[args.defaultParseWidth];
    const key = Array.isArray(parsePatterns) ? findIndex(parsePatterns, pattern => pattern.test(matchedString)) : findKey(parsePatterns, pattern => pattern.test(matchedString));
    let value;
    value = args.valueCallback ? args.valueCallback(key) : key;
    value = options.valueCallback ? options.valueCallback(value) : value;
    const rest = string.slice(matchedString.length);
    return {
      value,
      rest
    };
  };
}
function findKey(object, predicate) {
  for (const key in object) {
    if (Object.prototype.hasOwnProperty.call(object, key) && predicate(object[key])) {
      return key;
    }
  }
  return void 0;
}
function findIndex(array, predicate) {
  for (let key = 0; key < array.length; key++) {
    if (predicate(array[key])) {
      return key;
    }
  }
  return void 0;
}

// node_modules/date-fns/locale/_lib/buildMatchPatternFn.mjs
function buildMatchPatternFn(args) {
  return (string, options = {}) => {
    const matchResult = string.match(args.matchPattern);
    if (!matchResult) return null;
    const matchedString = matchResult[0];
    const parseResult = string.match(args.parsePattern);
    if (!parseResult) return null;
    let value = args.valueCallback ? args.valueCallback(parseResult[0]) : parseResult[0];
    value = options.valueCallback ? options.valueCallback(value) : value;
    const rest = string.slice(matchedString.length);
    return {
      value,
      rest
    };
  };
}

// node_modules/date-fns/locale/it/_lib/match.mjs
var matchOrdinalNumberPattern = /^(\d+)(º)?/i;
var parseOrdinalNumberPattern = /\d+/i;
var matchEraPatterns = {
  narrow: /^(aC|dC)/i,
  abbreviated: /^(a\.?\s?C\.?|a\.?\s?e\.?\s?v\.?|d\.?\s?C\.?|e\.?\s?v\.?)/i,
  wide: /^(avanti Cristo|avanti Era Volgare|dopo Cristo|Era Volgare)/i
};
var parseEraPatterns = {
  any: [/^a/i, /^(d|e)/i]
};
var matchQuarterPatterns = {
  narrow: /^[1234]/i,
  abbreviated: /^t[1234]/i,
  wide: /^[1234](º)? trimestre/i
};
var parseQuarterPatterns = {
  any: [/1/i, /2/i, /3/i, /4/i]
};
var matchMonthPatterns = {
  narrow: /^[gfmalsond]/i,
  abbreviated: /^(gen|feb|mar|apr|mag|giu|lug|ago|set|ott|nov|dic)/i,
  wide: /^(gennaio|febbraio|marzo|aprile|maggio|giugno|luglio|agosto|settembre|ottobre|novembre|dicembre)/i
};
var parseMonthPatterns = {
  narrow: [/^g/i, /^f/i, /^m/i, /^a/i, /^m/i, /^g/i, /^l/i, /^a/i, /^s/i, /^o/i, /^n/i, /^d/i],
  any: [/^ge/i, /^f/i, /^mar/i, /^ap/i, /^mag/i, /^gi/i, /^l/i, /^ag/i, /^s/i, /^o/i, /^n/i, /^d/i]
};
var matchDayPatterns = {
  narrow: /^[dlmgvs]/i,
  short: /^(do|lu|ma|me|gi|ve|sa)/i,
  abbreviated: /^(dom|lun|mar|mer|gio|ven|sab)/i,
  wide: /^(domenica|luned[i|ì]|marted[i|ì]|mercoled[i|ì]|gioved[i|ì]|venerd[i|ì]|sabato)/i
};
var parseDayPatterns = {
  narrow: [/^d/i, /^l/i, /^m/i, /^m/i, /^g/i, /^v/i, /^s/i],
  any: [/^d/i, /^l/i, /^ma/i, /^me/i, /^g/i, /^v/i, /^s/i]
};
var matchDayPeriodPatterns = {
  narrow: /^(a|m\.|p|mezzanotte|mezzogiorno|(di|del) (mattina|pomeriggio|sera|notte))/i,
  any: /^([ap]\.?\s?m\.?|mezzanotte|mezzogiorno|(di|del) (mattina|pomeriggio|sera|notte))/i
};
var parseDayPeriodPatterns = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^mezza/i,
    noon: /^mezzo/i,
    morning: /mattina/i,
    afternoon: /pomeriggio/i,
    evening: /sera/i,
    night: /notte/i
  }
};
var match = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern,
    parsePattern: parseOrdinalNumberPattern,
    valueCallback: value => parseInt(value, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns,
    defaultParseWidth: "any",
    valueCallback: index => index + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns,
    defaultParseWidth: "any"
  })
};

// node_modules/date-fns/locale/_lib/buildFormatLongFn.mjs
function buildFormatLongFn(args) {
  return (options = {}) => {
    const width = options.width ? String(options.width) : args.defaultWidth;
    const format = args.formats[width] || args.formats[args.defaultWidth];
    return format;
  };
}

// node_modules/date-fns/locale/it-CH/_lib/formatLong.mjs
var dateFormats = {
  full: "EEEE d MMMM y",
  long: "d MMMM y",
  medium: "d MMM y",
  short: "dd.MM.y"
};
var timeFormats = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
};
var dateTimeFormats = {
  full: "{{date}} {{time}}",
  long: "{{date}} {{time}}",
  medium: "{{date}} {{time}}",
  short: "{{date}} {{time}}"
};
var formatLong = {
  date: buildFormatLongFn({
    formats: dateFormats,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats,
    defaultWidth: "full"
  })
};

// node_modules/date-fns/locale/it-CH.mjs
var itCH = {
  code: "it-CH",
  formatDistance,
  formatLong,
  formatRelative,
  localize,
  match,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
};
var it_CH_default = itCH;

// .beyond/uimport/temp/date-fns/locale/it-CH.3.6.0.js
var it_CH_3_6_0_default = it_CH_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2xvY2FsZS9pdC1DSC4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9sb2NhbGUvaXQvX2xpYi9mb3JtYXREaXN0YW5jZS5tanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvbG9jYWxlL2l0L19saWIvZm9ybWF0UmVsYXRpdmUubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9fbGliL2J1aWxkTG9jYWxpemVGbi5tanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvbG9jYWxlL2l0L19saWIvbG9jYWxpemUubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9fbGliL2J1aWxkTWF0Y2hGbi5tanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvbG9jYWxlL19saWIvYnVpbGRNYXRjaFBhdHRlcm5Gbi5tanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvbG9jYWxlL2l0L19saWIvbWF0Y2gubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9fbGliL2J1aWxkRm9ybWF0TG9uZ0ZuLm1qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9sb2NhbGUvaXQtQ0gvX2xpYi9mb3JtYXRMb25nLm1qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9sb2NhbGUvaXQtQ0gubWpzIl0sIm5hbWVzIjpbIml0X0NIXzNfNl8wX2V4cG9ydHMiLCJfX2V4cG9ydCIsImRlZmF1bHQiLCJpdF9DSF8zXzZfMF9kZWZhdWx0IiwiaXRDSCIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJmb3JtYXREaXN0YW5jZUxvY2FsZSIsImxlc3NUaGFuWFNlY29uZHMiLCJvbmUiLCJvdGhlciIsInhTZWNvbmRzIiwiaGFsZkFNaW51dGUiLCJsZXNzVGhhblhNaW51dGVzIiwieE1pbnV0ZXMiLCJhYm91dFhIb3VycyIsInhIb3VycyIsInhEYXlzIiwiYWJvdXRYV2Vla3MiLCJ4V2Vla3MiLCJhYm91dFhNb250aHMiLCJ4TW9udGhzIiwiYWJvdXRYWWVhcnMiLCJ4WWVhcnMiLCJvdmVyWFllYXJzIiwiYWxtb3N0WFllYXJzIiwiZm9ybWF0RGlzdGFuY2UiLCJ0b2tlbiIsImNvdW50Iiwib3B0aW9ucyIsInJlc3VsdCIsInRva2VuVmFsdWUiLCJyZXBsYWNlIiwidG9TdHJpbmciLCJhZGRTdWZmaXgiLCJjb21wYXJpc29uIiwiaW1wb3J0X2lzU2FtZVdlZWsiLCJyZXF1aXJlIiwid2Vla2RheXMiLCJsYXN0V2VlayIsImRheSIsInRoaXNXZWVrIiwibmV4dFdlZWsiLCJmb3JtYXRSZWxhdGl2ZUxvY2FsZSIsImRhdGUiLCJiYXNlRGF0ZSIsImdldERheSIsImlzU2FtZVdlZWsiLCJ5ZXN0ZXJkYXkiLCJ0b2RheSIsInRvbW9ycm93IiwiZm9ybWF0UmVsYXRpdmUiLCJmb3JtYXQiLCJidWlsZExvY2FsaXplRm4iLCJhcmdzIiwidmFsdWUiLCJjb250ZXh0IiwiU3RyaW5nIiwidmFsdWVzQXJyYXkiLCJmb3JtYXR0aW5nVmFsdWVzIiwiZGVmYXVsdFdpZHRoIiwiZGVmYXVsdEZvcm1hdHRpbmdXaWR0aCIsIndpZHRoIiwidmFsdWVzIiwiaW5kZXgiLCJhcmd1bWVudENhbGxiYWNrIiwiZXJhVmFsdWVzIiwibmFycm93IiwiYWJicmV2aWF0ZWQiLCJ3aWRlIiwicXVhcnRlclZhbHVlcyIsIm1vbnRoVmFsdWVzIiwiZGF5VmFsdWVzIiwic2hvcnQiLCJkYXlQZXJpb2RWYWx1ZXMiLCJhbSIsInBtIiwibWlkbmlnaHQiLCJub29uIiwibW9ybmluZyIsImFmdGVybm9vbiIsImV2ZW5pbmciLCJuaWdodCIsImZvcm1hdHRpbmdEYXlQZXJpb2RWYWx1ZXMiLCJvcmRpbmFsTnVtYmVyIiwiZGlydHlOdW1iZXIiLCJfb3B0aW9ucyIsIm51bWJlciIsIk51bWJlciIsImxvY2FsaXplIiwiZXJhIiwicXVhcnRlciIsIm1vbnRoIiwiZGF5UGVyaW9kIiwiYnVpbGRNYXRjaEZuIiwic3RyaW5nIiwibWF0Y2hQYXR0ZXJuIiwibWF0Y2hQYXR0ZXJucyIsImRlZmF1bHRNYXRjaFdpZHRoIiwibWF0Y2hSZXN1bHQiLCJtYXRjaCIsIm1hdGNoZWRTdHJpbmciLCJwYXJzZVBhdHRlcm5zIiwiZGVmYXVsdFBhcnNlV2lkdGgiLCJrZXkiLCJBcnJheSIsImlzQXJyYXkiLCJmaW5kSW5kZXgiLCJwYXR0ZXJuIiwidGVzdCIsImZpbmRLZXkiLCJ2YWx1ZUNhbGxiYWNrIiwicmVzdCIsInNsaWNlIiwibGVuZ3RoIiwib2JqZWN0IiwicHJlZGljYXRlIiwiT2JqZWN0IiwicHJvdG90eXBlIiwiaGFzT3duUHJvcGVydHkiLCJjYWxsIiwiYXJyYXkiLCJidWlsZE1hdGNoUGF0dGVybkZuIiwicGFyc2VSZXN1bHQiLCJwYXJzZVBhdHRlcm4iLCJtYXRjaE9yZGluYWxOdW1iZXJQYXR0ZXJuIiwicGFyc2VPcmRpbmFsTnVtYmVyUGF0dGVybiIsIm1hdGNoRXJhUGF0dGVybnMiLCJwYXJzZUVyYVBhdHRlcm5zIiwiYW55IiwibWF0Y2hRdWFydGVyUGF0dGVybnMiLCJwYXJzZVF1YXJ0ZXJQYXR0ZXJucyIsIm1hdGNoTW9udGhQYXR0ZXJucyIsInBhcnNlTW9udGhQYXR0ZXJucyIsIm1hdGNoRGF5UGF0dGVybnMiLCJwYXJzZURheVBhdHRlcm5zIiwibWF0Y2hEYXlQZXJpb2RQYXR0ZXJucyIsInBhcnNlRGF5UGVyaW9kUGF0dGVybnMiLCJwYXJzZUludCIsImJ1aWxkRm9ybWF0TG9uZ0ZuIiwiZm9ybWF0cyIsImRhdGVGb3JtYXRzIiwiZnVsbCIsImxvbmciLCJtZWRpdW0iLCJ0aW1lRm9ybWF0cyIsImRhdGVUaW1lRm9ybWF0cyIsImZvcm1hdExvbmciLCJ0aW1lIiwiZGF0ZVRpbWUiLCJjb2RlIiwid2Vla1N0YXJ0c09uIiwiZmlyc3RXZWVrQ29udGFpbnNEYXRlIiwiaXRfQ0hfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsbUJBQUE7QUFBQUMsUUFBQSxDQUFBRCxtQkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsbUJBQUE7RUFBQUMsSUFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsbUJBQUE7OztBQ0FBLElBQU1RLG9CQUFBLEdBQXVCO0VBQzNCQyxnQkFBQSxFQUFrQjtJQUNoQkMsR0FBQSxFQUFLO0lBQ0xDLEtBQUEsRUFBTztFQUNUO0VBRUFDLFFBQUEsRUFBVTtJQUNSRixHQUFBLEVBQUs7SUFDTEMsS0FBQSxFQUFPO0VBQ1Q7RUFFQUUsV0FBQSxFQUFhO0VBRWJDLGdCQUFBLEVBQWtCO0lBQ2hCSixHQUFBLEVBQUs7SUFDTEMsS0FBQSxFQUFPO0VBQ1Q7RUFFQUksUUFBQSxFQUFVO0lBQ1JMLEdBQUEsRUFBSztJQUNMQyxLQUFBLEVBQU87RUFDVDtFQUVBSyxXQUFBLEVBQWE7SUFDWE4sR0FBQSxFQUFLO0lBQ0xDLEtBQUEsRUFBTztFQUNUO0VBRUFNLE1BQUEsRUFBUTtJQUNOUCxHQUFBLEVBQUs7SUFDTEMsS0FBQSxFQUFPO0VBQ1Q7RUFFQU8sS0FBQSxFQUFPO0lBQ0xSLEdBQUEsRUFBSztJQUNMQyxLQUFBLEVBQU87RUFDVDtFQUVBUSxXQUFBLEVBQWE7SUFDWFQsR0FBQSxFQUFLO0lBQ0xDLEtBQUEsRUFBTztFQUNUO0VBRUFTLE1BQUEsRUFBUTtJQUNOVixHQUFBLEVBQUs7SUFDTEMsS0FBQSxFQUFPO0VBQ1Q7RUFFQVUsWUFBQSxFQUFjO0lBQ1pYLEdBQUEsRUFBSztJQUNMQyxLQUFBLEVBQU87RUFDVDtFQUVBVyxPQUFBLEVBQVM7SUFDUFosR0FBQSxFQUFLO0lBQ0xDLEtBQUEsRUFBTztFQUNUO0VBRUFZLFdBQUEsRUFBYTtJQUNYYixHQUFBLEVBQUs7SUFDTEMsS0FBQSxFQUFPO0VBQ1Q7RUFFQWEsTUFBQSxFQUFRO0lBQ05kLEdBQUEsRUFBSztJQUNMQyxLQUFBLEVBQU87RUFDVDtFQUVBYyxVQUFBLEVBQVk7SUFDVmYsR0FBQSxFQUFLO0lBQ0xDLEtBQUEsRUFBTztFQUNUO0VBRUFlLFlBQUEsRUFBYztJQUNaaEIsR0FBQSxFQUFLO0lBQ0xDLEtBQUEsRUFBTztFQUNUO0FBQ0Y7QUFFTyxJQUFNZ0IsY0FBQSxHQUFpQkEsQ0FBQ0MsS0FBQSxFQUFPQyxLQUFBLEVBQU9DLE9BQUEsS0FBWTtFQUN2RCxJQUFJQyxNQUFBO0VBRUosTUFBTUMsVUFBQSxHQUFheEIsb0JBQUEsQ0FBcUJvQixLQUFBO0VBQ3hDLElBQUksT0FBT0ksVUFBQSxLQUFlLFVBQVU7SUFDbENELE1BQUEsR0FBU0MsVUFBQTtFQUNYLFdBQVdILEtBQUEsS0FBVSxHQUFHO0lBQ3RCRSxNQUFBLEdBQVNDLFVBQUEsQ0FBV3RCLEdBQUE7RUFDdEIsT0FBTztJQUNMcUIsTUFBQSxHQUFTQyxVQUFBLENBQVdyQixLQUFBLENBQU1zQixPQUFBLENBQVEsYUFBYUosS0FBQSxDQUFNSyxRQUFBLENBQVMsQ0FBQztFQUNqRTtFQUVBLElBQUlKLE9BQUEsRUFBU0ssU0FBQSxFQUFXO0lBQ3RCLElBQUlMLE9BQUEsQ0FBUU0sVUFBQSxJQUFjTixPQUFBLENBQVFNLFVBQUEsR0FBYSxHQUFHO01BQ2hELE9BQU8sU0FBU0wsTUFBQTtJQUNsQixPQUFPO01BQ0wsT0FBT0EsTUFBQSxHQUFTO0lBQ2xCO0VBQ0Y7RUFFQSxPQUFPQSxNQUFBO0FBQ1Q7OztBQ3BHQSxJQUFBTSxpQkFBQSxHQUEyQkMsT0FBQTtBQUUzQixJQUFNQyxRQUFBLEdBQVcsQ0FDZixZQUNBLGFBQ0EsY0FDQSxnQkFDQSxjQUNBLGNBQ0EsU0FDRjtBQUVBLFNBQVNDLFNBQVNDLEdBQUEsRUFBSztFQUNyQixRQUFRQSxHQUFBO0lBQUEsS0FDRDtNQUNILE9BQU87SUFBQTtNQUVQLE9BQU8sTUFBTUYsUUFBQSxDQUFTRSxHQUFBLElBQU87RUFBQTtBQUVuQztBQUVBLFNBQVNDLFNBQVNELEdBQUEsRUFBSztFQUNyQixPQUFPLE1BQU1GLFFBQUEsQ0FBU0UsR0FBQSxJQUFPO0FBQy9CO0FBRUEsU0FBU0UsU0FBU0YsR0FBQSxFQUFLO0VBQ3JCLFFBQVFBLEdBQUE7SUFBQSxLQUNEO01BQ0gsT0FBTztJQUFBO01BRVAsT0FBTyxNQUFNRixRQUFBLENBQVNFLEdBQUEsSUFBTztFQUFBO0FBRW5DO0FBRUEsSUFBTUcsb0JBQUEsR0FBdUI7RUFDM0JKLFFBQUEsRUFBVUEsQ0FBQ0ssSUFBQSxFQUFNQyxRQUFBLEVBQVVoQixPQUFBLEtBQVk7SUFDckMsTUFBTVcsR0FBQSxHQUFNSSxJQUFBLENBQUtFLE1BQUEsQ0FBTztJQUN4QixRQUFJVixpQkFBQSxDQUFBVyxVQUFBLEVBQVdILElBQUEsRUFBTUMsUUFBQSxFQUFVaEIsT0FBTyxHQUFHO01BQ3ZDLE9BQU9ZLFFBQUEsQ0FBU0QsR0FBRztJQUNyQixPQUFPO01BQ0wsT0FBT0QsUUFBQSxDQUFTQyxHQUFHO0lBQ3JCO0VBQ0Y7RUFDQVEsU0FBQSxFQUFXO0VBQ1hDLEtBQUEsRUFBTztFQUNQQyxRQUFBLEVBQVU7RUFDVlIsUUFBQSxFQUFVQSxDQUFDRSxJQUFBLEVBQU1DLFFBQUEsRUFBVWhCLE9BQUEsS0FBWTtJQUNyQyxNQUFNVyxHQUFBLEdBQU1JLElBQUEsQ0FBS0UsTUFBQSxDQUFPO0lBQ3hCLFFBQUlWLGlCQUFBLENBQUFXLFVBQUEsRUFBV0gsSUFBQSxFQUFNQyxRQUFBLEVBQVVoQixPQUFPLEdBQUc7TUFDdkMsT0FBT1ksUUFBQSxDQUFTRCxHQUFHO0lBQ3JCLE9BQU87TUFDTCxPQUFPRSxRQUFBLENBQVNGLEdBQUc7SUFDckI7RUFDRjtFQUNBOUIsS0FBQSxFQUFPO0FBQ1Q7QUFFTyxJQUFNeUMsY0FBQSxHQUFpQkEsQ0FBQ3hCLEtBQUEsRUFBT2lCLElBQUEsRUFBTUMsUUFBQSxFQUFVaEIsT0FBQSxLQUFZO0VBQ2hFLE1BQU11QixNQUFBLEdBQVNULG9CQUFBLENBQXFCaEIsS0FBQTtFQUVwQyxJQUFJLE9BQU95QixNQUFBLEtBQVcsWUFBWTtJQUNoQyxPQUFPQSxNQUFBLENBQU9SLElBQUEsRUFBTUMsUUFBQSxFQUFVaEIsT0FBTztFQUN2QztFQUVBLE9BQU91QixNQUFBO0FBQ1Q7OztBQ3hCTyxTQUFTQyxnQkFBZ0JDLElBQUEsRUFBTTtFQUNwQyxPQUFPLENBQUNDLEtBQUEsRUFBTzFCLE9BQUEsS0FBWTtJQUN6QixNQUFNMkIsT0FBQSxHQUFVM0IsT0FBQSxFQUFTMkIsT0FBQSxHQUFVQyxNQUFBLENBQU81QixPQUFBLENBQVEyQixPQUFPLElBQUk7SUFFN0QsSUFBSUUsV0FBQTtJQUNKLElBQUlGLE9BQUEsS0FBWSxnQkFBZ0JGLElBQUEsQ0FBS0ssZ0JBQUEsRUFBa0I7TUFDckQsTUFBTUMsWUFBQSxHQUFlTixJQUFBLENBQUtPLHNCQUFBLElBQTBCUCxJQUFBLENBQUtNLFlBQUE7TUFDekQsTUFBTUUsS0FBQSxHQUFRakMsT0FBQSxFQUFTaUMsS0FBQSxHQUFRTCxNQUFBLENBQU81QixPQUFBLENBQVFpQyxLQUFLLElBQUlGLFlBQUE7TUFFdkRGLFdBQUEsR0FDRUosSUFBQSxDQUFLSyxnQkFBQSxDQUFpQkcsS0FBQSxLQUFVUixJQUFBLENBQUtLLGdCQUFBLENBQWlCQyxZQUFBO0lBQzFELE9BQU87TUFDTCxNQUFNQSxZQUFBLEdBQWVOLElBQUEsQ0FBS00sWUFBQTtNQUMxQixNQUFNRSxLQUFBLEdBQVFqQyxPQUFBLEVBQVNpQyxLQUFBLEdBQVFMLE1BQUEsQ0FBTzVCLE9BQUEsQ0FBUWlDLEtBQUssSUFBSVIsSUFBQSxDQUFLTSxZQUFBO01BRTVERixXQUFBLEdBQWNKLElBQUEsQ0FBS1MsTUFBQSxDQUFPRCxLQUFBLEtBQVVSLElBQUEsQ0FBS1MsTUFBQSxDQUFPSCxZQUFBO0lBQ2xEO0lBQ0EsTUFBTUksS0FBQSxHQUFRVixJQUFBLENBQUtXLGdCQUFBLEdBQW1CWCxJQUFBLENBQUtXLGdCQUFBLENBQWlCVixLQUFLLElBQUlBLEtBQUE7SUFHckUsT0FBT0csV0FBQSxDQUFZTSxLQUFBO0VBQ3JCO0FBQ0Y7OztBQzdEQSxJQUFNRSxTQUFBLEdBQVk7RUFDaEJDLE1BQUEsRUFBUSxDQUFDLE1BQU0sSUFBSTtFQUNuQkMsV0FBQSxFQUFhLENBQUMsUUFBUSxNQUFNO0VBQzVCQyxJQUFBLEVBQU0sQ0FBQyxpQkFBaUIsYUFBYTtBQUN2QztBQUVBLElBQU1DLGFBQUEsR0FBZ0I7RUFDcEJILE1BQUEsRUFBUSxDQUFDLEtBQUssS0FBSyxLQUFLLEdBQUc7RUFDM0JDLFdBQUEsRUFBYSxDQUFDLE1BQU0sTUFBTSxNQUFNLElBQUk7RUFDcENDLElBQUEsRUFBTSxDQUFDLG1CQUFnQixtQkFBZ0IsbUJBQWdCLGlCQUFjO0FBQ3ZFO0FBRUEsSUFBTUUsV0FBQSxHQUFjO0VBQ2xCSixNQUFBLEVBQVEsQ0FBQyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssR0FBRztFQUNuRUMsV0FBQSxFQUFhLENBQ1gsT0FDQSxPQUNBLE9BQ0EsT0FDQSxPQUNBLE9BQ0EsT0FDQSxPQUNBLE9BQ0EsT0FDQSxPQUNBLE1BQ0Y7RUFFQUMsSUFBQSxFQUFNLENBQ0osV0FDQSxZQUNBLFNBQ0EsVUFDQSxVQUNBLFVBQ0EsVUFDQSxVQUNBLGFBQ0EsV0FDQSxZQUNBO0FBRUo7QUFFQSxJQUFNRyxTQUFBLEdBQVk7RUFDaEJMLE1BQUEsRUFBUSxDQUFDLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEdBQUc7RUFDMUNNLEtBQUEsRUFBTyxDQUFDLE9BQU8sT0FBTyxPQUFPLE9BQU8sT0FBTyxPQUFPLEtBQUs7RUFDdkRMLFdBQUEsRUFBYSxDQUFDLE9BQU8sT0FBTyxPQUFPLE9BQU8sT0FBTyxPQUFPLEtBQUs7RUFDN0RDLElBQUEsRUFBTSxDQUNKLFlBQ0EsYUFDQSxjQUNBLGdCQUNBLGNBQ0EsY0FDQTtBQUVKO0FBRUEsSUFBTUssZUFBQSxHQUFrQjtFQUN0QlAsTUFBQSxFQUFRO0lBQ05RLEVBQUEsRUFBSTtJQUNKQyxFQUFBLEVBQUk7SUFDSkMsUUFBQSxFQUFVO0lBQ1ZDLElBQUEsRUFBTTtJQUNOQyxPQUFBLEVBQVM7SUFDVEMsU0FBQSxFQUFXO0lBQ1hDLE9BQUEsRUFBUztJQUNUQyxLQUFBLEVBQU87RUFDVDtFQUNBZCxXQUFBLEVBQWE7SUFDWE8sRUFBQSxFQUFJO0lBQ0pDLEVBQUEsRUFBSTtJQUNKQyxRQUFBLEVBQVU7SUFDVkMsSUFBQSxFQUFNO0lBQ05DLE9BQUEsRUFBUztJQUNUQyxTQUFBLEVBQVc7SUFDWEMsT0FBQSxFQUFTO0lBQ1RDLEtBQUEsRUFBTztFQUNUO0VBQ0FiLElBQUEsRUFBTTtJQUNKTSxFQUFBLEVBQUk7SUFDSkMsRUFBQSxFQUFJO0lBQ0pDLFFBQUEsRUFBVTtJQUNWQyxJQUFBLEVBQU07SUFDTkMsT0FBQSxFQUFTO0lBQ1RDLFNBQUEsRUFBVztJQUNYQyxPQUFBLEVBQVM7SUFDVEMsS0FBQSxFQUFPO0VBQ1Q7QUFDRjtBQUVBLElBQU1DLHlCQUFBLEdBQTRCO0VBQ2hDaEIsTUFBQSxFQUFRO0lBQ05RLEVBQUEsRUFBSTtJQUNKQyxFQUFBLEVBQUk7SUFDSkMsUUFBQSxFQUFVO0lBQ1ZDLElBQUEsRUFBTTtJQUNOQyxPQUFBLEVBQVM7SUFDVEMsU0FBQSxFQUFXO0lBQ1hDLE9BQUEsRUFBUztJQUNUQyxLQUFBLEVBQU87RUFDVDtFQUNBZCxXQUFBLEVBQWE7SUFDWE8sRUFBQSxFQUFJO0lBQ0pDLEVBQUEsRUFBSTtJQUNKQyxRQUFBLEVBQVU7SUFDVkMsSUFBQSxFQUFNO0lBQ05DLE9BQUEsRUFBUztJQUNUQyxTQUFBLEVBQVc7SUFDWEMsT0FBQSxFQUFTO0lBQ1RDLEtBQUEsRUFBTztFQUNUO0VBQ0FiLElBQUEsRUFBTTtJQUNKTSxFQUFBLEVBQUk7SUFDSkMsRUFBQSxFQUFJO0lBQ0pDLFFBQUEsRUFBVTtJQUNWQyxJQUFBLEVBQU07SUFDTkMsT0FBQSxFQUFTO0lBQ1RDLFNBQUEsRUFBVztJQUNYQyxPQUFBLEVBQVM7SUFDVEMsS0FBQSxFQUFPO0VBQ1Q7QUFDRjtBQUVBLElBQU1FLGFBQUEsR0FBZ0JBLENBQUNDLFdBQUEsRUFBYUMsUUFBQSxLQUFhO0VBQy9DLE1BQU1DLE1BQUEsR0FBU0MsTUFBQSxDQUFPSCxXQUFXO0VBQ2pDLE9BQU81QixNQUFBLENBQU84QixNQUFNO0FBQ3RCO0FBRU8sSUFBTUUsUUFBQSxHQUFXO0VBQ3RCTCxhQUFBO0VBRUFNLEdBQUEsRUFBS3JDLGVBQUEsQ0FBZ0I7SUFDbkJVLE1BQUEsRUFBUUcsU0FBQTtJQUNSTixZQUFBLEVBQWM7RUFDaEIsQ0FBQztFQUVEK0IsT0FBQSxFQUFTdEMsZUFBQSxDQUFnQjtJQUN2QlUsTUFBQSxFQUFRTyxhQUFBO0lBQ1JWLFlBQUEsRUFBYztJQUNkSyxnQkFBQSxFQUFtQjBCLE9BQUEsSUFBWUEsT0FBQSxHQUFVO0VBQzNDLENBQUM7RUFFREMsS0FBQSxFQUFPdkMsZUFBQSxDQUFnQjtJQUNyQlUsTUFBQSxFQUFRUSxXQUFBO0lBQ1JYLFlBQUEsRUFBYztFQUNoQixDQUFDO0VBRURwQixHQUFBLEVBQUthLGVBQUEsQ0FBZ0I7SUFDbkJVLE1BQUEsRUFBUVMsU0FBQTtJQUNSWixZQUFBLEVBQWM7RUFDaEIsQ0FBQztFQUVEaUMsU0FBQSxFQUFXeEMsZUFBQSxDQUFnQjtJQUN6QlUsTUFBQSxFQUFRVyxlQUFBO0lBQ1JkLFlBQUEsRUFBYztJQUNkRCxnQkFBQSxFQUFrQndCLHlCQUFBO0lBQ2xCdEIsc0JBQUEsRUFBd0I7RUFDMUIsQ0FBQztBQUNIOzs7QUNuS08sU0FBU2lDLGFBQWF4QyxJQUFBLEVBQU07RUFDakMsT0FBTyxDQUFDeUMsTUFBQSxFQUFRbEUsT0FBQSxHQUFVLENBQUMsTUFBTTtJQUMvQixNQUFNaUMsS0FBQSxHQUFRakMsT0FBQSxDQUFRaUMsS0FBQTtJQUV0QixNQUFNa0MsWUFBQSxHQUNIbEMsS0FBQSxJQUFTUixJQUFBLENBQUsyQyxhQUFBLENBQWNuQyxLQUFBLEtBQzdCUixJQUFBLENBQUsyQyxhQUFBLENBQWMzQyxJQUFBLENBQUs0QyxpQkFBQTtJQUMxQixNQUFNQyxXQUFBLEdBQWNKLE1BQUEsQ0FBT0ssS0FBQSxDQUFNSixZQUFZO0lBRTdDLElBQUksQ0FBQ0csV0FBQSxFQUFhO01BQ2hCLE9BQU87SUFDVDtJQUNBLE1BQU1FLGFBQUEsR0FBZ0JGLFdBQUEsQ0FBWTtJQUVsQyxNQUFNRyxhQUFBLEdBQ0h4QyxLQUFBLElBQVNSLElBQUEsQ0FBS2dELGFBQUEsQ0FBY3hDLEtBQUEsS0FDN0JSLElBQUEsQ0FBS2dELGFBQUEsQ0FBY2hELElBQUEsQ0FBS2lELGlCQUFBO0lBRTFCLE1BQU1DLEdBQUEsR0FBTUMsS0FBQSxDQUFNQyxPQUFBLENBQVFKLGFBQWEsSUFDbkNLLFNBQUEsQ0FBVUwsYUFBQSxFQUFnQk0sT0FBQSxJQUFZQSxPQUFBLENBQVFDLElBQUEsQ0FBS1IsYUFBYSxDQUFDLElBRWpFUyxPQUFBLENBQVFSLGFBQUEsRUFBZ0JNLE9BQUEsSUFBWUEsT0FBQSxDQUFRQyxJQUFBLENBQUtSLGFBQWEsQ0FBQztJQUVuRSxJQUFJOUMsS0FBQTtJQUVKQSxLQUFBLEdBQVFELElBQUEsQ0FBS3lELGFBQUEsR0FBZ0J6RCxJQUFBLENBQUt5RCxhQUFBLENBQWNQLEdBQUcsSUFBSUEsR0FBQTtJQUN2RGpELEtBQUEsR0FBUTFCLE9BQUEsQ0FBUWtGLGFBQUEsR0FFWmxGLE9BQUEsQ0FBUWtGLGFBQUEsQ0FBY3hELEtBQUssSUFDM0JBLEtBQUE7SUFFSixNQUFNeUQsSUFBQSxHQUFPakIsTUFBQSxDQUFPa0IsS0FBQSxDQUFNWixhQUFBLENBQWNhLE1BQU07SUFFOUMsT0FBTztNQUFFM0QsS0FBQTtNQUFPeUQ7SUFBSztFQUN2QjtBQUNGO0FBRUEsU0FBU0YsUUFBUUssTUFBQSxFQUFRQyxTQUFBLEVBQVc7RUFDbEMsV0FBV1osR0FBQSxJQUFPVyxNQUFBLEVBQVE7SUFDeEIsSUFDRUUsTUFBQSxDQUFPQyxTQUFBLENBQVVDLGNBQUEsQ0FBZUMsSUFBQSxDQUFLTCxNQUFBLEVBQVFYLEdBQUcsS0FDaERZLFNBQUEsQ0FBVUQsTUFBQSxDQUFPWCxHQUFBLENBQUksR0FDckI7TUFDQSxPQUFPQSxHQUFBO0lBQ1Q7RUFDRjtFQUNBLE9BQU87QUFDVDtBQUVBLFNBQVNHLFVBQVVjLEtBQUEsRUFBT0wsU0FBQSxFQUFXO0VBQ25DLFNBQVNaLEdBQUEsR0FBTSxHQUFHQSxHQUFBLEdBQU1pQixLQUFBLENBQU1QLE1BQUEsRUFBUVYsR0FBQSxJQUFPO0lBQzNDLElBQUlZLFNBQUEsQ0FBVUssS0FBQSxDQUFNakIsR0FBQSxDQUFJLEdBQUc7TUFDekIsT0FBT0EsR0FBQTtJQUNUO0VBQ0Y7RUFDQSxPQUFPO0FBQ1Q7OztBQ3hETyxTQUFTa0Isb0JBQW9CcEUsSUFBQSxFQUFNO0VBQ3hDLE9BQU8sQ0FBQ3lDLE1BQUEsRUFBUWxFLE9BQUEsR0FBVSxDQUFDLE1BQU07SUFDL0IsTUFBTXNFLFdBQUEsR0FBY0osTUFBQSxDQUFPSyxLQUFBLENBQU05QyxJQUFBLENBQUswQyxZQUFZO0lBQ2xELElBQUksQ0FBQ0csV0FBQSxFQUFhLE9BQU87SUFDekIsTUFBTUUsYUFBQSxHQUFnQkYsV0FBQSxDQUFZO0lBRWxDLE1BQU13QixXQUFBLEdBQWM1QixNQUFBLENBQU9LLEtBQUEsQ0FBTTlDLElBQUEsQ0FBS3NFLFlBQVk7SUFDbEQsSUFBSSxDQUFDRCxXQUFBLEVBQWEsT0FBTztJQUN6QixJQUFJcEUsS0FBQSxHQUFRRCxJQUFBLENBQUt5RCxhQUFBLEdBQ2J6RCxJQUFBLENBQUt5RCxhQUFBLENBQWNZLFdBQUEsQ0FBWSxFQUFFLElBQ2pDQSxXQUFBLENBQVk7SUFHaEJwRSxLQUFBLEdBQVExQixPQUFBLENBQVFrRixhQUFBLEdBQWdCbEYsT0FBQSxDQUFRa0YsYUFBQSxDQUFjeEQsS0FBSyxJQUFJQSxLQUFBO0lBRS9ELE1BQU15RCxJQUFBLEdBQU9qQixNQUFBLENBQU9rQixLQUFBLENBQU1aLGFBQUEsQ0FBY2EsTUFBTTtJQUU5QyxPQUFPO01BQUUzRCxLQUFBO01BQU95RDtJQUFLO0VBQ3ZCO0FBQ0Y7OztBQ2hCQSxJQUFNYSx5QkFBQSxHQUE0QjtBQUNsQyxJQUFNQyx5QkFBQSxHQUE0QjtBQUVsQyxJQUFNQyxnQkFBQSxHQUFtQjtFQUN2QjVELE1BQUEsRUFBUTtFQUNSQyxXQUFBLEVBQWE7RUFDYkMsSUFBQSxFQUFNO0FBQ1I7QUFDQSxJQUFNMkQsZ0JBQUEsR0FBbUI7RUFDdkJDLEdBQUEsRUFBSyxDQUFDLE9BQU8sU0FBUztBQUN4QjtBQUVBLElBQU1DLG9CQUFBLEdBQXVCO0VBQzNCL0QsTUFBQSxFQUFRO0VBQ1JDLFdBQUEsRUFBYTtFQUNiQyxJQUFBLEVBQU07QUFDUjtBQUNBLElBQU04RCxvQkFBQSxHQUF1QjtFQUMzQkYsR0FBQSxFQUFLLENBQUMsTUFBTSxNQUFNLE1BQU0sSUFBSTtBQUM5QjtBQUVBLElBQU1HLGtCQUFBLEdBQXFCO0VBQ3pCakUsTUFBQSxFQUFRO0VBQ1JDLFdBQUEsRUFBYTtFQUNiQyxJQUFBLEVBQU07QUFDUjtBQUNBLElBQU1nRSxrQkFBQSxHQUFxQjtFQUN6QmxFLE1BQUEsRUFBUSxDQUNOLE9BQ0EsT0FDQSxPQUNBLE9BQ0EsT0FDQSxPQUNBLE9BQ0EsT0FDQSxPQUNBLE9BQ0EsT0FDQSxNQUNGO0VBRUE4RCxHQUFBLEVBQUssQ0FDSCxRQUNBLE9BQ0EsU0FDQSxRQUNBLFNBQ0EsUUFDQSxPQUNBLFFBQ0EsT0FDQSxPQUNBLE9BQ0E7QUFFSjtBQUVBLElBQU1LLGdCQUFBLEdBQW1CO0VBQ3ZCbkUsTUFBQSxFQUFRO0VBQ1JNLEtBQUEsRUFBTztFQUNQTCxXQUFBLEVBQWE7RUFDYkMsSUFBQSxFQUFNO0FBQ1I7QUFDQSxJQUFNa0UsZ0JBQUEsR0FBbUI7RUFDdkJwRSxNQUFBLEVBQVEsQ0FBQyxPQUFPLE9BQU8sT0FBTyxPQUFPLE9BQU8sT0FBTyxLQUFLO0VBQ3hEOEQsR0FBQSxFQUFLLENBQUMsT0FBTyxPQUFPLFFBQVEsUUFBUSxPQUFPLE9BQU8sS0FBSztBQUN6RDtBQUVBLElBQU1PLHNCQUFBLEdBQXlCO0VBQzdCckUsTUFBQSxFQUNFO0VBQ0Y4RCxHQUFBLEVBQUs7QUFDUDtBQUNBLElBQU1RLHNCQUFBLEdBQXlCO0VBQzdCUixHQUFBLEVBQUs7SUFDSHRELEVBQUEsRUFBSTtJQUNKQyxFQUFBLEVBQUk7SUFDSkMsUUFBQSxFQUFVO0lBQ1ZDLElBQUEsRUFBTTtJQUNOQyxPQUFBLEVBQVM7SUFDVEMsU0FBQSxFQUFXO0lBQ1hDLE9BQUEsRUFBUztJQUNUQyxLQUFBLEVBQU87RUFDVDtBQUNGO0FBRU8sSUFBTWtCLEtBQUEsR0FBUTtFQUNuQmhCLGFBQUEsRUFBZXNDLG1CQUFBLENBQW9CO0lBQ2pDMUIsWUFBQSxFQUFjNkIseUJBQUE7SUFDZEQsWUFBQSxFQUFjRSx5QkFBQTtJQUNkZixhQUFBLEVBQWdCeEQsS0FBQSxJQUFVbUYsUUFBQSxDQUFTbkYsS0FBQSxFQUFPLEVBQUU7RUFDOUMsQ0FBQztFQUVEbUMsR0FBQSxFQUFLSSxZQUFBLENBQWE7SUFDaEJHLGFBQUEsRUFBZThCLGdCQUFBO0lBQ2Y3QixpQkFBQSxFQUFtQjtJQUNuQkksYUFBQSxFQUFlMEIsZ0JBQUE7SUFDZnpCLGlCQUFBLEVBQW1CO0VBQ3JCLENBQUM7RUFFRFosT0FBQSxFQUFTRyxZQUFBLENBQWE7SUFDcEJHLGFBQUEsRUFBZWlDLG9CQUFBO0lBQ2ZoQyxpQkFBQSxFQUFtQjtJQUNuQkksYUFBQSxFQUFlNkIsb0JBQUE7SUFDZjVCLGlCQUFBLEVBQW1CO0lBQ25CUSxhQUFBLEVBQWdCL0MsS0FBQSxJQUFVQSxLQUFBLEdBQVE7RUFDcEMsQ0FBQztFQUVENEIsS0FBQSxFQUFPRSxZQUFBLENBQWE7SUFDbEJHLGFBQUEsRUFBZW1DLGtCQUFBO0lBQ2ZsQyxpQkFBQSxFQUFtQjtJQUNuQkksYUFBQSxFQUFlK0Isa0JBQUE7SUFDZjlCLGlCQUFBLEVBQW1CO0VBQ3JCLENBQUM7RUFFRC9ELEdBQUEsRUFBS3NELFlBQUEsQ0FBYTtJQUNoQkcsYUFBQSxFQUFlcUMsZ0JBQUE7SUFDZnBDLGlCQUFBLEVBQW1CO0lBQ25CSSxhQUFBLEVBQWVpQyxnQkFBQTtJQUNmaEMsaUJBQUEsRUFBbUI7RUFDckIsQ0FBQztFQUVEVixTQUFBLEVBQVdDLFlBQUEsQ0FBYTtJQUN0QkcsYUFBQSxFQUFldUMsc0JBQUE7SUFDZnRDLGlCQUFBLEVBQW1CO0lBQ25CSSxhQUFBLEVBQWVtQyxzQkFBQTtJQUNmbEMsaUJBQUEsRUFBbUI7RUFDckIsQ0FBQztBQUNIOzs7QUNwSU8sU0FBU29DLGtCQUFrQnJGLElBQUEsRUFBTTtFQUN0QyxPQUFPLENBQUN6QixPQUFBLEdBQVUsQ0FBQyxNQUFNO0lBRXZCLE1BQU1pQyxLQUFBLEdBQVFqQyxPQUFBLENBQVFpQyxLQUFBLEdBQVFMLE1BQUEsQ0FBTzVCLE9BQUEsQ0FBUWlDLEtBQUssSUFBSVIsSUFBQSxDQUFLTSxZQUFBO0lBQzNELE1BQU1SLE1BQUEsR0FBU0UsSUFBQSxDQUFLc0YsT0FBQSxDQUFROUUsS0FBQSxLQUFVUixJQUFBLENBQUtzRixPQUFBLENBQVF0RixJQUFBLENBQUtNLFlBQUE7SUFDeEQsT0FBT1IsTUFBQTtFQUNUO0FBQ0Y7OztBQ0xBLElBQU15RixXQUFBLEdBQWM7RUFDbEJDLElBQUEsRUFBTTtFQUNOQyxJQUFBLEVBQU07RUFDTkMsTUFBQSxFQUFRO0VBQ1J2RSxLQUFBLEVBQU87QUFDVDtBQUVBLElBQU13RSxXQUFBLEdBQWM7RUFDbEJILElBQUEsRUFBTTtFQUNOQyxJQUFBLEVBQU07RUFDTkMsTUFBQSxFQUFRO0VBQ1J2RSxLQUFBLEVBQU87QUFDVDtBQUVBLElBQU15RSxlQUFBLEdBQWtCO0VBQ3RCSixJQUFBLEVBQU07RUFDTkMsSUFBQSxFQUFNO0VBQ05DLE1BQUEsRUFBUTtFQUNSdkUsS0FBQSxFQUFPO0FBQ1Q7QUFFTyxJQUFNMEUsVUFBQSxHQUFhO0VBQ3hCdkcsSUFBQSxFQUFNK0YsaUJBQUEsQ0FBa0I7SUFDdEJDLE9BQUEsRUFBU0MsV0FBQTtJQUNUakYsWUFBQSxFQUFjO0VBQ2hCLENBQUM7RUFFRHdGLElBQUEsRUFBTVQsaUJBQUEsQ0FBa0I7SUFDdEJDLE9BQUEsRUFBU0ssV0FBQTtJQUNUckYsWUFBQSxFQUFjO0VBQ2hCLENBQUM7RUFFRHlGLFFBQUEsRUFBVVYsaUJBQUEsQ0FBa0I7SUFDMUJDLE9BQUEsRUFBU00sZUFBQTtJQUNUdEYsWUFBQSxFQUFjO0VBQ2hCLENBQUM7QUFDSDs7O0FDekJPLElBQU16RCxJQUFBLEdBQU87RUFDbEJtSixJQUFBLEVBQU07RUFDTjVILGNBQUE7RUFDQXlILFVBQUE7RUFDQWhHLGNBQUE7RUFDQXNDLFFBQUE7RUFDQVcsS0FBQTtFQUNBdkUsT0FBQSxFQUFTO0lBQ1AwSCxZQUFBLEVBQWM7SUFDZEMscUJBQUEsRUFBdUI7RUFDekI7QUFDRjtBQUdBLElBQU9DLGFBQUEsR0FBUXRKLElBQUE7OztBVnhCZixJQUFPRCxtQkFBQSxHQUFRdUosYUFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==