System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/startOfWeek","date-fns@3.6.0/isSameWeek"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfWeek', dep), dep => dependencies.set('date-fns@3.6.0/isSameWeek', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/locale/it.3.6.0.js
var it_3_6_0_exports = {};
__export(it_3_6_0_exports, {
  default: () => it_3_6_0_default,
  it: () => it
});
module.exports = __toCommonJS(it_3_6_0_exports);

// node_modules/date-fns/locale/it/_lib/formatDistance.mjs
var formatDistanceLocale = {
  lessThanXSeconds: {
    one: "meno di un secondo",
    other: "meno di {{count}} secondi"
  },
  xSeconds: {
    one: "un secondo",
    other: "{{count}} secondi"
  },
  halfAMinute: "alcuni secondi",
  lessThanXMinutes: {
    one: "meno di un minuto",
    other: "meno di {{count}} minuti"
  },
  xMinutes: {
    one: "un minuto",
    other: "{{count}} minuti"
  },
  aboutXHours: {
    one: "circa un'ora",
    other: "circa {{count}} ore"
  },
  xHours: {
    one: "un'ora",
    other: "{{count}} ore"
  },
  xDays: {
    one: "un giorno",
    other: "{{count}} giorni"
  },
  aboutXWeeks: {
    one: "circa una settimana",
    other: "circa {{count}} settimane"
  },
  xWeeks: {
    one: "una settimana",
    other: "{{count}} settimane"
  },
  aboutXMonths: {
    one: "circa un mese",
    other: "circa {{count}} mesi"
  },
  xMonths: {
    one: "un mese",
    other: "{{count}} mesi"
  },
  aboutXYears: {
    one: "circa un anno",
    other: "circa {{count}} anni"
  },
  xYears: {
    one: "un anno",
    other: "{{count}} anni"
  },
  overXYears: {
    one: "pi\xF9 di un anno",
    other: "pi\xF9 di {{count}} anni"
  },
  almostXYears: {
    one: "quasi un anno",
    other: "quasi {{count}} anni"
  }
};
var formatDistance = (token, count, options) => {
  let result;
  const tokenValue = formatDistanceLocale[token];
  if (typeof tokenValue === "string") {
    result = tokenValue;
  } else if (count === 1) {
    result = tokenValue.one;
  } else {
    result = tokenValue.other.replace("{{count}}", count.toString());
  }
  if (options?.addSuffix) {
    if (options.comparison && options.comparison > 0) {
      return "tra " + result;
    } else {
      return result + " fa";
    }
  }
  return result;
};

// node_modules/date-fns/locale/_lib/buildFormatLongFn.mjs
function buildFormatLongFn(args) {
  return (options = {}) => {
    const width = options.width ? String(options.width) : args.defaultWidth;
    const format = args.formats[width] || args.formats[args.defaultWidth];
    return format;
  };
}

// node_modules/date-fns/locale/it/_lib/formatLong.mjs
var dateFormats = {
  full: "EEEE d MMMM y",
  long: "d MMMM y",
  medium: "d MMM y",
  short: "dd/MM/y"
};
var timeFormats = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
};
var dateTimeFormats = {
  full: "{{date}} {{time}}",
  long: "{{date}} {{time}}",
  medium: "{{date}} {{time}}",
  short: "{{date}} {{time}}"
};
var formatLong = {
  date: buildFormatLongFn({
    formats: dateFormats,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats,
    defaultWidth: "full"
  })
};

// node_modules/date-fns/locale/it/_lib/formatRelative.mjs
var import_isSameWeek = require("date-fns@3.6.0/isSameWeek");
var weekdays = ["domenica", "luned\xEC", "marted\xEC", "mercoled\xEC", "gioved\xEC", "venerd\xEC", "sabato"];
function lastWeek(day) {
  switch (day) {
    case 0:
      return "'domenica scorsa alle' p";
    default:
      return "'" + weekdays[day] + " scorso alle' p";
  }
}
function thisWeek(day) {
  return "'" + weekdays[day] + " alle' p";
}
function nextWeek(day) {
  switch (day) {
    case 0:
      return "'domenica prossima alle' p";
    default:
      return "'" + weekdays[day] + " prossimo alle' p";
  }
}
var formatRelativeLocale = {
  lastWeek: (date, baseDate, options) => {
    const day = date.getDay();
    if ((0, import_isSameWeek.isSameWeek)(date, baseDate, options)) {
      return thisWeek(day);
    } else {
      return lastWeek(day);
    }
  },
  yesterday: "'ieri alle' p",
  today: "'oggi alle' p",
  tomorrow: "'domani alle' p",
  nextWeek: (date, baseDate, options) => {
    const day = date.getDay();
    if ((0, import_isSameWeek.isSameWeek)(date, baseDate, options)) {
      return thisWeek(day);
    } else {
      return nextWeek(day);
    }
  },
  other: "P"
};
var formatRelative = (token, date, baseDate, options) => {
  const format = formatRelativeLocale[token];
  if (typeof format === "function") {
    return format(date, baseDate, options);
  }
  return format;
};

// node_modules/date-fns/locale/_lib/buildLocalizeFn.mjs
function buildLocalizeFn(args) {
  return (value, options) => {
    const context = options?.context ? String(options.context) : "standalone";
    let valuesArray;
    if (context === "formatting" && args.formattingValues) {
      const defaultWidth = args.defaultFormattingWidth || args.defaultWidth;
      const width = options?.width ? String(options.width) : defaultWidth;
      valuesArray = args.formattingValues[width] || args.formattingValues[defaultWidth];
    } else {
      const defaultWidth = args.defaultWidth;
      const width = options?.width ? String(options.width) : args.defaultWidth;
      valuesArray = args.values[width] || args.values[defaultWidth];
    }
    const index = args.argumentCallback ? args.argumentCallback(value) : value;
    return valuesArray[index];
  };
}

// node_modules/date-fns/locale/it/_lib/localize.mjs
var eraValues = {
  narrow: ["aC", "dC"],
  abbreviated: ["a.C.", "d.C."],
  wide: ["avanti Cristo", "dopo Cristo"]
};
var quarterValues = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["T1", "T2", "T3", "T4"],
  wide: ["1\xBA trimestre", "2\xBA trimestre", "3\xBA trimestre", "4\xBA trimestre"]
};
var monthValues = {
  narrow: ["G", "F", "M", "A", "M", "G", "L", "A", "S", "O", "N", "D"],
  abbreviated: ["gen", "feb", "mar", "apr", "mag", "giu", "lug", "ago", "set", "ott", "nov", "dic"],
  wide: ["gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno", "luglio", "agosto", "settembre", "ottobre", "novembre", "dicembre"]
};
var dayValues = {
  narrow: ["D", "L", "M", "M", "G", "V", "S"],
  short: ["dom", "lun", "mar", "mer", "gio", "ven", "sab"],
  abbreviated: ["dom", "lun", "mar", "mer", "gio", "ven", "sab"],
  wide: ["domenica", "luned\xEC", "marted\xEC", "mercoled\xEC", "gioved\xEC", "venerd\xEC", "sabato"]
};
var dayPeriodValues = {
  narrow: {
    am: "m.",
    pm: "p.",
    midnight: "mezzanotte",
    noon: "mezzogiorno",
    morning: "mattina",
    afternoon: "pomeriggio",
    evening: "sera",
    night: "notte"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "mezzanotte",
    noon: "mezzogiorno",
    morning: "mattina",
    afternoon: "pomeriggio",
    evening: "sera",
    night: "notte"
  },
  wide: {
    am: "AM",
    pm: "PM",
    midnight: "mezzanotte",
    noon: "mezzogiorno",
    morning: "mattina",
    afternoon: "pomeriggio",
    evening: "sera",
    night: "notte"
  }
};
var formattingDayPeriodValues = {
  narrow: {
    am: "m.",
    pm: "p.",
    midnight: "mezzanotte",
    noon: "mezzogiorno",
    morning: "di mattina",
    afternoon: "del pomeriggio",
    evening: "di sera",
    night: "di notte"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "mezzanotte",
    noon: "mezzogiorno",
    morning: "di mattina",
    afternoon: "del pomeriggio",
    evening: "di sera",
    night: "di notte"
  },
  wide: {
    am: "AM",
    pm: "PM",
    midnight: "mezzanotte",
    noon: "mezzogiorno",
    morning: "di mattina",
    afternoon: "del pomeriggio",
    evening: "di sera",
    night: "di notte"
  }
};
var ordinalNumber = (dirtyNumber, _options) => {
  const number = Number(dirtyNumber);
  return String(number);
};
var localize = {
  ordinalNumber,
  era: buildLocalizeFn({
    values: eraValues,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues,
    defaultWidth: "wide",
    argumentCallback: quarter => quarter - 1
  }),
  month: buildLocalizeFn({
    values: monthValues,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues,
    defaultFormattingWidth: "wide"
  })
};

// node_modules/date-fns/locale/_lib/buildMatchFn.mjs
function buildMatchFn(args) {
  return (string, options = {}) => {
    const width = options.width;
    const matchPattern = width && args.matchPatterns[width] || args.matchPatterns[args.defaultMatchWidth];
    const matchResult = string.match(matchPattern);
    if (!matchResult) {
      return null;
    }
    const matchedString = matchResult[0];
    const parsePatterns = width && args.parsePatterns[width] || args.parsePatterns[args.defaultParseWidth];
    const key = Array.isArray(parsePatterns) ? findIndex(parsePatterns, pattern => pattern.test(matchedString)) : findKey(parsePatterns, pattern => pattern.test(matchedString));
    let value;
    value = args.valueCallback ? args.valueCallback(key) : key;
    value = options.valueCallback ? options.valueCallback(value) : value;
    const rest = string.slice(matchedString.length);
    return {
      value,
      rest
    };
  };
}
function findKey(object, predicate) {
  for (const key in object) {
    if (Object.prototype.hasOwnProperty.call(object, key) && predicate(object[key])) {
      return key;
    }
  }
  return void 0;
}
function findIndex(array, predicate) {
  for (let key = 0; key < array.length; key++) {
    if (predicate(array[key])) {
      return key;
    }
  }
  return void 0;
}

// node_modules/date-fns/locale/_lib/buildMatchPatternFn.mjs
function buildMatchPatternFn(args) {
  return (string, options = {}) => {
    const matchResult = string.match(args.matchPattern);
    if (!matchResult) return null;
    const matchedString = matchResult[0];
    const parseResult = string.match(args.parsePattern);
    if (!parseResult) return null;
    let value = args.valueCallback ? args.valueCallback(parseResult[0]) : parseResult[0];
    value = options.valueCallback ? options.valueCallback(value) : value;
    const rest = string.slice(matchedString.length);
    return {
      value,
      rest
    };
  };
}

// node_modules/date-fns/locale/it/_lib/match.mjs
var matchOrdinalNumberPattern = /^(\d+)(º)?/i;
var parseOrdinalNumberPattern = /\d+/i;
var matchEraPatterns = {
  narrow: /^(aC|dC)/i,
  abbreviated: /^(a\.?\s?C\.?|a\.?\s?e\.?\s?v\.?|d\.?\s?C\.?|e\.?\s?v\.?)/i,
  wide: /^(avanti Cristo|avanti Era Volgare|dopo Cristo|Era Volgare)/i
};
var parseEraPatterns = {
  any: [/^a/i, /^(d|e)/i]
};
var matchQuarterPatterns = {
  narrow: /^[1234]/i,
  abbreviated: /^t[1234]/i,
  wide: /^[1234](º)? trimestre/i
};
var parseQuarterPatterns = {
  any: [/1/i, /2/i, /3/i, /4/i]
};
var matchMonthPatterns = {
  narrow: /^[gfmalsond]/i,
  abbreviated: /^(gen|feb|mar|apr|mag|giu|lug|ago|set|ott|nov|dic)/i,
  wide: /^(gennaio|febbraio|marzo|aprile|maggio|giugno|luglio|agosto|settembre|ottobre|novembre|dicembre)/i
};
var parseMonthPatterns = {
  narrow: [/^g/i, /^f/i, /^m/i, /^a/i, /^m/i, /^g/i, /^l/i, /^a/i, /^s/i, /^o/i, /^n/i, /^d/i],
  any: [/^ge/i, /^f/i, /^mar/i, /^ap/i, /^mag/i, /^gi/i, /^l/i, /^ag/i, /^s/i, /^o/i, /^n/i, /^d/i]
};
var matchDayPatterns = {
  narrow: /^[dlmgvs]/i,
  short: /^(do|lu|ma|me|gi|ve|sa)/i,
  abbreviated: /^(dom|lun|mar|mer|gio|ven|sab)/i,
  wide: /^(domenica|luned[i|ì]|marted[i|ì]|mercoled[i|ì]|gioved[i|ì]|venerd[i|ì]|sabato)/i
};
var parseDayPatterns = {
  narrow: [/^d/i, /^l/i, /^m/i, /^m/i, /^g/i, /^v/i, /^s/i],
  any: [/^d/i, /^l/i, /^ma/i, /^me/i, /^g/i, /^v/i, /^s/i]
};
var matchDayPeriodPatterns = {
  narrow: /^(a|m\.|p|mezzanotte|mezzogiorno|(di|del) (mattina|pomeriggio|sera|notte))/i,
  any: /^([ap]\.?\s?m\.?|mezzanotte|mezzogiorno|(di|del) (mattina|pomeriggio|sera|notte))/i
};
var parseDayPeriodPatterns = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^mezza/i,
    noon: /^mezzo/i,
    morning: /mattina/i,
    afternoon: /pomeriggio/i,
    evening: /sera/i,
    night: /notte/i
  }
};
var match = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern,
    parsePattern: parseOrdinalNumberPattern,
    valueCallback: value => parseInt(value, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns,
    defaultParseWidth: "any",
    valueCallback: index => index + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns,
    defaultParseWidth: "any"
  })
};

// node_modules/date-fns/locale/it.mjs
var it = {
  code: "it",
  formatDistance,
  formatLong,
  formatRelative,
  localize,
  match,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
};
var it_default = it;

// .beyond/uimport/temp/date-fns/locale/it.3.6.0.js
var it_3_6_0_default = it_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL2xvY2FsZS9pdC4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9sb2NhbGUvaXQvX2xpYi9mb3JtYXREaXN0YW5jZS5tanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvbG9jYWxlL19saWIvYnVpbGRGb3JtYXRMb25nRm4ubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9pdC9fbGliL2Zvcm1hdExvbmcubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9pdC9fbGliL2Zvcm1hdFJlbGF0aXZlLm1qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9sb2NhbGUvX2xpYi9idWlsZExvY2FsaXplRm4ubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9pdC9fbGliL2xvY2FsaXplLm1qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9sb2NhbGUvX2xpYi9idWlsZE1hdGNoRm4ubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9fbGliL2J1aWxkTWF0Y2hQYXR0ZXJuRm4ubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL2xvY2FsZS9pdC9fbGliL21hdGNoLm1qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9sb2NhbGUvaXQubWpzIl0sIm5hbWVzIjpbIml0XzNfNl8wX2V4cG9ydHMiLCJfX2V4cG9ydCIsImRlZmF1bHQiLCJpdF8zXzZfMF9kZWZhdWx0IiwiaXQiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiZm9ybWF0RGlzdGFuY2VMb2NhbGUiLCJsZXNzVGhhblhTZWNvbmRzIiwib25lIiwib3RoZXIiLCJ4U2Vjb25kcyIsImhhbGZBTWludXRlIiwibGVzc1RoYW5YTWludXRlcyIsInhNaW51dGVzIiwiYWJvdXRYSG91cnMiLCJ4SG91cnMiLCJ4RGF5cyIsImFib3V0WFdlZWtzIiwieFdlZWtzIiwiYWJvdXRYTW9udGhzIiwieE1vbnRocyIsImFib3V0WFllYXJzIiwieFllYXJzIiwib3ZlclhZZWFycyIsImFsbW9zdFhZZWFycyIsImZvcm1hdERpc3RhbmNlIiwidG9rZW4iLCJjb3VudCIsIm9wdGlvbnMiLCJyZXN1bHQiLCJ0b2tlblZhbHVlIiwicmVwbGFjZSIsInRvU3RyaW5nIiwiYWRkU3VmZml4IiwiY29tcGFyaXNvbiIsImJ1aWxkRm9ybWF0TG9uZ0ZuIiwiYXJncyIsIndpZHRoIiwiU3RyaW5nIiwiZGVmYXVsdFdpZHRoIiwiZm9ybWF0IiwiZm9ybWF0cyIsImRhdGVGb3JtYXRzIiwiZnVsbCIsImxvbmciLCJtZWRpdW0iLCJzaG9ydCIsInRpbWVGb3JtYXRzIiwiZGF0ZVRpbWVGb3JtYXRzIiwiZm9ybWF0TG9uZyIsImRhdGUiLCJ0aW1lIiwiZGF0ZVRpbWUiLCJpbXBvcnRfaXNTYW1lV2VlayIsInJlcXVpcmUiLCJ3ZWVrZGF5cyIsImxhc3RXZWVrIiwiZGF5IiwidGhpc1dlZWsiLCJuZXh0V2VlayIsImZvcm1hdFJlbGF0aXZlTG9jYWxlIiwiYmFzZURhdGUiLCJnZXREYXkiLCJpc1NhbWVXZWVrIiwieWVzdGVyZGF5IiwidG9kYXkiLCJ0b21vcnJvdyIsImZvcm1hdFJlbGF0aXZlIiwiYnVpbGRMb2NhbGl6ZUZuIiwidmFsdWUiLCJjb250ZXh0IiwidmFsdWVzQXJyYXkiLCJmb3JtYXR0aW5nVmFsdWVzIiwiZGVmYXVsdEZvcm1hdHRpbmdXaWR0aCIsInZhbHVlcyIsImluZGV4IiwiYXJndW1lbnRDYWxsYmFjayIsImVyYVZhbHVlcyIsIm5hcnJvdyIsImFiYnJldmlhdGVkIiwid2lkZSIsInF1YXJ0ZXJWYWx1ZXMiLCJtb250aFZhbHVlcyIsImRheVZhbHVlcyIsImRheVBlcmlvZFZhbHVlcyIsImFtIiwicG0iLCJtaWRuaWdodCIsIm5vb24iLCJtb3JuaW5nIiwiYWZ0ZXJub29uIiwiZXZlbmluZyIsIm5pZ2h0IiwiZm9ybWF0dGluZ0RheVBlcmlvZFZhbHVlcyIsIm9yZGluYWxOdW1iZXIiLCJkaXJ0eU51bWJlciIsIl9vcHRpb25zIiwibnVtYmVyIiwiTnVtYmVyIiwibG9jYWxpemUiLCJlcmEiLCJxdWFydGVyIiwibW9udGgiLCJkYXlQZXJpb2QiLCJidWlsZE1hdGNoRm4iLCJzdHJpbmciLCJtYXRjaFBhdHRlcm4iLCJtYXRjaFBhdHRlcm5zIiwiZGVmYXVsdE1hdGNoV2lkdGgiLCJtYXRjaFJlc3VsdCIsIm1hdGNoIiwibWF0Y2hlZFN0cmluZyIsInBhcnNlUGF0dGVybnMiLCJkZWZhdWx0UGFyc2VXaWR0aCIsImtleSIsIkFycmF5IiwiaXNBcnJheSIsImZpbmRJbmRleCIsInBhdHRlcm4iLCJ0ZXN0IiwiZmluZEtleSIsInZhbHVlQ2FsbGJhY2siLCJyZXN0Iiwic2xpY2UiLCJsZW5ndGgiLCJvYmplY3QiLCJwcmVkaWNhdGUiLCJPYmplY3QiLCJwcm90b3R5cGUiLCJoYXNPd25Qcm9wZXJ0eSIsImNhbGwiLCJhcnJheSIsImJ1aWxkTWF0Y2hQYXR0ZXJuRm4iLCJwYXJzZVJlc3VsdCIsInBhcnNlUGF0dGVybiIsIm1hdGNoT3JkaW5hbE51bWJlclBhdHRlcm4iLCJwYXJzZU9yZGluYWxOdW1iZXJQYXR0ZXJuIiwibWF0Y2hFcmFQYXR0ZXJucyIsInBhcnNlRXJhUGF0dGVybnMiLCJhbnkiLCJtYXRjaFF1YXJ0ZXJQYXR0ZXJucyIsInBhcnNlUXVhcnRlclBhdHRlcm5zIiwibWF0Y2hNb250aFBhdHRlcm5zIiwicGFyc2VNb250aFBhdHRlcm5zIiwibWF0Y2hEYXlQYXR0ZXJucyIsInBhcnNlRGF5UGF0dGVybnMiLCJtYXRjaERheVBlcmlvZFBhdHRlcm5zIiwicGFyc2VEYXlQZXJpb2RQYXR0ZXJucyIsInBhcnNlSW50IiwiY29kZSIsIndlZWtTdGFydHNPbiIsImZpcnN0V2Vla0NvbnRhaW5zRGF0ZSIsIml0X2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLGdCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsZ0JBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLGdCQUFBO0VBQUFDLEVBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLGdCQUFBOzs7QUNBQSxJQUFNUSxvQkFBQSxHQUF1QjtFQUMzQkMsZ0JBQUEsRUFBa0I7SUFDaEJDLEdBQUEsRUFBSztJQUNMQyxLQUFBLEVBQU87RUFDVDtFQUVBQyxRQUFBLEVBQVU7SUFDUkYsR0FBQSxFQUFLO0lBQ0xDLEtBQUEsRUFBTztFQUNUO0VBRUFFLFdBQUEsRUFBYTtFQUViQyxnQkFBQSxFQUFrQjtJQUNoQkosR0FBQSxFQUFLO0lBQ0xDLEtBQUEsRUFBTztFQUNUO0VBRUFJLFFBQUEsRUFBVTtJQUNSTCxHQUFBLEVBQUs7SUFDTEMsS0FBQSxFQUFPO0VBQ1Q7RUFFQUssV0FBQSxFQUFhO0lBQ1hOLEdBQUEsRUFBSztJQUNMQyxLQUFBLEVBQU87RUFDVDtFQUVBTSxNQUFBLEVBQVE7SUFDTlAsR0FBQSxFQUFLO0lBQ0xDLEtBQUEsRUFBTztFQUNUO0VBRUFPLEtBQUEsRUFBTztJQUNMUixHQUFBLEVBQUs7SUFDTEMsS0FBQSxFQUFPO0VBQ1Q7RUFFQVEsV0FBQSxFQUFhO0lBQ1hULEdBQUEsRUFBSztJQUNMQyxLQUFBLEVBQU87RUFDVDtFQUVBUyxNQUFBLEVBQVE7SUFDTlYsR0FBQSxFQUFLO0lBQ0xDLEtBQUEsRUFBTztFQUNUO0VBRUFVLFlBQUEsRUFBYztJQUNaWCxHQUFBLEVBQUs7SUFDTEMsS0FBQSxFQUFPO0VBQ1Q7RUFFQVcsT0FBQSxFQUFTO0lBQ1BaLEdBQUEsRUFBSztJQUNMQyxLQUFBLEVBQU87RUFDVDtFQUVBWSxXQUFBLEVBQWE7SUFDWGIsR0FBQSxFQUFLO0lBQ0xDLEtBQUEsRUFBTztFQUNUO0VBRUFhLE1BQUEsRUFBUTtJQUNOZCxHQUFBLEVBQUs7SUFDTEMsS0FBQSxFQUFPO0VBQ1Q7RUFFQWMsVUFBQSxFQUFZO0lBQ1ZmLEdBQUEsRUFBSztJQUNMQyxLQUFBLEVBQU87RUFDVDtFQUVBZSxZQUFBLEVBQWM7SUFDWmhCLEdBQUEsRUFBSztJQUNMQyxLQUFBLEVBQU87RUFDVDtBQUNGO0FBRU8sSUFBTWdCLGNBQUEsR0FBaUJBLENBQUNDLEtBQUEsRUFBT0MsS0FBQSxFQUFPQyxPQUFBLEtBQVk7RUFDdkQsSUFBSUMsTUFBQTtFQUVKLE1BQU1DLFVBQUEsR0FBYXhCLG9CQUFBLENBQXFCb0IsS0FBQTtFQUN4QyxJQUFJLE9BQU9JLFVBQUEsS0FBZSxVQUFVO0lBQ2xDRCxNQUFBLEdBQVNDLFVBQUE7RUFDWCxXQUFXSCxLQUFBLEtBQVUsR0FBRztJQUN0QkUsTUFBQSxHQUFTQyxVQUFBLENBQVd0QixHQUFBO0VBQ3RCLE9BQU87SUFDTHFCLE1BQUEsR0FBU0MsVUFBQSxDQUFXckIsS0FBQSxDQUFNc0IsT0FBQSxDQUFRLGFBQWFKLEtBQUEsQ0FBTUssUUFBQSxDQUFTLENBQUM7RUFDakU7RUFFQSxJQUFJSixPQUFBLEVBQVNLLFNBQUEsRUFBVztJQUN0QixJQUFJTCxPQUFBLENBQVFNLFVBQUEsSUFBY04sT0FBQSxDQUFRTSxVQUFBLEdBQWEsR0FBRztNQUNoRCxPQUFPLFNBQVNMLE1BQUE7SUFDbEIsT0FBTztNQUNMLE9BQU9BLE1BQUEsR0FBUztJQUNsQjtFQUNGO0VBRUEsT0FBT0EsTUFBQTtBQUNUOzs7QUNwR08sU0FBU00sa0JBQWtCQyxJQUFBLEVBQU07RUFDdEMsT0FBTyxDQUFDUixPQUFBLEdBQVUsQ0FBQyxNQUFNO0lBRXZCLE1BQU1TLEtBQUEsR0FBUVQsT0FBQSxDQUFRUyxLQUFBLEdBQVFDLE1BQUEsQ0FBT1YsT0FBQSxDQUFRUyxLQUFLLElBQUlELElBQUEsQ0FBS0csWUFBQTtJQUMzRCxNQUFNQyxNQUFBLEdBQVNKLElBQUEsQ0FBS0ssT0FBQSxDQUFRSixLQUFBLEtBQVVELElBQUEsQ0FBS0ssT0FBQSxDQUFRTCxJQUFBLENBQUtHLFlBQUE7SUFDeEQsT0FBT0MsTUFBQTtFQUNUO0FBQ0Y7OztBQ0xBLElBQU1FLFdBQUEsR0FBYztFQUNsQkMsSUFBQSxFQUFNO0VBQ05DLElBQUEsRUFBTTtFQUNOQyxNQUFBLEVBQVE7RUFDUkMsS0FBQSxFQUFPO0FBQ1Q7QUFFQSxJQUFNQyxXQUFBLEdBQWM7RUFDbEJKLElBQUEsRUFBTTtFQUNOQyxJQUFBLEVBQU07RUFDTkMsTUFBQSxFQUFRO0VBQ1JDLEtBQUEsRUFBTztBQUNUO0FBRUEsSUFBTUUsZUFBQSxHQUFrQjtFQUN0QkwsSUFBQSxFQUFNO0VBQ05DLElBQUEsRUFBTTtFQUNOQyxNQUFBLEVBQVE7RUFDUkMsS0FBQSxFQUFPO0FBQ1Q7QUFFTyxJQUFNRyxVQUFBLEdBQWE7RUFDeEJDLElBQUEsRUFBTWYsaUJBQUEsQ0FBa0I7SUFDdEJNLE9BQUEsRUFBU0MsV0FBQTtJQUNUSCxZQUFBLEVBQWM7RUFDaEIsQ0FBQztFQUVEWSxJQUFBLEVBQU1oQixpQkFBQSxDQUFrQjtJQUN0Qk0sT0FBQSxFQUFTTSxXQUFBO0lBQ1RSLFlBQUEsRUFBYztFQUNoQixDQUFDO0VBRURhLFFBQUEsRUFBVWpCLGlCQUFBLENBQWtCO0lBQzFCTSxPQUFBLEVBQVNPLGVBQUE7SUFDVFQsWUFBQSxFQUFjO0VBQ2hCLENBQUM7QUFDSDs7O0FDdENBLElBQUFjLGlCQUFBLEdBQTJCQyxPQUFBO0FBRTNCLElBQU1DLFFBQUEsR0FBVyxDQUNmLFlBQ0EsYUFDQSxjQUNBLGdCQUNBLGNBQ0EsY0FDQSxTQUNGO0FBRUEsU0FBU0MsU0FBU0MsR0FBQSxFQUFLO0VBQ3JCLFFBQVFBLEdBQUE7SUFBQSxLQUNEO01BQ0gsT0FBTztJQUFBO01BRVAsT0FBTyxNQUFNRixRQUFBLENBQVNFLEdBQUEsSUFBTztFQUFBO0FBRW5DO0FBRUEsU0FBU0MsU0FBU0QsR0FBQSxFQUFLO0VBQ3JCLE9BQU8sTUFBTUYsUUFBQSxDQUFTRSxHQUFBLElBQU87QUFDL0I7QUFFQSxTQUFTRSxTQUFTRixHQUFBLEVBQUs7RUFDckIsUUFBUUEsR0FBQTtJQUFBLEtBQ0Q7TUFDSCxPQUFPO0lBQUE7TUFFUCxPQUFPLE1BQU1GLFFBQUEsQ0FBU0UsR0FBQSxJQUFPO0VBQUE7QUFFbkM7QUFFQSxJQUFNRyxvQkFBQSxHQUF1QjtFQUMzQkosUUFBQSxFQUFVQSxDQUFDTixJQUFBLEVBQU1XLFFBQUEsRUFBVWpDLE9BQUEsS0FBWTtJQUNyQyxNQUFNNkIsR0FBQSxHQUFNUCxJQUFBLENBQUtZLE1BQUEsQ0FBTztJQUN4QixRQUFJVCxpQkFBQSxDQUFBVSxVQUFBLEVBQVdiLElBQUEsRUFBTVcsUUFBQSxFQUFVakMsT0FBTyxHQUFHO01BQ3ZDLE9BQU84QixRQUFBLENBQVNELEdBQUc7SUFDckIsT0FBTztNQUNMLE9BQU9ELFFBQUEsQ0FBU0MsR0FBRztJQUNyQjtFQUNGO0VBQ0FPLFNBQUEsRUFBVztFQUNYQyxLQUFBLEVBQU87RUFDUEMsUUFBQSxFQUFVO0VBQ1ZQLFFBQUEsRUFBVUEsQ0FBQ1QsSUFBQSxFQUFNVyxRQUFBLEVBQVVqQyxPQUFBLEtBQVk7SUFDckMsTUFBTTZCLEdBQUEsR0FBTVAsSUFBQSxDQUFLWSxNQUFBLENBQU87SUFDeEIsUUFBSVQsaUJBQUEsQ0FBQVUsVUFBQSxFQUFXYixJQUFBLEVBQU1XLFFBQUEsRUFBVWpDLE9BQU8sR0FBRztNQUN2QyxPQUFPOEIsUUFBQSxDQUFTRCxHQUFHO0lBQ3JCLE9BQU87TUFDTCxPQUFPRSxRQUFBLENBQVNGLEdBQUc7SUFDckI7RUFDRjtFQUNBaEQsS0FBQSxFQUFPO0FBQ1Q7QUFFTyxJQUFNMEQsY0FBQSxHQUFpQkEsQ0FBQ3pDLEtBQUEsRUFBT3dCLElBQUEsRUFBTVcsUUFBQSxFQUFVakMsT0FBQSxLQUFZO0VBQ2hFLE1BQU1ZLE1BQUEsR0FBU29CLG9CQUFBLENBQXFCbEMsS0FBQTtFQUVwQyxJQUFJLE9BQU9jLE1BQUEsS0FBVyxZQUFZO0lBQ2hDLE9BQU9BLE1BQUEsQ0FBT1UsSUFBQSxFQUFNVyxRQUFBLEVBQVVqQyxPQUFPO0VBQ3ZDO0VBRUEsT0FBT1ksTUFBQTtBQUNUOzs7QUN4Qk8sU0FBUzRCLGdCQUFnQmhDLElBQUEsRUFBTTtFQUNwQyxPQUFPLENBQUNpQyxLQUFBLEVBQU96QyxPQUFBLEtBQVk7SUFDekIsTUFBTTBDLE9BQUEsR0FBVTFDLE9BQUEsRUFBUzBDLE9BQUEsR0FBVWhDLE1BQUEsQ0FBT1YsT0FBQSxDQUFRMEMsT0FBTyxJQUFJO0lBRTdELElBQUlDLFdBQUE7SUFDSixJQUFJRCxPQUFBLEtBQVksZ0JBQWdCbEMsSUFBQSxDQUFLb0MsZ0JBQUEsRUFBa0I7TUFDckQsTUFBTWpDLFlBQUEsR0FBZUgsSUFBQSxDQUFLcUMsc0JBQUEsSUFBMEJyQyxJQUFBLENBQUtHLFlBQUE7TUFDekQsTUFBTUYsS0FBQSxHQUFRVCxPQUFBLEVBQVNTLEtBQUEsR0FBUUMsTUFBQSxDQUFPVixPQUFBLENBQVFTLEtBQUssSUFBSUUsWUFBQTtNQUV2RGdDLFdBQUEsR0FDRW5DLElBQUEsQ0FBS29DLGdCQUFBLENBQWlCbkMsS0FBQSxLQUFVRCxJQUFBLENBQUtvQyxnQkFBQSxDQUFpQmpDLFlBQUE7SUFDMUQsT0FBTztNQUNMLE1BQU1BLFlBQUEsR0FBZUgsSUFBQSxDQUFLRyxZQUFBO01BQzFCLE1BQU1GLEtBQUEsR0FBUVQsT0FBQSxFQUFTUyxLQUFBLEdBQVFDLE1BQUEsQ0FBT1YsT0FBQSxDQUFRUyxLQUFLLElBQUlELElBQUEsQ0FBS0csWUFBQTtNQUU1RGdDLFdBQUEsR0FBY25DLElBQUEsQ0FBS3NDLE1BQUEsQ0FBT3JDLEtBQUEsS0FBVUQsSUFBQSxDQUFLc0MsTUFBQSxDQUFPbkMsWUFBQTtJQUNsRDtJQUNBLE1BQU1vQyxLQUFBLEdBQVF2QyxJQUFBLENBQUt3QyxnQkFBQSxHQUFtQnhDLElBQUEsQ0FBS3dDLGdCQUFBLENBQWlCUCxLQUFLLElBQUlBLEtBQUE7SUFHckUsT0FBT0UsV0FBQSxDQUFZSSxLQUFBO0VBQ3JCO0FBQ0Y7OztBQzdEQSxJQUFNRSxTQUFBLEdBQVk7RUFDaEJDLE1BQUEsRUFBUSxDQUFDLE1BQU0sSUFBSTtFQUNuQkMsV0FBQSxFQUFhLENBQUMsUUFBUSxNQUFNO0VBQzVCQyxJQUFBLEVBQU0sQ0FBQyxpQkFBaUIsYUFBYTtBQUN2QztBQUVBLElBQU1DLGFBQUEsR0FBZ0I7RUFDcEJILE1BQUEsRUFBUSxDQUFDLEtBQUssS0FBSyxLQUFLLEdBQUc7RUFDM0JDLFdBQUEsRUFBYSxDQUFDLE1BQU0sTUFBTSxNQUFNLElBQUk7RUFDcENDLElBQUEsRUFBTSxDQUFDLG1CQUFnQixtQkFBZ0IsbUJBQWdCLGlCQUFjO0FBQ3ZFO0FBRUEsSUFBTUUsV0FBQSxHQUFjO0VBQ2xCSixNQUFBLEVBQVEsQ0FBQyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssR0FBRztFQUNuRUMsV0FBQSxFQUFhLENBQ1gsT0FDQSxPQUNBLE9BQ0EsT0FDQSxPQUNBLE9BQ0EsT0FDQSxPQUNBLE9BQ0EsT0FDQSxPQUNBLE1BQ0Y7RUFFQUMsSUFBQSxFQUFNLENBQ0osV0FDQSxZQUNBLFNBQ0EsVUFDQSxVQUNBLFVBQ0EsVUFDQSxVQUNBLGFBQ0EsV0FDQSxZQUNBO0FBRUo7QUFFQSxJQUFNRyxTQUFBLEdBQVk7RUFDaEJMLE1BQUEsRUFBUSxDQUFDLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEdBQUc7RUFDMUNoQyxLQUFBLEVBQU8sQ0FBQyxPQUFPLE9BQU8sT0FBTyxPQUFPLE9BQU8sT0FBTyxLQUFLO0VBQ3ZEaUMsV0FBQSxFQUFhLENBQUMsT0FBTyxPQUFPLE9BQU8sT0FBTyxPQUFPLE9BQU8sS0FBSztFQUM3REMsSUFBQSxFQUFNLENBQ0osWUFDQSxhQUNBLGNBQ0EsZ0JBQ0EsY0FDQSxjQUNBO0FBRUo7QUFFQSxJQUFNSSxlQUFBLEdBQWtCO0VBQ3RCTixNQUFBLEVBQVE7SUFDTk8sRUFBQSxFQUFJO0lBQ0pDLEVBQUEsRUFBSTtJQUNKQyxRQUFBLEVBQVU7SUFDVkMsSUFBQSxFQUFNO0lBQ05DLE9BQUEsRUFBUztJQUNUQyxTQUFBLEVBQVc7SUFDWEMsT0FBQSxFQUFTO0lBQ1RDLEtBQUEsRUFBTztFQUNUO0VBQ0FiLFdBQUEsRUFBYTtJQUNYTSxFQUFBLEVBQUk7SUFDSkMsRUFBQSxFQUFJO0lBQ0pDLFFBQUEsRUFBVTtJQUNWQyxJQUFBLEVBQU07SUFDTkMsT0FBQSxFQUFTO0lBQ1RDLFNBQUEsRUFBVztJQUNYQyxPQUFBLEVBQVM7SUFDVEMsS0FBQSxFQUFPO0VBQ1Q7RUFDQVosSUFBQSxFQUFNO0lBQ0pLLEVBQUEsRUFBSTtJQUNKQyxFQUFBLEVBQUk7SUFDSkMsUUFBQSxFQUFVO0lBQ1ZDLElBQUEsRUFBTTtJQUNOQyxPQUFBLEVBQVM7SUFDVEMsU0FBQSxFQUFXO0lBQ1hDLE9BQUEsRUFBUztJQUNUQyxLQUFBLEVBQU87RUFDVDtBQUNGO0FBRUEsSUFBTUMseUJBQUEsR0FBNEI7RUFDaENmLE1BQUEsRUFBUTtJQUNOTyxFQUFBLEVBQUk7SUFDSkMsRUFBQSxFQUFJO0lBQ0pDLFFBQUEsRUFBVTtJQUNWQyxJQUFBLEVBQU07SUFDTkMsT0FBQSxFQUFTO0lBQ1RDLFNBQUEsRUFBVztJQUNYQyxPQUFBLEVBQVM7SUFDVEMsS0FBQSxFQUFPO0VBQ1Q7RUFDQWIsV0FBQSxFQUFhO0lBQ1hNLEVBQUEsRUFBSTtJQUNKQyxFQUFBLEVBQUk7SUFDSkMsUUFBQSxFQUFVO0lBQ1ZDLElBQUEsRUFBTTtJQUNOQyxPQUFBLEVBQVM7SUFDVEMsU0FBQSxFQUFXO0lBQ1hDLE9BQUEsRUFBUztJQUNUQyxLQUFBLEVBQU87RUFDVDtFQUNBWixJQUFBLEVBQU07SUFDSkssRUFBQSxFQUFJO0lBQ0pDLEVBQUEsRUFBSTtJQUNKQyxRQUFBLEVBQVU7SUFDVkMsSUFBQSxFQUFNO0lBQ05DLE9BQUEsRUFBUztJQUNUQyxTQUFBLEVBQVc7SUFDWEMsT0FBQSxFQUFTO0lBQ1RDLEtBQUEsRUFBTztFQUNUO0FBQ0Y7QUFFQSxJQUFNRSxhQUFBLEdBQWdCQSxDQUFDQyxXQUFBLEVBQWFDLFFBQUEsS0FBYTtFQUMvQyxNQUFNQyxNQUFBLEdBQVNDLE1BQUEsQ0FBT0gsV0FBVztFQUNqQyxPQUFPekQsTUFBQSxDQUFPMkQsTUFBTTtBQUN0QjtBQUVPLElBQU1FLFFBQUEsR0FBVztFQUN0QkwsYUFBQTtFQUVBTSxHQUFBLEVBQUtoQyxlQUFBLENBQWdCO0lBQ25CTSxNQUFBLEVBQVFHLFNBQUE7SUFDUnRDLFlBQUEsRUFBYztFQUNoQixDQUFDO0VBRUQ4RCxPQUFBLEVBQVNqQyxlQUFBLENBQWdCO0lBQ3ZCTSxNQUFBLEVBQVFPLGFBQUE7SUFDUjFDLFlBQUEsRUFBYztJQUNkcUMsZ0JBQUEsRUFBbUJ5QixPQUFBLElBQVlBLE9BQUEsR0FBVTtFQUMzQyxDQUFDO0VBRURDLEtBQUEsRUFBT2xDLGVBQUEsQ0FBZ0I7SUFDckJNLE1BQUEsRUFBUVEsV0FBQTtJQUNSM0MsWUFBQSxFQUFjO0VBQ2hCLENBQUM7RUFFRGtCLEdBQUEsRUFBS1csZUFBQSxDQUFnQjtJQUNuQk0sTUFBQSxFQUFRUyxTQUFBO0lBQ1I1QyxZQUFBLEVBQWM7RUFDaEIsQ0FBQztFQUVEZ0UsU0FBQSxFQUFXbkMsZUFBQSxDQUFnQjtJQUN6Qk0sTUFBQSxFQUFRVSxlQUFBO0lBQ1I3QyxZQUFBLEVBQWM7SUFDZGlDLGdCQUFBLEVBQWtCcUIseUJBQUE7SUFDbEJwQixzQkFBQSxFQUF3QjtFQUMxQixDQUFDO0FBQ0g7OztBQ25LTyxTQUFTK0IsYUFBYXBFLElBQUEsRUFBTTtFQUNqQyxPQUFPLENBQUNxRSxNQUFBLEVBQVE3RSxPQUFBLEdBQVUsQ0FBQyxNQUFNO0lBQy9CLE1BQU1TLEtBQUEsR0FBUVQsT0FBQSxDQUFRUyxLQUFBO0lBRXRCLE1BQU1xRSxZQUFBLEdBQ0hyRSxLQUFBLElBQVNELElBQUEsQ0FBS3VFLGFBQUEsQ0FBY3RFLEtBQUEsS0FDN0JELElBQUEsQ0FBS3VFLGFBQUEsQ0FBY3ZFLElBQUEsQ0FBS3dFLGlCQUFBO0lBQzFCLE1BQU1DLFdBQUEsR0FBY0osTUFBQSxDQUFPSyxLQUFBLENBQU1KLFlBQVk7SUFFN0MsSUFBSSxDQUFDRyxXQUFBLEVBQWE7TUFDaEIsT0FBTztJQUNUO0lBQ0EsTUFBTUUsYUFBQSxHQUFnQkYsV0FBQSxDQUFZO0lBRWxDLE1BQU1HLGFBQUEsR0FDSDNFLEtBQUEsSUFBU0QsSUFBQSxDQUFLNEUsYUFBQSxDQUFjM0UsS0FBQSxLQUM3QkQsSUFBQSxDQUFLNEUsYUFBQSxDQUFjNUUsSUFBQSxDQUFLNkUsaUJBQUE7SUFFMUIsTUFBTUMsR0FBQSxHQUFNQyxLQUFBLENBQU1DLE9BQUEsQ0FBUUosYUFBYSxJQUNuQ0ssU0FBQSxDQUFVTCxhQUFBLEVBQWdCTSxPQUFBLElBQVlBLE9BQUEsQ0FBUUMsSUFBQSxDQUFLUixhQUFhLENBQUMsSUFFakVTLE9BQUEsQ0FBUVIsYUFBQSxFQUFnQk0sT0FBQSxJQUFZQSxPQUFBLENBQVFDLElBQUEsQ0FBS1IsYUFBYSxDQUFDO0lBRW5FLElBQUkxQyxLQUFBO0lBRUpBLEtBQUEsR0FBUWpDLElBQUEsQ0FBS3FGLGFBQUEsR0FBZ0JyRixJQUFBLENBQUtxRixhQUFBLENBQWNQLEdBQUcsSUFBSUEsR0FBQTtJQUN2RDdDLEtBQUEsR0FBUXpDLE9BQUEsQ0FBUTZGLGFBQUEsR0FFWjdGLE9BQUEsQ0FBUTZGLGFBQUEsQ0FBY3BELEtBQUssSUFDM0JBLEtBQUE7SUFFSixNQUFNcUQsSUFBQSxHQUFPakIsTUFBQSxDQUFPa0IsS0FBQSxDQUFNWixhQUFBLENBQWNhLE1BQU07SUFFOUMsT0FBTztNQUFFdkQsS0FBQTtNQUFPcUQ7SUFBSztFQUN2QjtBQUNGO0FBRUEsU0FBU0YsUUFBUUssTUFBQSxFQUFRQyxTQUFBLEVBQVc7RUFDbEMsV0FBV1osR0FBQSxJQUFPVyxNQUFBLEVBQVE7SUFDeEIsSUFDRUUsTUFBQSxDQUFPQyxTQUFBLENBQVVDLGNBQUEsQ0FBZUMsSUFBQSxDQUFLTCxNQUFBLEVBQVFYLEdBQUcsS0FDaERZLFNBQUEsQ0FBVUQsTUFBQSxDQUFPWCxHQUFBLENBQUksR0FDckI7TUFDQSxPQUFPQSxHQUFBO0lBQ1Q7RUFDRjtFQUNBLE9BQU87QUFDVDtBQUVBLFNBQVNHLFVBQVVjLEtBQUEsRUFBT0wsU0FBQSxFQUFXO0VBQ25DLFNBQVNaLEdBQUEsR0FBTSxHQUFHQSxHQUFBLEdBQU1pQixLQUFBLENBQU1QLE1BQUEsRUFBUVYsR0FBQSxJQUFPO0lBQzNDLElBQUlZLFNBQUEsQ0FBVUssS0FBQSxDQUFNakIsR0FBQSxDQUFJLEdBQUc7TUFDekIsT0FBT0EsR0FBQTtJQUNUO0VBQ0Y7RUFDQSxPQUFPO0FBQ1Q7OztBQ3hETyxTQUFTa0Isb0JBQW9CaEcsSUFBQSxFQUFNO0VBQ3hDLE9BQU8sQ0FBQ3FFLE1BQUEsRUFBUTdFLE9BQUEsR0FBVSxDQUFDLE1BQU07SUFDL0IsTUFBTWlGLFdBQUEsR0FBY0osTUFBQSxDQUFPSyxLQUFBLENBQU0xRSxJQUFBLENBQUtzRSxZQUFZO0lBQ2xELElBQUksQ0FBQ0csV0FBQSxFQUFhLE9BQU87SUFDekIsTUFBTUUsYUFBQSxHQUFnQkYsV0FBQSxDQUFZO0lBRWxDLE1BQU13QixXQUFBLEdBQWM1QixNQUFBLENBQU9LLEtBQUEsQ0FBTTFFLElBQUEsQ0FBS2tHLFlBQVk7SUFDbEQsSUFBSSxDQUFDRCxXQUFBLEVBQWEsT0FBTztJQUN6QixJQUFJaEUsS0FBQSxHQUFRakMsSUFBQSxDQUFLcUYsYUFBQSxHQUNickYsSUFBQSxDQUFLcUYsYUFBQSxDQUFjWSxXQUFBLENBQVksRUFBRSxJQUNqQ0EsV0FBQSxDQUFZO0lBR2hCaEUsS0FBQSxHQUFRekMsT0FBQSxDQUFRNkYsYUFBQSxHQUFnQjdGLE9BQUEsQ0FBUTZGLGFBQUEsQ0FBY3BELEtBQUssSUFBSUEsS0FBQTtJQUUvRCxNQUFNcUQsSUFBQSxHQUFPakIsTUFBQSxDQUFPa0IsS0FBQSxDQUFNWixhQUFBLENBQWNhLE1BQU07SUFFOUMsT0FBTztNQUFFdkQsS0FBQTtNQUFPcUQ7SUFBSztFQUN2QjtBQUNGOzs7QUNoQkEsSUFBTWEseUJBQUEsR0FBNEI7QUFDbEMsSUFBTUMseUJBQUEsR0FBNEI7QUFFbEMsSUFBTUMsZ0JBQUEsR0FBbUI7RUFDdkIzRCxNQUFBLEVBQVE7RUFDUkMsV0FBQSxFQUFhO0VBQ2JDLElBQUEsRUFBTTtBQUNSO0FBQ0EsSUFBTTBELGdCQUFBLEdBQW1CO0VBQ3ZCQyxHQUFBLEVBQUssQ0FBQyxPQUFPLFNBQVM7QUFDeEI7QUFFQSxJQUFNQyxvQkFBQSxHQUF1QjtFQUMzQjlELE1BQUEsRUFBUTtFQUNSQyxXQUFBLEVBQWE7RUFDYkMsSUFBQSxFQUFNO0FBQ1I7QUFDQSxJQUFNNkQsb0JBQUEsR0FBdUI7RUFDM0JGLEdBQUEsRUFBSyxDQUFDLE1BQU0sTUFBTSxNQUFNLElBQUk7QUFDOUI7QUFFQSxJQUFNRyxrQkFBQSxHQUFxQjtFQUN6QmhFLE1BQUEsRUFBUTtFQUNSQyxXQUFBLEVBQWE7RUFDYkMsSUFBQSxFQUFNO0FBQ1I7QUFDQSxJQUFNK0Qsa0JBQUEsR0FBcUI7RUFDekJqRSxNQUFBLEVBQVEsQ0FDTixPQUNBLE9BQ0EsT0FDQSxPQUNBLE9BQ0EsT0FDQSxPQUNBLE9BQ0EsT0FDQSxPQUNBLE9BQ0EsTUFDRjtFQUVBNkQsR0FBQSxFQUFLLENBQ0gsUUFDQSxPQUNBLFNBQ0EsUUFDQSxTQUNBLFFBQ0EsT0FDQSxRQUNBLE9BQ0EsT0FDQSxPQUNBO0FBRUo7QUFFQSxJQUFNSyxnQkFBQSxHQUFtQjtFQUN2QmxFLE1BQUEsRUFBUTtFQUNSaEMsS0FBQSxFQUFPO0VBQ1BpQyxXQUFBLEVBQWE7RUFDYkMsSUFBQSxFQUFNO0FBQ1I7QUFDQSxJQUFNaUUsZ0JBQUEsR0FBbUI7RUFDdkJuRSxNQUFBLEVBQVEsQ0FBQyxPQUFPLE9BQU8sT0FBTyxPQUFPLE9BQU8sT0FBTyxLQUFLO0VBQ3hENkQsR0FBQSxFQUFLLENBQUMsT0FBTyxPQUFPLFFBQVEsUUFBUSxPQUFPLE9BQU8sS0FBSztBQUN6RDtBQUVBLElBQU1PLHNCQUFBLEdBQXlCO0VBQzdCcEUsTUFBQSxFQUNFO0VBQ0Y2RCxHQUFBLEVBQUs7QUFDUDtBQUNBLElBQU1RLHNCQUFBLEdBQXlCO0VBQzdCUixHQUFBLEVBQUs7SUFDSHRELEVBQUEsRUFBSTtJQUNKQyxFQUFBLEVBQUk7SUFDSkMsUUFBQSxFQUFVO0lBQ1ZDLElBQUEsRUFBTTtJQUNOQyxPQUFBLEVBQVM7SUFDVEMsU0FBQSxFQUFXO0lBQ1hDLE9BQUEsRUFBUztJQUNUQyxLQUFBLEVBQU87RUFDVDtBQUNGO0FBRU8sSUFBTWtCLEtBQUEsR0FBUTtFQUNuQmhCLGFBQUEsRUFBZXNDLG1CQUFBLENBQW9CO0lBQ2pDMUIsWUFBQSxFQUFjNkIseUJBQUE7SUFDZEQsWUFBQSxFQUFjRSx5QkFBQTtJQUNkZixhQUFBLEVBQWdCcEQsS0FBQSxJQUFVK0UsUUFBQSxDQUFTL0UsS0FBQSxFQUFPLEVBQUU7RUFDOUMsQ0FBQztFQUVEK0IsR0FBQSxFQUFLSSxZQUFBLENBQWE7SUFDaEJHLGFBQUEsRUFBZThCLGdCQUFBO0lBQ2Y3QixpQkFBQSxFQUFtQjtJQUNuQkksYUFBQSxFQUFlMEIsZ0JBQUE7SUFDZnpCLGlCQUFBLEVBQW1CO0VBQ3JCLENBQUM7RUFFRFosT0FBQSxFQUFTRyxZQUFBLENBQWE7SUFDcEJHLGFBQUEsRUFBZWlDLG9CQUFBO0lBQ2ZoQyxpQkFBQSxFQUFtQjtJQUNuQkksYUFBQSxFQUFlNkIsb0JBQUE7SUFDZjVCLGlCQUFBLEVBQW1CO0lBQ25CUSxhQUFBLEVBQWdCOUMsS0FBQSxJQUFVQSxLQUFBLEdBQVE7RUFDcEMsQ0FBQztFQUVEMkIsS0FBQSxFQUFPRSxZQUFBLENBQWE7SUFDbEJHLGFBQUEsRUFBZW1DLGtCQUFBO0lBQ2ZsQyxpQkFBQSxFQUFtQjtJQUNuQkksYUFBQSxFQUFlK0Isa0JBQUE7SUFDZjlCLGlCQUFBLEVBQW1CO0VBQ3JCLENBQUM7RUFFRHhELEdBQUEsRUFBSytDLFlBQUEsQ0FBYTtJQUNoQkcsYUFBQSxFQUFlcUMsZ0JBQUE7SUFDZnBDLGlCQUFBLEVBQW1CO0lBQ25CSSxhQUFBLEVBQWVpQyxnQkFBQTtJQUNmaEMsaUJBQUEsRUFBbUI7RUFDckIsQ0FBQztFQUVEVixTQUFBLEVBQVdDLFlBQUEsQ0FBYTtJQUN0QkcsYUFBQSxFQUFldUMsc0JBQUE7SUFDZnRDLGlCQUFBLEVBQW1CO0lBQ25CSSxhQUFBLEVBQWVtQyxzQkFBQTtJQUNmbEMsaUJBQUEsRUFBbUI7RUFDckIsQ0FBQztBQUNIOzs7QUNySE8sSUFBTS9HLEVBQUEsR0FBSztFQUNoQm1KLElBQUEsRUFBTTtFQUNONUgsY0FBQTtFQUNBd0IsVUFBQTtFQUNBa0IsY0FBQTtFQUNBZ0MsUUFBQTtFQUNBVyxLQUFBO0VBQ0FsRixPQUFBLEVBQVM7SUFDUDBILFlBQUEsRUFBYztJQUNkQyxxQkFBQSxFQUF1QjtFQUN6QjtBQUNGO0FBR0EsSUFBT0MsVUFBQSxHQUFRdEosRUFBQTs7O0FWMUJmLElBQU9ELGdCQUFBLEdBQVF1SixVQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9