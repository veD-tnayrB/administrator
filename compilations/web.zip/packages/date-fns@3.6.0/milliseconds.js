System.register(["date-fns@3.6.0/constants"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constants', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/milliseconds.3.6.0.js
var milliseconds_3_6_0_exports = {};
__export(milliseconds_3_6_0_exports, {
  default: () => milliseconds_3_6_0_default,
  milliseconds: () => milliseconds
});
module.exports = __toCommonJS(milliseconds_3_6_0_exports);

// node_modules/date-fns/milliseconds.mjs
var import_constants = require("date-fns@3.6.0/constants");
function milliseconds({
  years,
  months,
  weeks,
  days,
  hours,
  minutes,
  seconds
}) {
  let totalDays = 0;
  if (years) totalDays += years * import_constants.daysInYear;
  if (months) totalDays += months * (import_constants.daysInYear / 12);
  if (weeks) totalDays += weeks * 7;
  if (days) totalDays += days;
  let totalSeconds = totalDays * 24 * 60 * 60;
  if (hours) totalSeconds += hours * 60 * 60;
  if (minutes) totalSeconds += minutes * 60;
  if (seconds) totalSeconds += seconds;
  return Math.trunc(totalSeconds * 1e3);
}
var milliseconds_default = milliseconds;

// .beyond/uimport/temp/date-fns/milliseconds.3.6.0.js
var milliseconds_3_6_0_default = milliseconds_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL21pbGxpc2Vjb25kcy4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9taWxsaXNlY29uZHMubWpzIl0sIm5hbWVzIjpbIm1pbGxpc2Vjb25kc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwibWlsbGlzZWNvbmRzXzNfNl8wX2RlZmF1bHQiLCJtaWxsaXNlY29uZHMiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2NvbnN0YW50cyIsInJlcXVpcmUiLCJ5ZWFycyIsIm1vbnRocyIsIndlZWtzIiwiZGF5cyIsImhvdXJzIiwibWludXRlcyIsInNlY29uZHMiLCJ0b3RhbERheXMiLCJkYXlzSW5ZZWFyIiwidG90YWxTZWNvbmRzIiwiTWF0aCIsInRydW5jIiwibWlsbGlzZWNvbmRzX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLDBCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsMEJBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLDBCQUFBO0VBQUFDLFlBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLDBCQUFBOzs7QUNBQSxJQUFBUSxnQkFBQSxHQUEyQkMsT0FBQTtBQStCcEIsU0FBU0wsYUFBYTtFQUMzQk0sS0FBQTtFQUNBQyxNQUFBO0VBQ0FDLEtBQUE7RUFDQUMsSUFBQTtFQUNBQyxLQUFBO0VBQ0FDLE9BQUE7RUFDQUM7QUFDRixHQUFHO0VBQ0QsSUFBSUMsU0FBQSxHQUFZO0VBRWhCLElBQUlQLEtBQUEsRUFBT08sU0FBQSxJQUFhUCxLQUFBLEdBQVFGLGdCQUFBLENBQUFVLFVBQUE7RUFDaEMsSUFBSVAsTUFBQSxFQUFRTSxTQUFBLElBQWFOLE1BQUEsSUFBVUgsZ0JBQUEsQ0FBQVUsVUFBQSxHQUFhO0VBQ2hELElBQUlOLEtBQUEsRUFBT0ssU0FBQSxJQUFhTCxLQUFBLEdBQVE7RUFDaEMsSUFBSUMsSUFBQSxFQUFNSSxTQUFBLElBQWFKLElBQUE7RUFFdkIsSUFBSU0sWUFBQSxHQUFlRixTQUFBLEdBQVksS0FBSyxLQUFLO0VBRXpDLElBQUlILEtBQUEsRUFBT0ssWUFBQSxJQUFnQkwsS0FBQSxHQUFRLEtBQUs7RUFDeEMsSUFBSUMsT0FBQSxFQUFTSSxZQUFBLElBQWdCSixPQUFBLEdBQVU7RUFDdkMsSUFBSUMsT0FBQSxFQUFTRyxZQUFBLElBQWdCSCxPQUFBO0VBRTdCLE9BQU9JLElBQUEsQ0FBS0MsS0FBQSxDQUFNRixZQUFBLEdBQWUsR0FBSTtBQUN2QztBQUdBLElBQU9HLG9CQUFBLEdBQVFsQixZQUFBOzs7QUR0RGYsSUFBT0QsMEJBQUEsR0FBUW1CLG9CQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9