System.register(["date-fns@3.6.0/constants"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constants', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/millisecondsToHours.3.6.0.js
var millisecondsToHours_3_6_0_exports = {};
__export(millisecondsToHours_3_6_0_exports, {
  default: () => millisecondsToHours_3_6_0_default,
  millisecondsToHours: () => millisecondsToHours
});
module.exports = __toCommonJS(millisecondsToHours_3_6_0_exports);

// node_modules/date-fns/millisecondsToHours.mjs
var import_constants = require("date-fns@3.6.0/constants");
function millisecondsToHours(milliseconds) {
  const hours = milliseconds / import_constants.millisecondsInHour;
  return Math.trunc(hours);
}
var millisecondsToHours_default = millisecondsToHours;

// .beyond/uimport/temp/date-fns/millisecondsToHours.3.6.0.js
var millisecondsToHours_3_6_0_default = millisecondsToHours_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL21pbGxpc2Vjb25kc1RvSG91cnMuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvbWlsbGlzZWNvbmRzVG9Ib3Vycy5tanMiXSwibmFtZXMiOlsibWlsbGlzZWNvbmRzVG9Ib3Vyc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwibWlsbGlzZWNvbmRzVG9Ib3Vyc18zXzZfMF9kZWZhdWx0IiwibWlsbGlzZWNvbmRzVG9Ib3VycyIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfY29uc3RhbnRzIiwicmVxdWlyZSIsIm1pbGxpc2Vjb25kcyIsImhvdXJzIiwibWlsbGlzZWNvbmRzSW5Ib3VyIiwiTWF0aCIsInRydW5jIiwibWlsbGlzZWNvbmRzVG9Ib3Vyc19kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSxpQ0FBQTtBQUFBQyxRQUFBLENBQUFELGlDQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyxpQ0FBQTtFQUFBQyxtQkFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsaUNBQUE7OztBQ0FBLElBQUFRLGdCQUFBLEdBQW1DQyxPQUFBO0FBd0I1QixTQUFTTCxvQkFBb0JNLFlBQUEsRUFBYztFQUNoRCxNQUFNQyxLQUFBLEdBQVFELFlBQUEsR0FBZUYsZ0JBQUEsQ0FBQUksa0JBQUE7RUFDN0IsT0FBT0MsSUFBQSxDQUFLQyxLQUFBLENBQU1ILEtBQUs7QUFDekI7QUFHQSxJQUFPSSwyQkFBQSxHQUFRWCxtQkFBQTs7O0FEM0JmLElBQU9ELGlDQUFBLEdBQVFZLDJCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9