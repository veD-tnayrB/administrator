System.register(["date-fns@3.6.0/constants"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constants', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/millisecondsToSeconds.3.6.0.js
var millisecondsToSeconds_3_6_0_exports = {};
__export(millisecondsToSeconds_3_6_0_exports, {
  default: () => millisecondsToSeconds_3_6_0_default,
  millisecondsToSeconds: () => millisecondsToSeconds
});
module.exports = __toCommonJS(millisecondsToSeconds_3_6_0_exports);

// node_modules/date-fns/millisecondsToSeconds.mjs
var import_constants = require("date-fns@3.6.0/constants");
function millisecondsToSeconds(milliseconds) {
  const seconds = milliseconds / import_constants.millisecondsInSecond;
  return Math.trunc(seconds);
}
var millisecondsToSeconds_default = millisecondsToSeconds;

// .beyond/uimport/temp/date-fns/millisecondsToSeconds.3.6.0.js
var millisecondsToSeconds_3_6_0_default = millisecondsToSeconds_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL21pbGxpc2Vjb25kc1RvU2Vjb25kcy4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9taWxsaXNlY29uZHNUb1NlY29uZHMubWpzIl0sIm5hbWVzIjpbIm1pbGxpc2Vjb25kc1RvU2Vjb25kc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwibWlsbGlzZWNvbmRzVG9TZWNvbmRzXzNfNl8wX2RlZmF1bHQiLCJtaWxsaXNlY29uZHNUb1NlY29uZHMiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2NvbnN0YW50cyIsInJlcXVpcmUiLCJtaWxsaXNlY29uZHMiLCJzZWNvbmRzIiwibWlsbGlzZWNvbmRzSW5TZWNvbmQiLCJNYXRoIiwidHJ1bmMiLCJtaWxsaXNlY29uZHNUb1NlY29uZHNfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsbUNBQUE7QUFBQUMsUUFBQSxDQUFBRCxtQ0FBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsbUNBQUE7RUFBQUMscUJBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLG1DQUFBOzs7QUNBQSxJQUFBUSxnQkFBQSxHQUFxQ0MsT0FBQTtBQXdCOUIsU0FBU0wsc0JBQXNCTSxZQUFBLEVBQWM7RUFDbEQsTUFBTUMsT0FBQSxHQUFVRCxZQUFBLEdBQWVGLGdCQUFBLENBQUFJLG9CQUFBO0VBQy9CLE9BQU9DLElBQUEsQ0FBS0MsS0FBQSxDQUFNSCxPQUFPO0FBQzNCO0FBR0EsSUFBT0ksNkJBQUEsR0FBUVgscUJBQUE7OztBRDNCZixJQUFPRCxtQ0FBQSxHQUFRWSw2QkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==