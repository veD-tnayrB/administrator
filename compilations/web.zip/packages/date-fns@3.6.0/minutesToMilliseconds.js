System.register(["date-fns@3.6.0/constants"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constants', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/minutesToMilliseconds.3.6.0.js
var minutesToMilliseconds_3_6_0_exports = {};
__export(minutesToMilliseconds_3_6_0_exports, {
  default: () => minutesToMilliseconds_3_6_0_default,
  minutesToMilliseconds: () => minutesToMilliseconds
});
module.exports = __toCommonJS(minutesToMilliseconds_3_6_0_exports);

// node_modules/date-fns/minutesToMilliseconds.mjs
var import_constants = require("date-fns@3.6.0/constants");
function minutesToMilliseconds(minutes) {
  return Math.trunc(minutes * import_constants.millisecondsInMinute);
}
var minutesToMilliseconds_default = minutesToMilliseconds;

// .beyond/uimport/temp/date-fns/minutesToMilliseconds.3.6.0.js
var minutesToMilliseconds_3_6_0_default = minutesToMilliseconds_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL21pbnV0ZXNUb01pbGxpc2Vjb25kcy4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9taW51dGVzVG9NaWxsaXNlY29uZHMubWpzIl0sIm5hbWVzIjpbIm1pbnV0ZXNUb01pbGxpc2Vjb25kc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwibWludXRlc1RvTWlsbGlzZWNvbmRzXzNfNl8wX2RlZmF1bHQiLCJtaW51dGVzVG9NaWxsaXNlY29uZHMiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2NvbnN0YW50cyIsInJlcXVpcmUiLCJtaW51dGVzIiwiTWF0aCIsInRydW5jIiwibWlsbGlzZWNvbmRzSW5NaW51dGUiLCJtaW51dGVzVG9NaWxsaXNlY29uZHNfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsbUNBQUE7QUFBQUMsUUFBQSxDQUFBRCxtQ0FBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsbUNBQUE7RUFBQUMscUJBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLG1DQUFBOzs7QUNBQSxJQUFBUSxnQkFBQSxHQUFxQ0MsT0FBQTtBQW1COUIsU0FBU0wsc0JBQXNCTSxPQUFBLEVBQVM7RUFDN0MsT0FBT0MsSUFBQSxDQUFLQyxLQUFBLENBQU1GLE9BQUEsR0FBVUYsZ0JBQUEsQ0FBQUssb0JBQW9CO0FBQ2xEO0FBR0EsSUFBT0MsNkJBQUEsR0FBUVYscUJBQUE7OztBRHJCZixJQUFPRCxtQ0FBQSxHQUFRVyw2QkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==