System.register(["date-fns@3.6.0/constants"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constants', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/monthsToQuarters.3.6.0.js
var monthsToQuarters_3_6_0_exports = {};
__export(monthsToQuarters_3_6_0_exports, {
  default: () => monthsToQuarters_3_6_0_default,
  monthsToQuarters: () => monthsToQuarters
});
module.exports = __toCommonJS(monthsToQuarters_3_6_0_exports);

// node_modules/date-fns/monthsToQuarters.mjs
var import_constants = require("date-fns@3.6.0/constants");
function monthsToQuarters(months) {
  const quarters = months / import_constants.monthsInQuarter;
  return Math.trunc(quarters);
}
var monthsToQuarters_default = monthsToQuarters;

// .beyond/uimport/temp/date-fns/monthsToQuarters.3.6.0.js
var monthsToQuarters_3_6_0_default = monthsToQuarters_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL21vbnRoc1RvUXVhcnRlcnMuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvbW9udGhzVG9RdWFydGVycy5tanMiXSwibmFtZXMiOlsibW9udGhzVG9RdWFydGVyc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwibW9udGhzVG9RdWFydGVyc18zXzZfMF9kZWZhdWx0IiwibW9udGhzVG9RdWFydGVycyIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfY29uc3RhbnRzIiwicmVxdWlyZSIsIm1vbnRocyIsInF1YXJ0ZXJzIiwibW9udGhzSW5RdWFydGVyIiwiTWF0aCIsInRydW5jIiwibW9udGhzVG9RdWFydGVyc19kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSw4QkFBQTtBQUFBQyxRQUFBLENBQUFELDhCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyw4QkFBQTtFQUFBQyxnQkFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsOEJBQUE7OztBQ0FBLElBQUFRLGdCQUFBLEdBQWdDQyxPQUFBO0FBd0J6QixTQUFTTCxpQkFBaUJNLE1BQUEsRUFBUTtFQUN2QyxNQUFNQyxRQUFBLEdBQVdELE1BQUEsR0FBU0YsZ0JBQUEsQ0FBQUksZUFBQTtFQUMxQixPQUFPQyxJQUFBLENBQUtDLEtBQUEsQ0FBTUgsUUFBUTtBQUM1QjtBQUdBLElBQU9JLHdCQUFBLEdBQVFYLGdCQUFBOzs7QUQzQmYsSUFBT0QsOEJBQUEsR0FBUVksd0JBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=