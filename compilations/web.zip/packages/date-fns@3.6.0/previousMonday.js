System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/getDay","date-fns@3.6.0/constructFrom","date-fns@3.6.0/addDays","date-fns@3.6.0/subDays","date-fns@3.6.0/previousDay"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/getDay', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/addDays', dep), dep => dependencies.set('date-fns@3.6.0/subDays', dep), dep => dependencies.set('date-fns@3.6.0/previousDay', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/previousMonday.3.6.0.js
var previousMonday_3_6_0_exports = {};
__export(previousMonday_3_6_0_exports, {
  default: () => previousMonday_3_6_0_default,
  previousMonday: () => previousMonday
});
module.exports = __toCommonJS(previousMonday_3_6_0_exports);

// node_modules/date-fns/previousMonday.mjs
var import_previousDay = require("date-fns@3.6.0/previousDay");
function previousMonday(date) {
  return (0, import_previousDay.previousDay)(date, 1);
}
var previousMonday_default = previousMonday;

// .beyond/uimport/temp/date-fns/previousMonday.3.6.0.js
var previousMonday_3_6_0_default = previousMonday_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3ByZXZpb3VzTW9uZGF5LjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL3ByZXZpb3VzTW9uZGF5Lm1qcyJdLCJuYW1lcyI6WyJwcmV2aW91c01vbmRheV8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwicHJldmlvdXNNb25kYXlfM182XzBfZGVmYXVsdCIsInByZXZpb3VzTW9uZGF5IiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF9wcmV2aW91c0RheSIsInJlcXVpcmUiLCJkYXRlIiwicHJldmlvdXNEYXkiLCJwcmV2aW91c01vbmRheV9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSw0QkFBQTtBQUFBQyxRQUFBLENBQUFELDRCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyw0QkFBQTtFQUFBQyxjQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCw0QkFBQTs7O0FDQUEsSUFBQVEsa0JBQUEsR0FBNEJDLE9BQUE7QUFxQnJCLFNBQVNMLGVBQWVNLElBQUEsRUFBTTtFQUNuQyxXQUFPRixrQkFBQSxDQUFBRyxXQUFBLEVBQVlELElBQUEsRUFBTSxDQUFDO0FBQzVCO0FBR0EsSUFBT0Usc0JBQUEsR0FBUVIsY0FBQTs7O0FEdkJmLElBQU9ELDRCQUFBLEdBQVFTLHNCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9