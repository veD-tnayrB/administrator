System.register(["date-fns@3.6.0/constructFrom","date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/roundToNearestHours.3.6.0.js
var roundToNearestHours_3_6_0_exports = {};
__export(roundToNearestHours_3_6_0_exports, {
  default: () => roundToNearestHours_3_6_0_default,
  roundToNearestHours: () => roundToNearestHours
});
module.exports = __toCommonJS(roundToNearestHours_3_6_0_exports);

// node_modules/date-fns/_lib/getRoundingMethod.mjs
function getRoundingMethod(method) {
  return number => {
    const round = method ? Math[method] : Math.trunc;
    const result = round(number);
    return result === 0 ? 0 : result;
  };
}

// node_modules/date-fns/roundToNearestHours.mjs
var import_constructFrom = require("date-fns@3.6.0/constructFrom");
var import_toDate = require("date-fns@3.6.0/toDate");
function roundToNearestHours(date, options) {
  const nearestTo = options?.nearestTo ?? 1;
  if (nearestTo < 1 || nearestTo > 12) return (0, import_constructFrom.constructFrom)(date, NaN);
  const _date = (0, import_toDate.toDate)(date);
  const fractionalMinutes = _date.getMinutes() / 60;
  const fractionalSeconds = _date.getSeconds() / 60 / 60;
  const fractionalMilliseconds = _date.getMilliseconds() / 1e3 / 60 / 60;
  const hours = _date.getHours() + fractionalMinutes + fractionalSeconds + fractionalMilliseconds;
  const method = options?.roundingMethod ?? "round";
  const roundingMethod = getRoundingMethod(method);
  const roundedHours = roundingMethod(hours / nearestTo) * nearestTo;
  const result = (0, import_constructFrom.constructFrom)(date, _date);
  result.setHours(roundedHours, 0, 0, 0);
  return result;
}
var roundToNearestHours_default = roundToNearestHours;

// .beyond/uimport/temp/date-fns/roundToNearestHours.3.6.0.js
var roundToNearestHours_3_6_0_default = roundToNearestHours_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3JvdW5kVG9OZWFyZXN0SG91cnMuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvX2xpYi9nZXRSb3VuZGluZ01ldGhvZC5tanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvcm91bmRUb05lYXJlc3RIb3Vycy5tanMiXSwibmFtZXMiOlsicm91bmRUb05lYXJlc3RIb3Vyc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0Iiwicm91bmRUb05lYXJlc3RIb3Vyc18zXzZfMF9kZWZhdWx0Iiwicm91bmRUb05lYXJlc3RIb3VycyIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJnZXRSb3VuZGluZ01ldGhvZCIsIm1ldGhvZCIsIm51bWJlciIsInJvdW5kIiwiTWF0aCIsInRydW5jIiwicmVzdWx0IiwiaW1wb3J0X2NvbnN0cnVjdEZyb20iLCJyZXF1aXJlIiwiaW1wb3J0X3RvRGF0ZSIsImRhdGUiLCJvcHRpb25zIiwibmVhcmVzdFRvIiwiY29uc3RydWN0RnJvbSIsIk5hTiIsIl9kYXRlIiwidG9EYXRlIiwiZnJhY3Rpb25hbE1pbnV0ZXMiLCJnZXRNaW51dGVzIiwiZnJhY3Rpb25hbFNlY29uZHMiLCJnZXRTZWNvbmRzIiwiZnJhY3Rpb25hbE1pbGxpc2Vjb25kcyIsImdldE1pbGxpc2Vjb25kcyIsImhvdXJzIiwiZ2V0SG91cnMiLCJyb3VuZGluZ01ldGhvZCIsInJvdW5kZWRIb3VycyIsInNldEhvdXJzIiwicm91bmRUb05lYXJlc3RIb3Vyc19kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSxpQ0FBQTtBQUFBQyxRQUFBLENBQUFELGlDQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyxpQ0FBQTtFQUFBQyxtQkFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsaUNBQUE7OztBQ0FPLFNBQVNRLGtCQUFrQkMsTUFBQSxFQUFRO0VBQ3hDLE9BQVFDLE1BQUEsSUFBVztJQUNqQixNQUFNQyxLQUFBLEdBQVFGLE1BQUEsR0FBU0csSUFBQSxDQUFLSCxNQUFBLElBQVVHLElBQUEsQ0FBS0MsS0FBQTtJQUMzQyxNQUFNQyxNQUFBLEdBQVNILEtBQUEsQ0FBTUQsTUFBTTtJQUUzQixPQUFPSSxNQUFBLEtBQVcsSUFBSSxJQUFJQSxNQUFBO0VBQzVCO0FBQ0Y7OztBQ05BLElBQUFDLG9CQUFBLEdBQThCQyxPQUFBO0FBQzlCLElBQUFDLGFBQUEsR0FBdUJELE9BQUE7QUErQ2hCLFNBQVNaLG9CQUFvQmMsSUFBQSxFQUFNQyxPQUFBLEVBQVM7RUFDakQsTUFBTUMsU0FBQSxHQUFZRCxPQUFBLEVBQVNDLFNBQUEsSUFBYTtFQUV4QyxJQUFJQSxTQUFBLEdBQVksS0FBS0EsU0FBQSxHQUFZLElBQUksV0FBT0wsb0JBQUEsQ0FBQU0sYUFBQSxFQUFjSCxJQUFBLEVBQU1JLEdBQUc7RUFFbkUsTUFBTUMsS0FBQSxPQUFRTixhQUFBLENBQUFPLE1BQUEsRUFBT04sSUFBSTtFQUN6QixNQUFNTyxpQkFBQSxHQUFvQkYsS0FBQSxDQUFNRyxVQUFBLENBQVcsSUFBSTtFQUMvQyxNQUFNQyxpQkFBQSxHQUFvQkosS0FBQSxDQUFNSyxVQUFBLENBQVcsSUFBSSxLQUFLO0VBQ3BELE1BQU1DLHNCQUFBLEdBQXlCTixLQUFBLENBQU1PLGVBQUEsQ0FBZ0IsSUFBSSxNQUFPLEtBQUs7RUFDckUsTUFBTUMsS0FBQSxHQUNKUixLQUFBLENBQU1TLFFBQUEsQ0FBUyxJQUNmUCxpQkFBQSxHQUNBRSxpQkFBQSxHQUNBRSxzQkFBQTtFQUdGLE1BQU1wQixNQUFBLEdBQVNVLE9BQUEsRUFBU2MsY0FBQSxJQUFrQjtFQUMxQyxNQUFNQSxjQUFBLEdBQWlCekIsaUJBQUEsQ0FBa0JDLE1BQU07RUFHL0MsTUFBTXlCLFlBQUEsR0FBZUQsY0FBQSxDQUFlRixLQUFBLEdBQVFYLFNBQVMsSUFBSUEsU0FBQTtFQUV6RCxNQUFNTixNQUFBLE9BQVNDLG9CQUFBLENBQUFNLGFBQUEsRUFBY0gsSUFBQSxFQUFNSyxLQUFLO0VBQ3hDVCxNQUFBLENBQU9xQixRQUFBLENBQVNELFlBQUEsRUFBYyxHQUFHLEdBQUcsQ0FBQztFQUNyQyxPQUFPcEIsTUFBQTtBQUNUO0FBR0EsSUFBT3NCLDJCQUFBLEdBQVFoQyxtQkFBQTs7O0FGMUVmLElBQU9ELGlDQUFBLEdBQVFpQywyQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==