System.register(["date-fns@3.6.0/constants"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constants', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/secondsToHours.3.6.0.js
var secondsToHours_3_6_0_exports = {};
__export(secondsToHours_3_6_0_exports, {
  default: () => secondsToHours_3_6_0_default,
  secondsToHours: () => secondsToHours
});
module.exports = __toCommonJS(secondsToHours_3_6_0_exports);

// node_modules/date-fns/secondsToHours.mjs
var import_constants = require("date-fns@3.6.0/constants");
function secondsToHours(seconds) {
  const hours = seconds / import_constants.secondsInHour;
  return Math.trunc(hours);
}
var secondsToHours_default = secondsToHours;

// .beyond/uimport/temp/date-fns/secondsToHours.3.6.0.js
var secondsToHours_3_6_0_default = secondsToHours_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3NlY29uZHNUb0hvdXJzLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL3NlY29uZHNUb0hvdXJzLm1qcyJdLCJuYW1lcyI6WyJzZWNvbmRzVG9Ib3Vyc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0Iiwic2Vjb25kc1RvSG91cnNfM182XzBfZGVmYXVsdCIsInNlY29uZHNUb0hvdXJzIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF9jb25zdGFudHMiLCJyZXF1aXJlIiwic2Vjb25kcyIsImhvdXJzIiwic2Vjb25kc0luSG91ciIsIk1hdGgiLCJ0cnVuYyIsInNlY29uZHNUb0hvdXJzX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLDRCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsNEJBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLDRCQUFBO0VBQUFDLGNBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLDRCQUFBOzs7QUNBQSxJQUFBUSxnQkFBQSxHQUE4QkMsT0FBQTtBQXdCdkIsU0FBU0wsZUFBZU0sT0FBQSxFQUFTO0VBQ3RDLE1BQU1DLEtBQUEsR0FBUUQsT0FBQSxHQUFVRixnQkFBQSxDQUFBSSxhQUFBO0VBQ3hCLE9BQU9DLElBQUEsQ0FBS0MsS0FBQSxDQUFNSCxLQUFLO0FBQ3pCO0FBR0EsSUFBT0ksc0JBQUEsR0FBUVgsY0FBQTs7O0FEM0JmLElBQU9ELDRCQUFBLEdBQVFZLHNCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9