System.register(["date-fns@3.6.0/constants"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constants', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/secondsToMinutes.3.6.0.js
var secondsToMinutes_3_6_0_exports = {};
__export(secondsToMinutes_3_6_0_exports, {
  default: () => secondsToMinutes_3_6_0_default,
  secondsToMinutes: () => secondsToMinutes
});
module.exports = __toCommonJS(secondsToMinutes_3_6_0_exports);

// node_modules/date-fns/secondsToMinutes.mjs
var import_constants = require("date-fns@3.6.0/constants");
function secondsToMinutes(seconds) {
  const minutes = seconds / import_constants.secondsInMinute;
  return Math.trunc(minutes);
}
var secondsToMinutes_default = secondsToMinutes;

// .beyond/uimport/temp/date-fns/secondsToMinutes.3.6.0.js
var secondsToMinutes_3_6_0_default = secondsToMinutes_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3NlY29uZHNUb01pbnV0ZXMuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvc2Vjb25kc1RvTWludXRlcy5tanMiXSwibmFtZXMiOlsic2Vjb25kc1RvTWludXRlc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0Iiwic2Vjb25kc1RvTWludXRlc18zXzZfMF9kZWZhdWx0Iiwic2Vjb25kc1RvTWludXRlcyIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfY29uc3RhbnRzIiwicmVxdWlyZSIsInNlY29uZHMiLCJtaW51dGVzIiwic2Vjb25kc0luTWludXRlIiwiTWF0aCIsInRydW5jIiwic2Vjb25kc1RvTWludXRlc19kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSw4QkFBQTtBQUFBQyxRQUFBLENBQUFELDhCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyw4QkFBQTtFQUFBQyxnQkFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsOEJBQUE7OztBQ0FBLElBQUFRLGdCQUFBLEdBQWdDQyxPQUFBO0FBd0J6QixTQUFTTCxpQkFBaUJNLE9BQUEsRUFBUztFQUN4QyxNQUFNQyxPQUFBLEdBQVVELE9BQUEsR0FBVUYsZ0JBQUEsQ0FBQUksZUFBQTtFQUMxQixPQUFPQyxJQUFBLENBQUtDLEtBQUEsQ0FBTUgsT0FBTztBQUMzQjtBQUdBLElBQU9JLHdCQUFBLEdBQVFYLGdCQUFBOzs7QUQzQmYsSUFBT0QsOEJBQUEsR0FBUVksd0JBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=