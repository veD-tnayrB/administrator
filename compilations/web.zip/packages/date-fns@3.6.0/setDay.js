System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/constructFrom","date-fns@3.6.0/addDays"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/addDays', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/setDay.3.6.0.js
var setDay_3_6_0_exports = {};
__export(setDay_3_6_0_exports, {
  default: () => setDay_3_6_0_default,
  setDay: () => setDay
});
module.exports = __toCommonJS(setDay_3_6_0_exports);

// node_modules/date-fns/_lib/defaultOptions.mjs
var defaultOptions = {};
function getDefaultOptions() {
  return defaultOptions;
}
function setDefaultOptions(newOptions) {
  defaultOptions = newOptions;
}

// node_modules/date-fns/setDay.mjs
var import_addDays = require("date-fns@3.6.0/addDays");
var import_toDate = require("date-fns@3.6.0/toDate");
function setDay(date, day, options) {
  const defaultOptions2 = getDefaultOptions();
  const weekStartsOn = options?.weekStartsOn ?? options?.locale?.options?.weekStartsOn ?? defaultOptions2.weekStartsOn ?? defaultOptions2.locale?.options?.weekStartsOn ?? 0;
  const _date = (0, import_toDate.toDate)(date);
  const currentDay = _date.getDay();
  const remainder = day % 7;
  const dayIndex = (remainder + 7) % 7;
  const delta = 7 - weekStartsOn;
  const diff = day < 0 || day > 6 ? day - (currentDay + delta) % 7 : (dayIndex + delta) % 7 - (currentDay + delta) % 7;
  return (0, import_addDays.addDays)(_date, diff);
}
var setDay_default = setDay;

// .beyond/uimport/temp/date-fns/setDay.3.6.0.js
var setDay_3_6_0_default = setDay_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3NldERheS4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9fbGliL2RlZmF1bHRPcHRpb25zLm1qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9zZXREYXkubWpzIl0sIm5hbWVzIjpbInNldERheV8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0Iiwic2V0RGF5XzNfNl8wX2RlZmF1bHQiLCJzZXREYXkiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiZGVmYXVsdE9wdGlvbnMiLCJnZXREZWZhdWx0T3B0aW9ucyIsInNldERlZmF1bHRPcHRpb25zIiwibmV3T3B0aW9ucyIsImltcG9ydF9hZGREYXlzIiwicmVxdWlyZSIsImltcG9ydF90b0RhdGUiLCJkYXRlIiwiZGF5Iiwib3B0aW9ucyIsImRlZmF1bHRPcHRpb25zMiIsIndlZWtTdGFydHNPbiIsImxvY2FsZSIsIl9kYXRlIiwidG9EYXRlIiwiY3VycmVudERheSIsImdldERheSIsInJlbWFpbmRlciIsImRheUluZGV4IiwiZGVsdGEiLCJkaWZmIiwiYWRkRGF5cyIsInNldERheV9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSxvQkFBQTtBQUFBQyxRQUFBLENBQUFELG9CQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyxvQkFBQTtFQUFBQyxNQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCxvQkFBQTs7O0FDQUEsSUFBSVEsY0FBQSxHQUFpQixDQUFDO0FBRWYsU0FBU0Msa0JBQUEsRUFBb0I7RUFDbEMsT0FBT0QsY0FBQTtBQUNUO0FBRU8sU0FBU0Usa0JBQWtCQyxVQUFBLEVBQVk7RUFDNUNILGNBQUEsR0FBaUJHLFVBQUE7QUFDbkI7OztBQ1JBLElBQUFDLGNBQUEsR0FBd0JDLE9BQUE7QUFDeEIsSUFBQUMsYUFBQSxHQUF1QkQsT0FBQTtBQWlDaEIsU0FBU1QsT0FBT1csSUFBQSxFQUFNQyxHQUFBLEVBQUtDLE9BQUEsRUFBUztFQUN6QyxNQUFNQyxlQUFBLEdBQWlCVCxpQkFBQSxDQUFrQjtFQUN6QyxNQUFNVSxZQUFBLEdBQ0pGLE9BQUEsRUFBU0UsWUFBQSxJQUNURixPQUFBLEVBQVNHLE1BQUEsRUFBUUgsT0FBQSxFQUFTRSxZQUFBLElBQzFCRCxlQUFBLENBQWVDLFlBQUEsSUFDZkQsZUFBQSxDQUFlRSxNQUFBLEVBQVFILE9BQUEsRUFBU0UsWUFBQSxJQUNoQztFQUVGLE1BQU1FLEtBQUEsT0FBUVAsYUFBQSxDQUFBUSxNQUFBLEVBQU9QLElBQUk7RUFDekIsTUFBTVEsVUFBQSxHQUFhRixLQUFBLENBQU1HLE1BQUEsQ0FBTztFQUVoQyxNQUFNQyxTQUFBLEdBQVlULEdBQUEsR0FBTTtFQUN4QixNQUFNVSxRQUFBLElBQVlELFNBQUEsR0FBWSxLQUFLO0VBRW5DLE1BQU1FLEtBQUEsR0FBUSxJQUFJUixZQUFBO0VBQ2xCLE1BQU1TLElBQUEsR0FDSlosR0FBQSxHQUFNLEtBQUtBLEdBQUEsR0FBTSxJQUNiQSxHQUFBLElBQVFPLFVBQUEsR0FBYUksS0FBQSxJQUFTLEtBQzVCRCxRQUFBLEdBQVdDLEtBQUEsSUFBUyxLQUFPSixVQUFBLEdBQWFJLEtBQUEsSUFBUztFQUN6RCxXQUFPZixjQUFBLENBQUFpQixPQUFBLEVBQVFSLEtBQUEsRUFBT08sSUFBSTtBQUM1QjtBQUdBLElBQU9FLGNBQUEsR0FBUTFCLE1BQUE7OztBRnZEZixJQUFPRCxvQkFBQSxHQUFRMkIsY0FBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==