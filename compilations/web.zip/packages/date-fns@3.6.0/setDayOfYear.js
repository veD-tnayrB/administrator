System.register(["date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/setDayOfYear.3.6.0.js
var setDayOfYear_3_6_0_exports = {};
__export(setDayOfYear_3_6_0_exports, {
  default: () => setDayOfYear_3_6_0_default,
  setDayOfYear: () => setDayOfYear
});
module.exports = __toCommonJS(setDayOfYear_3_6_0_exports);

// node_modules/date-fns/setDayOfYear.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function setDayOfYear(date, dayOfYear) {
  const _date = (0, import_toDate.toDate)(date);
  _date.setMonth(0);
  _date.setDate(dayOfYear);
  return _date;
}
var setDayOfYear_default = setDayOfYear;

// .beyond/uimport/temp/date-fns/setDayOfYear.3.6.0.js
var setDayOfYear_3_6_0_default = setDayOfYear_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3NldERheU9mWWVhci4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9zZXREYXlPZlllYXIubWpzIl0sIm5hbWVzIjpbInNldERheU9mWWVhcl8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0Iiwic2V0RGF5T2ZZZWFyXzNfNl8wX2RlZmF1bHQiLCJzZXREYXlPZlllYXIiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X3RvRGF0ZSIsInJlcXVpcmUiLCJkYXRlIiwiZGF5T2ZZZWFyIiwiX2RhdGUiLCJ0b0RhdGUiLCJzZXRNb250aCIsInNldERhdGUiLCJzZXREYXlPZlllYXJfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsMEJBQUE7QUFBQUMsUUFBQSxDQUFBRCwwQkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsMEJBQUE7RUFBQUMsWUFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsMEJBQUE7OztBQ0FBLElBQUFRLGFBQUEsR0FBdUJDLE9BQUE7QUFzQmhCLFNBQVNMLGFBQWFNLElBQUEsRUFBTUMsU0FBQSxFQUFXO0VBQzVDLE1BQU1DLEtBQUEsT0FBUUosYUFBQSxDQUFBSyxNQUFBLEVBQU9ILElBQUk7RUFDekJFLEtBQUEsQ0FBTUUsUUFBQSxDQUFTLENBQUM7RUFDaEJGLEtBQUEsQ0FBTUcsT0FBQSxDQUFRSixTQUFTO0VBQ3ZCLE9BQU9DLEtBQUE7QUFDVDtBQUdBLElBQU9JLG9CQUFBLEdBQVFaLFlBQUE7OztBRDNCZixJQUFPRCwwQkFBQSxHQUFRYSxvQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==