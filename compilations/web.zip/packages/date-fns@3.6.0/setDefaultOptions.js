System.register([], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/setDefaultOptions.3.6.0.js
var setDefaultOptions_3_6_0_exports = {};
__export(setDefaultOptions_3_6_0_exports, {
  default: () => setDefaultOptions_3_6_0_default,
  setDefaultOptions: () => setDefaultOptions2
});
module.exports = __toCommonJS(setDefaultOptions_3_6_0_exports);

// node_modules/date-fns/_lib/defaultOptions.mjs
var defaultOptions = {};
function getDefaultOptions() {
  return defaultOptions;
}
function setDefaultOptions(newOptions) {
  defaultOptions = newOptions;
}

// node_modules/date-fns/setDefaultOptions.mjs
function setDefaultOptions2(options) {
  const result = {};
  const defaultOptions2 = getDefaultOptions();
  for (const property in defaultOptions2) {
    if (Object.prototype.hasOwnProperty.call(defaultOptions2, property)) {
      result[property] = defaultOptions2[property];
    }
  }
  for (const property in options) {
    if (Object.prototype.hasOwnProperty.call(options, property)) {
      if (options[property] === void 0) {
        delete result[property];
      } else {
        result[property] = options[property];
      }
    }
  }
  setDefaultOptions(result);
}
var setDefaultOptions_default = setDefaultOptions2;

// .beyond/uimport/temp/date-fns/setDefaultOptions.3.6.0.js
var setDefaultOptions_3_6_0_default = setDefaultOptions_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3NldERlZmF1bHRPcHRpb25zLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL19saWIvZGVmYXVsdE9wdGlvbnMubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL3NldERlZmF1bHRPcHRpb25zLm1qcyJdLCJuYW1lcyI6WyJzZXREZWZhdWx0T3B0aW9uc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0Iiwic2V0RGVmYXVsdE9wdGlvbnNfM182XzBfZGVmYXVsdCIsInNldERlZmF1bHRPcHRpb25zIiwic2V0RGVmYXVsdE9wdGlvbnMyIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImRlZmF1bHRPcHRpb25zIiwiZ2V0RGVmYXVsdE9wdGlvbnMiLCJuZXdPcHRpb25zIiwib3B0aW9ucyIsInJlc3VsdCIsImRlZmF1bHRPcHRpb25zMiIsInByb3BlcnR5IiwiT2JqZWN0IiwicHJvdG90eXBlIiwiaGFzT3duUHJvcGVydHkiLCJjYWxsIiwic2V0RGVmYXVsdE9wdGlvbnNfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsK0JBQUE7QUFBQUMsUUFBQSxDQUFBRCwrQkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsK0JBQUE7RUFBQUMsaUJBQUEsRUFBQUEsQ0FBQSxLQUFBQztBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFSLCtCQUFBOzs7QUNBQSxJQUFJUyxjQUFBLEdBQWlCLENBQUM7QUFFZixTQUFTQyxrQkFBQSxFQUFvQjtFQUNsQyxPQUFPRCxjQUFBO0FBQ1Q7QUFFTyxTQUFTTCxrQkFBa0JPLFVBQUEsRUFBWTtFQUM1Q0YsY0FBQSxHQUFpQkUsVUFBQTtBQUNuQjs7O0FDMENPLFNBQVNOLG1CQUFrQk8sT0FBQSxFQUFTO0VBQ3pDLE1BQU1DLE1BQUEsR0FBUyxDQUFDO0VBQ2hCLE1BQU1DLGVBQUEsR0FBaUJKLGlCQUFBLENBQWtCO0VBRXpDLFdBQVdLLFFBQUEsSUFBWUQsZUFBQSxFQUFnQjtJQUNyQyxJQUFJRSxNQUFBLENBQU9DLFNBQUEsQ0FBVUMsY0FBQSxDQUFlQyxJQUFBLENBQUtMLGVBQUEsRUFBZ0JDLFFBQVEsR0FBRztNQUVsRUYsTUFBQSxDQUFPRSxRQUFBLElBQVlELGVBQUEsQ0FBZUMsUUFBQTtJQUNwQztFQUNGO0VBRUEsV0FBV0EsUUFBQSxJQUFZSCxPQUFBLEVBQVM7SUFDOUIsSUFBSUksTUFBQSxDQUFPQyxTQUFBLENBQVVDLGNBQUEsQ0FBZUMsSUFBQSxDQUFLUCxPQUFBLEVBQVNHLFFBQVEsR0FBRztNQUMzRCxJQUFJSCxPQUFBLENBQVFHLFFBQUEsTUFBYyxRQUFXO1FBRW5DLE9BQU9GLE1BQUEsQ0FBT0UsUUFBQTtNQUNoQixPQUFPO1FBRUxGLE1BQUEsQ0FBT0UsUUFBQSxJQUFZSCxPQUFBLENBQVFHLFFBQUE7TUFDN0I7SUFDRjtFQUNGO0VBRUFYLGlCQUFBLENBQTBCUyxNQUFNO0FBQ2xDO0FBR0EsSUFBT08seUJBQUEsR0FBUWYsa0JBQUE7OztBRjFFZixJQUFPRiwrQkFBQSxHQUFRaUIseUJBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=