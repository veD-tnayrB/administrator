System.register(["date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/setHours.3.6.0.js
var setHours_3_6_0_exports = {};
__export(setHours_3_6_0_exports, {
  default: () => setHours_3_6_0_default,
  setHours: () => setHours
});
module.exports = __toCommonJS(setHours_3_6_0_exports);

// node_modules/date-fns/setHours.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function setHours(date, hours) {
  const _date = (0, import_toDate.toDate)(date);
  _date.setHours(hours);
  return _date;
}
var setHours_default = setHours;

// .beyond/uimport/temp/date-fns/setHours.3.6.0.js
var setHours_3_6_0_default = setHours_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3NldEhvdXJzLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL3NldEhvdXJzLm1qcyJdLCJuYW1lcyI6WyJzZXRIb3Vyc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0Iiwic2V0SG91cnNfM182XzBfZGVmYXVsdCIsInNldEhvdXJzIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF90b0RhdGUiLCJyZXF1aXJlIiwiZGF0ZSIsImhvdXJzIiwiX2RhdGUiLCJ0b0RhdGUiLCJzZXRIb3Vyc19kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSxzQkFBQTtBQUFBQyxRQUFBLENBQUFELHNCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyxzQkFBQTtFQUFBQyxRQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCxzQkFBQTs7O0FDQUEsSUFBQVEsYUFBQSxHQUF1QkMsT0FBQTtBQXNCaEIsU0FBU0wsU0FBU00sSUFBQSxFQUFNQyxLQUFBLEVBQU87RUFDcEMsTUFBTUMsS0FBQSxPQUFRSixhQUFBLENBQUFLLE1BQUEsRUFBT0gsSUFBSTtFQUN6QkUsS0FBQSxDQUFNUixRQUFBLENBQVNPLEtBQUs7RUFDcEIsT0FBT0MsS0FBQTtBQUNUO0FBR0EsSUFBT0UsZ0JBQUEsR0FBUVYsUUFBQTs7O0FEMUJmLElBQU9ELHNCQUFBLEdBQVFXLGdCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9