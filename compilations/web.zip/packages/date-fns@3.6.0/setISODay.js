System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/constructFrom","date-fns@3.6.0/addDays","date-fns@3.6.0/getISODay"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/addDays', dep), dep => dependencies.set('date-fns@3.6.0/getISODay', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/setISODay.3.6.0.js
var setISODay_3_6_0_exports = {};
__export(setISODay_3_6_0_exports, {
  default: () => setISODay_3_6_0_default,
  setISODay: () => setISODay
});
module.exports = __toCommonJS(setISODay_3_6_0_exports);

// node_modules/date-fns/setISODay.mjs
var import_addDays = require("date-fns@3.6.0/addDays");
var import_getISODay = require("date-fns@3.6.0/getISODay");
var import_toDate = require("date-fns@3.6.0/toDate");
function setISODay(date, day) {
  const _date = (0, import_toDate.toDate)(date);
  const currentDay = (0, import_getISODay.getISODay)(_date);
  const diff = day - currentDay;
  return (0, import_addDays.addDays)(_date, diff);
}
var setISODay_default = setISODay;

// .beyond/uimport/temp/date-fns/setISODay.3.6.0.js
var setISODay_3_6_0_default = setISODay_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3NldElTT0RheS4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9zZXRJU09EYXkubWpzIl0sIm5hbWVzIjpbInNldElTT0RheV8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0Iiwic2V0SVNPRGF5XzNfNl8wX2RlZmF1bHQiLCJzZXRJU09EYXkiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2FkZERheXMiLCJyZXF1aXJlIiwiaW1wb3J0X2dldElTT0RheSIsImltcG9ydF90b0RhdGUiLCJkYXRlIiwiZGF5IiwiX2RhdGUiLCJ0b0RhdGUiLCJjdXJyZW50RGF5IiwiZ2V0SVNPRGF5IiwiZGlmZiIsImFkZERheXMiLCJzZXRJU09EYXlfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsdUJBQUE7QUFBQUMsUUFBQSxDQUFBRCx1QkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsdUJBQUE7RUFBQUMsU0FBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsdUJBQUE7OztBQ0FBLElBQUFRLGNBQUEsR0FBd0JDLE9BQUE7QUFDeEIsSUFBQUMsZ0JBQUEsR0FBMEJELE9BQUE7QUFDMUIsSUFBQUUsYUFBQSxHQUF1QkYsT0FBQTtBQXdCaEIsU0FBU0wsVUFBVVEsSUFBQSxFQUFNQyxHQUFBLEVBQUs7RUFDbkMsTUFBTUMsS0FBQSxPQUFRSCxhQUFBLENBQUFJLE1BQUEsRUFBT0gsSUFBSTtFQUN6QixNQUFNSSxVQUFBLE9BQWFOLGdCQUFBLENBQUFPLFNBQUEsRUFBVUgsS0FBSztFQUNsQyxNQUFNSSxJQUFBLEdBQU9MLEdBQUEsR0FBTUcsVUFBQTtFQUNuQixXQUFPUixjQUFBLENBQUFXLE9BQUEsRUFBUUwsS0FBQSxFQUFPSSxJQUFJO0FBQzVCO0FBR0EsSUFBT0UsaUJBQUEsR0FBUWhCLFNBQUE7OztBRC9CZixJQUFPRCx1QkFBQSxHQUFRaUIsaUJBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=