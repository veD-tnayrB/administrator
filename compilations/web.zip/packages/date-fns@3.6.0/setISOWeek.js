System.register(["date-fns@3.6.0/constants","date-fns@3.6.0/toDate","date-fns@3.6.0/startOfWeek","date-fns@3.6.0/startOfISOWeek","date-fns@3.6.0/constructFrom","date-fns@3.6.0/getISOWeekYear","date-fns@3.6.0/startOfISOWeekYear","date-fns@3.6.0/getISOWeek"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constants', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfWeek', dep), dep => dependencies.set('date-fns@3.6.0/startOfISOWeek', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/getISOWeekYear', dep), dep => dependencies.set('date-fns@3.6.0/startOfISOWeekYear', dep), dep => dependencies.set('date-fns@3.6.0/getISOWeek', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/setISOWeek.3.6.0.js
var setISOWeek_3_6_0_exports = {};
__export(setISOWeek_3_6_0_exports, {
  default: () => setISOWeek_3_6_0_default,
  setISOWeek: () => setISOWeek
});
module.exports = __toCommonJS(setISOWeek_3_6_0_exports);

// node_modules/date-fns/setISOWeek.mjs
var import_getISOWeek = require("date-fns@3.6.0/getISOWeek");
var import_toDate = require("date-fns@3.6.0/toDate");
function setISOWeek(date, week) {
  const _date = (0, import_toDate.toDate)(date);
  const diff = (0, import_getISOWeek.getISOWeek)(_date) - week;
  _date.setDate(_date.getDate() - diff * 7);
  return _date;
}
var setISOWeek_default = setISOWeek;

// .beyond/uimport/temp/date-fns/setISOWeek.3.6.0.js
var setISOWeek_3_6_0_default = setISOWeek_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3NldElTT1dlZWsuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvc2V0SVNPV2Vlay5tanMiXSwibmFtZXMiOlsic2V0SVNPV2Vla18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0Iiwic2V0SVNPV2Vla18zXzZfMF9kZWZhdWx0Iiwic2V0SVNPV2VlayIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfZ2V0SVNPV2VlayIsInJlcXVpcmUiLCJpbXBvcnRfdG9EYXRlIiwiZGF0ZSIsIndlZWsiLCJfZGF0ZSIsInRvRGF0ZSIsImRpZmYiLCJnZXRJU09XZWVrIiwic2V0RGF0ZSIsImdldERhdGUiLCJzZXRJU09XZWVrX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLHdCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsd0JBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLHdCQUFBO0VBQUFDLFVBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLHdCQUFBOzs7QUNBQSxJQUFBUSxpQkFBQSxHQUEyQkMsT0FBQTtBQUMzQixJQUFBQyxhQUFBLEdBQXVCRCxPQUFBO0FBd0JoQixTQUFTTCxXQUFXTyxJQUFBLEVBQU1DLElBQUEsRUFBTTtFQUNyQyxNQUFNQyxLQUFBLE9BQVFILGFBQUEsQ0FBQUksTUFBQSxFQUFPSCxJQUFJO0VBQ3pCLE1BQU1JLElBQUEsT0FBT1AsaUJBQUEsQ0FBQVEsVUFBQSxFQUFXSCxLQUFLLElBQUlELElBQUE7RUFDakNDLEtBQUEsQ0FBTUksT0FBQSxDQUFRSixLQUFBLENBQU1LLE9BQUEsQ0FBUSxJQUFJSCxJQUFBLEdBQU8sQ0FBQztFQUN4QyxPQUFPRixLQUFBO0FBQ1Q7QUFHQSxJQUFPTSxrQkFBQSxHQUFRZixVQUFBOzs7QUQ5QmYsSUFBT0Qsd0JBQUEsR0FBUWdCLGtCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9