System.register(["date-fns@3.6.0/constructFrom","date-fns@3.6.0/constants","date-fns@3.6.0/toDate","date-fns@3.6.0/startOfDay","date-fns@3.6.0/differenceInCalendarDays","date-fns@3.6.0/startOfWeek","date-fns@3.6.0/startOfISOWeek","date-fns@3.6.0/getISOWeekYear","date-fns@3.6.0/startOfISOWeekYear"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/constants', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfDay', dep), dep => dependencies.set('date-fns@3.6.0/differenceInCalendarDays', dep), dep => dependencies.set('date-fns@3.6.0/startOfWeek', dep), dep => dependencies.set('date-fns@3.6.0/startOfISOWeek', dep), dep => dependencies.set('date-fns@3.6.0/getISOWeekYear', dep), dep => dependencies.set('date-fns@3.6.0/startOfISOWeekYear', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/setISOWeekYear.3.6.0.js
var setISOWeekYear_3_6_0_exports = {};
__export(setISOWeekYear_3_6_0_exports, {
  default: () => setISOWeekYear_3_6_0_default,
  setISOWeekYear: () => setISOWeekYear
});
module.exports = __toCommonJS(setISOWeekYear_3_6_0_exports);

// node_modules/date-fns/setISOWeekYear.mjs
var import_constructFrom = require("date-fns@3.6.0/constructFrom");
var import_differenceInCalendarDays = require("date-fns@3.6.0/differenceInCalendarDays");
var import_startOfISOWeekYear = require("date-fns@3.6.0/startOfISOWeekYear");
var import_toDate = require("date-fns@3.6.0/toDate");
function setISOWeekYear(date, weekYear) {
  let _date = (0, import_toDate.toDate)(date);
  const diff = (0, import_differenceInCalendarDays.differenceInCalendarDays)(_date, (0, import_startOfISOWeekYear.startOfISOWeekYear)(_date));
  const fourthOfJanuary = (0, import_constructFrom.constructFrom)(date, 0);
  fourthOfJanuary.setFullYear(weekYear, 0, 4);
  fourthOfJanuary.setHours(0, 0, 0, 0);
  _date = (0, import_startOfISOWeekYear.startOfISOWeekYear)(fourthOfJanuary);
  _date.setDate(_date.getDate() + diff);
  return _date;
}
var setISOWeekYear_default = setISOWeekYear;

// .beyond/uimport/temp/date-fns/setISOWeekYear.3.6.0.js
var setISOWeekYear_3_6_0_default = setISOWeekYear_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3NldElTT1dlZWtZZWFyLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL3NldElTT1dlZWtZZWFyLm1qcyJdLCJuYW1lcyI6WyJzZXRJU09XZWVrWWVhcl8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0Iiwic2V0SVNPV2Vla1llYXJfM182XzBfZGVmYXVsdCIsInNldElTT1dlZWtZZWFyIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF9jb25zdHJ1Y3RGcm9tIiwicmVxdWlyZSIsImltcG9ydF9kaWZmZXJlbmNlSW5DYWxlbmRhckRheXMiLCJpbXBvcnRfc3RhcnRPZklTT1dlZWtZZWFyIiwiaW1wb3J0X3RvRGF0ZSIsImRhdGUiLCJ3ZWVrWWVhciIsIl9kYXRlIiwidG9EYXRlIiwiZGlmZiIsImRpZmZlcmVuY2VJbkNhbGVuZGFyRGF5cyIsInN0YXJ0T2ZJU09XZWVrWWVhciIsImZvdXJ0aE9mSmFudWFyeSIsImNvbnN0cnVjdEZyb20iLCJzZXRGdWxsWWVhciIsInNldEhvdXJzIiwic2V0RGF0ZSIsImdldERhdGUiLCJzZXRJU09XZWVrWWVhcl9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSw0QkFBQTtBQUFBQyxRQUFBLENBQUFELDRCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyw0QkFBQTtFQUFBQyxjQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCw0QkFBQTs7O0FDQUEsSUFBQVEsb0JBQUEsR0FBOEJDLE9BQUE7QUFDOUIsSUFBQUMsK0JBQUEsR0FBeUNELE9BQUE7QUFDekMsSUFBQUUseUJBQUEsR0FBbUNGLE9BQUE7QUFDbkMsSUFBQUcsYUFBQSxHQUF1QkgsT0FBQTtBQXlCaEIsU0FBU0wsZUFBZVMsSUFBQSxFQUFNQyxRQUFBLEVBQVU7RUFDN0MsSUFBSUMsS0FBQSxPQUFRSCxhQUFBLENBQUFJLE1BQUEsRUFBT0gsSUFBSTtFQUN2QixNQUFNSSxJQUFBLE9BQU9QLCtCQUFBLENBQUFRLHdCQUFBLEVBQXlCSCxLQUFBLE1BQU9KLHlCQUFBLENBQUFRLGtCQUFBLEVBQW1CSixLQUFLLENBQUM7RUFDdEUsTUFBTUssZUFBQSxPQUFrQlosb0JBQUEsQ0FBQWEsYUFBQSxFQUFjUixJQUFBLEVBQU0sQ0FBQztFQUM3Q08sZUFBQSxDQUFnQkUsV0FBQSxDQUFZUixRQUFBLEVBQVUsR0FBRyxDQUFDO0VBQzFDTSxlQUFBLENBQWdCRyxRQUFBLENBQVMsR0FBRyxHQUFHLEdBQUcsQ0FBQztFQUNuQ1IsS0FBQSxPQUFRSix5QkFBQSxDQUFBUSxrQkFBQSxFQUFtQkMsZUFBZTtFQUMxQ0wsS0FBQSxDQUFNUyxPQUFBLENBQVFULEtBQUEsQ0FBTVUsT0FBQSxDQUFRLElBQUlSLElBQUk7RUFDcEMsT0FBT0YsS0FBQTtBQUNUO0FBR0EsSUFBT1csc0JBQUEsR0FBUXRCLGNBQUE7OztBRHJDZixJQUFPRCw0QkFBQSxHQUFRdUIsc0JBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=