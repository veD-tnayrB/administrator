System.register(["date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/startOfDay.3.6.0.js
var startOfDay_3_6_0_exports = {};
__export(startOfDay_3_6_0_exports, {
  default: () => startOfDay_3_6_0_default,
  startOfDay: () => startOfDay
});
module.exports = __toCommonJS(startOfDay_3_6_0_exports);

// node_modules/date-fns/startOfDay.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function startOfDay(date) {
  const _date = (0, import_toDate.toDate)(date);
  _date.setHours(0, 0, 0, 0);
  return _date;
}
var startOfDay_default = startOfDay;

// .beyond/uimport/temp/date-fns/startOfDay.3.6.0.js
var startOfDay_3_6_0_default = startOfDay_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3N0YXJ0T2ZEYXkuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvc3RhcnRPZkRheS5tanMiXSwibmFtZXMiOlsic3RhcnRPZkRheV8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0Iiwic3RhcnRPZkRheV8zXzZfMF9kZWZhdWx0Iiwic3RhcnRPZkRheSIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfdG9EYXRlIiwicmVxdWlyZSIsImRhdGUiLCJfZGF0ZSIsInRvRGF0ZSIsInNldEhvdXJzIiwic3RhcnRPZkRheV9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSx3QkFBQTtBQUFBQyxRQUFBLENBQUFELHdCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyx3QkFBQTtFQUFBQyxVQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCx3QkFBQTs7O0FDQUEsSUFBQVEsYUFBQSxHQUF1QkMsT0FBQTtBQXNCaEIsU0FBU0wsV0FBV00sSUFBQSxFQUFNO0VBQy9CLE1BQU1DLEtBQUEsT0FBUUgsYUFBQSxDQUFBSSxNQUFBLEVBQU9GLElBQUk7RUFDekJDLEtBQUEsQ0FBTUUsUUFBQSxDQUFTLEdBQUcsR0FBRyxHQUFHLENBQUM7RUFDekIsT0FBT0YsS0FBQTtBQUNUO0FBR0EsSUFBT0csa0JBQUEsR0FBUVYsVUFBQTs7O0FEMUJmLElBQU9ELHdCQUFBLEdBQVFXLGtCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9