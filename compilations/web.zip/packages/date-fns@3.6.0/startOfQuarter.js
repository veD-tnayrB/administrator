System.register(["date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/startOfQuarter.3.6.0.js
var startOfQuarter_3_6_0_exports = {};
__export(startOfQuarter_3_6_0_exports, {
  default: () => startOfQuarter_3_6_0_default,
  startOfQuarter: () => startOfQuarter
});
module.exports = __toCommonJS(startOfQuarter_3_6_0_exports);

// node_modules/date-fns/startOfQuarter.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function startOfQuarter(date) {
  const _date = (0, import_toDate.toDate)(date);
  const currentMonth = _date.getMonth();
  const month = currentMonth - currentMonth % 3;
  _date.setMonth(month, 1);
  _date.setHours(0, 0, 0, 0);
  return _date;
}
var startOfQuarter_default = startOfQuarter;

// .beyond/uimport/temp/date-fns/startOfQuarter.3.6.0.js
var startOfQuarter_3_6_0_default = startOfQuarter_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3N0YXJ0T2ZRdWFydGVyLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL3N0YXJ0T2ZRdWFydGVyLm1qcyJdLCJuYW1lcyI6WyJzdGFydE9mUXVhcnRlcl8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0Iiwic3RhcnRPZlF1YXJ0ZXJfM182XzBfZGVmYXVsdCIsInN0YXJ0T2ZRdWFydGVyIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF90b0RhdGUiLCJyZXF1aXJlIiwiZGF0ZSIsIl9kYXRlIiwidG9EYXRlIiwiY3VycmVudE1vbnRoIiwiZ2V0TW9udGgiLCJtb250aCIsInNldE1vbnRoIiwic2V0SG91cnMiLCJzdGFydE9mUXVhcnRlcl9kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSw0QkFBQTtBQUFBQyxRQUFBLENBQUFELDRCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyw0QkFBQTtFQUFBQyxjQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCw0QkFBQTs7O0FDQUEsSUFBQVEsYUFBQSxHQUF1QkMsT0FBQTtBQXNCaEIsU0FBU0wsZUFBZU0sSUFBQSxFQUFNO0VBQ25DLE1BQU1DLEtBQUEsT0FBUUgsYUFBQSxDQUFBSSxNQUFBLEVBQU9GLElBQUk7RUFDekIsTUFBTUcsWUFBQSxHQUFlRixLQUFBLENBQU1HLFFBQUEsQ0FBUztFQUNwQyxNQUFNQyxLQUFBLEdBQVFGLFlBQUEsR0FBZ0JBLFlBQUEsR0FBZTtFQUM3Q0YsS0FBQSxDQUFNSyxRQUFBLENBQVNELEtBQUEsRUFBTyxDQUFDO0VBQ3ZCSixLQUFBLENBQU1NLFFBQUEsQ0FBUyxHQUFHLEdBQUcsR0FBRyxDQUFDO0VBQ3pCLE9BQU9OLEtBQUE7QUFDVDtBQUdBLElBQU9PLHNCQUFBLEdBQVFkLGNBQUE7OztBRDdCZixJQUFPRCw0QkFBQSxHQUFRZSxzQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==