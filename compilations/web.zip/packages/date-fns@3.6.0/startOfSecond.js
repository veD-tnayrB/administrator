System.register(["date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/startOfSecond.3.6.0.js
var startOfSecond_3_6_0_exports = {};
__export(startOfSecond_3_6_0_exports, {
  default: () => startOfSecond_3_6_0_default,
  startOfSecond: () => startOfSecond
});
module.exports = __toCommonJS(startOfSecond_3_6_0_exports);

// node_modules/date-fns/startOfSecond.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function startOfSecond(date) {
  const _date = (0, import_toDate.toDate)(date);
  _date.setMilliseconds(0);
  return _date;
}
var startOfSecond_default = startOfSecond;

// .beyond/uimport/temp/date-fns/startOfSecond.3.6.0.js
var startOfSecond_3_6_0_default = startOfSecond_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3N0YXJ0T2ZTZWNvbmQuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvc3RhcnRPZlNlY29uZC5tanMiXSwibmFtZXMiOlsic3RhcnRPZlNlY29uZF8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0Iiwic3RhcnRPZlNlY29uZF8zXzZfMF9kZWZhdWx0Iiwic3RhcnRPZlNlY29uZCIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfdG9EYXRlIiwicmVxdWlyZSIsImRhdGUiLCJfZGF0ZSIsInRvRGF0ZSIsInNldE1pbGxpc2Vjb25kcyIsInN0YXJ0T2ZTZWNvbmRfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsMkJBQUE7QUFBQUMsUUFBQSxDQUFBRCwyQkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsMkJBQUE7RUFBQUMsYUFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsMkJBQUE7OztBQ0FBLElBQUFRLGFBQUEsR0FBdUJDLE9BQUE7QUFzQmhCLFNBQVNMLGNBQWNNLElBQUEsRUFBTTtFQUNsQyxNQUFNQyxLQUFBLE9BQVFILGFBQUEsQ0FBQUksTUFBQSxFQUFPRixJQUFJO0VBQ3pCQyxLQUFBLENBQU1FLGVBQUEsQ0FBZ0IsQ0FBQztFQUN2QixPQUFPRixLQUFBO0FBQ1Q7QUFHQSxJQUFPRyxxQkFBQSxHQUFRVixhQUFBOzs7QUQxQmYsSUFBT0QsMkJBQUEsR0FBUVcscUJBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=