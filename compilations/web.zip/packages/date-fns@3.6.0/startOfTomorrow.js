System.register([], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/startOfTomorrow.3.6.0.js
var startOfTomorrow_3_6_0_exports = {};
__export(startOfTomorrow_3_6_0_exports, {
  default: () => startOfTomorrow_3_6_0_default,
  startOfTomorrow: () => startOfTomorrow
});
module.exports = __toCommonJS(startOfTomorrow_3_6_0_exports);

// node_modules/date-fns/startOfTomorrow.mjs
function startOfTomorrow() {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();
  const day = now.getDate();
  const date = new Date(0);
  date.setFullYear(year, month, day + 1);
  date.setHours(0, 0, 0, 0);
  return date;
}
var startOfTomorrow_default = startOfTomorrow;

// .beyond/uimport/temp/date-fns/startOfTomorrow.3.6.0.js
var startOfTomorrow_3_6_0_default = startOfTomorrow_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3N0YXJ0T2ZUb21vcnJvdy4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9zdGFydE9mVG9tb3Jyb3cubWpzIl0sIm5hbWVzIjpbInN0YXJ0T2ZUb21vcnJvd18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0Iiwic3RhcnRPZlRvbW9ycm93XzNfNl8wX2RlZmF1bHQiLCJzdGFydE9mVG9tb3Jyb3ciLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwibm93IiwiRGF0ZSIsInllYXIiLCJnZXRGdWxsWWVhciIsIm1vbnRoIiwiZ2V0TW9udGgiLCJkYXkiLCJnZXREYXRlIiwiZGF0ZSIsInNldEZ1bGxZZWFyIiwic2V0SG91cnMiLCJzdGFydE9mVG9tb3Jyb3dfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsNkJBQUE7QUFBQUMsUUFBQSxDQUFBRCw2QkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsNkJBQUE7RUFBQUMsZUFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsNkJBQUE7OztBQ2dCTyxTQUFTSSxnQkFBQSxFQUFrQjtFQUNoQyxNQUFNSSxHQUFBLEdBQU0sSUFBSUMsSUFBQSxDQUFLO0VBQ3JCLE1BQU1DLElBQUEsR0FBT0YsR0FBQSxDQUFJRyxXQUFBLENBQVk7RUFDN0IsTUFBTUMsS0FBQSxHQUFRSixHQUFBLENBQUlLLFFBQUEsQ0FBUztFQUMzQixNQUFNQyxHQUFBLEdBQU1OLEdBQUEsQ0FBSU8sT0FBQSxDQUFRO0VBRXhCLE1BQU1DLElBQUEsR0FBTyxJQUFJUCxJQUFBLENBQUssQ0FBQztFQUN2Qk8sSUFBQSxDQUFLQyxXQUFBLENBQVlQLElBQUEsRUFBTUUsS0FBQSxFQUFPRSxHQUFBLEdBQU0sQ0FBQztFQUNyQ0UsSUFBQSxDQUFLRSxRQUFBLENBQVMsR0FBRyxHQUFHLEdBQUcsQ0FBQztFQUN4QixPQUFPRixJQUFBO0FBQ1Q7QUFHQSxJQUFPRyx1QkFBQSxHQUFRZixlQUFBOzs7QUQxQmYsSUFBT0QsNkJBQUEsR0FBUWdCLHVCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9