System.register(["date-fns@3.6.0/toDate"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/startOfWeek.3.6.0.js
var startOfWeek_3_6_0_exports = {};
__export(startOfWeek_3_6_0_exports, {
  default: () => startOfWeek_3_6_0_default,
  startOfWeek: () => startOfWeek
});
module.exports = __toCommonJS(startOfWeek_3_6_0_exports);

// node_modules/date-fns/_lib/defaultOptions.mjs
var defaultOptions = {};
function getDefaultOptions() {
  return defaultOptions;
}
function setDefaultOptions(newOptions) {
  defaultOptions = newOptions;
}

// node_modules/date-fns/startOfWeek.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
function startOfWeek(date, options) {
  const defaultOptions2 = getDefaultOptions();
  const weekStartsOn = options?.weekStartsOn ?? options?.locale?.options?.weekStartsOn ?? defaultOptions2.weekStartsOn ?? defaultOptions2.locale?.options?.weekStartsOn ?? 0;
  const _date = (0, import_toDate.toDate)(date);
  const day = _date.getDay();
  const diff = (day < weekStartsOn ? 7 : 0) + day - weekStartsOn;
  _date.setDate(_date.getDate() - diff);
  _date.setHours(0, 0, 0, 0);
  return _date;
}
var startOfWeek_default = startOfWeek;

// .beyond/uimport/temp/date-fns/startOfWeek.3.6.0.js
var startOfWeek_3_6_0_default = startOfWeek_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3N0YXJ0T2ZXZWVrLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL19saWIvZGVmYXVsdE9wdGlvbnMubWpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL3N0YXJ0T2ZXZWVrLm1qcyJdLCJuYW1lcyI6WyJzdGFydE9mV2Vla18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0Iiwic3RhcnRPZldlZWtfM182XzBfZGVmYXVsdCIsInN0YXJ0T2ZXZWVrIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImRlZmF1bHRPcHRpb25zIiwiZ2V0RGVmYXVsdE9wdGlvbnMiLCJzZXREZWZhdWx0T3B0aW9ucyIsIm5ld09wdGlvbnMiLCJpbXBvcnRfdG9EYXRlIiwicmVxdWlyZSIsImRhdGUiLCJvcHRpb25zIiwiZGVmYXVsdE9wdGlvbnMyIiwid2Vla1N0YXJ0c09uIiwibG9jYWxlIiwiX2RhdGUiLCJ0b0RhdGUiLCJkYXkiLCJnZXREYXkiLCJkaWZmIiwic2V0RGF0ZSIsImdldERhdGUiLCJzZXRIb3VycyIsInN0YXJ0T2ZXZWVrX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLHlCQUFBO0FBQUFDLFFBQUEsQ0FBQUQseUJBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLHlCQUFBO0VBQUFDLFdBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLHlCQUFBOzs7QUNBQSxJQUFJUSxjQUFBLEdBQWlCLENBQUM7QUFFZixTQUFTQyxrQkFBQSxFQUFvQjtFQUNsQyxPQUFPRCxjQUFBO0FBQ1Q7QUFFTyxTQUFTRSxrQkFBa0JDLFVBQUEsRUFBWTtFQUM1Q0gsY0FBQSxHQUFpQkcsVUFBQTtBQUNuQjs7O0FDUkEsSUFBQUMsYUFBQSxHQUF1QkMsT0FBQTtBQWlDaEIsU0FBU1QsWUFBWVUsSUFBQSxFQUFNQyxPQUFBLEVBQVM7RUFDekMsTUFBTUMsZUFBQSxHQUFpQlAsaUJBQUEsQ0FBa0I7RUFDekMsTUFBTVEsWUFBQSxHQUNKRixPQUFBLEVBQVNFLFlBQUEsSUFDVEYsT0FBQSxFQUFTRyxNQUFBLEVBQVFILE9BQUEsRUFBU0UsWUFBQSxJQUMxQkQsZUFBQSxDQUFlQyxZQUFBLElBQ2ZELGVBQUEsQ0FBZUUsTUFBQSxFQUFRSCxPQUFBLEVBQVNFLFlBQUEsSUFDaEM7RUFFRixNQUFNRSxLQUFBLE9BQVFQLGFBQUEsQ0FBQVEsTUFBQSxFQUFPTixJQUFJO0VBQ3pCLE1BQU1PLEdBQUEsR0FBTUYsS0FBQSxDQUFNRyxNQUFBLENBQU87RUFDekIsTUFBTUMsSUFBQSxJQUFRRixHQUFBLEdBQU1KLFlBQUEsR0FBZSxJQUFJLEtBQUtJLEdBQUEsR0FBTUosWUFBQTtFQUVsREUsS0FBQSxDQUFNSyxPQUFBLENBQVFMLEtBQUEsQ0FBTU0sT0FBQSxDQUFRLElBQUlGLElBQUk7RUFDcENKLEtBQUEsQ0FBTU8sUUFBQSxDQUFTLEdBQUcsR0FBRyxHQUFHLENBQUM7RUFDekIsT0FBT1AsS0FBQTtBQUNUO0FBR0EsSUFBT1EsbUJBQUEsR0FBUXZCLFdBQUE7OztBRmpEZixJQUFPRCx5QkFBQSxHQUFRd0IsbUJBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=