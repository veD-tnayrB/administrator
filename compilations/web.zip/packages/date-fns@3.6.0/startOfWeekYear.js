System.register(["date-fns@3.6.0/constructFrom","date-fns@3.6.0/toDate","date-fns@3.6.0/startOfWeek","date-fns@3.6.0/getWeekYear"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/startOfWeek', dep), dep => dependencies.set('date-fns@3.6.0/getWeekYear', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/startOfWeekYear.3.6.0.js
var startOfWeekYear_3_6_0_exports = {};
__export(startOfWeekYear_3_6_0_exports, {
  default: () => startOfWeekYear_3_6_0_default,
  startOfWeekYear: () => startOfWeekYear
});
module.exports = __toCommonJS(startOfWeekYear_3_6_0_exports);

// node_modules/date-fns/_lib/defaultOptions.mjs
var defaultOptions = {};
function getDefaultOptions() {
  return defaultOptions;
}
function setDefaultOptions(newOptions) {
  defaultOptions = newOptions;
}

// node_modules/date-fns/startOfWeekYear.mjs
var import_constructFrom = require("date-fns@3.6.0/constructFrom");
var import_getWeekYear = require("date-fns@3.6.0/getWeekYear");
var import_startOfWeek = require("date-fns@3.6.0/startOfWeek");
function startOfWeekYear(date, options) {
  const defaultOptions2 = getDefaultOptions();
  const firstWeekContainsDate = options?.firstWeekContainsDate ?? options?.locale?.options?.firstWeekContainsDate ?? defaultOptions2.firstWeekContainsDate ?? defaultOptions2.locale?.options?.firstWeekContainsDate ?? 1;
  const year = (0, import_getWeekYear.getWeekYear)(date, options);
  const firstWeek = (0, import_constructFrom.constructFrom)(date, 0);
  firstWeek.setFullYear(year, 0, firstWeekContainsDate);
  firstWeek.setHours(0, 0, 0, 0);
  const _date = (0, import_startOfWeek.startOfWeek)(firstWeek, options);
  return _date;
}
var startOfWeekYear_default = startOfWeekYear;

// .beyond/uimport/temp/date-fns/startOfWeekYear.3.6.0.js
var startOfWeekYear_3_6_0_default = startOfWeekYear_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3N0YXJ0T2ZXZWVrWWVhci4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9fbGliL2RlZmF1bHRPcHRpb25zLm1qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9zdGFydE9mV2Vla1llYXIubWpzIl0sIm5hbWVzIjpbInN0YXJ0T2ZXZWVrWWVhcl8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0Iiwic3RhcnRPZldlZWtZZWFyXzNfNl8wX2RlZmF1bHQiLCJzdGFydE9mV2Vla1llYXIiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiZGVmYXVsdE9wdGlvbnMiLCJnZXREZWZhdWx0T3B0aW9ucyIsInNldERlZmF1bHRPcHRpb25zIiwibmV3T3B0aW9ucyIsImltcG9ydF9jb25zdHJ1Y3RGcm9tIiwicmVxdWlyZSIsImltcG9ydF9nZXRXZWVrWWVhciIsImltcG9ydF9zdGFydE9mV2VlayIsImRhdGUiLCJvcHRpb25zIiwiZGVmYXVsdE9wdGlvbnMyIiwiZmlyc3RXZWVrQ29udGFpbnNEYXRlIiwibG9jYWxlIiwieWVhciIsImdldFdlZWtZZWFyIiwiZmlyc3RXZWVrIiwiY29uc3RydWN0RnJvbSIsInNldEZ1bGxZZWFyIiwic2V0SG91cnMiLCJfZGF0ZSIsInN0YXJ0T2ZXZWVrIiwic3RhcnRPZldlZWtZZWFyX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLDZCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsNkJBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLDZCQUFBO0VBQUFDLGVBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLDZCQUFBOzs7QUNBQSxJQUFJUSxjQUFBLEdBQWlCLENBQUM7QUFFZixTQUFTQyxrQkFBQSxFQUFvQjtFQUNsQyxPQUFPRCxjQUFBO0FBQ1Q7QUFFTyxTQUFTRSxrQkFBa0JDLFVBQUEsRUFBWTtFQUM1Q0gsY0FBQSxHQUFpQkcsVUFBQTtBQUNuQjs7O0FDUkEsSUFBQUMsb0JBQUEsR0FBOEJDLE9BQUE7QUFDOUIsSUFBQUMsa0JBQUEsR0FBNEJELE9BQUE7QUFDNUIsSUFBQUUsa0JBQUEsR0FBNEJGLE9BQUE7QUEyQ3JCLFNBQVNULGdCQUFnQlksSUFBQSxFQUFNQyxPQUFBLEVBQVM7RUFDN0MsTUFBTUMsZUFBQSxHQUFpQlQsaUJBQUEsQ0FBa0I7RUFDekMsTUFBTVUscUJBQUEsR0FDSkYsT0FBQSxFQUFTRSxxQkFBQSxJQUNURixPQUFBLEVBQVNHLE1BQUEsRUFBUUgsT0FBQSxFQUFTRSxxQkFBQSxJQUMxQkQsZUFBQSxDQUFlQyxxQkFBQSxJQUNmRCxlQUFBLENBQWVFLE1BQUEsRUFBUUgsT0FBQSxFQUFTRSxxQkFBQSxJQUNoQztFQUVGLE1BQU1FLElBQUEsT0FBT1Asa0JBQUEsQ0FBQVEsV0FBQSxFQUFZTixJQUFBLEVBQU1DLE9BQU87RUFDdEMsTUFBTU0sU0FBQSxPQUFZWCxvQkFBQSxDQUFBWSxhQUFBLEVBQWNSLElBQUEsRUFBTSxDQUFDO0VBQ3ZDTyxTQUFBLENBQVVFLFdBQUEsQ0FBWUosSUFBQSxFQUFNLEdBQUdGLHFCQUFxQjtFQUNwREksU0FBQSxDQUFVRyxRQUFBLENBQVMsR0FBRyxHQUFHLEdBQUcsQ0FBQztFQUM3QixNQUFNQyxLQUFBLE9BQVFaLGtCQUFBLENBQUFhLFdBQUEsRUFBWUwsU0FBQSxFQUFXTixPQUFPO0VBQzVDLE9BQU9VLEtBQUE7QUFDVDtBQUdBLElBQU9FLHVCQUFBLEdBQVF6QixlQUFBOzs7QUY1RGYsSUFBT0QsNkJBQUEsR0FBUTBCLHVCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9