System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/constructFrom"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/startOfYear.3.6.0.js
var startOfYear_3_6_0_exports = {};
__export(startOfYear_3_6_0_exports, {
  default: () => startOfYear_3_6_0_default,
  startOfYear: () => startOfYear
});
module.exports = __toCommonJS(startOfYear_3_6_0_exports);

// node_modules/date-fns/startOfYear.mjs
var import_toDate = require("date-fns@3.6.0/toDate");
var import_constructFrom = require("date-fns@3.6.0/constructFrom");
function startOfYear(date) {
  const cleanDate = (0, import_toDate.toDate)(date);
  const _date = (0, import_constructFrom.constructFrom)(date, 0);
  _date.setFullYear(cleanDate.getFullYear(), 0, 1);
  _date.setHours(0, 0, 0, 0);
  return _date;
}
var startOfYear_default = startOfYear;

// .beyond/uimport/temp/date-fns/startOfYear.3.6.0.js
var startOfYear_3_6_0_default = startOfYear_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3N0YXJ0T2ZZZWFyLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL3N0YXJ0T2ZZZWFyLm1qcyJdLCJuYW1lcyI6WyJzdGFydE9mWWVhcl8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0Iiwic3RhcnRPZlllYXJfM182XzBfZGVmYXVsdCIsInN0YXJ0T2ZZZWFyIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF90b0RhdGUiLCJyZXF1aXJlIiwiaW1wb3J0X2NvbnN0cnVjdEZyb20iLCJkYXRlIiwiY2xlYW5EYXRlIiwidG9EYXRlIiwiX2RhdGUiLCJjb25zdHJ1Y3RGcm9tIiwic2V0RnVsbFllYXIiLCJnZXRGdWxsWWVhciIsInNldEhvdXJzIiwic3RhcnRPZlllYXJfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEseUJBQUE7QUFBQUMsUUFBQSxDQUFBRCx5QkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMseUJBQUE7RUFBQUMsV0FBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAseUJBQUE7OztBQ0FBLElBQUFRLGFBQUEsR0FBdUJDLE9BQUE7QUFDdkIsSUFBQUMsb0JBQUEsR0FBOEJELE9BQUE7QUFzQnZCLFNBQVNMLFlBQVlPLElBQUEsRUFBTTtFQUNoQyxNQUFNQyxTQUFBLE9BQVlKLGFBQUEsQ0FBQUssTUFBQSxFQUFPRixJQUFJO0VBQzdCLE1BQU1HLEtBQUEsT0FBUUosb0JBQUEsQ0FBQUssYUFBQSxFQUFjSixJQUFBLEVBQU0sQ0FBQztFQUNuQ0csS0FBQSxDQUFNRSxXQUFBLENBQVlKLFNBQUEsQ0FBVUssV0FBQSxDQUFZLEdBQUcsR0FBRyxDQUFDO0VBQy9DSCxLQUFBLENBQU1JLFFBQUEsQ0FBUyxHQUFHLEdBQUcsR0FBRyxDQUFDO0VBQ3pCLE9BQU9KLEtBQUE7QUFDVDtBQUdBLElBQU9LLG1CQUFBLEdBQVFmLFdBQUE7OztBRDdCZixJQUFPRCx5QkFBQSxHQUFRZ0IsbUJBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=