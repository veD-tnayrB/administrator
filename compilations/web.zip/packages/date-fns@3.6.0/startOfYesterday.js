System.register([], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/startOfYesterday.3.6.0.js
var startOfYesterday_3_6_0_exports = {};
__export(startOfYesterday_3_6_0_exports, {
  default: () => startOfYesterday_3_6_0_default,
  startOfYesterday: () => startOfYesterday
});
module.exports = __toCommonJS(startOfYesterday_3_6_0_exports);

// node_modules/date-fns/startOfYesterday.mjs
function startOfYesterday() {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();
  const day = now.getDate();
  const date = new Date(0);
  date.setFullYear(year, month, day - 1);
  date.setHours(0, 0, 0, 0);
  return date;
}
var startOfYesterday_default = startOfYesterday;

// .beyond/uimport/temp/date-fns/startOfYesterday.3.6.0.js
var startOfYesterday_3_6_0_default = startOfYesterday_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3N0YXJ0T2ZZZXN0ZXJkYXkuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMvc3RhcnRPZlllc3RlcmRheS5tanMiXSwibmFtZXMiOlsic3RhcnRPZlllc3RlcmRheV8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0Iiwic3RhcnRPZlllc3RlcmRheV8zXzZfMF9kZWZhdWx0Iiwic3RhcnRPZlllc3RlcmRheSIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJub3ciLCJEYXRlIiwieWVhciIsImdldEZ1bGxZZWFyIiwibW9udGgiLCJnZXRNb250aCIsImRheSIsImdldERhdGUiLCJkYXRlIiwic2V0RnVsbFllYXIiLCJzZXRIb3VycyIsInN0YXJ0T2ZZZXN0ZXJkYXlfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsOEJBQUE7QUFBQUMsUUFBQSxDQUFBRCw4QkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsOEJBQUE7RUFBQUMsZ0JBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLDhCQUFBOzs7QUNnQk8sU0FBU0ksaUJBQUEsRUFBbUI7RUFDakMsTUFBTUksR0FBQSxHQUFNLElBQUlDLElBQUEsQ0FBSztFQUNyQixNQUFNQyxJQUFBLEdBQU9GLEdBQUEsQ0FBSUcsV0FBQSxDQUFZO0VBQzdCLE1BQU1DLEtBQUEsR0FBUUosR0FBQSxDQUFJSyxRQUFBLENBQVM7RUFDM0IsTUFBTUMsR0FBQSxHQUFNTixHQUFBLENBQUlPLE9BQUEsQ0FBUTtFQUV4QixNQUFNQyxJQUFBLEdBQU8sSUFBSVAsSUFBQSxDQUFLLENBQUM7RUFDdkJPLElBQUEsQ0FBS0MsV0FBQSxDQUFZUCxJQUFBLEVBQU1FLEtBQUEsRUFBT0UsR0FBQSxHQUFNLENBQUM7RUFDckNFLElBQUEsQ0FBS0UsUUFBQSxDQUFTLEdBQUcsR0FBRyxHQUFHLENBQUM7RUFDeEIsT0FBT0YsSUFBQTtBQUNUO0FBR0EsSUFBT0csd0JBQUEsR0FBUWYsZ0JBQUE7OztBRDFCZixJQUFPRCw4QkFBQSxHQUFRZ0Isd0JBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=