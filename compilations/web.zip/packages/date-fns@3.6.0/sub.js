System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/constructFrom","date-fns@3.6.0/addDays","date-fns@3.6.0/subDays","date-fns@3.6.0/addMonths","date-fns@3.6.0/subMonths"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/addDays', dep), dep => dependencies.set('date-fns@3.6.0/subDays', dep), dep => dependencies.set('date-fns@3.6.0/addMonths', dep), dep => dependencies.set('date-fns@3.6.0/subMonths', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/sub.3.6.0.js
var sub_3_6_0_exports = {};
__export(sub_3_6_0_exports, {
  default: () => sub_3_6_0_default,
  sub: () => sub
});
module.exports = __toCommonJS(sub_3_6_0_exports);

// node_modules/date-fns/sub.mjs
var import_subDays = require("date-fns@3.6.0/subDays");
var import_subMonths = require("date-fns@3.6.0/subMonths");
var import_constructFrom = require("date-fns@3.6.0/constructFrom");
function sub(date, duration) {
  const {
    years = 0,
    months = 0,
    weeks = 0,
    days = 0,
    hours = 0,
    minutes = 0,
    seconds = 0
  } = duration;
  const dateWithoutMonths = (0, import_subMonths.subMonths)(date, months + years * 12);
  const dateWithoutDays = (0, import_subDays.subDays)(dateWithoutMonths, days + weeks * 7);
  const minutestoSub = minutes + hours * 60;
  const secondstoSub = seconds + minutestoSub * 60;
  const mstoSub = secondstoSub * 1e3;
  const finalDate = (0, import_constructFrom.constructFrom)(date, dateWithoutDays.getTime() - mstoSub);
  return finalDate;
}
var sub_default = sub;

// .beyond/uimport/temp/date-fns/sub.3.6.0.js
var sub_3_6_0_default = sub_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3N1Yi4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9zdWIubWpzIl0sIm5hbWVzIjpbInN1Yl8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0Iiwic3ViXzNfNl8wX2RlZmF1bHQiLCJzdWIiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X3N1YkRheXMiLCJyZXF1aXJlIiwiaW1wb3J0X3N1Yk1vbnRocyIsImltcG9ydF9jb25zdHJ1Y3RGcm9tIiwiZGF0ZSIsImR1cmF0aW9uIiwieWVhcnMiLCJtb250aHMiLCJ3ZWVrcyIsImRheXMiLCJob3VycyIsIm1pbnV0ZXMiLCJzZWNvbmRzIiwiZGF0ZVdpdGhvdXRNb250aHMiLCJzdWJNb250aHMiLCJkYXRlV2l0aG91dERheXMiLCJzdWJEYXlzIiwibWludXRlc3RvU3ViIiwic2Vjb25kc3RvU3ViIiwibXN0b1N1YiIsImZpbmFsRGF0ZSIsImNvbnN0cnVjdEZyb20iLCJnZXRUaW1lIiwic3ViX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLGlCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsaUJBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLGlCQUFBO0VBQUFDLEdBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLGlCQUFBOzs7QUNBQSxJQUFBUSxjQUFBLEdBQXdCQyxPQUFBO0FBQ3hCLElBQUFDLGdCQUFBLEdBQTBCRCxPQUFBO0FBQzFCLElBQUFFLG9CQUFBLEdBQThCRixPQUFBO0FBMEN2QixTQUFTTCxJQUFJUSxJQUFBLEVBQU1DLFFBQUEsRUFBVTtFQUNsQyxNQUFNO0lBQ0pDLEtBQUEsR0FBUTtJQUNSQyxNQUFBLEdBQVM7SUFDVEMsS0FBQSxHQUFRO0lBQ1JDLElBQUEsR0FBTztJQUNQQyxLQUFBLEdBQVE7SUFDUkMsT0FBQSxHQUFVO0lBQ1ZDLE9BQUEsR0FBVTtFQUNaLElBQUlQLFFBQUE7RUFHSixNQUFNUSxpQkFBQSxPQUFvQlgsZ0JBQUEsQ0FBQVksU0FBQSxFQUFVVixJQUFBLEVBQU1HLE1BQUEsR0FBU0QsS0FBQSxHQUFRLEVBQUU7RUFHN0QsTUFBTVMsZUFBQSxPQUFrQmYsY0FBQSxDQUFBZ0IsT0FBQSxFQUFRSCxpQkFBQSxFQUFtQkosSUFBQSxHQUFPRCxLQUFBLEdBQVEsQ0FBQztFQUduRSxNQUFNUyxZQUFBLEdBQWVOLE9BQUEsR0FBVUQsS0FBQSxHQUFRO0VBQ3ZDLE1BQU1RLFlBQUEsR0FBZU4sT0FBQSxHQUFVSyxZQUFBLEdBQWU7RUFDOUMsTUFBTUUsT0FBQSxHQUFVRCxZQUFBLEdBQWU7RUFDL0IsTUFBTUUsU0FBQSxPQUFZakIsb0JBQUEsQ0FBQWtCLGFBQUEsRUFBY2pCLElBQUEsRUFBTVcsZUFBQSxDQUFnQk8sT0FBQSxDQUFRLElBQUlILE9BQU87RUFFekUsT0FBT0MsU0FBQTtBQUNUO0FBR0EsSUFBT0csV0FBQSxHQUFRM0IsR0FBQTs7O0FEcEVmLElBQU9ELGlCQUFBLEdBQVE0QixXQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9