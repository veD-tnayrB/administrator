System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/constructFrom","date-fns@3.6.0/addMonths"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/addMonths', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/subMonths.3.6.0.js
var subMonths_3_6_0_exports = {};
__export(subMonths_3_6_0_exports, {
  default: () => subMonths_3_6_0_default,
  subMonths: () => subMonths
});
module.exports = __toCommonJS(subMonths_3_6_0_exports);

// node_modules/date-fns/subMonths.mjs
var import_addMonths = require("date-fns@3.6.0/addMonths");
function subMonths(date, amount) {
  return (0, import_addMonths.addMonths)(date, -amount);
}
var subMonths_default = subMonths;

// .beyond/uimport/temp/date-fns/subMonths.3.6.0.js
var subMonths_3_6_0_default = subMonths_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3N1Yk1vbnRocy4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy9zdWJNb250aHMubWpzIl0sIm5hbWVzIjpbInN1Yk1vbnRoc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0Iiwic3ViTW9udGhzXzNfNl8wX2RlZmF1bHQiLCJzdWJNb250aHMiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2FkZE1vbnRocyIsInJlcXVpcmUiLCJkYXRlIiwiYW1vdW50IiwiYWRkTW9udGhzIiwic3ViTW9udGhzX2RlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLHVCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsdUJBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDLHVCQUFBO0VBQUFDLFNBQUEsRUFBQUEsQ0FBQSxLQUFBQTtBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLHVCQUFBOzs7QUNBQSxJQUFBUSxnQkFBQSxHQUEwQkMsT0FBQTtBQXNCbkIsU0FBU0wsVUFBVU0sSUFBQSxFQUFNQyxNQUFBLEVBQVE7RUFDdEMsV0FBT0gsZ0JBQUEsQ0FBQUksU0FBQSxFQUFVRixJQUFBLEVBQU0sQ0FBQ0MsTUFBTTtBQUNoQztBQUdBLElBQU9FLGlCQUFBLEdBQVFULFNBQUE7OztBRHhCZixJQUFPRCx1QkFBQSxHQUFRVSxpQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==