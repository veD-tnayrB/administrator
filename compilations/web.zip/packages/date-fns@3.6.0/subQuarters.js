System.register(["date-fns@3.6.0/toDate","date-fns@3.6.0/constructFrom","date-fns@3.6.0/addMonths","date-fns@3.6.0/addQuarters"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/toDate', dep), dep => dependencies.set('date-fns@3.6.0/constructFrom', dep), dep => dependencies.set('date-fns@3.6.0/addMonths', dep), dep => dependencies.set('date-fns@3.6.0/addQuarters', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/subQuarters.3.6.0.js
var subQuarters_3_6_0_exports = {};
__export(subQuarters_3_6_0_exports, {
  default: () => subQuarters_3_6_0_default,
  subQuarters: () => subQuarters
});
module.exports = __toCommonJS(subQuarters_3_6_0_exports);

// node_modules/date-fns/subQuarters.mjs
var import_addQuarters = require("date-fns@3.6.0/addQuarters");
function subQuarters(date, amount) {
  return (0, import_addQuarters.addQuarters)(date, -amount);
}
var subQuarters_default = subQuarters;

// .beyond/uimport/temp/date-fns/subQuarters.3.6.0.js
var subQuarters_3_6_0_default = subQuarters_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3N1YlF1YXJ0ZXJzLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL3N1YlF1YXJ0ZXJzLm1qcyJdLCJuYW1lcyI6WyJzdWJRdWFydGVyc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0Iiwic3ViUXVhcnRlcnNfM182XzBfZGVmYXVsdCIsInN1YlF1YXJ0ZXJzIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF9hZGRRdWFydGVycyIsInJlcXVpcmUiLCJkYXRlIiwiYW1vdW50IiwiYWRkUXVhcnRlcnMiLCJzdWJRdWFydGVyc19kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSx5QkFBQTtBQUFBQyxRQUFBLENBQUFELHlCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQyx5QkFBQTtFQUFBQyxXQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCx5QkFBQTs7O0FDQUEsSUFBQVEsa0JBQUEsR0FBNEJDLE9BQUE7QUFzQnJCLFNBQVNMLFlBQVlNLElBQUEsRUFBTUMsTUFBQSxFQUFRO0VBQ3hDLFdBQU9ILGtCQUFBLENBQUFJLFdBQUEsRUFBWUYsSUFBQSxFQUFNLENBQUNDLE1BQU07QUFDbEM7QUFHQSxJQUFPRSxtQkFBQSxHQUFRVCxXQUFBOzs7QUR4QmYsSUFBT0QseUJBQUEsR0FBUVUsbUJBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=