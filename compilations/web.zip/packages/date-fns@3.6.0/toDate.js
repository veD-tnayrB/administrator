System.register([], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/toDate.3.6.0.js
var toDate_3_6_0_exports = {};
__export(toDate_3_6_0_exports, {
  default: () => toDate_3_6_0_default,
  toDate: () => toDate
});
module.exports = __toCommonJS(toDate_3_6_0_exports);

// node_modules/date-fns/toDate.mjs
function toDate(argument) {
  const argStr = Object.prototype.toString.call(argument);
  if (argument instanceof Date || typeof argument === "object" && argStr === "[object Date]") {
    return new argument.constructor(+argument);
  } else if (typeof argument === "number" || argStr === "[object Number]" || typeof argument === "string" || argStr === "[object String]") {
    return new Date(argument);
  } else {
    return new Date(NaN);
  }
}
var toDate_default = toDate;

// .beyond/uimport/temp/date-fns/toDate.3.6.0.js
var toDate_3_6_0_default = toDate_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3RvRGF0ZS4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy90b0RhdGUubWpzIl0sIm5hbWVzIjpbInRvRGF0ZV8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwidG9EYXRlXzNfNl8wX2RlZmF1bHQiLCJ0b0RhdGUiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiYXJndW1lbnQiLCJhcmdTdHIiLCJPYmplY3QiLCJwcm90b3R5cGUiLCJ0b1N0cmluZyIsImNhbGwiLCJEYXRlIiwiY29uc3RydWN0b3IiLCJOYU4iLCJ0b0RhdGVfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsb0JBQUE7QUFBQUMsUUFBQSxDQUFBRCxvQkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsb0JBQUE7RUFBQUMsTUFBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsb0JBQUE7OztBQ2dDTyxTQUFTSSxPQUFPSSxRQUFBLEVBQVU7RUFDL0IsTUFBTUMsTUFBQSxHQUFTQyxNQUFBLENBQU9DLFNBQUEsQ0FBVUMsUUFBQSxDQUFTQyxJQUFBLENBQUtMLFFBQVE7RUFHdEQsSUFDRUEsUUFBQSxZQUFvQk0sSUFBQSxJQUNuQixPQUFPTixRQUFBLEtBQWEsWUFBWUMsTUFBQSxLQUFXLGlCQUM1QztJQUVBLE9BQU8sSUFBSUQsUUFBQSxDQUFTTyxXQUFBLENBQVksQ0FBQ1AsUUFBUTtFQUMzQyxXQUNFLE9BQU9BLFFBQUEsS0FBYSxZQUNwQkMsTUFBQSxLQUFXLHFCQUNYLE9BQU9ELFFBQUEsS0FBYSxZQUNwQkMsTUFBQSxLQUFXLG1CQUNYO0lBRUEsT0FBTyxJQUFJSyxJQUFBLENBQUtOLFFBQVE7RUFDMUIsT0FBTztJQUVMLE9BQU8sSUFBSU0sSUFBQSxDQUFLRSxHQUFHO0VBQ3JCO0FBQ0Y7QUFHQSxJQUFPQyxjQUFBLEdBQVFiLE1BQUE7OztBRHREZixJQUFPRCxvQkFBQSxHQUFRYyxjQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9