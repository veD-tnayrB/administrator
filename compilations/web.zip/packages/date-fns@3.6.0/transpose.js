System.register(["date-fns@3.6.0/constructFrom"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constructFrom', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/transpose.3.6.0.js
var transpose_3_6_0_exports = {};
__export(transpose_3_6_0_exports, {
  default: () => transpose_3_6_0_default,
  transpose: () => transpose
});
module.exports = __toCommonJS(transpose_3_6_0_exports);

// node_modules/date-fns/transpose.mjs
var import_constructFrom = require("date-fns@3.6.0/constructFrom");
function transpose(fromDate, constructor) {
  const date = constructor instanceof Date ? (0, import_constructFrom.constructFrom)(constructor, 0) : new constructor(0);
  date.setFullYear(fromDate.getFullYear(), fromDate.getMonth(), fromDate.getDate());
  date.setHours(fromDate.getHours(), fromDate.getMinutes(), fromDate.getSeconds(), fromDate.getMilliseconds());
  return date;
}
var transpose_default = transpose;

// .beyond/uimport/temp/date-fns/transpose.3.6.0.js
var transpose_3_6_0_default = transpose_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3RyYW5zcG9zZS4zLjYuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9kYXRlLWZucy90cmFuc3Bvc2UubWpzIl0sIm5hbWVzIjpbInRyYW5zcG9zZV8zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwidHJhbnNwb3NlXzNfNl8wX2RlZmF1bHQiLCJ0cmFuc3Bvc2UiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiaW1wb3J0X2NvbnN0cnVjdEZyb20iLCJyZXF1aXJlIiwiZnJvbURhdGUiLCJjb25zdHJ1Y3RvciIsImRhdGUiLCJEYXRlIiwiY29uc3RydWN0RnJvbSIsInNldEZ1bGxZZWFyIiwiZ2V0RnVsbFllYXIiLCJnZXRNb250aCIsImdldERhdGUiLCJzZXRIb3VycyIsImdldEhvdXJzIiwiZ2V0TWludXRlcyIsImdldFNlY29uZHMiLCJnZXRNaWxsaXNlY29uZHMiLCJ0cmFuc3Bvc2VfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsdUJBQUE7QUFBQUMsUUFBQSxDQUFBRCx1QkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMsdUJBQUE7RUFBQUMsU0FBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAsdUJBQUE7OztBQ0FBLElBQUFRLG9CQUFBLEdBQThCQyxPQUFBO0FBOEJ2QixTQUFTTCxVQUFVTSxRQUFBLEVBQVVDLFdBQUEsRUFBYTtFQUMvQyxNQUFNQyxJQUFBLEdBQ0pELFdBQUEsWUFBdUJFLElBQUEsT0FDbkJMLG9CQUFBLENBQUFNLGFBQUEsRUFBY0gsV0FBQSxFQUFhLENBQUMsSUFDNUIsSUFBSUEsV0FBQSxDQUFZLENBQUM7RUFDdkJDLElBQUEsQ0FBS0csV0FBQSxDQUNITCxRQUFBLENBQVNNLFdBQUEsQ0FBWSxHQUNyQk4sUUFBQSxDQUFTTyxRQUFBLENBQVMsR0FDbEJQLFFBQUEsQ0FBU1EsT0FBQSxDQUFRLENBQ25CO0VBQ0FOLElBQUEsQ0FBS08sUUFBQSxDQUNIVCxRQUFBLENBQVNVLFFBQUEsQ0FBUyxHQUNsQlYsUUFBQSxDQUFTVyxVQUFBLENBQVcsR0FDcEJYLFFBQUEsQ0FBU1ksVUFBQSxDQUFXLEdBQ3BCWixRQUFBLENBQVNhLGVBQUEsQ0FBZ0IsQ0FDM0I7RUFDQSxPQUFPWCxJQUFBO0FBQ1Q7QUFHQSxJQUFPWSxpQkFBQSxHQUFRcEIsU0FBQTs7O0FEL0NmLElBQU9ELHVCQUFBLEdBQVFxQixpQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==