System.register(["date-fns@3.6.0/constants"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constants', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/yearsToDays.3.6.0.js
var yearsToDays_3_6_0_exports = {};
__export(yearsToDays_3_6_0_exports, {
  default: () => yearsToDays_3_6_0_default,
  yearsToDays: () => yearsToDays
});
module.exports = __toCommonJS(yearsToDays_3_6_0_exports);

// node_modules/date-fns/yearsToDays.mjs
var import_constants = require("date-fns@3.6.0/constants");
function yearsToDays(years) {
  return Math.trunc(years * import_constants.daysInYear);
}
var yearsToDays_default = yearsToDays;

// .beyond/uimport/temp/date-fns/yearsToDays.3.6.0.js
var yearsToDays_3_6_0_default = yearsToDays_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3llYXJzVG9EYXlzLjMuNi4wLmpzIiwiLi4vbm9kZV9tb2R1bGVzL2RhdGUtZm5zL3llYXJzVG9EYXlzLm1qcyJdLCJuYW1lcyI6WyJ5ZWFyc1RvRGF5c18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwieWVhcnNUb0RheXNfM182XzBfZGVmYXVsdCIsInllYXJzVG9EYXlzIiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImltcG9ydF9jb25zdGFudHMiLCJyZXF1aXJlIiwieWVhcnMiLCJNYXRoIiwidHJ1bmMiLCJkYXlzSW5ZZWFyIiwieWVhcnNUb0RheXNfZGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEseUJBQUE7QUFBQUMsUUFBQSxDQUFBRCx5QkFBQTtFQUFBRSxPQUFBLEVBQUFBLENBQUEsS0FBQUMseUJBQUE7RUFBQUMsV0FBQSxFQUFBQSxDQUFBLEtBQUFBO0FBQUE7QUFBQUMsTUFBQSxDQUFBQyxPQUFBLEdBQUFDLFlBQUEsQ0FBQVAseUJBQUE7OztBQ0FBLElBQUFRLGdCQUFBLEdBQTJCQyxPQUFBO0FBbUJwQixTQUFTTCxZQUFZTSxLQUFBLEVBQU87RUFDakMsT0FBT0MsSUFBQSxDQUFLQyxLQUFBLENBQU1GLEtBQUEsR0FBUUYsZ0JBQUEsQ0FBQUssVUFBVTtBQUN0QztBQUdBLElBQU9DLG1CQUFBLEdBQVFWLFdBQUE7OztBRHJCZixJQUFPRCx5QkFBQSxHQUFRVyxtQkFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==