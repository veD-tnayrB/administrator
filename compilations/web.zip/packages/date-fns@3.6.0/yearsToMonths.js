System.register(["date-fns@3.6.0/constants"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["date-fns","3.6.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('date-fns@3.6.0/constants', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/date-fns/yearsToMonths.3.6.0.js
var yearsToMonths_3_6_0_exports = {};
__export(yearsToMonths_3_6_0_exports, {
  default: () => yearsToMonths_3_6_0_default,
  yearsToMonths: () => yearsToMonths
});
module.exports = __toCommonJS(yearsToMonths_3_6_0_exports);

// node_modules/date-fns/yearsToMonths.mjs
var import_constants = require("date-fns@3.6.0/constants");
function yearsToMonths(years) {
  return Math.trunc(years * import_constants.monthsInYear);
}
var yearsToMonths_default = yearsToMonths;

// .beyond/uimport/temp/date-fns/yearsToMonths.3.6.0.js
var yearsToMonths_3_6_0_default = yearsToMonths_default;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL2RhdGUtZm5zL3llYXJzVG9Nb250aHMuMy42LjAuanMiLCIuLi9ub2RlX21vZHVsZXMvZGF0ZS1mbnMveWVhcnNUb01vbnRocy5tanMiXSwibmFtZXMiOlsieWVhcnNUb01vbnRoc18zXzZfMF9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwieWVhcnNUb01vbnRoc18zXzZfMF9kZWZhdWx0IiwieWVhcnNUb01vbnRocyIsIm1vZHVsZSIsImV4cG9ydHMiLCJfX3RvQ29tbW9uSlMiLCJpbXBvcnRfY29uc3RhbnRzIiwicmVxdWlyZSIsInllYXJzIiwiTWF0aCIsInRydW5jIiwibW9udGhzSW5ZZWFyIiwieWVhcnNUb01vbnRoc19kZWZhdWx0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSwyQkFBQTtBQUFBQyxRQUFBLENBQUFELDJCQUFBO0VBQUFFLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQywyQkFBQTtFQUFBQyxhQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBUCwyQkFBQTs7O0FDQUEsSUFBQVEsZ0JBQUEsR0FBNkJDLE9BQUE7QUFtQnRCLFNBQVNMLGNBQWNNLEtBQUEsRUFBTztFQUNuQyxPQUFPQyxJQUFBLENBQUtDLEtBQUEsQ0FBTUYsS0FBQSxHQUFRRixnQkFBQSxDQUFBSyxZQUFZO0FBQ3hDO0FBR0EsSUFBT0MscUJBQUEsR0FBUVYsYUFBQTs7O0FEckJmLElBQU9ELDJCQUFBLEdBQVFXLHFCQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvY2xpZW50L291dCJ9