System.register([], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["moment","2.30.1"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = {
    exports: {}
  }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
  value: mod,
  enumerable: true
}) : target, mod));
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// node_modules/moment/moment.js
var require_moment = __commonJS({
  "node_modules/moment/moment.js"(exports, module2) {
    ;
    (function (global, factory) {
      typeof exports === "object" && typeof module2 !== "undefined" ? module2.exports = factory() : typeof define === "function" && define.amd ? define(factory) : global.moment = factory();
    })(exports, function () {
      "use strict";

      var hookCallback;
      function hooks() {
        return hookCallback.apply(null, arguments);
      }
      function setHookCallback(callback) {
        hookCallback = callback;
      }
      function isArray(input) {
        return input instanceof Array || Object.prototype.toString.call(input) === "[object Array]";
      }
      function isObject(input) {
        return input != null && Object.prototype.toString.call(input) === "[object Object]";
      }
      function hasOwnProp(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b);
      }
      function isObjectEmpty(obj) {
        if (Object.getOwnPropertyNames) {
          return Object.getOwnPropertyNames(obj).length === 0;
        } else {
          var k;
          for (k in obj) {
            if (hasOwnProp(obj, k)) {
              return false;
            }
          }
          return true;
        }
      }
      function isUndefined(input) {
        return input === void 0;
      }
      function isNumber(input) {
        return typeof input === "number" || Object.prototype.toString.call(input) === "[object Number]";
      }
      function isDate(input) {
        return input instanceof Date || Object.prototype.toString.call(input) === "[object Date]";
      }
      function map(arr, fn) {
        var res = [],
          i,
          arrLen = arr.length;
        for (i = 0; i < arrLen; ++i) {
          res.push(fn(arr[i], i));
        }
        return res;
      }
      function extend(a, b) {
        for (var i in b) {
          if (hasOwnProp(b, i)) {
            a[i] = b[i];
          }
        }
        if (hasOwnProp(b, "toString")) {
          a.toString = b.toString;
        }
        if (hasOwnProp(b, "valueOf")) {
          a.valueOf = b.valueOf;
        }
        return a;
      }
      function createUTC(input, format2, locale2, strict) {
        return createLocalOrUTC(input, format2, locale2, strict, true).utc();
      }
      function defaultParsingFlags() {
        return {
          empty: false,
          unusedTokens: [],
          unusedInput: [],
          overflow: -2,
          charsLeftOver: 0,
          nullInput: false,
          invalidEra: null,
          invalidMonth: null,
          invalidFormat: false,
          userInvalidated: false,
          iso: false,
          parsedDateParts: [],
          era: null,
          meridiem: null,
          rfc2822: false,
          weekdayMismatch: false
        };
      }
      function getParsingFlags(m) {
        if (m._pf == null) {
          m._pf = defaultParsingFlags();
        }
        return m._pf;
      }
      var some;
      if (Array.prototype.some) {
        some = Array.prototype.some;
      } else {
        some = function (fun) {
          var t = Object(this),
            len = t.length >>> 0,
            i;
          for (i = 0; i < len; i++) {
            if (i in t && fun.call(this, t[i], i, t)) {
              return true;
            }
          }
          return false;
        };
      }
      function isValid(m) {
        var flags = null,
          parsedParts = false,
          isNowValid = m._d && !isNaN(m._d.getTime());
        if (isNowValid) {
          flags = getParsingFlags(m);
          parsedParts = some.call(flags.parsedDateParts, function (i) {
            return i != null;
          });
          isNowValid = flags.overflow < 0 && !flags.empty && !flags.invalidEra && !flags.invalidMonth && !flags.invalidWeekday && !flags.weekdayMismatch && !flags.nullInput && !flags.invalidFormat && !flags.userInvalidated && (!flags.meridiem || flags.meridiem && parsedParts);
          if (m._strict) {
            isNowValid = isNowValid && flags.charsLeftOver === 0 && flags.unusedTokens.length === 0 && flags.bigHour === void 0;
          }
        }
        if (Object.isFrozen == null || !Object.isFrozen(m)) {
          m._isValid = isNowValid;
        } else {
          return isNowValid;
        }
        return m._isValid;
      }
      function createInvalid(flags) {
        var m = createUTC(NaN);
        if (flags != null) {
          extend(getParsingFlags(m), flags);
        } else {
          getParsingFlags(m).userInvalidated = true;
        }
        return m;
      }
      var momentProperties = hooks.momentProperties = [],
        updateInProgress = false;
      function copyConfig(to2, from2) {
        var i,
          prop,
          val,
          momentPropertiesLen = momentProperties.length;
        if (!isUndefined(from2._isAMomentObject)) {
          to2._isAMomentObject = from2._isAMomentObject;
        }
        if (!isUndefined(from2._i)) {
          to2._i = from2._i;
        }
        if (!isUndefined(from2._f)) {
          to2._f = from2._f;
        }
        if (!isUndefined(from2._l)) {
          to2._l = from2._l;
        }
        if (!isUndefined(from2._strict)) {
          to2._strict = from2._strict;
        }
        if (!isUndefined(from2._tzm)) {
          to2._tzm = from2._tzm;
        }
        if (!isUndefined(from2._isUTC)) {
          to2._isUTC = from2._isUTC;
        }
        if (!isUndefined(from2._offset)) {
          to2._offset = from2._offset;
        }
        if (!isUndefined(from2._pf)) {
          to2._pf = getParsingFlags(from2);
        }
        if (!isUndefined(from2._locale)) {
          to2._locale = from2._locale;
        }
        if (momentPropertiesLen > 0) {
          for (i = 0; i < momentPropertiesLen; i++) {
            prop = momentProperties[i];
            val = from2[prop];
            if (!isUndefined(val)) {
              to2[prop] = val;
            }
          }
        }
        return to2;
      }
      function Moment(config) {
        copyConfig(this, config);
        this._d = new Date(config._d != null ? config._d.getTime() : NaN);
        if (!this.isValid()) {
          this._d = new Date(NaN);
        }
        if (updateInProgress === false) {
          updateInProgress = true;
          hooks.updateOffset(this);
          updateInProgress = false;
        }
      }
      function isMoment(obj) {
        return obj instanceof Moment || obj != null && obj._isAMomentObject != null;
      }
      function warn(msg) {
        if (hooks.suppressDeprecationWarnings === false && typeof console !== "undefined" && console.warn) {
          console.warn("Deprecation warning: " + msg);
        }
      }
      function deprecate(msg, fn) {
        var firstTime = true;
        return extend(function () {
          if (hooks.deprecationHandler != null) {
            hooks.deprecationHandler(null, msg);
          }
          if (firstTime) {
            var args = [],
              arg,
              i,
              key,
              argLen = arguments.length;
            for (i = 0; i < argLen; i++) {
              arg = "";
              if (typeof arguments[i] === "object") {
                arg += "\n[" + i + "] ";
                for (key in arguments[0]) {
                  if (hasOwnProp(arguments[0], key)) {
                    arg += key + ": " + arguments[0][key] + ", ";
                  }
                }
                arg = arg.slice(0, -2);
              } else {
                arg = arguments[i];
              }
              args.push(arg);
            }
            warn(msg + "\nArguments: " + Array.prototype.slice.call(args).join("") + "\n" + new Error().stack);
            firstTime = false;
          }
          return fn.apply(this, arguments);
        }, fn);
      }
      var deprecations = {};
      function deprecateSimple(name, msg) {
        if (hooks.deprecationHandler != null) {
          hooks.deprecationHandler(name, msg);
        }
        if (!deprecations[name]) {
          warn(msg);
          deprecations[name] = true;
        }
      }
      hooks.suppressDeprecationWarnings = false;
      hooks.deprecationHandler = null;
      function isFunction(input) {
        return typeof Function !== "undefined" && input instanceof Function || Object.prototype.toString.call(input) === "[object Function]";
      }
      function set(config) {
        var prop, i;
        for (i in config) {
          if (hasOwnProp(config, i)) {
            prop = config[i];
            if (isFunction(prop)) {
              this[i] = prop;
            } else {
              this["_" + i] = prop;
            }
          }
        }
        this._config = config;
        this._dayOfMonthOrdinalParseLenient = new RegExp((this._dayOfMonthOrdinalParse.source || this._ordinalParse.source) + "|" + /\d{1,2}/.source);
      }
      function mergeConfigs(parentConfig, childConfig) {
        var res = extend({}, parentConfig),
          prop;
        for (prop in childConfig) {
          if (hasOwnProp(childConfig, prop)) {
            if (isObject(parentConfig[prop]) && isObject(childConfig[prop])) {
              res[prop] = {};
              extend(res[prop], parentConfig[prop]);
              extend(res[prop], childConfig[prop]);
            } else if (childConfig[prop] != null) {
              res[prop] = childConfig[prop];
            } else {
              delete res[prop];
            }
          }
        }
        for (prop in parentConfig) {
          if (hasOwnProp(parentConfig, prop) && !hasOwnProp(childConfig, prop) && isObject(parentConfig[prop])) {
            res[prop] = extend({}, res[prop]);
          }
        }
        return res;
      }
      function Locale(config) {
        if (config != null) {
          this.set(config);
        }
      }
      var keys;
      if (Object.keys) {
        keys = Object.keys;
      } else {
        keys = function (obj) {
          var i,
            res = [];
          for (i in obj) {
            if (hasOwnProp(obj, i)) {
              res.push(i);
            }
          }
          return res;
        };
      }
      var defaultCalendar = {
        sameDay: "[Today at] LT",
        nextDay: "[Tomorrow at] LT",
        nextWeek: "dddd [at] LT",
        lastDay: "[Yesterday at] LT",
        lastWeek: "[Last] dddd [at] LT",
        sameElse: "L"
      };
      function calendar(key, mom, now2) {
        var output = this._calendar[key] || this._calendar["sameElse"];
        return isFunction(output) ? output.call(mom, now2) : output;
      }
      function zeroFill(number, targetLength, forceSign) {
        var absNumber = "" + Math.abs(number),
          zerosToFill = targetLength - absNumber.length,
          sign2 = number >= 0;
        return (sign2 ? forceSign ? "+" : "" : "-") + Math.pow(10, Math.max(0, zerosToFill)).toString().substr(1) + absNumber;
      }
      var formattingTokens = /(\[[^\[]*\])|(\\)?([Hh]mm(ss)?|Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|Qo?|N{1,5}|YYYYYY|YYYYY|YYYY|YY|y{2,4}|yo?|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|kk?|mm?|ss?|S{1,9}|x|X|zz?|ZZ?|.)/g,
        localFormattingTokens = /(\[[^\[]*\])|(\\)?(LTS|LT|LL?L?L?|l{1,4})/g,
        formatFunctions = {},
        formatTokenFunctions = {};
      function addFormatToken(token2, padded, ordinal2, callback) {
        var func = callback;
        if (typeof callback === "string") {
          func = function () {
            return this[callback]();
          };
        }
        if (token2) {
          formatTokenFunctions[token2] = func;
        }
        if (padded) {
          formatTokenFunctions[padded[0]] = function () {
            return zeroFill(func.apply(this, arguments), padded[1], padded[2]);
          };
        }
        if (ordinal2) {
          formatTokenFunctions[ordinal2] = function () {
            return this.localeData().ordinal(func.apply(this, arguments), token2);
          };
        }
      }
      function removeFormattingTokens(input) {
        if (input.match(/\[[\s\S]/)) {
          return input.replace(/^\[|\]$/g, "");
        }
        return input.replace(/\\/g, "");
      }
      function makeFormatFunction(format2) {
        var array = format2.match(formattingTokens),
          i,
          length;
        for (i = 0, length = array.length; i < length; i++) {
          if (formatTokenFunctions[array[i]]) {
            array[i] = formatTokenFunctions[array[i]];
          } else {
            array[i] = removeFormattingTokens(array[i]);
          }
        }
        return function (mom) {
          var output = "",
            i2;
          for (i2 = 0; i2 < length; i2++) {
            output += isFunction(array[i2]) ? array[i2].call(mom, format2) : array[i2];
          }
          return output;
        };
      }
      function formatMoment(m, format2) {
        if (!m.isValid()) {
          return m.localeData().invalidDate();
        }
        format2 = expandFormat(format2, m.localeData());
        formatFunctions[format2] = formatFunctions[format2] || makeFormatFunction(format2);
        return formatFunctions[format2](m);
      }
      function expandFormat(format2, locale2) {
        var i = 5;
        function replaceLongDateFormatTokens(input) {
          return locale2.longDateFormat(input) || input;
        }
        localFormattingTokens.lastIndex = 0;
        while (i >= 0 && localFormattingTokens.test(format2)) {
          format2 = format2.replace(localFormattingTokens, replaceLongDateFormatTokens);
          localFormattingTokens.lastIndex = 0;
          i -= 1;
        }
        return format2;
      }
      var defaultLongDateFormat = {
        LTS: "h:mm:ss A",
        LT: "h:mm A",
        L: "MM/DD/YYYY",
        LL: "MMMM D, YYYY",
        LLL: "MMMM D, YYYY h:mm A",
        LLLL: "dddd, MMMM D, YYYY h:mm A"
      };
      function longDateFormat(key) {
        var format2 = this._longDateFormat[key],
          formatUpper = this._longDateFormat[key.toUpperCase()];
        if (format2 || !formatUpper) {
          return format2;
        }
        this._longDateFormat[key] = formatUpper.match(formattingTokens).map(function (tok) {
          if (tok === "MMMM" || tok === "MM" || tok === "DD" || tok === "dddd") {
            return tok.slice(1);
          }
          return tok;
        }).join("");
        return this._longDateFormat[key];
      }
      var defaultInvalidDate = "Invalid date";
      function invalidDate() {
        return this._invalidDate;
      }
      var defaultOrdinal = "%d",
        defaultDayOfMonthOrdinalParse = /\d{1,2}/;
      function ordinal(number) {
        return this._ordinal.replace("%d", number);
      }
      var defaultRelativeTime = {
        future: "in %s",
        past: "%s ago",
        s: "a few seconds",
        ss: "%d seconds",
        m: "a minute",
        mm: "%d minutes",
        h: "an hour",
        hh: "%d hours",
        d: "a day",
        dd: "%d days",
        w: "a week",
        ww: "%d weeks",
        M: "a month",
        MM: "%d months",
        y: "a year",
        yy: "%d years"
      };
      function relativeTime(number, withoutSuffix, string, isFuture) {
        var output = this._relativeTime[string];
        return isFunction(output) ? output(number, withoutSuffix, string, isFuture) : output.replace(/%d/i, number);
      }
      function pastFuture(diff2, output) {
        var format2 = this._relativeTime[diff2 > 0 ? "future" : "past"];
        return isFunction(format2) ? format2(output) : format2.replace(/%s/i, output);
      }
      var aliases = {
        D: "date",
        dates: "date",
        date: "date",
        d: "day",
        days: "day",
        day: "day",
        e: "weekday",
        weekdays: "weekday",
        weekday: "weekday",
        E: "isoWeekday",
        isoweekdays: "isoWeekday",
        isoweekday: "isoWeekday",
        DDD: "dayOfYear",
        dayofyears: "dayOfYear",
        dayofyear: "dayOfYear",
        h: "hour",
        hours: "hour",
        hour: "hour",
        ms: "millisecond",
        milliseconds: "millisecond",
        millisecond: "millisecond",
        m: "minute",
        minutes: "minute",
        minute: "minute",
        M: "month",
        months: "month",
        month: "month",
        Q: "quarter",
        quarters: "quarter",
        quarter: "quarter",
        s: "second",
        seconds: "second",
        second: "second",
        gg: "weekYear",
        weekyears: "weekYear",
        weekyear: "weekYear",
        GG: "isoWeekYear",
        isoweekyears: "isoWeekYear",
        isoweekyear: "isoWeekYear",
        w: "week",
        weeks: "week",
        week: "week",
        W: "isoWeek",
        isoweeks: "isoWeek",
        isoweek: "isoWeek",
        y: "year",
        years: "year",
        year: "year"
      };
      function normalizeUnits(units) {
        return typeof units === "string" ? aliases[units] || aliases[units.toLowerCase()] : void 0;
      }
      function normalizeObjectUnits(inputObject) {
        var normalizedInput = {},
          normalizedProp,
          prop;
        for (prop in inputObject) {
          if (hasOwnProp(inputObject, prop)) {
            normalizedProp = normalizeUnits(prop);
            if (normalizedProp) {
              normalizedInput[normalizedProp] = inputObject[prop];
            }
          }
        }
        return normalizedInput;
      }
      var priorities = {
        date: 9,
        day: 11,
        weekday: 11,
        isoWeekday: 11,
        dayOfYear: 4,
        hour: 13,
        millisecond: 16,
        minute: 14,
        month: 8,
        quarter: 7,
        second: 15,
        weekYear: 1,
        isoWeekYear: 1,
        week: 5,
        isoWeek: 5,
        year: 1
      };
      function getPrioritizedUnits(unitsObj) {
        var units = [],
          u;
        for (u in unitsObj) {
          if (hasOwnProp(unitsObj, u)) {
            units.push({
              unit: u,
              priority: priorities[u]
            });
          }
        }
        units.sort(function (a, b) {
          return a.priority - b.priority;
        });
        return units;
      }
      var match1 = /\d/,
        match2 = /\d\d/,
        match3 = /\d{3}/,
        match4 = /\d{4}/,
        match6 = /[+-]?\d{6}/,
        match1to2 = /\d\d?/,
        match3to4 = /\d\d\d\d?/,
        match5to6 = /\d\d\d\d\d\d?/,
        match1to3 = /\d{1,3}/,
        match1to4 = /\d{1,4}/,
        match1to6 = /[+-]?\d{1,6}/,
        matchUnsigned = /\d+/,
        matchSigned = /[+-]?\d+/,
        matchOffset = /Z|[+-]\d\d:?\d\d/gi,
        matchShortOffset = /Z|[+-]\d\d(?::?\d\d)?/gi,
        matchTimestamp = /[+-]?\d+(\.\d{1,3})?/,
        matchWord = /[0-9]{0,256}['a-z\u00A0-\u05FF\u0700-\uD7FF\uF900-\uFDCF\uFDF0-\uFF07\uFF10-\uFFEF]{1,256}|[\u0600-\u06FF\/]{1,256}(\s*?[\u0600-\u06FF]{1,256}){1,2}/i,
        match1to2NoLeadingZero = /^[1-9]\d?/,
        match1to2HasZero = /^([1-9]\d|\d)/,
        regexes;
      regexes = {};
      function addRegexToken(token2, regex, strictRegex) {
        regexes[token2] = isFunction(regex) ? regex : function (isStrict, localeData2) {
          return isStrict && strictRegex ? strictRegex : regex;
        };
      }
      function getParseRegexForToken(token2, config) {
        if (!hasOwnProp(regexes, token2)) {
          return new RegExp(unescapeFormat(token2));
        }
        return regexes[token2](config._strict, config._locale);
      }
      function unescapeFormat(s) {
        return regexEscape(s.replace("\\", "").replace(/\\(\[)|\\(\])|\[([^\]\[]*)\]|\\(.)/g, function (matched, p1, p2, p3, p4) {
          return p1 || p2 || p3 || p4;
        }));
      }
      function regexEscape(s) {
        return s.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&");
      }
      function absFloor(number) {
        if (number < 0) {
          return Math.ceil(number) || 0;
        } else {
          return Math.floor(number);
        }
      }
      function toInt(argumentForCoercion) {
        var coercedNumber = +argumentForCoercion,
          value = 0;
        if (coercedNumber !== 0 && isFinite(coercedNumber)) {
          value = absFloor(coercedNumber);
        }
        return value;
      }
      var tokens = {};
      function addParseToken(token2, callback) {
        var i,
          func = callback,
          tokenLen;
        if (typeof token2 === "string") {
          token2 = [token2];
        }
        if (isNumber(callback)) {
          func = function (input, array) {
            array[callback] = toInt(input);
          };
        }
        tokenLen = token2.length;
        for (i = 0; i < tokenLen; i++) {
          tokens[token2[i]] = func;
        }
      }
      function addWeekParseToken(token2, callback) {
        addParseToken(token2, function (input, array, config, token3) {
          config._w = config._w || {};
          callback(input, config._w, config, token3);
        });
      }
      function addTimeToArrayFromToken(token2, input, config) {
        if (input != null && hasOwnProp(tokens, token2)) {
          tokens[token2](input, config._a, config, token2);
        }
      }
      function isLeapYear(year) {
        return year % 4 === 0 && year % 100 !== 0 || year % 400 === 0;
      }
      var YEAR = 0,
        MONTH = 1,
        DATE = 2,
        HOUR = 3,
        MINUTE = 4,
        SECOND = 5,
        MILLISECOND = 6,
        WEEK = 7,
        WEEKDAY = 8;
      addFormatToken("Y", 0, 0, function () {
        var y = this.year();
        return y <= 9999 ? zeroFill(y, 4) : "+" + y;
      });
      addFormatToken(0, ["YY", 2], 0, function () {
        return this.year() % 100;
      });
      addFormatToken(0, ["YYYY", 4], 0, "year");
      addFormatToken(0, ["YYYYY", 5], 0, "year");
      addFormatToken(0, ["YYYYYY", 6, true], 0, "year");
      addRegexToken("Y", matchSigned);
      addRegexToken("YY", match1to2, match2);
      addRegexToken("YYYY", match1to4, match4);
      addRegexToken("YYYYY", match1to6, match6);
      addRegexToken("YYYYYY", match1to6, match6);
      addParseToken(["YYYYY", "YYYYYY"], YEAR);
      addParseToken("YYYY", function (input, array) {
        array[YEAR] = input.length === 2 ? hooks.parseTwoDigitYear(input) : toInt(input);
      });
      addParseToken("YY", function (input, array) {
        array[YEAR] = hooks.parseTwoDigitYear(input);
      });
      addParseToken("Y", function (input, array) {
        array[YEAR] = parseInt(input, 10);
      });
      function daysInYear(year) {
        return isLeapYear(year) ? 366 : 365;
      }
      hooks.parseTwoDigitYear = function (input) {
        return toInt(input) + (toInt(input) > 68 ? 1900 : 2e3);
      };
      var getSetYear = makeGetSet("FullYear", true);
      function getIsLeapYear() {
        return isLeapYear(this.year());
      }
      function makeGetSet(unit, keepTime) {
        return function (value) {
          if (value != null) {
            set$1(this, unit, value);
            hooks.updateOffset(this, keepTime);
            return this;
          } else {
            return get(this, unit);
          }
        };
      }
      function get(mom, unit) {
        if (!mom.isValid()) {
          return NaN;
        }
        var d = mom._d,
          isUTC = mom._isUTC;
        switch (unit) {
          case "Milliseconds":
            return isUTC ? d.getUTCMilliseconds() : d.getMilliseconds();
          case "Seconds":
            return isUTC ? d.getUTCSeconds() : d.getSeconds();
          case "Minutes":
            return isUTC ? d.getUTCMinutes() : d.getMinutes();
          case "Hours":
            return isUTC ? d.getUTCHours() : d.getHours();
          case "Date":
            return isUTC ? d.getUTCDate() : d.getDate();
          case "Day":
            return isUTC ? d.getUTCDay() : d.getDay();
          case "Month":
            return isUTC ? d.getUTCMonth() : d.getMonth();
          case "FullYear":
            return isUTC ? d.getUTCFullYear() : d.getFullYear();
          default:
            return NaN;
        }
      }
      function set$1(mom, unit, value) {
        var d, isUTC, year, month, date;
        if (!mom.isValid() || isNaN(value)) {
          return;
        }
        d = mom._d;
        isUTC = mom._isUTC;
        switch (unit) {
          case "Milliseconds":
            return void (isUTC ? d.setUTCMilliseconds(value) : d.setMilliseconds(value));
          case "Seconds":
            return void (isUTC ? d.setUTCSeconds(value) : d.setSeconds(value));
          case "Minutes":
            return void (isUTC ? d.setUTCMinutes(value) : d.setMinutes(value));
          case "Hours":
            return void (isUTC ? d.setUTCHours(value) : d.setHours(value));
          case "Date":
            return void (isUTC ? d.setUTCDate(value) : d.setDate(value));
          case "FullYear":
            break;
          default:
            return;
        }
        year = value;
        month = mom.month();
        date = mom.date();
        date = date === 29 && month === 1 && !isLeapYear(year) ? 28 : date;
        void (isUTC ? d.setUTCFullYear(year, month, date) : d.setFullYear(year, month, date));
      }
      function stringGet(units) {
        units = normalizeUnits(units);
        if (isFunction(this[units])) {
          return this[units]();
        }
        return this;
      }
      function stringSet(units, value) {
        if (typeof units === "object") {
          units = normalizeObjectUnits(units);
          var prioritized = getPrioritizedUnits(units),
            i,
            prioritizedLen = prioritized.length;
          for (i = 0; i < prioritizedLen; i++) {
            this[prioritized[i].unit](units[prioritized[i].unit]);
          }
        } else {
          units = normalizeUnits(units);
          if (isFunction(this[units])) {
            return this[units](value);
          }
        }
        return this;
      }
      function mod(n, x) {
        return (n % x + x) % x;
      }
      var indexOf;
      if (Array.prototype.indexOf) {
        indexOf = Array.prototype.indexOf;
      } else {
        indexOf = function (o) {
          var i;
          for (i = 0; i < this.length; ++i) {
            if (this[i] === o) {
              return i;
            }
          }
          return -1;
        };
      }
      function daysInMonth(year, month) {
        if (isNaN(year) || isNaN(month)) {
          return NaN;
        }
        var modMonth = mod(month, 12);
        year += (month - modMonth) / 12;
        return modMonth === 1 ? isLeapYear(year) ? 29 : 28 : 31 - modMonth % 7 % 2;
      }
      addFormatToken("M", ["MM", 2], "Mo", function () {
        return this.month() + 1;
      });
      addFormatToken("MMM", 0, 0, function (format2) {
        return this.localeData().monthsShort(this, format2);
      });
      addFormatToken("MMMM", 0, 0, function (format2) {
        return this.localeData().months(this, format2);
      });
      addRegexToken("M", match1to2, match1to2NoLeadingZero);
      addRegexToken("MM", match1to2, match2);
      addRegexToken("MMM", function (isStrict, locale2) {
        return locale2.monthsShortRegex(isStrict);
      });
      addRegexToken("MMMM", function (isStrict, locale2) {
        return locale2.monthsRegex(isStrict);
      });
      addParseToken(["M", "MM"], function (input, array) {
        array[MONTH] = toInt(input) - 1;
      });
      addParseToken(["MMM", "MMMM"], function (input, array, config, token2) {
        var month = config._locale.monthsParse(input, token2, config._strict);
        if (month != null) {
          array[MONTH] = month;
        } else {
          getParsingFlags(config).invalidMonth = input;
        }
      });
      var defaultLocaleMonths = "January_February_March_April_May_June_July_August_September_October_November_December".split("_"),
        defaultLocaleMonthsShort = "Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"),
        MONTHS_IN_FORMAT = /D[oD]?(\[[^\[\]]*\]|\s)+MMMM?/,
        defaultMonthsShortRegex = matchWord,
        defaultMonthsRegex = matchWord;
      function localeMonths(m, format2) {
        if (!m) {
          return isArray(this._months) ? this._months : this._months["standalone"];
        }
        return isArray(this._months) ? this._months[m.month()] : this._months[(this._months.isFormat || MONTHS_IN_FORMAT).test(format2) ? "format" : "standalone"][m.month()];
      }
      function localeMonthsShort(m, format2) {
        if (!m) {
          return isArray(this._monthsShort) ? this._monthsShort : this._monthsShort["standalone"];
        }
        return isArray(this._monthsShort) ? this._monthsShort[m.month()] : this._monthsShort[MONTHS_IN_FORMAT.test(format2) ? "format" : "standalone"][m.month()];
      }
      function handleStrictParse(monthName, format2, strict) {
        var i,
          ii,
          mom,
          llc = monthName.toLocaleLowerCase();
        if (!this._monthsParse) {
          this._monthsParse = [];
          this._longMonthsParse = [];
          this._shortMonthsParse = [];
          for (i = 0; i < 12; ++i) {
            mom = createUTC([2e3, i]);
            this._shortMonthsParse[i] = this.monthsShort(mom, "").toLocaleLowerCase();
            this._longMonthsParse[i] = this.months(mom, "").toLocaleLowerCase();
          }
        }
        if (strict) {
          if (format2 === "MMM") {
            ii = indexOf.call(this._shortMonthsParse, llc);
            return ii !== -1 ? ii : null;
          } else {
            ii = indexOf.call(this._longMonthsParse, llc);
            return ii !== -1 ? ii : null;
          }
        } else {
          if (format2 === "MMM") {
            ii = indexOf.call(this._shortMonthsParse, llc);
            if (ii !== -1) {
              return ii;
            }
            ii = indexOf.call(this._longMonthsParse, llc);
            return ii !== -1 ? ii : null;
          } else {
            ii = indexOf.call(this._longMonthsParse, llc);
            if (ii !== -1) {
              return ii;
            }
            ii = indexOf.call(this._shortMonthsParse, llc);
            return ii !== -1 ? ii : null;
          }
        }
      }
      function localeMonthsParse(monthName, format2, strict) {
        var i, mom, regex;
        if (this._monthsParseExact) {
          return handleStrictParse.call(this, monthName, format2, strict);
        }
        if (!this._monthsParse) {
          this._monthsParse = [];
          this._longMonthsParse = [];
          this._shortMonthsParse = [];
        }
        for (i = 0; i < 12; i++) {
          mom = createUTC([2e3, i]);
          if (strict && !this._longMonthsParse[i]) {
            this._longMonthsParse[i] = new RegExp("^" + this.months(mom, "").replace(".", "") + "$", "i");
            this._shortMonthsParse[i] = new RegExp("^" + this.monthsShort(mom, "").replace(".", "") + "$", "i");
          }
          if (!strict && !this._monthsParse[i]) {
            regex = "^" + this.months(mom, "") + "|^" + this.monthsShort(mom, "");
            this._monthsParse[i] = new RegExp(regex.replace(".", ""), "i");
          }
          if (strict && format2 === "MMMM" && this._longMonthsParse[i].test(monthName)) {
            return i;
          } else if (strict && format2 === "MMM" && this._shortMonthsParse[i].test(monthName)) {
            return i;
          } else if (!strict && this._monthsParse[i].test(monthName)) {
            return i;
          }
        }
      }
      function setMonth(mom, value) {
        if (!mom.isValid()) {
          return mom;
        }
        if (typeof value === "string") {
          if (/^\d+$/.test(value)) {
            value = toInt(value);
          } else {
            value = mom.localeData().monthsParse(value);
            if (!isNumber(value)) {
              return mom;
            }
          }
        }
        var month = value,
          date = mom.date();
        date = date < 29 ? date : Math.min(date, daysInMonth(mom.year(), month));
        void (mom._isUTC ? mom._d.setUTCMonth(month, date) : mom._d.setMonth(month, date));
        return mom;
      }
      function getSetMonth(value) {
        if (value != null) {
          setMonth(this, value);
          hooks.updateOffset(this, true);
          return this;
        } else {
          return get(this, "Month");
        }
      }
      function getDaysInMonth() {
        return daysInMonth(this.year(), this.month());
      }
      function monthsShortRegex(isStrict) {
        if (this._monthsParseExact) {
          if (!hasOwnProp(this, "_monthsRegex")) {
            computeMonthsParse.call(this);
          }
          if (isStrict) {
            return this._monthsShortStrictRegex;
          } else {
            return this._monthsShortRegex;
          }
        } else {
          if (!hasOwnProp(this, "_monthsShortRegex")) {
            this._monthsShortRegex = defaultMonthsShortRegex;
          }
          return this._monthsShortStrictRegex && isStrict ? this._monthsShortStrictRegex : this._monthsShortRegex;
        }
      }
      function monthsRegex(isStrict) {
        if (this._monthsParseExact) {
          if (!hasOwnProp(this, "_monthsRegex")) {
            computeMonthsParse.call(this);
          }
          if (isStrict) {
            return this._monthsStrictRegex;
          } else {
            return this._monthsRegex;
          }
        } else {
          if (!hasOwnProp(this, "_monthsRegex")) {
            this._monthsRegex = defaultMonthsRegex;
          }
          return this._monthsStrictRegex && isStrict ? this._monthsStrictRegex : this._monthsRegex;
        }
      }
      function computeMonthsParse() {
        function cmpLenRev(a, b) {
          return b.length - a.length;
        }
        var shortPieces = [],
          longPieces = [],
          mixedPieces = [],
          i,
          mom,
          shortP,
          longP;
        for (i = 0; i < 12; i++) {
          mom = createUTC([2e3, i]);
          shortP = regexEscape(this.monthsShort(mom, ""));
          longP = regexEscape(this.months(mom, ""));
          shortPieces.push(shortP);
          longPieces.push(longP);
          mixedPieces.push(longP);
          mixedPieces.push(shortP);
        }
        shortPieces.sort(cmpLenRev);
        longPieces.sort(cmpLenRev);
        mixedPieces.sort(cmpLenRev);
        this._monthsRegex = new RegExp("^(" + mixedPieces.join("|") + ")", "i");
        this._monthsShortRegex = this._monthsRegex;
        this._monthsStrictRegex = new RegExp("^(" + longPieces.join("|") + ")", "i");
        this._monthsShortStrictRegex = new RegExp("^(" + shortPieces.join("|") + ")", "i");
      }
      function createDate(y, m, d, h, M, s, ms) {
        var date;
        if (y < 100 && y >= 0) {
          date = new Date(y + 400, m, d, h, M, s, ms);
          if (isFinite(date.getFullYear())) {
            date.setFullYear(y);
          }
        } else {
          date = new Date(y, m, d, h, M, s, ms);
        }
        return date;
      }
      function createUTCDate(y) {
        var date, args;
        if (y < 100 && y >= 0) {
          args = Array.prototype.slice.call(arguments);
          args[0] = y + 400;
          date = new Date(Date.UTC.apply(null, args));
          if (isFinite(date.getUTCFullYear())) {
            date.setUTCFullYear(y);
          }
        } else {
          date = new Date(Date.UTC.apply(null, arguments));
        }
        return date;
      }
      function firstWeekOffset(year, dow, doy) {
        var fwd = 7 + dow - doy,
          fwdlw = (7 + createUTCDate(year, 0, fwd).getUTCDay() - dow) % 7;
        return -fwdlw + fwd - 1;
      }
      function dayOfYearFromWeeks(year, week, weekday, dow, doy) {
        var localWeekday = (7 + weekday - dow) % 7,
          weekOffset = firstWeekOffset(year, dow, doy),
          dayOfYear = 1 + 7 * (week - 1) + localWeekday + weekOffset,
          resYear,
          resDayOfYear;
        if (dayOfYear <= 0) {
          resYear = year - 1;
          resDayOfYear = daysInYear(resYear) + dayOfYear;
        } else if (dayOfYear > daysInYear(year)) {
          resYear = year + 1;
          resDayOfYear = dayOfYear - daysInYear(year);
        } else {
          resYear = year;
          resDayOfYear = dayOfYear;
        }
        return {
          year: resYear,
          dayOfYear: resDayOfYear
        };
      }
      function weekOfYear(mom, dow, doy) {
        var weekOffset = firstWeekOffset(mom.year(), dow, doy),
          week = Math.floor((mom.dayOfYear() - weekOffset - 1) / 7) + 1,
          resWeek,
          resYear;
        if (week < 1) {
          resYear = mom.year() - 1;
          resWeek = week + weeksInYear(resYear, dow, doy);
        } else if (week > weeksInYear(mom.year(), dow, doy)) {
          resWeek = week - weeksInYear(mom.year(), dow, doy);
          resYear = mom.year() + 1;
        } else {
          resYear = mom.year();
          resWeek = week;
        }
        return {
          week: resWeek,
          year: resYear
        };
      }
      function weeksInYear(year, dow, doy) {
        var weekOffset = firstWeekOffset(year, dow, doy),
          weekOffsetNext = firstWeekOffset(year + 1, dow, doy);
        return (daysInYear(year) - weekOffset + weekOffsetNext) / 7;
      }
      addFormatToken("w", ["ww", 2], "wo", "week");
      addFormatToken("W", ["WW", 2], "Wo", "isoWeek");
      addRegexToken("w", match1to2, match1to2NoLeadingZero);
      addRegexToken("ww", match1to2, match2);
      addRegexToken("W", match1to2, match1to2NoLeadingZero);
      addRegexToken("WW", match1to2, match2);
      addWeekParseToken(["w", "ww", "W", "WW"], function (input, week, config, token2) {
        week[token2.substr(0, 1)] = toInt(input);
      });
      function localeWeek(mom) {
        return weekOfYear(mom, this._week.dow, this._week.doy).week;
      }
      var defaultLocaleWeek = {
        dow: 0,
        doy: 6
      };
      function localeFirstDayOfWeek() {
        return this._week.dow;
      }
      function localeFirstDayOfYear() {
        return this._week.doy;
      }
      function getSetWeek(input) {
        var week = this.localeData().week(this);
        return input == null ? week : this.add((input - week) * 7, "d");
      }
      function getSetISOWeek(input) {
        var week = weekOfYear(this, 1, 4).week;
        return input == null ? week : this.add((input - week) * 7, "d");
      }
      addFormatToken("d", 0, "do", "day");
      addFormatToken("dd", 0, 0, function (format2) {
        return this.localeData().weekdaysMin(this, format2);
      });
      addFormatToken("ddd", 0, 0, function (format2) {
        return this.localeData().weekdaysShort(this, format2);
      });
      addFormatToken("dddd", 0, 0, function (format2) {
        return this.localeData().weekdays(this, format2);
      });
      addFormatToken("e", 0, 0, "weekday");
      addFormatToken("E", 0, 0, "isoWeekday");
      addRegexToken("d", match1to2);
      addRegexToken("e", match1to2);
      addRegexToken("E", match1to2);
      addRegexToken("dd", function (isStrict, locale2) {
        return locale2.weekdaysMinRegex(isStrict);
      });
      addRegexToken("ddd", function (isStrict, locale2) {
        return locale2.weekdaysShortRegex(isStrict);
      });
      addRegexToken("dddd", function (isStrict, locale2) {
        return locale2.weekdaysRegex(isStrict);
      });
      addWeekParseToken(["dd", "ddd", "dddd"], function (input, week, config, token2) {
        var weekday = config._locale.weekdaysParse(input, token2, config._strict);
        if (weekday != null) {
          week.d = weekday;
        } else {
          getParsingFlags(config).invalidWeekday = input;
        }
      });
      addWeekParseToken(["d", "e", "E"], function (input, week, config, token2) {
        week[token2] = toInt(input);
      });
      function parseWeekday(input, locale2) {
        if (typeof input !== "string") {
          return input;
        }
        if (!isNaN(input)) {
          return parseInt(input, 10);
        }
        input = locale2.weekdaysParse(input);
        if (typeof input === "number") {
          return input;
        }
        return null;
      }
      function parseIsoWeekday(input, locale2) {
        if (typeof input === "string") {
          return locale2.weekdaysParse(input) % 7 || 7;
        }
        return isNaN(input) ? null : input;
      }
      function shiftWeekdays(ws, n) {
        return ws.slice(n, 7).concat(ws.slice(0, n));
      }
      var defaultLocaleWeekdays = "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),
        defaultLocaleWeekdaysShort = "Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"),
        defaultLocaleWeekdaysMin = "Su_Mo_Tu_We_Th_Fr_Sa".split("_"),
        defaultWeekdaysRegex = matchWord,
        defaultWeekdaysShortRegex = matchWord,
        defaultWeekdaysMinRegex = matchWord;
      function localeWeekdays(m, format2) {
        var weekdays = isArray(this._weekdays) ? this._weekdays : this._weekdays[m && m !== true && this._weekdays.isFormat.test(format2) ? "format" : "standalone"];
        return m === true ? shiftWeekdays(weekdays, this._week.dow) : m ? weekdays[m.day()] : weekdays;
      }
      function localeWeekdaysShort(m) {
        return m === true ? shiftWeekdays(this._weekdaysShort, this._week.dow) : m ? this._weekdaysShort[m.day()] : this._weekdaysShort;
      }
      function localeWeekdaysMin(m) {
        return m === true ? shiftWeekdays(this._weekdaysMin, this._week.dow) : m ? this._weekdaysMin[m.day()] : this._weekdaysMin;
      }
      function handleStrictParse$1(weekdayName, format2, strict) {
        var i,
          ii,
          mom,
          llc = weekdayName.toLocaleLowerCase();
        if (!this._weekdaysParse) {
          this._weekdaysParse = [];
          this._shortWeekdaysParse = [];
          this._minWeekdaysParse = [];
          for (i = 0; i < 7; ++i) {
            mom = createUTC([2e3, 1]).day(i);
            this._minWeekdaysParse[i] = this.weekdaysMin(mom, "").toLocaleLowerCase();
            this._shortWeekdaysParse[i] = this.weekdaysShort(mom, "").toLocaleLowerCase();
            this._weekdaysParse[i] = this.weekdays(mom, "").toLocaleLowerCase();
          }
        }
        if (strict) {
          if (format2 === "dddd") {
            ii = indexOf.call(this._weekdaysParse, llc);
            return ii !== -1 ? ii : null;
          } else if (format2 === "ddd") {
            ii = indexOf.call(this._shortWeekdaysParse, llc);
            return ii !== -1 ? ii : null;
          } else {
            ii = indexOf.call(this._minWeekdaysParse, llc);
            return ii !== -1 ? ii : null;
          }
        } else {
          if (format2 === "dddd") {
            ii = indexOf.call(this._weekdaysParse, llc);
            if (ii !== -1) {
              return ii;
            }
            ii = indexOf.call(this._shortWeekdaysParse, llc);
            if (ii !== -1) {
              return ii;
            }
            ii = indexOf.call(this._minWeekdaysParse, llc);
            return ii !== -1 ? ii : null;
          } else if (format2 === "ddd") {
            ii = indexOf.call(this._shortWeekdaysParse, llc);
            if (ii !== -1) {
              return ii;
            }
            ii = indexOf.call(this._weekdaysParse, llc);
            if (ii !== -1) {
              return ii;
            }
            ii = indexOf.call(this._minWeekdaysParse, llc);
            return ii !== -1 ? ii : null;
          } else {
            ii = indexOf.call(this._minWeekdaysParse, llc);
            if (ii !== -1) {
              return ii;
            }
            ii = indexOf.call(this._weekdaysParse, llc);
            if (ii !== -1) {
              return ii;
            }
            ii = indexOf.call(this._shortWeekdaysParse, llc);
            return ii !== -1 ? ii : null;
          }
        }
      }
      function localeWeekdaysParse(weekdayName, format2, strict) {
        var i, mom, regex;
        if (this._weekdaysParseExact) {
          return handleStrictParse$1.call(this, weekdayName, format2, strict);
        }
        if (!this._weekdaysParse) {
          this._weekdaysParse = [];
          this._minWeekdaysParse = [];
          this._shortWeekdaysParse = [];
          this._fullWeekdaysParse = [];
        }
        for (i = 0; i < 7; i++) {
          mom = createUTC([2e3, 1]).day(i);
          if (strict && !this._fullWeekdaysParse[i]) {
            this._fullWeekdaysParse[i] = new RegExp("^" + this.weekdays(mom, "").replace(".", "\\.?") + "$", "i");
            this._shortWeekdaysParse[i] = new RegExp("^" + this.weekdaysShort(mom, "").replace(".", "\\.?") + "$", "i");
            this._minWeekdaysParse[i] = new RegExp("^" + this.weekdaysMin(mom, "").replace(".", "\\.?") + "$", "i");
          }
          if (!this._weekdaysParse[i]) {
            regex = "^" + this.weekdays(mom, "") + "|^" + this.weekdaysShort(mom, "") + "|^" + this.weekdaysMin(mom, "");
            this._weekdaysParse[i] = new RegExp(regex.replace(".", ""), "i");
          }
          if (strict && format2 === "dddd" && this._fullWeekdaysParse[i].test(weekdayName)) {
            return i;
          } else if (strict && format2 === "ddd" && this._shortWeekdaysParse[i].test(weekdayName)) {
            return i;
          } else if (strict && format2 === "dd" && this._minWeekdaysParse[i].test(weekdayName)) {
            return i;
          } else if (!strict && this._weekdaysParse[i].test(weekdayName)) {
            return i;
          }
        }
      }
      function getSetDayOfWeek(input) {
        if (!this.isValid()) {
          return input != null ? this : NaN;
        }
        var day = get(this, "Day");
        if (input != null) {
          input = parseWeekday(input, this.localeData());
          return this.add(input - day, "d");
        } else {
          return day;
        }
      }
      function getSetLocaleDayOfWeek(input) {
        if (!this.isValid()) {
          return input != null ? this : NaN;
        }
        var weekday = (this.day() + 7 - this.localeData()._week.dow) % 7;
        return input == null ? weekday : this.add(input - weekday, "d");
      }
      function getSetISODayOfWeek(input) {
        if (!this.isValid()) {
          return input != null ? this : NaN;
        }
        if (input != null) {
          var weekday = parseIsoWeekday(input, this.localeData());
          return this.day(this.day() % 7 ? weekday : weekday - 7);
        } else {
          return this.day() || 7;
        }
      }
      function weekdaysRegex(isStrict) {
        if (this._weekdaysParseExact) {
          if (!hasOwnProp(this, "_weekdaysRegex")) {
            computeWeekdaysParse.call(this);
          }
          if (isStrict) {
            return this._weekdaysStrictRegex;
          } else {
            return this._weekdaysRegex;
          }
        } else {
          if (!hasOwnProp(this, "_weekdaysRegex")) {
            this._weekdaysRegex = defaultWeekdaysRegex;
          }
          return this._weekdaysStrictRegex && isStrict ? this._weekdaysStrictRegex : this._weekdaysRegex;
        }
      }
      function weekdaysShortRegex(isStrict) {
        if (this._weekdaysParseExact) {
          if (!hasOwnProp(this, "_weekdaysRegex")) {
            computeWeekdaysParse.call(this);
          }
          if (isStrict) {
            return this._weekdaysShortStrictRegex;
          } else {
            return this._weekdaysShortRegex;
          }
        } else {
          if (!hasOwnProp(this, "_weekdaysShortRegex")) {
            this._weekdaysShortRegex = defaultWeekdaysShortRegex;
          }
          return this._weekdaysShortStrictRegex && isStrict ? this._weekdaysShortStrictRegex : this._weekdaysShortRegex;
        }
      }
      function weekdaysMinRegex(isStrict) {
        if (this._weekdaysParseExact) {
          if (!hasOwnProp(this, "_weekdaysRegex")) {
            computeWeekdaysParse.call(this);
          }
          if (isStrict) {
            return this._weekdaysMinStrictRegex;
          } else {
            return this._weekdaysMinRegex;
          }
        } else {
          if (!hasOwnProp(this, "_weekdaysMinRegex")) {
            this._weekdaysMinRegex = defaultWeekdaysMinRegex;
          }
          return this._weekdaysMinStrictRegex && isStrict ? this._weekdaysMinStrictRegex : this._weekdaysMinRegex;
        }
      }
      function computeWeekdaysParse() {
        function cmpLenRev(a, b) {
          return b.length - a.length;
        }
        var minPieces = [],
          shortPieces = [],
          longPieces = [],
          mixedPieces = [],
          i,
          mom,
          minp,
          shortp,
          longp;
        for (i = 0; i < 7; i++) {
          mom = createUTC([2e3, 1]).day(i);
          minp = regexEscape(this.weekdaysMin(mom, ""));
          shortp = regexEscape(this.weekdaysShort(mom, ""));
          longp = regexEscape(this.weekdays(mom, ""));
          minPieces.push(minp);
          shortPieces.push(shortp);
          longPieces.push(longp);
          mixedPieces.push(minp);
          mixedPieces.push(shortp);
          mixedPieces.push(longp);
        }
        minPieces.sort(cmpLenRev);
        shortPieces.sort(cmpLenRev);
        longPieces.sort(cmpLenRev);
        mixedPieces.sort(cmpLenRev);
        this._weekdaysRegex = new RegExp("^(" + mixedPieces.join("|") + ")", "i");
        this._weekdaysShortRegex = this._weekdaysRegex;
        this._weekdaysMinRegex = this._weekdaysRegex;
        this._weekdaysStrictRegex = new RegExp("^(" + longPieces.join("|") + ")", "i");
        this._weekdaysShortStrictRegex = new RegExp("^(" + shortPieces.join("|") + ")", "i");
        this._weekdaysMinStrictRegex = new RegExp("^(" + minPieces.join("|") + ")", "i");
      }
      function hFormat() {
        return this.hours() % 12 || 12;
      }
      function kFormat() {
        return this.hours() || 24;
      }
      addFormatToken("H", ["HH", 2], 0, "hour");
      addFormatToken("h", ["hh", 2], 0, hFormat);
      addFormatToken("k", ["kk", 2], 0, kFormat);
      addFormatToken("hmm", 0, 0, function () {
        return "" + hFormat.apply(this) + zeroFill(this.minutes(), 2);
      });
      addFormatToken("hmmss", 0, 0, function () {
        return "" + hFormat.apply(this) + zeroFill(this.minutes(), 2) + zeroFill(this.seconds(), 2);
      });
      addFormatToken("Hmm", 0, 0, function () {
        return "" + this.hours() + zeroFill(this.minutes(), 2);
      });
      addFormatToken("Hmmss", 0, 0, function () {
        return "" + this.hours() + zeroFill(this.minutes(), 2) + zeroFill(this.seconds(), 2);
      });
      function meridiem(token2, lowercase) {
        addFormatToken(token2, 0, 0, function () {
          return this.localeData().meridiem(this.hours(), this.minutes(), lowercase);
        });
      }
      meridiem("a", true);
      meridiem("A", false);
      function matchMeridiem(isStrict, locale2) {
        return locale2._meridiemParse;
      }
      addRegexToken("a", matchMeridiem);
      addRegexToken("A", matchMeridiem);
      addRegexToken("H", match1to2, match1to2HasZero);
      addRegexToken("h", match1to2, match1to2NoLeadingZero);
      addRegexToken("k", match1to2, match1to2NoLeadingZero);
      addRegexToken("HH", match1to2, match2);
      addRegexToken("hh", match1to2, match2);
      addRegexToken("kk", match1to2, match2);
      addRegexToken("hmm", match3to4);
      addRegexToken("hmmss", match5to6);
      addRegexToken("Hmm", match3to4);
      addRegexToken("Hmmss", match5to6);
      addParseToken(["H", "HH"], HOUR);
      addParseToken(["k", "kk"], function (input, array, config) {
        var kInput = toInt(input);
        array[HOUR] = kInput === 24 ? 0 : kInput;
      });
      addParseToken(["a", "A"], function (input, array, config) {
        config._isPm = config._locale.isPM(input);
        config._meridiem = input;
      });
      addParseToken(["h", "hh"], function (input, array, config) {
        array[HOUR] = toInt(input);
        getParsingFlags(config).bigHour = true;
      });
      addParseToken("hmm", function (input, array, config) {
        var pos = input.length - 2;
        array[HOUR] = toInt(input.substr(0, pos));
        array[MINUTE] = toInt(input.substr(pos));
        getParsingFlags(config).bigHour = true;
      });
      addParseToken("hmmss", function (input, array, config) {
        var pos1 = input.length - 4,
          pos2 = input.length - 2;
        array[HOUR] = toInt(input.substr(0, pos1));
        array[MINUTE] = toInt(input.substr(pos1, 2));
        array[SECOND] = toInt(input.substr(pos2));
        getParsingFlags(config).bigHour = true;
      });
      addParseToken("Hmm", function (input, array, config) {
        var pos = input.length - 2;
        array[HOUR] = toInt(input.substr(0, pos));
        array[MINUTE] = toInt(input.substr(pos));
      });
      addParseToken("Hmmss", function (input, array, config) {
        var pos1 = input.length - 4,
          pos2 = input.length - 2;
        array[HOUR] = toInt(input.substr(0, pos1));
        array[MINUTE] = toInt(input.substr(pos1, 2));
        array[SECOND] = toInt(input.substr(pos2));
      });
      function localeIsPM(input) {
        return (input + "").toLowerCase().charAt(0) === "p";
      }
      var defaultLocaleMeridiemParse = /[ap]\.?m?\.?/i,
        getSetHour = makeGetSet("Hours", true);
      function localeMeridiem(hours2, minutes2, isLower) {
        if (hours2 > 11) {
          return isLower ? "pm" : "PM";
        } else {
          return isLower ? "am" : "AM";
        }
      }
      var baseConfig = {
        calendar: defaultCalendar,
        longDateFormat: defaultLongDateFormat,
        invalidDate: defaultInvalidDate,
        ordinal: defaultOrdinal,
        dayOfMonthOrdinalParse: defaultDayOfMonthOrdinalParse,
        relativeTime: defaultRelativeTime,
        months: defaultLocaleMonths,
        monthsShort: defaultLocaleMonthsShort,
        week: defaultLocaleWeek,
        weekdays: defaultLocaleWeekdays,
        weekdaysMin: defaultLocaleWeekdaysMin,
        weekdaysShort: defaultLocaleWeekdaysShort,
        meridiemParse: defaultLocaleMeridiemParse
      };
      var locales = {},
        localeFamilies = {},
        globalLocale;
      function commonPrefix(arr1, arr2) {
        var i,
          minl = Math.min(arr1.length, arr2.length);
        for (i = 0; i < minl; i += 1) {
          if (arr1[i] !== arr2[i]) {
            return i;
          }
        }
        return minl;
      }
      function normalizeLocale(key) {
        return key ? key.toLowerCase().replace("_", "-") : key;
      }
      function chooseLocale(names) {
        var i = 0,
          j,
          next,
          locale2,
          split;
        while (i < names.length) {
          split = normalizeLocale(names[i]).split("-");
          j = split.length;
          next = normalizeLocale(names[i + 1]);
          next = next ? next.split("-") : null;
          while (j > 0) {
            locale2 = loadLocale(split.slice(0, j).join("-"));
            if (locale2) {
              return locale2;
            }
            if (next && next.length >= j && commonPrefix(split, next) >= j - 1) {
              break;
            }
            j--;
          }
          i++;
        }
        return globalLocale;
      }
      function isLocaleNameSane(name) {
        return !!(name && name.match("^[^/\\\\]*$"));
      }
      function loadLocale(name) {
        var oldLocale = null,
          aliasedRequire;
        if (locales[name] === void 0 && typeof module2 !== "undefined" && module2 && module2.exports && isLocaleNameSane(name)) {
          try {
            oldLocale = globalLocale._abbr;
            aliasedRequire = require;
            aliasedRequire("./locale/" + name);
            getSetGlobalLocale(oldLocale);
          } catch (e) {
            locales[name] = null;
          }
        }
        return locales[name];
      }
      function getSetGlobalLocale(key, values) {
        var data;
        if (key) {
          if (isUndefined(values)) {
            data = getLocale(key);
          } else {
            data = defineLocale(key, values);
          }
          if (data) {
            globalLocale = data;
          } else {
            if (typeof console !== "undefined" && console.warn) {
              console.warn("Locale " + key + " not found. Did you forget to load it?");
            }
          }
        }
        return globalLocale._abbr;
      }
      function defineLocale(name, config) {
        if (config !== null) {
          var locale2,
            parentConfig = baseConfig;
          config.abbr = name;
          if (locales[name] != null) {
            deprecateSimple("defineLocaleOverride", "use moment.updateLocale(localeName, config) to change an existing locale. moment.defineLocale(localeName, config) should only be used for creating a new locale See http://momentjs.com/guides/#/warnings/define-locale/ for more info.");
            parentConfig = locales[name]._config;
          } else if (config.parentLocale != null) {
            if (locales[config.parentLocale] != null) {
              parentConfig = locales[config.parentLocale]._config;
            } else {
              locale2 = loadLocale(config.parentLocale);
              if (locale2 != null) {
                parentConfig = locale2._config;
              } else {
                if (!localeFamilies[config.parentLocale]) {
                  localeFamilies[config.parentLocale] = [];
                }
                localeFamilies[config.parentLocale].push({
                  name,
                  config
                });
                return null;
              }
            }
          }
          locales[name] = new Locale(mergeConfigs(parentConfig, config));
          if (localeFamilies[name]) {
            localeFamilies[name].forEach(function (x) {
              defineLocale(x.name, x.config);
            });
          }
          getSetGlobalLocale(name);
          return locales[name];
        } else {
          delete locales[name];
          return null;
        }
      }
      function updateLocale(name, config) {
        if (config != null) {
          var locale2,
            tmpLocale,
            parentConfig = baseConfig;
          if (locales[name] != null && locales[name].parentLocale != null) {
            locales[name].set(mergeConfigs(locales[name]._config, config));
          } else {
            tmpLocale = loadLocale(name);
            if (tmpLocale != null) {
              parentConfig = tmpLocale._config;
            }
            config = mergeConfigs(parentConfig, config);
            if (tmpLocale == null) {
              config.abbr = name;
            }
            locale2 = new Locale(config);
            locale2.parentLocale = locales[name];
            locales[name] = locale2;
          }
          getSetGlobalLocale(name);
        } else {
          if (locales[name] != null) {
            if (locales[name].parentLocale != null) {
              locales[name] = locales[name].parentLocale;
              if (name === getSetGlobalLocale()) {
                getSetGlobalLocale(name);
              }
            } else if (locales[name] != null) {
              delete locales[name];
            }
          }
        }
        return locales[name];
      }
      function getLocale(key) {
        var locale2;
        if (key && key._locale && key._locale._abbr) {
          key = key._locale._abbr;
        }
        if (!key) {
          return globalLocale;
        }
        if (!isArray(key)) {
          locale2 = loadLocale(key);
          if (locale2) {
            return locale2;
          }
          key = [key];
        }
        return chooseLocale(key);
      }
      function listLocales() {
        return keys(locales);
      }
      function checkOverflow(m) {
        var overflow,
          a = m._a;
        if (a && getParsingFlags(m).overflow === -2) {
          overflow = a[MONTH] < 0 || a[MONTH] > 11 ? MONTH : a[DATE] < 1 || a[DATE] > daysInMonth(a[YEAR], a[MONTH]) ? DATE : a[HOUR] < 0 || a[HOUR] > 24 || a[HOUR] === 24 && (a[MINUTE] !== 0 || a[SECOND] !== 0 || a[MILLISECOND] !== 0) ? HOUR : a[MINUTE] < 0 || a[MINUTE] > 59 ? MINUTE : a[SECOND] < 0 || a[SECOND] > 59 ? SECOND : a[MILLISECOND] < 0 || a[MILLISECOND] > 999 ? MILLISECOND : -1;
          if (getParsingFlags(m)._overflowDayOfYear && (overflow < YEAR || overflow > DATE)) {
            overflow = DATE;
          }
          if (getParsingFlags(m)._overflowWeeks && overflow === -1) {
            overflow = WEEK;
          }
          if (getParsingFlags(m)._overflowWeekday && overflow === -1) {
            overflow = WEEKDAY;
          }
          getParsingFlags(m).overflow = overflow;
        }
        return m;
      }
      var extendedIsoRegex = /^\s*((?:[+-]\d{6}|\d{4})-(?:\d\d-\d\d|W\d\d-\d|W\d\d|\d\d\d|\d\d))(?:(T| )(\d\d(?::\d\d(?::\d\d(?:[.,]\d+)?)?)?)([+-]\d\d(?::?\d\d)?|\s*Z)?)?$/,
        basicIsoRegex = /^\s*((?:[+-]\d{6}|\d{4})(?:\d\d\d\d|W\d\d\d|W\d\d|\d\d\d|\d\d|))(?:(T| )(\d\d(?:\d\d(?:\d\d(?:[.,]\d+)?)?)?)([+-]\d\d(?::?\d\d)?|\s*Z)?)?$/,
        tzRegex = /Z|[+-]\d\d(?::?\d\d)?/,
        isoDates = [["YYYYYY-MM-DD", /[+-]\d{6}-\d\d-\d\d/], ["YYYY-MM-DD", /\d{4}-\d\d-\d\d/], ["GGGG-[W]WW-E", /\d{4}-W\d\d-\d/], ["GGGG-[W]WW", /\d{4}-W\d\d/, false], ["YYYY-DDD", /\d{4}-\d{3}/], ["YYYY-MM", /\d{4}-\d\d/, false], ["YYYYYYMMDD", /[+-]\d{10}/], ["YYYYMMDD", /\d{8}/], ["GGGG[W]WWE", /\d{4}W\d{3}/], ["GGGG[W]WW", /\d{4}W\d{2}/, false], ["YYYYDDD", /\d{7}/], ["YYYYMM", /\d{6}/, false], ["YYYY", /\d{4}/, false]],
        isoTimes = [["HH:mm:ss.SSSS", /\d\d:\d\d:\d\d\.\d+/], ["HH:mm:ss,SSSS", /\d\d:\d\d:\d\d,\d+/], ["HH:mm:ss", /\d\d:\d\d:\d\d/], ["HH:mm", /\d\d:\d\d/], ["HHmmss.SSSS", /\d\d\d\d\d\d\.\d+/], ["HHmmss,SSSS", /\d\d\d\d\d\d,\d+/], ["HHmmss", /\d\d\d\d\d\d/], ["HHmm", /\d\d\d\d/], ["HH", /\d\d/]],
        aspNetJsonRegex = /^\/?Date\((-?\d+)/i,
        rfc2822 = /^(?:(Mon|Tue|Wed|Thu|Fri|Sat|Sun),?\s)?(\d{1,2})\s(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s(\d{2,4})\s(\d\d):(\d\d)(?::(\d\d))?\s(?:(UT|GMT|[ECMP][SD]T)|([Zz])|([+-]\d{4}))$/,
        obsOffsets = {
          UT: 0,
          GMT: 0,
          EDT: -4 * 60,
          EST: -5 * 60,
          CDT: -5 * 60,
          CST: -6 * 60,
          MDT: -6 * 60,
          MST: -7 * 60,
          PDT: -7 * 60,
          PST: -8 * 60
        };
      function configFromISO(config) {
        var i,
          l,
          string = config._i,
          match = extendedIsoRegex.exec(string) || basicIsoRegex.exec(string),
          allowTime,
          dateFormat,
          timeFormat,
          tzFormat,
          isoDatesLen = isoDates.length,
          isoTimesLen = isoTimes.length;
        if (match) {
          getParsingFlags(config).iso = true;
          for (i = 0, l = isoDatesLen; i < l; i++) {
            if (isoDates[i][1].exec(match[1])) {
              dateFormat = isoDates[i][0];
              allowTime = isoDates[i][2] !== false;
              break;
            }
          }
          if (dateFormat == null) {
            config._isValid = false;
            return;
          }
          if (match[3]) {
            for (i = 0, l = isoTimesLen; i < l; i++) {
              if (isoTimes[i][1].exec(match[3])) {
                timeFormat = (match[2] || " ") + isoTimes[i][0];
                break;
              }
            }
            if (timeFormat == null) {
              config._isValid = false;
              return;
            }
          }
          if (!allowTime && timeFormat != null) {
            config._isValid = false;
            return;
          }
          if (match[4]) {
            if (tzRegex.exec(match[4])) {
              tzFormat = "Z";
            } else {
              config._isValid = false;
              return;
            }
          }
          config._f = dateFormat + (timeFormat || "") + (tzFormat || "");
          configFromStringAndFormat(config);
        } else {
          config._isValid = false;
        }
      }
      function extractFromRFC2822Strings(yearStr, monthStr, dayStr, hourStr, minuteStr, secondStr) {
        var result = [untruncateYear(yearStr), defaultLocaleMonthsShort.indexOf(monthStr), parseInt(dayStr, 10), parseInt(hourStr, 10), parseInt(minuteStr, 10)];
        if (secondStr) {
          result.push(parseInt(secondStr, 10));
        }
        return result;
      }
      function untruncateYear(yearStr) {
        var year = parseInt(yearStr, 10);
        if (year <= 49) {
          return 2e3 + year;
        } else if (year <= 999) {
          return 1900 + year;
        }
        return year;
      }
      function preprocessRFC2822(s) {
        return s.replace(/\([^()]*\)|[\n\t]/g, " ").replace(/(\s\s+)/g, " ").replace(/^\s\s*/, "").replace(/\s\s*$/, "");
      }
      function checkWeekday(weekdayStr, parsedInput, config) {
        if (weekdayStr) {
          var weekdayProvided = defaultLocaleWeekdaysShort.indexOf(weekdayStr),
            weekdayActual = new Date(parsedInput[0], parsedInput[1], parsedInput[2]).getDay();
          if (weekdayProvided !== weekdayActual) {
            getParsingFlags(config).weekdayMismatch = true;
            config._isValid = false;
            return false;
          }
        }
        return true;
      }
      function calculateOffset(obsOffset, militaryOffset, numOffset) {
        if (obsOffset) {
          return obsOffsets[obsOffset];
        } else if (militaryOffset) {
          return 0;
        } else {
          var hm = parseInt(numOffset, 10),
            m = hm % 100,
            h = (hm - m) / 100;
          return h * 60 + m;
        }
      }
      function configFromRFC2822(config) {
        var match = rfc2822.exec(preprocessRFC2822(config._i)),
          parsedArray;
        if (match) {
          parsedArray = extractFromRFC2822Strings(match[4], match[3], match[2], match[5], match[6], match[7]);
          if (!checkWeekday(match[1], parsedArray, config)) {
            return;
          }
          config._a = parsedArray;
          config._tzm = calculateOffset(match[8], match[9], match[10]);
          config._d = createUTCDate.apply(null, config._a);
          config._d.setUTCMinutes(config._d.getUTCMinutes() - config._tzm);
          getParsingFlags(config).rfc2822 = true;
        } else {
          config._isValid = false;
        }
      }
      function configFromString(config) {
        var matched = aspNetJsonRegex.exec(config._i);
        if (matched !== null) {
          config._d = new Date(+matched[1]);
          return;
        }
        configFromISO(config);
        if (config._isValid === false) {
          delete config._isValid;
        } else {
          return;
        }
        configFromRFC2822(config);
        if (config._isValid === false) {
          delete config._isValid;
        } else {
          return;
        }
        if (config._strict) {
          config._isValid = false;
        } else {
          hooks.createFromInputFallback(config);
        }
      }
      hooks.createFromInputFallback = deprecate("value provided is not in a recognized RFC2822 or ISO format. moment construction falls back to js Date(), which is not reliable across all browsers and versions. Non RFC2822/ISO date formats are discouraged. Please refer to http://momentjs.com/guides/#/warnings/js-date/ for more info.", function (config) {
        config._d = new Date(config._i + (config._useUTC ? " UTC" : ""));
      });
      function defaults(a, b, c) {
        if (a != null) {
          return a;
        }
        if (b != null) {
          return b;
        }
        return c;
      }
      function currentDateArray(config) {
        var nowValue = new Date(hooks.now());
        if (config._useUTC) {
          return [nowValue.getUTCFullYear(), nowValue.getUTCMonth(), nowValue.getUTCDate()];
        }
        return [nowValue.getFullYear(), nowValue.getMonth(), nowValue.getDate()];
      }
      function configFromArray(config) {
        var i,
          date,
          input = [],
          currentDate,
          expectedWeekday,
          yearToUse;
        if (config._d) {
          return;
        }
        currentDate = currentDateArray(config);
        if (config._w && config._a[DATE] == null && config._a[MONTH] == null) {
          dayOfYearFromWeekInfo(config);
        }
        if (config._dayOfYear != null) {
          yearToUse = defaults(config._a[YEAR], currentDate[YEAR]);
          if (config._dayOfYear > daysInYear(yearToUse) || config._dayOfYear === 0) {
            getParsingFlags(config)._overflowDayOfYear = true;
          }
          date = createUTCDate(yearToUse, 0, config._dayOfYear);
          config._a[MONTH] = date.getUTCMonth();
          config._a[DATE] = date.getUTCDate();
        }
        for (i = 0; i < 3 && config._a[i] == null; ++i) {
          config._a[i] = input[i] = currentDate[i];
        }
        for (; i < 7; i++) {
          config._a[i] = input[i] = config._a[i] == null ? i === 2 ? 1 : 0 : config._a[i];
        }
        if (config._a[HOUR] === 24 && config._a[MINUTE] === 0 && config._a[SECOND] === 0 && config._a[MILLISECOND] === 0) {
          config._nextDay = true;
          config._a[HOUR] = 0;
        }
        config._d = (config._useUTC ? createUTCDate : createDate).apply(null, input);
        expectedWeekday = config._useUTC ? config._d.getUTCDay() : config._d.getDay();
        if (config._tzm != null) {
          config._d.setUTCMinutes(config._d.getUTCMinutes() - config._tzm);
        }
        if (config._nextDay) {
          config._a[HOUR] = 24;
        }
        if (config._w && typeof config._w.d !== "undefined" && config._w.d !== expectedWeekday) {
          getParsingFlags(config).weekdayMismatch = true;
        }
      }
      function dayOfYearFromWeekInfo(config) {
        var w, weekYear, week, weekday, dow, doy, temp, weekdayOverflow, curWeek;
        w = config._w;
        if (w.GG != null || w.W != null || w.E != null) {
          dow = 1;
          doy = 4;
          weekYear = defaults(w.GG, config._a[YEAR], weekOfYear(createLocal(), 1, 4).year);
          week = defaults(w.W, 1);
          weekday = defaults(w.E, 1);
          if (weekday < 1 || weekday > 7) {
            weekdayOverflow = true;
          }
        } else {
          dow = config._locale._week.dow;
          doy = config._locale._week.doy;
          curWeek = weekOfYear(createLocal(), dow, doy);
          weekYear = defaults(w.gg, config._a[YEAR], curWeek.year);
          week = defaults(w.w, curWeek.week);
          if (w.d != null) {
            weekday = w.d;
            if (weekday < 0 || weekday > 6) {
              weekdayOverflow = true;
            }
          } else if (w.e != null) {
            weekday = w.e + dow;
            if (w.e < 0 || w.e > 6) {
              weekdayOverflow = true;
            }
          } else {
            weekday = dow;
          }
        }
        if (week < 1 || week > weeksInYear(weekYear, dow, doy)) {
          getParsingFlags(config)._overflowWeeks = true;
        } else if (weekdayOverflow != null) {
          getParsingFlags(config)._overflowWeekday = true;
        } else {
          temp = dayOfYearFromWeeks(weekYear, week, weekday, dow, doy);
          config._a[YEAR] = temp.year;
          config._dayOfYear = temp.dayOfYear;
        }
      }
      hooks.ISO_8601 = function () {};
      hooks.RFC_2822 = function () {};
      function configFromStringAndFormat(config) {
        if (config._f === hooks.ISO_8601) {
          configFromISO(config);
          return;
        }
        if (config._f === hooks.RFC_2822) {
          configFromRFC2822(config);
          return;
        }
        config._a = [];
        getParsingFlags(config).empty = true;
        var string = "" + config._i,
          i,
          parsedInput,
          tokens2,
          token2,
          skipped,
          stringLength = string.length,
          totalParsedInputLength = 0,
          era,
          tokenLen;
        tokens2 = expandFormat(config._f, config._locale).match(formattingTokens) || [];
        tokenLen = tokens2.length;
        for (i = 0; i < tokenLen; i++) {
          token2 = tokens2[i];
          parsedInput = (string.match(getParseRegexForToken(token2, config)) || [])[0];
          if (parsedInput) {
            skipped = string.substr(0, string.indexOf(parsedInput));
            if (skipped.length > 0) {
              getParsingFlags(config).unusedInput.push(skipped);
            }
            string = string.slice(string.indexOf(parsedInput) + parsedInput.length);
            totalParsedInputLength += parsedInput.length;
          }
          if (formatTokenFunctions[token2]) {
            if (parsedInput) {
              getParsingFlags(config).empty = false;
            } else {
              getParsingFlags(config).unusedTokens.push(token2);
            }
            addTimeToArrayFromToken(token2, parsedInput, config);
          } else if (config._strict && !parsedInput) {
            getParsingFlags(config).unusedTokens.push(token2);
          }
        }
        getParsingFlags(config).charsLeftOver = stringLength - totalParsedInputLength;
        if (string.length > 0) {
          getParsingFlags(config).unusedInput.push(string);
        }
        if (config._a[HOUR] <= 12 && getParsingFlags(config).bigHour === true && config._a[HOUR] > 0) {
          getParsingFlags(config).bigHour = void 0;
        }
        getParsingFlags(config).parsedDateParts = config._a.slice(0);
        getParsingFlags(config).meridiem = config._meridiem;
        config._a[HOUR] = meridiemFixWrap(config._locale, config._a[HOUR], config._meridiem);
        era = getParsingFlags(config).era;
        if (era !== null) {
          config._a[YEAR] = config._locale.erasConvertYear(era, config._a[YEAR]);
        }
        configFromArray(config);
        checkOverflow(config);
      }
      function meridiemFixWrap(locale2, hour, meridiem2) {
        var isPm;
        if (meridiem2 == null) {
          return hour;
        }
        if (locale2.meridiemHour != null) {
          return locale2.meridiemHour(hour, meridiem2);
        } else if (locale2.isPM != null) {
          isPm = locale2.isPM(meridiem2);
          if (isPm && hour < 12) {
            hour += 12;
          }
          if (!isPm && hour === 12) {
            hour = 0;
          }
          return hour;
        } else {
          return hour;
        }
      }
      function configFromStringAndArray(config) {
        var tempConfig,
          bestMoment,
          scoreToBeat,
          i,
          currentScore,
          validFormatFound,
          bestFormatIsValid = false,
          configfLen = config._f.length;
        if (configfLen === 0) {
          getParsingFlags(config).invalidFormat = true;
          config._d = new Date(NaN);
          return;
        }
        for (i = 0; i < configfLen; i++) {
          currentScore = 0;
          validFormatFound = false;
          tempConfig = copyConfig({}, config);
          if (config._useUTC != null) {
            tempConfig._useUTC = config._useUTC;
          }
          tempConfig._f = config._f[i];
          configFromStringAndFormat(tempConfig);
          if (isValid(tempConfig)) {
            validFormatFound = true;
          }
          currentScore += getParsingFlags(tempConfig).charsLeftOver;
          currentScore += getParsingFlags(tempConfig).unusedTokens.length * 10;
          getParsingFlags(tempConfig).score = currentScore;
          if (!bestFormatIsValid) {
            if (scoreToBeat == null || currentScore < scoreToBeat || validFormatFound) {
              scoreToBeat = currentScore;
              bestMoment = tempConfig;
              if (validFormatFound) {
                bestFormatIsValid = true;
              }
            }
          } else {
            if (currentScore < scoreToBeat) {
              scoreToBeat = currentScore;
              bestMoment = tempConfig;
            }
          }
        }
        extend(config, bestMoment || tempConfig);
      }
      function configFromObject(config) {
        if (config._d) {
          return;
        }
        var i = normalizeObjectUnits(config._i),
          dayOrDate = i.day === void 0 ? i.date : i.day;
        config._a = map([i.year, i.month, dayOrDate, i.hour, i.minute, i.second, i.millisecond], function (obj) {
          return obj && parseInt(obj, 10);
        });
        configFromArray(config);
      }
      function createFromConfig(config) {
        var res = new Moment(checkOverflow(prepareConfig(config)));
        if (res._nextDay) {
          res.add(1, "d");
          res._nextDay = void 0;
        }
        return res;
      }
      function prepareConfig(config) {
        var input = config._i,
          format2 = config._f;
        config._locale = config._locale || getLocale(config._l);
        if (input === null || format2 === void 0 && input === "") {
          return createInvalid({
            nullInput: true
          });
        }
        if (typeof input === "string") {
          config._i = input = config._locale.preparse(input);
        }
        if (isMoment(input)) {
          return new Moment(checkOverflow(input));
        } else if (isDate(input)) {
          config._d = input;
        } else if (isArray(format2)) {
          configFromStringAndArray(config);
        } else if (format2) {
          configFromStringAndFormat(config);
        } else {
          configFromInput(config);
        }
        if (!isValid(config)) {
          config._d = null;
        }
        return config;
      }
      function configFromInput(config) {
        var input = config._i;
        if (isUndefined(input)) {
          config._d = new Date(hooks.now());
        } else if (isDate(input)) {
          config._d = new Date(input.valueOf());
        } else if (typeof input === "string") {
          configFromString(config);
        } else if (isArray(input)) {
          config._a = map(input.slice(0), function (obj) {
            return parseInt(obj, 10);
          });
          configFromArray(config);
        } else if (isObject(input)) {
          configFromObject(config);
        } else if (isNumber(input)) {
          config._d = new Date(input);
        } else {
          hooks.createFromInputFallback(config);
        }
      }
      function createLocalOrUTC(input, format2, locale2, strict, isUTC) {
        var c = {};
        if (format2 === true || format2 === false) {
          strict = format2;
          format2 = void 0;
        }
        if (locale2 === true || locale2 === false) {
          strict = locale2;
          locale2 = void 0;
        }
        if (isObject(input) && isObjectEmpty(input) || isArray(input) && input.length === 0) {
          input = void 0;
        }
        c._isAMomentObject = true;
        c._useUTC = c._isUTC = isUTC;
        c._l = locale2;
        c._i = input;
        c._f = format2;
        c._strict = strict;
        return createFromConfig(c);
      }
      function createLocal(input, format2, locale2, strict) {
        return createLocalOrUTC(input, format2, locale2, strict, false);
      }
      var prototypeMin = deprecate("moment().min is deprecated, use moment.max instead. http://momentjs.com/guides/#/warnings/min-max/", function () {
          var other = createLocal.apply(null, arguments);
          if (this.isValid() && other.isValid()) {
            return other < this ? this : other;
          } else {
            return createInvalid();
          }
        }),
        prototypeMax = deprecate("moment().max is deprecated, use moment.min instead. http://momentjs.com/guides/#/warnings/min-max/", function () {
          var other = createLocal.apply(null, arguments);
          if (this.isValid() && other.isValid()) {
            return other > this ? this : other;
          } else {
            return createInvalid();
          }
        });
      function pickBy(fn, moments) {
        var res, i;
        if (moments.length === 1 && isArray(moments[0])) {
          moments = moments[0];
        }
        if (!moments.length) {
          return createLocal();
        }
        res = moments[0];
        for (i = 1; i < moments.length; ++i) {
          if (!moments[i].isValid() || moments[i][fn](res)) {
            res = moments[i];
          }
        }
        return res;
      }
      function min() {
        var args = [].slice.call(arguments, 0);
        return pickBy("isBefore", args);
      }
      function max() {
        var args = [].slice.call(arguments, 0);
        return pickBy("isAfter", args);
      }
      var now = function () {
        return Date.now ? Date.now() : +new Date();
      };
      var ordering = ["year", "quarter", "month", "week", "day", "hour", "minute", "second", "millisecond"];
      function isDurationValid(m) {
        var key,
          unitHasDecimal = false,
          i,
          orderLen = ordering.length;
        for (key in m) {
          if (hasOwnProp(m, key) && !(indexOf.call(ordering, key) !== -1 && (m[key] == null || !isNaN(m[key])))) {
            return false;
          }
        }
        for (i = 0; i < orderLen; ++i) {
          if (m[ordering[i]]) {
            if (unitHasDecimal) {
              return false;
            }
            if (parseFloat(m[ordering[i]]) !== toInt(m[ordering[i]])) {
              unitHasDecimal = true;
            }
          }
        }
        return true;
      }
      function isValid$1() {
        return this._isValid;
      }
      function createInvalid$1() {
        return createDuration(NaN);
      }
      function Duration(duration) {
        var normalizedInput = normalizeObjectUnits(duration),
          years2 = normalizedInput.year || 0,
          quarters = normalizedInput.quarter || 0,
          months2 = normalizedInput.month || 0,
          weeks2 = normalizedInput.week || normalizedInput.isoWeek || 0,
          days2 = normalizedInput.day || 0,
          hours2 = normalizedInput.hour || 0,
          minutes2 = normalizedInput.minute || 0,
          seconds2 = normalizedInput.second || 0,
          milliseconds2 = normalizedInput.millisecond || 0;
        this._isValid = isDurationValid(normalizedInput);
        this._milliseconds = +milliseconds2 + seconds2 * 1e3 + minutes2 * 6e4 + hours2 * 1e3 * 60 * 60;
        this._days = +days2 + weeks2 * 7;
        this._months = +months2 + quarters * 3 + years2 * 12;
        this._data = {};
        this._locale = getLocale();
        this._bubble();
      }
      function isDuration(obj) {
        return obj instanceof Duration;
      }
      function absRound(number) {
        if (number < 0) {
          return Math.round(-1 * number) * -1;
        } else {
          return Math.round(number);
        }
      }
      function compareArrays(array1, array2, dontConvert) {
        var len = Math.min(array1.length, array2.length),
          lengthDiff = Math.abs(array1.length - array2.length),
          diffs = 0,
          i;
        for (i = 0; i < len; i++) {
          if (dontConvert && array1[i] !== array2[i] || !dontConvert && toInt(array1[i]) !== toInt(array2[i])) {
            diffs++;
          }
        }
        return diffs + lengthDiff;
      }
      function offset(token2, separator) {
        addFormatToken(token2, 0, 0, function () {
          var offset2 = this.utcOffset(),
            sign2 = "+";
          if (offset2 < 0) {
            offset2 = -offset2;
            sign2 = "-";
          }
          return sign2 + zeroFill(~~(offset2 / 60), 2) + separator + zeroFill(~~offset2 % 60, 2);
        });
      }
      offset("Z", ":");
      offset("ZZ", "");
      addRegexToken("Z", matchShortOffset);
      addRegexToken("ZZ", matchShortOffset);
      addParseToken(["Z", "ZZ"], function (input, array, config) {
        config._useUTC = true;
        config._tzm = offsetFromString(matchShortOffset, input);
      });
      var chunkOffset = /([\+\-]|\d\d)/gi;
      function offsetFromString(matcher, string) {
        var matches = (string || "").match(matcher),
          chunk,
          parts,
          minutes2;
        if (matches === null) {
          return null;
        }
        chunk = matches[matches.length - 1] || [];
        parts = (chunk + "").match(chunkOffset) || ["-", 0, 0];
        minutes2 = +(parts[1] * 60) + toInt(parts[2]);
        return minutes2 === 0 ? 0 : parts[0] === "+" ? minutes2 : -minutes2;
      }
      function cloneWithOffset(input, model) {
        var res, diff2;
        if (model._isUTC) {
          res = model.clone();
          diff2 = (isMoment(input) || isDate(input) ? input.valueOf() : createLocal(input).valueOf()) - res.valueOf();
          res._d.setTime(res._d.valueOf() + diff2);
          hooks.updateOffset(res, false);
          return res;
        } else {
          return createLocal(input).local();
        }
      }
      function getDateOffset(m) {
        return -Math.round(m._d.getTimezoneOffset());
      }
      hooks.updateOffset = function () {};
      function getSetOffset(input, keepLocalTime, keepMinutes) {
        var offset2 = this._offset || 0,
          localAdjust;
        if (!this.isValid()) {
          return input != null ? this : NaN;
        }
        if (input != null) {
          if (typeof input === "string") {
            input = offsetFromString(matchShortOffset, input);
            if (input === null) {
              return this;
            }
          } else if (Math.abs(input) < 16 && !keepMinutes) {
            input = input * 60;
          }
          if (!this._isUTC && keepLocalTime) {
            localAdjust = getDateOffset(this);
          }
          this._offset = input;
          this._isUTC = true;
          if (localAdjust != null) {
            this.add(localAdjust, "m");
          }
          if (offset2 !== input) {
            if (!keepLocalTime || this._changeInProgress) {
              addSubtract(this, createDuration(input - offset2, "m"), 1, false);
            } else if (!this._changeInProgress) {
              this._changeInProgress = true;
              hooks.updateOffset(this, true);
              this._changeInProgress = null;
            }
          }
          return this;
        } else {
          return this._isUTC ? offset2 : getDateOffset(this);
        }
      }
      function getSetZone(input, keepLocalTime) {
        if (input != null) {
          if (typeof input !== "string") {
            input = -input;
          }
          this.utcOffset(input, keepLocalTime);
          return this;
        } else {
          return -this.utcOffset();
        }
      }
      function setOffsetToUTC(keepLocalTime) {
        return this.utcOffset(0, keepLocalTime);
      }
      function setOffsetToLocal(keepLocalTime) {
        if (this._isUTC) {
          this.utcOffset(0, keepLocalTime);
          this._isUTC = false;
          if (keepLocalTime) {
            this.subtract(getDateOffset(this), "m");
          }
        }
        return this;
      }
      function setOffsetToParsedOffset() {
        if (this._tzm != null) {
          this.utcOffset(this._tzm, false, true);
        } else if (typeof this._i === "string") {
          var tZone = offsetFromString(matchOffset, this._i);
          if (tZone != null) {
            this.utcOffset(tZone);
          } else {
            this.utcOffset(0, true);
          }
        }
        return this;
      }
      function hasAlignedHourOffset(input) {
        if (!this.isValid()) {
          return false;
        }
        input = input ? createLocal(input).utcOffset() : 0;
        return (this.utcOffset() - input) % 60 === 0;
      }
      function isDaylightSavingTime() {
        return this.utcOffset() > this.clone().month(0).utcOffset() || this.utcOffset() > this.clone().month(5).utcOffset();
      }
      function isDaylightSavingTimeShifted() {
        if (!isUndefined(this._isDSTShifted)) {
          return this._isDSTShifted;
        }
        var c = {},
          other;
        copyConfig(c, this);
        c = prepareConfig(c);
        if (c._a) {
          other = c._isUTC ? createUTC(c._a) : createLocal(c._a);
          this._isDSTShifted = this.isValid() && compareArrays(c._a, other.toArray()) > 0;
        } else {
          this._isDSTShifted = false;
        }
        return this._isDSTShifted;
      }
      function isLocal() {
        return this.isValid() ? !this._isUTC : false;
      }
      function isUtcOffset() {
        return this.isValid() ? this._isUTC : false;
      }
      function isUtc() {
        return this.isValid() ? this._isUTC && this._offset === 0 : false;
      }
      var aspNetRegex = /^(-|\+)?(?:(\d*)[. ])?(\d+):(\d+)(?::(\d+)(\.\d*)?)?$/,
        isoRegex = /^(-|\+)?P(?:([-+]?[0-9,.]*)Y)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)W)?(?:([-+]?[0-9,.]*)D)?(?:T(?:([-+]?[0-9,.]*)H)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)S)?)?$/;
      function createDuration(input, key) {
        var duration = input,
          match = null,
          sign2,
          ret,
          diffRes;
        if (isDuration(input)) {
          duration = {
            ms: input._milliseconds,
            d: input._days,
            M: input._months
          };
        } else if (isNumber(input) || !isNaN(+input)) {
          duration = {};
          if (key) {
            duration[key] = +input;
          } else {
            duration.milliseconds = +input;
          }
        } else if (match = aspNetRegex.exec(input)) {
          sign2 = match[1] === "-" ? -1 : 1;
          duration = {
            y: 0,
            d: toInt(match[DATE]) * sign2,
            h: toInt(match[HOUR]) * sign2,
            m: toInt(match[MINUTE]) * sign2,
            s: toInt(match[SECOND]) * sign2,
            ms: toInt(absRound(match[MILLISECOND] * 1e3)) * sign2
          };
        } else if (match = isoRegex.exec(input)) {
          sign2 = match[1] === "-" ? -1 : 1;
          duration = {
            y: parseIso(match[2], sign2),
            M: parseIso(match[3], sign2),
            w: parseIso(match[4], sign2),
            d: parseIso(match[5], sign2),
            h: parseIso(match[6], sign2),
            m: parseIso(match[7], sign2),
            s: parseIso(match[8], sign2)
          };
        } else if (duration == null) {
          duration = {};
        } else if (typeof duration === "object" && ("from" in duration || "to" in duration)) {
          diffRes = momentsDifference(createLocal(duration.from), createLocal(duration.to));
          duration = {};
          duration.ms = diffRes.milliseconds;
          duration.M = diffRes.months;
        }
        ret = new Duration(duration);
        if (isDuration(input) && hasOwnProp(input, "_locale")) {
          ret._locale = input._locale;
        }
        if (isDuration(input) && hasOwnProp(input, "_isValid")) {
          ret._isValid = input._isValid;
        }
        return ret;
      }
      createDuration.fn = Duration.prototype;
      createDuration.invalid = createInvalid$1;
      function parseIso(inp, sign2) {
        var res = inp && parseFloat(inp.replace(",", "."));
        return (isNaN(res) ? 0 : res) * sign2;
      }
      function positiveMomentsDifference(base, other) {
        var res = {};
        res.months = other.month() - base.month() + (other.year() - base.year()) * 12;
        if (base.clone().add(res.months, "M").isAfter(other)) {
          --res.months;
        }
        res.milliseconds = +other - +base.clone().add(res.months, "M");
        return res;
      }
      function momentsDifference(base, other) {
        var res;
        if (!(base.isValid() && other.isValid())) {
          return {
            milliseconds: 0,
            months: 0
          };
        }
        other = cloneWithOffset(other, base);
        if (base.isBefore(other)) {
          res = positiveMomentsDifference(base, other);
        } else {
          res = positiveMomentsDifference(other, base);
          res.milliseconds = -res.milliseconds;
          res.months = -res.months;
        }
        return res;
      }
      function createAdder(direction, name) {
        return function (val, period) {
          var dur, tmp;
          if (period !== null && !isNaN(+period)) {
            deprecateSimple(name, "moment()." + name + "(period, number) is deprecated. Please use moment()." + name + "(number, period). See http://momentjs.com/guides/#/warnings/add-inverted-param/ for more info.");
            tmp = val;
            val = period;
            period = tmp;
          }
          dur = createDuration(val, period);
          addSubtract(this, dur, direction);
          return this;
        };
      }
      function addSubtract(mom, duration, isAdding, updateOffset) {
        var milliseconds2 = duration._milliseconds,
          days2 = absRound(duration._days),
          months2 = absRound(duration._months);
        if (!mom.isValid()) {
          return;
        }
        updateOffset = updateOffset == null ? true : updateOffset;
        if (months2) {
          setMonth(mom, get(mom, "Month") + months2 * isAdding);
        }
        if (days2) {
          set$1(mom, "Date", get(mom, "Date") + days2 * isAdding);
        }
        if (milliseconds2) {
          mom._d.setTime(mom._d.valueOf() + milliseconds2 * isAdding);
        }
        if (updateOffset) {
          hooks.updateOffset(mom, days2 || months2);
        }
      }
      var add = createAdder(1, "add"),
        subtract = createAdder(-1, "subtract");
      function isString(input) {
        return typeof input === "string" || input instanceof String;
      }
      function isMomentInput(input) {
        return isMoment(input) || isDate(input) || isString(input) || isNumber(input) || isNumberOrStringArray(input) || isMomentInputObject(input) || input === null || input === void 0;
      }
      function isMomentInputObject(input) {
        var objectTest = isObject(input) && !isObjectEmpty(input),
          propertyTest = false,
          properties = ["years", "year", "y", "months", "month", "M", "days", "day", "d", "dates", "date", "D", "hours", "hour", "h", "minutes", "minute", "m", "seconds", "second", "s", "milliseconds", "millisecond", "ms"],
          i,
          property,
          propertyLen = properties.length;
        for (i = 0; i < propertyLen; i += 1) {
          property = properties[i];
          propertyTest = propertyTest || hasOwnProp(input, property);
        }
        return objectTest && propertyTest;
      }
      function isNumberOrStringArray(input) {
        var arrayTest = isArray(input),
          dataTypeTest = false;
        if (arrayTest) {
          dataTypeTest = input.filter(function (item) {
            return !isNumber(item) && isString(input);
          }).length === 0;
        }
        return arrayTest && dataTypeTest;
      }
      function isCalendarSpec(input) {
        var objectTest = isObject(input) && !isObjectEmpty(input),
          propertyTest = false,
          properties = ["sameDay", "nextDay", "lastDay", "nextWeek", "lastWeek", "sameElse"],
          i,
          property;
        for (i = 0; i < properties.length; i += 1) {
          property = properties[i];
          propertyTest = propertyTest || hasOwnProp(input, property);
        }
        return objectTest && propertyTest;
      }
      function getCalendarFormat(myMoment, now2) {
        var diff2 = myMoment.diff(now2, "days", true);
        return diff2 < -6 ? "sameElse" : diff2 < -1 ? "lastWeek" : diff2 < 0 ? "lastDay" : diff2 < 1 ? "sameDay" : diff2 < 2 ? "nextDay" : diff2 < 7 ? "nextWeek" : "sameElse";
      }
      function calendar$1(time, formats) {
        if (arguments.length === 1) {
          if (!arguments[0]) {
            time = void 0;
            formats = void 0;
          } else if (isMomentInput(arguments[0])) {
            time = arguments[0];
            formats = void 0;
          } else if (isCalendarSpec(arguments[0])) {
            formats = arguments[0];
            time = void 0;
          }
        }
        var now2 = time || createLocal(),
          sod = cloneWithOffset(now2, this).startOf("day"),
          format2 = hooks.calendarFormat(this, sod) || "sameElse",
          output = formats && (isFunction(formats[format2]) ? formats[format2].call(this, now2) : formats[format2]);
        return this.format(output || this.localeData().calendar(format2, this, createLocal(now2)));
      }
      function clone() {
        return new Moment(this);
      }
      function isAfter(input, units) {
        var localInput = isMoment(input) ? input : createLocal(input);
        if (!(this.isValid() && localInput.isValid())) {
          return false;
        }
        units = normalizeUnits(units) || "millisecond";
        if (units === "millisecond") {
          return this.valueOf() > localInput.valueOf();
        } else {
          return localInput.valueOf() < this.clone().startOf(units).valueOf();
        }
      }
      function isBefore(input, units) {
        var localInput = isMoment(input) ? input : createLocal(input);
        if (!(this.isValid() && localInput.isValid())) {
          return false;
        }
        units = normalizeUnits(units) || "millisecond";
        if (units === "millisecond") {
          return this.valueOf() < localInput.valueOf();
        } else {
          return this.clone().endOf(units).valueOf() < localInput.valueOf();
        }
      }
      function isBetween(from2, to2, units, inclusivity) {
        var localFrom = isMoment(from2) ? from2 : createLocal(from2),
          localTo = isMoment(to2) ? to2 : createLocal(to2);
        if (!(this.isValid() && localFrom.isValid() && localTo.isValid())) {
          return false;
        }
        inclusivity = inclusivity || "()";
        return (inclusivity[0] === "(" ? this.isAfter(localFrom, units) : !this.isBefore(localFrom, units)) && (inclusivity[1] === ")" ? this.isBefore(localTo, units) : !this.isAfter(localTo, units));
      }
      function isSame(input, units) {
        var localInput = isMoment(input) ? input : createLocal(input),
          inputMs;
        if (!(this.isValid() && localInput.isValid())) {
          return false;
        }
        units = normalizeUnits(units) || "millisecond";
        if (units === "millisecond") {
          return this.valueOf() === localInput.valueOf();
        } else {
          inputMs = localInput.valueOf();
          return this.clone().startOf(units).valueOf() <= inputMs && inputMs <= this.clone().endOf(units).valueOf();
        }
      }
      function isSameOrAfter(input, units) {
        return this.isSame(input, units) || this.isAfter(input, units);
      }
      function isSameOrBefore(input, units) {
        return this.isSame(input, units) || this.isBefore(input, units);
      }
      function diff(input, units, asFloat) {
        var that, zoneDelta, output;
        if (!this.isValid()) {
          return NaN;
        }
        that = cloneWithOffset(input, this);
        if (!that.isValid()) {
          return NaN;
        }
        zoneDelta = (that.utcOffset() - this.utcOffset()) * 6e4;
        units = normalizeUnits(units);
        switch (units) {
          case "year":
            output = monthDiff(this, that) / 12;
            break;
          case "month":
            output = monthDiff(this, that);
            break;
          case "quarter":
            output = monthDiff(this, that) / 3;
            break;
          case "second":
            output = (this - that) / 1e3;
            break;
          case "minute":
            output = (this - that) / 6e4;
            break;
          case "hour":
            output = (this - that) / 36e5;
            break;
          case "day":
            output = (this - that - zoneDelta) / 864e5;
            break;
          case "week":
            output = (this - that - zoneDelta) / 6048e5;
            break;
          default:
            output = this - that;
        }
        return asFloat ? output : absFloor(output);
      }
      function monthDiff(a, b) {
        if (a.date() < b.date()) {
          return -monthDiff(b, a);
        }
        var wholeMonthDiff = (b.year() - a.year()) * 12 + (b.month() - a.month()),
          anchor = a.clone().add(wholeMonthDiff, "months"),
          anchor2,
          adjust;
        if (b - anchor < 0) {
          anchor2 = a.clone().add(wholeMonthDiff - 1, "months");
          adjust = (b - anchor) / (anchor - anchor2);
        } else {
          anchor2 = a.clone().add(wholeMonthDiff + 1, "months");
          adjust = (b - anchor) / (anchor2 - anchor);
        }
        return -(wholeMonthDiff + adjust) || 0;
      }
      hooks.defaultFormat = "YYYY-MM-DDTHH:mm:ssZ";
      hooks.defaultFormatUtc = "YYYY-MM-DDTHH:mm:ss[Z]";
      function toString() {
        return this.clone().locale("en").format("ddd MMM DD YYYY HH:mm:ss [GMT]ZZ");
      }
      function toISOString(keepOffset) {
        if (!this.isValid()) {
          return null;
        }
        var utc = keepOffset !== true,
          m = utc ? this.clone().utc() : this;
        if (m.year() < 0 || m.year() > 9999) {
          return formatMoment(m, utc ? "YYYYYY-MM-DD[T]HH:mm:ss.SSS[Z]" : "YYYYYY-MM-DD[T]HH:mm:ss.SSSZ");
        }
        if (isFunction(Date.prototype.toISOString)) {
          if (utc) {
            return this.toDate().toISOString();
          } else {
            return new Date(this.valueOf() + this.utcOffset() * 60 * 1e3).toISOString().replace("Z", formatMoment(m, "Z"));
          }
        }
        return formatMoment(m, utc ? "YYYY-MM-DD[T]HH:mm:ss.SSS[Z]" : "YYYY-MM-DD[T]HH:mm:ss.SSSZ");
      }
      function inspect() {
        if (!this.isValid()) {
          return "moment.invalid(/* " + this._i + " */)";
        }
        var func = "moment",
          zone = "",
          prefix,
          year,
          datetime,
          suffix;
        if (!this.isLocal()) {
          func = this.utcOffset() === 0 ? "moment.utc" : "moment.parseZone";
          zone = "Z";
        }
        prefix = "[" + func + '("]';
        year = 0 <= this.year() && this.year() <= 9999 ? "YYYY" : "YYYYYY";
        datetime = "-MM-DD[T]HH:mm:ss.SSS";
        suffix = zone + '[")]';
        return this.format(prefix + year + datetime + suffix);
      }
      function format(inputString) {
        if (!inputString) {
          inputString = this.isUtc() ? hooks.defaultFormatUtc : hooks.defaultFormat;
        }
        var output = formatMoment(this, inputString);
        return this.localeData().postformat(output);
      }
      function from(time, withoutSuffix) {
        if (this.isValid() && (isMoment(time) && time.isValid() || createLocal(time).isValid())) {
          return createDuration({
            to: this,
            from: time
          }).locale(this.locale()).humanize(!withoutSuffix);
        } else {
          return this.localeData().invalidDate();
        }
      }
      function fromNow(withoutSuffix) {
        return this.from(createLocal(), withoutSuffix);
      }
      function to(time, withoutSuffix) {
        if (this.isValid() && (isMoment(time) && time.isValid() || createLocal(time).isValid())) {
          return createDuration({
            from: this,
            to: time
          }).locale(this.locale()).humanize(!withoutSuffix);
        } else {
          return this.localeData().invalidDate();
        }
      }
      function toNow(withoutSuffix) {
        return this.to(createLocal(), withoutSuffix);
      }
      function locale(key) {
        var newLocaleData;
        if (key === void 0) {
          return this._locale._abbr;
        } else {
          newLocaleData = getLocale(key);
          if (newLocaleData != null) {
            this._locale = newLocaleData;
          }
          return this;
        }
      }
      var lang = deprecate("moment().lang() is deprecated. Instead, use moment().localeData() to get the language configuration. Use moment().locale() to change languages.", function (key) {
        if (key === void 0) {
          return this.localeData();
        } else {
          return this.locale(key);
        }
      });
      function localeData() {
        return this._locale;
      }
      var MS_PER_SECOND = 1e3,
        MS_PER_MINUTE = 60 * MS_PER_SECOND,
        MS_PER_HOUR = 60 * MS_PER_MINUTE,
        MS_PER_400_YEARS = (365 * 400 + 97) * 24 * MS_PER_HOUR;
      function mod$1(dividend, divisor) {
        return (dividend % divisor + divisor) % divisor;
      }
      function localStartOfDate(y, m, d) {
        if (y < 100 && y >= 0) {
          return new Date(y + 400, m, d) - MS_PER_400_YEARS;
        } else {
          return new Date(y, m, d).valueOf();
        }
      }
      function utcStartOfDate(y, m, d) {
        if (y < 100 && y >= 0) {
          return Date.UTC(y + 400, m, d) - MS_PER_400_YEARS;
        } else {
          return Date.UTC(y, m, d);
        }
      }
      function startOf(units) {
        var time, startOfDate;
        units = normalizeUnits(units);
        if (units === void 0 || units === "millisecond" || !this.isValid()) {
          return this;
        }
        startOfDate = this._isUTC ? utcStartOfDate : localStartOfDate;
        switch (units) {
          case "year":
            time = startOfDate(this.year(), 0, 1);
            break;
          case "quarter":
            time = startOfDate(this.year(), this.month() - this.month() % 3, 1);
            break;
          case "month":
            time = startOfDate(this.year(), this.month(), 1);
            break;
          case "week":
            time = startOfDate(this.year(), this.month(), this.date() - this.weekday());
            break;
          case "isoWeek":
            time = startOfDate(this.year(), this.month(), this.date() - (this.isoWeekday() - 1));
            break;
          case "day":
          case "date":
            time = startOfDate(this.year(), this.month(), this.date());
            break;
          case "hour":
            time = this._d.valueOf();
            time -= mod$1(time + (this._isUTC ? 0 : this.utcOffset() * MS_PER_MINUTE), MS_PER_HOUR);
            break;
          case "minute":
            time = this._d.valueOf();
            time -= mod$1(time, MS_PER_MINUTE);
            break;
          case "second":
            time = this._d.valueOf();
            time -= mod$1(time, MS_PER_SECOND);
            break;
        }
        this._d.setTime(time);
        hooks.updateOffset(this, true);
        return this;
      }
      function endOf(units) {
        var time, startOfDate;
        units = normalizeUnits(units);
        if (units === void 0 || units === "millisecond" || !this.isValid()) {
          return this;
        }
        startOfDate = this._isUTC ? utcStartOfDate : localStartOfDate;
        switch (units) {
          case "year":
            time = startOfDate(this.year() + 1, 0, 1) - 1;
            break;
          case "quarter":
            time = startOfDate(this.year(), this.month() - this.month() % 3 + 3, 1) - 1;
            break;
          case "month":
            time = startOfDate(this.year(), this.month() + 1, 1) - 1;
            break;
          case "week":
            time = startOfDate(this.year(), this.month(), this.date() - this.weekday() + 7) - 1;
            break;
          case "isoWeek":
            time = startOfDate(this.year(), this.month(), this.date() - (this.isoWeekday() - 1) + 7) - 1;
            break;
          case "day":
          case "date":
            time = startOfDate(this.year(), this.month(), this.date() + 1) - 1;
            break;
          case "hour":
            time = this._d.valueOf();
            time += MS_PER_HOUR - mod$1(time + (this._isUTC ? 0 : this.utcOffset() * MS_PER_MINUTE), MS_PER_HOUR) - 1;
            break;
          case "minute":
            time = this._d.valueOf();
            time += MS_PER_MINUTE - mod$1(time, MS_PER_MINUTE) - 1;
            break;
          case "second":
            time = this._d.valueOf();
            time += MS_PER_SECOND - mod$1(time, MS_PER_SECOND) - 1;
            break;
        }
        this._d.setTime(time);
        hooks.updateOffset(this, true);
        return this;
      }
      function valueOf() {
        return this._d.valueOf() - (this._offset || 0) * 6e4;
      }
      function unix() {
        return Math.floor(this.valueOf() / 1e3);
      }
      function toDate() {
        return new Date(this.valueOf());
      }
      function toArray() {
        var m = this;
        return [m.year(), m.month(), m.date(), m.hour(), m.minute(), m.second(), m.millisecond()];
      }
      function toObject() {
        var m = this;
        return {
          years: m.year(),
          months: m.month(),
          date: m.date(),
          hours: m.hours(),
          minutes: m.minutes(),
          seconds: m.seconds(),
          milliseconds: m.milliseconds()
        };
      }
      function toJSON() {
        return this.isValid() ? this.toISOString() : null;
      }
      function isValid$2() {
        return isValid(this);
      }
      function parsingFlags() {
        return extend({}, getParsingFlags(this));
      }
      function invalidAt() {
        return getParsingFlags(this).overflow;
      }
      function creationData() {
        return {
          input: this._i,
          format: this._f,
          locale: this._locale,
          isUTC: this._isUTC,
          strict: this._strict
        };
      }
      addFormatToken("N", 0, 0, "eraAbbr");
      addFormatToken("NN", 0, 0, "eraAbbr");
      addFormatToken("NNN", 0, 0, "eraAbbr");
      addFormatToken("NNNN", 0, 0, "eraName");
      addFormatToken("NNNNN", 0, 0, "eraNarrow");
      addFormatToken("y", ["y", 1], "yo", "eraYear");
      addFormatToken("y", ["yy", 2], 0, "eraYear");
      addFormatToken("y", ["yyy", 3], 0, "eraYear");
      addFormatToken("y", ["yyyy", 4], 0, "eraYear");
      addRegexToken("N", matchEraAbbr);
      addRegexToken("NN", matchEraAbbr);
      addRegexToken("NNN", matchEraAbbr);
      addRegexToken("NNNN", matchEraName);
      addRegexToken("NNNNN", matchEraNarrow);
      addParseToken(["N", "NN", "NNN", "NNNN", "NNNNN"], function (input, array, config, token2) {
        var era = config._locale.erasParse(input, token2, config._strict);
        if (era) {
          getParsingFlags(config).era = era;
        } else {
          getParsingFlags(config).invalidEra = input;
        }
      });
      addRegexToken("y", matchUnsigned);
      addRegexToken("yy", matchUnsigned);
      addRegexToken("yyy", matchUnsigned);
      addRegexToken("yyyy", matchUnsigned);
      addRegexToken("yo", matchEraYearOrdinal);
      addParseToken(["y", "yy", "yyy", "yyyy"], YEAR);
      addParseToken(["yo"], function (input, array, config, token2) {
        var match;
        if (config._locale._eraYearOrdinalRegex) {
          match = input.match(config._locale._eraYearOrdinalRegex);
        }
        if (config._locale.eraYearOrdinalParse) {
          array[YEAR] = config._locale.eraYearOrdinalParse(input, match);
        } else {
          array[YEAR] = parseInt(input, 10);
        }
      });
      function localeEras(m, format2) {
        var i,
          l,
          date,
          eras = this._eras || getLocale("en")._eras;
        for (i = 0, l = eras.length; i < l; ++i) {
          switch (typeof eras[i].since) {
            case "string":
              date = hooks(eras[i].since).startOf("day");
              eras[i].since = date.valueOf();
              break;
          }
          switch (typeof eras[i].until) {
            case "undefined":
              eras[i].until = Infinity;
              break;
            case "string":
              date = hooks(eras[i].until).startOf("day").valueOf();
              eras[i].until = date.valueOf();
              break;
          }
        }
        return eras;
      }
      function localeErasParse(eraName, format2, strict) {
        var i,
          l,
          eras = this.eras(),
          name,
          abbr,
          narrow;
        eraName = eraName.toUpperCase();
        for (i = 0, l = eras.length; i < l; ++i) {
          name = eras[i].name.toUpperCase();
          abbr = eras[i].abbr.toUpperCase();
          narrow = eras[i].narrow.toUpperCase();
          if (strict) {
            switch (format2) {
              case "N":
              case "NN":
              case "NNN":
                if (abbr === eraName) {
                  return eras[i];
                }
                break;
              case "NNNN":
                if (name === eraName) {
                  return eras[i];
                }
                break;
              case "NNNNN":
                if (narrow === eraName) {
                  return eras[i];
                }
                break;
            }
          } else if ([name, abbr, narrow].indexOf(eraName) >= 0) {
            return eras[i];
          }
        }
      }
      function localeErasConvertYear(era, year) {
        var dir = era.since <= era.until ? 1 : -1;
        if (year === void 0) {
          return hooks(era.since).year();
        } else {
          return hooks(era.since).year() + (year - era.offset) * dir;
        }
      }
      function getEraName() {
        var i,
          l,
          val,
          eras = this.localeData().eras();
        for (i = 0, l = eras.length; i < l; ++i) {
          val = this.clone().startOf("day").valueOf();
          if (eras[i].since <= val && val <= eras[i].until) {
            return eras[i].name;
          }
          if (eras[i].until <= val && val <= eras[i].since) {
            return eras[i].name;
          }
        }
        return "";
      }
      function getEraNarrow() {
        var i,
          l,
          val,
          eras = this.localeData().eras();
        for (i = 0, l = eras.length; i < l; ++i) {
          val = this.clone().startOf("day").valueOf();
          if (eras[i].since <= val && val <= eras[i].until) {
            return eras[i].narrow;
          }
          if (eras[i].until <= val && val <= eras[i].since) {
            return eras[i].narrow;
          }
        }
        return "";
      }
      function getEraAbbr() {
        var i,
          l,
          val,
          eras = this.localeData().eras();
        for (i = 0, l = eras.length; i < l; ++i) {
          val = this.clone().startOf("day").valueOf();
          if (eras[i].since <= val && val <= eras[i].until) {
            return eras[i].abbr;
          }
          if (eras[i].until <= val && val <= eras[i].since) {
            return eras[i].abbr;
          }
        }
        return "";
      }
      function getEraYear() {
        var i,
          l,
          dir,
          val,
          eras = this.localeData().eras();
        for (i = 0, l = eras.length; i < l; ++i) {
          dir = eras[i].since <= eras[i].until ? 1 : -1;
          val = this.clone().startOf("day").valueOf();
          if (eras[i].since <= val && val <= eras[i].until || eras[i].until <= val && val <= eras[i].since) {
            return (this.year() - hooks(eras[i].since).year()) * dir + eras[i].offset;
          }
        }
        return this.year();
      }
      function erasNameRegex(isStrict) {
        if (!hasOwnProp(this, "_erasNameRegex")) {
          computeErasParse.call(this);
        }
        return isStrict ? this._erasNameRegex : this._erasRegex;
      }
      function erasAbbrRegex(isStrict) {
        if (!hasOwnProp(this, "_erasAbbrRegex")) {
          computeErasParse.call(this);
        }
        return isStrict ? this._erasAbbrRegex : this._erasRegex;
      }
      function erasNarrowRegex(isStrict) {
        if (!hasOwnProp(this, "_erasNarrowRegex")) {
          computeErasParse.call(this);
        }
        return isStrict ? this._erasNarrowRegex : this._erasRegex;
      }
      function matchEraAbbr(isStrict, locale2) {
        return locale2.erasAbbrRegex(isStrict);
      }
      function matchEraName(isStrict, locale2) {
        return locale2.erasNameRegex(isStrict);
      }
      function matchEraNarrow(isStrict, locale2) {
        return locale2.erasNarrowRegex(isStrict);
      }
      function matchEraYearOrdinal(isStrict, locale2) {
        return locale2._eraYearOrdinalRegex || matchUnsigned;
      }
      function computeErasParse() {
        var abbrPieces = [],
          namePieces = [],
          narrowPieces = [],
          mixedPieces = [],
          i,
          l,
          erasName,
          erasAbbr,
          erasNarrow,
          eras = this.eras();
        for (i = 0, l = eras.length; i < l; ++i) {
          erasName = regexEscape(eras[i].name);
          erasAbbr = regexEscape(eras[i].abbr);
          erasNarrow = regexEscape(eras[i].narrow);
          namePieces.push(erasName);
          abbrPieces.push(erasAbbr);
          narrowPieces.push(erasNarrow);
          mixedPieces.push(erasName);
          mixedPieces.push(erasAbbr);
          mixedPieces.push(erasNarrow);
        }
        this._erasRegex = new RegExp("^(" + mixedPieces.join("|") + ")", "i");
        this._erasNameRegex = new RegExp("^(" + namePieces.join("|") + ")", "i");
        this._erasAbbrRegex = new RegExp("^(" + abbrPieces.join("|") + ")", "i");
        this._erasNarrowRegex = new RegExp("^(" + narrowPieces.join("|") + ")", "i");
      }
      addFormatToken(0, ["gg", 2], 0, function () {
        return this.weekYear() % 100;
      });
      addFormatToken(0, ["GG", 2], 0, function () {
        return this.isoWeekYear() % 100;
      });
      function addWeekYearFormatToken(token2, getter) {
        addFormatToken(0, [token2, token2.length], 0, getter);
      }
      addWeekYearFormatToken("gggg", "weekYear");
      addWeekYearFormatToken("ggggg", "weekYear");
      addWeekYearFormatToken("GGGG", "isoWeekYear");
      addWeekYearFormatToken("GGGGG", "isoWeekYear");
      addRegexToken("G", matchSigned);
      addRegexToken("g", matchSigned);
      addRegexToken("GG", match1to2, match2);
      addRegexToken("gg", match1to2, match2);
      addRegexToken("GGGG", match1to4, match4);
      addRegexToken("gggg", match1to4, match4);
      addRegexToken("GGGGG", match1to6, match6);
      addRegexToken("ggggg", match1to6, match6);
      addWeekParseToken(["gggg", "ggggg", "GGGG", "GGGGG"], function (input, week, config, token2) {
        week[token2.substr(0, 2)] = toInt(input);
      });
      addWeekParseToken(["gg", "GG"], function (input, week, config, token2) {
        week[token2] = hooks.parseTwoDigitYear(input);
      });
      function getSetWeekYear(input) {
        return getSetWeekYearHelper.call(this, input, this.week(), this.weekday() + this.localeData()._week.dow, this.localeData()._week.dow, this.localeData()._week.doy);
      }
      function getSetISOWeekYear(input) {
        return getSetWeekYearHelper.call(this, input, this.isoWeek(), this.isoWeekday(), 1, 4);
      }
      function getISOWeeksInYear() {
        return weeksInYear(this.year(), 1, 4);
      }
      function getISOWeeksInISOWeekYear() {
        return weeksInYear(this.isoWeekYear(), 1, 4);
      }
      function getWeeksInYear() {
        var weekInfo = this.localeData()._week;
        return weeksInYear(this.year(), weekInfo.dow, weekInfo.doy);
      }
      function getWeeksInWeekYear() {
        var weekInfo = this.localeData()._week;
        return weeksInYear(this.weekYear(), weekInfo.dow, weekInfo.doy);
      }
      function getSetWeekYearHelper(input, week, weekday, dow, doy) {
        var weeksTarget;
        if (input == null) {
          return weekOfYear(this, dow, doy).year;
        } else {
          weeksTarget = weeksInYear(input, dow, doy);
          if (week > weeksTarget) {
            week = weeksTarget;
          }
          return setWeekAll.call(this, input, week, weekday, dow, doy);
        }
      }
      function setWeekAll(weekYear, week, weekday, dow, doy) {
        var dayOfYearData = dayOfYearFromWeeks(weekYear, week, weekday, dow, doy),
          date = createUTCDate(dayOfYearData.year, 0, dayOfYearData.dayOfYear);
        this.year(date.getUTCFullYear());
        this.month(date.getUTCMonth());
        this.date(date.getUTCDate());
        return this;
      }
      addFormatToken("Q", 0, "Qo", "quarter");
      addRegexToken("Q", match1);
      addParseToken("Q", function (input, array) {
        array[MONTH] = (toInt(input) - 1) * 3;
      });
      function getSetQuarter(input) {
        return input == null ? Math.ceil((this.month() + 1) / 3) : this.month((input - 1) * 3 + this.month() % 3);
      }
      addFormatToken("D", ["DD", 2], "Do", "date");
      addRegexToken("D", match1to2, match1to2NoLeadingZero);
      addRegexToken("DD", match1to2, match2);
      addRegexToken("Do", function (isStrict, locale2) {
        return isStrict ? locale2._dayOfMonthOrdinalParse || locale2._ordinalParse : locale2._dayOfMonthOrdinalParseLenient;
      });
      addParseToken(["D", "DD"], DATE);
      addParseToken("Do", function (input, array) {
        array[DATE] = toInt(input.match(match1to2)[0]);
      });
      var getSetDayOfMonth = makeGetSet("Date", true);
      addFormatToken("DDD", ["DDDD", 3], "DDDo", "dayOfYear");
      addRegexToken("DDD", match1to3);
      addRegexToken("DDDD", match3);
      addParseToken(["DDD", "DDDD"], function (input, array, config) {
        config._dayOfYear = toInt(input);
      });
      function getSetDayOfYear(input) {
        var dayOfYear = Math.round((this.clone().startOf("day") - this.clone().startOf("year")) / 864e5) + 1;
        return input == null ? dayOfYear : this.add(input - dayOfYear, "d");
      }
      addFormatToken("m", ["mm", 2], 0, "minute");
      addRegexToken("m", match1to2, match1to2HasZero);
      addRegexToken("mm", match1to2, match2);
      addParseToken(["m", "mm"], MINUTE);
      var getSetMinute = makeGetSet("Minutes", false);
      addFormatToken("s", ["ss", 2], 0, "second");
      addRegexToken("s", match1to2, match1to2HasZero);
      addRegexToken("ss", match1to2, match2);
      addParseToken(["s", "ss"], SECOND);
      var getSetSecond = makeGetSet("Seconds", false);
      addFormatToken("S", 0, 0, function () {
        return ~~(this.millisecond() / 100);
      });
      addFormatToken(0, ["SS", 2], 0, function () {
        return ~~(this.millisecond() / 10);
      });
      addFormatToken(0, ["SSS", 3], 0, "millisecond");
      addFormatToken(0, ["SSSS", 4], 0, function () {
        return this.millisecond() * 10;
      });
      addFormatToken(0, ["SSSSS", 5], 0, function () {
        return this.millisecond() * 100;
      });
      addFormatToken(0, ["SSSSSS", 6], 0, function () {
        return this.millisecond() * 1e3;
      });
      addFormatToken(0, ["SSSSSSS", 7], 0, function () {
        return this.millisecond() * 1e4;
      });
      addFormatToken(0, ["SSSSSSSS", 8], 0, function () {
        return this.millisecond() * 1e5;
      });
      addFormatToken(0, ["SSSSSSSSS", 9], 0, function () {
        return this.millisecond() * 1e6;
      });
      addRegexToken("S", match1to3, match1);
      addRegexToken("SS", match1to3, match2);
      addRegexToken("SSS", match1to3, match3);
      var token, getSetMillisecond;
      for (token = "SSSS"; token.length <= 9; token += "S") {
        addRegexToken(token, matchUnsigned);
      }
      function parseMs(input, array) {
        array[MILLISECOND] = toInt(("0." + input) * 1e3);
      }
      for (token = "S"; token.length <= 9; token += "S") {
        addParseToken(token, parseMs);
      }
      getSetMillisecond = makeGetSet("Milliseconds", false);
      addFormatToken("z", 0, 0, "zoneAbbr");
      addFormatToken("zz", 0, 0, "zoneName");
      function getZoneAbbr() {
        return this._isUTC ? "UTC" : "";
      }
      function getZoneName() {
        return this._isUTC ? "Coordinated Universal Time" : "";
      }
      var proto = Moment.prototype;
      proto.add = add;
      proto.calendar = calendar$1;
      proto.clone = clone;
      proto.diff = diff;
      proto.endOf = endOf;
      proto.format = format;
      proto.from = from;
      proto.fromNow = fromNow;
      proto.to = to;
      proto.toNow = toNow;
      proto.get = stringGet;
      proto.invalidAt = invalidAt;
      proto.isAfter = isAfter;
      proto.isBefore = isBefore;
      proto.isBetween = isBetween;
      proto.isSame = isSame;
      proto.isSameOrAfter = isSameOrAfter;
      proto.isSameOrBefore = isSameOrBefore;
      proto.isValid = isValid$2;
      proto.lang = lang;
      proto.locale = locale;
      proto.localeData = localeData;
      proto.max = prototypeMax;
      proto.min = prototypeMin;
      proto.parsingFlags = parsingFlags;
      proto.set = stringSet;
      proto.startOf = startOf;
      proto.subtract = subtract;
      proto.toArray = toArray;
      proto.toObject = toObject;
      proto.toDate = toDate;
      proto.toISOString = toISOString;
      proto.inspect = inspect;
      if (typeof Symbol !== "undefined" && Symbol.for != null) {
        proto[Symbol.for("nodejs.util.inspect.custom")] = function () {
          return "Moment<" + this.format() + ">";
        };
      }
      proto.toJSON = toJSON;
      proto.toString = toString;
      proto.unix = unix;
      proto.valueOf = valueOf;
      proto.creationData = creationData;
      proto.eraName = getEraName;
      proto.eraNarrow = getEraNarrow;
      proto.eraAbbr = getEraAbbr;
      proto.eraYear = getEraYear;
      proto.year = getSetYear;
      proto.isLeapYear = getIsLeapYear;
      proto.weekYear = getSetWeekYear;
      proto.isoWeekYear = getSetISOWeekYear;
      proto.quarter = proto.quarters = getSetQuarter;
      proto.month = getSetMonth;
      proto.daysInMonth = getDaysInMonth;
      proto.week = proto.weeks = getSetWeek;
      proto.isoWeek = proto.isoWeeks = getSetISOWeek;
      proto.weeksInYear = getWeeksInYear;
      proto.weeksInWeekYear = getWeeksInWeekYear;
      proto.isoWeeksInYear = getISOWeeksInYear;
      proto.isoWeeksInISOWeekYear = getISOWeeksInISOWeekYear;
      proto.date = getSetDayOfMonth;
      proto.day = proto.days = getSetDayOfWeek;
      proto.weekday = getSetLocaleDayOfWeek;
      proto.isoWeekday = getSetISODayOfWeek;
      proto.dayOfYear = getSetDayOfYear;
      proto.hour = proto.hours = getSetHour;
      proto.minute = proto.minutes = getSetMinute;
      proto.second = proto.seconds = getSetSecond;
      proto.millisecond = proto.milliseconds = getSetMillisecond;
      proto.utcOffset = getSetOffset;
      proto.utc = setOffsetToUTC;
      proto.local = setOffsetToLocal;
      proto.parseZone = setOffsetToParsedOffset;
      proto.hasAlignedHourOffset = hasAlignedHourOffset;
      proto.isDST = isDaylightSavingTime;
      proto.isLocal = isLocal;
      proto.isUtcOffset = isUtcOffset;
      proto.isUtc = isUtc;
      proto.isUTC = isUtc;
      proto.zoneAbbr = getZoneAbbr;
      proto.zoneName = getZoneName;
      proto.dates = deprecate("dates accessor is deprecated. Use date instead.", getSetDayOfMonth);
      proto.months = deprecate("months accessor is deprecated. Use month instead", getSetMonth);
      proto.years = deprecate("years accessor is deprecated. Use year instead", getSetYear);
      proto.zone = deprecate("moment().zone is deprecated, use moment().utcOffset instead. http://momentjs.com/guides/#/warnings/zone/", getSetZone);
      proto.isDSTShifted = deprecate("isDSTShifted is deprecated. See http://momentjs.com/guides/#/warnings/dst-shifted/ for more information", isDaylightSavingTimeShifted);
      function createUnix(input) {
        return createLocal(input * 1e3);
      }
      function createInZone() {
        return createLocal.apply(null, arguments).parseZone();
      }
      function preParsePostFormat(string) {
        return string;
      }
      var proto$1 = Locale.prototype;
      proto$1.calendar = calendar;
      proto$1.longDateFormat = longDateFormat;
      proto$1.invalidDate = invalidDate;
      proto$1.ordinal = ordinal;
      proto$1.preparse = preParsePostFormat;
      proto$1.postformat = preParsePostFormat;
      proto$1.relativeTime = relativeTime;
      proto$1.pastFuture = pastFuture;
      proto$1.set = set;
      proto$1.eras = localeEras;
      proto$1.erasParse = localeErasParse;
      proto$1.erasConvertYear = localeErasConvertYear;
      proto$1.erasAbbrRegex = erasAbbrRegex;
      proto$1.erasNameRegex = erasNameRegex;
      proto$1.erasNarrowRegex = erasNarrowRegex;
      proto$1.months = localeMonths;
      proto$1.monthsShort = localeMonthsShort;
      proto$1.monthsParse = localeMonthsParse;
      proto$1.monthsRegex = monthsRegex;
      proto$1.monthsShortRegex = monthsShortRegex;
      proto$1.week = localeWeek;
      proto$1.firstDayOfYear = localeFirstDayOfYear;
      proto$1.firstDayOfWeek = localeFirstDayOfWeek;
      proto$1.weekdays = localeWeekdays;
      proto$1.weekdaysMin = localeWeekdaysMin;
      proto$1.weekdaysShort = localeWeekdaysShort;
      proto$1.weekdaysParse = localeWeekdaysParse;
      proto$1.weekdaysRegex = weekdaysRegex;
      proto$1.weekdaysShortRegex = weekdaysShortRegex;
      proto$1.weekdaysMinRegex = weekdaysMinRegex;
      proto$1.isPM = localeIsPM;
      proto$1.meridiem = localeMeridiem;
      function get$1(format2, index, field, setter) {
        var locale2 = getLocale(),
          utc = createUTC().set(setter, index);
        return locale2[field](utc, format2);
      }
      function listMonthsImpl(format2, index, field) {
        if (isNumber(format2)) {
          index = format2;
          format2 = void 0;
        }
        format2 = format2 || "";
        if (index != null) {
          return get$1(format2, index, field, "month");
        }
        var i,
          out = [];
        for (i = 0; i < 12; i++) {
          out[i] = get$1(format2, i, field, "month");
        }
        return out;
      }
      function listWeekdaysImpl(localeSorted, format2, index, field) {
        if (typeof localeSorted === "boolean") {
          if (isNumber(format2)) {
            index = format2;
            format2 = void 0;
          }
          format2 = format2 || "";
        } else {
          format2 = localeSorted;
          index = format2;
          localeSorted = false;
          if (isNumber(format2)) {
            index = format2;
            format2 = void 0;
          }
          format2 = format2 || "";
        }
        var locale2 = getLocale(),
          shift = localeSorted ? locale2._week.dow : 0,
          i,
          out = [];
        if (index != null) {
          return get$1(format2, (index + shift) % 7, field, "day");
        }
        for (i = 0; i < 7; i++) {
          out[i] = get$1(format2, (i + shift) % 7, field, "day");
        }
        return out;
      }
      function listMonths(format2, index) {
        return listMonthsImpl(format2, index, "months");
      }
      function listMonthsShort(format2, index) {
        return listMonthsImpl(format2, index, "monthsShort");
      }
      function listWeekdays(localeSorted, format2, index) {
        return listWeekdaysImpl(localeSorted, format2, index, "weekdays");
      }
      function listWeekdaysShort(localeSorted, format2, index) {
        return listWeekdaysImpl(localeSorted, format2, index, "weekdaysShort");
      }
      function listWeekdaysMin(localeSorted, format2, index) {
        return listWeekdaysImpl(localeSorted, format2, index, "weekdaysMin");
      }
      getSetGlobalLocale("en", {
        eras: [{
          since: "0001-01-01",
          until: Infinity,
          offset: 1,
          name: "Anno Domini",
          narrow: "AD",
          abbr: "AD"
        }, {
          since: "0000-12-31",
          until: -Infinity,
          offset: 1,
          name: "Before Christ",
          narrow: "BC",
          abbr: "BC"
        }],
        dayOfMonthOrdinalParse: /\d{1,2}(th|st|nd|rd)/,
        ordinal: function (number) {
          var b = number % 10,
            output = toInt(number % 100 / 10) === 1 ? "th" : b === 1 ? "st" : b === 2 ? "nd" : b === 3 ? "rd" : "th";
          return number + output;
        }
      });
      hooks.lang = deprecate("moment.lang is deprecated. Use moment.locale instead.", getSetGlobalLocale);
      hooks.langData = deprecate("moment.langData is deprecated. Use moment.localeData instead.", getLocale);
      var mathAbs = Math.abs;
      function abs() {
        var data = this._data;
        this._milliseconds = mathAbs(this._milliseconds);
        this._days = mathAbs(this._days);
        this._months = mathAbs(this._months);
        data.milliseconds = mathAbs(data.milliseconds);
        data.seconds = mathAbs(data.seconds);
        data.minutes = mathAbs(data.minutes);
        data.hours = mathAbs(data.hours);
        data.months = mathAbs(data.months);
        data.years = mathAbs(data.years);
        return this;
      }
      function addSubtract$1(duration, input, value, direction) {
        var other = createDuration(input, value);
        duration._milliseconds += direction * other._milliseconds;
        duration._days += direction * other._days;
        duration._months += direction * other._months;
        return duration._bubble();
      }
      function add$1(input, value) {
        return addSubtract$1(this, input, value, 1);
      }
      function subtract$1(input, value) {
        return addSubtract$1(this, input, value, -1);
      }
      function absCeil(number) {
        if (number < 0) {
          return Math.floor(number);
        } else {
          return Math.ceil(number);
        }
      }
      function bubble() {
        var milliseconds2 = this._milliseconds,
          days2 = this._days,
          months2 = this._months,
          data = this._data,
          seconds2,
          minutes2,
          hours2,
          years2,
          monthsFromDays;
        if (!(milliseconds2 >= 0 && days2 >= 0 && months2 >= 0 || milliseconds2 <= 0 && days2 <= 0 && months2 <= 0)) {
          milliseconds2 += absCeil(monthsToDays(months2) + days2) * 864e5;
          days2 = 0;
          months2 = 0;
        }
        data.milliseconds = milliseconds2 % 1e3;
        seconds2 = absFloor(milliseconds2 / 1e3);
        data.seconds = seconds2 % 60;
        minutes2 = absFloor(seconds2 / 60);
        data.minutes = minutes2 % 60;
        hours2 = absFloor(minutes2 / 60);
        data.hours = hours2 % 24;
        days2 += absFloor(hours2 / 24);
        monthsFromDays = absFloor(daysToMonths(days2));
        months2 += monthsFromDays;
        days2 -= absCeil(monthsToDays(monthsFromDays));
        years2 = absFloor(months2 / 12);
        months2 %= 12;
        data.days = days2;
        data.months = months2;
        data.years = years2;
        return this;
      }
      function daysToMonths(days2) {
        return days2 * 4800 / 146097;
      }
      function monthsToDays(months2) {
        return months2 * 146097 / 4800;
      }
      function as(units) {
        if (!this.isValid()) {
          return NaN;
        }
        var days2,
          months2,
          milliseconds2 = this._milliseconds;
        units = normalizeUnits(units);
        if (units === "month" || units === "quarter" || units === "year") {
          days2 = this._days + milliseconds2 / 864e5;
          months2 = this._months + daysToMonths(days2);
          switch (units) {
            case "month":
              return months2;
            case "quarter":
              return months2 / 3;
            case "year":
              return months2 / 12;
          }
        } else {
          days2 = this._days + Math.round(monthsToDays(this._months));
          switch (units) {
            case "week":
              return days2 / 7 + milliseconds2 / 6048e5;
            case "day":
              return days2 + milliseconds2 / 864e5;
            case "hour":
              return days2 * 24 + milliseconds2 / 36e5;
            case "minute":
              return days2 * 1440 + milliseconds2 / 6e4;
            case "second":
              return days2 * 86400 + milliseconds2 / 1e3;
            case "millisecond":
              return Math.floor(days2 * 864e5) + milliseconds2;
            default:
              throw new Error("Unknown unit " + units);
          }
        }
      }
      function makeAs(alias) {
        return function () {
          return this.as(alias);
        };
      }
      var asMilliseconds = makeAs("ms"),
        asSeconds = makeAs("s"),
        asMinutes = makeAs("m"),
        asHours = makeAs("h"),
        asDays = makeAs("d"),
        asWeeks = makeAs("w"),
        asMonths = makeAs("M"),
        asQuarters = makeAs("Q"),
        asYears = makeAs("y"),
        valueOf$1 = asMilliseconds;
      function clone$1() {
        return createDuration(this);
      }
      function get$2(units) {
        units = normalizeUnits(units);
        return this.isValid() ? this[units + "s"]() : NaN;
      }
      function makeGetter(name) {
        return function () {
          return this.isValid() ? this._data[name] : NaN;
        };
      }
      var milliseconds = makeGetter("milliseconds"),
        seconds = makeGetter("seconds"),
        minutes = makeGetter("minutes"),
        hours = makeGetter("hours"),
        days = makeGetter("days"),
        months = makeGetter("months"),
        years = makeGetter("years");
      function weeks() {
        return absFloor(this.days() / 7);
      }
      var round = Math.round,
        thresholds = {
          ss: 44,
          s: 45,
          m: 45,
          h: 22,
          d: 26,
          w: null,
          M: 11
        };
      function substituteTimeAgo(string, number, withoutSuffix, isFuture, locale2) {
        return locale2.relativeTime(number || 1, !!withoutSuffix, string, isFuture);
      }
      function relativeTime$1(posNegDuration, withoutSuffix, thresholds2, locale2) {
        var duration = createDuration(posNegDuration).abs(),
          seconds2 = round(duration.as("s")),
          minutes2 = round(duration.as("m")),
          hours2 = round(duration.as("h")),
          days2 = round(duration.as("d")),
          months2 = round(duration.as("M")),
          weeks2 = round(duration.as("w")),
          years2 = round(duration.as("y")),
          a = seconds2 <= thresholds2.ss && ["s", seconds2] || seconds2 < thresholds2.s && ["ss", seconds2] || minutes2 <= 1 && ["m"] || minutes2 < thresholds2.m && ["mm", minutes2] || hours2 <= 1 && ["h"] || hours2 < thresholds2.h && ["hh", hours2] || days2 <= 1 && ["d"] || days2 < thresholds2.d && ["dd", days2];
        if (thresholds2.w != null) {
          a = a || weeks2 <= 1 && ["w"] || weeks2 < thresholds2.w && ["ww", weeks2];
        }
        a = a || months2 <= 1 && ["M"] || months2 < thresholds2.M && ["MM", months2] || years2 <= 1 && ["y"] || ["yy", years2];
        a[2] = withoutSuffix;
        a[3] = +posNegDuration > 0;
        a[4] = locale2;
        return substituteTimeAgo.apply(null, a);
      }
      function getSetRelativeTimeRounding(roundingFunction) {
        if (roundingFunction === void 0) {
          return round;
        }
        if (typeof roundingFunction === "function") {
          round = roundingFunction;
          return true;
        }
        return false;
      }
      function getSetRelativeTimeThreshold(threshold, limit) {
        if (thresholds[threshold] === void 0) {
          return false;
        }
        if (limit === void 0) {
          return thresholds[threshold];
        }
        thresholds[threshold] = limit;
        if (threshold === "s") {
          thresholds.ss = limit - 1;
        }
        return true;
      }
      function humanize(argWithSuffix, argThresholds) {
        if (!this.isValid()) {
          return this.localeData().invalidDate();
        }
        var withSuffix = false,
          th = thresholds,
          locale2,
          output;
        if (typeof argWithSuffix === "object") {
          argThresholds = argWithSuffix;
          argWithSuffix = false;
        }
        if (typeof argWithSuffix === "boolean") {
          withSuffix = argWithSuffix;
        }
        if (typeof argThresholds === "object") {
          th = Object.assign({}, thresholds, argThresholds);
          if (argThresholds.s != null && argThresholds.ss == null) {
            th.ss = argThresholds.s - 1;
          }
        }
        locale2 = this.localeData();
        output = relativeTime$1(this, !withSuffix, th, locale2);
        if (withSuffix) {
          output = locale2.pastFuture(+this, output);
        }
        return locale2.postformat(output);
      }
      var abs$1 = Math.abs;
      function sign(x) {
        return (x > 0) - (x < 0) || +x;
      }
      function toISOString$1() {
        if (!this.isValid()) {
          return this.localeData().invalidDate();
        }
        var seconds2 = abs$1(this._milliseconds) / 1e3,
          days2 = abs$1(this._days),
          months2 = abs$1(this._months),
          minutes2,
          hours2,
          years2,
          s,
          total = this.asSeconds(),
          totalSign,
          ymSign,
          daysSign,
          hmsSign;
        if (!total) {
          return "P0D";
        }
        minutes2 = absFloor(seconds2 / 60);
        hours2 = absFloor(minutes2 / 60);
        seconds2 %= 60;
        minutes2 %= 60;
        years2 = absFloor(months2 / 12);
        months2 %= 12;
        s = seconds2 ? seconds2.toFixed(3).replace(/\.?0+$/, "") : "";
        totalSign = total < 0 ? "-" : "";
        ymSign = sign(this._months) !== sign(total) ? "-" : "";
        daysSign = sign(this._days) !== sign(total) ? "-" : "";
        hmsSign = sign(this._milliseconds) !== sign(total) ? "-" : "";
        return totalSign + "P" + (years2 ? ymSign + years2 + "Y" : "") + (months2 ? ymSign + months2 + "M" : "") + (days2 ? daysSign + days2 + "D" : "") + (hours2 || minutes2 || seconds2 ? "T" : "") + (hours2 ? hmsSign + hours2 + "H" : "") + (minutes2 ? hmsSign + minutes2 + "M" : "") + (seconds2 ? hmsSign + s + "S" : "");
      }
      var proto$2 = Duration.prototype;
      proto$2.isValid = isValid$1;
      proto$2.abs = abs;
      proto$2.add = add$1;
      proto$2.subtract = subtract$1;
      proto$2.as = as;
      proto$2.asMilliseconds = asMilliseconds;
      proto$2.asSeconds = asSeconds;
      proto$2.asMinutes = asMinutes;
      proto$2.asHours = asHours;
      proto$2.asDays = asDays;
      proto$2.asWeeks = asWeeks;
      proto$2.asMonths = asMonths;
      proto$2.asQuarters = asQuarters;
      proto$2.asYears = asYears;
      proto$2.valueOf = valueOf$1;
      proto$2._bubble = bubble;
      proto$2.clone = clone$1;
      proto$2.get = get$2;
      proto$2.milliseconds = milliseconds;
      proto$2.seconds = seconds;
      proto$2.minutes = minutes;
      proto$2.hours = hours;
      proto$2.days = days;
      proto$2.weeks = weeks;
      proto$2.months = months;
      proto$2.years = years;
      proto$2.humanize = humanize;
      proto$2.toISOString = toISOString$1;
      proto$2.toString = toISOString$1;
      proto$2.toJSON = toISOString$1;
      proto$2.locale = locale;
      proto$2.localeData = localeData;
      proto$2.toIsoString = deprecate("toIsoString() is deprecated. Please use toISOString() instead (notice the capitals)", toISOString$1);
      proto$2.lang = lang;
      addFormatToken("X", 0, 0, "unix");
      addFormatToken("x", 0, 0, "valueOf");
      addRegexToken("x", matchSigned);
      addRegexToken("X", matchTimestamp);
      addParseToken("X", function (input, array, config) {
        config._d = new Date(parseFloat(input) * 1e3);
      });
      addParseToken("x", function (input, array, config) {
        config._d = new Date(toInt(input));
      });
      hooks.version = "2.30.1";
      setHookCallback(createLocal);
      hooks.fn = proto;
      hooks.min = min;
      hooks.max = max;
      hooks.now = now;
      hooks.utc = createUTC;
      hooks.unix = createUnix;
      hooks.months = listMonths;
      hooks.isDate = isDate;
      hooks.locale = getSetGlobalLocale;
      hooks.invalid = createInvalid;
      hooks.duration = createDuration;
      hooks.isMoment = isMoment;
      hooks.weekdays = listWeekdays;
      hooks.parseZone = createInZone;
      hooks.localeData = getLocale;
      hooks.isDuration = isDuration;
      hooks.monthsShort = listMonthsShort;
      hooks.weekdaysMin = listWeekdaysMin;
      hooks.defineLocale = defineLocale;
      hooks.updateLocale = updateLocale;
      hooks.locales = listLocales;
      hooks.weekdaysShort = listWeekdaysShort;
      hooks.normalizeUnits = normalizeUnits;
      hooks.relativeTimeRounding = getSetRelativeTimeRounding;
      hooks.relativeTimeThreshold = getSetRelativeTimeThreshold;
      hooks.calendarFormat = getCalendarFormat;
      hooks.prototype = proto;
      hooks.HTML5_FMT = {
        DATETIME_LOCAL: "YYYY-MM-DDTHH:mm",
        DATETIME_LOCAL_SECONDS: "YYYY-MM-DDTHH:mm:ss",
        DATETIME_LOCAL_MS: "YYYY-MM-DDTHH:mm:ss.SSS",
        DATE: "YYYY-MM-DD",
        TIME: "HH:mm",
        TIME_SECONDS: "HH:mm:ss",
        TIME_MS: "HH:mm:ss.SSS",
        WEEK: "GGGG-[W]WW",
        MONTH: "YYYY-MM"
      };
      return hooks;
    });
  }
});

// .beyond/uimport/temp/moment.2.30.1.js
var moment_2_30_1_exports = {};
__export(moment_2_30_1_exports, {
  default: () => moment_2_30_1_default
});
module.exports = __toCommonJS(moment_2_30_1_exports);
__reExport(moment_2_30_1_exports, __toESM(require_moment()), module.exports);
var import_moment = __toESM(require_moment());
var moment_2_30_1_default = import_moment.default;
//! authors : Tim Wood, Iskren Chernev, Moment.js contributors
//! license : MIT
//! moment.js
//! momentjs.com
//! version : 2.30.1
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL25vZGVfbW9kdWxlcy9tb21lbnQvbW9tZW50LmpzIiwiLi4vLmJleW9uZC91aW1wb3J0L3RlbXAvbW9tZW50LjIuMzAuMS5qcyJdLCJuYW1lcyI6WyJyZXF1aXJlX21vbWVudCIsIl9fY29tbW9uSlMiLCJub2RlX21vZHVsZXMvbW9tZW50L21vbWVudC5qcyIsImV4cG9ydHMiLCJtb2R1bGUyIiwiZ2xvYmFsIiwiZmFjdG9yeSIsImRlZmluZSIsImFtZCIsIm1vbWVudCIsImhvb2tDYWxsYmFjayIsImhvb2tzIiwiYXBwbHkiLCJhcmd1bWVudHMiLCJzZXRIb29rQ2FsbGJhY2siLCJjYWxsYmFjayIsImlzQXJyYXkiLCJpbnB1dCIsIkFycmF5IiwiT2JqZWN0IiwicHJvdG90eXBlIiwidG9TdHJpbmciLCJjYWxsIiwiaXNPYmplY3QiLCJoYXNPd25Qcm9wIiwiYSIsImIiLCJoYXNPd25Qcm9wZXJ0eSIsImlzT2JqZWN0RW1wdHkiLCJvYmoiLCJnZXRPd25Qcm9wZXJ0eU5hbWVzIiwibGVuZ3RoIiwiayIsImlzVW5kZWZpbmVkIiwiaXNOdW1iZXIiLCJpc0RhdGUiLCJEYXRlIiwibWFwIiwiYXJyIiwiZm4iLCJyZXMiLCJpIiwiYXJyTGVuIiwicHVzaCIsImV4dGVuZCIsInZhbHVlT2YiLCJjcmVhdGVVVEMiLCJmb3JtYXQyIiwibG9jYWxlMiIsInN0cmljdCIsImNyZWF0ZUxvY2FsT3JVVEMiLCJ1dGMiLCJkZWZhdWx0UGFyc2luZ0ZsYWdzIiwiZW1wdHkiLCJ1bnVzZWRUb2tlbnMiLCJ1bnVzZWRJbnB1dCIsIm92ZXJmbG93IiwiY2hhcnNMZWZ0T3ZlciIsIm51bGxJbnB1dCIsImludmFsaWRFcmEiLCJpbnZhbGlkTW9udGgiLCJpbnZhbGlkRm9ybWF0IiwidXNlckludmFsaWRhdGVkIiwiaXNvIiwicGFyc2VkRGF0ZVBhcnRzIiwiZXJhIiwibWVyaWRpZW0iLCJyZmMyODIyIiwid2Vla2RheU1pc21hdGNoIiwiZ2V0UGFyc2luZ0ZsYWdzIiwibSIsIl9wZiIsInNvbWUiLCJmdW4iLCJ0IiwibGVuIiwiaXNWYWxpZCIsImZsYWdzIiwicGFyc2VkUGFydHMiLCJpc05vd1ZhbGlkIiwiX2QiLCJpc05hTiIsImdldFRpbWUiLCJpbnZhbGlkV2Vla2RheSIsIl9zdHJpY3QiLCJiaWdIb3VyIiwiaXNGcm96ZW4iLCJfaXNWYWxpZCIsImNyZWF0ZUludmFsaWQiLCJOYU4iLCJtb21lbnRQcm9wZXJ0aWVzIiwidXBkYXRlSW5Qcm9ncmVzcyIsImNvcHlDb25maWciLCJ0bzIiLCJmcm9tMiIsInByb3AiLCJ2YWwiLCJtb21lbnRQcm9wZXJ0aWVzTGVuIiwiX2lzQU1vbWVudE9iamVjdCIsIl9pIiwiX2YiLCJfbCIsIl90em0iLCJfaXNVVEMiLCJfb2Zmc2V0IiwiX2xvY2FsZSIsIk1vbWVudCIsImNvbmZpZyIsInVwZGF0ZU9mZnNldCIsImlzTW9tZW50Iiwid2FybiIsIm1zZyIsInN1cHByZXNzRGVwcmVjYXRpb25XYXJuaW5ncyIsImNvbnNvbGUiLCJkZXByZWNhdGUiLCJmaXJzdFRpbWUiLCJkZXByZWNhdGlvbkhhbmRsZXIiLCJhcmdzIiwiYXJnIiwia2V5IiwiYXJnTGVuIiwic2xpY2UiLCJqb2luIiwiRXJyb3IiLCJzdGFjayIsImRlcHJlY2F0aW9ucyIsImRlcHJlY2F0ZVNpbXBsZSIsIm5hbWUiLCJpc0Z1bmN0aW9uIiwiRnVuY3Rpb24iLCJzZXQiLCJfY29uZmlnIiwiX2RheU9mTW9udGhPcmRpbmFsUGFyc2VMZW5pZW50IiwiUmVnRXhwIiwiX2RheU9mTW9udGhPcmRpbmFsUGFyc2UiLCJzb3VyY2UiLCJfb3JkaW5hbFBhcnNlIiwibWVyZ2VDb25maWdzIiwicGFyZW50Q29uZmlnIiwiY2hpbGRDb25maWciLCJMb2NhbGUiLCJrZXlzIiwiZGVmYXVsdENhbGVuZGFyIiwic2FtZURheSIsIm5leHREYXkiLCJuZXh0V2VlayIsImxhc3REYXkiLCJsYXN0V2VlayIsInNhbWVFbHNlIiwiY2FsZW5kYXIiLCJtb20iLCJub3cyIiwib3V0cHV0IiwiX2NhbGVuZGFyIiwiemVyb0ZpbGwiLCJudW1iZXIiLCJ0YXJnZXRMZW5ndGgiLCJmb3JjZVNpZ24iLCJhYnNOdW1iZXIiLCJNYXRoIiwiYWJzIiwiemVyb3NUb0ZpbGwiLCJzaWduMiIsInBvdyIsIm1heCIsInN1YnN0ciIsImZvcm1hdHRpbmdUb2tlbnMiLCJsb2NhbEZvcm1hdHRpbmdUb2tlbnMiLCJmb3JtYXRGdW5jdGlvbnMiLCJmb3JtYXRUb2tlbkZ1bmN0aW9ucyIsImFkZEZvcm1hdFRva2VuIiwidG9rZW4yIiwicGFkZGVkIiwib3JkaW5hbDIiLCJmdW5jIiwibG9jYWxlRGF0YSIsIm9yZGluYWwiLCJyZW1vdmVGb3JtYXR0aW5nVG9rZW5zIiwibWF0Y2giLCJyZXBsYWNlIiwibWFrZUZvcm1hdEZ1bmN0aW9uIiwiYXJyYXkiLCJpMiIsImZvcm1hdE1vbWVudCIsImludmFsaWREYXRlIiwiZXhwYW5kRm9ybWF0IiwicmVwbGFjZUxvbmdEYXRlRm9ybWF0VG9rZW5zIiwibG9uZ0RhdGVGb3JtYXQiLCJsYXN0SW5kZXgiLCJ0ZXN0IiwiZGVmYXVsdExvbmdEYXRlRm9ybWF0IiwiTFRTIiwiTFQiLCJMIiwiTEwiLCJMTEwiLCJMTExMIiwiX2xvbmdEYXRlRm9ybWF0IiwiZm9ybWF0VXBwZXIiLCJ0b1VwcGVyQ2FzZSIsInRvayIsImRlZmF1bHRJbnZhbGlkRGF0ZSIsIl9pbnZhbGlkRGF0ZSIsImRlZmF1bHRPcmRpbmFsIiwiZGVmYXVsdERheU9mTW9udGhPcmRpbmFsUGFyc2UiLCJfb3JkaW5hbCIsImRlZmF1bHRSZWxhdGl2ZVRpbWUiLCJmdXR1cmUiLCJwYXN0IiwicyIsInNzIiwibW0iLCJoIiwiaGgiLCJkIiwiZGQiLCJ3Iiwid3ciLCJNIiwiTU0iLCJ5IiwieXkiLCJyZWxhdGl2ZVRpbWUiLCJ3aXRob3V0U3VmZml4Iiwic3RyaW5nIiwiaXNGdXR1cmUiLCJfcmVsYXRpdmVUaW1lIiwicGFzdEZ1dHVyZSIsImRpZmYyIiwiYWxpYXNlcyIsIkQiLCJkYXRlcyIsImRhdGUiLCJkYXlzIiwiZGF5IiwiZSIsIndlZWtkYXlzIiwid2Vla2RheSIsIkUiLCJpc293ZWVrZGF5cyIsImlzb3dlZWtkYXkiLCJEREQiLCJkYXlvZnllYXJzIiwiZGF5b2Z5ZWFyIiwiaG91cnMiLCJob3VyIiwibXMiLCJtaWxsaXNlY29uZHMiLCJtaWxsaXNlY29uZCIsIm1pbnV0ZXMiLCJtaW51dGUiLCJtb250aHMiLCJtb250aCIsIlEiLCJxdWFydGVycyIsInF1YXJ0ZXIiLCJzZWNvbmRzIiwic2Vjb25kIiwiZ2ciLCJ3ZWVreWVhcnMiLCJ3ZWVreWVhciIsIkdHIiwiaXNvd2Vla3llYXJzIiwiaXNvd2Vla3llYXIiLCJ3ZWVrcyIsIndlZWsiLCJXIiwiaXNvd2Vla3MiLCJpc293ZWVrIiwieWVhcnMiLCJ5ZWFyIiwibm9ybWFsaXplVW5pdHMiLCJ1bml0cyIsInRvTG93ZXJDYXNlIiwibm9ybWFsaXplT2JqZWN0VW5pdHMiLCJpbnB1dE9iamVjdCIsIm5vcm1hbGl6ZWRJbnB1dCIsIm5vcm1hbGl6ZWRQcm9wIiwicHJpb3JpdGllcyIsImlzb1dlZWtkYXkiLCJkYXlPZlllYXIiLCJ3ZWVrWWVhciIsImlzb1dlZWtZZWFyIiwiaXNvV2VlayIsImdldFByaW9yaXRpemVkVW5pdHMiLCJ1bml0c09iaiIsInUiLCJ1bml0IiwicHJpb3JpdHkiLCJzb3J0IiwibWF0Y2gxIiwibWF0Y2gyIiwibWF0Y2gzIiwibWF0Y2g0IiwibWF0Y2g2IiwibWF0Y2gxdG8yIiwibWF0Y2gzdG80IiwibWF0Y2g1dG82IiwibWF0Y2gxdG8zIiwibWF0Y2gxdG80IiwibWF0Y2gxdG82IiwibWF0Y2hVbnNpZ25lZCIsIm1hdGNoU2lnbmVkIiwibWF0Y2hPZmZzZXQiLCJtYXRjaFNob3J0T2Zmc2V0IiwibWF0Y2hUaW1lc3RhbXAiLCJtYXRjaFdvcmQiLCJtYXRjaDF0bzJOb0xlYWRpbmdaZXJvIiwibWF0Y2gxdG8ySGFzWmVybyIsInJlZ2V4ZXMiLCJhZGRSZWdleFRva2VuIiwicmVnZXgiLCJzdHJpY3RSZWdleCIsImlzU3RyaWN0IiwibG9jYWxlRGF0YTIiLCJnZXRQYXJzZVJlZ2V4Rm9yVG9rZW4iLCJ1bmVzY2FwZUZvcm1hdCIsInJlZ2V4RXNjYXBlIiwibWF0Y2hlZCIsInAxIiwicDIiLCJwMyIsInA0IiwiYWJzRmxvb3IiLCJjZWlsIiwiZmxvb3IiLCJ0b0ludCIsImFyZ3VtZW50Rm9yQ29lcmNpb24iLCJjb2VyY2VkTnVtYmVyIiwidmFsdWUiLCJpc0Zpbml0ZSIsInRva2VucyIsImFkZFBhcnNlVG9rZW4iLCJ0b2tlbkxlbiIsImFkZFdlZWtQYXJzZVRva2VuIiwidG9rZW4zIiwiX3ciLCJhZGRUaW1lVG9BcnJheUZyb21Ub2tlbiIsIl9hIiwiaXNMZWFwWWVhciIsIllFQVIiLCJNT05USCIsIkRBVEUiLCJIT1VSIiwiTUlOVVRFIiwiU0VDT05EIiwiTUlMTElTRUNPTkQiLCJXRUVLIiwiV0VFS0RBWSIsInBhcnNlVHdvRGlnaXRZZWFyIiwicGFyc2VJbnQiLCJkYXlzSW5ZZWFyIiwiZ2V0U2V0WWVhciIsIm1ha2VHZXRTZXQiLCJnZXRJc0xlYXBZZWFyIiwia2VlcFRpbWUiLCJzZXQkMSIsImdldCIsImlzVVRDIiwiZ2V0VVRDTWlsbGlzZWNvbmRzIiwiZ2V0TWlsbGlzZWNvbmRzIiwiZ2V0VVRDU2Vjb25kcyIsImdldFNlY29uZHMiLCJnZXRVVENNaW51dGVzIiwiZ2V0TWludXRlcyIsImdldFVUQ0hvdXJzIiwiZ2V0SG91cnMiLCJnZXRVVENEYXRlIiwiZ2V0RGF0ZSIsImdldFVUQ0RheSIsImdldERheSIsImdldFVUQ01vbnRoIiwiZ2V0TW9udGgiLCJnZXRVVENGdWxsWWVhciIsImdldEZ1bGxZZWFyIiwic2V0VVRDTWlsbGlzZWNvbmRzIiwic2V0TWlsbGlzZWNvbmRzIiwic2V0VVRDU2Vjb25kcyIsInNldFNlY29uZHMiLCJzZXRVVENNaW51dGVzIiwic2V0TWludXRlcyIsInNldFVUQ0hvdXJzIiwic2V0SG91cnMiLCJzZXRVVENEYXRlIiwic2V0RGF0ZSIsInNldFVUQ0Z1bGxZZWFyIiwic2V0RnVsbFllYXIiLCJzdHJpbmdHZXQiLCJzdHJpbmdTZXQiLCJwcmlvcml0aXplZCIsInByaW9yaXRpemVkTGVuIiwibW9kIiwibiIsIngiLCJpbmRleE9mIiwibyIsImRheXNJbk1vbnRoIiwibW9kTW9udGgiLCJtb250aHNTaG9ydCIsIm1vbnRoc1Nob3J0UmVnZXgiLCJtb250aHNSZWdleCIsIm1vbnRoc1BhcnNlIiwiZGVmYXVsdExvY2FsZU1vbnRocyIsInNwbGl0IiwiZGVmYXVsdExvY2FsZU1vbnRoc1Nob3J0IiwiTU9OVEhTX0lOX0ZPUk1BVCIsImRlZmF1bHRNb250aHNTaG9ydFJlZ2V4IiwiZGVmYXVsdE1vbnRoc1JlZ2V4IiwibG9jYWxlTW9udGhzIiwiX21vbnRocyIsImlzRm9ybWF0IiwibG9jYWxlTW9udGhzU2hvcnQiLCJfbW9udGhzU2hvcnQiLCJoYW5kbGVTdHJpY3RQYXJzZSIsIm1vbnRoTmFtZSIsImlpIiwibGxjIiwidG9Mb2NhbGVMb3dlckNhc2UiLCJfbW9udGhzUGFyc2UiLCJfbG9uZ01vbnRoc1BhcnNlIiwiX3Nob3J0TW9udGhzUGFyc2UiLCJsb2NhbGVNb250aHNQYXJzZSIsIl9tb250aHNQYXJzZUV4YWN0Iiwic2V0TW9udGgiLCJtaW4iLCJzZXRVVENNb250aCIsImdldFNldE1vbnRoIiwiZ2V0RGF5c0luTW9udGgiLCJjb21wdXRlTW9udGhzUGFyc2UiLCJfbW9udGhzU2hvcnRTdHJpY3RSZWdleCIsIl9tb250aHNTaG9ydFJlZ2V4IiwiX21vbnRoc1N0cmljdFJlZ2V4IiwiX21vbnRoc1JlZ2V4IiwiY21wTGVuUmV2Iiwic2hvcnRQaWVjZXMiLCJsb25nUGllY2VzIiwibWl4ZWRQaWVjZXMiLCJzaG9ydFAiLCJsb25nUCIsImNyZWF0ZURhdGUiLCJjcmVhdGVVVENEYXRlIiwiVVRDIiwiZmlyc3RXZWVrT2Zmc2V0IiwiZG93IiwiZG95IiwiZndkIiwiZndkbHciLCJkYXlPZlllYXJGcm9tV2Vla3MiLCJsb2NhbFdlZWtkYXkiLCJ3ZWVrT2Zmc2V0IiwicmVzWWVhciIsInJlc0RheU9mWWVhciIsIndlZWtPZlllYXIiLCJyZXNXZWVrIiwid2Vla3NJblllYXIiLCJ3ZWVrT2Zmc2V0TmV4dCIsImxvY2FsZVdlZWsiLCJfd2VlayIsImRlZmF1bHRMb2NhbGVXZWVrIiwibG9jYWxlRmlyc3REYXlPZldlZWsiLCJsb2NhbGVGaXJzdERheU9mWWVhciIsImdldFNldFdlZWsiLCJhZGQiLCJnZXRTZXRJU09XZWVrIiwid2Vla2RheXNNaW4iLCJ3ZWVrZGF5c1Nob3J0Iiwid2Vla2RheXNNaW5SZWdleCIsIndlZWtkYXlzU2hvcnRSZWdleCIsIndlZWtkYXlzUmVnZXgiLCJ3ZWVrZGF5c1BhcnNlIiwicGFyc2VXZWVrZGF5IiwicGFyc2VJc29XZWVrZGF5Iiwic2hpZnRXZWVrZGF5cyIsIndzIiwiY29uY2F0IiwiZGVmYXVsdExvY2FsZVdlZWtkYXlzIiwiZGVmYXVsdExvY2FsZVdlZWtkYXlzU2hvcnQiLCJkZWZhdWx0TG9jYWxlV2Vla2RheXNNaW4iLCJkZWZhdWx0V2Vla2RheXNSZWdleCIsImRlZmF1bHRXZWVrZGF5c1Nob3J0UmVnZXgiLCJkZWZhdWx0V2Vla2RheXNNaW5SZWdleCIsImxvY2FsZVdlZWtkYXlzIiwiX3dlZWtkYXlzIiwibG9jYWxlV2Vla2RheXNTaG9ydCIsIl93ZWVrZGF5c1Nob3J0IiwibG9jYWxlV2Vla2RheXNNaW4iLCJfd2Vla2RheXNNaW4iLCJoYW5kbGVTdHJpY3RQYXJzZSQxIiwid2Vla2RheU5hbWUiLCJfd2Vla2RheXNQYXJzZSIsIl9zaG9ydFdlZWtkYXlzUGFyc2UiLCJfbWluV2Vla2RheXNQYXJzZSIsImxvY2FsZVdlZWtkYXlzUGFyc2UiLCJfd2Vla2RheXNQYXJzZUV4YWN0IiwiX2Z1bGxXZWVrZGF5c1BhcnNlIiwiZ2V0U2V0RGF5T2ZXZWVrIiwiZ2V0U2V0TG9jYWxlRGF5T2ZXZWVrIiwiZ2V0U2V0SVNPRGF5T2ZXZWVrIiwiY29tcHV0ZVdlZWtkYXlzUGFyc2UiLCJfd2Vla2RheXNTdHJpY3RSZWdleCIsIl93ZWVrZGF5c1JlZ2V4IiwiX3dlZWtkYXlzU2hvcnRTdHJpY3RSZWdleCIsIl93ZWVrZGF5c1Nob3J0UmVnZXgiLCJfd2Vla2RheXNNaW5TdHJpY3RSZWdleCIsIl93ZWVrZGF5c01pblJlZ2V4IiwibWluUGllY2VzIiwibWlucCIsInNob3J0cCIsImxvbmdwIiwiaEZvcm1hdCIsImtGb3JtYXQiLCJsb3dlcmNhc2UiLCJtYXRjaE1lcmlkaWVtIiwiX21lcmlkaWVtUGFyc2UiLCJrSW5wdXQiLCJfaXNQbSIsImlzUE0iLCJfbWVyaWRpZW0iLCJwb3MiLCJwb3MxIiwicG9zMiIsImxvY2FsZUlzUE0iLCJjaGFyQXQiLCJkZWZhdWx0TG9jYWxlTWVyaWRpZW1QYXJzZSIsImdldFNldEhvdXIiLCJsb2NhbGVNZXJpZGllbSIsImhvdXJzMiIsIm1pbnV0ZXMyIiwiaXNMb3dlciIsImJhc2VDb25maWciLCJkYXlPZk1vbnRoT3JkaW5hbFBhcnNlIiwibWVyaWRpZW1QYXJzZSIsImxvY2FsZXMiLCJsb2NhbGVGYW1pbGllcyIsImdsb2JhbExvY2FsZSIsImNvbW1vblByZWZpeCIsImFycjEiLCJhcnIyIiwibWlubCIsIm5vcm1hbGl6ZUxvY2FsZSIsImNob29zZUxvY2FsZSIsIm5hbWVzIiwiaiIsIm5leHQiLCJsb2FkTG9jYWxlIiwiaXNMb2NhbGVOYW1lU2FuZSIsIm9sZExvY2FsZSIsImFsaWFzZWRSZXF1aXJlIiwiX2FiYnIiLCJyZXF1aXJlIiwiZ2V0U2V0R2xvYmFsTG9jYWxlIiwidmFsdWVzIiwiZGF0YSIsImdldExvY2FsZSIsImRlZmluZUxvY2FsZSIsImFiYnIiLCJwYXJlbnRMb2NhbGUiLCJmb3JFYWNoIiwidXBkYXRlTG9jYWxlIiwidG1wTG9jYWxlIiwibGlzdExvY2FsZXMiLCJjaGVja092ZXJmbG93IiwiX292ZXJmbG93RGF5T2ZZZWFyIiwiX292ZXJmbG93V2Vla3MiLCJfb3ZlcmZsb3dXZWVrZGF5IiwiZXh0ZW5kZWRJc29SZWdleCIsImJhc2ljSXNvUmVnZXgiLCJ0elJlZ2V4IiwiaXNvRGF0ZXMiLCJpc29UaW1lcyIsImFzcE5ldEpzb25SZWdleCIsIm9ic09mZnNldHMiLCJVVCIsIkdNVCIsIkVEVCIsIkVTVCIsIkNEVCIsIkNTVCIsIk1EVCIsIk1TVCIsIlBEVCIsIlBTVCIsImNvbmZpZ0Zyb21JU08iLCJsIiwiZXhlYyIsImFsbG93VGltZSIsImRhdGVGb3JtYXQiLCJ0aW1lRm9ybWF0IiwidHpGb3JtYXQiLCJpc29EYXRlc0xlbiIsImlzb1RpbWVzTGVuIiwiY29uZmlnRnJvbVN0cmluZ0FuZEZvcm1hdCIsImV4dHJhY3RGcm9tUkZDMjgyMlN0cmluZ3MiLCJ5ZWFyU3RyIiwibW9udGhTdHIiLCJkYXlTdHIiLCJob3VyU3RyIiwibWludXRlU3RyIiwic2Vjb25kU3RyIiwicmVzdWx0IiwidW50cnVuY2F0ZVllYXIiLCJwcmVwcm9jZXNzUkZDMjgyMiIsImNoZWNrV2Vla2RheSIsIndlZWtkYXlTdHIiLCJwYXJzZWRJbnB1dCIsIndlZWtkYXlQcm92aWRlZCIsIndlZWtkYXlBY3R1YWwiLCJjYWxjdWxhdGVPZmZzZXQiLCJvYnNPZmZzZXQiLCJtaWxpdGFyeU9mZnNldCIsIm51bU9mZnNldCIsImhtIiwiY29uZmlnRnJvbVJGQzI4MjIiLCJwYXJzZWRBcnJheSIsImNvbmZpZ0Zyb21TdHJpbmciLCJjcmVhdGVGcm9tSW5wdXRGYWxsYmFjayIsIl91c2VVVEMiLCJkZWZhdWx0cyIsImMiLCJjdXJyZW50RGF0ZUFycmF5Iiwibm93VmFsdWUiLCJub3ciLCJjb25maWdGcm9tQXJyYXkiLCJjdXJyZW50RGF0ZSIsImV4cGVjdGVkV2Vla2RheSIsInllYXJUb1VzZSIsImRheU9mWWVhckZyb21XZWVrSW5mbyIsIl9kYXlPZlllYXIiLCJfbmV4dERheSIsInRlbXAiLCJ3ZWVrZGF5T3ZlcmZsb3ciLCJjdXJXZWVrIiwiY3JlYXRlTG9jYWwiLCJJU09fODYwMSIsIlJGQ18yODIyIiwidG9rZW5zMiIsInNraXBwZWQiLCJzdHJpbmdMZW5ndGgiLCJ0b3RhbFBhcnNlZElucHV0TGVuZ3RoIiwibWVyaWRpZW1GaXhXcmFwIiwiZXJhc0NvbnZlcnRZZWFyIiwibWVyaWRpZW0yIiwiaXNQbSIsIm1lcmlkaWVtSG91ciIsImNvbmZpZ0Zyb21TdHJpbmdBbmRBcnJheSIsInRlbXBDb25maWciLCJiZXN0TW9tZW50Iiwic2NvcmVUb0JlYXQiLCJjdXJyZW50U2NvcmUiLCJ2YWxpZEZvcm1hdEZvdW5kIiwiYmVzdEZvcm1hdElzVmFsaWQiLCJjb25maWdmTGVuIiwic2NvcmUiLCJjb25maWdGcm9tT2JqZWN0IiwiZGF5T3JEYXRlIiwiY3JlYXRlRnJvbUNvbmZpZyIsInByZXBhcmVDb25maWciLCJwcmVwYXJzZSIsImNvbmZpZ0Zyb21JbnB1dCIsInByb3RvdHlwZU1pbiIsIm90aGVyIiwicHJvdG90eXBlTWF4IiwicGlja0J5IiwibW9tZW50cyIsIm9yZGVyaW5nIiwiaXNEdXJhdGlvblZhbGlkIiwidW5pdEhhc0RlY2ltYWwiLCJvcmRlckxlbiIsInBhcnNlRmxvYXQiLCJpc1ZhbGlkJDEiLCJjcmVhdGVJbnZhbGlkJDEiLCJjcmVhdGVEdXJhdGlvbiIsIkR1cmF0aW9uIiwiZHVyYXRpb24iLCJ5ZWFyczIiLCJtb250aHMyIiwid2Vla3MyIiwiZGF5czIiLCJzZWNvbmRzMiIsIm1pbGxpc2Vjb25kczIiLCJfbWlsbGlzZWNvbmRzIiwiX2RheXMiLCJfZGF0YSIsIl9idWJibGUiLCJpc0R1cmF0aW9uIiwiYWJzUm91bmQiLCJyb3VuZCIsImNvbXBhcmVBcnJheXMiLCJhcnJheTEiLCJhcnJheTIiLCJkb250Q29udmVydCIsImxlbmd0aERpZmYiLCJkaWZmcyIsIm9mZnNldCIsInNlcGFyYXRvciIsIm9mZnNldDIiLCJ1dGNPZmZzZXQiLCJvZmZzZXRGcm9tU3RyaW5nIiwiY2h1bmtPZmZzZXQiLCJtYXRjaGVyIiwibWF0Y2hlcyIsImNodW5rIiwicGFydHMiLCJjbG9uZVdpdGhPZmZzZXQiLCJtb2RlbCIsImNsb25lIiwic2V0VGltZSIsImxvY2FsIiwiZ2V0RGF0ZU9mZnNldCIsImdldFRpbWV6b25lT2Zmc2V0IiwiZ2V0U2V0T2Zmc2V0Iiwia2VlcExvY2FsVGltZSIsImtlZXBNaW51dGVzIiwibG9jYWxBZGp1c3QiLCJfY2hhbmdlSW5Qcm9ncmVzcyIsImFkZFN1YnRyYWN0IiwiZ2V0U2V0Wm9uZSIsInNldE9mZnNldFRvVVRDIiwic2V0T2Zmc2V0VG9Mb2NhbCIsInN1YnRyYWN0Iiwic2V0T2Zmc2V0VG9QYXJzZWRPZmZzZXQiLCJ0Wm9uZSIsImhhc0FsaWduZWRIb3VyT2Zmc2V0IiwiaXNEYXlsaWdodFNhdmluZ1RpbWUiLCJpc0RheWxpZ2h0U2F2aW5nVGltZVNoaWZ0ZWQiLCJfaXNEU1RTaGlmdGVkIiwidG9BcnJheSIsImlzTG9jYWwiLCJpc1V0Y09mZnNldCIsImlzVXRjIiwiYXNwTmV0UmVnZXgiLCJpc29SZWdleCIsInJldCIsImRpZmZSZXMiLCJwYXJzZUlzbyIsIm1vbWVudHNEaWZmZXJlbmNlIiwiZnJvbSIsInRvIiwiaW52YWxpZCIsImlucCIsInBvc2l0aXZlTW9tZW50c0RpZmZlcmVuY2UiLCJiYXNlIiwiaXNBZnRlciIsImlzQmVmb3JlIiwiY3JlYXRlQWRkZXIiLCJkaXJlY3Rpb24iLCJwZXJpb2QiLCJkdXIiLCJ0bXAiLCJpc0FkZGluZyIsImlzU3RyaW5nIiwiU3RyaW5nIiwiaXNNb21lbnRJbnB1dCIsImlzTnVtYmVyT3JTdHJpbmdBcnJheSIsImlzTW9tZW50SW5wdXRPYmplY3QiLCJvYmplY3RUZXN0IiwicHJvcGVydHlUZXN0IiwicHJvcGVydGllcyIsInByb3BlcnR5IiwicHJvcGVydHlMZW4iLCJhcnJheVRlc3QiLCJkYXRhVHlwZVRlc3QiLCJmaWx0ZXIiLCJpdGVtIiwiaXNDYWxlbmRhclNwZWMiLCJnZXRDYWxlbmRhckZvcm1hdCIsIm15TW9tZW50IiwiZGlmZiIsImNhbGVuZGFyJDEiLCJ0aW1lIiwiZm9ybWF0cyIsInNvZCIsInN0YXJ0T2YiLCJjYWxlbmRhckZvcm1hdCIsImZvcm1hdCIsImxvY2FsSW5wdXQiLCJlbmRPZiIsImlzQmV0d2VlbiIsImluY2x1c2l2aXR5IiwibG9jYWxGcm9tIiwibG9jYWxUbyIsImlzU2FtZSIsImlucHV0TXMiLCJpc1NhbWVPckFmdGVyIiwiaXNTYW1lT3JCZWZvcmUiLCJhc0Zsb2F0IiwidGhhdCIsInpvbmVEZWx0YSIsIm1vbnRoRGlmZiIsIndob2xlTW9udGhEaWZmIiwiYW5jaG9yIiwiYW5jaG9yMiIsImFkanVzdCIsImRlZmF1bHRGb3JtYXQiLCJkZWZhdWx0Rm9ybWF0VXRjIiwibG9jYWxlIiwidG9JU09TdHJpbmciLCJrZWVwT2Zmc2V0IiwidG9EYXRlIiwiaW5zcGVjdCIsInpvbmUiLCJwcmVmaXgiLCJkYXRldGltZSIsInN1ZmZpeCIsImlucHV0U3RyaW5nIiwicG9zdGZvcm1hdCIsImh1bWFuaXplIiwiZnJvbU5vdyIsInRvTm93IiwibmV3TG9jYWxlRGF0YSIsImxhbmciLCJNU19QRVJfU0VDT05EIiwiTVNfUEVSX01JTlVURSIsIk1TX1BFUl9IT1VSIiwiTVNfUEVSXzQwMF9ZRUFSUyIsIm1vZCQxIiwiZGl2aWRlbmQiLCJkaXZpc29yIiwibG9jYWxTdGFydE9mRGF0ZSIsInV0Y1N0YXJ0T2ZEYXRlIiwic3RhcnRPZkRhdGUiLCJ1bml4IiwidG9PYmplY3QiLCJ0b0pTT04iLCJpc1ZhbGlkJDIiLCJwYXJzaW5nRmxhZ3MiLCJpbnZhbGlkQXQiLCJjcmVhdGlvbkRhdGEiLCJtYXRjaEVyYUFiYnIiLCJtYXRjaEVyYU5hbWUiLCJtYXRjaEVyYU5hcnJvdyIsImVyYXNQYXJzZSIsIm1hdGNoRXJhWWVhck9yZGluYWwiLCJfZXJhWWVhck9yZGluYWxSZWdleCIsImVyYVllYXJPcmRpbmFsUGFyc2UiLCJsb2NhbGVFcmFzIiwiZXJhcyIsIl9lcmFzIiwic2luY2UiLCJ1bnRpbCIsIkluZmluaXR5IiwibG9jYWxlRXJhc1BhcnNlIiwiZXJhTmFtZSIsIm5hcnJvdyIsImxvY2FsZUVyYXNDb252ZXJ0WWVhciIsImRpciIsImdldEVyYU5hbWUiLCJnZXRFcmFOYXJyb3ciLCJnZXRFcmFBYmJyIiwiZ2V0RXJhWWVhciIsImVyYXNOYW1lUmVnZXgiLCJjb21wdXRlRXJhc1BhcnNlIiwiX2VyYXNOYW1lUmVnZXgiLCJfZXJhc1JlZ2V4IiwiZXJhc0FiYnJSZWdleCIsIl9lcmFzQWJiclJlZ2V4IiwiZXJhc05hcnJvd1JlZ2V4IiwiX2VyYXNOYXJyb3dSZWdleCIsImFiYnJQaWVjZXMiLCJuYW1lUGllY2VzIiwibmFycm93UGllY2VzIiwiZXJhc05hbWUiLCJlcmFzQWJiciIsImVyYXNOYXJyb3ciLCJhZGRXZWVrWWVhckZvcm1hdFRva2VuIiwiZ2V0dGVyIiwiZ2V0U2V0V2Vla1llYXIiLCJnZXRTZXRXZWVrWWVhckhlbHBlciIsImdldFNldElTT1dlZWtZZWFyIiwiZ2V0SVNPV2Vla3NJblllYXIiLCJnZXRJU09XZWVrc0luSVNPV2Vla1llYXIiLCJnZXRXZWVrc0luWWVhciIsIndlZWtJbmZvIiwiZ2V0V2Vla3NJbldlZWtZZWFyIiwid2Vla3NUYXJnZXQiLCJzZXRXZWVrQWxsIiwiZGF5T2ZZZWFyRGF0YSIsImdldFNldFF1YXJ0ZXIiLCJnZXRTZXREYXlPZk1vbnRoIiwiZ2V0U2V0RGF5T2ZZZWFyIiwiZ2V0U2V0TWludXRlIiwiZ2V0U2V0U2Vjb25kIiwidG9rZW4iLCJnZXRTZXRNaWxsaXNlY29uZCIsInBhcnNlTXMiLCJnZXRab25lQWJiciIsImdldFpvbmVOYW1lIiwicHJvdG8iLCJTeW1ib2wiLCJmb3IiLCJlcmFOYXJyb3ciLCJlcmFBYmJyIiwiZXJhWWVhciIsImlzb1dlZWtzIiwid2Vla3NJbldlZWtZZWFyIiwiaXNvV2Vla3NJblllYXIiLCJpc29XZWVrc0luSVNPV2Vla1llYXIiLCJwYXJzZVpvbmUiLCJpc0RTVCIsInpvbmVBYmJyIiwiem9uZU5hbWUiLCJpc0RTVFNoaWZ0ZWQiLCJjcmVhdGVVbml4IiwiY3JlYXRlSW5ab25lIiwicHJlUGFyc2VQb3N0Rm9ybWF0IiwicHJvdG8kMSIsImZpcnN0RGF5T2ZZZWFyIiwiZmlyc3REYXlPZldlZWsiLCJnZXQkMSIsImluZGV4IiwiZmllbGQiLCJzZXR0ZXIiLCJsaXN0TW9udGhzSW1wbCIsIm91dCIsImxpc3RXZWVrZGF5c0ltcGwiLCJsb2NhbGVTb3J0ZWQiLCJzaGlmdCIsImxpc3RNb250aHMiLCJsaXN0TW9udGhzU2hvcnQiLCJsaXN0V2Vla2RheXMiLCJsaXN0V2Vla2RheXNTaG9ydCIsImxpc3RXZWVrZGF5c01pbiIsImxhbmdEYXRhIiwibWF0aEFicyIsImFkZFN1YnRyYWN0JDEiLCJhZGQkMSIsInN1YnRyYWN0JDEiLCJhYnNDZWlsIiwiYnViYmxlIiwibW9udGhzRnJvbURheXMiLCJtb250aHNUb0RheXMiLCJkYXlzVG9Nb250aHMiLCJhcyIsIm1ha2VBcyIsImFsaWFzIiwiYXNNaWxsaXNlY29uZHMiLCJhc1NlY29uZHMiLCJhc01pbnV0ZXMiLCJhc0hvdXJzIiwiYXNEYXlzIiwiYXNXZWVrcyIsImFzTW9udGhzIiwiYXNRdWFydGVycyIsImFzWWVhcnMiLCJ2YWx1ZU9mJDEiLCJjbG9uZSQxIiwiZ2V0JDIiLCJtYWtlR2V0dGVyIiwidGhyZXNob2xkcyIsInN1YnN0aXR1dGVUaW1lQWdvIiwicmVsYXRpdmVUaW1lJDEiLCJwb3NOZWdEdXJhdGlvbiIsInRocmVzaG9sZHMyIiwiZ2V0U2V0UmVsYXRpdmVUaW1lUm91bmRpbmciLCJyb3VuZGluZ0Z1bmN0aW9uIiwiZ2V0U2V0UmVsYXRpdmVUaW1lVGhyZXNob2xkIiwidGhyZXNob2xkIiwibGltaXQiLCJhcmdXaXRoU3VmZml4IiwiYXJnVGhyZXNob2xkcyIsIndpdGhTdWZmaXgiLCJ0aCIsImFzc2lnbiIsImFicyQxIiwic2lnbiIsInRvSVNPU3RyaW5nJDEiLCJ0b3RhbCIsInRvdGFsU2lnbiIsInltU2lnbiIsImRheXNTaWduIiwiaG1zU2lnbiIsInRvRml4ZWQiLCJwcm90byQyIiwidG9Jc29TdHJpbmciLCJ2ZXJzaW9uIiwicmVsYXRpdmVUaW1lUm91bmRpbmciLCJyZWxhdGl2ZVRpbWVUaHJlc2hvbGQiLCJIVE1MNV9GTVQiLCJEQVRFVElNRV9MT0NBTCIsIkRBVEVUSU1FX0xPQ0FMX1NFQ09ORFMiLCJEQVRFVElNRV9MT0NBTF9NUyIsIlRJTUUiLCJUSU1FX1NFQ09ORFMiLCJUSU1FX01TIiwibW9tZW50XzJfMzBfMV9leHBvcnRzIiwiX19leHBvcnQiLCJkZWZhdWx0IiwibW9tZW50XzJfMzBfMV9kZWZhdWx0IiwibW9kdWxlIiwiX190b0NvbW1vbkpTIiwiX19yZUV4cG9ydCIsIl9fdG9FU00iLCJpbXBvcnRfbW9tZW50Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSxjQUFBLEdBQUFDLFVBQUE7RUFBQSwrQkFBQUMsQ0FBQUMsT0FBQSxFQUFBQyxPQUFBO0lBTUE7SUFBQyxDQUFDLFVBQVVDLE1BQUEsRUFBUUMsT0FBQSxFQUFTO01BQ3pCLE9BQU9ILE9BQUEsS0FBWSxZQUFZLE9BQU9DLE9BQUEsS0FBVyxjQUFjQSxPQUFBLENBQU9ELE9BQUEsR0FBVUcsT0FBQSxDQUFRLElBQ3hGLE9BQU9DLE1BQUEsS0FBVyxjQUFjQSxNQUFBLENBQU9DLEdBQUEsR0FBTUQsTUFBQSxDQUFPRCxPQUFPLElBQzNERCxNQUFBLENBQU9JLE1BQUEsR0FBU0gsT0FBQSxDQUFRO0lBQzVCLEdBQUVILE9BQUEsRUFBTyxZQUFZO01BQUU7O01BRW5CLElBQUlPLFlBQUE7TUFFSixTQUFTQyxNQUFBLEVBQVE7UUFDYixPQUFPRCxZQUFBLENBQWFFLEtBQUEsQ0FBTSxNQUFNQyxTQUFTO01BQzdDO01BSUEsU0FBU0MsZ0JBQWdCQyxRQUFBLEVBQVU7UUFDL0JMLFlBQUEsR0FBZUssUUFBQTtNQUNuQjtNQUVBLFNBQVNDLFFBQVFDLEtBQUEsRUFBTztRQUNwQixPQUNJQSxLQUFBLFlBQWlCQyxLQUFBLElBQ2pCQyxNQUFBLENBQU9DLFNBQUEsQ0FBVUMsUUFBQSxDQUFTQyxJQUFBLENBQUtMLEtBQUssTUFBTTtNQUVsRDtNQUVBLFNBQVNNLFNBQVNOLEtBQUEsRUFBTztRQUdyQixPQUNJQSxLQUFBLElBQVMsUUFDVEUsTUFBQSxDQUFPQyxTQUFBLENBQVVDLFFBQUEsQ0FBU0MsSUFBQSxDQUFLTCxLQUFLLE1BQU07TUFFbEQ7TUFFQSxTQUFTTyxXQUFXQyxDQUFBLEVBQUdDLENBQUEsRUFBRztRQUN0QixPQUFPUCxNQUFBLENBQU9DLFNBQUEsQ0FBVU8sY0FBQSxDQUFlTCxJQUFBLENBQUtHLENBQUEsRUFBR0MsQ0FBQztNQUNwRDtNQUVBLFNBQVNFLGNBQWNDLEdBQUEsRUFBSztRQUN4QixJQUFJVixNQUFBLENBQU9XLG1CQUFBLEVBQXFCO1VBQzVCLE9BQU9YLE1BQUEsQ0FBT1csbUJBQUEsQ0FBb0JELEdBQUcsRUFBRUUsTUFBQSxLQUFXO1FBQ3RELE9BQU87VUFDSCxJQUFJQyxDQUFBO1VBQ0osS0FBS0EsQ0FBQSxJQUFLSCxHQUFBLEVBQUs7WUFDWCxJQUFJTCxVQUFBLENBQVdLLEdBQUEsRUFBS0csQ0FBQyxHQUFHO2NBQ3BCLE9BQU87WUFDWDtVQUNKO1VBQ0EsT0FBTztRQUNYO01BQ0o7TUFFQSxTQUFTQyxZQUFZaEIsS0FBQSxFQUFPO1FBQ3hCLE9BQU9BLEtBQUEsS0FBVTtNQUNyQjtNQUVBLFNBQVNpQixTQUFTakIsS0FBQSxFQUFPO1FBQ3JCLE9BQ0ksT0FBT0EsS0FBQSxLQUFVLFlBQ2pCRSxNQUFBLENBQU9DLFNBQUEsQ0FBVUMsUUFBQSxDQUFTQyxJQUFBLENBQUtMLEtBQUssTUFBTTtNQUVsRDtNQUVBLFNBQVNrQixPQUFPbEIsS0FBQSxFQUFPO1FBQ25CLE9BQ0lBLEtBQUEsWUFBaUJtQixJQUFBLElBQ2pCakIsTUFBQSxDQUFPQyxTQUFBLENBQVVDLFFBQUEsQ0FBU0MsSUFBQSxDQUFLTCxLQUFLLE1BQU07TUFFbEQ7TUFFQSxTQUFTb0IsSUFBSUMsR0FBQSxFQUFLQyxFQUFBLEVBQUk7UUFDbEIsSUFBSUMsR0FBQSxHQUFNLEVBQUM7VUFDUEMsQ0FBQTtVQUNBQyxNQUFBLEdBQVNKLEdBQUEsQ0FBSVAsTUFBQTtRQUNqQixLQUFLVSxDQUFBLEdBQUksR0FBR0EsQ0FBQSxHQUFJQyxNQUFBLEVBQVEsRUFBRUQsQ0FBQSxFQUFHO1VBQ3pCRCxHQUFBLENBQUlHLElBQUEsQ0FBS0osRUFBQSxDQUFHRCxHQUFBLENBQUlHLENBQUEsR0FBSUEsQ0FBQyxDQUFDO1FBQzFCO1FBQ0EsT0FBT0QsR0FBQTtNQUNYO01BRUEsU0FBU0ksT0FBT25CLENBQUEsRUFBR0MsQ0FBQSxFQUFHO1FBQ2xCLFNBQVNlLENBQUEsSUFBS2YsQ0FBQSxFQUFHO1VBQ2IsSUFBSUYsVUFBQSxDQUFXRSxDQUFBLEVBQUdlLENBQUMsR0FBRztZQUNsQmhCLENBQUEsQ0FBRWdCLENBQUEsSUFBS2YsQ0FBQSxDQUFFZSxDQUFBO1VBQ2I7UUFDSjtRQUVBLElBQUlqQixVQUFBLENBQVdFLENBQUEsRUFBRyxVQUFVLEdBQUc7VUFDM0JELENBQUEsQ0FBRUosUUFBQSxHQUFXSyxDQUFBLENBQUVMLFFBQUE7UUFDbkI7UUFFQSxJQUFJRyxVQUFBLENBQVdFLENBQUEsRUFBRyxTQUFTLEdBQUc7VUFDMUJELENBQUEsQ0FBRW9CLE9BQUEsR0FBVW5CLENBQUEsQ0FBRW1CLE9BQUE7UUFDbEI7UUFFQSxPQUFPcEIsQ0FBQTtNQUNYO01BRUEsU0FBU3FCLFVBQVU3QixLQUFBLEVBQU84QixPQUFBLEVBQVFDLE9BQUEsRUFBUUMsTUFBQSxFQUFRO1FBQzlDLE9BQU9DLGdCQUFBLENBQWlCakMsS0FBQSxFQUFPOEIsT0FBQSxFQUFRQyxPQUFBLEVBQVFDLE1BQUEsRUFBUSxJQUFJLEVBQUVFLEdBQUEsQ0FBSTtNQUNyRTtNQUVBLFNBQVNDLG9CQUFBLEVBQXNCO1FBRTNCLE9BQU87VUFDSEMsS0FBQSxFQUFPO1VBQ1BDLFlBQUEsRUFBYyxFQUFDO1VBQ2ZDLFdBQUEsRUFBYSxFQUFDO1VBQ2RDLFFBQUEsRUFBVTtVQUNWQyxhQUFBLEVBQWU7VUFDZkMsU0FBQSxFQUFXO1VBQ1hDLFVBQUEsRUFBWTtVQUNaQyxZQUFBLEVBQWM7VUFDZEMsYUFBQSxFQUFlO1VBQ2ZDLGVBQUEsRUFBaUI7VUFDakJDLEdBQUEsRUFBSztVQUNMQyxlQUFBLEVBQWlCLEVBQUM7VUFDbEJDLEdBQUEsRUFBSztVQUNMQyxRQUFBLEVBQVU7VUFDVkMsT0FBQSxFQUFTO1VBQ1RDLGVBQUEsRUFBaUI7UUFDckI7TUFDSjtNQUVBLFNBQVNDLGdCQUFnQkMsQ0FBQSxFQUFHO1FBQ3hCLElBQUlBLENBQUEsQ0FBRUMsR0FBQSxJQUFPLE1BQU07VUFDZkQsQ0FBQSxDQUFFQyxHQUFBLEdBQU1uQixtQkFBQSxDQUFvQjtRQUNoQztRQUNBLE9BQU9rQixDQUFBLENBQUVDLEdBQUE7TUFDYjtNQUVBLElBQUlDLElBQUE7TUFDSixJQUFJdEQsS0FBQSxDQUFNRSxTQUFBLENBQVVvRCxJQUFBLEVBQU07UUFDdEJBLElBQUEsR0FBT3RELEtBQUEsQ0FBTUUsU0FBQSxDQUFVb0QsSUFBQTtNQUMzQixPQUFPO1FBQ0hBLElBQUEsR0FBTyxTQUFBQSxDQUFVQyxHQUFBLEVBQUs7VUFDbEIsSUFBSUMsQ0FBQSxHQUFJdkQsTUFBQSxDQUFPLElBQUk7WUFDZndELEdBQUEsR0FBTUQsQ0FBQSxDQUFFM0MsTUFBQSxLQUFXO1lBQ25CVSxDQUFBO1VBRUosS0FBS0EsQ0FBQSxHQUFJLEdBQUdBLENBQUEsR0FBSWtDLEdBQUEsRUFBS2xDLENBQUEsSUFBSztZQUN0QixJQUFJQSxDQUFBLElBQUtpQyxDQUFBLElBQUtELEdBQUEsQ0FBSW5ELElBQUEsQ0FBSyxNQUFNb0QsQ0FBQSxDQUFFakMsQ0FBQSxHQUFJQSxDQUFBLEVBQUdpQyxDQUFDLEdBQUc7Y0FDdEMsT0FBTztZQUNYO1VBQ0o7VUFFQSxPQUFPO1FBQ1g7TUFDSjtNQUVBLFNBQVNFLFFBQVFOLENBQUEsRUFBRztRQUNoQixJQUFJTyxLQUFBLEdBQVE7VUFDUkMsV0FBQSxHQUFjO1VBQ2RDLFVBQUEsR0FBYVQsQ0FBQSxDQUFFVSxFQUFBLElBQU0sQ0FBQ0MsS0FBQSxDQUFNWCxDQUFBLENBQUVVLEVBQUEsQ0FBR0UsT0FBQSxDQUFRLENBQUM7UUFDOUMsSUFBSUgsVUFBQSxFQUFZO1VBQ1pGLEtBQUEsR0FBUVIsZUFBQSxDQUFnQkMsQ0FBQztVQUN6QlEsV0FBQSxHQUFjTixJQUFBLENBQUtsRCxJQUFBLENBQUt1RCxLQUFBLENBQU1iLGVBQUEsRUFBaUIsVUFBVXZCLENBQUEsRUFBRztZQUN4RCxPQUFPQSxDQUFBLElBQUs7VUFDaEIsQ0FBQztVQUNEc0MsVUFBQSxHQUNJRixLQUFBLENBQU1yQixRQUFBLEdBQVcsS0FDakIsQ0FBQ3FCLEtBQUEsQ0FBTXhCLEtBQUEsSUFDUCxDQUFDd0IsS0FBQSxDQUFNbEIsVUFBQSxJQUNQLENBQUNrQixLQUFBLENBQU1qQixZQUFBLElBQ1AsQ0FBQ2lCLEtBQUEsQ0FBTU0sY0FBQSxJQUNQLENBQUNOLEtBQUEsQ0FBTVQsZUFBQSxJQUNQLENBQUNTLEtBQUEsQ0FBTW5CLFNBQUEsSUFDUCxDQUFDbUIsS0FBQSxDQUFNaEIsYUFBQSxJQUNQLENBQUNnQixLQUFBLENBQU1mLGVBQUEsS0FDTixDQUFDZSxLQUFBLENBQU1YLFFBQUEsSUFBYVcsS0FBQSxDQUFNWCxRQUFBLElBQVlZLFdBQUE7VUFDM0MsSUFBSVIsQ0FBQSxDQUFFYyxPQUFBLEVBQVM7WUFDWEwsVUFBQSxHQUNJQSxVQUFBLElBQ0FGLEtBQUEsQ0FBTXBCLGFBQUEsS0FBa0IsS0FDeEJvQixLQUFBLENBQU12QixZQUFBLENBQWF2QixNQUFBLEtBQVcsS0FDOUI4QyxLQUFBLENBQU1RLE9BQUEsS0FBWTtVQUMxQjtRQUNKO1FBQ0EsSUFBSWxFLE1BQUEsQ0FBT21FLFFBQUEsSUFBWSxRQUFRLENBQUNuRSxNQUFBLENBQU9tRSxRQUFBLENBQVNoQixDQUFDLEdBQUc7VUFDaERBLENBQUEsQ0FBRWlCLFFBQUEsR0FBV1IsVUFBQTtRQUNqQixPQUFPO1VBQ0gsT0FBT0EsVUFBQTtRQUNYO1FBQ0EsT0FBT1QsQ0FBQSxDQUFFaUIsUUFBQTtNQUNiO01BRUEsU0FBU0MsY0FBY1gsS0FBQSxFQUFPO1FBQzFCLElBQUlQLENBQUEsR0FBSXhCLFNBQUEsQ0FBVTJDLEdBQUc7UUFDckIsSUFBSVosS0FBQSxJQUFTLE1BQU07VUFDZmpDLE1BQUEsQ0FBT3lCLGVBQUEsQ0FBZ0JDLENBQUMsR0FBR08sS0FBSztRQUNwQyxPQUFPO1VBQ0hSLGVBQUEsQ0FBZ0JDLENBQUMsRUFBRVIsZUFBQSxHQUFrQjtRQUN6QztRQUVBLE9BQU9RLENBQUE7TUFDWDtNQUlBLElBQUlvQixnQkFBQSxHQUFvQi9FLEtBQUEsQ0FBTStFLGdCQUFBLEdBQW1CLEVBQUM7UUFDOUNDLGdCQUFBLEdBQW1CO01BRXZCLFNBQVNDLFdBQVdDLEdBQUEsRUFBSUMsS0FBQSxFQUFNO1FBQzFCLElBQUlyRCxDQUFBO1VBQ0FzRCxJQUFBO1VBQ0FDLEdBQUE7VUFDQUMsbUJBQUEsR0FBc0JQLGdCQUFBLENBQWlCM0QsTUFBQTtRQUUzQyxJQUFJLENBQUNFLFdBQUEsQ0FBWTZELEtBQUEsQ0FBS0ksZ0JBQWdCLEdBQUc7VUFDckNMLEdBQUEsQ0FBR0ssZ0JBQUEsR0FBbUJKLEtBQUEsQ0FBS0ksZ0JBQUE7UUFDL0I7UUFDQSxJQUFJLENBQUNqRSxXQUFBLENBQVk2RCxLQUFBLENBQUtLLEVBQUUsR0FBRztVQUN2Qk4sR0FBQSxDQUFHTSxFQUFBLEdBQUtMLEtBQUEsQ0FBS0ssRUFBQTtRQUNqQjtRQUNBLElBQUksQ0FBQ2xFLFdBQUEsQ0FBWTZELEtBQUEsQ0FBS00sRUFBRSxHQUFHO1VBQ3ZCUCxHQUFBLENBQUdPLEVBQUEsR0FBS04sS0FBQSxDQUFLTSxFQUFBO1FBQ2pCO1FBQ0EsSUFBSSxDQUFDbkUsV0FBQSxDQUFZNkQsS0FBQSxDQUFLTyxFQUFFLEdBQUc7VUFDdkJSLEdBQUEsQ0FBR1EsRUFBQSxHQUFLUCxLQUFBLENBQUtPLEVBQUE7UUFDakI7UUFDQSxJQUFJLENBQUNwRSxXQUFBLENBQVk2RCxLQUFBLENBQUtWLE9BQU8sR0FBRztVQUM1QlMsR0FBQSxDQUFHVCxPQUFBLEdBQVVVLEtBQUEsQ0FBS1YsT0FBQTtRQUN0QjtRQUNBLElBQUksQ0FBQ25ELFdBQUEsQ0FBWTZELEtBQUEsQ0FBS1EsSUFBSSxHQUFHO1VBQ3pCVCxHQUFBLENBQUdTLElBQUEsR0FBT1IsS0FBQSxDQUFLUSxJQUFBO1FBQ25CO1FBQ0EsSUFBSSxDQUFDckUsV0FBQSxDQUFZNkQsS0FBQSxDQUFLUyxNQUFNLEdBQUc7VUFDM0JWLEdBQUEsQ0FBR1UsTUFBQSxHQUFTVCxLQUFBLENBQUtTLE1BQUE7UUFDckI7UUFDQSxJQUFJLENBQUN0RSxXQUFBLENBQVk2RCxLQUFBLENBQUtVLE9BQU8sR0FBRztVQUM1QlgsR0FBQSxDQUFHVyxPQUFBLEdBQVVWLEtBQUEsQ0FBS1UsT0FBQTtRQUN0QjtRQUNBLElBQUksQ0FBQ3ZFLFdBQUEsQ0FBWTZELEtBQUEsQ0FBS3ZCLEdBQUcsR0FBRztVQUN4QnNCLEdBQUEsQ0FBR3RCLEdBQUEsR0FBTUYsZUFBQSxDQUFnQnlCLEtBQUk7UUFDakM7UUFDQSxJQUFJLENBQUM3RCxXQUFBLENBQVk2RCxLQUFBLENBQUtXLE9BQU8sR0FBRztVQUM1QlosR0FBQSxDQUFHWSxPQUFBLEdBQVVYLEtBQUEsQ0FBS1csT0FBQTtRQUN0QjtRQUVBLElBQUlSLG1CQUFBLEdBQXNCLEdBQUc7VUFDekIsS0FBS3hELENBQUEsR0FBSSxHQUFHQSxDQUFBLEdBQUl3RCxtQkFBQSxFQUFxQnhELENBQUEsSUFBSztZQUN0Q3NELElBQUEsR0FBT0wsZ0JBQUEsQ0FBaUJqRCxDQUFBO1lBQ3hCdUQsR0FBQSxHQUFNRixLQUFBLENBQUtDLElBQUE7WUFDWCxJQUFJLENBQUM5RCxXQUFBLENBQVkrRCxHQUFHLEdBQUc7Y0FDbkJILEdBQUEsQ0FBR0UsSUFBQSxJQUFRQyxHQUFBO1lBQ2Y7VUFDSjtRQUNKO1FBRUEsT0FBT0gsR0FBQTtNQUNYO01BR0EsU0FBU2EsT0FBT0MsTUFBQSxFQUFRO1FBQ3BCZixVQUFBLENBQVcsTUFBTWUsTUFBTTtRQUN2QixLQUFLM0IsRUFBQSxHQUFLLElBQUk1QyxJQUFBLENBQUt1RSxNQUFBLENBQU8zQixFQUFBLElBQU0sT0FBTzJCLE1BQUEsQ0FBTzNCLEVBQUEsQ0FBR0UsT0FBQSxDQUFRLElBQUlPLEdBQUc7UUFDaEUsSUFBSSxDQUFDLEtBQUtiLE9BQUEsQ0FBUSxHQUFHO1VBQ2pCLEtBQUtJLEVBQUEsR0FBSyxJQUFJNUMsSUFBQSxDQUFLcUQsR0FBRztRQUMxQjtRQUdBLElBQUlFLGdCQUFBLEtBQXFCLE9BQU87VUFDNUJBLGdCQUFBLEdBQW1CO1VBQ25CaEYsS0FBQSxDQUFNaUcsWUFBQSxDQUFhLElBQUk7VUFDdkJqQixnQkFBQSxHQUFtQjtRQUN2QjtNQUNKO01BRUEsU0FBU2tCLFNBQVNoRixHQUFBLEVBQUs7UUFDbkIsT0FDSUEsR0FBQSxZQUFlNkUsTUFBQSxJQUFXN0UsR0FBQSxJQUFPLFFBQVFBLEdBQUEsQ0FBSXFFLGdCQUFBLElBQW9CO01BRXpFO01BRUEsU0FBU1ksS0FBS0MsR0FBQSxFQUFLO1FBQ2YsSUFDSXBHLEtBQUEsQ0FBTXFHLDJCQUFBLEtBQWdDLFNBQ3RDLE9BQU9DLE9BQUEsS0FBWSxlQUNuQkEsT0FBQSxDQUFRSCxJQUFBLEVBQ1Y7VUFDRUcsT0FBQSxDQUFRSCxJQUFBLENBQUssMEJBQTBCQyxHQUFHO1FBQzlDO01BQ0o7TUFFQSxTQUFTRyxVQUFVSCxHQUFBLEVBQUt4RSxFQUFBLEVBQUk7UUFDeEIsSUFBSTRFLFNBQUEsR0FBWTtRQUVoQixPQUFPdkUsTUFBQSxDQUFPLFlBQVk7VUFDdEIsSUFBSWpDLEtBQUEsQ0FBTXlHLGtCQUFBLElBQXNCLE1BQU07WUFDbEN6RyxLQUFBLENBQU15RyxrQkFBQSxDQUFtQixNQUFNTCxHQUFHO1VBQ3RDO1VBQ0EsSUFBSUksU0FBQSxFQUFXO1lBQ1gsSUFBSUUsSUFBQSxHQUFPLEVBQUM7Y0FDUkMsR0FBQTtjQUNBN0UsQ0FBQTtjQUNBOEUsR0FBQTtjQUNBQyxNQUFBLEdBQVMzRyxTQUFBLENBQVVrQixNQUFBO1lBQ3ZCLEtBQUtVLENBQUEsR0FBSSxHQUFHQSxDQUFBLEdBQUkrRSxNQUFBLEVBQVEvRSxDQUFBLElBQUs7Y0FDekI2RSxHQUFBLEdBQU07Y0FDTixJQUFJLE9BQU96RyxTQUFBLENBQVU0QixDQUFBLE1BQU8sVUFBVTtnQkFDbEM2RSxHQUFBLElBQU8sUUFBUTdFLENBQUEsR0FBSTtnQkFDbkIsS0FBSzhFLEdBQUEsSUFBTzFHLFNBQUEsQ0FBVSxJQUFJO2tCQUN0QixJQUFJVyxVQUFBLENBQVdYLFNBQUEsQ0FBVSxJQUFJMEcsR0FBRyxHQUFHO29CQUMvQkQsR0FBQSxJQUFPQyxHQUFBLEdBQU0sT0FBTzFHLFNBQUEsQ0FBVSxHQUFHMEcsR0FBQSxJQUFPO2tCQUM1QztnQkFDSjtnQkFDQUQsR0FBQSxHQUFNQSxHQUFBLENBQUlHLEtBQUEsQ0FBTSxHQUFHLEVBQUU7Y0FDekIsT0FBTztnQkFDSEgsR0FBQSxHQUFNekcsU0FBQSxDQUFVNEIsQ0FBQTtjQUNwQjtjQUNBNEUsSUFBQSxDQUFLMUUsSUFBQSxDQUFLMkUsR0FBRztZQUNqQjtZQUNBUixJQUFBLENBQ0lDLEdBQUEsR0FDSSxrQkFDQTdGLEtBQUEsQ0FBTUUsU0FBQSxDQUFVcUcsS0FBQSxDQUFNbkcsSUFBQSxDQUFLK0YsSUFBSSxFQUFFSyxJQUFBLENBQUssRUFBRSxJQUN4QyxPQUNBLElBQUlDLEtBQUEsQ0FBTSxFQUFFQyxLQUNwQjtZQUNBVCxTQUFBLEdBQVk7VUFDaEI7VUFDQSxPQUFPNUUsRUFBQSxDQUFHM0IsS0FBQSxDQUFNLE1BQU1DLFNBQVM7UUFDbkMsR0FBRzBCLEVBQUU7TUFDVDtNQUVBLElBQUlzRixZQUFBLEdBQWUsQ0FBQztNQUVwQixTQUFTQyxnQkFBZ0JDLElBQUEsRUFBTWhCLEdBQUEsRUFBSztRQUNoQyxJQUFJcEcsS0FBQSxDQUFNeUcsa0JBQUEsSUFBc0IsTUFBTTtVQUNsQ3pHLEtBQUEsQ0FBTXlHLGtCQUFBLENBQW1CVyxJQUFBLEVBQU1oQixHQUFHO1FBQ3RDO1FBQ0EsSUFBSSxDQUFDYyxZQUFBLENBQWFFLElBQUEsR0FBTztVQUNyQmpCLElBQUEsQ0FBS0MsR0FBRztVQUNSYyxZQUFBLENBQWFFLElBQUEsSUFBUTtRQUN6QjtNQUNKO01BRUFwSCxLQUFBLENBQU1xRywyQkFBQSxHQUE4QjtNQUNwQ3JHLEtBQUEsQ0FBTXlHLGtCQUFBLEdBQXFCO01BRTNCLFNBQVNZLFdBQVcvRyxLQUFBLEVBQU87UUFDdkIsT0FDSyxPQUFPZ0gsUUFBQSxLQUFhLGVBQWVoSCxLQUFBLFlBQWlCZ0gsUUFBQSxJQUNyRDlHLE1BQUEsQ0FBT0MsU0FBQSxDQUFVQyxRQUFBLENBQVNDLElBQUEsQ0FBS0wsS0FBSyxNQUFNO01BRWxEO01BRUEsU0FBU2lILElBQUl2QixNQUFBLEVBQVE7UUFDakIsSUFBSVosSUFBQSxFQUFNdEQsQ0FBQTtRQUNWLEtBQUtBLENBQUEsSUFBS2tFLE1BQUEsRUFBUTtVQUNkLElBQUluRixVQUFBLENBQVdtRixNQUFBLEVBQVFsRSxDQUFDLEdBQUc7WUFDdkJzRCxJQUFBLEdBQU9ZLE1BQUEsQ0FBT2xFLENBQUE7WUFDZCxJQUFJdUYsVUFBQSxDQUFXakMsSUFBSSxHQUFHO2NBQ2xCLEtBQUt0RCxDQUFBLElBQUtzRCxJQUFBO1lBQ2QsT0FBTztjQUNILEtBQUssTUFBTXRELENBQUEsSUFBS3NELElBQUE7WUFDcEI7VUFDSjtRQUNKO1FBQ0EsS0FBS29DLE9BQUEsR0FBVXhCLE1BQUE7UUFJZixLQUFLeUIsOEJBQUEsR0FBaUMsSUFBSUMsTUFBQSxFQUNyQyxLQUFLQyx1QkFBQSxDQUF3QkMsTUFBQSxJQUFVLEtBQUtDLGFBQUEsQ0FBY0QsTUFBQSxJQUN2RCxNQUNBLFVBQVVBLE1BQ2xCO01BQ0o7TUFFQSxTQUFTRSxhQUFhQyxZQUFBLEVBQWNDLFdBQUEsRUFBYTtRQUM3QyxJQUFJbkcsR0FBQSxHQUFNSSxNQUFBLENBQU8sQ0FBQyxHQUFHOEYsWUFBWTtVQUM3QjNDLElBQUE7UUFDSixLQUFLQSxJQUFBLElBQVE0QyxXQUFBLEVBQWE7VUFDdEIsSUFBSW5ILFVBQUEsQ0FBV21ILFdBQUEsRUFBYTVDLElBQUksR0FBRztZQUMvQixJQUFJeEUsUUFBQSxDQUFTbUgsWUFBQSxDQUFhM0MsSUFBQSxDQUFLLEtBQUt4RSxRQUFBLENBQVNvSCxXQUFBLENBQVk1QyxJQUFBLENBQUssR0FBRztjQUM3RHZELEdBQUEsQ0FBSXVELElBQUEsSUFBUSxDQUFDO2NBQ2JuRCxNQUFBLENBQU9KLEdBQUEsQ0FBSXVELElBQUEsR0FBTzJDLFlBQUEsQ0FBYTNDLElBQUEsQ0FBSztjQUNwQ25ELE1BQUEsQ0FBT0osR0FBQSxDQUFJdUQsSUFBQSxHQUFPNEMsV0FBQSxDQUFZNUMsSUFBQSxDQUFLO1lBQ3ZDLFdBQVc0QyxXQUFBLENBQVk1QyxJQUFBLEtBQVMsTUFBTTtjQUNsQ3ZELEdBQUEsQ0FBSXVELElBQUEsSUFBUTRDLFdBQUEsQ0FBWTVDLElBQUE7WUFDNUIsT0FBTztjQUNILE9BQU92RCxHQUFBLENBQUl1RCxJQUFBO1lBQ2Y7VUFDSjtRQUNKO1FBQ0EsS0FBS0EsSUFBQSxJQUFRMkMsWUFBQSxFQUFjO1VBQ3ZCLElBQ0lsSCxVQUFBLENBQVdrSCxZQUFBLEVBQWMzQyxJQUFJLEtBQzdCLENBQUN2RSxVQUFBLENBQVdtSCxXQUFBLEVBQWE1QyxJQUFJLEtBQzdCeEUsUUFBQSxDQUFTbUgsWUFBQSxDQUFhM0MsSUFBQSxDQUFLLEdBQzdCO1lBRUV2RCxHQUFBLENBQUl1RCxJQUFBLElBQVFuRCxNQUFBLENBQU8sQ0FBQyxHQUFHSixHQUFBLENBQUl1RCxJQUFBLENBQUs7VUFDcEM7UUFDSjtRQUNBLE9BQU92RCxHQUFBO01BQ1g7TUFFQSxTQUFTb0csT0FBT2pDLE1BQUEsRUFBUTtRQUNwQixJQUFJQSxNQUFBLElBQVUsTUFBTTtVQUNoQixLQUFLdUIsR0FBQSxDQUFJdkIsTUFBTTtRQUNuQjtNQUNKO01BRUEsSUFBSWtDLElBQUE7TUFFSixJQUFJMUgsTUFBQSxDQUFPMEgsSUFBQSxFQUFNO1FBQ2JBLElBQUEsR0FBTzFILE1BQUEsQ0FBTzBILElBQUE7TUFDbEIsT0FBTztRQUNIQSxJQUFBLEdBQU8sU0FBQUEsQ0FBVWhILEdBQUEsRUFBSztVQUNsQixJQUFJWSxDQUFBO1lBQ0FELEdBQUEsR0FBTSxFQUFDO1VBQ1gsS0FBS0MsQ0FBQSxJQUFLWixHQUFBLEVBQUs7WUFDWCxJQUFJTCxVQUFBLENBQVdLLEdBQUEsRUFBS1ksQ0FBQyxHQUFHO2NBQ3BCRCxHQUFBLENBQUlHLElBQUEsQ0FBS0YsQ0FBQztZQUNkO1VBQ0o7VUFDQSxPQUFPRCxHQUFBO1FBQ1g7TUFDSjtNQUVBLElBQUlzRyxlQUFBLEdBQWtCO1FBQ2xCQyxPQUFBLEVBQVM7UUFDVEMsT0FBQSxFQUFTO1FBQ1RDLFFBQUEsRUFBVTtRQUNWQyxPQUFBLEVBQVM7UUFDVEMsUUFBQSxFQUFVO1FBQ1ZDLFFBQUEsRUFBVTtNQUNkO01BRUEsU0FBU0MsU0FBUzlCLEdBQUEsRUFBSytCLEdBQUEsRUFBS0MsSUFBQSxFQUFLO1FBQzdCLElBQUlDLE1BQUEsR0FBUyxLQUFLQyxTQUFBLENBQVVsQyxHQUFBLEtBQVEsS0FBS2tDLFNBQUEsQ0FBVTtRQUNuRCxPQUFPekIsVUFBQSxDQUFXd0IsTUFBTSxJQUFJQSxNQUFBLENBQU9sSSxJQUFBLENBQUtnSSxHQUFBLEVBQUtDLElBQUcsSUFBSUMsTUFBQTtNQUN4RDtNQUVBLFNBQVNFLFNBQVNDLE1BQUEsRUFBUUMsWUFBQSxFQUFjQyxTQUFBLEVBQVc7UUFDL0MsSUFBSUMsU0FBQSxHQUFZLEtBQUtDLElBQUEsQ0FBS0MsR0FBQSxDQUFJTCxNQUFNO1VBQ2hDTSxXQUFBLEdBQWNMLFlBQUEsR0FBZUUsU0FBQSxDQUFVL0gsTUFBQTtVQUN2Q21JLEtBQUEsR0FBT1AsTUFBQSxJQUFVO1FBQ3JCLFFBQ0tPLEtBQUEsR0FBUUwsU0FBQSxHQUFZLE1BQU0sS0FBTSxPQUNqQ0UsSUFBQSxDQUFLSSxHQUFBLENBQUksSUFBSUosSUFBQSxDQUFLSyxHQUFBLENBQUksR0FBR0gsV0FBVyxDQUFDLEVBQUU1SSxRQUFBLENBQVMsRUFBRWdKLE1BQUEsQ0FBTyxDQUFDLElBQzFEUCxTQUFBO01BRVI7TUFFQSxJQUFJUSxnQkFBQSxHQUNJO1FBQ0pDLHFCQUFBLEdBQXdCO1FBQ3hCQyxlQUFBLEdBQWtCLENBQUM7UUFDbkJDLG9CQUFBLEdBQXVCLENBQUM7TUFNNUIsU0FBU0MsZUFBZUMsTUFBQSxFQUFPQyxNQUFBLEVBQVFDLFFBQUEsRUFBUzlKLFFBQUEsRUFBVTtRQUN0RCxJQUFJK0osSUFBQSxHQUFPL0osUUFBQTtRQUNYLElBQUksT0FBT0EsUUFBQSxLQUFhLFVBQVU7VUFDOUIrSixJQUFBLEdBQU8sU0FBQUEsQ0FBQSxFQUFZO1lBQ2YsT0FBTyxLQUFLL0osUUFBQSxFQUFVO1VBQzFCO1FBQ0o7UUFDQSxJQUFJNEosTUFBQSxFQUFPO1VBQ1BGLG9CQUFBLENBQXFCRSxNQUFBLElBQVNHLElBQUE7UUFDbEM7UUFDQSxJQUFJRixNQUFBLEVBQVE7VUFDUkgsb0JBQUEsQ0FBcUJHLE1BQUEsQ0FBTyxNQUFNLFlBQVk7WUFDMUMsT0FBT2xCLFFBQUEsQ0FBU29CLElBQUEsQ0FBS2xLLEtBQUEsQ0FBTSxNQUFNQyxTQUFTLEdBQUcrSixNQUFBLENBQU8sSUFBSUEsTUFBQSxDQUFPLEVBQUU7VUFDckU7UUFDSjtRQUNBLElBQUlDLFFBQUEsRUFBUztVQUNUSixvQkFBQSxDQUFxQkksUUFBQSxJQUFXLFlBQVk7WUFDeEMsT0FBTyxLQUFLRSxVQUFBLENBQVcsRUFBRUMsT0FBQSxDQUNyQkYsSUFBQSxDQUFLbEssS0FBQSxDQUFNLE1BQU1DLFNBQVMsR0FDMUI4SixNQUNKO1VBQ0o7UUFDSjtNQUNKO01BRUEsU0FBU00sdUJBQXVCaEssS0FBQSxFQUFPO1FBQ25DLElBQUlBLEtBQUEsQ0FBTWlLLEtBQUEsQ0FBTSxVQUFVLEdBQUc7VUFDekIsT0FBT2pLLEtBQUEsQ0FBTWtLLE9BQUEsQ0FBUSxZQUFZLEVBQUU7UUFDdkM7UUFDQSxPQUFPbEssS0FBQSxDQUFNa0ssT0FBQSxDQUFRLE9BQU8sRUFBRTtNQUNsQztNQUVBLFNBQVNDLG1CQUFtQnJJLE9BQUEsRUFBUTtRQUNoQyxJQUFJc0ksS0FBQSxHQUFRdEksT0FBQSxDQUFPbUksS0FBQSxDQUFNWixnQkFBZ0I7VUFDckM3SCxDQUFBO1VBQ0FWLE1BQUE7UUFFSixLQUFLVSxDQUFBLEdBQUksR0FBR1YsTUFBQSxHQUFTc0osS0FBQSxDQUFNdEosTUFBQSxFQUFRVSxDQUFBLEdBQUlWLE1BQUEsRUFBUVUsQ0FBQSxJQUFLO1VBQ2hELElBQUlnSSxvQkFBQSxDQUFxQlksS0FBQSxDQUFNNUksQ0FBQSxJQUFLO1lBQ2hDNEksS0FBQSxDQUFNNUksQ0FBQSxJQUFLZ0ksb0JBQUEsQ0FBcUJZLEtBQUEsQ0FBTTVJLENBQUE7VUFDMUMsT0FBTztZQUNINEksS0FBQSxDQUFNNUksQ0FBQSxJQUFLd0ksc0JBQUEsQ0FBdUJJLEtBQUEsQ0FBTTVJLENBQUEsQ0FBRTtVQUM5QztRQUNKO1FBRUEsT0FBTyxVQUFVNkcsR0FBQSxFQUFLO1VBQ2xCLElBQUlFLE1BQUEsR0FBUztZQUNUOEIsRUFBQTtVQUNKLEtBQUtBLEVBQUEsR0FBSSxHQUFHQSxFQUFBLEdBQUl2SixNQUFBLEVBQVF1SixFQUFBLElBQUs7WUFDekI5QixNQUFBLElBQVV4QixVQUFBLENBQVdxRCxLQUFBLENBQU1DLEVBQUEsQ0FBRSxJQUN2QkQsS0FBQSxDQUFNQyxFQUFBLEVBQUdoSyxJQUFBLENBQUtnSSxHQUFBLEVBQUt2RyxPQUFNLElBQ3pCc0ksS0FBQSxDQUFNQyxFQUFBO1VBQ2hCO1VBQ0EsT0FBTzlCLE1BQUE7UUFDWDtNQUNKO01BR0EsU0FBUytCLGFBQWFqSCxDQUFBLEVBQUd2QixPQUFBLEVBQVE7UUFDN0IsSUFBSSxDQUFDdUIsQ0FBQSxDQUFFTSxPQUFBLENBQVEsR0FBRztVQUNkLE9BQU9OLENBQUEsQ0FBRXlHLFVBQUEsQ0FBVyxFQUFFUyxXQUFBLENBQVk7UUFDdEM7UUFFQXpJLE9BQUEsR0FBUzBJLFlBQUEsQ0FBYTFJLE9BQUEsRUFBUXVCLENBQUEsQ0FBRXlHLFVBQUEsQ0FBVyxDQUFDO1FBQzVDUCxlQUFBLENBQWdCekgsT0FBQSxJQUNaeUgsZUFBQSxDQUFnQnpILE9BQUEsS0FBV3FJLGtCQUFBLENBQW1CckksT0FBTTtRQUV4RCxPQUFPeUgsZUFBQSxDQUFnQnpILE9BQUEsRUFBUXVCLENBQUM7TUFDcEM7TUFFQSxTQUFTbUgsYUFBYTFJLE9BQUEsRUFBUUMsT0FBQSxFQUFRO1FBQ2xDLElBQUlQLENBQUEsR0FBSTtRQUVSLFNBQVNpSiw0QkFBNEJ6SyxLQUFBLEVBQU87VUFDeEMsT0FBTytCLE9BQUEsQ0FBTzJJLGNBQUEsQ0FBZTFLLEtBQUssS0FBS0EsS0FBQTtRQUMzQztRQUVBc0oscUJBQUEsQ0FBc0JxQixTQUFBLEdBQVk7UUFDbEMsT0FBT25KLENBQUEsSUFBSyxLQUFLOEgscUJBQUEsQ0FBc0JzQixJQUFBLENBQUs5SSxPQUFNLEdBQUc7VUFDakRBLE9BQUEsR0FBU0EsT0FBQSxDQUFPb0ksT0FBQSxDQUNaWixxQkFBQSxFQUNBbUIsMkJBQ0o7VUFDQW5CLHFCQUFBLENBQXNCcUIsU0FBQSxHQUFZO1VBQ2xDbkosQ0FBQSxJQUFLO1FBQ1Q7UUFFQSxPQUFPTSxPQUFBO01BQ1g7TUFFQSxJQUFJK0kscUJBQUEsR0FBd0I7UUFDeEJDLEdBQUEsRUFBSztRQUNMQyxFQUFBLEVBQUk7UUFDSkMsQ0FBQSxFQUFHO1FBQ0hDLEVBQUEsRUFBSTtRQUNKQyxHQUFBLEVBQUs7UUFDTEMsSUFBQSxFQUFNO01BQ1Y7TUFFQSxTQUFTVCxlQUFlcEUsR0FBQSxFQUFLO1FBQ3pCLElBQUl4RSxPQUFBLEdBQVMsS0FBS3NKLGVBQUEsQ0FBZ0I5RSxHQUFBO1VBQzlCK0UsV0FBQSxHQUFjLEtBQUtELGVBQUEsQ0FBZ0I5RSxHQUFBLENBQUlnRixXQUFBLENBQVk7UUFFdkQsSUFBSXhKLE9BQUEsSUFBVSxDQUFDdUosV0FBQSxFQUFhO1VBQ3hCLE9BQU92SixPQUFBO1FBQ1g7UUFFQSxLQUFLc0osZUFBQSxDQUFnQjlFLEdBQUEsSUFBTytFLFdBQUEsQ0FDdkJwQixLQUFBLENBQU1aLGdCQUFnQixFQUN0QmpJLEdBQUEsQ0FBSSxVQUFVbUssR0FBQSxFQUFLO1VBQ2hCLElBQ0lBLEdBQUEsS0FBUSxVQUNSQSxHQUFBLEtBQVEsUUFDUkEsR0FBQSxLQUFRLFFBQ1JBLEdBQUEsS0FBUSxRQUNWO1lBQ0UsT0FBT0EsR0FBQSxDQUFJL0UsS0FBQSxDQUFNLENBQUM7VUFDdEI7VUFDQSxPQUFPK0UsR0FBQTtRQUNYLENBQUMsRUFDQTlFLElBQUEsQ0FBSyxFQUFFO1FBRVosT0FBTyxLQUFLMkUsZUFBQSxDQUFnQjlFLEdBQUE7TUFDaEM7TUFFQSxJQUFJa0Ysa0JBQUEsR0FBcUI7TUFFekIsU0FBU2pCLFlBQUEsRUFBYztRQUNuQixPQUFPLEtBQUtrQixZQUFBO01BQ2hCO01BRUEsSUFBSUMsY0FBQSxHQUFpQjtRQUNqQkMsNkJBQUEsR0FBZ0M7TUFFcEMsU0FBUzVCLFFBQVFyQixNQUFBLEVBQVE7UUFDckIsT0FBTyxLQUFLa0QsUUFBQSxDQUFTMUIsT0FBQSxDQUFRLE1BQU14QixNQUFNO01BQzdDO01BRUEsSUFBSW1ELG1CQUFBLEdBQXNCO1FBQ3RCQyxNQUFBLEVBQVE7UUFDUkMsSUFBQSxFQUFNO1FBQ05DLENBQUEsRUFBRztRQUNIQyxFQUFBLEVBQUk7UUFDSjVJLENBQUEsRUFBRztRQUNINkksRUFBQSxFQUFJO1FBQ0pDLENBQUEsRUFBRztRQUNIQyxFQUFBLEVBQUk7UUFDSkMsQ0FBQSxFQUFHO1FBQ0hDLEVBQUEsRUFBSTtRQUNKQyxDQUFBLEVBQUc7UUFDSEMsRUFBQSxFQUFJO1FBQ0pDLENBQUEsRUFBRztRQUNIQyxFQUFBLEVBQUk7UUFDSkMsQ0FBQSxFQUFHO1FBQ0hDLEVBQUEsRUFBSTtNQUNSO01BRUEsU0FBU0MsYUFBYW5FLE1BQUEsRUFBUW9FLGFBQUEsRUFBZUMsTUFBQSxFQUFRQyxRQUFBLEVBQVU7UUFDM0QsSUFBSXpFLE1BQUEsR0FBUyxLQUFLMEUsYUFBQSxDQUFjRixNQUFBO1FBQ2hDLE9BQU9oRyxVQUFBLENBQVd3QixNQUFNLElBQ2xCQSxNQUFBLENBQU9HLE1BQUEsRUFBUW9FLGFBQUEsRUFBZUMsTUFBQSxFQUFRQyxRQUFRLElBQzlDekUsTUFBQSxDQUFPMkIsT0FBQSxDQUFRLE9BQU94QixNQUFNO01BQ3RDO01BRUEsU0FBU3dFLFdBQVdDLEtBQUEsRUFBTTVFLE1BQUEsRUFBUTtRQUM5QixJQUFJekcsT0FBQSxHQUFTLEtBQUttTCxhQUFBLENBQWNFLEtBQUEsR0FBTyxJQUFJLFdBQVc7UUFDdEQsT0FBT3BHLFVBQUEsQ0FBV2pGLE9BQU0sSUFBSUEsT0FBQSxDQUFPeUcsTUFBTSxJQUFJekcsT0FBQSxDQUFPb0ksT0FBQSxDQUFRLE9BQU8zQixNQUFNO01BQzdFO01BRUEsSUFBSTZFLE9BQUEsR0FBVTtRQUNWQyxDQUFBLEVBQUc7UUFDSEMsS0FBQSxFQUFPO1FBQ1BDLElBQUEsRUFBTTtRQUNObEIsQ0FBQSxFQUFHO1FBQ0htQixJQUFBLEVBQU07UUFDTkMsR0FBQSxFQUFLO1FBQ0xDLENBQUEsRUFBRztRQUNIQyxRQUFBLEVBQVU7UUFDVkMsT0FBQSxFQUFTO1FBQ1RDLENBQUEsRUFBRztRQUNIQyxXQUFBLEVBQWE7UUFDYkMsVUFBQSxFQUFZO1FBQ1pDLEdBQUEsRUFBSztRQUNMQyxVQUFBLEVBQVk7UUFDWkMsU0FBQSxFQUFXO1FBQ1gvQixDQUFBLEVBQUc7UUFDSGdDLEtBQUEsRUFBTztRQUNQQyxJQUFBLEVBQU07UUFDTkMsRUFBQSxFQUFJO1FBQ0pDLFlBQUEsRUFBYztRQUNkQyxXQUFBLEVBQWE7UUFDYmxMLENBQUEsRUFBRztRQUNIbUwsT0FBQSxFQUFTO1FBQ1RDLE1BQUEsRUFBUTtRQUNSaEMsQ0FBQSxFQUFHO1FBQ0hpQyxNQUFBLEVBQVE7UUFDUkMsS0FBQSxFQUFPO1FBQ1BDLENBQUEsRUFBRztRQUNIQyxRQUFBLEVBQVU7UUFDVkMsT0FBQSxFQUFTO1FBQ1Q5QyxDQUFBLEVBQUc7UUFDSCtDLE9BQUEsRUFBUztRQUNUQyxNQUFBLEVBQVE7UUFDUkMsRUFBQSxFQUFJO1FBQ0pDLFNBQUEsRUFBVztRQUNYQyxRQUFBLEVBQVU7UUFDVkMsRUFBQSxFQUFJO1FBQ0pDLFlBQUEsRUFBYztRQUNkQyxXQUFBLEVBQWE7UUFDYi9DLENBQUEsRUFBRztRQUNIZ0QsS0FBQSxFQUFPO1FBQ1BDLElBQUEsRUFBTTtRQUNOQyxDQUFBLEVBQUc7UUFDSEMsUUFBQSxFQUFVO1FBQ1ZDLE9BQUEsRUFBUztRQUNUaEQsQ0FBQSxFQUFHO1FBQ0hpRCxLQUFBLEVBQU87UUFDUEMsSUFBQSxFQUFNO01BQ1Y7TUFFQSxTQUFTQyxlQUFlQyxLQUFBLEVBQU87UUFDM0IsT0FBTyxPQUFPQSxLQUFBLEtBQVUsV0FDbEIzQyxPQUFBLENBQVEyQyxLQUFBLEtBQVUzQyxPQUFBLENBQVEyQyxLQUFBLENBQU1DLFdBQUEsQ0FBWSxLQUM1QztNQUNWO01BRUEsU0FBU0MscUJBQXFCQyxXQUFBLEVBQWE7UUFDdkMsSUFBSUMsZUFBQSxHQUFrQixDQUFDO1VBQ25CQyxjQUFBO1VBQ0F0TCxJQUFBO1FBRUosS0FBS0EsSUFBQSxJQUFRb0wsV0FBQSxFQUFhO1VBQ3RCLElBQUkzUCxVQUFBLENBQVcyUCxXQUFBLEVBQWFwTCxJQUFJLEdBQUc7WUFDL0JzTCxjQUFBLEdBQWlCTixjQUFBLENBQWVoTCxJQUFJO1lBQ3BDLElBQUlzTCxjQUFBLEVBQWdCO2NBQ2hCRCxlQUFBLENBQWdCQyxjQUFBLElBQWtCRixXQUFBLENBQVlwTCxJQUFBO1lBQ2xEO1VBQ0o7UUFDSjtRQUVBLE9BQU9xTCxlQUFBO01BQ1g7TUFFQSxJQUFJRSxVQUFBLEdBQWE7UUFDYjlDLElBQUEsRUFBTTtRQUNORSxHQUFBLEVBQUs7UUFDTEcsT0FBQSxFQUFTO1FBQ1QwQyxVQUFBLEVBQVk7UUFDWkMsU0FBQSxFQUFXO1FBQ1huQyxJQUFBLEVBQU07UUFDTkcsV0FBQSxFQUFhO1FBQ2JFLE1BQUEsRUFBUTtRQUNSRSxLQUFBLEVBQU87UUFDUEcsT0FBQSxFQUFTO1FBQ1RFLE1BQUEsRUFBUTtRQUNSd0IsUUFBQSxFQUFVO1FBQ1ZDLFdBQUEsRUFBYTtRQUNiakIsSUFBQSxFQUFNO1FBQ05rQixPQUFBLEVBQVM7UUFDVGIsSUFBQSxFQUFNO01BQ1Y7TUFFQSxTQUFTYyxvQkFBb0JDLFFBQUEsRUFBVTtRQUNuQyxJQUFJYixLQUFBLEdBQVEsRUFBQztVQUNUYyxDQUFBO1FBQ0osS0FBS0EsQ0FBQSxJQUFLRCxRQUFBLEVBQVU7VUFDaEIsSUFBSXJRLFVBQUEsQ0FBV3FRLFFBQUEsRUFBVUMsQ0FBQyxHQUFHO1lBQ3pCZCxLQUFBLENBQU1yTyxJQUFBLENBQUs7Y0FBRW9QLElBQUEsRUFBTUQsQ0FBQTtjQUFHRSxRQUFBLEVBQVVWLFVBQUEsQ0FBV1EsQ0FBQTtZQUFHLENBQUM7VUFDbkQ7UUFDSjtRQUNBZCxLQUFBLENBQU1pQixJQUFBLENBQUssVUFBVXhRLENBQUEsRUFBR0MsQ0FBQSxFQUFHO1VBQ3ZCLE9BQU9ELENBQUEsQ0FBRXVRLFFBQUEsR0FBV3RRLENBQUEsQ0FBRXNRLFFBQUE7UUFDMUIsQ0FBQztRQUNELE9BQU9oQixLQUFBO01BQ1g7TUFFQSxJQUFJa0IsTUFBQSxHQUFTO1FBQ1RDLE1BQUEsR0FBUztRQUNUQyxNQUFBLEdBQVM7UUFDVEMsTUFBQSxHQUFTO1FBQ1RDLE1BQUEsR0FBUztRQUNUQyxTQUFBLEdBQVk7UUFDWkMsU0FBQSxHQUFZO1FBQ1pDLFNBQUEsR0FBWTtRQUNaQyxTQUFBLEdBQVk7UUFDWkMsU0FBQSxHQUFZO1FBQ1pDLFNBQUEsR0FBWTtRQUNaQyxhQUFBLEdBQWdCO1FBQ2hCQyxXQUFBLEdBQWM7UUFDZEMsV0FBQSxHQUFjO1FBQ2RDLGdCQUFBLEdBQW1CO1FBQ25CQyxjQUFBLEdBQWlCO1FBR2pCQyxTQUFBLEdBQ0k7UUFDSkMsc0JBQUEsR0FBeUI7UUFDekJDLGdCQUFBLEdBQW1CO1FBQ25CQyxPQUFBO01BRUpBLE9BQUEsR0FBVSxDQUFDO01BRVgsU0FBU0MsY0FBYzNJLE1BQUEsRUFBTzRJLEtBQUEsRUFBT0MsV0FBQSxFQUFhO1FBQzlDSCxPQUFBLENBQVExSSxNQUFBLElBQVMzQyxVQUFBLENBQVd1TCxLQUFLLElBQzNCQSxLQUFBLEdBQ0EsVUFBVUUsUUFBQSxFQUFVQyxXQUFBLEVBQVk7VUFDNUIsT0FBT0QsUUFBQSxJQUFZRCxXQUFBLEdBQWNBLFdBQUEsR0FBY0QsS0FBQTtRQUNuRDtNQUNWO01BRUEsU0FBU0ksc0JBQXNCaEosTUFBQSxFQUFPaEUsTUFBQSxFQUFRO1FBQzFDLElBQUksQ0FBQ25GLFVBQUEsQ0FBVzZSLE9BQUEsRUFBUzFJLE1BQUssR0FBRztVQUM3QixPQUFPLElBQUl0QyxNQUFBLENBQU91TCxjQUFBLENBQWVqSixNQUFLLENBQUM7UUFDM0M7UUFFQSxPQUFPMEksT0FBQSxDQUFRMUksTUFBQSxFQUFPaEUsTUFBQSxDQUFPdkIsT0FBQSxFQUFTdUIsTUFBQSxDQUFPRixPQUFPO01BQ3hEO01BR0EsU0FBU21OLGVBQWUzRyxDQUFBLEVBQUc7UUFDdkIsT0FBTzRHLFdBQUEsQ0FDSDVHLENBQUEsQ0FDSzlCLE9BQUEsQ0FBUSxNQUFNLEVBQUUsRUFDaEJBLE9BQUEsQ0FDRyx1Q0FDQSxVQUFVMkksT0FBQSxFQUFTQyxFQUFBLEVBQUlDLEVBQUEsRUFBSUMsRUFBQSxFQUFJQyxFQUFBLEVBQUk7VUFDL0IsT0FBT0gsRUFBQSxJQUFNQyxFQUFBLElBQU1DLEVBQUEsSUFBTUMsRUFBQTtRQUM3QixDQUNKLENBQ1I7TUFDSjtNQUVBLFNBQVNMLFlBQVk1RyxDQUFBLEVBQUc7UUFDcEIsT0FBT0EsQ0FBQSxDQUFFOUIsT0FBQSxDQUFRLDBCQUEwQixNQUFNO01BQ3JEO01BRUEsU0FBU2dKLFNBQVN4SyxNQUFBLEVBQVE7UUFDdEIsSUFBSUEsTUFBQSxHQUFTLEdBQUc7VUFFWixPQUFPSSxJQUFBLENBQUtxSyxJQUFBLENBQUt6SyxNQUFNLEtBQUs7UUFDaEMsT0FBTztVQUNILE9BQU9JLElBQUEsQ0FBS3NLLEtBQUEsQ0FBTTFLLE1BQU07UUFDNUI7TUFDSjtNQUVBLFNBQVMySyxNQUFNQyxtQkFBQSxFQUFxQjtRQUNoQyxJQUFJQyxhQUFBLEdBQWdCLENBQUNELG1CQUFBO1VBQ2pCRSxLQUFBLEdBQVE7UUFFWixJQUFJRCxhQUFBLEtBQWtCLEtBQUtFLFFBQUEsQ0FBU0YsYUFBYSxHQUFHO1VBQ2hEQyxLQUFBLEdBQVFOLFFBQUEsQ0FBU0ssYUFBYTtRQUNsQztRQUVBLE9BQU9DLEtBQUE7TUFDWDtNQUVBLElBQUlFLE1BQUEsR0FBUyxDQUFDO01BRWQsU0FBU0MsY0FBY2pLLE1BQUEsRUFBTzVKLFFBQUEsRUFBVTtRQUNwQyxJQUFJMEIsQ0FBQTtVQUNBcUksSUFBQSxHQUFPL0osUUFBQTtVQUNQOFQsUUFBQTtRQUNKLElBQUksT0FBT2xLLE1BQUEsS0FBVSxVQUFVO1VBQzNCQSxNQUFBLEdBQVEsQ0FBQ0EsTUFBSztRQUNsQjtRQUNBLElBQUl6SSxRQUFBLENBQVNuQixRQUFRLEdBQUc7VUFDcEIrSixJQUFBLEdBQU8sU0FBQUEsQ0FBVTdKLEtBQUEsRUFBT29LLEtBQUEsRUFBTztZQUMzQkEsS0FBQSxDQUFNdEssUUFBQSxJQUFZdVQsS0FBQSxDQUFNclQsS0FBSztVQUNqQztRQUNKO1FBQ0E0VCxRQUFBLEdBQVdsSyxNQUFBLENBQU01SSxNQUFBO1FBQ2pCLEtBQUtVLENBQUEsR0FBSSxHQUFHQSxDQUFBLEdBQUlvUyxRQUFBLEVBQVVwUyxDQUFBLElBQUs7VUFDM0JrUyxNQUFBLENBQU9oSyxNQUFBLENBQU1sSSxDQUFBLEtBQU1xSSxJQUFBO1FBQ3ZCO01BQ0o7TUFFQSxTQUFTZ0ssa0JBQWtCbkssTUFBQSxFQUFPNUosUUFBQSxFQUFVO1FBQ3hDNlQsYUFBQSxDQUFjakssTUFBQSxFQUFPLFVBQVUxSixLQUFBLEVBQU9vSyxLQUFBLEVBQU8xRSxNQUFBLEVBQVFvTyxNQUFBLEVBQU87VUFDeERwTyxNQUFBLENBQU9xTyxFQUFBLEdBQUtyTyxNQUFBLENBQU9xTyxFQUFBLElBQU0sQ0FBQztVQUMxQmpVLFFBQUEsQ0FBU0UsS0FBQSxFQUFPMEYsTUFBQSxDQUFPcU8sRUFBQSxFQUFJck8sTUFBQSxFQUFRb08sTUFBSztRQUM1QyxDQUFDO01BQ0w7TUFFQSxTQUFTRSx3QkFBd0J0SyxNQUFBLEVBQU8xSixLQUFBLEVBQU8wRixNQUFBLEVBQVE7UUFDbkQsSUFBSTFGLEtBQUEsSUFBUyxRQUFRTyxVQUFBLENBQVdtVCxNQUFBLEVBQVFoSyxNQUFLLEdBQUc7VUFDNUNnSyxNQUFBLENBQU9oSyxNQUFBLEVBQU8xSixLQUFBLEVBQU8wRixNQUFBLENBQU91TyxFQUFBLEVBQUl2TyxNQUFBLEVBQVFnRSxNQUFLO1FBQ2pEO01BQ0o7TUFFQSxTQUFTd0ssV0FBV3JFLElBQUEsRUFBTTtRQUN0QixPQUFRQSxJQUFBLEdBQU8sTUFBTSxLQUFLQSxJQUFBLEdBQU8sUUFBUSxLQUFNQSxJQUFBLEdBQU8sUUFBUTtNQUNsRTtNQUVBLElBQUlzRSxJQUFBLEdBQU87UUFDUEMsS0FBQSxHQUFRO1FBQ1JDLElBQUEsR0FBTztRQUNQQyxJQUFBLEdBQU87UUFDUEMsTUFBQSxHQUFTO1FBQ1RDLE1BQUEsR0FBUztRQUNUQyxXQUFBLEdBQWM7UUFDZEMsSUFBQSxHQUFPO1FBQ1BDLE9BQUEsR0FBVTtNQUlkbEwsY0FBQSxDQUFlLEtBQUssR0FBRyxHQUFHLFlBQVk7UUFDbEMsSUFBSWtELENBQUEsR0FBSSxLQUFLa0QsSUFBQSxDQUFLO1FBQ2xCLE9BQU9sRCxDQUFBLElBQUssT0FBT2xFLFFBQUEsQ0FBU2tFLENBQUEsRUFBRyxDQUFDLElBQUksTUFBTUEsQ0FBQTtNQUM5QyxDQUFDO01BRURsRCxjQUFBLENBQWUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsWUFBWTtRQUN4QyxPQUFPLEtBQUtvRyxJQUFBLENBQUssSUFBSTtNQUN6QixDQUFDO01BRURwRyxjQUFBLENBQWUsR0FBRyxDQUFDLFFBQVEsQ0FBQyxHQUFHLEdBQUcsTUFBTTtNQUN4Q0EsY0FBQSxDQUFlLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBRyxHQUFHLE1BQU07TUFDekNBLGNBQUEsQ0FBZSxHQUFHLENBQUMsVUFBVSxHQUFHLElBQUksR0FBRyxHQUFHLE1BQU07TUFJaEQ0SSxhQUFBLENBQWMsS0FBS1IsV0FBVztNQUM5QlEsYUFBQSxDQUFjLE1BQU1mLFNBQUEsRUFBV0osTUFBTTtNQUNyQ21CLGFBQUEsQ0FBYyxRQUFRWCxTQUFBLEVBQVdOLE1BQU07TUFDdkNpQixhQUFBLENBQWMsU0FBU1YsU0FBQSxFQUFXTixNQUFNO01BQ3hDZ0IsYUFBQSxDQUFjLFVBQVVWLFNBQUEsRUFBV04sTUFBTTtNQUV6Q3NDLGFBQUEsQ0FBYyxDQUFDLFNBQVMsUUFBUSxHQUFHUSxJQUFJO01BQ3ZDUixhQUFBLENBQWMsUUFBUSxVQUFVM1QsS0FBQSxFQUFPb0ssS0FBQSxFQUFPO1FBQzFDQSxLQUFBLENBQU0rSixJQUFBLElBQ0ZuVSxLQUFBLENBQU1jLE1BQUEsS0FBVyxJQUFJcEIsS0FBQSxDQUFNa1YsaUJBQUEsQ0FBa0I1VSxLQUFLLElBQUlxVCxLQUFBLENBQU1yVCxLQUFLO01BQ3pFLENBQUM7TUFDRDJULGFBQUEsQ0FBYyxNQUFNLFVBQVUzVCxLQUFBLEVBQU9vSyxLQUFBLEVBQU87UUFDeENBLEtBQUEsQ0FBTStKLElBQUEsSUFBUXpVLEtBQUEsQ0FBTWtWLGlCQUFBLENBQWtCNVUsS0FBSztNQUMvQyxDQUFDO01BQ0QyVCxhQUFBLENBQWMsS0FBSyxVQUFVM1QsS0FBQSxFQUFPb0ssS0FBQSxFQUFPO1FBQ3ZDQSxLQUFBLENBQU0rSixJQUFBLElBQVFVLFFBQUEsQ0FBUzdVLEtBQUEsRUFBTyxFQUFFO01BQ3BDLENBQUM7TUFJRCxTQUFTOFUsV0FBV2pGLElBQUEsRUFBTTtRQUN0QixPQUFPcUUsVUFBQSxDQUFXckUsSUFBSSxJQUFJLE1BQU07TUFDcEM7TUFJQW5RLEtBQUEsQ0FBTWtWLGlCQUFBLEdBQW9CLFVBQVU1VSxLQUFBLEVBQU87UUFDdkMsT0FBT3FULEtBQUEsQ0FBTXJULEtBQUssS0FBS3FULEtBQUEsQ0FBTXJULEtBQUssSUFBSSxLQUFLLE9BQU87TUFDdEQ7TUFJQSxJQUFJK1UsVUFBQSxHQUFhQyxVQUFBLENBQVcsWUFBWSxJQUFJO01BRTVDLFNBQVNDLGNBQUEsRUFBZ0I7UUFDckIsT0FBT2YsVUFBQSxDQUFXLEtBQUtyRSxJQUFBLENBQUssQ0FBQztNQUNqQztNQUVBLFNBQVNtRixXQUFXbEUsSUFBQSxFQUFNb0UsUUFBQSxFQUFVO1FBQ2hDLE9BQU8sVUFBVTFCLEtBQUEsRUFBTztVQUNwQixJQUFJQSxLQUFBLElBQVMsTUFBTTtZQUNmMkIsS0FBQSxDQUFNLE1BQU1yRSxJQUFBLEVBQU0wQyxLQUFLO1lBQ3ZCOVQsS0FBQSxDQUFNaUcsWUFBQSxDQUFhLE1BQU11UCxRQUFRO1lBQ2pDLE9BQU87VUFDWCxPQUFPO1lBQ0gsT0FBT0UsR0FBQSxDQUFJLE1BQU10RSxJQUFJO1VBQ3pCO1FBQ0o7TUFDSjtNQUVBLFNBQVNzRSxJQUFJL00sR0FBQSxFQUFLeUksSUFBQSxFQUFNO1FBQ3BCLElBQUksQ0FBQ3pJLEdBQUEsQ0FBSTFFLE9BQUEsQ0FBUSxHQUFHO1VBQ2hCLE9BQU9hLEdBQUE7UUFDWDtRQUVBLElBQUk2SCxDQUFBLEdBQUloRSxHQUFBLENBQUl0RSxFQUFBO1VBQ1JzUixLQUFBLEdBQVFoTixHQUFBLENBQUkvQyxNQUFBO1FBRWhCLFFBQVF3TCxJQUFBO1VBQUEsS0FDQztZQUNELE9BQU91RSxLQUFBLEdBQVFoSixDQUFBLENBQUVpSixrQkFBQSxDQUFtQixJQUFJakosQ0FBQSxDQUFFa0osZUFBQSxDQUFnQjtVQUFBLEtBQ3pEO1lBQ0QsT0FBT0YsS0FBQSxHQUFRaEosQ0FBQSxDQUFFbUosYUFBQSxDQUFjLElBQUluSixDQUFBLENBQUVvSixVQUFBLENBQVc7VUFBQSxLQUMvQztZQUNELE9BQU9KLEtBQUEsR0FBUWhKLENBQUEsQ0FBRXFKLGFBQUEsQ0FBYyxJQUFJckosQ0FBQSxDQUFFc0osVUFBQSxDQUFXO1VBQUEsS0FDL0M7WUFDRCxPQUFPTixLQUFBLEdBQVFoSixDQUFBLENBQUV1SixXQUFBLENBQVksSUFBSXZKLENBQUEsQ0FBRXdKLFFBQUEsQ0FBUztVQUFBLEtBQzNDO1lBQ0QsT0FBT1IsS0FBQSxHQUFRaEosQ0FBQSxDQUFFeUosVUFBQSxDQUFXLElBQUl6SixDQUFBLENBQUUwSixPQUFBLENBQVE7VUFBQSxLQUN6QztZQUNELE9BQU9WLEtBQUEsR0FBUWhKLENBQUEsQ0FBRTJKLFNBQUEsQ0FBVSxJQUFJM0osQ0FBQSxDQUFFNEosTUFBQSxDQUFPO1VBQUEsS0FDdkM7WUFDRCxPQUFPWixLQUFBLEdBQVFoSixDQUFBLENBQUU2SixXQUFBLENBQVksSUFBSTdKLENBQUEsQ0FBRThKLFFBQUEsQ0FBUztVQUFBLEtBQzNDO1lBQ0QsT0FBT2QsS0FBQSxHQUFRaEosQ0FBQSxDQUFFK0osY0FBQSxDQUFlLElBQUkvSixDQUFBLENBQUVnSyxXQUFBLENBQVk7VUFBQTtZQUVsRCxPQUFPN1IsR0FBQTtRQUFBO01BRW5CO01BRUEsU0FBUzJRLE1BQU05TSxHQUFBLEVBQUt5SSxJQUFBLEVBQU0wQyxLQUFBLEVBQU87UUFDN0IsSUFBSW5ILENBQUEsRUFBR2dKLEtBQUEsRUFBT3hGLElBQUEsRUFBTWxCLEtBQUEsRUFBT3BCLElBQUE7UUFFM0IsSUFBSSxDQUFDbEYsR0FBQSxDQUFJMUUsT0FBQSxDQUFRLEtBQUtLLEtBQUEsQ0FBTXdQLEtBQUssR0FBRztVQUNoQztRQUNKO1FBRUFuSCxDQUFBLEdBQUloRSxHQUFBLENBQUl0RSxFQUFBO1FBQ1JzUixLQUFBLEdBQVFoTixHQUFBLENBQUkvQyxNQUFBO1FBRVosUUFBUXdMLElBQUE7VUFBQSxLQUNDO1lBQ0QsT0FBTyxNQUFNdUUsS0FBQSxHQUNQaEosQ0FBQSxDQUFFaUssa0JBQUEsQ0FBbUI5QyxLQUFLLElBQzFCbkgsQ0FBQSxDQUFFa0ssZUFBQSxDQUFnQi9DLEtBQUs7VUFBQSxLQUM1QjtZQUNELE9BQU8sTUFBTTZCLEtBQUEsR0FBUWhKLENBQUEsQ0FBRW1LLGFBQUEsQ0FBY2hELEtBQUssSUFBSW5ILENBQUEsQ0FBRW9LLFVBQUEsQ0FBV2pELEtBQUs7VUFBQSxLQUMvRDtZQUNELE9BQU8sTUFBTTZCLEtBQUEsR0FBUWhKLENBQUEsQ0FBRXFLLGFBQUEsQ0FBY2xELEtBQUssSUFBSW5ILENBQUEsQ0FBRXNLLFVBQUEsQ0FBV25ELEtBQUs7VUFBQSxLQUMvRDtZQUNELE9BQU8sTUFBTTZCLEtBQUEsR0FBUWhKLENBQUEsQ0FBRXVLLFdBQUEsQ0FBWXBELEtBQUssSUFBSW5ILENBQUEsQ0FBRXdLLFFBQUEsQ0FBU3JELEtBQUs7VUFBQSxLQUMzRDtZQUNELE9BQU8sTUFBTTZCLEtBQUEsR0FBUWhKLENBQUEsQ0FBRXlLLFVBQUEsQ0FBV3RELEtBQUssSUFBSW5ILENBQUEsQ0FBRTBLLE9BQUEsQ0FBUXZELEtBQUs7VUFBQSxLQUt6RDtZQUNEO1VBQUE7WUFFQTtRQUFBO1FBR1IzRCxJQUFBLEdBQU8yRCxLQUFBO1FBQ1A3RSxLQUFBLEdBQVF0RyxHQUFBLENBQUlzRyxLQUFBLENBQU07UUFDbEJwQixJQUFBLEdBQU9sRixHQUFBLENBQUlrRixJQUFBLENBQUs7UUFDaEJBLElBQUEsR0FBT0EsSUFBQSxLQUFTLE1BQU1vQixLQUFBLEtBQVUsS0FBSyxDQUFDdUYsVUFBQSxDQUFXckUsSUFBSSxJQUFJLEtBQUt0QyxJQUFBO1FBQzlELE1BQU04SCxLQUFBLEdBQ0FoSixDQUFBLENBQUUySyxjQUFBLENBQWVuSCxJQUFBLEVBQU1sQixLQUFBLEVBQU9wQixJQUFJLElBQ2xDbEIsQ0FBQSxDQUFFNEssV0FBQSxDQUFZcEgsSUFBQSxFQUFNbEIsS0FBQSxFQUFPcEIsSUFBSTtNQUN6QztNQUlBLFNBQVMySixVQUFVbkgsS0FBQSxFQUFPO1FBQ3RCQSxLQUFBLEdBQVFELGNBQUEsQ0FBZUMsS0FBSztRQUM1QixJQUFJaEosVUFBQSxDQUFXLEtBQUtnSixLQUFBLENBQU0sR0FBRztVQUN6QixPQUFPLEtBQUtBLEtBQUEsRUFBTztRQUN2QjtRQUNBLE9BQU87TUFDWDtNQUVBLFNBQVNvSCxVQUFVcEgsS0FBQSxFQUFPeUQsS0FBQSxFQUFPO1FBQzdCLElBQUksT0FBT3pELEtBQUEsS0FBVSxVQUFVO1VBQzNCQSxLQUFBLEdBQVFFLG9CQUFBLENBQXFCRixLQUFLO1VBQ2xDLElBQUlxSCxXQUFBLEdBQWN6RyxtQkFBQSxDQUFvQlosS0FBSztZQUN2Q3ZPLENBQUE7WUFDQTZWLGNBQUEsR0FBaUJELFdBQUEsQ0FBWXRXLE1BQUE7VUFDakMsS0FBS1UsQ0FBQSxHQUFJLEdBQUdBLENBQUEsR0FBSTZWLGNBQUEsRUFBZ0I3VixDQUFBLElBQUs7WUFDakMsS0FBSzRWLFdBQUEsQ0FBWTVWLENBQUEsRUFBR3NQLElBQUEsRUFBTWYsS0FBQSxDQUFNcUgsV0FBQSxDQUFZNVYsQ0FBQSxFQUFHc1AsSUFBQSxDQUFLO1VBQ3hEO1FBQ0osT0FBTztVQUNIZixLQUFBLEdBQVFELGNBQUEsQ0FBZUMsS0FBSztVQUM1QixJQUFJaEosVUFBQSxDQUFXLEtBQUtnSixLQUFBLENBQU0sR0FBRztZQUN6QixPQUFPLEtBQUtBLEtBQUEsRUFBT3lELEtBQUs7VUFDNUI7UUFDSjtRQUNBLE9BQU87TUFDWDtNQUVBLFNBQVM4RCxJQUFJQyxDQUFBLEVBQUdDLENBQUEsRUFBRztRQUNmLFFBQVNELENBQUEsR0FBSUMsQ0FBQSxHQUFLQSxDQUFBLElBQUtBLENBQUE7TUFDM0I7TUFFQSxJQUFJQyxPQUFBO01BRUosSUFBSXhYLEtBQUEsQ0FBTUUsU0FBQSxDQUFVc1gsT0FBQSxFQUFTO1FBQ3pCQSxPQUFBLEdBQVV4WCxLQUFBLENBQU1FLFNBQUEsQ0FBVXNYLE9BQUE7TUFDOUIsT0FBTztRQUNIQSxPQUFBLEdBQVUsU0FBQUEsQ0FBVUMsQ0FBQSxFQUFHO1VBRW5CLElBQUlsVyxDQUFBO1VBQ0osS0FBS0EsQ0FBQSxHQUFJLEdBQUdBLENBQUEsR0FBSSxLQUFLVixNQUFBLEVBQVEsRUFBRVUsQ0FBQSxFQUFHO1lBQzlCLElBQUksS0FBS0EsQ0FBQSxNQUFPa1csQ0FBQSxFQUFHO2NBQ2YsT0FBT2xXLENBQUE7WUFDWDtVQUNKO1VBQ0EsT0FBTztRQUNYO01BQ0o7TUFFQSxTQUFTbVcsWUFBWTlILElBQUEsRUFBTWxCLEtBQUEsRUFBTztRQUM5QixJQUFJM0ssS0FBQSxDQUFNNkwsSUFBSSxLQUFLN0wsS0FBQSxDQUFNMkssS0FBSyxHQUFHO1VBQzdCLE9BQU9uSyxHQUFBO1FBQ1g7UUFDQSxJQUFJb1QsUUFBQSxHQUFXTixHQUFBLENBQUkzSSxLQUFBLEVBQU8sRUFBRTtRQUM1QmtCLElBQUEsS0FBU2xCLEtBQUEsR0FBUWlKLFFBQUEsSUFBWTtRQUM3QixPQUFPQSxRQUFBLEtBQWEsSUFDZDFELFVBQUEsQ0FBV3JFLElBQUksSUFDWCxLQUNBLEtBQ0osS0FBTytILFFBQUEsR0FBVyxJQUFLO01BQ2pDO01BSUFuTyxjQUFBLENBQWUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLE1BQU0sWUFBWTtRQUM3QyxPQUFPLEtBQUtrRixLQUFBLENBQU0sSUFBSTtNQUMxQixDQUFDO01BRURsRixjQUFBLENBQWUsT0FBTyxHQUFHLEdBQUcsVUFBVTNILE9BQUEsRUFBUTtRQUMxQyxPQUFPLEtBQUtnSSxVQUFBLENBQVcsRUFBRStOLFdBQUEsQ0FBWSxNQUFNL1YsT0FBTTtNQUNyRCxDQUFDO01BRUQySCxjQUFBLENBQWUsUUFBUSxHQUFHLEdBQUcsVUFBVTNILE9BQUEsRUFBUTtRQUMzQyxPQUFPLEtBQUtnSSxVQUFBLENBQVcsRUFBRTRFLE1BQUEsQ0FBTyxNQUFNNU0sT0FBTTtNQUNoRCxDQUFDO01BSUR1USxhQUFBLENBQWMsS0FBS2YsU0FBQSxFQUFXWSxzQkFBc0I7TUFDcERHLGFBQUEsQ0FBYyxNQUFNZixTQUFBLEVBQVdKLE1BQU07TUFDckNtQixhQUFBLENBQWMsT0FBTyxVQUFVRyxRQUFBLEVBQVV6USxPQUFBLEVBQVE7UUFDN0MsT0FBT0EsT0FBQSxDQUFPK1YsZ0JBQUEsQ0FBaUJ0RixRQUFRO01BQzNDLENBQUM7TUFDREgsYUFBQSxDQUFjLFFBQVEsVUFBVUcsUUFBQSxFQUFVelEsT0FBQSxFQUFRO1FBQzlDLE9BQU9BLE9BQUEsQ0FBT2dXLFdBQUEsQ0FBWXZGLFFBQVE7TUFDdEMsQ0FBQztNQUVEbUIsYUFBQSxDQUFjLENBQUMsS0FBSyxJQUFJLEdBQUcsVUFBVTNULEtBQUEsRUFBT29LLEtBQUEsRUFBTztRQUMvQ0EsS0FBQSxDQUFNZ0ssS0FBQSxJQUFTZixLQUFBLENBQU1yVCxLQUFLLElBQUk7TUFDbEMsQ0FBQztNQUVEMlQsYUFBQSxDQUFjLENBQUMsT0FBTyxNQUFNLEdBQUcsVUFBVTNULEtBQUEsRUFBT29LLEtBQUEsRUFBTzFFLE1BQUEsRUFBUWdFLE1BQUEsRUFBTztRQUNsRSxJQUFJaUYsS0FBQSxHQUFRakosTUFBQSxDQUFPRixPQUFBLENBQVF3UyxXQUFBLENBQVloWSxLQUFBLEVBQU8wSixNQUFBLEVBQU9oRSxNQUFBLENBQU92QixPQUFPO1FBRW5FLElBQUl3SyxLQUFBLElBQVMsTUFBTTtVQUNmdkUsS0FBQSxDQUFNZ0ssS0FBQSxJQUFTekYsS0FBQTtRQUNuQixPQUFPO1VBQ0h2TCxlQUFBLENBQWdCc0MsTUFBTSxFQUFFL0MsWUFBQSxHQUFlM0MsS0FBQTtRQUMzQztNQUNKLENBQUM7TUFJRCxJQUFJaVksbUJBQUEsR0FDSSx3RkFBd0ZDLEtBQUEsQ0FDcEYsR0FDSjtRQUNKQyx3QkFBQSxHQUNJLGtEQUFrREQsS0FBQSxDQUFNLEdBQUc7UUFDL0RFLGdCQUFBLEdBQW1CO1FBQ25CQyx1QkFBQSxHQUEwQnBHLFNBQUE7UUFDMUJxRyxrQkFBQSxHQUFxQnJHLFNBQUE7TUFFekIsU0FBU3NHLGFBQWFsVixDQUFBLEVBQUd2QixPQUFBLEVBQVE7UUFDN0IsSUFBSSxDQUFDdUIsQ0FBQSxFQUFHO1VBQ0osT0FBT3RELE9BQUEsQ0FBUSxLQUFLeVksT0FBTyxJQUNyQixLQUFLQSxPQUFBLEdBQ0wsS0FBS0EsT0FBQSxDQUFRO1FBQ3ZCO1FBQ0EsT0FBT3pZLE9BQUEsQ0FBUSxLQUFLeVksT0FBTyxJQUNyQixLQUFLQSxPQUFBLENBQVFuVixDQUFBLENBQUVzTCxLQUFBLENBQU0sS0FDckIsS0FBSzZKLE9BQUEsRUFDQSxLQUFLQSxPQUFBLENBQVFDLFFBQUEsSUFBWUwsZ0JBQUEsRUFBa0J4TixJQUFBLENBQUs5SSxPQUFNLElBQ2pELFdBQ0EsY0FDUnVCLENBQUEsQ0FBRXNMLEtBQUEsQ0FBTTtNQUNwQjtNQUVBLFNBQVMrSixrQkFBa0JyVixDQUFBLEVBQUd2QixPQUFBLEVBQVE7UUFDbEMsSUFBSSxDQUFDdUIsQ0FBQSxFQUFHO1VBQ0osT0FBT3RELE9BQUEsQ0FBUSxLQUFLNFksWUFBWSxJQUMxQixLQUFLQSxZQUFBLEdBQ0wsS0FBS0EsWUFBQSxDQUFhO1FBQzVCO1FBQ0EsT0FBTzVZLE9BQUEsQ0FBUSxLQUFLNFksWUFBWSxJQUMxQixLQUFLQSxZQUFBLENBQWF0VixDQUFBLENBQUVzTCxLQUFBLENBQU0sS0FDMUIsS0FBS2dLLFlBQUEsQ0FDRFAsZ0JBQUEsQ0FBaUJ4TixJQUFBLENBQUs5SSxPQUFNLElBQUksV0FBVyxjQUM3Q3VCLENBQUEsQ0FBRXNMLEtBQUEsQ0FBTTtNQUNwQjtNQUVBLFNBQVNpSyxrQkFBa0JDLFNBQUEsRUFBVy9XLE9BQUEsRUFBUUUsTUFBQSxFQUFRO1FBQ2xELElBQUlSLENBQUE7VUFDQXNYLEVBQUE7VUFDQXpRLEdBQUE7VUFDQTBRLEdBQUEsR0FBTUYsU0FBQSxDQUFVRyxpQkFBQSxDQUFrQjtRQUN0QyxJQUFJLENBQUMsS0FBS0MsWUFBQSxFQUFjO1VBRXBCLEtBQUtBLFlBQUEsR0FBZSxFQUFDO1VBQ3JCLEtBQUtDLGdCQUFBLEdBQW1CLEVBQUM7VUFDekIsS0FBS0MsaUJBQUEsR0FBb0IsRUFBQztVQUMxQixLQUFLM1gsQ0FBQSxHQUFJLEdBQUdBLENBQUEsR0FBSSxJQUFJLEVBQUVBLENBQUEsRUFBRztZQUNyQjZHLEdBQUEsR0FBTXhHLFNBQUEsQ0FBVSxDQUFDLEtBQU1MLENBQUMsQ0FBQztZQUN6QixLQUFLMlgsaUJBQUEsQ0FBa0IzWCxDQUFBLElBQUssS0FBS3FXLFdBQUEsQ0FDN0J4UCxHQUFBLEVBQ0EsRUFDSixFQUFFMlEsaUJBQUEsQ0FBa0I7WUFDcEIsS0FBS0UsZ0JBQUEsQ0FBaUIxWCxDQUFBLElBQUssS0FBS2tOLE1BQUEsQ0FBT3JHLEdBQUEsRUFBSyxFQUFFLEVBQUUyUSxpQkFBQSxDQUFrQjtVQUN0RTtRQUNKO1FBRUEsSUFBSWhYLE1BQUEsRUFBUTtVQUNSLElBQUlGLE9BQUEsS0FBVyxPQUFPO1lBQ2xCZ1gsRUFBQSxHQUFLckIsT0FBQSxDQUFRcFgsSUFBQSxDQUFLLEtBQUs4WSxpQkFBQSxFQUFtQkosR0FBRztZQUM3QyxPQUFPRCxFQUFBLEtBQU8sS0FBS0EsRUFBQSxHQUFLO1VBQzVCLE9BQU87WUFDSEEsRUFBQSxHQUFLckIsT0FBQSxDQUFRcFgsSUFBQSxDQUFLLEtBQUs2WSxnQkFBQSxFQUFrQkgsR0FBRztZQUM1QyxPQUFPRCxFQUFBLEtBQU8sS0FBS0EsRUFBQSxHQUFLO1VBQzVCO1FBQ0osT0FBTztVQUNILElBQUloWCxPQUFBLEtBQVcsT0FBTztZQUNsQmdYLEVBQUEsR0FBS3JCLE9BQUEsQ0FBUXBYLElBQUEsQ0FBSyxLQUFLOFksaUJBQUEsRUFBbUJKLEdBQUc7WUFDN0MsSUFBSUQsRUFBQSxLQUFPLElBQUk7Y0FDWCxPQUFPQSxFQUFBO1lBQ1g7WUFDQUEsRUFBQSxHQUFLckIsT0FBQSxDQUFRcFgsSUFBQSxDQUFLLEtBQUs2WSxnQkFBQSxFQUFrQkgsR0FBRztZQUM1QyxPQUFPRCxFQUFBLEtBQU8sS0FBS0EsRUFBQSxHQUFLO1VBQzVCLE9BQU87WUFDSEEsRUFBQSxHQUFLckIsT0FBQSxDQUFRcFgsSUFBQSxDQUFLLEtBQUs2WSxnQkFBQSxFQUFrQkgsR0FBRztZQUM1QyxJQUFJRCxFQUFBLEtBQU8sSUFBSTtjQUNYLE9BQU9BLEVBQUE7WUFDWDtZQUNBQSxFQUFBLEdBQUtyQixPQUFBLENBQVFwWCxJQUFBLENBQUssS0FBSzhZLGlCQUFBLEVBQW1CSixHQUFHO1lBQzdDLE9BQU9ELEVBQUEsS0FBTyxLQUFLQSxFQUFBLEdBQUs7VUFDNUI7UUFDSjtNQUNKO01BRUEsU0FBU00sa0JBQWtCUCxTQUFBLEVBQVcvVyxPQUFBLEVBQVFFLE1BQUEsRUFBUTtRQUNsRCxJQUFJUixDQUFBLEVBQUc2RyxHQUFBLEVBQUtpSyxLQUFBO1FBRVosSUFBSSxLQUFLK0csaUJBQUEsRUFBbUI7VUFDeEIsT0FBT1QsaUJBQUEsQ0FBa0J2WSxJQUFBLENBQUssTUFBTXdZLFNBQUEsRUFBVy9XLE9BQUEsRUFBUUUsTUFBTTtRQUNqRTtRQUVBLElBQUksQ0FBQyxLQUFLaVgsWUFBQSxFQUFjO1VBQ3BCLEtBQUtBLFlBQUEsR0FBZSxFQUFDO1VBQ3JCLEtBQUtDLGdCQUFBLEdBQW1CLEVBQUM7VUFDekIsS0FBS0MsaUJBQUEsR0FBb0IsRUFBQztRQUM5QjtRQUtBLEtBQUszWCxDQUFBLEdBQUksR0FBR0EsQ0FBQSxHQUFJLElBQUlBLENBQUEsSUFBSztVQUVyQjZHLEdBQUEsR0FBTXhHLFNBQUEsQ0FBVSxDQUFDLEtBQU1MLENBQUMsQ0FBQztVQUN6QixJQUFJUSxNQUFBLElBQVUsQ0FBQyxLQUFLa1gsZ0JBQUEsQ0FBaUIxWCxDQUFBLEdBQUk7WUFDckMsS0FBSzBYLGdCQUFBLENBQWlCMVgsQ0FBQSxJQUFLLElBQUk0RixNQUFBLENBQzNCLE1BQU0sS0FBS3NILE1BQUEsQ0FBT3JHLEdBQUEsRUFBSyxFQUFFLEVBQUU2QixPQUFBLENBQVEsS0FBSyxFQUFFLElBQUksS0FDOUMsR0FDSjtZQUNBLEtBQUtpUCxpQkFBQSxDQUFrQjNYLENBQUEsSUFBSyxJQUFJNEYsTUFBQSxDQUM1QixNQUFNLEtBQUt5USxXQUFBLENBQVl4UCxHQUFBLEVBQUssRUFBRSxFQUFFNkIsT0FBQSxDQUFRLEtBQUssRUFBRSxJQUFJLEtBQ25ELEdBQ0o7VUFDSjtVQUNBLElBQUksQ0FBQ2xJLE1BQUEsSUFBVSxDQUFDLEtBQUtpWCxZQUFBLENBQWF6WCxDQUFBLEdBQUk7WUFDbEM4USxLQUFBLEdBQ0ksTUFBTSxLQUFLNUQsTUFBQSxDQUFPckcsR0FBQSxFQUFLLEVBQUUsSUFBSSxPQUFPLEtBQUt3UCxXQUFBLENBQVl4UCxHQUFBLEVBQUssRUFBRTtZQUNoRSxLQUFLNFEsWUFBQSxDQUFhelgsQ0FBQSxJQUFLLElBQUk0RixNQUFBLENBQU9rTCxLQUFBLENBQU1wSSxPQUFBLENBQVEsS0FBSyxFQUFFLEdBQUcsR0FBRztVQUNqRTtVQUVBLElBQ0lsSSxNQUFBLElBQ0FGLE9BQUEsS0FBVyxVQUNYLEtBQUtvWCxnQkFBQSxDQUFpQjFYLENBQUEsRUFBR29KLElBQUEsQ0FBS2lPLFNBQVMsR0FDekM7WUFDRSxPQUFPclgsQ0FBQTtVQUNYLFdBQ0lRLE1BQUEsSUFDQUYsT0FBQSxLQUFXLFNBQ1gsS0FBS3FYLGlCQUFBLENBQWtCM1gsQ0FBQSxFQUFHb0osSUFBQSxDQUFLaU8sU0FBUyxHQUMxQztZQUNFLE9BQU9yWCxDQUFBO1VBQ1gsV0FBVyxDQUFDUSxNQUFBLElBQVUsS0FBS2lYLFlBQUEsQ0FBYXpYLENBQUEsRUFBR29KLElBQUEsQ0FBS2lPLFNBQVMsR0FBRztZQUN4RCxPQUFPclgsQ0FBQTtVQUNYO1FBQ0o7TUFDSjtNQUlBLFNBQVM4WCxTQUFTalIsR0FBQSxFQUFLbUwsS0FBQSxFQUFPO1FBQzFCLElBQUksQ0FBQ25MLEdBQUEsQ0FBSTFFLE9BQUEsQ0FBUSxHQUFHO1VBRWhCLE9BQU8wRSxHQUFBO1FBQ1g7UUFFQSxJQUFJLE9BQU9tTCxLQUFBLEtBQVUsVUFBVTtVQUMzQixJQUFJLFFBQVE1SSxJQUFBLENBQUs0SSxLQUFLLEdBQUc7WUFDckJBLEtBQUEsR0FBUUgsS0FBQSxDQUFNRyxLQUFLO1VBQ3ZCLE9BQU87WUFDSEEsS0FBQSxHQUFRbkwsR0FBQSxDQUFJeUIsVUFBQSxDQUFXLEVBQUVrTyxXQUFBLENBQVl4RSxLQUFLO1lBRTFDLElBQUksQ0FBQ3ZTLFFBQUEsQ0FBU3VTLEtBQUssR0FBRztjQUNsQixPQUFPbkwsR0FBQTtZQUNYO1VBQ0o7UUFDSjtRQUVBLElBQUlzRyxLQUFBLEdBQVE2RSxLQUFBO1VBQ1JqRyxJQUFBLEdBQU9sRixHQUFBLENBQUlrRixJQUFBLENBQUs7UUFFcEJBLElBQUEsR0FBT0EsSUFBQSxHQUFPLEtBQUtBLElBQUEsR0FBT3pFLElBQUEsQ0FBS3lRLEdBQUEsQ0FBSWhNLElBQUEsRUFBTW9LLFdBQUEsQ0FBWXRQLEdBQUEsQ0FBSXdILElBQUEsQ0FBSyxHQUFHbEIsS0FBSyxDQUFDO1FBQ3ZFLE1BQU10RyxHQUFBLENBQUkvQyxNQUFBLEdBQ0orQyxHQUFBLENBQUl0RSxFQUFBLENBQUd5VixXQUFBLENBQVk3SyxLQUFBLEVBQU9wQixJQUFJLElBQzlCbEYsR0FBQSxDQUFJdEUsRUFBQSxDQUFHdVYsUUFBQSxDQUFTM0ssS0FBQSxFQUFPcEIsSUFBSTtRQUNqQyxPQUFPbEYsR0FBQTtNQUNYO01BRUEsU0FBU29SLFlBQVlqRyxLQUFBLEVBQU87UUFDeEIsSUFBSUEsS0FBQSxJQUFTLE1BQU07VUFDZjhGLFFBQUEsQ0FBUyxNQUFNOUYsS0FBSztVQUNwQjlULEtBQUEsQ0FBTWlHLFlBQUEsQ0FBYSxNQUFNLElBQUk7VUFDN0IsT0FBTztRQUNYLE9BQU87VUFDSCxPQUFPeVAsR0FBQSxDQUFJLE1BQU0sT0FBTztRQUM1QjtNQUNKO01BRUEsU0FBU3NFLGVBQUEsRUFBaUI7UUFDdEIsT0FBTy9CLFdBQUEsQ0FBWSxLQUFLOUgsSUFBQSxDQUFLLEdBQUcsS0FBS2xCLEtBQUEsQ0FBTSxDQUFDO01BQ2hEO01BRUEsU0FBU21KLGlCQUFpQnRGLFFBQUEsRUFBVTtRQUNoQyxJQUFJLEtBQUs2RyxpQkFBQSxFQUFtQjtVQUN4QixJQUFJLENBQUM5WSxVQUFBLENBQVcsTUFBTSxjQUFjLEdBQUc7WUFDbkNvWixrQkFBQSxDQUFtQnRaLElBQUEsQ0FBSyxJQUFJO1VBQ2hDO1VBQ0EsSUFBSW1TLFFBQUEsRUFBVTtZQUNWLE9BQU8sS0FBS29ILHVCQUFBO1VBQ2hCLE9BQU87WUFDSCxPQUFPLEtBQUtDLGlCQUFBO1VBQ2hCO1FBQ0osT0FBTztVQUNILElBQUksQ0FBQ3RaLFVBQUEsQ0FBVyxNQUFNLG1CQUFtQixHQUFHO1lBQ3hDLEtBQUtzWixpQkFBQSxHQUFvQnhCLHVCQUFBO1VBQzdCO1VBQ0EsT0FBTyxLQUFLdUIsdUJBQUEsSUFBMkJwSCxRQUFBLEdBQ2pDLEtBQUtvSCx1QkFBQSxHQUNMLEtBQUtDLGlCQUFBO1FBQ2Y7TUFDSjtNQUVBLFNBQVM5QixZQUFZdkYsUUFBQSxFQUFVO1FBQzNCLElBQUksS0FBSzZHLGlCQUFBLEVBQW1CO1VBQ3hCLElBQUksQ0FBQzlZLFVBQUEsQ0FBVyxNQUFNLGNBQWMsR0FBRztZQUNuQ29aLGtCQUFBLENBQW1CdFosSUFBQSxDQUFLLElBQUk7VUFDaEM7VUFDQSxJQUFJbVMsUUFBQSxFQUFVO1lBQ1YsT0FBTyxLQUFLc0gsa0JBQUE7VUFDaEIsT0FBTztZQUNILE9BQU8sS0FBS0MsWUFBQTtVQUNoQjtRQUNKLE9BQU87VUFDSCxJQUFJLENBQUN4WixVQUFBLENBQVcsTUFBTSxjQUFjLEdBQUc7WUFDbkMsS0FBS3daLFlBQUEsR0FBZXpCLGtCQUFBO1VBQ3hCO1VBQ0EsT0FBTyxLQUFLd0Isa0JBQUEsSUFBc0J0SCxRQUFBLEdBQzVCLEtBQUtzSCxrQkFBQSxHQUNMLEtBQUtDLFlBQUE7UUFDZjtNQUNKO01BRUEsU0FBU0osbUJBQUEsRUFBcUI7UUFDMUIsU0FBU0ssVUFBVXhaLENBQUEsRUFBR0MsQ0FBQSxFQUFHO1VBQ3JCLE9BQU9BLENBQUEsQ0FBRUssTUFBQSxHQUFTTixDQUFBLENBQUVNLE1BQUE7UUFDeEI7UUFFQSxJQUFJbVosV0FBQSxHQUFjLEVBQUM7VUFDZkMsVUFBQSxHQUFhLEVBQUM7VUFDZEMsV0FBQSxHQUFjLEVBQUM7VUFDZjNZLENBQUE7VUFDQTZHLEdBQUE7VUFDQStSLE1BQUE7VUFDQUMsS0FBQTtRQUNKLEtBQUs3WSxDQUFBLEdBQUksR0FBR0EsQ0FBQSxHQUFJLElBQUlBLENBQUEsSUFBSztVQUVyQjZHLEdBQUEsR0FBTXhHLFNBQUEsQ0FBVSxDQUFDLEtBQU1MLENBQUMsQ0FBQztVQUN6QjRZLE1BQUEsR0FBU3hILFdBQUEsQ0FBWSxLQUFLaUYsV0FBQSxDQUFZeFAsR0FBQSxFQUFLLEVBQUUsQ0FBQztVQUM5Q2dTLEtBQUEsR0FBUXpILFdBQUEsQ0FBWSxLQUFLbEUsTUFBQSxDQUFPckcsR0FBQSxFQUFLLEVBQUUsQ0FBQztVQUN4QzRSLFdBQUEsQ0FBWXZZLElBQUEsQ0FBSzBZLE1BQU07VUFDdkJGLFVBQUEsQ0FBV3hZLElBQUEsQ0FBSzJZLEtBQUs7VUFDckJGLFdBQUEsQ0FBWXpZLElBQUEsQ0FBSzJZLEtBQUs7VUFDdEJGLFdBQUEsQ0FBWXpZLElBQUEsQ0FBSzBZLE1BQU07UUFDM0I7UUFHQUgsV0FBQSxDQUFZakosSUFBQSxDQUFLZ0osU0FBUztRQUMxQkUsVUFBQSxDQUFXbEosSUFBQSxDQUFLZ0osU0FBUztRQUN6QkcsV0FBQSxDQUFZbkosSUFBQSxDQUFLZ0osU0FBUztRQUUxQixLQUFLRCxZQUFBLEdBQWUsSUFBSTNTLE1BQUEsQ0FBTyxPQUFPK1MsV0FBQSxDQUFZMVQsSUFBQSxDQUFLLEdBQUcsSUFBSSxLQUFLLEdBQUc7UUFDdEUsS0FBS29ULGlCQUFBLEdBQW9CLEtBQUtFLFlBQUE7UUFDOUIsS0FBS0Qsa0JBQUEsR0FBcUIsSUFBSTFTLE1BQUEsQ0FDMUIsT0FBTzhTLFVBQUEsQ0FBV3pULElBQUEsQ0FBSyxHQUFHLElBQUksS0FDOUIsR0FDSjtRQUNBLEtBQUttVCx1QkFBQSxHQUEwQixJQUFJeFMsTUFBQSxDQUMvQixPQUFPNlMsV0FBQSxDQUFZeFQsSUFBQSxDQUFLLEdBQUcsSUFBSSxLQUMvQixHQUNKO01BQ0o7TUFFQSxTQUFTNlQsV0FBVzNOLENBQUEsRUFBR3RKLENBQUEsRUFBR2dKLENBQUEsRUFBR0YsQ0FBQSxFQUFHTSxDQUFBLEVBQUdULENBQUEsRUFBR3FDLEVBQUEsRUFBSTtRQUd0QyxJQUFJZCxJQUFBO1FBRUosSUFBSVosQ0FBQSxHQUFJLE9BQU9BLENBQUEsSUFBSyxHQUFHO1VBRW5CWSxJQUFBLEdBQU8sSUFBSXBNLElBQUEsQ0FBS3dMLENBQUEsR0FBSSxLQUFLdEosQ0FBQSxFQUFHZ0osQ0FBQSxFQUFHRixDQUFBLEVBQUdNLENBQUEsRUFBR1QsQ0FBQSxFQUFHcUMsRUFBRTtVQUMxQyxJQUFJb0YsUUFBQSxDQUFTbEcsSUFBQSxDQUFLOEksV0FBQSxDQUFZLENBQUMsR0FBRztZQUM5QjlJLElBQUEsQ0FBSzBKLFdBQUEsQ0FBWXRLLENBQUM7VUFDdEI7UUFDSixPQUFPO1VBQ0hZLElBQUEsR0FBTyxJQUFJcE0sSUFBQSxDQUFLd0wsQ0FBQSxFQUFHdEosQ0FBQSxFQUFHZ0osQ0FBQSxFQUFHRixDQUFBLEVBQUdNLENBQUEsRUFBR1QsQ0FBQSxFQUFHcUMsRUFBRTtRQUN4QztRQUVBLE9BQU9kLElBQUE7TUFDWDtNQUVBLFNBQVNnTixjQUFjNU4sQ0FBQSxFQUFHO1FBQ3RCLElBQUlZLElBQUEsRUFBTW5ILElBQUE7UUFFVixJQUFJdUcsQ0FBQSxHQUFJLE9BQU9BLENBQUEsSUFBSyxHQUFHO1VBQ25CdkcsSUFBQSxHQUFPbkcsS0FBQSxDQUFNRSxTQUFBLENBQVVxRyxLQUFBLENBQU1uRyxJQUFBLENBQUtULFNBQVM7VUFFM0N3RyxJQUFBLENBQUssS0FBS3VHLENBQUEsR0FBSTtVQUNkWSxJQUFBLEdBQU8sSUFBSXBNLElBQUEsQ0FBS0EsSUFBQSxDQUFLcVosR0FBQSxDQUFJN2EsS0FBQSxDQUFNLE1BQU15RyxJQUFJLENBQUM7VUFDMUMsSUFBSXFOLFFBQUEsQ0FBU2xHLElBQUEsQ0FBSzZJLGNBQUEsQ0FBZSxDQUFDLEdBQUc7WUFDakM3SSxJQUFBLENBQUt5SixjQUFBLENBQWVySyxDQUFDO1VBQ3pCO1FBQ0osT0FBTztVQUNIWSxJQUFBLEdBQU8sSUFBSXBNLElBQUEsQ0FBS0EsSUFBQSxDQUFLcVosR0FBQSxDQUFJN2EsS0FBQSxDQUFNLE1BQU1DLFNBQVMsQ0FBQztRQUNuRDtRQUVBLE9BQU8yTixJQUFBO01BQ1g7TUFHQSxTQUFTa04sZ0JBQWdCNUssSUFBQSxFQUFNNkssR0FBQSxFQUFLQyxHQUFBLEVBQUs7UUFDckMsSUFDSUMsR0FBQSxHQUFNLElBQUlGLEdBQUEsR0FBTUMsR0FBQTtVQUVoQkUsS0FBQSxJQUFTLElBQUlOLGFBQUEsQ0FBYzFLLElBQUEsRUFBTSxHQUFHK0ssR0FBRyxFQUFFNUUsU0FBQSxDQUFVLElBQUkwRSxHQUFBLElBQU87UUFFbEUsT0FBTyxDQUFDRyxLQUFBLEdBQVFELEdBQUEsR0FBTTtNQUMxQjtNQUdBLFNBQVNFLG1CQUFtQmpMLElBQUEsRUFBTUwsSUFBQSxFQUFNNUIsT0FBQSxFQUFTOE0sR0FBQSxFQUFLQyxHQUFBLEVBQUs7UUFDdkQsSUFBSUksWUFBQSxJQUFnQixJQUFJbk4sT0FBQSxHQUFVOE0sR0FBQSxJQUFPO1VBQ3JDTSxVQUFBLEdBQWFQLGVBQUEsQ0FBZ0I1SyxJQUFBLEVBQU02SyxHQUFBLEVBQUtDLEdBQUc7VUFDM0NwSyxTQUFBLEdBQVksSUFBSSxLQUFLZixJQUFBLEdBQU8sS0FBS3VMLFlBQUEsR0FBZUMsVUFBQTtVQUNoREMsT0FBQTtVQUNBQyxZQUFBO1FBRUosSUFBSTNLLFNBQUEsSUFBYSxHQUFHO1VBQ2hCMEssT0FBQSxHQUFVcEwsSUFBQSxHQUFPO1VBQ2pCcUwsWUFBQSxHQUFlcEcsVUFBQSxDQUFXbUcsT0FBTyxJQUFJMUssU0FBQTtRQUN6QyxXQUFXQSxTQUFBLEdBQVl1RSxVQUFBLENBQVdqRixJQUFJLEdBQUc7VUFDckNvTCxPQUFBLEdBQVVwTCxJQUFBLEdBQU87VUFDakJxTCxZQUFBLEdBQWUzSyxTQUFBLEdBQVl1RSxVQUFBLENBQVdqRixJQUFJO1FBQzlDLE9BQU87VUFDSG9MLE9BQUEsR0FBVXBMLElBQUE7VUFDVnFMLFlBQUEsR0FBZTNLLFNBQUE7UUFDbkI7UUFFQSxPQUFPO1VBQ0hWLElBQUEsRUFBTW9MLE9BQUE7VUFDTjFLLFNBQUEsRUFBVzJLO1FBQ2Y7TUFDSjtNQUVBLFNBQVNDLFdBQVc5UyxHQUFBLEVBQUtxUyxHQUFBLEVBQUtDLEdBQUEsRUFBSztRQUMvQixJQUFJSyxVQUFBLEdBQWFQLGVBQUEsQ0FBZ0JwUyxHQUFBLENBQUl3SCxJQUFBLENBQUssR0FBRzZLLEdBQUEsRUFBS0MsR0FBRztVQUNqRG5MLElBQUEsR0FBTzFHLElBQUEsQ0FBS3NLLEtBQUEsRUFBTy9LLEdBQUEsQ0FBSWtJLFNBQUEsQ0FBVSxJQUFJeUssVUFBQSxHQUFhLEtBQUssQ0FBQyxJQUFJO1VBQzVESSxPQUFBO1VBQ0FILE9BQUE7UUFFSixJQUFJekwsSUFBQSxHQUFPLEdBQUc7VUFDVnlMLE9BQUEsR0FBVTVTLEdBQUEsQ0FBSXdILElBQUEsQ0FBSyxJQUFJO1VBQ3ZCdUwsT0FBQSxHQUFVNUwsSUFBQSxHQUFPNkwsV0FBQSxDQUFZSixPQUFBLEVBQVNQLEdBQUEsRUFBS0MsR0FBRztRQUNsRCxXQUFXbkwsSUFBQSxHQUFPNkwsV0FBQSxDQUFZaFQsR0FBQSxDQUFJd0gsSUFBQSxDQUFLLEdBQUc2SyxHQUFBLEVBQUtDLEdBQUcsR0FBRztVQUNqRFMsT0FBQSxHQUFVNUwsSUFBQSxHQUFPNkwsV0FBQSxDQUFZaFQsR0FBQSxDQUFJd0gsSUFBQSxDQUFLLEdBQUc2SyxHQUFBLEVBQUtDLEdBQUc7VUFDakRNLE9BQUEsR0FBVTVTLEdBQUEsQ0FBSXdILElBQUEsQ0FBSyxJQUFJO1FBQzNCLE9BQU87VUFDSG9MLE9BQUEsR0FBVTVTLEdBQUEsQ0FBSXdILElBQUEsQ0FBSztVQUNuQnVMLE9BQUEsR0FBVTVMLElBQUE7UUFDZDtRQUVBLE9BQU87VUFDSEEsSUFBQSxFQUFNNEwsT0FBQTtVQUNOdkwsSUFBQSxFQUFNb0w7UUFDVjtNQUNKO01BRUEsU0FBU0ksWUFBWXhMLElBQUEsRUFBTTZLLEdBQUEsRUFBS0MsR0FBQSxFQUFLO1FBQ2pDLElBQUlLLFVBQUEsR0FBYVAsZUFBQSxDQUFnQjVLLElBQUEsRUFBTTZLLEdBQUEsRUFBS0MsR0FBRztVQUMzQ1csY0FBQSxHQUFpQmIsZUFBQSxDQUFnQjVLLElBQUEsR0FBTyxHQUFHNkssR0FBQSxFQUFLQyxHQUFHO1FBQ3ZELFFBQVE3RixVQUFBLENBQVdqRixJQUFJLElBQUltTCxVQUFBLEdBQWFNLGNBQUEsSUFBa0I7TUFDOUQ7TUFJQTdSLGNBQUEsQ0FBZSxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsTUFBTSxNQUFNO01BQzNDQSxjQUFBLENBQWUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLE1BQU0sU0FBUztNQUk5QzRJLGFBQUEsQ0FBYyxLQUFLZixTQUFBLEVBQVdZLHNCQUFzQjtNQUNwREcsYUFBQSxDQUFjLE1BQU1mLFNBQUEsRUFBV0osTUFBTTtNQUNyQ21CLGFBQUEsQ0FBYyxLQUFLZixTQUFBLEVBQVdZLHNCQUFzQjtNQUNwREcsYUFBQSxDQUFjLE1BQU1mLFNBQUEsRUFBV0osTUFBTTtNQUVyQzJDLGlCQUFBLENBQ0ksQ0FBQyxLQUFLLE1BQU0sS0FBSyxJQUFJLEdBQ3JCLFVBQVU3VCxLQUFBLEVBQU93UCxJQUFBLEVBQU05SixNQUFBLEVBQVFnRSxNQUFBLEVBQU87UUFDbEM4RixJQUFBLENBQUs5RixNQUFBLENBQU1OLE1BQUEsQ0FBTyxHQUFHLENBQUMsS0FBS2lLLEtBQUEsQ0FBTXJULEtBQUs7TUFDMUMsQ0FDSjtNQU1BLFNBQVN1YixXQUFXbFQsR0FBQSxFQUFLO1FBQ3JCLE9BQU84UyxVQUFBLENBQVc5UyxHQUFBLEVBQUssS0FBS21ULEtBQUEsQ0FBTWQsR0FBQSxFQUFLLEtBQUtjLEtBQUEsQ0FBTWIsR0FBRyxFQUFFbkwsSUFBQTtNQUMzRDtNQUVBLElBQUlpTSxpQkFBQSxHQUFvQjtRQUNwQmYsR0FBQSxFQUFLO1FBQ0xDLEdBQUEsRUFBSztNQUNUO01BRUEsU0FBU2UscUJBQUEsRUFBdUI7UUFDNUIsT0FBTyxLQUFLRixLQUFBLENBQU1kLEdBQUE7TUFDdEI7TUFFQSxTQUFTaUIscUJBQUEsRUFBdUI7UUFDNUIsT0FBTyxLQUFLSCxLQUFBLENBQU1iLEdBQUE7TUFDdEI7TUFJQSxTQUFTaUIsV0FBVzViLEtBQUEsRUFBTztRQUN2QixJQUFJd1AsSUFBQSxHQUFPLEtBQUsxRixVQUFBLENBQVcsRUFBRTBGLElBQUEsQ0FBSyxJQUFJO1FBQ3RDLE9BQU94UCxLQUFBLElBQVMsT0FBT3dQLElBQUEsR0FBTyxLQUFLcU0sR0FBQSxFQUFLN2IsS0FBQSxHQUFRd1AsSUFBQSxJQUFRLEdBQUcsR0FBRztNQUNsRTtNQUVBLFNBQVNzTSxjQUFjOWIsS0FBQSxFQUFPO1FBQzFCLElBQUl3UCxJQUFBLEdBQU8yTCxVQUFBLENBQVcsTUFBTSxHQUFHLENBQUMsRUFBRTNMLElBQUE7UUFDbEMsT0FBT3hQLEtBQUEsSUFBUyxPQUFPd1AsSUFBQSxHQUFPLEtBQUtxTSxHQUFBLEVBQUs3YixLQUFBLEdBQVF3UCxJQUFBLElBQVEsR0FBRyxHQUFHO01BQ2xFO01BSUEvRixjQUFBLENBQWUsS0FBSyxHQUFHLE1BQU0sS0FBSztNQUVsQ0EsY0FBQSxDQUFlLE1BQU0sR0FBRyxHQUFHLFVBQVUzSCxPQUFBLEVBQVE7UUFDekMsT0FBTyxLQUFLZ0ksVUFBQSxDQUFXLEVBQUVpUyxXQUFBLENBQVksTUFBTWphLE9BQU07TUFDckQsQ0FBQztNQUVEMkgsY0FBQSxDQUFlLE9BQU8sR0FBRyxHQUFHLFVBQVUzSCxPQUFBLEVBQVE7UUFDMUMsT0FBTyxLQUFLZ0ksVUFBQSxDQUFXLEVBQUVrUyxhQUFBLENBQWMsTUFBTWxhLE9BQU07TUFDdkQsQ0FBQztNQUVEMkgsY0FBQSxDQUFlLFFBQVEsR0FBRyxHQUFHLFVBQVUzSCxPQUFBLEVBQVE7UUFDM0MsT0FBTyxLQUFLZ0ksVUFBQSxDQUFXLEVBQUU2RCxRQUFBLENBQVMsTUFBTTdMLE9BQU07TUFDbEQsQ0FBQztNQUVEMkgsY0FBQSxDQUFlLEtBQUssR0FBRyxHQUFHLFNBQVM7TUFDbkNBLGNBQUEsQ0FBZSxLQUFLLEdBQUcsR0FBRyxZQUFZO01BSXRDNEksYUFBQSxDQUFjLEtBQUtmLFNBQVM7TUFDNUJlLGFBQUEsQ0FBYyxLQUFLZixTQUFTO01BQzVCZSxhQUFBLENBQWMsS0FBS2YsU0FBUztNQUM1QmUsYUFBQSxDQUFjLE1BQU0sVUFBVUcsUUFBQSxFQUFVelEsT0FBQSxFQUFRO1FBQzVDLE9BQU9BLE9BQUEsQ0FBT2thLGdCQUFBLENBQWlCekosUUFBUTtNQUMzQyxDQUFDO01BQ0RILGFBQUEsQ0FBYyxPQUFPLFVBQVVHLFFBQUEsRUFBVXpRLE9BQUEsRUFBUTtRQUM3QyxPQUFPQSxPQUFBLENBQU9tYSxrQkFBQSxDQUFtQjFKLFFBQVE7TUFDN0MsQ0FBQztNQUNESCxhQUFBLENBQWMsUUFBUSxVQUFVRyxRQUFBLEVBQVV6USxPQUFBLEVBQVE7UUFDOUMsT0FBT0EsT0FBQSxDQUFPb2EsYUFBQSxDQUFjM0osUUFBUTtNQUN4QyxDQUFDO01BRURxQixpQkFBQSxDQUFrQixDQUFDLE1BQU0sT0FBTyxNQUFNLEdBQUcsVUFBVTdULEtBQUEsRUFBT3dQLElBQUEsRUFBTTlKLE1BQUEsRUFBUWdFLE1BQUEsRUFBTztRQUMzRSxJQUFJa0UsT0FBQSxHQUFVbEksTUFBQSxDQUFPRixPQUFBLENBQVE0VyxhQUFBLENBQWNwYyxLQUFBLEVBQU8wSixNQUFBLEVBQU9oRSxNQUFBLENBQU92QixPQUFPO1FBRXZFLElBQUl5SixPQUFBLElBQVcsTUFBTTtVQUNqQjRCLElBQUEsQ0FBS25ELENBQUEsR0FBSXVCLE9BQUE7UUFDYixPQUFPO1VBQ0h4SyxlQUFBLENBQWdCc0MsTUFBTSxFQUFFeEIsY0FBQSxHQUFpQmxFLEtBQUE7UUFDN0M7TUFDSixDQUFDO01BRUQ2VCxpQkFBQSxDQUFrQixDQUFDLEtBQUssS0FBSyxHQUFHLEdBQUcsVUFBVTdULEtBQUEsRUFBT3dQLElBQUEsRUFBTTlKLE1BQUEsRUFBUWdFLE1BQUEsRUFBTztRQUNyRThGLElBQUEsQ0FBSzlGLE1BQUEsSUFBUzJKLEtBQUEsQ0FBTXJULEtBQUs7TUFDN0IsQ0FBQztNQUlELFNBQVNxYyxhQUFhcmMsS0FBQSxFQUFPK0IsT0FBQSxFQUFRO1FBQ2pDLElBQUksT0FBTy9CLEtBQUEsS0FBVSxVQUFVO1VBQzNCLE9BQU9BLEtBQUE7UUFDWDtRQUVBLElBQUksQ0FBQ2dFLEtBQUEsQ0FBTWhFLEtBQUssR0FBRztVQUNmLE9BQU82VSxRQUFBLENBQVM3VSxLQUFBLEVBQU8sRUFBRTtRQUM3QjtRQUVBQSxLQUFBLEdBQVErQixPQUFBLENBQU9xYSxhQUFBLENBQWNwYyxLQUFLO1FBQ2xDLElBQUksT0FBT0EsS0FBQSxLQUFVLFVBQVU7VUFDM0IsT0FBT0EsS0FBQTtRQUNYO1FBRUEsT0FBTztNQUNYO01BRUEsU0FBU3NjLGdCQUFnQnRjLEtBQUEsRUFBTytCLE9BQUEsRUFBUTtRQUNwQyxJQUFJLE9BQU8vQixLQUFBLEtBQVUsVUFBVTtVQUMzQixPQUFPK0IsT0FBQSxDQUFPcWEsYUFBQSxDQUFjcGMsS0FBSyxJQUFJLEtBQUs7UUFDOUM7UUFDQSxPQUFPZ0UsS0FBQSxDQUFNaEUsS0FBSyxJQUFJLE9BQU9BLEtBQUE7TUFDakM7TUFHQSxTQUFTdWMsY0FBY0MsRUFBQSxFQUFJakYsQ0FBQSxFQUFHO1FBQzFCLE9BQU9pRixFQUFBLENBQUdoVyxLQUFBLENBQU0rUSxDQUFBLEVBQUcsQ0FBQyxFQUFFa0YsTUFBQSxDQUFPRCxFQUFBLENBQUdoVyxLQUFBLENBQU0sR0FBRytRLENBQUMsQ0FBQztNQUMvQztNQUVBLElBQUltRixxQkFBQSxHQUNJLDJEQUEyRHhFLEtBQUEsQ0FBTSxHQUFHO1FBQ3hFeUUsMEJBQUEsR0FBNkIsOEJBQThCekUsS0FBQSxDQUFNLEdBQUc7UUFDcEUwRSx3QkFBQSxHQUEyQix1QkFBdUIxRSxLQUFBLENBQU0sR0FBRztRQUMzRDJFLG9CQUFBLEdBQXVCNUssU0FBQTtRQUN2QjZLLHlCQUFBLEdBQTRCN0ssU0FBQTtRQUM1QjhLLHVCQUFBLEdBQTBCOUssU0FBQTtNQUU5QixTQUFTK0ssZUFBZTNaLENBQUEsRUFBR3ZCLE9BQUEsRUFBUTtRQUMvQixJQUFJNkwsUUFBQSxHQUFXNU4sT0FBQSxDQUFRLEtBQUtrZCxTQUFTLElBQy9CLEtBQUtBLFNBQUEsR0FDTCxLQUFLQSxTQUFBLENBQ0Q1WixDQUFBLElBQUtBLENBQUEsS0FBTSxRQUFRLEtBQUs0WixTQUFBLENBQVV4RSxRQUFBLENBQVM3TixJQUFBLENBQUs5SSxPQUFNLElBQ2hELFdBQ0E7UUFFaEIsT0FBT3VCLENBQUEsS0FBTSxPQUNQa1osYUFBQSxDQUFjNU8sUUFBQSxFQUFVLEtBQUs2TixLQUFBLENBQU1kLEdBQUcsSUFDdENyWCxDQUFBLEdBQ0VzSyxRQUFBLENBQVN0SyxDQUFBLENBQUVvSyxHQUFBLENBQUksS0FDZkUsUUFBQTtNQUNaO01BRUEsU0FBU3VQLG9CQUFvQjdaLENBQUEsRUFBRztRQUM1QixPQUFPQSxDQUFBLEtBQU0sT0FDUGtaLGFBQUEsQ0FBYyxLQUFLWSxjQUFBLEVBQWdCLEtBQUszQixLQUFBLENBQU1kLEdBQUcsSUFDakRyWCxDQUFBLEdBQ0UsS0FBSzhaLGNBQUEsQ0FBZTlaLENBQUEsQ0FBRW9LLEdBQUEsQ0FBSSxLQUMxQixLQUFLMFAsY0FBQTtNQUNqQjtNQUVBLFNBQVNDLGtCQUFrQi9aLENBQUEsRUFBRztRQUMxQixPQUFPQSxDQUFBLEtBQU0sT0FDUGtaLGFBQUEsQ0FBYyxLQUFLYyxZQUFBLEVBQWMsS0FBSzdCLEtBQUEsQ0FBTWQsR0FBRyxJQUMvQ3JYLENBQUEsR0FDRSxLQUFLZ2EsWUFBQSxDQUFhaGEsQ0FBQSxDQUFFb0ssR0FBQSxDQUFJLEtBQ3hCLEtBQUs0UCxZQUFBO01BQ2pCO01BRUEsU0FBU0Msb0JBQW9CQyxXQUFBLEVBQWF6YixPQUFBLEVBQVFFLE1BQUEsRUFBUTtRQUN0RCxJQUFJUixDQUFBO1VBQ0FzWCxFQUFBO1VBQ0F6USxHQUFBO1VBQ0EwUSxHQUFBLEdBQU13RSxXQUFBLENBQVl2RSxpQkFBQSxDQUFrQjtRQUN4QyxJQUFJLENBQUMsS0FBS3dFLGNBQUEsRUFBZ0I7VUFDdEIsS0FBS0EsY0FBQSxHQUFpQixFQUFDO1VBQ3ZCLEtBQUtDLG1CQUFBLEdBQXNCLEVBQUM7VUFDNUIsS0FBS0MsaUJBQUEsR0FBb0IsRUFBQztVQUUxQixLQUFLbGMsQ0FBQSxHQUFJLEdBQUdBLENBQUEsR0FBSSxHQUFHLEVBQUVBLENBQUEsRUFBRztZQUNwQjZHLEdBQUEsR0FBTXhHLFNBQUEsQ0FBVSxDQUFDLEtBQU0sQ0FBQyxDQUFDLEVBQUU0TCxHQUFBLENBQUlqTSxDQUFDO1lBQ2hDLEtBQUtrYyxpQkFBQSxDQUFrQmxjLENBQUEsSUFBSyxLQUFLdWEsV0FBQSxDQUM3QjFULEdBQUEsRUFDQSxFQUNKLEVBQUUyUSxpQkFBQSxDQUFrQjtZQUNwQixLQUFLeUUsbUJBQUEsQ0FBb0JqYyxDQUFBLElBQUssS0FBS3dhLGFBQUEsQ0FDL0IzVCxHQUFBLEVBQ0EsRUFDSixFQUFFMlEsaUJBQUEsQ0FBa0I7WUFDcEIsS0FBS3dFLGNBQUEsQ0FBZWhjLENBQUEsSUFBSyxLQUFLbU0sUUFBQSxDQUFTdEYsR0FBQSxFQUFLLEVBQUUsRUFBRTJRLGlCQUFBLENBQWtCO1VBQ3RFO1FBQ0o7UUFFQSxJQUFJaFgsTUFBQSxFQUFRO1VBQ1IsSUFBSUYsT0FBQSxLQUFXLFFBQVE7WUFDbkJnWCxFQUFBLEdBQUtyQixPQUFBLENBQVFwWCxJQUFBLENBQUssS0FBS21kLGNBQUEsRUFBZ0J6RSxHQUFHO1lBQzFDLE9BQU9ELEVBQUEsS0FBTyxLQUFLQSxFQUFBLEdBQUs7VUFDNUIsV0FBV2hYLE9BQUEsS0FBVyxPQUFPO1lBQ3pCZ1gsRUFBQSxHQUFLckIsT0FBQSxDQUFRcFgsSUFBQSxDQUFLLEtBQUtvZCxtQkFBQSxFQUFxQjFFLEdBQUc7WUFDL0MsT0FBT0QsRUFBQSxLQUFPLEtBQUtBLEVBQUEsR0FBSztVQUM1QixPQUFPO1lBQ0hBLEVBQUEsR0FBS3JCLE9BQUEsQ0FBUXBYLElBQUEsQ0FBSyxLQUFLcWQsaUJBQUEsRUFBbUIzRSxHQUFHO1lBQzdDLE9BQU9ELEVBQUEsS0FBTyxLQUFLQSxFQUFBLEdBQUs7VUFDNUI7UUFDSixPQUFPO1VBQ0gsSUFBSWhYLE9BQUEsS0FBVyxRQUFRO1lBQ25CZ1gsRUFBQSxHQUFLckIsT0FBQSxDQUFRcFgsSUFBQSxDQUFLLEtBQUttZCxjQUFBLEVBQWdCekUsR0FBRztZQUMxQyxJQUFJRCxFQUFBLEtBQU8sSUFBSTtjQUNYLE9BQU9BLEVBQUE7WUFDWDtZQUNBQSxFQUFBLEdBQUtyQixPQUFBLENBQVFwWCxJQUFBLENBQUssS0FBS29kLG1CQUFBLEVBQXFCMUUsR0FBRztZQUMvQyxJQUFJRCxFQUFBLEtBQU8sSUFBSTtjQUNYLE9BQU9BLEVBQUE7WUFDWDtZQUNBQSxFQUFBLEdBQUtyQixPQUFBLENBQVFwWCxJQUFBLENBQUssS0FBS3FkLGlCQUFBLEVBQW1CM0UsR0FBRztZQUM3QyxPQUFPRCxFQUFBLEtBQU8sS0FBS0EsRUFBQSxHQUFLO1VBQzVCLFdBQVdoWCxPQUFBLEtBQVcsT0FBTztZQUN6QmdYLEVBQUEsR0FBS3JCLE9BQUEsQ0FBUXBYLElBQUEsQ0FBSyxLQUFLb2QsbUJBQUEsRUFBcUIxRSxHQUFHO1lBQy9DLElBQUlELEVBQUEsS0FBTyxJQUFJO2NBQ1gsT0FBT0EsRUFBQTtZQUNYO1lBQ0FBLEVBQUEsR0FBS3JCLE9BQUEsQ0FBUXBYLElBQUEsQ0FBSyxLQUFLbWQsY0FBQSxFQUFnQnpFLEdBQUc7WUFDMUMsSUFBSUQsRUFBQSxLQUFPLElBQUk7Y0FDWCxPQUFPQSxFQUFBO1lBQ1g7WUFDQUEsRUFBQSxHQUFLckIsT0FBQSxDQUFRcFgsSUFBQSxDQUFLLEtBQUtxZCxpQkFBQSxFQUFtQjNFLEdBQUc7WUFDN0MsT0FBT0QsRUFBQSxLQUFPLEtBQUtBLEVBQUEsR0FBSztVQUM1QixPQUFPO1lBQ0hBLEVBQUEsR0FBS3JCLE9BQUEsQ0FBUXBYLElBQUEsQ0FBSyxLQUFLcWQsaUJBQUEsRUFBbUIzRSxHQUFHO1lBQzdDLElBQUlELEVBQUEsS0FBTyxJQUFJO2NBQ1gsT0FBT0EsRUFBQTtZQUNYO1lBQ0FBLEVBQUEsR0FBS3JCLE9BQUEsQ0FBUXBYLElBQUEsQ0FBSyxLQUFLbWQsY0FBQSxFQUFnQnpFLEdBQUc7WUFDMUMsSUFBSUQsRUFBQSxLQUFPLElBQUk7Y0FDWCxPQUFPQSxFQUFBO1lBQ1g7WUFDQUEsRUFBQSxHQUFLckIsT0FBQSxDQUFRcFgsSUFBQSxDQUFLLEtBQUtvZCxtQkFBQSxFQUFxQjFFLEdBQUc7WUFDL0MsT0FBT0QsRUFBQSxLQUFPLEtBQUtBLEVBQUEsR0FBSztVQUM1QjtRQUNKO01BQ0o7TUFFQSxTQUFTNkUsb0JBQW9CSixXQUFBLEVBQWF6YixPQUFBLEVBQVFFLE1BQUEsRUFBUTtRQUN0RCxJQUFJUixDQUFBLEVBQUc2RyxHQUFBLEVBQUtpSyxLQUFBO1FBRVosSUFBSSxLQUFLc0wsbUJBQUEsRUFBcUI7VUFDMUIsT0FBT04sbUJBQUEsQ0FBb0JqZCxJQUFBLENBQUssTUFBTWtkLFdBQUEsRUFBYXpiLE9BQUEsRUFBUUUsTUFBTTtRQUNyRTtRQUVBLElBQUksQ0FBQyxLQUFLd2IsY0FBQSxFQUFnQjtVQUN0QixLQUFLQSxjQUFBLEdBQWlCLEVBQUM7VUFDdkIsS0FBS0UsaUJBQUEsR0FBb0IsRUFBQztVQUMxQixLQUFLRCxtQkFBQSxHQUFzQixFQUFDO1VBQzVCLEtBQUtJLGtCQUFBLEdBQXFCLEVBQUM7UUFDL0I7UUFFQSxLQUFLcmMsQ0FBQSxHQUFJLEdBQUdBLENBQUEsR0FBSSxHQUFHQSxDQUFBLElBQUs7VUFHcEI2RyxHQUFBLEdBQU14RyxTQUFBLENBQVUsQ0FBQyxLQUFNLENBQUMsQ0FBQyxFQUFFNEwsR0FBQSxDQUFJak0sQ0FBQztVQUNoQyxJQUFJUSxNQUFBLElBQVUsQ0FBQyxLQUFLNmIsa0JBQUEsQ0FBbUJyYyxDQUFBLEdBQUk7WUFDdkMsS0FBS3FjLGtCQUFBLENBQW1CcmMsQ0FBQSxJQUFLLElBQUk0RixNQUFBLENBQzdCLE1BQU0sS0FBS3VHLFFBQUEsQ0FBU3RGLEdBQUEsRUFBSyxFQUFFLEVBQUU2QixPQUFBLENBQVEsS0FBSyxNQUFNLElBQUksS0FDcEQsR0FDSjtZQUNBLEtBQUt1VCxtQkFBQSxDQUFvQmpjLENBQUEsSUFBSyxJQUFJNEYsTUFBQSxDQUM5QixNQUFNLEtBQUs0VSxhQUFBLENBQWMzVCxHQUFBLEVBQUssRUFBRSxFQUFFNkIsT0FBQSxDQUFRLEtBQUssTUFBTSxJQUFJLEtBQ3pELEdBQ0o7WUFDQSxLQUFLd1QsaUJBQUEsQ0FBa0JsYyxDQUFBLElBQUssSUFBSTRGLE1BQUEsQ0FDNUIsTUFBTSxLQUFLMlUsV0FBQSxDQUFZMVQsR0FBQSxFQUFLLEVBQUUsRUFBRTZCLE9BQUEsQ0FBUSxLQUFLLE1BQU0sSUFBSSxLQUN2RCxHQUNKO1VBQ0o7VUFDQSxJQUFJLENBQUMsS0FBS3NULGNBQUEsQ0FBZWhjLENBQUEsR0FBSTtZQUN6QjhRLEtBQUEsR0FDSSxNQUNBLEtBQUszRSxRQUFBLENBQVN0RixHQUFBLEVBQUssRUFBRSxJQUNyQixPQUNBLEtBQUsyVCxhQUFBLENBQWMzVCxHQUFBLEVBQUssRUFBRSxJQUMxQixPQUNBLEtBQUswVCxXQUFBLENBQVkxVCxHQUFBLEVBQUssRUFBRTtZQUM1QixLQUFLbVYsY0FBQSxDQUFlaGMsQ0FBQSxJQUFLLElBQUk0RixNQUFBLENBQU9rTCxLQUFBLENBQU1wSSxPQUFBLENBQVEsS0FBSyxFQUFFLEdBQUcsR0FBRztVQUNuRTtVQUVBLElBQ0lsSSxNQUFBLElBQ0FGLE9BQUEsS0FBVyxVQUNYLEtBQUsrYixrQkFBQSxDQUFtQnJjLENBQUEsRUFBR29KLElBQUEsQ0FBSzJTLFdBQVcsR0FDN0M7WUFDRSxPQUFPL2IsQ0FBQTtVQUNYLFdBQ0lRLE1BQUEsSUFDQUYsT0FBQSxLQUFXLFNBQ1gsS0FBSzJiLG1CQUFBLENBQW9CamMsQ0FBQSxFQUFHb0osSUFBQSxDQUFLMlMsV0FBVyxHQUM5QztZQUNFLE9BQU8vYixDQUFBO1VBQ1gsV0FDSVEsTUFBQSxJQUNBRixPQUFBLEtBQVcsUUFDWCxLQUFLNGIsaUJBQUEsQ0FBa0JsYyxDQUFBLEVBQUdvSixJQUFBLENBQUsyUyxXQUFXLEdBQzVDO1lBQ0UsT0FBTy9iLENBQUE7VUFDWCxXQUFXLENBQUNRLE1BQUEsSUFBVSxLQUFLd2IsY0FBQSxDQUFlaGMsQ0FBQSxFQUFHb0osSUFBQSxDQUFLMlMsV0FBVyxHQUFHO1lBQzVELE9BQU8vYixDQUFBO1VBQ1g7UUFDSjtNQUNKO01BSUEsU0FBU3NjLGdCQUFnQjlkLEtBQUEsRUFBTztRQUM1QixJQUFJLENBQUMsS0FBSzJELE9BQUEsQ0FBUSxHQUFHO1VBQ2pCLE9BQU8zRCxLQUFBLElBQVMsT0FBTyxPQUFPd0UsR0FBQTtRQUNsQztRQUVBLElBQUlpSixHQUFBLEdBQU0ySCxHQUFBLENBQUksTUFBTSxLQUFLO1FBQ3pCLElBQUlwVixLQUFBLElBQVMsTUFBTTtVQUNmQSxLQUFBLEdBQVFxYyxZQUFBLENBQWFyYyxLQUFBLEVBQU8sS0FBSzhKLFVBQUEsQ0FBVyxDQUFDO1VBQzdDLE9BQU8sS0FBSytSLEdBQUEsQ0FBSTdiLEtBQUEsR0FBUXlOLEdBQUEsRUFBSyxHQUFHO1FBQ3BDLE9BQU87VUFDSCxPQUFPQSxHQUFBO1FBQ1g7TUFDSjtNQUVBLFNBQVNzUSxzQkFBc0IvZCxLQUFBLEVBQU87UUFDbEMsSUFBSSxDQUFDLEtBQUsyRCxPQUFBLENBQVEsR0FBRztVQUNqQixPQUFPM0QsS0FBQSxJQUFTLE9BQU8sT0FBT3dFLEdBQUE7UUFDbEM7UUFDQSxJQUFJb0osT0FBQSxJQUFXLEtBQUtILEdBQUEsQ0FBSSxJQUFJLElBQUksS0FBSzNELFVBQUEsQ0FBVyxFQUFFMFIsS0FBQSxDQUFNZCxHQUFBLElBQU87UUFDL0QsT0FBTzFhLEtBQUEsSUFBUyxPQUFPNE4sT0FBQSxHQUFVLEtBQUtpTyxHQUFBLENBQUk3YixLQUFBLEdBQVE0TixPQUFBLEVBQVMsR0FBRztNQUNsRTtNQUVBLFNBQVNvUSxtQkFBbUJoZSxLQUFBLEVBQU87UUFDL0IsSUFBSSxDQUFDLEtBQUsyRCxPQUFBLENBQVEsR0FBRztVQUNqQixPQUFPM0QsS0FBQSxJQUFTLE9BQU8sT0FBT3dFLEdBQUE7UUFDbEM7UUFNQSxJQUFJeEUsS0FBQSxJQUFTLE1BQU07VUFDZixJQUFJNE4sT0FBQSxHQUFVME8sZUFBQSxDQUFnQnRjLEtBQUEsRUFBTyxLQUFLOEosVUFBQSxDQUFXLENBQUM7VUFDdEQsT0FBTyxLQUFLMkQsR0FBQSxDQUFJLEtBQUtBLEdBQUEsQ0FBSSxJQUFJLElBQUlHLE9BQUEsR0FBVUEsT0FBQSxHQUFVLENBQUM7UUFDMUQsT0FBTztVQUNILE9BQU8sS0FBS0gsR0FBQSxDQUFJLEtBQUs7UUFDekI7TUFDSjtNQUVBLFNBQVMwTyxjQUFjM0osUUFBQSxFQUFVO1FBQzdCLElBQUksS0FBS29MLG1CQUFBLEVBQXFCO1VBQzFCLElBQUksQ0FBQ3JkLFVBQUEsQ0FBVyxNQUFNLGdCQUFnQixHQUFHO1lBQ3JDMGQsb0JBQUEsQ0FBcUI1ZCxJQUFBLENBQUssSUFBSTtVQUNsQztVQUNBLElBQUltUyxRQUFBLEVBQVU7WUFDVixPQUFPLEtBQUswTCxvQkFBQTtVQUNoQixPQUFPO1lBQ0gsT0FBTyxLQUFLQyxjQUFBO1VBQ2hCO1FBQ0osT0FBTztVQUNILElBQUksQ0FBQzVkLFVBQUEsQ0FBVyxNQUFNLGdCQUFnQixHQUFHO1lBQ3JDLEtBQUs0ZCxjQUFBLEdBQWlCdEIsb0JBQUE7VUFDMUI7VUFDQSxPQUFPLEtBQUtxQixvQkFBQSxJQUF3QjFMLFFBQUEsR0FDOUIsS0FBSzBMLG9CQUFBLEdBQ0wsS0FBS0MsY0FBQTtRQUNmO01BQ0o7TUFFQSxTQUFTakMsbUJBQW1CMUosUUFBQSxFQUFVO1FBQ2xDLElBQUksS0FBS29MLG1CQUFBLEVBQXFCO1VBQzFCLElBQUksQ0FBQ3JkLFVBQUEsQ0FBVyxNQUFNLGdCQUFnQixHQUFHO1lBQ3JDMGQsb0JBQUEsQ0FBcUI1ZCxJQUFBLENBQUssSUFBSTtVQUNsQztVQUNBLElBQUltUyxRQUFBLEVBQVU7WUFDVixPQUFPLEtBQUs0TCx5QkFBQTtVQUNoQixPQUFPO1lBQ0gsT0FBTyxLQUFLQyxtQkFBQTtVQUNoQjtRQUNKLE9BQU87VUFDSCxJQUFJLENBQUM5ZCxVQUFBLENBQVcsTUFBTSxxQkFBcUIsR0FBRztZQUMxQyxLQUFLOGQsbUJBQUEsR0FBc0J2Qix5QkFBQTtVQUMvQjtVQUNBLE9BQU8sS0FBS3NCLHlCQUFBLElBQTZCNUwsUUFBQSxHQUNuQyxLQUFLNEwseUJBQUEsR0FDTCxLQUFLQyxtQkFBQTtRQUNmO01BQ0o7TUFFQSxTQUFTcEMsaUJBQWlCekosUUFBQSxFQUFVO1FBQ2hDLElBQUksS0FBS29MLG1CQUFBLEVBQXFCO1VBQzFCLElBQUksQ0FBQ3JkLFVBQUEsQ0FBVyxNQUFNLGdCQUFnQixHQUFHO1lBQ3JDMGQsb0JBQUEsQ0FBcUI1ZCxJQUFBLENBQUssSUFBSTtVQUNsQztVQUNBLElBQUltUyxRQUFBLEVBQVU7WUFDVixPQUFPLEtBQUs4TCx1QkFBQTtVQUNoQixPQUFPO1lBQ0gsT0FBTyxLQUFLQyxpQkFBQTtVQUNoQjtRQUNKLE9BQU87VUFDSCxJQUFJLENBQUNoZSxVQUFBLENBQVcsTUFBTSxtQkFBbUIsR0FBRztZQUN4QyxLQUFLZ2UsaUJBQUEsR0FBb0J4Qix1QkFBQTtVQUM3QjtVQUNBLE9BQU8sS0FBS3VCLHVCQUFBLElBQTJCOUwsUUFBQSxHQUNqQyxLQUFLOEwsdUJBQUEsR0FDTCxLQUFLQyxpQkFBQTtRQUNmO01BQ0o7TUFFQSxTQUFTTixxQkFBQSxFQUF1QjtRQUM1QixTQUFTakUsVUFBVXhaLENBQUEsRUFBR0MsQ0FBQSxFQUFHO1VBQ3JCLE9BQU9BLENBQUEsQ0FBRUssTUFBQSxHQUFTTixDQUFBLENBQUVNLE1BQUE7UUFDeEI7UUFFQSxJQUFJMGQsU0FBQSxHQUFZLEVBQUM7VUFDYnZFLFdBQUEsR0FBYyxFQUFDO1VBQ2ZDLFVBQUEsR0FBYSxFQUFDO1VBQ2RDLFdBQUEsR0FBYyxFQUFDO1VBQ2YzWSxDQUFBO1VBQ0E2RyxHQUFBO1VBQ0FvVyxJQUFBO1VBQ0FDLE1BQUE7VUFDQUMsS0FBQTtRQUNKLEtBQUtuZCxDQUFBLEdBQUksR0FBR0EsQ0FBQSxHQUFJLEdBQUdBLENBQUEsSUFBSztVQUVwQjZHLEdBQUEsR0FBTXhHLFNBQUEsQ0FBVSxDQUFDLEtBQU0sQ0FBQyxDQUFDLEVBQUU0TCxHQUFBLENBQUlqTSxDQUFDO1VBQ2hDaWQsSUFBQSxHQUFPN0wsV0FBQSxDQUFZLEtBQUttSixXQUFBLENBQVkxVCxHQUFBLEVBQUssRUFBRSxDQUFDO1VBQzVDcVcsTUFBQSxHQUFTOUwsV0FBQSxDQUFZLEtBQUtvSixhQUFBLENBQWMzVCxHQUFBLEVBQUssRUFBRSxDQUFDO1VBQ2hEc1csS0FBQSxHQUFRL0wsV0FBQSxDQUFZLEtBQUtqRixRQUFBLENBQVN0RixHQUFBLEVBQUssRUFBRSxDQUFDO1VBQzFDbVcsU0FBQSxDQUFVOWMsSUFBQSxDQUFLK2MsSUFBSTtVQUNuQnhFLFdBQUEsQ0FBWXZZLElBQUEsQ0FBS2dkLE1BQU07VUFDdkJ4RSxVQUFBLENBQVd4WSxJQUFBLENBQUtpZCxLQUFLO1VBQ3JCeEUsV0FBQSxDQUFZelksSUFBQSxDQUFLK2MsSUFBSTtVQUNyQnRFLFdBQUEsQ0FBWXpZLElBQUEsQ0FBS2dkLE1BQU07VUFDdkJ2RSxXQUFBLENBQVl6WSxJQUFBLENBQUtpZCxLQUFLO1FBQzFCO1FBR0FILFNBQUEsQ0FBVXhOLElBQUEsQ0FBS2dKLFNBQVM7UUFDeEJDLFdBQUEsQ0FBWWpKLElBQUEsQ0FBS2dKLFNBQVM7UUFDMUJFLFVBQUEsQ0FBV2xKLElBQUEsQ0FBS2dKLFNBQVM7UUFDekJHLFdBQUEsQ0FBWW5KLElBQUEsQ0FBS2dKLFNBQVM7UUFFMUIsS0FBS21FLGNBQUEsR0FBaUIsSUFBSS9XLE1BQUEsQ0FBTyxPQUFPK1MsV0FBQSxDQUFZMVQsSUFBQSxDQUFLLEdBQUcsSUFBSSxLQUFLLEdBQUc7UUFDeEUsS0FBSzRYLG1CQUFBLEdBQXNCLEtBQUtGLGNBQUE7UUFDaEMsS0FBS0ksaUJBQUEsR0FBb0IsS0FBS0osY0FBQTtRQUU5QixLQUFLRCxvQkFBQSxHQUF1QixJQUFJOVcsTUFBQSxDQUM1QixPQUFPOFMsVUFBQSxDQUFXelQsSUFBQSxDQUFLLEdBQUcsSUFBSSxLQUM5QixHQUNKO1FBQ0EsS0FBSzJYLHlCQUFBLEdBQTRCLElBQUloWCxNQUFBLENBQ2pDLE9BQU82UyxXQUFBLENBQVl4VCxJQUFBLENBQUssR0FBRyxJQUFJLEtBQy9CLEdBQ0o7UUFDQSxLQUFLNlgsdUJBQUEsR0FBMEIsSUFBSWxYLE1BQUEsQ0FDL0IsT0FBT29YLFNBQUEsQ0FBVS9YLElBQUEsQ0FBSyxHQUFHLElBQUksS0FDN0IsR0FDSjtNQUNKO01BSUEsU0FBU21ZLFFBQUEsRUFBVTtRQUNmLE9BQU8sS0FBS3pRLEtBQUEsQ0FBTSxJQUFJLE1BQU07TUFDaEM7TUFFQSxTQUFTMFEsUUFBQSxFQUFVO1FBQ2YsT0FBTyxLQUFLMVEsS0FBQSxDQUFNLEtBQUs7TUFDM0I7TUFFQTFFLGNBQUEsQ0FBZSxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxNQUFNO01BQ3hDQSxjQUFBLENBQWUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUdtVixPQUFPO01BQ3pDblYsY0FBQSxDQUFlLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHb1YsT0FBTztNQUV6Q3BWLGNBQUEsQ0FBZSxPQUFPLEdBQUcsR0FBRyxZQUFZO1FBQ3BDLE9BQU8sS0FBS21WLE9BQUEsQ0FBUWpmLEtBQUEsQ0FBTSxJQUFJLElBQUk4SSxRQUFBLENBQVMsS0FBSytGLE9BQUEsQ0FBUSxHQUFHLENBQUM7TUFDaEUsQ0FBQztNQUVEL0UsY0FBQSxDQUFlLFNBQVMsR0FBRyxHQUFHLFlBQVk7UUFDdEMsT0FDSSxLQUNBbVYsT0FBQSxDQUFRamYsS0FBQSxDQUFNLElBQUksSUFDbEI4SSxRQUFBLENBQVMsS0FBSytGLE9BQUEsQ0FBUSxHQUFHLENBQUMsSUFDMUIvRixRQUFBLENBQVMsS0FBS3NHLE9BQUEsQ0FBUSxHQUFHLENBQUM7TUFFbEMsQ0FBQztNQUVEdEYsY0FBQSxDQUFlLE9BQU8sR0FBRyxHQUFHLFlBQVk7UUFDcEMsT0FBTyxLQUFLLEtBQUswRSxLQUFBLENBQU0sSUFBSTFGLFFBQUEsQ0FBUyxLQUFLK0YsT0FBQSxDQUFRLEdBQUcsQ0FBQztNQUN6RCxDQUFDO01BRUQvRSxjQUFBLENBQWUsU0FBUyxHQUFHLEdBQUcsWUFBWTtRQUN0QyxPQUNJLEtBQ0EsS0FBSzBFLEtBQUEsQ0FBTSxJQUNYMUYsUUFBQSxDQUFTLEtBQUsrRixPQUFBLENBQVEsR0FBRyxDQUFDLElBQzFCL0YsUUFBQSxDQUFTLEtBQUtzRyxPQUFBLENBQVEsR0FBRyxDQUFDO01BRWxDLENBQUM7TUFFRCxTQUFTOUwsU0FBU3lHLE1BQUEsRUFBT29WLFNBQUEsRUFBVztRQUNoQ3JWLGNBQUEsQ0FBZUMsTUFBQSxFQUFPLEdBQUcsR0FBRyxZQUFZO1VBQ3BDLE9BQU8sS0FBS0ksVUFBQSxDQUFXLEVBQUU3RyxRQUFBLENBQ3JCLEtBQUtrTCxLQUFBLENBQU0sR0FDWCxLQUFLSyxPQUFBLENBQVEsR0FDYnNRLFNBQ0o7UUFDSixDQUFDO01BQ0w7TUFFQTdiLFFBQUEsQ0FBUyxLQUFLLElBQUk7TUFDbEJBLFFBQUEsQ0FBUyxLQUFLLEtBQUs7TUFJbkIsU0FBUzhiLGNBQWN2TSxRQUFBLEVBQVV6USxPQUFBLEVBQVE7UUFDckMsT0FBT0EsT0FBQSxDQUFPaWQsY0FBQTtNQUNsQjtNQUVBM00sYUFBQSxDQUFjLEtBQUswTSxhQUFhO01BQ2hDMU0sYUFBQSxDQUFjLEtBQUswTSxhQUFhO01BQ2hDMU0sYUFBQSxDQUFjLEtBQUtmLFNBQUEsRUFBV2EsZ0JBQWdCO01BQzlDRSxhQUFBLENBQWMsS0FBS2YsU0FBQSxFQUFXWSxzQkFBc0I7TUFDcERHLGFBQUEsQ0FBYyxLQUFLZixTQUFBLEVBQVdZLHNCQUFzQjtNQUNwREcsYUFBQSxDQUFjLE1BQU1mLFNBQUEsRUFBV0osTUFBTTtNQUNyQ21CLGFBQUEsQ0FBYyxNQUFNZixTQUFBLEVBQVdKLE1BQU07TUFDckNtQixhQUFBLENBQWMsTUFBTWYsU0FBQSxFQUFXSixNQUFNO01BRXJDbUIsYUFBQSxDQUFjLE9BQU9kLFNBQVM7TUFDOUJjLGFBQUEsQ0FBYyxTQUFTYixTQUFTO01BQ2hDYSxhQUFBLENBQWMsT0FBT2QsU0FBUztNQUM5QmMsYUFBQSxDQUFjLFNBQVNiLFNBQVM7TUFFaENtQyxhQUFBLENBQWMsQ0FBQyxLQUFLLElBQUksR0FBR1csSUFBSTtNQUMvQlgsYUFBQSxDQUFjLENBQUMsS0FBSyxJQUFJLEdBQUcsVUFBVTNULEtBQUEsRUFBT29LLEtBQUEsRUFBTzFFLE1BQUEsRUFBUTtRQUN2RCxJQUFJdVosTUFBQSxHQUFTNUwsS0FBQSxDQUFNclQsS0FBSztRQUN4Qm9LLEtBQUEsQ0FBTWtLLElBQUEsSUFBUTJLLE1BQUEsS0FBVyxLQUFLLElBQUlBLE1BQUE7TUFDdEMsQ0FBQztNQUNEdEwsYUFBQSxDQUFjLENBQUMsS0FBSyxHQUFHLEdBQUcsVUFBVTNULEtBQUEsRUFBT29LLEtBQUEsRUFBTzFFLE1BQUEsRUFBUTtRQUN0REEsTUFBQSxDQUFPd1osS0FBQSxHQUFReFosTUFBQSxDQUFPRixPQUFBLENBQVEyWixJQUFBLENBQUtuZixLQUFLO1FBQ3hDMEYsTUFBQSxDQUFPMFosU0FBQSxHQUFZcGYsS0FBQTtNQUN2QixDQUFDO01BQ0QyVCxhQUFBLENBQWMsQ0FBQyxLQUFLLElBQUksR0FBRyxVQUFVM1QsS0FBQSxFQUFPb0ssS0FBQSxFQUFPMUUsTUFBQSxFQUFRO1FBQ3ZEMEUsS0FBQSxDQUFNa0ssSUFBQSxJQUFRakIsS0FBQSxDQUFNclQsS0FBSztRQUN6Qm9ELGVBQUEsQ0FBZ0JzQyxNQUFNLEVBQUV0QixPQUFBLEdBQVU7TUFDdEMsQ0FBQztNQUNEdVAsYUFBQSxDQUFjLE9BQU8sVUFBVTNULEtBQUEsRUFBT29LLEtBQUEsRUFBTzFFLE1BQUEsRUFBUTtRQUNqRCxJQUFJMlosR0FBQSxHQUFNcmYsS0FBQSxDQUFNYyxNQUFBLEdBQVM7UUFDekJzSixLQUFBLENBQU1rSyxJQUFBLElBQVFqQixLQUFBLENBQU1yVCxLQUFBLENBQU1vSixNQUFBLENBQU8sR0FBR2lXLEdBQUcsQ0FBQztRQUN4Q2pWLEtBQUEsQ0FBTW1LLE1BQUEsSUFBVWxCLEtBQUEsQ0FBTXJULEtBQUEsQ0FBTW9KLE1BQUEsQ0FBT2lXLEdBQUcsQ0FBQztRQUN2Q2pjLGVBQUEsQ0FBZ0JzQyxNQUFNLEVBQUV0QixPQUFBLEdBQVU7TUFDdEMsQ0FBQztNQUNEdVAsYUFBQSxDQUFjLFNBQVMsVUFBVTNULEtBQUEsRUFBT29LLEtBQUEsRUFBTzFFLE1BQUEsRUFBUTtRQUNuRCxJQUFJNFosSUFBQSxHQUFPdGYsS0FBQSxDQUFNYyxNQUFBLEdBQVM7VUFDdEJ5ZSxJQUFBLEdBQU92ZixLQUFBLENBQU1jLE1BQUEsR0FBUztRQUMxQnNKLEtBQUEsQ0FBTWtLLElBQUEsSUFBUWpCLEtBQUEsQ0FBTXJULEtBQUEsQ0FBTW9KLE1BQUEsQ0FBTyxHQUFHa1csSUFBSSxDQUFDO1FBQ3pDbFYsS0FBQSxDQUFNbUssTUFBQSxJQUFVbEIsS0FBQSxDQUFNclQsS0FBQSxDQUFNb0osTUFBQSxDQUFPa1csSUFBQSxFQUFNLENBQUMsQ0FBQztRQUMzQ2xWLEtBQUEsQ0FBTW9LLE1BQUEsSUFBVW5CLEtBQUEsQ0FBTXJULEtBQUEsQ0FBTW9KLE1BQUEsQ0FBT21XLElBQUksQ0FBQztRQUN4Q25jLGVBQUEsQ0FBZ0JzQyxNQUFNLEVBQUV0QixPQUFBLEdBQVU7TUFDdEMsQ0FBQztNQUNEdVAsYUFBQSxDQUFjLE9BQU8sVUFBVTNULEtBQUEsRUFBT29LLEtBQUEsRUFBTzFFLE1BQUEsRUFBUTtRQUNqRCxJQUFJMlosR0FBQSxHQUFNcmYsS0FBQSxDQUFNYyxNQUFBLEdBQVM7UUFDekJzSixLQUFBLENBQU1rSyxJQUFBLElBQVFqQixLQUFBLENBQU1yVCxLQUFBLENBQU1vSixNQUFBLENBQU8sR0FBR2lXLEdBQUcsQ0FBQztRQUN4Q2pWLEtBQUEsQ0FBTW1LLE1BQUEsSUFBVWxCLEtBQUEsQ0FBTXJULEtBQUEsQ0FBTW9KLE1BQUEsQ0FBT2lXLEdBQUcsQ0FBQztNQUMzQyxDQUFDO01BQ0QxTCxhQUFBLENBQWMsU0FBUyxVQUFVM1QsS0FBQSxFQUFPb0ssS0FBQSxFQUFPMUUsTUFBQSxFQUFRO1FBQ25ELElBQUk0WixJQUFBLEdBQU90ZixLQUFBLENBQU1jLE1BQUEsR0FBUztVQUN0QnllLElBQUEsR0FBT3ZmLEtBQUEsQ0FBTWMsTUFBQSxHQUFTO1FBQzFCc0osS0FBQSxDQUFNa0ssSUFBQSxJQUFRakIsS0FBQSxDQUFNclQsS0FBQSxDQUFNb0osTUFBQSxDQUFPLEdBQUdrVyxJQUFJLENBQUM7UUFDekNsVixLQUFBLENBQU1tSyxNQUFBLElBQVVsQixLQUFBLENBQU1yVCxLQUFBLENBQU1vSixNQUFBLENBQU9rVyxJQUFBLEVBQU0sQ0FBQyxDQUFDO1FBQzNDbFYsS0FBQSxDQUFNb0ssTUFBQSxJQUFVbkIsS0FBQSxDQUFNclQsS0FBQSxDQUFNb0osTUFBQSxDQUFPbVcsSUFBSSxDQUFDO01BQzVDLENBQUM7TUFJRCxTQUFTQyxXQUFXeGYsS0FBQSxFQUFPO1FBR3ZCLFFBQVFBLEtBQUEsR0FBUSxJQUFJZ1EsV0FBQSxDQUFZLEVBQUV5UCxNQUFBLENBQU8sQ0FBQyxNQUFNO01BQ3BEO01BRUEsSUFBSUMsMEJBQUEsR0FBNkI7UUFLN0JDLFVBQUEsR0FBYTNLLFVBQUEsQ0FBVyxTQUFTLElBQUk7TUFFekMsU0FBUzRLLGVBQWVDLE1BQUEsRUFBT0MsUUFBQSxFQUFTQyxPQUFBLEVBQVM7UUFDN0MsSUFBSUYsTUFBQSxHQUFRLElBQUk7VUFDWixPQUFPRSxPQUFBLEdBQVUsT0FBTztRQUM1QixPQUFPO1VBQ0gsT0FBT0EsT0FBQSxHQUFVLE9BQU87UUFDNUI7TUFDSjtNQUVBLElBQUlDLFVBQUEsR0FBYTtRQUNiNVgsUUFBQSxFQUFVUCxlQUFBO1FBQ1Y2QyxjQUFBLEVBQWdCRyxxQkFBQTtRQUNoQk4sV0FBQSxFQUFhaUIsa0JBQUE7UUFDYnpCLE9BQUEsRUFBUzJCLGNBQUE7UUFDVHVVLHNCQUFBLEVBQXdCdFUsNkJBQUE7UUFDeEJrQixZQUFBLEVBQWNoQixtQkFBQTtRQUVkNkMsTUFBQSxFQUFRdUosbUJBQUE7UUFDUkosV0FBQSxFQUFhTSx3QkFBQTtRQUViM0ksSUFBQSxFQUFNaU0saUJBQUE7UUFFTjlOLFFBQUEsRUFBVStPLHFCQUFBO1FBQ1ZYLFdBQUEsRUFBYWEsd0JBQUE7UUFDYlosYUFBQSxFQUFlVywwQkFBQTtRQUVmdUQsYUFBQSxFQUFlUjtNQUNuQjtNQUdBLElBQUlTLE9BQUEsR0FBVSxDQUFDO1FBQ1hDLGNBQUEsR0FBaUIsQ0FBQztRQUNsQkMsWUFBQTtNQUVKLFNBQVNDLGFBQWFDLElBQUEsRUFBTUMsSUFBQSxFQUFNO1FBQzlCLElBQUloZixDQUFBO1VBQ0FpZixJQUFBLEdBQU8zWCxJQUFBLENBQUt5USxHQUFBLENBQUlnSCxJQUFBLENBQUt6ZixNQUFBLEVBQVEwZixJQUFBLENBQUsxZixNQUFNO1FBQzVDLEtBQUtVLENBQUEsR0FBSSxHQUFHQSxDQUFBLEdBQUlpZixJQUFBLEVBQU1qZixDQUFBLElBQUssR0FBRztVQUMxQixJQUFJK2UsSUFBQSxDQUFLL2UsQ0FBQSxNQUFPZ2YsSUFBQSxDQUFLaGYsQ0FBQSxHQUFJO1lBQ3JCLE9BQU9BLENBQUE7VUFDWDtRQUNKO1FBQ0EsT0FBT2lmLElBQUE7TUFDWDtNQUVBLFNBQVNDLGdCQUFnQnBhLEdBQUEsRUFBSztRQUMxQixPQUFPQSxHQUFBLEdBQU1BLEdBQUEsQ0FBSTBKLFdBQUEsQ0FBWSxFQUFFOUYsT0FBQSxDQUFRLEtBQUssR0FBRyxJQUFJNUQsR0FBQTtNQUN2RDtNQUtBLFNBQVNxYSxhQUFhQyxLQUFBLEVBQU87UUFDekIsSUFBSXBmLENBQUEsR0FBSTtVQUNKcWYsQ0FBQTtVQUNBQyxJQUFBO1VBQ0EvZSxPQUFBO1VBQ0FtVyxLQUFBO1FBRUosT0FBTzFXLENBQUEsR0FBSW9mLEtBQUEsQ0FBTTlmLE1BQUEsRUFBUTtVQUNyQm9YLEtBQUEsR0FBUXdJLGVBQUEsQ0FBZ0JFLEtBQUEsQ0FBTXBmLENBQUEsQ0FBRSxFQUFFMFcsS0FBQSxDQUFNLEdBQUc7VUFDM0MySSxDQUFBLEdBQUkzSSxLQUFBLENBQU1wWCxNQUFBO1VBQ1ZnZ0IsSUFBQSxHQUFPSixlQUFBLENBQWdCRSxLQUFBLENBQU1wZixDQUFBLEdBQUksRUFBRTtVQUNuQ3NmLElBQUEsR0FBT0EsSUFBQSxHQUFPQSxJQUFBLENBQUs1SSxLQUFBLENBQU0sR0FBRyxJQUFJO1VBQ2hDLE9BQU8ySSxDQUFBLEdBQUksR0FBRztZQUNWOWUsT0FBQSxHQUFTZ2YsVUFBQSxDQUFXN0ksS0FBQSxDQUFNMVIsS0FBQSxDQUFNLEdBQUdxYSxDQUFDLEVBQUVwYSxJQUFBLENBQUssR0FBRyxDQUFDO1lBQy9DLElBQUkxRSxPQUFBLEVBQVE7Y0FDUixPQUFPQSxPQUFBO1lBQ1g7WUFDQSxJQUNJK2UsSUFBQSxJQUNBQSxJQUFBLENBQUtoZ0IsTUFBQSxJQUFVK2YsQ0FBQSxJQUNmUCxZQUFBLENBQWFwSSxLQUFBLEVBQU80SSxJQUFJLEtBQUtELENBQUEsR0FBSSxHQUNuQztjQUVFO1lBQ0o7WUFDQUEsQ0FBQTtVQUNKO1VBQ0FyZixDQUFBO1FBQ0o7UUFDQSxPQUFPNmUsWUFBQTtNQUNYO01BRUEsU0FBU1csaUJBQWlCbGEsSUFBQSxFQUFNO1FBRzVCLE9BQU8sQ0FBQyxFQUFFQSxJQUFBLElBQVFBLElBQUEsQ0FBS21ELEtBQUEsQ0FBTSxhQUFhO01BQzlDO01BRUEsU0FBUzhXLFdBQVdqYSxJQUFBLEVBQU07UUFDdEIsSUFBSW1hLFNBQUEsR0FBWTtVQUNaQyxjQUFBO1FBRUosSUFDSWYsT0FBQSxDQUFRclosSUFBQSxNQUFVLFVBQ2xCLE9BQU8zSCxPQUFBLEtBQVcsZUFDbEJBLE9BQUEsSUFDQUEsT0FBQSxDQUFPRCxPQUFBLElBQ1A4aEIsZ0JBQUEsQ0FBaUJsYSxJQUFJLEdBQ3ZCO1VBQ0UsSUFBSTtZQUNBbWEsU0FBQSxHQUFZWixZQUFBLENBQWFjLEtBQUE7WUFDekJELGNBQUEsR0FBaUJFLE9BQUE7WUFDakJGLGNBQUEsQ0FBZSxjQUFjcGEsSUFBSTtZQUNqQ3VhLGtCQUFBLENBQW1CSixTQUFTO1VBQ2hDLFNBQVN2VCxDQUFBLEVBQVA7WUFHRXlTLE9BQUEsQ0FBUXJaLElBQUEsSUFBUTtVQUNwQjtRQUNKO1FBQ0EsT0FBT3FaLE9BQUEsQ0FBUXJaLElBQUE7TUFDbkI7TUFLQSxTQUFTdWEsbUJBQW1CL2EsR0FBQSxFQUFLZ2IsTUFBQSxFQUFRO1FBQ3JDLElBQUlDLElBQUE7UUFDSixJQUFJamIsR0FBQSxFQUFLO1VBQ0wsSUFBSXRGLFdBQUEsQ0FBWXNnQixNQUFNLEdBQUc7WUFDckJDLElBQUEsR0FBT0MsU0FBQSxDQUFVbGIsR0FBRztVQUN4QixPQUFPO1lBQ0hpYixJQUFBLEdBQU9FLFlBQUEsQ0FBYW5iLEdBQUEsRUFBS2diLE1BQU07VUFDbkM7VUFFQSxJQUFJQyxJQUFBLEVBQU07WUFFTmxCLFlBQUEsR0FBZWtCLElBQUE7VUFDbkIsT0FBTztZQUNILElBQUksT0FBT3ZiLE9BQUEsS0FBWSxlQUFlQSxPQUFBLENBQVFILElBQUEsRUFBTTtjQUVoREcsT0FBQSxDQUFRSCxJQUFBLENBQ0osWUFBWVMsR0FBQSxHQUFNLHdDQUN0QjtZQUNKO1VBQ0o7UUFDSjtRQUVBLE9BQU8rWixZQUFBLENBQWFjLEtBQUE7TUFDeEI7TUFFQSxTQUFTTSxhQUFhM2EsSUFBQSxFQUFNcEIsTUFBQSxFQUFRO1FBQ2hDLElBQUlBLE1BQUEsS0FBVyxNQUFNO1VBQ2pCLElBQUkzRCxPQUFBO1lBQ0EwRixZQUFBLEdBQWV1WSxVQUFBO1VBQ25CdGEsTUFBQSxDQUFPZ2MsSUFBQSxHQUFPNWEsSUFBQTtVQUNkLElBQUlxWixPQUFBLENBQVFyWixJQUFBLEtBQVMsTUFBTTtZQUN2QkQsZUFBQSxDQUNJLHdCQUNBLHlPQUlKO1lBQ0FZLFlBQUEsR0FBZTBZLE9BQUEsQ0FBUXJaLElBQUEsRUFBTUksT0FBQTtVQUNqQyxXQUFXeEIsTUFBQSxDQUFPaWMsWUFBQSxJQUFnQixNQUFNO1lBQ3BDLElBQUl4QixPQUFBLENBQVF6YSxNQUFBLENBQU9pYyxZQUFBLEtBQWlCLE1BQU07Y0FDdENsYSxZQUFBLEdBQWUwWSxPQUFBLENBQVF6YSxNQUFBLENBQU9pYyxZQUFBLEVBQWN6YSxPQUFBO1lBQ2hELE9BQU87Y0FDSG5GLE9BQUEsR0FBU2dmLFVBQUEsQ0FBV3JiLE1BQUEsQ0FBT2ljLFlBQVk7Y0FDdkMsSUFBSTVmLE9BQUEsSUFBVSxNQUFNO2dCQUNoQjBGLFlBQUEsR0FBZTFGLE9BQUEsQ0FBT21GLE9BQUE7Y0FDMUIsT0FBTztnQkFDSCxJQUFJLENBQUNrWixjQUFBLENBQWUxYSxNQUFBLENBQU9pYyxZQUFBLEdBQWU7a0JBQ3RDdkIsY0FBQSxDQUFlMWEsTUFBQSxDQUFPaWMsWUFBQSxJQUFnQixFQUFDO2dCQUMzQztnQkFDQXZCLGNBQUEsQ0FBZTFhLE1BQUEsQ0FBT2ljLFlBQUEsRUFBY2pnQixJQUFBLENBQUs7a0JBQ3JDb0YsSUFBQTtrQkFDQXBCO2dCQUNKLENBQUM7Z0JBQ0QsT0FBTztjQUNYO1lBQ0o7VUFDSjtVQUNBeWEsT0FBQSxDQUFRclosSUFBQSxJQUFRLElBQUlhLE1BQUEsQ0FBT0gsWUFBQSxDQUFhQyxZQUFBLEVBQWMvQixNQUFNLENBQUM7VUFFN0QsSUFBSTBhLGNBQUEsQ0FBZXRaLElBQUEsR0FBTztZQUN0QnNaLGNBQUEsQ0FBZXRaLElBQUEsRUFBTThhLE9BQUEsQ0FBUSxVQUFVcEssQ0FBQSxFQUFHO2NBQ3RDaUssWUFBQSxDQUFhakssQ0FBQSxDQUFFMVEsSUFBQSxFQUFNMFEsQ0FBQSxDQUFFOVIsTUFBTTtZQUNqQyxDQUFDO1VBQ0w7VUFLQTJiLGtCQUFBLENBQW1CdmEsSUFBSTtVQUV2QixPQUFPcVosT0FBQSxDQUFRclosSUFBQTtRQUNuQixPQUFPO1VBRUgsT0FBT3FaLE9BQUEsQ0FBUXJaLElBQUE7VUFDZixPQUFPO1FBQ1g7TUFDSjtNQUVBLFNBQVMrYSxhQUFhL2EsSUFBQSxFQUFNcEIsTUFBQSxFQUFRO1FBQ2hDLElBQUlBLE1BQUEsSUFBVSxNQUFNO1VBQ2hCLElBQUkzRCxPQUFBO1lBQ0ErZixTQUFBO1lBQ0FyYSxZQUFBLEdBQWV1WSxVQUFBO1VBRW5CLElBQUlHLE9BQUEsQ0FBUXJaLElBQUEsS0FBUyxRQUFRcVosT0FBQSxDQUFRclosSUFBQSxFQUFNNmEsWUFBQSxJQUFnQixNQUFNO1lBRTdEeEIsT0FBQSxDQUFRclosSUFBQSxFQUFNRyxHQUFBLENBQUlPLFlBQUEsQ0FBYTJZLE9BQUEsQ0FBUXJaLElBQUEsRUFBTUksT0FBQSxFQUFTeEIsTUFBTSxDQUFDO1VBQ2pFLE9BQU87WUFFSG9jLFNBQUEsR0FBWWYsVUFBQSxDQUFXamEsSUFBSTtZQUMzQixJQUFJZ2IsU0FBQSxJQUFhLE1BQU07Y0FDbkJyYSxZQUFBLEdBQWVxYSxTQUFBLENBQVU1YSxPQUFBO1lBQzdCO1lBQ0F4QixNQUFBLEdBQVM4QixZQUFBLENBQWFDLFlBQUEsRUFBYy9CLE1BQU07WUFDMUMsSUFBSW9jLFNBQUEsSUFBYSxNQUFNO2NBSW5CcGMsTUFBQSxDQUFPZ2MsSUFBQSxHQUFPNWEsSUFBQTtZQUNsQjtZQUNBL0UsT0FBQSxHQUFTLElBQUk0RixNQUFBLENBQU9qQyxNQUFNO1lBQzFCM0QsT0FBQSxDQUFPNGYsWUFBQSxHQUFleEIsT0FBQSxDQUFRclosSUFBQTtZQUM5QnFaLE9BQUEsQ0FBUXJaLElBQUEsSUFBUS9FLE9BQUE7VUFDcEI7VUFHQXNmLGtCQUFBLENBQW1CdmEsSUFBSTtRQUMzQixPQUFPO1VBRUgsSUFBSXFaLE9BQUEsQ0FBUXJaLElBQUEsS0FBUyxNQUFNO1lBQ3ZCLElBQUlxWixPQUFBLENBQVFyWixJQUFBLEVBQU02YSxZQUFBLElBQWdCLE1BQU07Y0FDcEN4QixPQUFBLENBQVFyWixJQUFBLElBQVFxWixPQUFBLENBQVFyWixJQUFBLEVBQU02YSxZQUFBO2NBQzlCLElBQUk3YSxJQUFBLEtBQVN1YSxrQkFBQSxDQUFtQixHQUFHO2dCQUMvQkEsa0JBQUEsQ0FBbUJ2YSxJQUFJO2NBQzNCO1lBQ0osV0FBV3FaLE9BQUEsQ0FBUXJaLElBQUEsS0FBUyxNQUFNO2NBQzlCLE9BQU9xWixPQUFBLENBQVFyWixJQUFBO1lBQ25CO1VBQ0o7UUFDSjtRQUNBLE9BQU9xWixPQUFBLENBQVFyWixJQUFBO01BQ25CO01BR0EsU0FBUzBhLFVBQVVsYixHQUFBLEVBQUs7UUFDcEIsSUFBSXZFLE9BQUE7UUFFSixJQUFJdUUsR0FBQSxJQUFPQSxHQUFBLENBQUlkLE9BQUEsSUFBV2MsR0FBQSxDQUFJZCxPQUFBLENBQVEyYixLQUFBLEVBQU87VUFDekM3YSxHQUFBLEdBQU1BLEdBQUEsQ0FBSWQsT0FBQSxDQUFRMmIsS0FBQTtRQUN0QjtRQUVBLElBQUksQ0FBQzdhLEdBQUEsRUFBSztVQUNOLE9BQU8rWixZQUFBO1FBQ1g7UUFFQSxJQUFJLENBQUN0Z0IsT0FBQSxDQUFRdUcsR0FBRyxHQUFHO1VBRWZ2RSxPQUFBLEdBQVNnZixVQUFBLENBQVd6YSxHQUFHO1VBQ3ZCLElBQUl2RSxPQUFBLEVBQVE7WUFDUixPQUFPQSxPQUFBO1VBQ1g7VUFDQXVFLEdBQUEsR0FBTSxDQUFDQSxHQUFHO1FBQ2Q7UUFFQSxPQUFPcWEsWUFBQSxDQUFhcmEsR0FBRztNQUMzQjtNQUVBLFNBQVN5YixZQUFBLEVBQWM7UUFDbkIsT0FBT25hLElBQUEsQ0FBS3VZLE9BQU87TUFDdkI7TUFFQSxTQUFTNkIsY0FBYzNlLENBQUEsRUFBRztRQUN0QixJQUFJZCxRQUFBO1VBQ0EvQixDQUFBLEdBQUk2QyxDQUFBLENBQUU0USxFQUFBO1FBRVYsSUFBSXpULENBQUEsSUFBSzRDLGVBQUEsQ0FBZ0JDLENBQUMsRUFBRWQsUUFBQSxLQUFhLElBQUk7VUFDekNBLFFBQUEsR0FDSS9CLENBQUEsQ0FBRTRULEtBQUEsSUFBUyxLQUFLNVQsQ0FBQSxDQUFFNFQsS0FBQSxJQUFTLEtBQ3JCQSxLQUFBLEdBQ0E1VCxDQUFBLENBQUU2VCxJQUFBLElBQVEsS0FBSzdULENBQUEsQ0FBRTZULElBQUEsSUFBUXNELFdBQUEsQ0FBWW5YLENBQUEsQ0FBRTJULElBQUEsR0FBTzNULENBQUEsQ0FBRTRULEtBQUEsQ0FBTSxJQUNwREMsSUFBQSxHQUNBN1QsQ0FBQSxDQUFFOFQsSUFBQSxJQUFRLEtBQ1I5VCxDQUFBLENBQUU4VCxJQUFBLElBQVEsTUFDVDlULENBQUEsQ0FBRThULElBQUEsTUFBVSxPQUNSOVQsQ0FBQSxDQUFFK1QsTUFBQSxNQUFZLEtBQ1gvVCxDQUFBLENBQUVnVSxNQUFBLE1BQVksS0FDZGhVLENBQUEsQ0FBRWlVLFdBQUEsTUFBaUIsS0FDM0JILElBQUEsR0FDQTlULENBQUEsQ0FBRStULE1BQUEsSUFBVSxLQUFLL1QsQ0FBQSxDQUFFK1QsTUFBQSxJQUFVLEtBQzNCQSxNQUFBLEdBQ0EvVCxDQUFBLENBQUVnVSxNQUFBLElBQVUsS0FBS2hVLENBQUEsQ0FBRWdVLE1BQUEsSUFBVSxLQUMzQkEsTUFBQSxHQUNBaFUsQ0FBQSxDQUFFaVUsV0FBQSxJQUFlLEtBQUtqVSxDQUFBLENBQUVpVSxXQUFBLElBQWUsTUFDckNBLFdBQUEsR0FDQTtVQUVwQixJQUNJclIsZUFBQSxDQUFnQkMsQ0FBQyxFQUFFNGUsa0JBQUEsS0FDbEIxZixRQUFBLEdBQVc0UixJQUFBLElBQVE1UixRQUFBLEdBQVc4UixJQUFBLEdBQ2pDO1lBQ0U5UixRQUFBLEdBQVc4UixJQUFBO1VBQ2Y7VUFDQSxJQUFJalIsZUFBQSxDQUFnQkMsQ0FBQyxFQUFFNmUsY0FBQSxJQUFrQjNmLFFBQUEsS0FBYSxJQUFJO1lBQ3REQSxRQUFBLEdBQVdtUyxJQUFBO1VBQ2Y7VUFDQSxJQUFJdFIsZUFBQSxDQUFnQkMsQ0FBQyxFQUFFOGUsZ0JBQUEsSUFBb0I1ZixRQUFBLEtBQWEsSUFBSTtZQUN4REEsUUFBQSxHQUFXb1MsT0FBQTtVQUNmO1VBRUF2UixlQUFBLENBQWdCQyxDQUFDLEVBQUVkLFFBQUEsR0FBV0EsUUFBQTtRQUNsQztRQUVBLE9BQU9jLENBQUE7TUFDWDtNQUlBLElBQUkrZSxnQkFBQSxHQUNJO1FBQ0pDLGFBQUEsR0FDSTtRQUNKQyxPQUFBLEdBQVU7UUFDVkMsUUFBQSxHQUFXLENBQ1AsQ0FBQyxnQkFBZ0IscUJBQXFCLEdBQ3RDLENBQUMsY0FBYyxpQkFBaUIsR0FDaEMsQ0FBQyxnQkFBZ0IsZ0JBQWdCLEdBQ2pDLENBQUMsY0FBYyxlQUFlLEtBQUssR0FDbkMsQ0FBQyxZQUFZLGFBQWEsR0FDMUIsQ0FBQyxXQUFXLGNBQWMsS0FBSyxHQUMvQixDQUFDLGNBQWMsWUFBWSxHQUMzQixDQUFDLFlBQVksT0FBTyxHQUNwQixDQUFDLGNBQWMsYUFBYSxHQUM1QixDQUFDLGFBQWEsZUFBZSxLQUFLLEdBQ2xDLENBQUMsV0FBVyxPQUFPLEdBQ25CLENBQUMsVUFBVSxTQUFTLEtBQUssR0FDekIsQ0FBQyxRQUFRLFNBQVMsS0FBSyxFQUMzQjtRQUVBQyxRQUFBLEdBQVcsQ0FDUCxDQUFDLGlCQUFpQixxQkFBcUIsR0FDdkMsQ0FBQyxpQkFBaUIsb0JBQW9CLEdBQ3RDLENBQUMsWUFBWSxnQkFBZ0IsR0FDN0IsQ0FBQyxTQUFTLFdBQVcsR0FDckIsQ0FBQyxlQUFlLG1CQUFtQixHQUNuQyxDQUFDLGVBQWUsa0JBQWtCLEdBQ2xDLENBQUMsVUFBVSxjQUFjLEdBQ3pCLENBQUMsUUFBUSxVQUFVLEdBQ25CLENBQUMsTUFBTSxNQUFNLEVBQ2pCO1FBQ0FDLGVBQUEsR0FBa0I7UUFFbEJ2ZixPQUFBLEdBQ0k7UUFDSndmLFVBQUEsR0FBYTtVQUNUQyxFQUFBLEVBQUk7VUFDSkMsR0FBQSxFQUFLO1VBQ0xDLEdBQUEsRUFBSyxLQUFLO1VBQ1ZDLEdBQUEsRUFBSyxLQUFLO1VBQ1ZDLEdBQUEsRUFBSyxLQUFLO1VBQ1ZDLEdBQUEsRUFBSyxLQUFLO1VBQ1ZDLEdBQUEsRUFBSyxLQUFLO1VBQ1ZDLEdBQUEsRUFBSyxLQUFLO1VBQ1ZDLEdBQUEsRUFBSyxLQUFLO1VBQ1ZDLEdBQUEsRUFBSyxLQUFLO1FBQ2Q7TUFHSixTQUFTQyxjQUFjM2QsTUFBQSxFQUFRO1FBQzNCLElBQUlsRSxDQUFBO1VBQ0E4aEIsQ0FBQTtVQUNBdlcsTUFBQSxHQUFTckgsTUFBQSxDQUFPUixFQUFBO1VBQ2hCK0UsS0FBQSxHQUFRbVksZ0JBQUEsQ0FBaUJtQixJQUFBLENBQUt4VyxNQUFNLEtBQUtzVixhQUFBLENBQWNrQixJQUFBLENBQUt4VyxNQUFNO1VBQ2xFeVcsU0FBQTtVQUNBQyxVQUFBO1VBQ0FDLFVBQUE7VUFDQUMsUUFBQTtVQUNBQyxXQUFBLEdBQWNyQixRQUFBLENBQVN6aEIsTUFBQTtVQUN2QitpQixXQUFBLEdBQWNyQixRQUFBLENBQVMxaEIsTUFBQTtRQUUzQixJQUFJbUosS0FBQSxFQUFPO1VBQ1A3RyxlQUFBLENBQWdCc0MsTUFBTSxFQUFFNUMsR0FBQSxHQUFNO1VBQzlCLEtBQUt0QixDQUFBLEdBQUksR0FBRzhoQixDQUFBLEdBQUlNLFdBQUEsRUFBYXBpQixDQUFBLEdBQUk4aEIsQ0FBQSxFQUFHOWhCLENBQUEsSUFBSztZQUNyQyxJQUFJK2dCLFFBQUEsQ0FBUy9nQixDQUFBLEVBQUcsR0FBRytoQixJQUFBLENBQUt0WixLQUFBLENBQU0sRUFBRSxHQUFHO2NBQy9Cd1osVUFBQSxHQUFhbEIsUUFBQSxDQUFTL2dCLENBQUEsRUFBRztjQUN6QmdpQixTQUFBLEdBQVlqQixRQUFBLENBQVMvZ0IsQ0FBQSxFQUFHLE9BQU87Y0FDL0I7WUFDSjtVQUNKO1VBQ0EsSUFBSWlpQixVQUFBLElBQWMsTUFBTTtZQUNwQi9kLE1BQUEsQ0FBT3BCLFFBQUEsR0FBVztZQUNsQjtVQUNKO1VBQ0EsSUFBSTJGLEtBQUEsQ0FBTSxJQUFJO1lBQ1YsS0FBS3pJLENBQUEsR0FBSSxHQUFHOGhCLENBQUEsR0FBSU8sV0FBQSxFQUFhcmlCLENBQUEsR0FBSThoQixDQUFBLEVBQUc5aEIsQ0FBQSxJQUFLO2NBQ3JDLElBQUlnaEIsUUFBQSxDQUFTaGhCLENBQUEsRUFBRyxHQUFHK2hCLElBQUEsQ0FBS3RaLEtBQUEsQ0FBTSxFQUFFLEdBQUc7Z0JBRS9CeVosVUFBQSxJQUFjelosS0FBQSxDQUFNLE1BQU0sT0FBT3VZLFFBQUEsQ0FBU2hoQixDQUFBLEVBQUc7Z0JBQzdDO2NBQ0o7WUFDSjtZQUNBLElBQUlraUIsVUFBQSxJQUFjLE1BQU07Y0FDcEJoZSxNQUFBLENBQU9wQixRQUFBLEdBQVc7Y0FDbEI7WUFDSjtVQUNKO1VBQ0EsSUFBSSxDQUFDa2YsU0FBQSxJQUFhRSxVQUFBLElBQWMsTUFBTTtZQUNsQ2hlLE1BQUEsQ0FBT3BCLFFBQUEsR0FBVztZQUNsQjtVQUNKO1VBQ0EsSUFBSTJGLEtBQUEsQ0FBTSxJQUFJO1lBQ1YsSUFBSXFZLE9BQUEsQ0FBUWlCLElBQUEsQ0FBS3RaLEtBQUEsQ0FBTSxFQUFFLEdBQUc7Y0FDeEIwWixRQUFBLEdBQVc7WUFDZixPQUFPO2NBQ0hqZSxNQUFBLENBQU9wQixRQUFBLEdBQVc7Y0FDbEI7WUFDSjtVQUNKO1VBQ0FvQixNQUFBLENBQU9QLEVBQUEsR0FBS3NlLFVBQUEsSUFBY0MsVUFBQSxJQUFjLE9BQU9DLFFBQUEsSUFBWTtVQUMzREcseUJBQUEsQ0FBMEJwZSxNQUFNO1FBQ3BDLE9BQU87VUFDSEEsTUFBQSxDQUFPcEIsUUFBQSxHQUFXO1FBQ3RCO01BQ0o7TUFFQSxTQUFTeWYsMEJBQ0xDLE9BQUEsRUFDQUMsUUFBQSxFQUNBQyxNQUFBLEVBQ0FDLE9BQUEsRUFDQUMsU0FBQSxFQUNBQyxTQUFBLEVBQ0Y7UUFDRSxJQUFJQyxNQUFBLEdBQVMsQ0FDVEMsY0FBQSxDQUFlUCxPQUFPLEdBQ3RCN0wsd0JBQUEsQ0FBeUJWLE9BQUEsQ0FBUXdNLFFBQVEsR0FDekNwUCxRQUFBLENBQVNxUCxNQUFBLEVBQVEsRUFBRSxHQUNuQnJQLFFBQUEsQ0FBU3NQLE9BQUEsRUFBUyxFQUFFLEdBQ3BCdFAsUUFBQSxDQUFTdVAsU0FBQSxFQUFXLEVBQUUsRUFDMUI7UUFFQSxJQUFJQyxTQUFBLEVBQVc7VUFDWEMsTUFBQSxDQUFPNWlCLElBQUEsQ0FBS21ULFFBQUEsQ0FBU3dQLFNBQUEsRUFBVyxFQUFFLENBQUM7UUFDdkM7UUFFQSxPQUFPQyxNQUFBO01BQ1g7TUFFQSxTQUFTQyxlQUFlUCxPQUFBLEVBQVM7UUFDN0IsSUFBSW5VLElBQUEsR0FBT2dGLFFBQUEsQ0FBU21QLE9BQUEsRUFBUyxFQUFFO1FBQy9CLElBQUluVSxJQUFBLElBQVEsSUFBSTtVQUNaLE9BQU8sTUFBT0EsSUFBQTtRQUNsQixXQUFXQSxJQUFBLElBQVEsS0FBSztVQUNwQixPQUFPLE9BQU9BLElBQUE7UUFDbEI7UUFDQSxPQUFPQSxJQUFBO01BQ1g7TUFFQSxTQUFTMlUsa0JBQWtCeFksQ0FBQSxFQUFHO1FBRTFCLE9BQU9BLENBQUEsQ0FDRjlCLE9BQUEsQ0FBUSxzQkFBc0IsR0FBRyxFQUNqQ0EsT0FBQSxDQUFRLFlBQVksR0FBRyxFQUN2QkEsT0FBQSxDQUFRLFVBQVUsRUFBRSxFQUNwQkEsT0FBQSxDQUFRLFVBQVUsRUFBRTtNQUM3QjtNQUVBLFNBQVN1YSxhQUFhQyxVQUFBLEVBQVlDLFdBQUEsRUFBYWpmLE1BQUEsRUFBUTtRQUNuRCxJQUFJZ2YsVUFBQSxFQUFZO1VBRVosSUFBSUUsZUFBQSxHQUFrQmpJLDBCQUFBLENBQTJCbEYsT0FBQSxDQUFRaU4sVUFBVTtZQUMvREcsYUFBQSxHQUFnQixJQUFJMWpCLElBQUEsQ0FDaEJ3akIsV0FBQSxDQUFZLElBQ1pBLFdBQUEsQ0FBWSxJQUNaQSxXQUFBLENBQVksRUFDaEIsRUFBRTFPLE1BQUEsQ0FBTztVQUNiLElBQUkyTyxlQUFBLEtBQW9CQyxhQUFBLEVBQWU7WUFDbkN6aEIsZUFBQSxDQUFnQnNDLE1BQU0sRUFBRXZDLGVBQUEsR0FBa0I7WUFDMUN1QyxNQUFBLENBQU9wQixRQUFBLEdBQVc7WUFDbEIsT0FBTztVQUNYO1FBQ0o7UUFDQSxPQUFPO01BQ1g7TUFFQSxTQUFTd2dCLGdCQUFnQkMsU0FBQSxFQUFXQyxjQUFBLEVBQWdCQyxTQUFBLEVBQVc7UUFDM0QsSUFBSUYsU0FBQSxFQUFXO1VBQ1gsT0FBT3JDLFVBQUEsQ0FBV3FDLFNBQUE7UUFDdEIsV0FBV0MsY0FBQSxFQUFnQjtVQUV2QixPQUFPO1FBQ1gsT0FBTztVQUNILElBQUlFLEVBQUEsR0FBS3JRLFFBQUEsQ0FBU29RLFNBQUEsRUFBVyxFQUFFO1lBQzNCNWhCLENBQUEsR0FBSTZoQixFQUFBLEdBQUs7WUFDVC9ZLENBQUEsSUFBSytZLEVBQUEsR0FBSzdoQixDQUFBLElBQUs7VUFDbkIsT0FBTzhJLENBQUEsR0FBSSxLQUFLOUksQ0FBQTtRQUNwQjtNQUNKO01BR0EsU0FBUzhoQixrQkFBa0J6ZixNQUFBLEVBQVE7UUFDL0IsSUFBSXVFLEtBQUEsR0FBUS9HLE9BQUEsQ0FBUXFnQixJQUFBLENBQUtpQixpQkFBQSxDQUFrQjllLE1BQUEsQ0FBT1IsRUFBRSxDQUFDO1VBQ2pEa2dCLFdBQUE7UUFDSixJQUFJbmIsS0FBQSxFQUFPO1VBQ1BtYixXQUFBLEdBQWNyQix5QkFBQSxDQUNWOVosS0FBQSxDQUFNLElBQ05BLEtBQUEsQ0FBTSxJQUNOQSxLQUFBLENBQU0sSUFDTkEsS0FBQSxDQUFNLElBQ05BLEtBQUEsQ0FBTSxJQUNOQSxLQUFBLENBQU0sRUFDVjtVQUNBLElBQUksQ0FBQ3dhLFlBQUEsQ0FBYXhhLEtBQUEsQ0FBTSxJQUFJbWIsV0FBQSxFQUFhMWYsTUFBTSxHQUFHO1lBQzlDO1VBQ0o7VUFFQUEsTUFBQSxDQUFPdU8sRUFBQSxHQUFLbVIsV0FBQTtVQUNaMWYsTUFBQSxDQUFPTCxJQUFBLEdBQU95ZixlQUFBLENBQWdCN2EsS0FBQSxDQUFNLElBQUlBLEtBQUEsQ0FBTSxJQUFJQSxLQUFBLENBQU0sR0FBRztVQUUzRHZFLE1BQUEsQ0FBTzNCLEVBQUEsR0FBS3dXLGFBQUEsQ0FBYzVhLEtBQUEsQ0FBTSxNQUFNK0YsTUFBQSxDQUFPdU8sRUFBRTtVQUMvQ3ZPLE1BQUEsQ0FBTzNCLEVBQUEsQ0FBRzJTLGFBQUEsQ0FBY2hSLE1BQUEsQ0FBTzNCLEVBQUEsQ0FBRzJSLGFBQUEsQ0FBYyxJQUFJaFEsTUFBQSxDQUFPTCxJQUFJO1VBRS9EakMsZUFBQSxDQUFnQnNDLE1BQU0sRUFBRXhDLE9BQUEsR0FBVTtRQUN0QyxPQUFPO1VBQ0h3QyxNQUFBLENBQU9wQixRQUFBLEdBQVc7UUFDdEI7TUFDSjtNQUdBLFNBQVMrZ0IsaUJBQWlCM2YsTUFBQSxFQUFRO1FBQzlCLElBQUltTixPQUFBLEdBQVU0UCxlQUFBLENBQWdCYyxJQUFBLENBQUs3ZCxNQUFBLENBQU9SLEVBQUU7UUFDNUMsSUFBSTJOLE9BQUEsS0FBWSxNQUFNO1VBQ2xCbk4sTUFBQSxDQUFPM0IsRUFBQSxHQUFLLElBQUk1QyxJQUFBLENBQUssQ0FBQzBSLE9BQUEsQ0FBUSxFQUFFO1VBQ2hDO1FBQ0o7UUFFQXdRLGFBQUEsQ0FBYzNkLE1BQU07UUFDcEIsSUFBSUEsTUFBQSxDQUFPcEIsUUFBQSxLQUFhLE9BQU87VUFDM0IsT0FBT29CLE1BQUEsQ0FBT3BCLFFBQUE7UUFDbEIsT0FBTztVQUNIO1FBQ0o7UUFFQTZnQixpQkFBQSxDQUFrQnpmLE1BQU07UUFDeEIsSUFBSUEsTUFBQSxDQUFPcEIsUUFBQSxLQUFhLE9BQU87VUFDM0IsT0FBT29CLE1BQUEsQ0FBT3BCLFFBQUE7UUFDbEIsT0FBTztVQUNIO1FBQ0o7UUFFQSxJQUFJb0IsTUFBQSxDQUFPdkIsT0FBQSxFQUFTO1VBQ2hCdUIsTUFBQSxDQUFPcEIsUUFBQSxHQUFXO1FBQ3RCLE9BQU87VUFFSDVFLEtBQUEsQ0FBTTRsQix1QkFBQSxDQUF3QjVmLE1BQU07UUFDeEM7TUFDSjtNQUVBaEcsS0FBQSxDQUFNNGxCLHVCQUFBLEdBQTBCcmYsU0FBQSxDQUM1QixpU0FHQSxVQUFVUCxNQUFBLEVBQVE7UUFDZEEsTUFBQSxDQUFPM0IsRUFBQSxHQUFLLElBQUk1QyxJQUFBLENBQUt1RSxNQUFBLENBQU9SLEVBQUEsSUFBTVEsTUFBQSxDQUFPNmYsT0FBQSxHQUFVLFNBQVMsR0FBRztNQUNuRSxDQUNKO01BR0EsU0FBU0MsU0FBU2hsQixDQUFBLEVBQUdDLENBQUEsRUFBR2dsQixDQUFBLEVBQUc7UUFDdkIsSUFBSWpsQixDQUFBLElBQUssTUFBTTtVQUNYLE9BQU9BLENBQUE7UUFDWDtRQUNBLElBQUlDLENBQUEsSUFBSyxNQUFNO1VBQ1gsT0FBT0EsQ0FBQTtRQUNYO1FBQ0EsT0FBT2dsQixDQUFBO01BQ1g7TUFFQSxTQUFTQyxpQkFBaUJoZ0IsTUFBQSxFQUFRO1FBRTlCLElBQUlpZ0IsUUFBQSxHQUFXLElBQUl4a0IsSUFBQSxDQUFLekIsS0FBQSxDQUFNa21CLEdBQUEsQ0FBSSxDQUFDO1FBQ25DLElBQUlsZ0IsTUFBQSxDQUFPNmYsT0FBQSxFQUFTO1VBQ2hCLE9BQU8sQ0FDSEksUUFBQSxDQUFTdlAsY0FBQSxDQUFlLEdBQ3hCdVAsUUFBQSxDQUFTelAsV0FBQSxDQUFZLEdBQ3JCeVAsUUFBQSxDQUFTN1AsVUFBQSxDQUFXLEVBQ3hCO1FBQ0o7UUFDQSxPQUFPLENBQUM2UCxRQUFBLENBQVN0UCxXQUFBLENBQVksR0FBR3NQLFFBQUEsQ0FBU3hQLFFBQUEsQ0FBUyxHQUFHd1AsUUFBQSxDQUFTNVAsT0FBQSxDQUFRLENBQUM7TUFDM0U7TUFNQSxTQUFTOFAsZ0JBQWdCbmdCLE1BQUEsRUFBUTtRQUM3QixJQUFJbEUsQ0FBQTtVQUNBK0wsSUFBQTtVQUNBdk4sS0FBQSxHQUFRLEVBQUM7VUFDVDhsQixXQUFBO1VBQ0FDLGVBQUE7VUFDQUMsU0FBQTtRQUVKLElBQUl0Z0IsTUFBQSxDQUFPM0IsRUFBQSxFQUFJO1VBQ1g7UUFDSjtRQUVBK2hCLFdBQUEsR0FBY0osZ0JBQUEsQ0FBaUJoZ0IsTUFBTTtRQUdyQyxJQUFJQSxNQUFBLENBQU9xTyxFQUFBLElBQU1yTyxNQUFBLENBQU91TyxFQUFBLENBQUdJLElBQUEsS0FBUyxRQUFRM08sTUFBQSxDQUFPdU8sRUFBQSxDQUFHRyxLQUFBLEtBQVUsTUFBTTtVQUNsRTZSLHFCQUFBLENBQXNCdmdCLE1BQU07UUFDaEM7UUFHQSxJQUFJQSxNQUFBLENBQU93Z0IsVUFBQSxJQUFjLE1BQU07VUFDM0JGLFNBQUEsR0FBWVIsUUFBQSxDQUFTOWYsTUFBQSxDQUFPdU8sRUFBQSxDQUFHRSxJQUFBLEdBQU8yUixXQUFBLENBQVkzUixJQUFBLENBQUs7VUFFdkQsSUFDSXpPLE1BQUEsQ0FBT3dnQixVQUFBLEdBQWFwUixVQUFBLENBQVdrUixTQUFTLEtBQ3hDdGdCLE1BQUEsQ0FBT3dnQixVQUFBLEtBQWUsR0FDeEI7WUFDRTlpQixlQUFBLENBQWdCc0MsTUFBTSxFQUFFdWMsa0JBQUEsR0FBcUI7VUFDakQ7VUFFQTFVLElBQUEsR0FBT2dOLGFBQUEsQ0FBY3lMLFNBQUEsRUFBVyxHQUFHdGdCLE1BQUEsQ0FBT3dnQixVQUFVO1VBQ3BEeGdCLE1BQUEsQ0FBT3VPLEVBQUEsQ0FBR0csS0FBQSxJQUFTN0csSUFBQSxDQUFLMkksV0FBQSxDQUFZO1VBQ3BDeFEsTUFBQSxDQUFPdU8sRUFBQSxDQUFHSSxJQUFBLElBQVE5RyxJQUFBLENBQUt1SSxVQUFBLENBQVc7UUFDdEM7UUFPQSxLQUFLdFUsQ0FBQSxHQUFJLEdBQUdBLENBQUEsR0FBSSxLQUFLa0UsTUFBQSxDQUFPdU8sRUFBQSxDQUFHelMsQ0FBQSxLQUFNLE1BQU0sRUFBRUEsQ0FBQSxFQUFHO1VBQzVDa0UsTUFBQSxDQUFPdU8sRUFBQSxDQUFHelMsQ0FBQSxJQUFLeEIsS0FBQSxDQUFNd0IsQ0FBQSxJQUFLc2tCLFdBQUEsQ0FBWXRrQixDQUFBO1FBQzFDO1FBR0EsT0FBT0EsQ0FBQSxHQUFJLEdBQUdBLENBQUEsSUFBSztVQUNma0UsTUFBQSxDQUFPdU8sRUFBQSxDQUFHelMsQ0FBQSxJQUFLeEIsS0FBQSxDQUFNd0IsQ0FBQSxJQUNqQmtFLE1BQUEsQ0FBT3VPLEVBQUEsQ0FBR3pTLENBQUEsS0FBTSxPQUFRQSxDQUFBLEtBQU0sSUFBSSxJQUFJLElBQUtrRSxNQUFBLENBQU91TyxFQUFBLENBQUd6UyxDQUFBO1FBQzdEO1FBR0EsSUFDSWtFLE1BQUEsQ0FBT3VPLEVBQUEsQ0FBR0ssSUFBQSxNQUFVLE1BQ3BCNU8sTUFBQSxDQUFPdU8sRUFBQSxDQUFHTSxNQUFBLE1BQVksS0FDdEI3TyxNQUFBLENBQU91TyxFQUFBLENBQUdPLE1BQUEsTUFBWSxLQUN0QjlPLE1BQUEsQ0FBT3VPLEVBQUEsQ0FBR1EsV0FBQSxNQUFpQixHQUM3QjtVQUNFL08sTUFBQSxDQUFPeWdCLFFBQUEsR0FBVztVQUNsQnpnQixNQUFBLENBQU91TyxFQUFBLENBQUdLLElBQUEsSUFBUTtRQUN0QjtRQUVBNU8sTUFBQSxDQUFPM0IsRUFBQSxJQUFNMkIsTUFBQSxDQUFPNmYsT0FBQSxHQUFVaEwsYUFBQSxHQUFnQkQsVUFBQSxFQUFZM2EsS0FBQSxDQUN0RCxNQUNBSyxLQUNKO1FBQ0ErbEIsZUFBQSxHQUFrQnJnQixNQUFBLENBQU82ZixPQUFBLEdBQ25CN2YsTUFBQSxDQUFPM0IsRUFBQSxDQUFHaVMsU0FBQSxDQUFVLElBQ3BCdFEsTUFBQSxDQUFPM0IsRUFBQSxDQUFHa1MsTUFBQSxDQUFPO1FBSXZCLElBQUl2USxNQUFBLENBQU9MLElBQUEsSUFBUSxNQUFNO1VBQ3JCSyxNQUFBLENBQU8zQixFQUFBLENBQUcyUyxhQUFBLENBQWNoUixNQUFBLENBQU8zQixFQUFBLENBQUcyUixhQUFBLENBQWMsSUFBSWhRLE1BQUEsQ0FBT0wsSUFBSTtRQUNuRTtRQUVBLElBQUlLLE1BQUEsQ0FBT3lnQixRQUFBLEVBQVU7VUFDakJ6Z0IsTUFBQSxDQUFPdU8sRUFBQSxDQUFHSyxJQUFBLElBQVE7UUFDdEI7UUFHQSxJQUNJNU8sTUFBQSxDQUFPcU8sRUFBQSxJQUNQLE9BQU9yTyxNQUFBLENBQU9xTyxFQUFBLENBQUcxSCxDQUFBLEtBQU0sZUFDdkIzRyxNQUFBLENBQU9xTyxFQUFBLENBQUcxSCxDQUFBLEtBQU0wWixlQUFBLEVBQ2xCO1VBQ0UzaUIsZUFBQSxDQUFnQnNDLE1BQU0sRUFBRXZDLGVBQUEsR0FBa0I7UUFDOUM7TUFDSjtNQUVBLFNBQVM4aUIsc0JBQXNCdmdCLE1BQUEsRUFBUTtRQUNuQyxJQUFJNkcsQ0FBQSxFQUFHaUUsUUFBQSxFQUFVaEIsSUFBQSxFQUFNNUIsT0FBQSxFQUFTOE0sR0FBQSxFQUFLQyxHQUFBLEVBQUt5TCxJQUFBLEVBQU1DLGVBQUEsRUFBaUJDLE9BQUE7UUFFakUvWixDQUFBLEdBQUk3RyxNQUFBLENBQU9xTyxFQUFBO1FBQ1gsSUFBSXhILENBQUEsQ0FBRTZDLEVBQUEsSUFBTSxRQUFRN0MsQ0FBQSxDQUFFa0QsQ0FBQSxJQUFLLFFBQVFsRCxDQUFBLENBQUVzQixDQUFBLElBQUssTUFBTTtVQUM1QzZNLEdBQUEsR0FBTTtVQUNOQyxHQUFBLEdBQU07VUFNTm5LLFFBQUEsR0FBV2dWLFFBQUEsQ0FDUGpaLENBQUEsQ0FBRTZDLEVBQUEsRUFDRjFKLE1BQUEsQ0FBT3VPLEVBQUEsQ0FBR0UsSUFBQSxHQUNWZ0gsVUFBQSxDQUFXb0wsV0FBQSxDQUFZLEdBQUcsR0FBRyxDQUFDLEVBQUUxVyxJQUNwQztVQUNBTCxJQUFBLEdBQU9nVyxRQUFBLENBQVNqWixDQUFBLENBQUVrRCxDQUFBLEVBQUcsQ0FBQztVQUN0QjdCLE9BQUEsR0FBVTRYLFFBQUEsQ0FBU2paLENBQUEsQ0FBRXNCLENBQUEsRUFBRyxDQUFDO1VBQ3pCLElBQUlELE9BQUEsR0FBVSxLQUFLQSxPQUFBLEdBQVUsR0FBRztZQUM1QnlZLGVBQUEsR0FBa0I7VUFDdEI7UUFDSixPQUFPO1VBQ0gzTCxHQUFBLEdBQU1oVixNQUFBLENBQU9GLE9BQUEsQ0FBUWdXLEtBQUEsQ0FBTWQsR0FBQTtVQUMzQkMsR0FBQSxHQUFNalYsTUFBQSxDQUFPRixPQUFBLENBQVFnVyxLQUFBLENBQU1iLEdBQUE7VUFFM0IyTCxPQUFBLEdBQVVuTCxVQUFBLENBQVdvTCxXQUFBLENBQVksR0FBRzdMLEdBQUEsRUFBS0MsR0FBRztVQUU1Q25LLFFBQUEsR0FBV2dWLFFBQUEsQ0FBU2paLENBQUEsQ0FBRTBDLEVBQUEsRUFBSXZKLE1BQUEsQ0FBT3VPLEVBQUEsQ0FBR0UsSUFBQSxHQUFPbVMsT0FBQSxDQUFRelcsSUFBSTtVQUd2REwsSUFBQSxHQUFPZ1csUUFBQSxDQUFTalosQ0FBQSxDQUFFQSxDQUFBLEVBQUcrWixPQUFBLENBQVE5VyxJQUFJO1VBRWpDLElBQUlqRCxDQUFBLENBQUVGLENBQUEsSUFBSyxNQUFNO1lBRWJ1QixPQUFBLEdBQVVyQixDQUFBLENBQUVGLENBQUE7WUFDWixJQUFJdUIsT0FBQSxHQUFVLEtBQUtBLE9BQUEsR0FBVSxHQUFHO2NBQzVCeVksZUFBQSxHQUFrQjtZQUN0QjtVQUNKLFdBQVc5WixDQUFBLENBQUVtQixDQUFBLElBQUssTUFBTTtZQUVwQkUsT0FBQSxHQUFVckIsQ0FBQSxDQUFFbUIsQ0FBQSxHQUFJZ04sR0FBQTtZQUNoQixJQUFJbk8sQ0FBQSxDQUFFbUIsQ0FBQSxHQUFJLEtBQUtuQixDQUFBLENBQUVtQixDQUFBLEdBQUksR0FBRztjQUNwQjJZLGVBQUEsR0FBa0I7WUFDdEI7VUFDSixPQUFPO1lBRUh6WSxPQUFBLEdBQVU4TSxHQUFBO1VBQ2Q7UUFDSjtRQUNBLElBQUlsTCxJQUFBLEdBQU8sS0FBS0EsSUFBQSxHQUFPNkwsV0FBQSxDQUFZN0ssUUFBQSxFQUFVa0ssR0FBQSxFQUFLQyxHQUFHLEdBQUc7VUFDcER2WCxlQUFBLENBQWdCc0MsTUFBTSxFQUFFd2MsY0FBQSxHQUFpQjtRQUM3QyxXQUFXbUUsZUFBQSxJQUFtQixNQUFNO1VBQ2hDampCLGVBQUEsQ0FBZ0JzQyxNQUFNLEVBQUV5YyxnQkFBQSxHQUFtQjtRQUMvQyxPQUFPO1VBQ0hpRSxJQUFBLEdBQU90TCxrQkFBQSxDQUFtQnRLLFFBQUEsRUFBVWhCLElBQUEsRUFBTTVCLE9BQUEsRUFBUzhNLEdBQUEsRUFBS0MsR0FBRztVQUMzRGpWLE1BQUEsQ0FBT3VPLEVBQUEsQ0FBR0UsSUFBQSxJQUFRaVMsSUFBQSxDQUFLdlcsSUFBQTtVQUN2Qm5LLE1BQUEsQ0FBT3dnQixVQUFBLEdBQWFFLElBQUEsQ0FBSzdWLFNBQUE7UUFDN0I7TUFDSjtNQUdBN1EsS0FBQSxDQUFNOG1CLFFBQUEsR0FBVyxZQUFZLENBQUM7TUFHOUI5bUIsS0FBQSxDQUFNK21CLFFBQUEsR0FBVyxZQUFZLENBQUM7TUFHOUIsU0FBUzNDLDBCQUEwQnBlLE1BQUEsRUFBUTtRQUV2QyxJQUFJQSxNQUFBLENBQU9QLEVBQUEsS0FBT3pGLEtBQUEsQ0FBTThtQixRQUFBLEVBQVU7VUFDOUJuRCxhQUFBLENBQWMzZCxNQUFNO1VBQ3BCO1FBQ0o7UUFDQSxJQUFJQSxNQUFBLENBQU9QLEVBQUEsS0FBT3pGLEtBQUEsQ0FBTSttQixRQUFBLEVBQVU7VUFDOUJ0QixpQkFBQSxDQUFrQnpmLE1BQU07VUFDeEI7UUFDSjtRQUNBQSxNQUFBLENBQU91TyxFQUFBLEdBQUssRUFBQztRQUNiN1EsZUFBQSxDQUFnQnNDLE1BQU0sRUFBRXRELEtBQUEsR0FBUTtRQUdoQyxJQUFJMkssTUFBQSxHQUFTLEtBQUtySCxNQUFBLENBQU9SLEVBQUE7VUFDckIxRCxDQUFBO1VBQ0FtakIsV0FBQTtVQUNBK0IsT0FBQTtVQUNBaGQsTUFBQTtVQUNBaWQsT0FBQTtVQUNBQyxZQUFBLEdBQWU3WixNQUFBLENBQU9qTSxNQUFBO1VBQ3RCK2xCLHNCQUFBLEdBQXlCO1VBQ3pCN2pCLEdBQUE7VUFDQTRRLFFBQUE7UUFFSjhTLE9BQUEsR0FDSWxjLFlBQUEsQ0FBYTlFLE1BQUEsQ0FBT1AsRUFBQSxFQUFJTyxNQUFBLENBQU9GLE9BQU8sRUFBRXlFLEtBQUEsQ0FBTVosZ0JBQWdCLEtBQUssRUFBQztRQUN4RXVLLFFBQUEsR0FBVzhTLE9BQUEsQ0FBTzVsQixNQUFBO1FBQ2xCLEtBQUtVLENBQUEsR0FBSSxHQUFHQSxDQUFBLEdBQUlvUyxRQUFBLEVBQVVwUyxDQUFBLElBQUs7VUFDM0JrSSxNQUFBLEdBQVFnZCxPQUFBLENBQU9sbEIsQ0FBQTtVQUNmbWpCLFdBQUEsSUFBZTVYLE1BQUEsQ0FBTzlDLEtBQUEsQ0FBTXlJLHFCQUFBLENBQXNCaEosTUFBQSxFQUFPaEUsTUFBTSxDQUFDLEtBQzVELEVBQUMsRUFBRztVQUNSLElBQUlpZixXQUFBLEVBQWE7WUFDYmdDLE9BQUEsR0FBVTVaLE1BQUEsQ0FBTzNELE1BQUEsQ0FBTyxHQUFHMkQsTUFBQSxDQUFPMEssT0FBQSxDQUFRa04sV0FBVyxDQUFDO1lBQ3RELElBQUlnQyxPQUFBLENBQVE3bEIsTUFBQSxHQUFTLEdBQUc7Y0FDcEJzQyxlQUFBLENBQWdCc0MsTUFBTSxFQUFFcEQsV0FBQSxDQUFZWixJQUFBLENBQUtpbEIsT0FBTztZQUNwRDtZQUNBNVosTUFBQSxHQUFTQSxNQUFBLENBQU92RyxLQUFBLENBQ1p1RyxNQUFBLENBQU8wSyxPQUFBLENBQVFrTixXQUFXLElBQUlBLFdBQUEsQ0FBWTdqQixNQUM5QztZQUNBK2xCLHNCQUFBLElBQTBCbEMsV0FBQSxDQUFZN2pCLE1BQUE7VUFDMUM7VUFFQSxJQUFJMEksb0JBQUEsQ0FBcUJFLE1BQUEsR0FBUTtZQUM3QixJQUFJaWIsV0FBQSxFQUFhO2NBQ2J2aEIsZUFBQSxDQUFnQnNDLE1BQU0sRUFBRXRELEtBQUEsR0FBUTtZQUNwQyxPQUFPO2NBQ0hnQixlQUFBLENBQWdCc0MsTUFBTSxFQUFFckQsWUFBQSxDQUFhWCxJQUFBLENBQUtnSSxNQUFLO1lBQ25EO1lBQ0FzSyx1QkFBQSxDQUF3QnRLLE1BQUEsRUFBT2liLFdBQUEsRUFBYWpmLE1BQU07VUFDdEQsV0FBV0EsTUFBQSxDQUFPdkIsT0FBQSxJQUFXLENBQUN3Z0IsV0FBQSxFQUFhO1lBQ3ZDdmhCLGVBQUEsQ0FBZ0JzQyxNQUFNLEVBQUVyRCxZQUFBLENBQWFYLElBQUEsQ0FBS2dJLE1BQUs7VUFDbkQ7UUFDSjtRQUdBdEcsZUFBQSxDQUFnQnNDLE1BQU0sRUFBRWxELGFBQUEsR0FDcEJva0IsWUFBQSxHQUFlQyxzQkFBQTtRQUNuQixJQUFJOVosTUFBQSxDQUFPak0sTUFBQSxHQUFTLEdBQUc7VUFDbkJzQyxlQUFBLENBQWdCc0MsTUFBTSxFQUFFcEQsV0FBQSxDQUFZWixJQUFBLENBQUtxTCxNQUFNO1FBQ25EO1FBR0EsSUFDSXJILE1BQUEsQ0FBT3VPLEVBQUEsQ0FBR0ssSUFBQSxLQUFTLE1BQ25CbFIsZUFBQSxDQUFnQnNDLE1BQU0sRUFBRXRCLE9BQUEsS0FBWSxRQUNwQ3NCLE1BQUEsQ0FBT3VPLEVBQUEsQ0FBR0ssSUFBQSxJQUFRLEdBQ3BCO1VBQ0VsUixlQUFBLENBQWdCc0MsTUFBTSxFQUFFdEIsT0FBQSxHQUFVO1FBQ3RDO1FBRUFoQixlQUFBLENBQWdCc0MsTUFBTSxFQUFFM0MsZUFBQSxHQUFrQjJDLE1BQUEsQ0FBT3VPLEVBQUEsQ0FBR3pOLEtBQUEsQ0FBTSxDQUFDO1FBQzNEcEQsZUFBQSxDQUFnQnNDLE1BQU0sRUFBRXpDLFFBQUEsR0FBV3lDLE1BQUEsQ0FBTzBaLFNBQUE7UUFFMUMxWixNQUFBLENBQU91TyxFQUFBLENBQUdLLElBQUEsSUFBUXdTLGVBQUEsQ0FDZHBoQixNQUFBLENBQU9GLE9BQUEsRUFDUEUsTUFBQSxDQUFPdU8sRUFBQSxDQUFHSyxJQUFBLEdBQ1Y1TyxNQUFBLENBQU8wWixTQUNYO1FBR0FwYyxHQUFBLEdBQU1JLGVBQUEsQ0FBZ0JzQyxNQUFNLEVBQUUxQyxHQUFBO1FBQzlCLElBQUlBLEdBQUEsS0FBUSxNQUFNO1VBQ2QwQyxNQUFBLENBQU91TyxFQUFBLENBQUdFLElBQUEsSUFBUXpPLE1BQUEsQ0FBT0YsT0FBQSxDQUFRdWhCLGVBQUEsQ0FBZ0IvakIsR0FBQSxFQUFLMEMsTUFBQSxDQUFPdU8sRUFBQSxDQUFHRSxJQUFBLENBQUs7UUFDekU7UUFFQTBSLGVBQUEsQ0FBZ0JuZ0IsTUFBTTtRQUN0QnNjLGFBQUEsQ0FBY3RjLE1BQU07TUFDeEI7TUFFQSxTQUFTb2hCLGdCQUFnQi9rQixPQUFBLEVBQVFxTSxJQUFBLEVBQU00WSxTQUFBLEVBQVU7UUFDN0MsSUFBSUMsSUFBQTtRQUVKLElBQUlELFNBQUEsSUFBWSxNQUFNO1VBRWxCLE9BQU81WSxJQUFBO1FBQ1g7UUFDQSxJQUFJck0sT0FBQSxDQUFPbWxCLFlBQUEsSUFBZ0IsTUFBTTtVQUM3QixPQUFPbmxCLE9BQUEsQ0FBT21sQixZQUFBLENBQWE5WSxJQUFBLEVBQU00WSxTQUFRO1FBQzdDLFdBQVdqbEIsT0FBQSxDQUFPb2QsSUFBQSxJQUFRLE1BQU07VUFFNUI4SCxJQUFBLEdBQU9sbEIsT0FBQSxDQUFPb2QsSUFBQSxDQUFLNkgsU0FBUTtVQUMzQixJQUFJQyxJQUFBLElBQVE3WSxJQUFBLEdBQU8sSUFBSTtZQUNuQkEsSUFBQSxJQUFRO1VBQ1o7VUFDQSxJQUFJLENBQUM2WSxJQUFBLElBQVE3WSxJQUFBLEtBQVMsSUFBSTtZQUN0QkEsSUFBQSxHQUFPO1VBQ1g7VUFDQSxPQUFPQSxJQUFBO1FBQ1gsT0FBTztVQUVILE9BQU9BLElBQUE7UUFDWDtNQUNKO01BR0EsU0FBUytZLHlCQUF5QnpoQixNQUFBLEVBQVE7UUFDdEMsSUFBSTBoQixVQUFBO1VBQ0FDLFVBQUE7VUFDQUMsV0FBQTtVQUNBOWxCLENBQUE7VUFDQStsQixZQUFBO1VBQ0FDLGdCQUFBO1VBQ0FDLGlCQUFBLEdBQW9CO1VBQ3BCQyxVQUFBLEdBQWFoaUIsTUFBQSxDQUFPUCxFQUFBLENBQUdyRSxNQUFBO1FBRTNCLElBQUk0bUIsVUFBQSxLQUFlLEdBQUc7VUFDbEJ0a0IsZUFBQSxDQUFnQnNDLE1BQU0sRUFBRTlDLGFBQUEsR0FBZ0I7VUFDeEM4QyxNQUFBLENBQU8zQixFQUFBLEdBQUssSUFBSTVDLElBQUEsQ0FBS3FELEdBQUc7VUFDeEI7UUFDSjtRQUVBLEtBQUtoRCxDQUFBLEdBQUksR0FBR0EsQ0FBQSxHQUFJa21CLFVBQUEsRUFBWWxtQixDQUFBLElBQUs7VUFDN0IrbEIsWUFBQSxHQUFlO1VBQ2ZDLGdCQUFBLEdBQW1CO1VBQ25CSixVQUFBLEdBQWF6aUIsVUFBQSxDQUFXLENBQUMsR0FBR2UsTUFBTTtVQUNsQyxJQUFJQSxNQUFBLENBQU82ZixPQUFBLElBQVcsTUFBTTtZQUN4QjZCLFVBQUEsQ0FBVzdCLE9BQUEsR0FBVTdmLE1BQUEsQ0FBTzZmLE9BQUE7VUFDaEM7VUFDQTZCLFVBQUEsQ0FBV2ppQixFQUFBLEdBQUtPLE1BQUEsQ0FBT1AsRUFBQSxDQUFHM0QsQ0FBQTtVQUMxQnNpQix5QkFBQSxDQUEwQnNELFVBQVU7VUFFcEMsSUFBSXpqQixPQUFBLENBQVF5akIsVUFBVSxHQUFHO1lBQ3JCSSxnQkFBQSxHQUFtQjtVQUN2QjtVQUdBRCxZQUFBLElBQWdCbmtCLGVBQUEsQ0FBZ0Jna0IsVUFBVSxFQUFFNWtCLGFBQUE7VUFHNUMra0IsWUFBQSxJQUFnQm5rQixlQUFBLENBQWdCZ2tCLFVBQVUsRUFBRS9rQixZQUFBLENBQWF2QixNQUFBLEdBQVM7VUFFbEVzQyxlQUFBLENBQWdCZ2tCLFVBQVUsRUFBRU8sS0FBQSxHQUFRSixZQUFBO1VBRXBDLElBQUksQ0FBQ0UsaUJBQUEsRUFBbUI7WUFDcEIsSUFDSUgsV0FBQSxJQUFlLFFBQ2ZDLFlBQUEsR0FBZUQsV0FBQSxJQUNmRSxnQkFBQSxFQUNGO2NBQ0VGLFdBQUEsR0FBY0MsWUFBQTtjQUNkRixVQUFBLEdBQWFELFVBQUE7Y0FDYixJQUFJSSxnQkFBQSxFQUFrQjtnQkFDbEJDLGlCQUFBLEdBQW9CO2NBQ3hCO1lBQ0o7VUFDSixPQUFPO1lBQ0gsSUFBSUYsWUFBQSxHQUFlRCxXQUFBLEVBQWE7Y0FDNUJBLFdBQUEsR0FBY0MsWUFBQTtjQUNkRixVQUFBLEdBQWFELFVBQUE7WUFDakI7VUFDSjtRQUNKO1FBRUF6bEIsTUFBQSxDQUFPK0QsTUFBQSxFQUFRMmhCLFVBQUEsSUFBY0QsVUFBVTtNQUMzQztNQUVBLFNBQVNRLGlCQUFpQmxpQixNQUFBLEVBQVE7UUFDOUIsSUFBSUEsTUFBQSxDQUFPM0IsRUFBQSxFQUFJO1VBQ1g7UUFDSjtRQUVBLElBQUl2QyxDQUFBLEdBQUl5TyxvQkFBQSxDQUFxQnZLLE1BQUEsQ0FBT1IsRUFBRTtVQUNsQzJpQixTQUFBLEdBQVlybUIsQ0FBQSxDQUFFaU0sR0FBQSxLQUFRLFNBQVlqTSxDQUFBLENBQUUrTCxJQUFBLEdBQU8vTCxDQUFBLENBQUVpTSxHQUFBO1FBQ2pEL0gsTUFBQSxDQUFPdU8sRUFBQSxHQUFLN1MsR0FBQSxDQUNSLENBQUNJLENBQUEsQ0FBRXFPLElBQUEsRUFBTXJPLENBQUEsQ0FBRW1OLEtBQUEsRUFBT2taLFNBQUEsRUFBV3JtQixDQUFBLENBQUU0TSxJQUFBLEVBQU01TSxDQUFBLENBQUVpTixNQUFBLEVBQVFqTixDQUFBLENBQUV3TixNQUFBLEVBQVF4TixDQUFBLENBQUUrTSxXQUFXLEdBQ3RFLFVBQVUzTixHQUFBLEVBQUs7VUFDWCxPQUFPQSxHQUFBLElBQU9pVSxRQUFBLENBQVNqVSxHQUFBLEVBQUssRUFBRTtRQUNsQyxDQUNKO1FBRUFpbEIsZUFBQSxDQUFnQm5nQixNQUFNO01BQzFCO01BRUEsU0FBU29pQixpQkFBaUJwaUIsTUFBQSxFQUFRO1FBQzlCLElBQUluRSxHQUFBLEdBQU0sSUFBSWtFLE1BQUEsQ0FBT3VjLGFBQUEsQ0FBYytGLGFBQUEsQ0FBY3JpQixNQUFNLENBQUMsQ0FBQztRQUN6RCxJQUFJbkUsR0FBQSxDQUFJNGtCLFFBQUEsRUFBVTtVQUVkNWtCLEdBQUEsQ0FBSXNhLEdBQUEsQ0FBSSxHQUFHLEdBQUc7VUFDZHRhLEdBQUEsQ0FBSTRrQixRQUFBLEdBQVc7UUFDbkI7UUFFQSxPQUFPNWtCLEdBQUE7TUFDWDtNQUVBLFNBQVN3bUIsY0FBY3JpQixNQUFBLEVBQVE7UUFDM0IsSUFBSTFGLEtBQUEsR0FBUTBGLE1BQUEsQ0FBT1IsRUFBQTtVQUNmcEQsT0FBQSxHQUFTNEQsTUFBQSxDQUFPUCxFQUFBO1FBRXBCTyxNQUFBLENBQU9GLE9BQUEsR0FBVUUsTUFBQSxDQUFPRixPQUFBLElBQVdnYyxTQUFBLENBQVU5YixNQUFBLENBQU9OLEVBQUU7UUFFdEQsSUFBSXBGLEtBQUEsS0FBVSxRQUFTOEIsT0FBQSxLQUFXLFVBQWE5QixLQUFBLEtBQVUsSUFBSztVQUMxRCxPQUFPdUUsYUFBQSxDQUFjO1lBQUU5QixTQUFBLEVBQVc7VUFBSyxDQUFDO1FBQzVDO1FBRUEsSUFBSSxPQUFPekMsS0FBQSxLQUFVLFVBQVU7VUFDM0IwRixNQUFBLENBQU9SLEVBQUEsR0FBS2xGLEtBQUEsR0FBUTBGLE1BQUEsQ0FBT0YsT0FBQSxDQUFRd2lCLFFBQUEsQ0FBU2hvQixLQUFLO1FBQ3JEO1FBRUEsSUFBSTRGLFFBQUEsQ0FBUzVGLEtBQUssR0FBRztVQUNqQixPQUFPLElBQUl5RixNQUFBLENBQU91YyxhQUFBLENBQWNoaUIsS0FBSyxDQUFDO1FBQzFDLFdBQVdrQixNQUFBLENBQU9sQixLQUFLLEdBQUc7VUFDdEIwRixNQUFBLENBQU8zQixFQUFBLEdBQUsvRCxLQUFBO1FBQ2hCLFdBQVdELE9BQUEsQ0FBUStCLE9BQU0sR0FBRztVQUN4QnFsQix3QkFBQSxDQUF5QnpoQixNQUFNO1FBQ25DLFdBQVc1RCxPQUFBLEVBQVE7VUFDZmdpQix5QkFBQSxDQUEwQnBlLE1BQU07UUFDcEMsT0FBTztVQUNIdWlCLGVBQUEsQ0FBZ0J2aUIsTUFBTTtRQUMxQjtRQUVBLElBQUksQ0FBQy9CLE9BQUEsQ0FBUStCLE1BQU0sR0FBRztVQUNsQkEsTUFBQSxDQUFPM0IsRUFBQSxHQUFLO1FBQ2hCO1FBRUEsT0FBTzJCLE1BQUE7TUFDWDtNQUVBLFNBQVN1aUIsZ0JBQWdCdmlCLE1BQUEsRUFBUTtRQUM3QixJQUFJMUYsS0FBQSxHQUFRMEYsTUFBQSxDQUFPUixFQUFBO1FBQ25CLElBQUlsRSxXQUFBLENBQVloQixLQUFLLEdBQUc7VUFDcEIwRixNQUFBLENBQU8zQixFQUFBLEdBQUssSUFBSTVDLElBQUEsQ0FBS3pCLEtBQUEsQ0FBTWttQixHQUFBLENBQUksQ0FBQztRQUNwQyxXQUFXMWtCLE1BQUEsQ0FBT2xCLEtBQUssR0FBRztVQUN0QjBGLE1BQUEsQ0FBTzNCLEVBQUEsR0FBSyxJQUFJNUMsSUFBQSxDQUFLbkIsS0FBQSxDQUFNNEIsT0FBQSxDQUFRLENBQUM7UUFDeEMsV0FBVyxPQUFPNUIsS0FBQSxLQUFVLFVBQVU7VUFDbENxbEIsZ0JBQUEsQ0FBaUIzZixNQUFNO1FBQzNCLFdBQVczRixPQUFBLENBQVFDLEtBQUssR0FBRztVQUN2QjBGLE1BQUEsQ0FBT3VPLEVBQUEsR0FBSzdTLEdBQUEsQ0FBSXBCLEtBQUEsQ0FBTXdHLEtBQUEsQ0FBTSxDQUFDLEdBQUcsVUFBVTVGLEdBQUEsRUFBSztZQUMzQyxPQUFPaVUsUUFBQSxDQUFTalUsR0FBQSxFQUFLLEVBQUU7VUFDM0IsQ0FBQztVQUNEaWxCLGVBQUEsQ0FBZ0JuZ0IsTUFBTTtRQUMxQixXQUFXcEYsUUFBQSxDQUFTTixLQUFLLEdBQUc7VUFDeEI0bkIsZ0JBQUEsQ0FBaUJsaUIsTUFBTTtRQUMzQixXQUFXekUsUUFBQSxDQUFTakIsS0FBSyxHQUFHO1VBRXhCMEYsTUFBQSxDQUFPM0IsRUFBQSxHQUFLLElBQUk1QyxJQUFBLENBQUtuQixLQUFLO1FBQzlCLE9BQU87VUFDSE4sS0FBQSxDQUFNNGxCLHVCQUFBLENBQXdCNWYsTUFBTTtRQUN4QztNQUNKO01BRUEsU0FBU3pELGlCQUFpQmpDLEtBQUEsRUFBTzhCLE9BQUEsRUFBUUMsT0FBQSxFQUFRQyxNQUFBLEVBQVFxVCxLQUFBLEVBQU87UUFDNUQsSUFBSW9RLENBQUEsR0FBSSxDQUFDO1FBRVQsSUFBSTNqQixPQUFBLEtBQVcsUUFBUUEsT0FBQSxLQUFXLE9BQU87VUFDckNFLE1BQUEsR0FBU0YsT0FBQTtVQUNUQSxPQUFBLEdBQVM7UUFDYjtRQUVBLElBQUlDLE9BQUEsS0FBVyxRQUFRQSxPQUFBLEtBQVcsT0FBTztVQUNyQ0MsTUFBQSxHQUFTRCxPQUFBO1VBQ1RBLE9BQUEsR0FBUztRQUNiO1FBRUEsSUFDS3pCLFFBQUEsQ0FBU04sS0FBSyxLQUFLVyxhQUFBLENBQWNYLEtBQUssS0FDdENELE9BQUEsQ0FBUUMsS0FBSyxLQUFLQSxLQUFBLENBQU1jLE1BQUEsS0FBVyxHQUN0QztVQUNFZCxLQUFBLEdBQVE7UUFDWjtRQUdBeWxCLENBQUEsQ0FBRXhnQixnQkFBQSxHQUFtQjtRQUNyQndnQixDQUFBLENBQUVGLE9BQUEsR0FBVUUsQ0FBQSxDQUFFbmdCLE1BQUEsR0FBUytQLEtBQUE7UUFDdkJvUSxDQUFBLENBQUVyZ0IsRUFBQSxHQUFLckQsT0FBQTtRQUNQMGpCLENBQUEsQ0FBRXZnQixFQUFBLEdBQUtsRixLQUFBO1FBQ1B5bEIsQ0FBQSxDQUFFdGdCLEVBQUEsR0FBS3JELE9BQUE7UUFDUDJqQixDQUFBLENBQUV0aEIsT0FBQSxHQUFVbkMsTUFBQTtRQUVaLE9BQU84bEIsZ0JBQUEsQ0FBaUJyQyxDQUFDO01BQzdCO01BRUEsU0FBU2MsWUFBWXZtQixLQUFBLEVBQU84QixPQUFBLEVBQVFDLE9BQUEsRUFBUUMsTUFBQSxFQUFRO1FBQ2hELE9BQU9DLGdCQUFBLENBQWlCakMsS0FBQSxFQUFPOEIsT0FBQSxFQUFRQyxPQUFBLEVBQVFDLE1BQUEsRUFBUSxLQUFLO01BQ2hFO01BRUEsSUFBSWttQixZQUFBLEdBQWVqaUIsU0FBQSxDQUNYLHNHQUNBLFlBQVk7VUFDUixJQUFJa2lCLEtBQUEsR0FBUTVCLFdBQUEsQ0FBWTVtQixLQUFBLENBQU0sTUFBTUMsU0FBUztVQUM3QyxJQUFJLEtBQUsrRCxPQUFBLENBQVEsS0FBS3drQixLQUFBLENBQU14a0IsT0FBQSxDQUFRLEdBQUc7WUFDbkMsT0FBT3drQixLQUFBLEdBQVEsT0FBTyxPQUFPQSxLQUFBO1VBQ2pDLE9BQU87WUFDSCxPQUFPNWpCLGFBQUEsQ0FBYztVQUN6QjtRQUNKLENBQ0o7UUFDQTZqQixZQUFBLEdBQWVuaUIsU0FBQSxDQUNYLHNHQUNBLFlBQVk7VUFDUixJQUFJa2lCLEtBQUEsR0FBUTVCLFdBQUEsQ0FBWTVtQixLQUFBLENBQU0sTUFBTUMsU0FBUztVQUM3QyxJQUFJLEtBQUsrRCxPQUFBLENBQVEsS0FBS3drQixLQUFBLENBQU14a0IsT0FBQSxDQUFRLEdBQUc7WUFDbkMsT0FBT3drQixLQUFBLEdBQVEsT0FBTyxPQUFPQSxLQUFBO1VBQ2pDLE9BQU87WUFDSCxPQUFPNWpCLGFBQUEsQ0FBYztVQUN6QjtRQUNKLENBQ0o7TUFPSixTQUFTOGpCLE9BQU8vbUIsRUFBQSxFQUFJZ25CLE9BQUEsRUFBUztRQUN6QixJQUFJL21CLEdBQUEsRUFBS0MsQ0FBQTtRQUNULElBQUk4bUIsT0FBQSxDQUFReG5CLE1BQUEsS0FBVyxLQUFLZixPQUFBLENBQVF1b0IsT0FBQSxDQUFRLEVBQUUsR0FBRztVQUM3Q0EsT0FBQSxHQUFVQSxPQUFBLENBQVE7UUFDdEI7UUFDQSxJQUFJLENBQUNBLE9BQUEsQ0FBUXhuQixNQUFBLEVBQVE7VUFDakIsT0FBT3lsQixXQUFBLENBQVk7UUFDdkI7UUFDQWhsQixHQUFBLEdBQU0rbUIsT0FBQSxDQUFRO1FBQ2QsS0FBSzltQixDQUFBLEdBQUksR0FBR0EsQ0FBQSxHQUFJOG1CLE9BQUEsQ0FBUXhuQixNQUFBLEVBQVEsRUFBRVUsQ0FBQSxFQUFHO1VBQ2pDLElBQUksQ0FBQzhtQixPQUFBLENBQVE5bUIsQ0FBQSxFQUFHbUMsT0FBQSxDQUFRLEtBQUsya0IsT0FBQSxDQUFROW1CLENBQUEsRUFBR0YsRUFBQSxFQUFJQyxHQUFHLEdBQUc7WUFDOUNBLEdBQUEsR0FBTSttQixPQUFBLENBQVE5bUIsQ0FBQTtVQUNsQjtRQUNKO1FBQ0EsT0FBT0QsR0FBQTtNQUNYO01BR0EsU0FBU2dZLElBQUEsRUFBTTtRQUNYLElBQUluVCxJQUFBLEdBQU8sRUFBQyxDQUFFSSxLQUFBLENBQU1uRyxJQUFBLENBQUtULFNBQUEsRUFBVyxDQUFDO1FBRXJDLE9BQU95b0IsTUFBQSxDQUFPLFlBQVlqaUIsSUFBSTtNQUNsQztNQUVBLFNBQVMrQyxJQUFBLEVBQU07UUFDWCxJQUFJL0MsSUFBQSxHQUFPLEVBQUMsQ0FBRUksS0FBQSxDQUFNbkcsSUFBQSxDQUFLVCxTQUFBLEVBQVcsQ0FBQztRQUVyQyxPQUFPeW9CLE1BQUEsQ0FBTyxXQUFXamlCLElBQUk7TUFDakM7TUFFQSxJQUFJd2YsR0FBQSxHQUFNLFNBQUFBLENBQUEsRUFBWTtRQUNsQixPQUFPemtCLElBQUEsQ0FBS3lrQixHQUFBLEdBQU16a0IsSUFBQSxDQUFLeWtCLEdBQUEsQ0FBSSxJQUFJLENBQUMsSUFBSXprQixJQUFBLENBQUs7TUFDN0M7TUFFQSxJQUFJb25CLFFBQUEsR0FBVyxDQUNYLFFBQ0EsV0FDQSxTQUNBLFFBQ0EsT0FDQSxRQUNBLFVBQ0EsVUFDQSxjQUNKO01BRUEsU0FBU0MsZ0JBQWdCbmxCLENBQUEsRUFBRztRQUN4QixJQUFJaUQsR0FBQTtVQUNBbWlCLGNBQUEsR0FBaUI7VUFDakJqbkIsQ0FBQTtVQUNBa25CLFFBQUEsR0FBV0gsUUFBQSxDQUFTem5CLE1BQUE7UUFDeEIsS0FBS3dGLEdBQUEsSUFBT2pELENBQUEsRUFBRztVQUNYLElBQ0k5QyxVQUFBLENBQVc4QyxDQUFBLEVBQUdpRCxHQUFHLEtBQ2pCLEVBQ0ltUixPQUFBLENBQVFwWCxJQUFBLENBQUtrb0IsUUFBQSxFQUFVamlCLEdBQUcsTUFBTSxPQUMvQmpELENBQUEsQ0FBRWlELEdBQUEsS0FBUSxRQUFRLENBQUN0QyxLQUFBLENBQU1YLENBQUEsQ0FBRWlELEdBQUEsQ0FBSSxLQUV0QztZQUNFLE9BQU87VUFDWDtRQUNKO1FBRUEsS0FBSzlFLENBQUEsR0FBSSxHQUFHQSxDQUFBLEdBQUlrbkIsUUFBQSxFQUFVLEVBQUVsbkIsQ0FBQSxFQUFHO1VBQzNCLElBQUk2QixDQUFBLENBQUVrbEIsUUFBQSxDQUFTL21CLENBQUEsSUFBSztZQUNoQixJQUFJaW5CLGNBQUEsRUFBZ0I7Y0FDaEIsT0FBTztZQUNYO1lBQ0EsSUFBSUUsVUFBQSxDQUFXdGxCLENBQUEsQ0FBRWtsQixRQUFBLENBQVMvbUIsQ0FBQSxFQUFHLE1BQU02UixLQUFBLENBQU1oUSxDQUFBLENBQUVrbEIsUUFBQSxDQUFTL21CLENBQUEsRUFBRyxHQUFHO2NBQ3REaW5CLGNBQUEsR0FBaUI7WUFDckI7VUFDSjtRQUNKO1FBRUEsT0FBTztNQUNYO01BRUEsU0FBU0csVUFBQSxFQUFZO1FBQ2pCLE9BQU8sS0FBS3RrQixRQUFBO01BQ2hCO01BRUEsU0FBU3VrQixnQkFBQSxFQUFrQjtRQUN2QixPQUFPQyxjQUFBLENBQWV0a0IsR0FBRztNQUM3QjtNQUVBLFNBQVN1a0IsU0FBU0MsUUFBQSxFQUFVO1FBQ3hCLElBQUk3WSxlQUFBLEdBQWtCRixvQkFBQSxDQUFxQitZLFFBQVE7VUFDL0NDLE1BQUEsR0FBUTlZLGVBQUEsQ0FBZ0JOLElBQUEsSUFBUTtVQUNoQ2hCLFFBQUEsR0FBV3NCLGVBQUEsQ0FBZ0JyQixPQUFBLElBQVc7VUFDdENvYSxPQUFBLEdBQVMvWSxlQUFBLENBQWdCeEIsS0FBQSxJQUFTO1VBQ2xDd2EsTUFBQSxHQUFRaFosZUFBQSxDQUFnQlgsSUFBQSxJQUFRVyxlQUFBLENBQWdCTyxPQUFBLElBQVc7VUFDM0QwWSxLQUFBLEdBQU9qWixlQUFBLENBQWdCMUMsR0FBQSxJQUFPO1VBQzlCb1MsTUFBQSxHQUFRMVAsZUFBQSxDQUFnQi9CLElBQUEsSUFBUTtVQUNoQzBSLFFBQUEsR0FBVTNQLGVBQUEsQ0FBZ0IxQixNQUFBLElBQVU7VUFDcEM0YSxRQUFBLEdBQVVsWixlQUFBLENBQWdCbkIsTUFBQSxJQUFVO1VBQ3BDc2EsYUFBQSxHQUFlblosZUFBQSxDQUFnQjVCLFdBQUEsSUFBZTtRQUVsRCxLQUFLakssUUFBQSxHQUFXa2tCLGVBQUEsQ0FBZ0JyWSxlQUFlO1FBRy9DLEtBQUtvWixhQUFBLEdBQ0QsQ0FBQ0QsYUFBQSxHQUNERCxRQUFBLEdBQVUsTUFDVnZKLFFBQUEsR0FBVSxNQUNWRCxNQUFBLEdBQVEsTUFBTyxLQUFLO1FBR3hCLEtBQUsySixLQUFBLEdBQVEsQ0FBQ0osS0FBQSxHQUFPRCxNQUFBLEdBQVE7UUFJN0IsS0FBSzNRLE9BQUEsR0FBVSxDQUFDMFEsT0FBQSxHQUFTcmEsUUFBQSxHQUFXLElBQUlvYSxNQUFBLEdBQVE7UUFFaEQsS0FBS1EsS0FBQSxHQUFRLENBQUM7UUFFZCxLQUFLamtCLE9BQUEsR0FBVWdjLFNBQUEsQ0FBVTtRQUV6QixLQUFLa0ksT0FBQSxDQUFRO01BQ2pCO01BRUEsU0FBU0MsV0FBVy9vQixHQUFBLEVBQUs7UUFDckIsT0FBT0EsR0FBQSxZQUFlbW9CLFFBQUE7TUFDMUI7TUFFQSxTQUFTYSxTQUFTbGhCLE1BQUEsRUFBUTtRQUN0QixJQUFJQSxNQUFBLEdBQVMsR0FBRztVQUNaLE9BQU9JLElBQUEsQ0FBSytnQixLQUFBLENBQU0sS0FBS25oQixNQUFNLElBQUk7UUFDckMsT0FBTztVQUNILE9BQU9JLElBQUEsQ0FBSytnQixLQUFBLENBQU1uaEIsTUFBTTtRQUM1QjtNQUNKO01BR0EsU0FBU29oQixjQUFjQyxNQUFBLEVBQVFDLE1BQUEsRUFBUUMsV0FBQSxFQUFhO1FBQ2hELElBQUl2bUIsR0FBQSxHQUFNb0YsSUFBQSxDQUFLeVEsR0FBQSxDQUFJd1EsTUFBQSxDQUFPanBCLE1BQUEsRUFBUWtwQixNQUFBLENBQU9scEIsTUFBTTtVQUMzQ29wQixVQUFBLEdBQWFwaEIsSUFBQSxDQUFLQyxHQUFBLENBQUlnaEIsTUFBQSxDQUFPanBCLE1BQUEsR0FBU2twQixNQUFBLENBQU9scEIsTUFBTTtVQUNuRHFwQixLQUFBLEdBQVE7VUFDUjNvQixDQUFBO1FBQ0osS0FBS0EsQ0FBQSxHQUFJLEdBQUdBLENBQUEsR0FBSWtDLEdBQUEsRUFBS2xDLENBQUEsSUFBSztVQUN0QixJQUNLeW9CLFdBQUEsSUFBZUYsTUFBQSxDQUFPdm9CLENBQUEsTUFBT3dvQixNQUFBLENBQU94b0IsQ0FBQSxLQUNwQyxDQUFDeW9CLFdBQUEsSUFBZTVXLEtBQUEsQ0FBTTBXLE1BQUEsQ0FBT3ZvQixDQUFBLENBQUUsTUFBTTZSLEtBQUEsQ0FBTTJXLE1BQUEsQ0FBT3hvQixDQUFBLENBQUUsR0FDdkQ7WUFDRTJvQixLQUFBO1VBQ0o7UUFDSjtRQUNBLE9BQU9BLEtBQUEsR0FBUUQsVUFBQTtNQUNuQjtNQUlBLFNBQVNFLE9BQU8xZ0IsTUFBQSxFQUFPMmdCLFNBQUEsRUFBVztRQUM5QjVnQixjQUFBLENBQWVDLE1BQUEsRUFBTyxHQUFHLEdBQUcsWUFBWTtVQUNwQyxJQUFJNGdCLE9BQUEsR0FBUyxLQUFLQyxTQUFBLENBQVU7WUFDeEJ0aEIsS0FBQSxHQUFPO1VBQ1gsSUFBSXFoQixPQUFBLEdBQVMsR0FBRztZQUNaQSxPQUFBLEdBQVMsQ0FBQ0EsT0FBQTtZQUNWcmhCLEtBQUEsR0FBTztVQUNYO1VBQ0EsT0FDSUEsS0FBQSxHQUNBUixRQUFBLENBQVMsQ0FBQyxFQUFFNmhCLE9BQUEsR0FBUyxLQUFLLENBQUMsSUFDM0JELFNBQUEsR0FDQTVoQixRQUFBLENBQVMsQ0FBQyxDQUFDNmhCLE9BQUEsR0FBUyxJQUFJLENBQUM7UUFFakMsQ0FBQztNQUNMO01BRUFGLE1BQUEsQ0FBTyxLQUFLLEdBQUc7TUFDZkEsTUFBQSxDQUFPLE1BQU0sRUFBRTtNQUlmL1gsYUFBQSxDQUFjLEtBQUtOLGdCQUFnQjtNQUNuQ00sYUFBQSxDQUFjLE1BQU1OLGdCQUFnQjtNQUNwQzRCLGFBQUEsQ0FBYyxDQUFDLEtBQUssSUFBSSxHQUFHLFVBQVUzVCxLQUFBLEVBQU9vSyxLQUFBLEVBQU8xRSxNQUFBLEVBQVE7UUFDdkRBLE1BQUEsQ0FBTzZmLE9BQUEsR0FBVTtRQUNqQjdmLE1BQUEsQ0FBT0wsSUFBQSxHQUFPbWxCLGdCQUFBLENBQWlCelksZ0JBQUEsRUFBa0IvUixLQUFLO01BQzFELENBQUM7TUFPRCxJQUFJeXFCLFdBQUEsR0FBYztNQUVsQixTQUFTRCxpQkFBaUJFLE9BQUEsRUFBUzNkLE1BQUEsRUFBUTtRQUN2QyxJQUFJNGQsT0FBQSxJQUFXNWQsTUFBQSxJQUFVLElBQUk5QyxLQUFBLENBQU15Z0IsT0FBTztVQUN0Q0UsS0FBQTtVQUNBQyxLQUFBO1VBQ0EvSyxRQUFBO1FBRUosSUFBSTZLLE9BQUEsS0FBWSxNQUFNO1VBQ2xCLE9BQU87UUFDWDtRQUVBQyxLQUFBLEdBQVFELE9BQUEsQ0FBUUEsT0FBQSxDQUFRN3BCLE1BQUEsR0FBUyxNQUFNLEVBQUM7UUFDeEMrcEIsS0FBQSxJQUFTRCxLQUFBLEdBQVEsSUFBSTNnQixLQUFBLENBQU13Z0IsV0FBVyxLQUFLLENBQUMsS0FBSyxHQUFHLENBQUM7UUFDckQzSyxRQUFBLEdBQVUsRUFBRStLLEtBQUEsQ0FBTSxLQUFLLE1BQU14WCxLQUFBLENBQU13WCxLQUFBLENBQU0sRUFBRTtRQUUzQyxPQUFPL0ssUUFBQSxLQUFZLElBQUksSUFBSStLLEtBQUEsQ0FBTSxPQUFPLE1BQU0vSyxRQUFBLEdBQVUsQ0FBQ0EsUUFBQTtNQUM3RDtNQUdBLFNBQVNnTCxnQkFBZ0I5cUIsS0FBQSxFQUFPK3FCLEtBQUEsRUFBTztRQUNuQyxJQUFJeHBCLEdBQUEsRUFBSzRMLEtBQUE7UUFDVCxJQUFJNGQsS0FBQSxDQUFNemxCLE1BQUEsRUFBUTtVQUNkL0QsR0FBQSxHQUFNd3BCLEtBQUEsQ0FBTUMsS0FBQSxDQUFNO1VBQ2xCN2QsS0FBQSxJQUNLdkgsUUFBQSxDQUFTNUYsS0FBSyxLQUFLa0IsTUFBQSxDQUFPbEIsS0FBSyxJQUMxQkEsS0FBQSxDQUFNNEIsT0FBQSxDQUFRLElBQ2Qya0IsV0FBQSxDQUFZdm1CLEtBQUssRUFBRTRCLE9BQUEsQ0FBUSxLQUFLTCxHQUFBLENBQUlLLE9BQUEsQ0FBUTtVQUV0REwsR0FBQSxDQUFJd0MsRUFBQSxDQUFHa25CLE9BQUEsQ0FBUTFwQixHQUFBLENBQUl3QyxFQUFBLENBQUduQyxPQUFBLENBQVEsSUFBSXVMLEtBQUk7VUFDdEN6TixLQUFBLENBQU1pRyxZQUFBLENBQWFwRSxHQUFBLEVBQUssS0FBSztVQUM3QixPQUFPQSxHQUFBO1FBQ1gsT0FBTztVQUNILE9BQU9nbEIsV0FBQSxDQUFZdm1CLEtBQUssRUFBRWtyQixLQUFBLENBQU07UUFDcEM7TUFDSjtNQUVBLFNBQVNDLGNBQWM5bkIsQ0FBQSxFQUFHO1FBR3RCLE9BQU8sQ0FBQ3lGLElBQUEsQ0FBSytnQixLQUFBLENBQU14bUIsQ0FBQSxDQUFFVSxFQUFBLENBQUdxbkIsaUJBQUEsQ0FBa0IsQ0FBQztNQUMvQztNQU1BMXJCLEtBQUEsQ0FBTWlHLFlBQUEsR0FBZSxZQUFZLENBQUM7TUFjbEMsU0FBUzBsQixhQUFhcnJCLEtBQUEsRUFBT3NyQixhQUFBLEVBQWVDLFdBQUEsRUFBYTtRQUNyRCxJQUFJakIsT0FBQSxHQUFTLEtBQUsva0IsT0FBQSxJQUFXO1VBQ3pCaW1CLFdBQUE7UUFDSixJQUFJLENBQUMsS0FBSzduQixPQUFBLENBQVEsR0FBRztVQUNqQixPQUFPM0QsS0FBQSxJQUFTLE9BQU8sT0FBT3dFLEdBQUE7UUFDbEM7UUFDQSxJQUFJeEUsS0FBQSxJQUFTLE1BQU07VUFDZixJQUFJLE9BQU9BLEtBQUEsS0FBVSxVQUFVO1lBQzNCQSxLQUFBLEdBQVF3cUIsZ0JBQUEsQ0FBaUJ6WSxnQkFBQSxFQUFrQi9SLEtBQUs7WUFDaEQsSUFBSUEsS0FBQSxLQUFVLE1BQU07Y0FDaEIsT0FBTztZQUNYO1VBQ0osV0FBVzhJLElBQUEsQ0FBS0MsR0FBQSxDQUFJL0ksS0FBSyxJQUFJLE1BQU0sQ0FBQ3VyQixXQUFBLEVBQWE7WUFDN0N2ckIsS0FBQSxHQUFRQSxLQUFBLEdBQVE7VUFDcEI7VUFDQSxJQUFJLENBQUMsS0FBS3NGLE1BQUEsSUFBVWdtQixhQUFBLEVBQWU7WUFDL0JFLFdBQUEsR0FBY0wsYUFBQSxDQUFjLElBQUk7VUFDcEM7VUFDQSxLQUFLNWxCLE9BQUEsR0FBVXZGLEtBQUE7VUFDZixLQUFLc0YsTUFBQSxHQUFTO1VBQ2QsSUFBSWttQixXQUFBLElBQWUsTUFBTTtZQUNyQixLQUFLM1AsR0FBQSxDQUFJMlAsV0FBQSxFQUFhLEdBQUc7VUFDN0I7VUFDQSxJQUFJbEIsT0FBQSxLQUFXdHFCLEtBQUEsRUFBTztZQUNsQixJQUFJLENBQUNzckIsYUFBQSxJQUFpQixLQUFLRyxpQkFBQSxFQUFtQjtjQUMxQ0MsV0FBQSxDQUNJLE1BQ0E1QyxjQUFBLENBQWU5b0IsS0FBQSxHQUFRc3FCLE9BQUEsRUFBUSxHQUFHLEdBQ2xDLEdBQ0EsS0FDSjtZQUNKLFdBQVcsQ0FBQyxLQUFLbUIsaUJBQUEsRUFBbUI7Y0FDaEMsS0FBS0EsaUJBQUEsR0FBb0I7Y0FDekIvckIsS0FBQSxDQUFNaUcsWUFBQSxDQUFhLE1BQU0sSUFBSTtjQUM3QixLQUFLOGxCLGlCQUFBLEdBQW9CO1lBQzdCO1VBQ0o7VUFDQSxPQUFPO1FBQ1gsT0FBTztVQUNILE9BQU8sS0FBS25tQixNQUFBLEdBQVNnbEIsT0FBQSxHQUFTYSxhQUFBLENBQWMsSUFBSTtRQUNwRDtNQUNKO01BRUEsU0FBU1EsV0FBVzNyQixLQUFBLEVBQU9zckIsYUFBQSxFQUFlO1FBQ3RDLElBQUl0ckIsS0FBQSxJQUFTLE1BQU07VUFDZixJQUFJLE9BQU9BLEtBQUEsS0FBVSxVQUFVO1lBQzNCQSxLQUFBLEdBQVEsQ0FBQ0EsS0FBQTtVQUNiO1VBRUEsS0FBS3VxQixTQUFBLENBQVV2cUIsS0FBQSxFQUFPc3JCLGFBQWE7VUFFbkMsT0FBTztRQUNYLE9BQU87VUFDSCxPQUFPLENBQUMsS0FBS2YsU0FBQSxDQUFVO1FBQzNCO01BQ0o7TUFFQSxTQUFTcUIsZUFBZU4sYUFBQSxFQUFlO1FBQ25DLE9BQU8sS0FBS2YsU0FBQSxDQUFVLEdBQUdlLGFBQWE7TUFDMUM7TUFFQSxTQUFTTyxpQkFBaUJQLGFBQUEsRUFBZTtRQUNyQyxJQUFJLEtBQUtobUIsTUFBQSxFQUFRO1VBQ2IsS0FBS2lsQixTQUFBLENBQVUsR0FBR2UsYUFBYTtVQUMvQixLQUFLaG1CLE1BQUEsR0FBUztVQUVkLElBQUlnbUIsYUFBQSxFQUFlO1lBQ2YsS0FBS1EsUUFBQSxDQUFTWCxhQUFBLENBQWMsSUFBSSxHQUFHLEdBQUc7VUFDMUM7UUFDSjtRQUNBLE9BQU87TUFDWDtNQUVBLFNBQVNZLHdCQUFBLEVBQTBCO1FBQy9CLElBQUksS0FBSzFtQixJQUFBLElBQVEsTUFBTTtVQUNuQixLQUFLa2xCLFNBQUEsQ0FBVSxLQUFLbGxCLElBQUEsRUFBTSxPQUFPLElBQUk7UUFDekMsV0FBVyxPQUFPLEtBQUtILEVBQUEsS0FBTyxVQUFVO1VBQ3BDLElBQUk4bUIsS0FBQSxHQUFReEIsZ0JBQUEsQ0FBaUIxWSxXQUFBLEVBQWEsS0FBSzVNLEVBQUU7VUFDakQsSUFBSThtQixLQUFBLElBQVMsTUFBTTtZQUNmLEtBQUt6QixTQUFBLENBQVV5QixLQUFLO1VBQ3hCLE9BQU87WUFDSCxLQUFLekIsU0FBQSxDQUFVLEdBQUcsSUFBSTtVQUMxQjtRQUNKO1FBQ0EsT0FBTztNQUNYO01BRUEsU0FBUzBCLHFCQUFxQmpzQixLQUFBLEVBQU87UUFDakMsSUFBSSxDQUFDLEtBQUsyRCxPQUFBLENBQVEsR0FBRztVQUNqQixPQUFPO1FBQ1g7UUFDQTNELEtBQUEsR0FBUUEsS0FBQSxHQUFRdW1CLFdBQUEsQ0FBWXZtQixLQUFLLEVBQUV1cUIsU0FBQSxDQUFVLElBQUk7UUFFakQsUUFBUSxLQUFLQSxTQUFBLENBQVUsSUFBSXZxQixLQUFBLElBQVMsT0FBTztNQUMvQztNQUVBLFNBQVNrc0IscUJBQUEsRUFBdUI7UUFDNUIsT0FDSSxLQUFLM0IsU0FBQSxDQUFVLElBQUksS0FBS1MsS0FBQSxDQUFNLEVBQUVyYyxLQUFBLENBQU0sQ0FBQyxFQUFFNGIsU0FBQSxDQUFVLEtBQ25ELEtBQUtBLFNBQUEsQ0FBVSxJQUFJLEtBQUtTLEtBQUEsQ0FBTSxFQUFFcmMsS0FBQSxDQUFNLENBQUMsRUFBRTRiLFNBQUEsQ0FBVTtNQUUzRDtNQUVBLFNBQVM0Qiw0QkFBQSxFQUE4QjtRQUNuQyxJQUFJLENBQUNuckIsV0FBQSxDQUFZLEtBQUtvckIsYUFBYSxHQUFHO1VBQ2xDLE9BQU8sS0FBS0EsYUFBQTtRQUNoQjtRQUVBLElBQUkzRyxDQUFBLEdBQUksQ0FBQztVQUNMMEMsS0FBQTtRQUVKeGpCLFVBQUEsQ0FBVzhnQixDQUFBLEVBQUcsSUFBSTtRQUNsQkEsQ0FBQSxHQUFJc0MsYUFBQSxDQUFjdEMsQ0FBQztRQUVuQixJQUFJQSxDQUFBLENBQUV4UixFQUFBLEVBQUk7VUFDTmtVLEtBQUEsR0FBUTFDLENBQUEsQ0FBRW5nQixNQUFBLEdBQVN6RCxTQUFBLENBQVU0akIsQ0FBQSxDQUFFeFIsRUFBRSxJQUFJc1MsV0FBQSxDQUFZZCxDQUFBLENBQUV4UixFQUFFO1VBQ3JELEtBQUttWSxhQUFBLEdBQ0QsS0FBS3pvQixPQUFBLENBQVEsS0FBS21tQixhQUFBLENBQWNyRSxDQUFBLENBQUV4UixFQUFBLEVBQUlrVSxLQUFBLENBQU1rRSxPQUFBLENBQVEsQ0FBQyxJQUFJO1FBQ2pFLE9BQU87VUFDSCxLQUFLRCxhQUFBLEdBQWdCO1FBQ3pCO1FBRUEsT0FBTyxLQUFLQSxhQUFBO01BQ2hCO01BRUEsU0FBU0UsUUFBQSxFQUFVO1FBQ2YsT0FBTyxLQUFLM29CLE9BQUEsQ0FBUSxJQUFJLENBQUMsS0FBSzJCLE1BQUEsR0FBUztNQUMzQztNQUVBLFNBQVNpbkIsWUFBQSxFQUFjO1FBQ25CLE9BQU8sS0FBSzVvQixPQUFBLENBQVEsSUFBSSxLQUFLMkIsTUFBQSxHQUFTO01BQzFDO01BRUEsU0FBU2tuQixNQUFBLEVBQVE7UUFDYixPQUFPLEtBQUs3b0IsT0FBQSxDQUFRLElBQUksS0FBSzJCLE1BQUEsSUFBVSxLQUFLQyxPQUFBLEtBQVksSUFBSTtNQUNoRTtNQUdBLElBQUlrbkIsV0FBQSxHQUFjO1FBSWRDLFFBQUEsR0FDSTtNQUVSLFNBQVM1RCxlQUFlOW9CLEtBQUEsRUFBT3NHLEdBQUEsRUFBSztRQUNoQyxJQUFJMGlCLFFBQUEsR0FBV2hwQixLQUFBO1VBRVhpSyxLQUFBLEdBQVE7VUFDUmhCLEtBQUE7VUFDQTBqQixHQUFBO1VBQ0FDLE9BQUE7UUFFSixJQUFJakQsVUFBQSxDQUFXM3BCLEtBQUssR0FBRztVQUNuQmdwQixRQUFBLEdBQVc7WUFDUDNhLEVBQUEsRUFBSXJPLEtBQUEsQ0FBTXVwQixhQUFBO1lBQ1ZsZCxDQUFBLEVBQUdyTSxLQUFBLENBQU13cEIsS0FBQTtZQUNUL2MsQ0FBQSxFQUFHek0sS0FBQSxDQUFNd1k7VUFDYjtRQUNKLFdBQVd2WCxRQUFBLENBQVNqQixLQUFLLEtBQUssQ0FBQ2dFLEtBQUEsQ0FBTSxDQUFDaEUsS0FBSyxHQUFHO1VBQzFDZ3BCLFFBQUEsR0FBVyxDQUFDO1VBQ1osSUFBSTFpQixHQUFBLEVBQUs7WUFDTDBpQixRQUFBLENBQVMxaUIsR0FBQSxJQUFPLENBQUN0RyxLQUFBO1VBQ3JCLE9BQU87WUFDSGdwQixRQUFBLENBQVMxYSxZQUFBLEdBQWUsQ0FBQ3RPLEtBQUE7VUFDN0I7UUFDSixXQUFZaUssS0FBQSxHQUFRd2lCLFdBQUEsQ0FBWWxKLElBQUEsQ0FBS3ZqQixLQUFLLEdBQUk7VUFDMUNpSixLQUFBLEdBQU9nQixLQUFBLENBQU0sT0FBTyxNQUFNLEtBQUs7VUFDL0IrZSxRQUFBLEdBQVc7WUFDUHJjLENBQUEsRUFBRztZQUNITixDQUFBLEVBQUdnSCxLQUFBLENBQU1wSixLQUFBLENBQU1vSyxJQUFBLENBQUssSUFBSXBMLEtBQUE7WUFDeEJrRCxDQUFBLEVBQUdrSCxLQUFBLENBQU1wSixLQUFBLENBQU1xSyxJQUFBLENBQUssSUFBSXJMLEtBQUE7WUFDeEI1RixDQUFBLEVBQUdnUSxLQUFBLENBQU1wSixLQUFBLENBQU1zSyxNQUFBLENBQU8sSUFBSXRMLEtBQUE7WUFDMUIrQyxDQUFBLEVBQUdxSCxLQUFBLENBQU1wSixLQUFBLENBQU11SyxNQUFBLENBQU8sSUFBSXZMLEtBQUE7WUFDMUJvRixFQUFBLEVBQUlnRixLQUFBLENBQU11VyxRQUFBLENBQVMzZixLQUFBLENBQU13SyxXQUFBLElBQWUsR0FBSSxDQUFDLElBQUl4TDtVQUNyRDtRQUNKLFdBQVlnQixLQUFBLEdBQVF5aUIsUUFBQSxDQUFTbkosSUFBQSxDQUFLdmpCLEtBQUssR0FBSTtVQUN2Q2lKLEtBQUEsR0FBT2dCLEtBQUEsQ0FBTSxPQUFPLE1BQU0sS0FBSztVQUMvQitlLFFBQUEsR0FBVztZQUNQcmMsQ0FBQSxFQUFHa2dCLFFBQUEsQ0FBUzVpQixLQUFBLENBQU0sSUFBSWhCLEtBQUk7WUFDMUJ3RCxDQUFBLEVBQUdvZ0IsUUFBQSxDQUFTNWlCLEtBQUEsQ0FBTSxJQUFJaEIsS0FBSTtZQUMxQnNELENBQUEsRUFBR3NnQixRQUFBLENBQVM1aUIsS0FBQSxDQUFNLElBQUloQixLQUFJO1lBQzFCb0QsQ0FBQSxFQUFHd2dCLFFBQUEsQ0FBUzVpQixLQUFBLENBQU0sSUFBSWhCLEtBQUk7WUFDMUJrRCxDQUFBLEVBQUcwZ0IsUUFBQSxDQUFTNWlCLEtBQUEsQ0FBTSxJQUFJaEIsS0FBSTtZQUMxQjVGLENBQUEsRUFBR3dwQixRQUFBLENBQVM1aUIsS0FBQSxDQUFNLElBQUloQixLQUFJO1lBQzFCK0MsQ0FBQSxFQUFHNmdCLFFBQUEsQ0FBUzVpQixLQUFBLENBQU0sSUFBSWhCLEtBQUk7VUFDOUI7UUFDSixXQUFXK2YsUUFBQSxJQUFZLE1BQU07VUFFekJBLFFBQUEsR0FBVyxDQUFDO1FBQ2hCLFdBQ0ksT0FBT0EsUUFBQSxLQUFhLGFBQ25CLFVBQVVBLFFBQUEsSUFBWSxRQUFRQSxRQUFBLEdBQ2pDO1VBQ0U0RCxPQUFBLEdBQVVFLGlCQUFBLENBQ052RyxXQUFBLENBQVl5QyxRQUFBLENBQVMrRCxJQUFJLEdBQ3pCeEcsV0FBQSxDQUFZeUMsUUFBQSxDQUFTZ0UsRUFBRSxDQUMzQjtVQUVBaEUsUUFBQSxHQUFXLENBQUM7VUFDWkEsUUFBQSxDQUFTM2EsRUFBQSxHQUFLdWUsT0FBQSxDQUFRdGUsWUFBQTtVQUN0QjBhLFFBQUEsQ0FBU3ZjLENBQUEsR0FBSW1nQixPQUFBLENBQVFsZSxNQUFBO1FBQ3pCO1FBRUFpZSxHQUFBLEdBQU0sSUFBSTVELFFBQUEsQ0FBU0MsUUFBUTtRQUUzQixJQUFJVyxVQUFBLENBQVczcEIsS0FBSyxLQUFLTyxVQUFBLENBQVdQLEtBQUEsRUFBTyxTQUFTLEdBQUc7VUFDbkQyc0IsR0FBQSxDQUFJbm5CLE9BQUEsR0FBVXhGLEtBQUEsQ0FBTXdGLE9BQUE7UUFDeEI7UUFFQSxJQUFJbWtCLFVBQUEsQ0FBVzNwQixLQUFLLEtBQUtPLFVBQUEsQ0FBV1AsS0FBQSxFQUFPLFVBQVUsR0FBRztVQUNwRDJzQixHQUFBLENBQUlyb0IsUUFBQSxHQUFXdEUsS0FBQSxDQUFNc0UsUUFBQTtRQUN6QjtRQUVBLE9BQU9xb0IsR0FBQTtNQUNYO01BRUE3RCxjQUFBLENBQWV4bkIsRUFBQSxHQUFLeW5CLFFBQUEsQ0FBUzVvQixTQUFBO01BQzdCMm9CLGNBQUEsQ0FBZW1FLE9BQUEsR0FBVXBFLGVBQUE7TUFFekIsU0FBU2dFLFNBQVNLLEdBQUEsRUFBS2prQixLQUFBLEVBQU07UUFJekIsSUFBSTFILEdBQUEsR0FBTTJyQixHQUFBLElBQU92RSxVQUFBLENBQVd1RSxHQUFBLENBQUloakIsT0FBQSxDQUFRLEtBQUssR0FBRyxDQUFDO1FBRWpELFFBQVFsRyxLQUFBLENBQU16QyxHQUFHLElBQUksSUFBSUEsR0FBQSxJQUFPMEgsS0FBQTtNQUNwQztNQUVBLFNBQVNra0IsMEJBQTBCQyxJQUFBLEVBQU1qRixLQUFBLEVBQU87UUFDNUMsSUFBSTVtQixHQUFBLEdBQU0sQ0FBQztRQUVYQSxHQUFBLENBQUltTixNQUFBLEdBQ0F5WixLQUFBLENBQU14WixLQUFBLENBQU0sSUFBSXllLElBQUEsQ0FBS3plLEtBQUEsQ0FBTSxLQUFLd1osS0FBQSxDQUFNdFksSUFBQSxDQUFLLElBQUl1ZCxJQUFBLENBQUt2ZCxJQUFBLENBQUssS0FBSztRQUNsRSxJQUFJdWQsSUFBQSxDQUFLcEMsS0FBQSxDQUFNLEVBQUVuUCxHQUFBLENBQUl0YSxHQUFBLENBQUltTixNQUFBLEVBQVEsR0FBRyxFQUFFMmUsT0FBQSxDQUFRbEYsS0FBSyxHQUFHO1VBQ2xELEVBQUU1bUIsR0FBQSxDQUFJbU4sTUFBQTtRQUNWO1FBRUFuTixHQUFBLENBQUkrTSxZQUFBLEdBQWUsQ0FBQzZaLEtBQUEsR0FBUSxDQUFDaUYsSUFBQSxDQUFLcEMsS0FBQSxDQUFNLEVBQUVuUCxHQUFBLENBQUl0YSxHQUFBLENBQUltTixNQUFBLEVBQVEsR0FBRztRQUU3RCxPQUFPbk4sR0FBQTtNQUNYO01BRUEsU0FBU3VyQixrQkFBa0JNLElBQUEsRUFBTWpGLEtBQUEsRUFBTztRQUNwQyxJQUFJNW1CLEdBQUE7UUFDSixJQUFJLEVBQUU2ckIsSUFBQSxDQUFLenBCLE9BQUEsQ0FBUSxLQUFLd2tCLEtBQUEsQ0FBTXhrQixPQUFBLENBQVEsSUFBSTtVQUN0QyxPQUFPO1lBQUUySyxZQUFBLEVBQWM7WUFBR0ksTUFBQSxFQUFRO1VBQUU7UUFDeEM7UUFFQXlaLEtBQUEsR0FBUTJDLGVBQUEsQ0FBZ0IzQyxLQUFBLEVBQU9pRixJQUFJO1FBQ25DLElBQUlBLElBQUEsQ0FBS0UsUUFBQSxDQUFTbkYsS0FBSyxHQUFHO1VBQ3RCNW1CLEdBQUEsR0FBTTRyQix5QkFBQSxDQUEwQkMsSUFBQSxFQUFNakYsS0FBSztRQUMvQyxPQUFPO1VBQ0g1bUIsR0FBQSxHQUFNNHJCLHlCQUFBLENBQTBCaEYsS0FBQSxFQUFPaUYsSUFBSTtVQUMzQzdyQixHQUFBLENBQUkrTSxZQUFBLEdBQWUsQ0FBQy9NLEdBQUEsQ0FBSStNLFlBQUE7VUFDeEIvTSxHQUFBLENBQUltTixNQUFBLEdBQVMsQ0FBQ25OLEdBQUEsQ0FBSW1OLE1BQUE7UUFDdEI7UUFFQSxPQUFPbk4sR0FBQTtNQUNYO01BR0EsU0FBU2dzQixZQUFZQyxTQUFBLEVBQVcxbUIsSUFBQSxFQUFNO1FBQ2xDLE9BQU8sVUFBVS9CLEdBQUEsRUFBSzBvQixNQUFBLEVBQVE7VUFDMUIsSUFBSUMsR0FBQSxFQUFLQyxHQUFBO1VBRVQsSUFBSUYsTUFBQSxLQUFXLFFBQVEsQ0FBQ3pwQixLQUFBLENBQU0sQ0FBQ3lwQixNQUFNLEdBQUc7WUFDcEM1bUIsZUFBQSxDQUNJQyxJQUFBLEVBQ0EsY0FDSUEsSUFBQSxHQUNBLHlEQUNBQSxJQUFBLEdBQ0EsZ0dBRVI7WUFDQTZtQixHQUFBLEdBQU01b0IsR0FBQTtZQUNOQSxHQUFBLEdBQU0wb0IsTUFBQTtZQUNOQSxNQUFBLEdBQVNFLEdBQUE7VUFDYjtVQUVBRCxHQUFBLEdBQU01RSxjQUFBLENBQWUvakIsR0FBQSxFQUFLMG9CLE1BQU07VUFDaEMvQixXQUFBLENBQVksTUFBTWdDLEdBQUEsRUFBS0YsU0FBUztVQUNoQyxPQUFPO1FBQ1g7TUFDSjtNQUVBLFNBQVM5QixZQUFZcmpCLEdBQUEsRUFBSzJnQixRQUFBLEVBQVU0RSxRQUFBLEVBQVVqb0IsWUFBQSxFQUFjO1FBQ3hELElBQUkyakIsYUFBQSxHQUFlTixRQUFBLENBQVNPLGFBQUE7VUFDeEJILEtBQUEsR0FBT1EsUUFBQSxDQUFTWixRQUFBLENBQVNRLEtBQUs7VUFDOUJOLE9BQUEsR0FBU1UsUUFBQSxDQUFTWixRQUFBLENBQVN4USxPQUFPO1FBRXRDLElBQUksQ0FBQ25RLEdBQUEsQ0FBSTFFLE9BQUEsQ0FBUSxHQUFHO1VBRWhCO1FBQ0o7UUFFQWdDLFlBQUEsR0FBZUEsWUFBQSxJQUFnQixPQUFPLE9BQU9BLFlBQUE7UUFFN0MsSUFBSXVqQixPQUFBLEVBQVE7VUFDUjVQLFFBQUEsQ0FBU2pSLEdBQUEsRUFBSytNLEdBQUEsQ0FBSS9NLEdBQUEsRUFBSyxPQUFPLElBQUk2Z0IsT0FBQSxHQUFTMEUsUUFBUTtRQUN2RDtRQUNBLElBQUl4RSxLQUFBLEVBQU07VUFDTmpVLEtBQUEsQ0FBTTlNLEdBQUEsRUFBSyxRQUFRK00sR0FBQSxDQUFJL00sR0FBQSxFQUFLLE1BQU0sSUFBSStnQixLQUFBLEdBQU93RSxRQUFRO1FBQ3pEO1FBQ0EsSUFBSXRFLGFBQUEsRUFBYztVQUNkamhCLEdBQUEsQ0FBSXRFLEVBQUEsQ0FBR2tuQixPQUFBLENBQVE1aUIsR0FBQSxDQUFJdEUsRUFBQSxDQUFHbkMsT0FBQSxDQUFRLElBQUkwbkIsYUFBQSxHQUFlc0UsUUFBUTtRQUM3RDtRQUNBLElBQUlqb0IsWUFBQSxFQUFjO1VBQ2RqRyxLQUFBLENBQU1pRyxZQUFBLENBQWEwQyxHQUFBLEVBQUsrZ0IsS0FBQSxJQUFRRixPQUFNO1FBQzFDO01BQ0o7TUFFQSxJQUFJck4sR0FBQSxHQUFNMFIsV0FBQSxDQUFZLEdBQUcsS0FBSztRQUMxQnpCLFFBQUEsR0FBV3lCLFdBQUEsQ0FBWSxJQUFJLFVBQVU7TUFFekMsU0FBU00sU0FBUzd0QixLQUFBLEVBQU87UUFDckIsT0FBTyxPQUFPQSxLQUFBLEtBQVUsWUFBWUEsS0FBQSxZQUFpQjh0QixNQUFBO01BQ3pEO01BR0EsU0FBU0MsY0FBYy90QixLQUFBLEVBQU87UUFDMUIsT0FDSTRGLFFBQUEsQ0FBUzVGLEtBQUssS0FDZGtCLE1BQUEsQ0FBT2xCLEtBQUssS0FDWjZ0QixRQUFBLENBQVM3dEIsS0FBSyxLQUNkaUIsUUFBQSxDQUFTakIsS0FBSyxLQUNkZ3VCLHFCQUFBLENBQXNCaHVCLEtBQUssS0FDM0JpdUIsbUJBQUEsQ0FBb0JqdUIsS0FBSyxLQUN6QkEsS0FBQSxLQUFVLFFBQ1ZBLEtBQUEsS0FBVTtNQUVsQjtNQUVBLFNBQVNpdUIsb0JBQW9CanVCLEtBQUEsRUFBTztRQUNoQyxJQUFJa3VCLFVBQUEsR0FBYTV0QixRQUFBLENBQVNOLEtBQUssS0FBSyxDQUFDVyxhQUFBLENBQWNYLEtBQUs7VUFDcERtdUIsWUFBQSxHQUFlO1VBQ2ZDLFVBQUEsR0FBYSxDQUNULFNBQ0EsUUFDQSxLQUNBLFVBQ0EsU0FDQSxLQUNBLFFBQ0EsT0FDQSxLQUNBLFNBQ0EsUUFDQSxLQUNBLFNBQ0EsUUFDQSxLQUNBLFdBQ0EsVUFDQSxLQUNBLFdBQ0EsVUFDQSxLQUNBLGdCQUNBLGVBQ0EsS0FDSjtVQUNBNXNCLENBQUE7VUFDQTZzQixRQUFBO1VBQ0FDLFdBQUEsR0FBY0YsVUFBQSxDQUFXdHRCLE1BQUE7UUFFN0IsS0FBS1UsQ0FBQSxHQUFJLEdBQUdBLENBQUEsR0FBSThzQixXQUFBLEVBQWE5c0IsQ0FBQSxJQUFLLEdBQUc7VUFDakM2c0IsUUFBQSxHQUFXRCxVQUFBLENBQVc1c0IsQ0FBQTtVQUN0QjJzQixZQUFBLEdBQWVBLFlBQUEsSUFBZ0I1dEIsVUFBQSxDQUFXUCxLQUFBLEVBQU9xdUIsUUFBUTtRQUM3RDtRQUVBLE9BQU9ILFVBQUEsSUFBY0MsWUFBQTtNQUN6QjtNQUVBLFNBQVNILHNCQUFzQmh1QixLQUFBLEVBQU87UUFDbEMsSUFBSXV1QixTQUFBLEdBQVl4dUIsT0FBQSxDQUFRQyxLQUFLO1VBQ3pCd3VCLFlBQUEsR0FBZTtRQUNuQixJQUFJRCxTQUFBLEVBQVc7VUFDWEMsWUFBQSxHQUNJeHVCLEtBQUEsQ0FBTXl1QixNQUFBLENBQU8sVUFBVUMsSUFBQSxFQUFNO1lBQ3pCLE9BQU8sQ0FBQ3p0QixRQUFBLENBQVN5dEIsSUFBSSxLQUFLYixRQUFBLENBQVM3dEIsS0FBSztVQUM1QyxDQUFDLEVBQUVjLE1BQUEsS0FBVztRQUN0QjtRQUNBLE9BQU95dEIsU0FBQSxJQUFhQyxZQUFBO01BQ3hCO01BRUEsU0FBU0csZUFBZTN1QixLQUFBLEVBQU87UUFDM0IsSUFBSWt1QixVQUFBLEdBQWE1dEIsUUFBQSxDQUFTTixLQUFLLEtBQUssQ0FBQ1csYUFBQSxDQUFjWCxLQUFLO1VBQ3BEbXVCLFlBQUEsR0FBZTtVQUNmQyxVQUFBLEdBQWEsQ0FDVCxXQUNBLFdBQ0EsV0FDQSxZQUNBLFlBQ0EsV0FDSjtVQUNBNXNCLENBQUE7VUFDQTZzQixRQUFBO1FBRUosS0FBSzdzQixDQUFBLEdBQUksR0FBR0EsQ0FBQSxHQUFJNHNCLFVBQUEsQ0FBV3R0QixNQUFBLEVBQVFVLENBQUEsSUFBSyxHQUFHO1VBQ3ZDNnNCLFFBQUEsR0FBV0QsVUFBQSxDQUFXNXNCLENBQUE7VUFDdEIyc0IsWUFBQSxHQUFlQSxZQUFBLElBQWdCNXRCLFVBQUEsQ0FBV1AsS0FBQSxFQUFPcXVCLFFBQVE7UUFDN0Q7UUFFQSxPQUFPSCxVQUFBLElBQWNDLFlBQUE7TUFDekI7TUFFQSxTQUFTUyxrQkFBa0JDLFFBQUEsRUFBVXZtQixJQUFBLEVBQUs7UUFDdEMsSUFBSTZFLEtBQUEsR0FBTzBoQixRQUFBLENBQVNDLElBQUEsQ0FBS3htQixJQUFBLEVBQUssUUFBUSxJQUFJO1FBQzFDLE9BQU82RSxLQUFBLEdBQU8sS0FDUixhQUNBQSxLQUFBLEdBQU8sS0FDTCxhQUNBQSxLQUFBLEdBQU8sSUFDTCxZQUNBQSxLQUFBLEdBQU8sSUFDTCxZQUNBQSxLQUFBLEdBQU8sSUFDTCxZQUNBQSxLQUFBLEdBQU8sSUFDTCxhQUNBO01BQ3BCO01BRUEsU0FBUzRoQixXQUFXQyxJQUFBLEVBQU1DLE9BQUEsRUFBUztRQUUvQixJQUFJcnZCLFNBQUEsQ0FBVWtCLE1BQUEsS0FBVyxHQUFHO1VBQ3hCLElBQUksQ0FBQ2xCLFNBQUEsQ0FBVSxJQUFJO1lBQ2ZvdkIsSUFBQSxHQUFPO1lBQ1BDLE9BQUEsR0FBVTtVQUNkLFdBQVdsQixhQUFBLENBQWNudUIsU0FBQSxDQUFVLEVBQUUsR0FBRztZQUNwQ292QixJQUFBLEdBQU9wdkIsU0FBQSxDQUFVO1lBQ2pCcXZCLE9BQUEsR0FBVTtVQUNkLFdBQVdOLGNBQUEsQ0FBZS91QixTQUFBLENBQVUsRUFBRSxHQUFHO1lBQ3JDcXZCLE9BQUEsR0FBVXJ2QixTQUFBLENBQVU7WUFDcEJvdkIsSUFBQSxHQUFPO1VBQ1g7UUFDSjtRQUdBLElBQUkxbUIsSUFBQSxHQUFNMG1CLElBQUEsSUFBUXpJLFdBQUEsQ0FBWTtVQUMxQjJJLEdBQUEsR0FBTXBFLGVBQUEsQ0FBZ0J4aUIsSUFBQSxFQUFLLElBQUksRUFBRTZtQixPQUFBLENBQVEsS0FBSztVQUM5Q3J0QixPQUFBLEdBQVNwQyxLQUFBLENBQU0wdkIsY0FBQSxDQUFlLE1BQU1GLEdBQUcsS0FBSztVQUM1QzNtQixNQUFBLEdBQ0kwbUIsT0FBQSxLQUNDbG9CLFVBQUEsQ0FBV2tvQixPQUFBLENBQVFudEIsT0FBQSxDQUFPLElBQ3JCbXRCLE9BQUEsQ0FBUW50QixPQUFBLEVBQVF6QixJQUFBLENBQUssTUFBTWlJLElBQUcsSUFDOUIybUIsT0FBQSxDQUFRbnRCLE9BQUE7UUFFdEIsT0FBTyxLQUFLdXRCLE1BQUEsQ0FDUjltQixNQUFBLElBQVUsS0FBS3VCLFVBQUEsQ0FBVyxFQUFFMUIsUUFBQSxDQUFTdEcsT0FBQSxFQUFRLE1BQU15a0IsV0FBQSxDQUFZamUsSUFBRyxDQUFDLENBQ3ZFO01BQ0o7TUFFQSxTQUFTMGlCLE1BQUEsRUFBUTtRQUNiLE9BQU8sSUFBSXZsQixNQUFBLENBQU8sSUFBSTtNQUMxQjtNQUVBLFNBQVM0bkIsUUFBUXJ0QixLQUFBLEVBQU8rUCxLQUFBLEVBQU87UUFDM0IsSUFBSXVmLFVBQUEsR0FBYTFwQixRQUFBLENBQVM1RixLQUFLLElBQUlBLEtBQUEsR0FBUXVtQixXQUFBLENBQVl2bUIsS0FBSztRQUM1RCxJQUFJLEVBQUUsS0FBSzJELE9BQUEsQ0FBUSxLQUFLMnJCLFVBQUEsQ0FBVzNyQixPQUFBLENBQVEsSUFBSTtVQUMzQyxPQUFPO1FBQ1g7UUFDQW9NLEtBQUEsR0FBUUQsY0FBQSxDQUFlQyxLQUFLLEtBQUs7UUFDakMsSUFBSUEsS0FBQSxLQUFVLGVBQWU7VUFDekIsT0FBTyxLQUFLbk8sT0FBQSxDQUFRLElBQUkwdEIsVUFBQSxDQUFXMXRCLE9BQUEsQ0FBUTtRQUMvQyxPQUFPO1VBQ0gsT0FBTzB0QixVQUFBLENBQVcxdEIsT0FBQSxDQUFRLElBQUksS0FBS29wQixLQUFBLENBQU0sRUFBRW1FLE9BQUEsQ0FBUXBmLEtBQUssRUFBRW5PLE9BQUEsQ0FBUTtRQUN0RTtNQUNKO01BRUEsU0FBUzByQixTQUFTdHRCLEtBQUEsRUFBTytQLEtBQUEsRUFBTztRQUM1QixJQUFJdWYsVUFBQSxHQUFhMXBCLFFBQUEsQ0FBUzVGLEtBQUssSUFBSUEsS0FBQSxHQUFRdW1CLFdBQUEsQ0FBWXZtQixLQUFLO1FBQzVELElBQUksRUFBRSxLQUFLMkQsT0FBQSxDQUFRLEtBQUsyckIsVUFBQSxDQUFXM3JCLE9BQUEsQ0FBUSxJQUFJO1VBQzNDLE9BQU87UUFDWDtRQUNBb00sS0FBQSxHQUFRRCxjQUFBLENBQWVDLEtBQUssS0FBSztRQUNqQyxJQUFJQSxLQUFBLEtBQVUsZUFBZTtVQUN6QixPQUFPLEtBQUtuTyxPQUFBLENBQVEsSUFBSTB0QixVQUFBLENBQVcxdEIsT0FBQSxDQUFRO1FBQy9DLE9BQU87VUFDSCxPQUFPLEtBQUtvcEIsS0FBQSxDQUFNLEVBQUV1RSxLQUFBLENBQU14ZixLQUFLLEVBQUVuTyxPQUFBLENBQVEsSUFBSTB0QixVQUFBLENBQVcxdEIsT0FBQSxDQUFRO1FBQ3BFO01BQ0o7TUFFQSxTQUFTNHRCLFVBQVUzcUIsS0FBQSxFQUFNRCxHQUFBLEVBQUltTCxLQUFBLEVBQU8wZixXQUFBLEVBQWE7UUFDN0MsSUFBSUMsU0FBQSxHQUFZOXBCLFFBQUEsQ0FBU2YsS0FBSSxJQUFJQSxLQUFBLEdBQU8waEIsV0FBQSxDQUFZMWhCLEtBQUk7VUFDcEQ4cUIsT0FBQSxHQUFVL3BCLFFBQUEsQ0FBU2hCLEdBQUUsSUFBSUEsR0FBQSxHQUFLMmhCLFdBQUEsQ0FBWTNoQixHQUFFO1FBQ2hELElBQUksRUFBRSxLQUFLakIsT0FBQSxDQUFRLEtBQUsrckIsU0FBQSxDQUFVL3JCLE9BQUEsQ0FBUSxLQUFLZ3NCLE9BQUEsQ0FBUWhzQixPQUFBLENBQVEsSUFBSTtVQUMvRCxPQUFPO1FBQ1g7UUFDQThyQixXQUFBLEdBQWNBLFdBQUEsSUFBZTtRQUM3QixRQUNLQSxXQUFBLENBQVksT0FBTyxNQUNkLEtBQUtwQyxPQUFBLENBQVFxQyxTQUFBLEVBQVczZixLQUFLLElBQzdCLENBQUMsS0FBS3VkLFFBQUEsQ0FBU29DLFNBQUEsRUFBVzNmLEtBQUssT0FDcEMwZixXQUFBLENBQVksT0FBTyxNQUNkLEtBQUtuQyxRQUFBLENBQVNxQyxPQUFBLEVBQVM1ZixLQUFLLElBQzVCLENBQUMsS0FBS3NkLE9BQUEsQ0FBUXNDLE9BQUEsRUFBUzVmLEtBQUs7TUFFMUM7TUFFQSxTQUFTNmYsT0FBTzV2QixLQUFBLEVBQU8rUCxLQUFBLEVBQU87UUFDMUIsSUFBSXVmLFVBQUEsR0FBYTFwQixRQUFBLENBQVM1RixLQUFLLElBQUlBLEtBQUEsR0FBUXVtQixXQUFBLENBQVl2bUIsS0FBSztVQUN4RDZ2QixPQUFBO1FBQ0osSUFBSSxFQUFFLEtBQUtsc0IsT0FBQSxDQUFRLEtBQUsyckIsVUFBQSxDQUFXM3JCLE9BQUEsQ0FBUSxJQUFJO1VBQzNDLE9BQU87UUFDWDtRQUNBb00sS0FBQSxHQUFRRCxjQUFBLENBQWVDLEtBQUssS0FBSztRQUNqQyxJQUFJQSxLQUFBLEtBQVUsZUFBZTtVQUN6QixPQUFPLEtBQUtuTyxPQUFBLENBQVEsTUFBTTB0QixVQUFBLENBQVcxdEIsT0FBQSxDQUFRO1FBQ2pELE9BQU87VUFDSGl1QixPQUFBLEdBQVVQLFVBQUEsQ0FBVzF0QixPQUFBLENBQVE7VUFDN0IsT0FDSSxLQUFLb3BCLEtBQUEsQ0FBTSxFQUFFbUUsT0FBQSxDQUFRcGYsS0FBSyxFQUFFbk8sT0FBQSxDQUFRLEtBQUtpdUIsT0FBQSxJQUN6Q0EsT0FBQSxJQUFXLEtBQUs3RSxLQUFBLENBQU0sRUFBRXVFLEtBQUEsQ0FBTXhmLEtBQUssRUFBRW5PLE9BQUEsQ0FBUTtRQUVyRDtNQUNKO01BRUEsU0FBU2t1QixjQUFjOXZCLEtBQUEsRUFBTytQLEtBQUEsRUFBTztRQUNqQyxPQUFPLEtBQUs2ZixNQUFBLENBQU81dkIsS0FBQSxFQUFPK1AsS0FBSyxLQUFLLEtBQUtzZCxPQUFBLENBQVFydEIsS0FBQSxFQUFPK1AsS0FBSztNQUNqRTtNQUVBLFNBQVNnZ0IsZUFBZS92QixLQUFBLEVBQU8rUCxLQUFBLEVBQU87UUFDbEMsT0FBTyxLQUFLNmYsTUFBQSxDQUFPNXZCLEtBQUEsRUFBTytQLEtBQUssS0FBSyxLQUFLdWQsUUFBQSxDQUFTdHRCLEtBQUEsRUFBTytQLEtBQUs7TUFDbEU7TUFFQSxTQUFTK2UsS0FBSzl1QixLQUFBLEVBQU8rUCxLQUFBLEVBQU9pZ0IsT0FBQSxFQUFTO1FBQ2pDLElBQUlDLElBQUEsRUFBTUMsU0FBQSxFQUFXM25CLE1BQUE7UUFFckIsSUFBSSxDQUFDLEtBQUs1RSxPQUFBLENBQVEsR0FBRztVQUNqQixPQUFPYSxHQUFBO1FBQ1g7UUFFQXlyQixJQUFBLEdBQU9uRixlQUFBLENBQWdCOXFCLEtBQUEsRUFBTyxJQUFJO1FBRWxDLElBQUksQ0FBQ2l3QixJQUFBLENBQUt0c0IsT0FBQSxDQUFRLEdBQUc7VUFDakIsT0FBT2EsR0FBQTtRQUNYO1FBRUEwckIsU0FBQSxJQUFhRCxJQUFBLENBQUsxRixTQUFBLENBQVUsSUFBSSxLQUFLQSxTQUFBLENBQVUsS0FBSztRQUVwRHhhLEtBQUEsR0FBUUQsY0FBQSxDQUFlQyxLQUFLO1FBRTVCLFFBQVFBLEtBQUE7VUFBQSxLQUNDO1lBQ0R4SCxNQUFBLEdBQVM0bkIsU0FBQSxDQUFVLE1BQU1GLElBQUksSUFBSTtZQUNqQztVQUFBLEtBQ0M7WUFDRDFuQixNQUFBLEdBQVM0bkIsU0FBQSxDQUFVLE1BQU1GLElBQUk7WUFDN0I7VUFBQSxLQUNDO1lBQ0QxbkIsTUFBQSxHQUFTNG5CLFNBQUEsQ0FBVSxNQUFNRixJQUFJLElBQUk7WUFDakM7VUFBQSxLQUNDO1lBQ0QxbkIsTUFBQSxJQUFVLE9BQU8wbkIsSUFBQSxJQUFRO1lBQ3pCO1VBQUEsS0FDQztZQUNEMW5CLE1BQUEsSUFBVSxPQUFPMG5CLElBQUEsSUFBUTtZQUN6QjtVQUFBLEtBQ0M7WUFDRDFuQixNQUFBLElBQVUsT0FBTzBuQixJQUFBLElBQVE7WUFDekI7VUFBQSxLQUNDO1lBQ0QxbkIsTUFBQSxJQUFVLE9BQU8wbkIsSUFBQSxHQUFPQyxTQUFBLElBQWE7WUFDckM7VUFBQSxLQUNDO1lBQ0QzbkIsTUFBQSxJQUFVLE9BQU8wbkIsSUFBQSxHQUFPQyxTQUFBLElBQWE7WUFDckM7VUFBQTtZQUVBM25CLE1BQUEsR0FBUyxPQUFPMG5CLElBQUE7UUFBQTtRQUd4QixPQUFPRCxPQUFBLEdBQVV6bkIsTUFBQSxHQUFTMkssUUFBQSxDQUFTM0ssTUFBTTtNQUM3QztNQUVBLFNBQVM0bkIsVUFBVTN2QixDQUFBLEVBQUdDLENBQUEsRUFBRztRQUNyQixJQUFJRCxDQUFBLENBQUUrTSxJQUFBLENBQUssSUFBSTlNLENBQUEsQ0FBRThNLElBQUEsQ0FBSyxHQUFHO1VBR3JCLE9BQU8sQ0FBQzRpQixTQUFBLENBQVUxdkIsQ0FBQSxFQUFHRCxDQUFDO1FBQzFCO1FBRUEsSUFBSTR2QixjQUFBLElBQWtCM3ZCLENBQUEsQ0FBRW9QLElBQUEsQ0FBSyxJQUFJclAsQ0FBQSxDQUFFcVAsSUFBQSxDQUFLLEtBQUssTUFBTXBQLENBQUEsQ0FBRWtPLEtBQUEsQ0FBTSxJQUFJbk8sQ0FBQSxDQUFFbU8sS0FBQSxDQUFNO1VBRW5FMGhCLE1BQUEsR0FBUzd2QixDQUFBLENBQUV3cUIsS0FBQSxDQUFNLEVBQUVuUCxHQUFBLENBQUl1VSxjQUFBLEVBQWdCLFFBQVE7VUFDL0NFLE9BQUE7VUFDQUMsTUFBQTtRQUVKLElBQUk5dkIsQ0FBQSxHQUFJNHZCLE1BQUEsR0FBUyxHQUFHO1VBQ2hCQyxPQUFBLEdBQVU5dkIsQ0FBQSxDQUFFd3FCLEtBQUEsQ0FBTSxFQUFFblAsR0FBQSxDQUFJdVUsY0FBQSxHQUFpQixHQUFHLFFBQVE7VUFFcERHLE1BQUEsSUFBVTl2QixDQUFBLEdBQUk0dkIsTUFBQSxLQUFXQSxNQUFBLEdBQVNDLE9BQUE7UUFDdEMsT0FBTztVQUNIQSxPQUFBLEdBQVU5dkIsQ0FBQSxDQUFFd3FCLEtBQUEsQ0FBTSxFQUFFblAsR0FBQSxDQUFJdVUsY0FBQSxHQUFpQixHQUFHLFFBQVE7VUFFcERHLE1BQUEsSUFBVTl2QixDQUFBLEdBQUk0dkIsTUFBQSxLQUFXQyxPQUFBLEdBQVVELE1BQUE7UUFDdkM7UUFHQSxPQUFPLEVBQUVELGNBQUEsR0FBaUJHLE1BQUEsS0FBVztNQUN6QztNQUVBN3dCLEtBQUEsQ0FBTTh3QixhQUFBLEdBQWdCO01BQ3RCOXdCLEtBQUEsQ0FBTSt3QixnQkFBQSxHQUFtQjtNQUV6QixTQUFTcndCLFNBQUEsRUFBVztRQUNoQixPQUFPLEtBQUs0cUIsS0FBQSxDQUFNLEVBQUUwRixNQUFBLENBQU8sSUFBSSxFQUFFckIsTUFBQSxDQUFPLGtDQUFrQztNQUM5RTtNQUVBLFNBQVNzQixZQUFZQyxVQUFBLEVBQVk7UUFDN0IsSUFBSSxDQUFDLEtBQUtqdEIsT0FBQSxDQUFRLEdBQUc7VUFDakIsT0FBTztRQUNYO1FBQ0EsSUFBSXpCLEdBQUEsR0FBTTB1QixVQUFBLEtBQWU7VUFDckJ2dEIsQ0FBQSxHQUFJbkIsR0FBQSxHQUFNLEtBQUs4b0IsS0FBQSxDQUFNLEVBQUU5b0IsR0FBQSxDQUFJLElBQUk7UUFDbkMsSUFBSW1CLENBQUEsQ0FBRXdNLElBQUEsQ0FBSyxJQUFJLEtBQUt4TSxDQUFBLENBQUV3TSxJQUFBLENBQUssSUFBSSxNQUFNO1VBQ2pDLE9BQU92RixZQUFBLENBQ0hqSCxDQUFBLEVBQ0FuQixHQUFBLEdBQ00sbUNBQ0EsOEJBQ1Y7UUFDSjtRQUNBLElBQUk2RSxVQUFBLENBQVc1RixJQUFBLENBQUtoQixTQUFBLENBQVV3d0IsV0FBVyxHQUFHO1VBRXhDLElBQUl6dUIsR0FBQSxFQUFLO1lBQ0wsT0FBTyxLQUFLMnVCLE1BQUEsQ0FBTyxFQUFFRixXQUFBLENBQVk7VUFDckMsT0FBTztZQUNILE9BQU8sSUFBSXh2QixJQUFBLENBQUssS0FBS1MsT0FBQSxDQUFRLElBQUksS0FBSzJvQixTQUFBLENBQVUsSUFBSSxLQUFLLEdBQUksRUFDeERvRyxXQUFBLENBQVksRUFDWnptQixPQUFBLENBQVEsS0FBS0ksWUFBQSxDQUFhakgsQ0FBQSxFQUFHLEdBQUcsQ0FBQztVQUMxQztRQUNKO1FBQ0EsT0FBT2lILFlBQUEsQ0FDSGpILENBQUEsRUFDQW5CLEdBQUEsR0FBTSxpQ0FBaUMsNEJBQzNDO01BQ0o7TUFRQSxTQUFTNHVCLFFBQUEsRUFBVTtRQUNmLElBQUksQ0FBQyxLQUFLbnRCLE9BQUEsQ0FBUSxHQUFHO1VBQ2pCLE9BQU8sdUJBQXVCLEtBQUt1QixFQUFBLEdBQUs7UUFDNUM7UUFDQSxJQUFJMkUsSUFBQSxHQUFPO1VBQ1BrbkIsSUFBQSxHQUFPO1VBQ1BDLE1BQUE7VUFDQW5oQixJQUFBO1VBQ0FvaEIsUUFBQTtVQUNBQyxNQUFBO1FBQ0osSUFBSSxDQUFDLEtBQUs1RSxPQUFBLENBQVEsR0FBRztVQUNqQnppQixJQUFBLEdBQU8sS0FBSzBnQixTQUFBLENBQVUsTUFBTSxJQUFJLGVBQWU7VUFDL0N3RyxJQUFBLEdBQU87UUFDWDtRQUNBQyxNQUFBLEdBQVMsTUFBTW5uQixJQUFBLEdBQU87UUFDdEJnRyxJQUFBLEdBQU8sS0FBSyxLQUFLQSxJQUFBLENBQUssS0FBSyxLQUFLQSxJQUFBLENBQUssS0FBSyxPQUFPLFNBQVM7UUFDMURvaEIsUUFBQSxHQUFXO1FBQ1hDLE1BQUEsR0FBU0gsSUFBQSxHQUFPO1FBRWhCLE9BQU8sS0FBSzFCLE1BQUEsQ0FBTzJCLE1BQUEsR0FBU25oQixJQUFBLEdBQU9vaEIsUUFBQSxHQUFXQyxNQUFNO01BQ3hEO01BRUEsU0FBUzdCLE9BQU84QixXQUFBLEVBQWE7UUFDekIsSUFBSSxDQUFDQSxXQUFBLEVBQWE7VUFDZEEsV0FBQSxHQUFjLEtBQUszRSxLQUFBLENBQU0sSUFDbkI5c0IsS0FBQSxDQUFNK3dCLGdCQUFBLEdBQ04vd0IsS0FBQSxDQUFNOHdCLGFBQUE7UUFDaEI7UUFDQSxJQUFJam9CLE1BQUEsR0FBUytCLFlBQUEsQ0FBYSxNQUFNNm1CLFdBQVc7UUFDM0MsT0FBTyxLQUFLcm5CLFVBQUEsQ0FBVyxFQUFFc25CLFVBQUEsQ0FBVzdvQixNQUFNO01BQzlDO01BRUEsU0FBU3drQixLQUFLaUMsSUFBQSxFQUFNbGlCLGFBQUEsRUFBZTtRQUMvQixJQUNJLEtBQUtuSixPQUFBLENBQVEsTUFDWGlDLFFBQUEsQ0FBU29wQixJQUFJLEtBQUtBLElBQUEsQ0FBS3JyQixPQUFBLENBQVEsS0FBTTRpQixXQUFBLENBQVl5SSxJQUFJLEVBQUVyckIsT0FBQSxDQUFRLElBQ25FO1VBQ0UsT0FBT21sQixjQUFBLENBQWU7WUFBRWtFLEVBQUEsRUFBSTtZQUFNRCxJQUFBLEVBQU1pQztVQUFLLENBQUMsRUFDekMwQixNQUFBLENBQU8sS0FBS0EsTUFBQSxDQUFPLENBQUMsRUFDcEJXLFFBQUEsQ0FBUyxDQUFDdmtCLGFBQWE7UUFDaEMsT0FBTztVQUNILE9BQU8sS0FBS2hELFVBQUEsQ0FBVyxFQUFFUyxXQUFBLENBQVk7UUFDekM7TUFDSjtNQUVBLFNBQVMrbUIsUUFBUXhrQixhQUFBLEVBQWU7UUFDNUIsT0FBTyxLQUFLaWdCLElBQUEsQ0FBS3hHLFdBQUEsQ0FBWSxHQUFHelosYUFBYTtNQUNqRDtNQUVBLFNBQVNrZ0IsR0FBR2dDLElBQUEsRUFBTWxpQixhQUFBLEVBQWU7UUFDN0IsSUFDSSxLQUFLbkosT0FBQSxDQUFRLE1BQ1hpQyxRQUFBLENBQVNvcEIsSUFBSSxLQUFLQSxJQUFBLENBQUtyckIsT0FBQSxDQUFRLEtBQU00aUIsV0FBQSxDQUFZeUksSUFBSSxFQUFFcnJCLE9BQUEsQ0FBUSxJQUNuRTtVQUNFLE9BQU9tbEIsY0FBQSxDQUFlO1lBQUVpRSxJQUFBLEVBQU07WUFBTUMsRUFBQSxFQUFJZ0M7VUFBSyxDQUFDLEVBQ3pDMEIsTUFBQSxDQUFPLEtBQUtBLE1BQUEsQ0FBTyxDQUFDLEVBQ3BCVyxRQUFBLENBQVMsQ0FBQ3ZrQixhQUFhO1FBQ2hDLE9BQU87VUFDSCxPQUFPLEtBQUtoRCxVQUFBLENBQVcsRUFBRVMsV0FBQSxDQUFZO1FBQ3pDO01BQ0o7TUFFQSxTQUFTZ25CLE1BQU16a0IsYUFBQSxFQUFlO1FBQzFCLE9BQU8sS0FBS2tnQixFQUFBLENBQUd6RyxXQUFBLENBQVksR0FBR3paLGFBQWE7TUFDL0M7TUFLQSxTQUFTNGpCLE9BQU9wcUIsR0FBQSxFQUFLO1FBQ2pCLElBQUlrckIsYUFBQTtRQUVKLElBQUlsckIsR0FBQSxLQUFRLFFBQVc7VUFDbkIsT0FBTyxLQUFLZCxPQUFBLENBQVEyYixLQUFBO1FBQ3hCLE9BQU87VUFDSHFRLGFBQUEsR0FBZ0JoUSxTQUFBLENBQVVsYixHQUFHO1VBQzdCLElBQUlrckIsYUFBQSxJQUFpQixNQUFNO1lBQ3ZCLEtBQUtoc0IsT0FBQSxHQUFVZ3NCLGFBQUE7VUFDbkI7VUFDQSxPQUFPO1FBQ1g7TUFDSjtNQUVBLElBQUlDLElBQUEsR0FBT3hyQixTQUFBLENBQ1AsbUpBQ0EsVUFBVUssR0FBQSxFQUFLO1FBQ1gsSUFBSUEsR0FBQSxLQUFRLFFBQVc7VUFDbkIsT0FBTyxLQUFLd0QsVUFBQSxDQUFXO1FBQzNCLE9BQU87VUFDSCxPQUFPLEtBQUs0bUIsTUFBQSxDQUFPcHFCLEdBQUc7UUFDMUI7TUFDSixDQUNKO01BRUEsU0FBU3dELFdBQUEsRUFBYTtRQUNsQixPQUFPLEtBQUt0RSxPQUFBO01BQ2hCO01BRUEsSUFBSWtzQixhQUFBLEdBQWdCO1FBQ2hCQyxhQUFBLEdBQWdCLEtBQUtELGFBQUE7UUFDckJFLFdBQUEsR0FBYyxLQUFLRCxhQUFBO1FBQ25CRSxnQkFBQSxJQUFvQixNQUFNLE1BQU0sTUFBTSxLQUFLRCxXQUFBO01BRy9DLFNBQVNFLE1BQU1DLFFBQUEsRUFBVUMsT0FBQSxFQUFTO1FBQzlCLFFBQVNELFFBQUEsR0FBV0MsT0FBQSxHQUFXQSxPQUFBLElBQVdBLE9BQUE7TUFDOUM7TUFFQSxTQUFTQyxpQkFBaUJ0bEIsQ0FBQSxFQUFHdEosQ0FBQSxFQUFHZ0osQ0FBQSxFQUFHO1FBRS9CLElBQUlNLENBQUEsR0FBSSxPQUFPQSxDQUFBLElBQUssR0FBRztVQUVuQixPQUFPLElBQUl4TCxJQUFBLENBQUt3TCxDQUFBLEdBQUksS0FBS3RKLENBQUEsRUFBR2dKLENBQUMsSUFBSXdsQixnQkFBQTtRQUNyQyxPQUFPO1VBQ0gsT0FBTyxJQUFJMXdCLElBQUEsQ0FBS3dMLENBQUEsRUFBR3RKLENBQUEsRUFBR2dKLENBQUMsRUFBRXpLLE9BQUEsQ0FBUTtRQUNyQztNQUNKO01BRUEsU0FBU3N3QixlQUFldmxCLENBQUEsRUFBR3RKLENBQUEsRUFBR2dKLENBQUEsRUFBRztRQUU3QixJQUFJTSxDQUFBLEdBQUksT0FBT0EsQ0FBQSxJQUFLLEdBQUc7VUFFbkIsT0FBT3hMLElBQUEsQ0FBS3FaLEdBQUEsQ0FBSTdOLENBQUEsR0FBSSxLQUFLdEosQ0FBQSxFQUFHZ0osQ0FBQyxJQUFJd2xCLGdCQUFBO1FBQ3JDLE9BQU87VUFDSCxPQUFPMXdCLElBQUEsQ0FBS3FaLEdBQUEsQ0FBSTdOLENBQUEsRUFBR3RKLENBQUEsRUFBR2dKLENBQUM7UUFDM0I7TUFDSjtNQUVBLFNBQVM4aUIsUUFBUXBmLEtBQUEsRUFBTztRQUNwQixJQUFJaWYsSUFBQSxFQUFNbUQsV0FBQTtRQUNWcGlCLEtBQUEsR0FBUUQsY0FBQSxDQUFlQyxLQUFLO1FBQzVCLElBQUlBLEtBQUEsS0FBVSxVQUFhQSxLQUFBLEtBQVUsaUJBQWlCLENBQUMsS0FBS3BNLE9BQUEsQ0FBUSxHQUFHO1VBQ25FLE9BQU87UUFDWDtRQUVBd3VCLFdBQUEsR0FBYyxLQUFLN3NCLE1BQUEsR0FBUzRzQixjQUFBLEdBQWlCRCxnQkFBQTtRQUU3QyxRQUFRbGlCLEtBQUE7VUFBQSxLQUNDO1lBQ0RpZixJQUFBLEdBQU9tRCxXQUFBLENBQVksS0FBS3RpQixJQUFBLENBQUssR0FBRyxHQUFHLENBQUM7WUFDcEM7VUFBQSxLQUNDO1lBQ0RtZixJQUFBLEdBQU9tRCxXQUFBLENBQ0gsS0FBS3RpQixJQUFBLENBQUssR0FDVixLQUFLbEIsS0FBQSxDQUFNLElBQUssS0FBS0EsS0FBQSxDQUFNLElBQUksR0FDL0IsQ0FDSjtZQUNBO1VBQUEsS0FDQztZQUNEcWdCLElBQUEsR0FBT21ELFdBQUEsQ0FBWSxLQUFLdGlCLElBQUEsQ0FBSyxHQUFHLEtBQUtsQixLQUFBLENBQU0sR0FBRyxDQUFDO1lBQy9DO1VBQUEsS0FDQztZQUNEcWdCLElBQUEsR0FBT21ELFdBQUEsQ0FDSCxLQUFLdGlCLElBQUEsQ0FBSyxHQUNWLEtBQUtsQixLQUFBLENBQU0sR0FDWCxLQUFLcEIsSUFBQSxDQUFLLElBQUksS0FBS0ssT0FBQSxDQUFRLENBQy9CO1lBQ0E7VUFBQSxLQUNDO1lBQ0RvaEIsSUFBQSxHQUFPbUQsV0FBQSxDQUNILEtBQUt0aUIsSUFBQSxDQUFLLEdBQ1YsS0FBS2xCLEtBQUEsQ0FBTSxHQUNYLEtBQUtwQixJQUFBLENBQUssS0FBSyxLQUFLK0MsVUFBQSxDQUFXLElBQUksRUFDdkM7WUFDQTtVQUFBLEtBQ0M7VUFBQSxLQUNBO1lBQ0QwZSxJQUFBLEdBQU9tRCxXQUFBLENBQVksS0FBS3RpQixJQUFBLENBQUssR0FBRyxLQUFLbEIsS0FBQSxDQUFNLEdBQUcsS0FBS3BCLElBQUEsQ0FBSyxDQUFDO1lBQ3pEO1VBQUEsS0FDQztZQUNEeWhCLElBQUEsR0FBTyxLQUFLanJCLEVBQUEsQ0FBR25DLE9BQUEsQ0FBUTtZQUN2Qm90QixJQUFBLElBQVE4QyxLQUFBLENBQ0o5QyxJQUFBLElBQVEsS0FBSzFwQixNQUFBLEdBQVMsSUFBSSxLQUFLaWxCLFNBQUEsQ0FBVSxJQUFJb0gsYUFBQSxHQUM3Q0MsV0FDSjtZQUNBO1VBQUEsS0FDQztZQUNENUMsSUFBQSxHQUFPLEtBQUtqckIsRUFBQSxDQUFHbkMsT0FBQSxDQUFRO1lBQ3ZCb3RCLElBQUEsSUFBUThDLEtBQUEsQ0FBTTlDLElBQUEsRUFBTTJDLGFBQWE7WUFDakM7VUFBQSxLQUNDO1lBQ0QzQyxJQUFBLEdBQU8sS0FBS2pyQixFQUFBLENBQUduQyxPQUFBLENBQVE7WUFDdkJvdEIsSUFBQSxJQUFROEMsS0FBQSxDQUFNOUMsSUFBQSxFQUFNMEMsYUFBYTtZQUNqQztRQUFBO1FBR1IsS0FBSzN0QixFQUFBLENBQUdrbkIsT0FBQSxDQUFRK0QsSUFBSTtRQUNwQnR2QixLQUFBLENBQU1pRyxZQUFBLENBQWEsTUFBTSxJQUFJO1FBQzdCLE9BQU87TUFDWDtNQUVBLFNBQVM0cEIsTUFBTXhmLEtBQUEsRUFBTztRQUNsQixJQUFJaWYsSUFBQSxFQUFNbUQsV0FBQTtRQUNWcGlCLEtBQUEsR0FBUUQsY0FBQSxDQUFlQyxLQUFLO1FBQzVCLElBQUlBLEtBQUEsS0FBVSxVQUFhQSxLQUFBLEtBQVUsaUJBQWlCLENBQUMsS0FBS3BNLE9BQUEsQ0FBUSxHQUFHO1VBQ25FLE9BQU87UUFDWDtRQUVBd3VCLFdBQUEsR0FBYyxLQUFLN3NCLE1BQUEsR0FBUzRzQixjQUFBLEdBQWlCRCxnQkFBQTtRQUU3QyxRQUFRbGlCLEtBQUE7VUFBQSxLQUNDO1lBQ0RpZixJQUFBLEdBQU9tRCxXQUFBLENBQVksS0FBS3RpQixJQUFBLENBQUssSUFBSSxHQUFHLEdBQUcsQ0FBQyxJQUFJO1lBQzVDO1VBQUEsS0FDQztZQUNEbWYsSUFBQSxHQUNJbUQsV0FBQSxDQUNJLEtBQUt0aUIsSUFBQSxDQUFLLEdBQ1YsS0FBS2xCLEtBQUEsQ0FBTSxJQUFLLEtBQUtBLEtBQUEsQ0FBTSxJQUFJLElBQUssR0FDcEMsQ0FDSixJQUFJO1lBQ1I7VUFBQSxLQUNDO1lBQ0RxZ0IsSUFBQSxHQUFPbUQsV0FBQSxDQUFZLEtBQUt0aUIsSUFBQSxDQUFLLEdBQUcsS0FBS2xCLEtBQUEsQ0FBTSxJQUFJLEdBQUcsQ0FBQyxJQUFJO1lBQ3ZEO1VBQUEsS0FDQztZQUNEcWdCLElBQUEsR0FDSW1ELFdBQUEsQ0FDSSxLQUFLdGlCLElBQUEsQ0FBSyxHQUNWLEtBQUtsQixLQUFBLENBQU0sR0FDWCxLQUFLcEIsSUFBQSxDQUFLLElBQUksS0FBS0ssT0FBQSxDQUFRLElBQUksQ0FDbkMsSUFBSTtZQUNSO1VBQUEsS0FDQztZQUNEb2hCLElBQUEsR0FDSW1ELFdBQUEsQ0FDSSxLQUFLdGlCLElBQUEsQ0FBSyxHQUNWLEtBQUtsQixLQUFBLENBQU0sR0FDWCxLQUFLcEIsSUFBQSxDQUFLLEtBQUssS0FBSytDLFVBQUEsQ0FBVyxJQUFJLEtBQUssQ0FDNUMsSUFBSTtZQUNSO1VBQUEsS0FDQztVQUFBLEtBQ0E7WUFDRDBlLElBQUEsR0FBT21ELFdBQUEsQ0FBWSxLQUFLdGlCLElBQUEsQ0FBSyxHQUFHLEtBQUtsQixLQUFBLENBQU0sR0FBRyxLQUFLcEIsSUFBQSxDQUFLLElBQUksQ0FBQyxJQUFJO1lBQ2pFO1VBQUEsS0FDQztZQUNEeWhCLElBQUEsR0FBTyxLQUFLanJCLEVBQUEsQ0FBR25DLE9BQUEsQ0FBUTtZQUN2Qm90QixJQUFBLElBQ0k0QyxXQUFBLEdBQ0FFLEtBQUEsQ0FDSTlDLElBQUEsSUFBUSxLQUFLMXBCLE1BQUEsR0FBUyxJQUFJLEtBQUtpbEIsU0FBQSxDQUFVLElBQUlvSCxhQUFBLEdBQzdDQyxXQUNKLElBQ0E7WUFDSjtVQUFBLEtBQ0M7WUFDRDVDLElBQUEsR0FBTyxLQUFLanJCLEVBQUEsQ0FBR25DLE9BQUEsQ0FBUTtZQUN2Qm90QixJQUFBLElBQVEyQyxhQUFBLEdBQWdCRyxLQUFBLENBQU05QyxJQUFBLEVBQU0yQyxhQUFhLElBQUk7WUFDckQ7VUFBQSxLQUNDO1lBQ0QzQyxJQUFBLEdBQU8sS0FBS2pyQixFQUFBLENBQUduQyxPQUFBLENBQVE7WUFDdkJvdEIsSUFBQSxJQUFRMEMsYUFBQSxHQUFnQkksS0FBQSxDQUFNOUMsSUFBQSxFQUFNMEMsYUFBYSxJQUFJO1lBQ3JEO1FBQUE7UUFHUixLQUFLM3RCLEVBQUEsQ0FBR2tuQixPQUFBLENBQVErRCxJQUFJO1FBQ3BCdHZCLEtBQUEsQ0FBTWlHLFlBQUEsQ0FBYSxNQUFNLElBQUk7UUFDN0IsT0FBTztNQUNYO01BRUEsU0FBUy9ELFFBQUEsRUFBVTtRQUNmLE9BQU8sS0FBS21DLEVBQUEsQ0FBR25DLE9BQUEsQ0FBUSxLQUFLLEtBQUsyRCxPQUFBLElBQVcsS0FBSztNQUNyRDtNQUVBLFNBQVM2c0IsS0FBQSxFQUFPO1FBQ1osT0FBT3RwQixJQUFBLENBQUtzSyxLQUFBLENBQU0sS0FBS3hSLE9BQUEsQ0FBUSxJQUFJLEdBQUk7TUFDM0M7TUFFQSxTQUFTaXZCLE9BQUEsRUFBUztRQUNkLE9BQU8sSUFBSTF2QixJQUFBLENBQUssS0FBS1MsT0FBQSxDQUFRLENBQUM7TUFDbEM7TUFFQSxTQUFTeXFCLFFBQUEsRUFBVTtRQUNmLElBQUlocEIsQ0FBQSxHQUFJO1FBQ1IsT0FBTyxDQUNIQSxDQUFBLENBQUV3TSxJQUFBLENBQUssR0FDUHhNLENBQUEsQ0FBRXNMLEtBQUEsQ0FBTSxHQUNSdEwsQ0FBQSxDQUFFa0ssSUFBQSxDQUFLLEdBQ1BsSyxDQUFBLENBQUUrSyxJQUFBLENBQUssR0FDUC9LLENBQUEsQ0FBRW9MLE1BQUEsQ0FBTyxHQUNUcEwsQ0FBQSxDQUFFMkwsTUFBQSxDQUFPLEdBQ1QzTCxDQUFBLENBQUVrTCxXQUFBLENBQVksRUFDbEI7TUFDSjtNQUVBLFNBQVM4akIsU0FBQSxFQUFXO1FBQ2hCLElBQUlodkIsQ0FBQSxHQUFJO1FBQ1IsT0FBTztVQUNIdU0sS0FBQSxFQUFPdk0sQ0FBQSxDQUFFd00sSUFBQSxDQUFLO1VBQ2RuQixNQUFBLEVBQVFyTCxDQUFBLENBQUVzTCxLQUFBLENBQU07VUFDaEJwQixJQUFBLEVBQU1sSyxDQUFBLENBQUVrSyxJQUFBLENBQUs7VUFDYlksS0FBQSxFQUFPOUssQ0FBQSxDQUFFOEssS0FBQSxDQUFNO1VBQ2ZLLE9BQUEsRUFBU25MLENBQUEsQ0FBRW1MLE9BQUEsQ0FBUTtVQUNuQk8sT0FBQSxFQUFTMUwsQ0FBQSxDQUFFMEwsT0FBQSxDQUFRO1VBQ25CVCxZQUFBLEVBQWNqTCxDQUFBLENBQUVpTCxZQUFBLENBQWE7UUFDakM7TUFDSjtNQUVBLFNBQVNna0IsT0FBQSxFQUFTO1FBRWQsT0FBTyxLQUFLM3VCLE9BQUEsQ0FBUSxJQUFJLEtBQUtndEIsV0FBQSxDQUFZLElBQUk7TUFDakQ7TUFFQSxTQUFTNEIsVUFBQSxFQUFZO1FBQ2pCLE9BQU81dUIsT0FBQSxDQUFRLElBQUk7TUFDdkI7TUFFQSxTQUFTNnVCLGFBQUEsRUFBZTtRQUNwQixPQUFPN3dCLE1BQUEsQ0FBTyxDQUFDLEdBQUd5QixlQUFBLENBQWdCLElBQUksQ0FBQztNQUMzQztNQUVBLFNBQVNxdkIsVUFBQSxFQUFZO1FBQ2pCLE9BQU9ydkIsZUFBQSxDQUFnQixJQUFJLEVBQUViLFFBQUE7TUFDakM7TUFFQSxTQUFTbXdCLGFBQUEsRUFBZTtRQUNwQixPQUFPO1VBQ0gxeUIsS0FBQSxFQUFPLEtBQUtrRixFQUFBO1VBQ1ptcUIsTUFBQSxFQUFRLEtBQUtscUIsRUFBQTtVQUNidXJCLE1BQUEsRUFBUSxLQUFLbHJCLE9BQUE7VUFDYjZQLEtBQUEsRUFBTyxLQUFLL1AsTUFBQTtVQUNadEQsTUFBQSxFQUFRLEtBQUttQztRQUNqQjtNQUNKO01BRUFzRixjQUFBLENBQWUsS0FBSyxHQUFHLEdBQUcsU0FBUztNQUNuQ0EsY0FBQSxDQUFlLE1BQU0sR0FBRyxHQUFHLFNBQVM7TUFDcENBLGNBQUEsQ0FBZSxPQUFPLEdBQUcsR0FBRyxTQUFTO01BQ3JDQSxjQUFBLENBQWUsUUFBUSxHQUFHLEdBQUcsU0FBUztNQUN0Q0EsY0FBQSxDQUFlLFNBQVMsR0FBRyxHQUFHLFdBQVc7TUFFekNBLGNBQUEsQ0FBZSxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsTUFBTSxTQUFTO01BQzdDQSxjQUFBLENBQWUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsU0FBUztNQUMzQ0EsY0FBQSxDQUFlLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxHQUFHLFNBQVM7TUFDNUNBLGNBQUEsQ0FBZSxLQUFLLENBQUMsUUFBUSxDQUFDLEdBQUcsR0FBRyxTQUFTO01BRTdDNEksYUFBQSxDQUFjLEtBQUtzZ0IsWUFBWTtNQUMvQnRnQixhQUFBLENBQWMsTUFBTXNnQixZQUFZO01BQ2hDdGdCLGFBQUEsQ0FBYyxPQUFPc2dCLFlBQVk7TUFDakN0Z0IsYUFBQSxDQUFjLFFBQVF1Z0IsWUFBWTtNQUNsQ3ZnQixhQUFBLENBQWMsU0FBU3dnQixjQUFjO01BRXJDbGYsYUFBQSxDQUNJLENBQUMsS0FBSyxNQUFNLE9BQU8sUUFBUSxPQUFPLEdBQ2xDLFVBQVUzVCxLQUFBLEVBQU9vSyxLQUFBLEVBQU8xRSxNQUFBLEVBQVFnRSxNQUFBLEVBQU87UUFDbkMsSUFBSTFHLEdBQUEsR0FBTTBDLE1BQUEsQ0FBT0YsT0FBQSxDQUFRc3RCLFNBQUEsQ0FBVTl5QixLQUFBLEVBQU8wSixNQUFBLEVBQU9oRSxNQUFBLENBQU92QixPQUFPO1FBQy9ELElBQUluQixHQUFBLEVBQUs7VUFDTEksZUFBQSxDQUFnQnNDLE1BQU0sRUFBRTFDLEdBQUEsR0FBTUEsR0FBQTtRQUNsQyxPQUFPO1VBQ0hJLGVBQUEsQ0FBZ0JzQyxNQUFNLEVBQUVoRCxVQUFBLEdBQWExQyxLQUFBO1FBQ3pDO01BQ0osQ0FDSjtNQUVBcVMsYUFBQSxDQUFjLEtBQUtULGFBQWE7TUFDaENTLGFBQUEsQ0FBYyxNQUFNVCxhQUFhO01BQ2pDUyxhQUFBLENBQWMsT0FBT1QsYUFBYTtNQUNsQ1MsYUFBQSxDQUFjLFFBQVFULGFBQWE7TUFDbkNTLGFBQUEsQ0FBYyxNQUFNMGdCLG1CQUFtQjtNQUV2Q3BmLGFBQUEsQ0FBYyxDQUFDLEtBQUssTUFBTSxPQUFPLE1BQU0sR0FBR1EsSUFBSTtNQUM5Q1IsYUFBQSxDQUFjLENBQUMsSUFBSSxHQUFHLFVBQVUzVCxLQUFBLEVBQU9vSyxLQUFBLEVBQU8xRSxNQUFBLEVBQVFnRSxNQUFBLEVBQU87UUFDekQsSUFBSU8sS0FBQTtRQUNKLElBQUl2RSxNQUFBLENBQU9GLE9BQUEsQ0FBUXd0QixvQkFBQSxFQUFzQjtVQUNyQy9vQixLQUFBLEdBQVFqSyxLQUFBLENBQU1pSyxLQUFBLENBQU12RSxNQUFBLENBQU9GLE9BQUEsQ0FBUXd0QixvQkFBb0I7UUFDM0Q7UUFFQSxJQUFJdHRCLE1BQUEsQ0FBT0YsT0FBQSxDQUFReXRCLG1CQUFBLEVBQXFCO1VBQ3BDN29CLEtBQUEsQ0FBTStKLElBQUEsSUFBUXpPLE1BQUEsQ0FBT0YsT0FBQSxDQUFReXRCLG1CQUFBLENBQW9CanpCLEtBQUEsRUFBT2lLLEtBQUs7UUFDakUsT0FBTztVQUNIRyxLQUFBLENBQU0rSixJQUFBLElBQVFVLFFBQUEsQ0FBUzdVLEtBQUEsRUFBTyxFQUFFO1FBQ3BDO01BQ0osQ0FBQztNQUVELFNBQVNrekIsV0FBVzd2QixDQUFBLEVBQUd2QixPQUFBLEVBQVE7UUFDM0IsSUFBSU4sQ0FBQTtVQUNBOGhCLENBQUE7VUFDQS9WLElBQUE7VUFDQTRsQixJQUFBLEdBQU8sS0FBS0MsS0FBQSxJQUFTNVIsU0FBQSxDQUFVLElBQUksRUFBRTRSLEtBQUE7UUFDekMsS0FBSzV4QixDQUFBLEdBQUksR0FBRzhoQixDQUFBLEdBQUk2UCxJQUFBLENBQUtyeUIsTUFBQSxFQUFRVSxDQUFBLEdBQUk4aEIsQ0FBQSxFQUFHLEVBQUU5aEIsQ0FBQSxFQUFHO1VBQ3JDLFFBQVEsT0FBTzJ4QixJQUFBLENBQUszeEIsQ0FBQSxFQUFHNnhCLEtBQUE7WUFBQSxLQUNkO2NBRUQ5bEIsSUFBQSxHQUFPN04sS0FBQSxDQUFNeXpCLElBQUEsQ0FBSzN4QixDQUFBLEVBQUc2eEIsS0FBSyxFQUFFbEUsT0FBQSxDQUFRLEtBQUs7Y0FDekNnRSxJQUFBLENBQUszeEIsQ0FBQSxFQUFHNnhCLEtBQUEsR0FBUTlsQixJQUFBLENBQUszTCxPQUFBLENBQVE7Y0FDN0I7VUFBQTtVQUdSLFFBQVEsT0FBT3V4QixJQUFBLENBQUszeEIsQ0FBQSxFQUFHOHhCLEtBQUE7WUFBQSxLQUNkO2NBQ0RILElBQUEsQ0FBSzN4QixDQUFBLEVBQUc4eEIsS0FBQSxHQUFRQyxRQUFBO2NBQ2hCO1lBQUEsS0FDQztjQUVEaG1CLElBQUEsR0FBTzdOLEtBQUEsQ0FBTXl6QixJQUFBLENBQUszeEIsQ0FBQSxFQUFHOHhCLEtBQUssRUFBRW5FLE9BQUEsQ0FBUSxLQUFLLEVBQUV2dEIsT0FBQSxDQUFRO2NBQ25EdXhCLElBQUEsQ0FBSzN4QixDQUFBLEVBQUc4eEIsS0FBQSxHQUFRL2xCLElBQUEsQ0FBSzNMLE9BQUEsQ0FBUTtjQUM3QjtVQUFBO1FBRVo7UUFDQSxPQUFPdXhCLElBQUE7TUFDWDtNQUVBLFNBQVNLLGdCQUFnQkMsT0FBQSxFQUFTM3hCLE9BQUEsRUFBUUUsTUFBQSxFQUFRO1FBQzlDLElBQUlSLENBQUE7VUFDQThoQixDQUFBO1VBQ0E2UCxJQUFBLEdBQU8sS0FBS0EsSUFBQSxDQUFLO1VBQ2pCcnNCLElBQUE7VUFDQTRhLElBQUE7VUFDQWdTLE1BQUE7UUFDSkQsT0FBQSxHQUFVQSxPQUFBLENBQVFub0IsV0FBQSxDQUFZO1FBRTlCLEtBQUs5SixDQUFBLEdBQUksR0FBRzhoQixDQUFBLEdBQUk2UCxJQUFBLENBQUtyeUIsTUFBQSxFQUFRVSxDQUFBLEdBQUk4aEIsQ0FBQSxFQUFHLEVBQUU5aEIsQ0FBQSxFQUFHO1VBQ3JDc0YsSUFBQSxHQUFPcXNCLElBQUEsQ0FBSzN4QixDQUFBLEVBQUdzRixJQUFBLENBQUt3RSxXQUFBLENBQVk7VUFDaENvVyxJQUFBLEdBQU95UixJQUFBLENBQUszeEIsQ0FBQSxFQUFHa2dCLElBQUEsQ0FBS3BXLFdBQUEsQ0FBWTtVQUNoQ29vQixNQUFBLEdBQVNQLElBQUEsQ0FBSzN4QixDQUFBLEVBQUdreUIsTUFBQSxDQUFPcG9CLFdBQUEsQ0FBWTtVQUVwQyxJQUFJdEosTUFBQSxFQUFRO1lBQ1IsUUFBUUYsT0FBQTtjQUFBLEtBQ0M7Y0FBQSxLQUNBO2NBQUEsS0FDQTtnQkFDRCxJQUFJNGYsSUFBQSxLQUFTK1IsT0FBQSxFQUFTO2tCQUNsQixPQUFPTixJQUFBLENBQUszeEIsQ0FBQTtnQkFDaEI7Z0JBQ0E7Y0FBQSxLQUVDO2dCQUNELElBQUlzRixJQUFBLEtBQVMyc0IsT0FBQSxFQUFTO2tCQUNsQixPQUFPTixJQUFBLENBQUszeEIsQ0FBQTtnQkFDaEI7Z0JBQ0E7Y0FBQSxLQUVDO2dCQUNELElBQUlreUIsTUFBQSxLQUFXRCxPQUFBLEVBQVM7a0JBQ3BCLE9BQU9OLElBQUEsQ0FBSzN4QixDQUFBO2dCQUNoQjtnQkFDQTtZQUFBO1VBRVosV0FBVyxDQUFDc0YsSUFBQSxFQUFNNGEsSUFBQSxFQUFNZ1MsTUFBTSxFQUFFamMsT0FBQSxDQUFRZ2MsT0FBTyxLQUFLLEdBQUc7WUFDbkQsT0FBT04sSUFBQSxDQUFLM3hCLENBQUE7VUFDaEI7UUFDSjtNQUNKO01BRUEsU0FBU215QixzQkFBc0Izd0IsR0FBQSxFQUFLNk0sSUFBQSxFQUFNO1FBQ3RDLElBQUkrakIsR0FBQSxHQUFNNXdCLEdBQUEsQ0FBSXF3QixLQUFBLElBQVNyd0IsR0FBQSxDQUFJc3dCLEtBQUEsR0FBUSxJQUFLO1FBQ3hDLElBQUl6akIsSUFBQSxLQUFTLFFBQVc7VUFDcEIsT0FBT25RLEtBQUEsQ0FBTXNELEdBQUEsQ0FBSXF3QixLQUFLLEVBQUV4akIsSUFBQSxDQUFLO1FBQ2pDLE9BQU87VUFDSCxPQUFPblEsS0FBQSxDQUFNc0QsR0FBQSxDQUFJcXdCLEtBQUssRUFBRXhqQixJQUFBLENBQUssS0FBS0EsSUFBQSxHQUFPN00sR0FBQSxDQUFJb25CLE1BQUEsSUFBVXdKLEdBQUE7UUFDM0Q7TUFDSjtNQUVBLFNBQVNDLFdBQUEsRUFBYTtRQUNsQixJQUFJcnlCLENBQUE7VUFDQThoQixDQUFBO1VBQ0F2ZSxHQUFBO1VBQ0FvdUIsSUFBQSxHQUFPLEtBQUtycEIsVUFBQSxDQUFXLEVBQUVxcEIsSUFBQSxDQUFLO1FBQ2xDLEtBQUszeEIsQ0FBQSxHQUFJLEdBQUc4aEIsQ0FBQSxHQUFJNlAsSUFBQSxDQUFLcnlCLE1BQUEsRUFBUVUsQ0FBQSxHQUFJOGhCLENBQUEsRUFBRyxFQUFFOWhCLENBQUEsRUFBRztVQUVyQ3VELEdBQUEsR0FBTSxLQUFLaW1CLEtBQUEsQ0FBTSxFQUFFbUUsT0FBQSxDQUFRLEtBQUssRUFBRXZ0QixPQUFBLENBQVE7VUFFMUMsSUFBSXV4QixJQUFBLENBQUszeEIsQ0FBQSxFQUFHNnhCLEtBQUEsSUFBU3R1QixHQUFBLElBQU9BLEdBQUEsSUFBT291QixJQUFBLENBQUszeEIsQ0FBQSxFQUFHOHhCLEtBQUEsRUFBTztZQUM5QyxPQUFPSCxJQUFBLENBQUszeEIsQ0FBQSxFQUFHc0YsSUFBQTtVQUNuQjtVQUNBLElBQUlxc0IsSUFBQSxDQUFLM3hCLENBQUEsRUFBRzh4QixLQUFBLElBQVN2dUIsR0FBQSxJQUFPQSxHQUFBLElBQU9vdUIsSUFBQSxDQUFLM3hCLENBQUEsRUFBRzZ4QixLQUFBLEVBQU87WUFDOUMsT0FBT0YsSUFBQSxDQUFLM3hCLENBQUEsRUFBR3NGLElBQUE7VUFDbkI7UUFDSjtRQUVBLE9BQU87TUFDWDtNQUVBLFNBQVNndEIsYUFBQSxFQUFlO1FBQ3BCLElBQUl0eUIsQ0FBQTtVQUNBOGhCLENBQUE7VUFDQXZlLEdBQUE7VUFDQW91QixJQUFBLEdBQU8sS0FBS3JwQixVQUFBLENBQVcsRUFBRXFwQixJQUFBLENBQUs7UUFDbEMsS0FBSzN4QixDQUFBLEdBQUksR0FBRzhoQixDQUFBLEdBQUk2UCxJQUFBLENBQUtyeUIsTUFBQSxFQUFRVSxDQUFBLEdBQUk4aEIsQ0FBQSxFQUFHLEVBQUU5aEIsQ0FBQSxFQUFHO1VBRXJDdUQsR0FBQSxHQUFNLEtBQUtpbUIsS0FBQSxDQUFNLEVBQUVtRSxPQUFBLENBQVEsS0FBSyxFQUFFdnRCLE9BQUEsQ0FBUTtVQUUxQyxJQUFJdXhCLElBQUEsQ0FBSzN4QixDQUFBLEVBQUc2eEIsS0FBQSxJQUFTdHVCLEdBQUEsSUFBT0EsR0FBQSxJQUFPb3VCLElBQUEsQ0FBSzN4QixDQUFBLEVBQUc4eEIsS0FBQSxFQUFPO1lBQzlDLE9BQU9ILElBQUEsQ0FBSzN4QixDQUFBLEVBQUdreUIsTUFBQTtVQUNuQjtVQUNBLElBQUlQLElBQUEsQ0FBSzN4QixDQUFBLEVBQUc4eEIsS0FBQSxJQUFTdnVCLEdBQUEsSUFBT0EsR0FBQSxJQUFPb3VCLElBQUEsQ0FBSzN4QixDQUFBLEVBQUc2eEIsS0FBQSxFQUFPO1lBQzlDLE9BQU9GLElBQUEsQ0FBSzN4QixDQUFBLEVBQUdreUIsTUFBQTtVQUNuQjtRQUNKO1FBRUEsT0FBTztNQUNYO01BRUEsU0FBU0ssV0FBQSxFQUFhO1FBQ2xCLElBQUl2eUIsQ0FBQTtVQUNBOGhCLENBQUE7VUFDQXZlLEdBQUE7VUFDQW91QixJQUFBLEdBQU8sS0FBS3JwQixVQUFBLENBQVcsRUFBRXFwQixJQUFBLENBQUs7UUFDbEMsS0FBSzN4QixDQUFBLEdBQUksR0FBRzhoQixDQUFBLEdBQUk2UCxJQUFBLENBQUtyeUIsTUFBQSxFQUFRVSxDQUFBLEdBQUk4aEIsQ0FBQSxFQUFHLEVBQUU5aEIsQ0FBQSxFQUFHO1VBRXJDdUQsR0FBQSxHQUFNLEtBQUtpbUIsS0FBQSxDQUFNLEVBQUVtRSxPQUFBLENBQVEsS0FBSyxFQUFFdnRCLE9BQUEsQ0FBUTtVQUUxQyxJQUFJdXhCLElBQUEsQ0FBSzN4QixDQUFBLEVBQUc2eEIsS0FBQSxJQUFTdHVCLEdBQUEsSUFBT0EsR0FBQSxJQUFPb3VCLElBQUEsQ0FBSzN4QixDQUFBLEVBQUc4eEIsS0FBQSxFQUFPO1lBQzlDLE9BQU9ILElBQUEsQ0FBSzN4QixDQUFBLEVBQUdrZ0IsSUFBQTtVQUNuQjtVQUNBLElBQUl5UixJQUFBLENBQUszeEIsQ0FBQSxFQUFHOHhCLEtBQUEsSUFBU3Z1QixHQUFBLElBQU9BLEdBQUEsSUFBT291QixJQUFBLENBQUszeEIsQ0FBQSxFQUFHNnhCLEtBQUEsRUFBTztZQUM5QyxPQUFPRixJQUFBLENBQUszeEIsQ0FBQSxFQUFHa2dCLElBQUE7VUFDbkI7UUFDSjtRQUVBLE9BQU87TUFDWDtNQUVBLFNBQVNzUyxXQUFBLEVBQWE7UUFDbEIsSUFBSXh5QixDQUFBO1VBQ0E4aEIsQ0FBQTtVQUNBc1EsR0FBQTtVQUNBN3VCLEdBQUE7VUFDQW91QixJQUFBLEdBQU8sS0FBS3JwQixVQUFBLENBQVcsRUFBRXFwQixJQUFBLENBQUs7UUFDbEMsS0FBSzN4QixDQUFBLEdBQUksR0FBRzhoQixDQUFBLEdBQUk2UCxJQUFBLENBQUtyeUIsTUFBQSxFQUFRVSxDQUFBLEdBQUk4aEIsQ0FBQSxFQUFHLEVBQUU5aEIsQ0FBQSxFQUFHO1VBQ3JDb3lCLEdBQUEsR0FBTVQsSUFBQSxDQUFLM3hCLENBQUEsRUFBRzZ4QixLQUFBLElBQVNGLElBQUEsQ0FBSzN4QixDQUFBLEVBQUc4eEIsS0FBQSxHQUFRLElBQUs7VUFHNUN2dUIsR0FBQSxHQUFNLEtBQUtpbUIsS0FBQSxDQUFNLEVBQUVtRSxPQUFBLENBQVEsS0FBSyxFQUFFdnRCLE9BQUEsQ0FBUTtVQUUxQyxJQUNLdXhCLElBQUEsQ0FBSzN4QixDQUFBLEVBQUc2eEIsS0FBQSxJQUFTdHVCLEdBQUEsSUFBT0EsR0FBQSxJQUFPb3VCLElBQUEsQ0FBSzN4QixDQUFBLEVBQUc4eEIsS0FBQSxJQUN2Q0gsSUFBQSxDQUFLM3hCLENBQUEsRUFBRzh4QixLQUFBLElBQVN2dUIsR0FBQSxJQUFPQSxHQUFBLElBQU9vdUIsSUFBQSxDQUFLM3hCLENBQUEsRUFBRzZ4QixLQUFBLEVBQzFDO1lBQ0UsUUFDSyxLQUFLeGpCLElBQUEsQ0FBSyxJQUFJblEsS0FBQSxDQUFNeXpCLElBQUEsQ0FBSzN4QixDQUFBLEVBQUc2eEIsS0FBSyxFQUFFeGpCLElBQUEsQ0FBSyxLQUFLK2pCLEdBQUEsR0FDOUNULElBQUEsQ0FBSzN4QixDQUFBLEVBQUc0b0IsTUFBQTtVQUVoQjtRQUNKO1FBRUEsT0FBTyxLQUFLdmEsSUFBQSxDQUFLO01BQ3JCO01BRUEsU0FBU29rQixjQUFjemhCLFFBQUEsRUFBVTtRQUM3QixJQUFJLENBQUNqUyxVQUFBLENBQVcsTUFBTSxnQkFBZ0IsR0FBRztVQUNyQzJ6QixnQkFBQSxDQUFpQjd6QixJQUFBLENBQUssSUFBSTtRQUM5QjtRQUNBLE9BQU9tUyxRQUFBLEdBQVcsS0FBSzJoQixjQUFBLEdBQWlCLEtBQUtDLFVBQUE7TUFDakQ7TUFFQSxTQUFTQyxjQUFjN2hCLFFBQUEsRUFBVTtRQUM3QixJQUFJLENBQUNqUyxVQUFBLENBQVcsTUFBTSxnQkFBZ0IsR0FBRztVQUNyQzJ6QixnQkFBQSxDQUFpQjd6QixJQUFBLENBQUssSUFBSTtRQUM5QjtRQUNBLE9BQU9tUyxRQUFBLEdBQVcsS0FBSzhoQixjQUFBLEdBQWlCLEtBQUtGLFVBQUE7TUFDakQ7TUFFQSxTQUFTRyxnQkFBZ0IvaEIsUUFBQSxFQUFVO1FBQy9CLElBQUksQ0FBQ2pTLFVBQUEsQ0FBVyxNQUFNLGtCQUFrQixHQUFHO1VBQ3ZDMnpCLGdCQUFBLENBQWlCN3pCLElBQUEsQ0FBSyxJQUFJO1FBQzlCO1FBQ0EsT0FBT21TLFFBQUEsR0FBVyxLQUFLZ2lCLGdCQUFBLEdBQW1CLEtBQUtKLFVBQUE7TUFDbkQ7TUFFQSxTQUFTekIsYUFBYW5nQixRQUFBLEVBQVV6USxPQUFBLEVBQVE7UUFDcEMsT0FBT0EsT0FBQSxDQUFPc3lCLGFBQUEsQ0FBYzdoQixRQUFRO01BQ3hDO01BRUEsU0FBU29nQixhQUFhcGdCLFFBQUEsRUFBVXpRLE9BQUEsRUFBUTtRQUNwQyxPQUFPQSxPQUFBLENBQU9reUIsYUFBQSxDQUFjemhCLFFBQVE7TUFDeEM7TUFFQSxTQUFTcWdCLGVBQWVyZ0IsUUFBQSxFQUFVelEsT0FBQSxFQUFRO1FBQ3RDLE9BQU9BLE9BQUEsQ0FBT3d5QixlQUFBLENBQWdCL2hCLFFBQVE7TUFDMUM7TUFFQSxTQUFTdWdCLG9CQUFvQnZnQixRQUFBLEVBQVV6USxPQUFBLEVBQVE7UUFDM0MsT0FBT0EsT0FBQSxDQUFPaXhCLG9CQUFBLElBQXdCcGhCLGFBQUE7TUFDMUM7TUFFQSxTQUFTc2lCLGlCQUFBLEVBQW1CO1FBQ3hCLElBQUlPLFVBQUEsR0FBYSxFQUFDO1VBQ2RDLFVBQUEsR0FBYSxFQUFDO1VBQ2RDLFlBQUEsR0FBZSxFQUFDO1VBQ2hCeGEsV0FBQSxHQUFjLEVBQUM7VUFDZjNZLENBQUE7VUFDQThoQixDQUFBO1VBQ0FzUixRQUFBO1VBQ0FDLFFBQUE7VUFDQUMsVUFBQTtVQUNBM0IsSUFBQSxHQUFPLEtBQUtBLElBQUEsQ0FBSztRQUVyQixLQUFLM3hCLENBQUEsR0FBSSxHQUFHOGhCLENBQUEsR0FBSTZQLElBQUEsQ0FBS3J5QixNQUFBLEVBQVFVLENBQUEsR0FBSThoQixDQUFBLEVBQUcsRUFBRTloQixDQUFBLEVBQUc7VUFDckNvekIsUUFBQSxHQUFXaGlCLFdBQUEsQ0FBWXVnQixJQUFBLENBQUszeEIsQ0FBQSxFQUFHc0YsSUFBSTtVQUNuQyt0QixRQUFBLEdBQVdqaUIsV0FBQSxDQUFZdWdCLElBQUEsQ0FBSzN4QixDQUFBLEVBQUdrZ0IsSUFBSTtVQUNuQ29ULFVBQUEsR0FBYWxpQixXQUFBLENBQVl1Z0IsSUFBQSxDQUFLM3hCLENBQUEsRUFBR2t5QixNQUFNO1VBRXZDZ0IsVUFBQSxDQUFXaHpCLElBQUEsQ0FBS2t6QixRQUFRO1VBQ3hCSCxVQUFBLENBQVcveUIsSUFBQSxDQUFLbXpCLFFBQVE7VUFDeEJGLFlBQUEsQ0FBYWp6QixJQUFBLENBQUtvekIsVUFBVTtVQUM1QjNhLFdBQUEsQ0FBWXpZLElBQUEsQ0FBS2t6QixRQUFRO1VBQ3pCemEsV0FBQSxDQUFZelksSUFBQSxDQUFLbXpCLFFBQVE7VUFDekIxYSxXQUFBLENBQVl6WSxJQUFBLENBQUtvekIsVUFBVTtRQUMvQjtRQUVBLEtBQUtWLFVBQUEsR0FBYSxJQUFJaHRCLE1BQUEsQ0FBTyxPQUFPK1MsV0FBQSxDQUFZMVQsSUFBQSxDQUFLLEdBQUcsSUFBSSxLQUFLLEdBQUc7UUFDcEUsS0FBSzB0QixjQUFBLEdBQWlCLElBQUkvc0IsTUFBQSxDQUFPLE9BQU9zdEIsVUFBQSxDQUFXanVCLElBQUEsQ0FBSyxHQUFHLElBQUksS0FBSyxHQUFHO1FBQ3ZFLEtBQUs2dEIsY0FBQSxHQUFpQixJQUFJbHRCLE1BQUEsQ0FBTyxPQUFPcXRCLFVBQUEsQ0FBV2h1QixJQUFBLENBQUssR0FBRyxJQUFJLEtBQUssR0FBRztRQUN2RSxLQUFLK3RCLGdCQUFBLEdBQW1CLElBQUlwdEIsTUFBQSxDQUN4QixPQUFPdXRCLFlBQUEsQ0FBYWx1QixJQUFBLENBQUssR0FBRyxJQUFJLEtBQ2hDLEdBQ0o7TUFDSjtNQUlBZ0QsY0FBQSxDQUFlLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLFlBQVk7UUFDeEMsT0FBTyxLQUFLK0csUUFBQSxDQUFTLElBQUk7TUFDN0IsQ0FBQztNQUVEL0csY0FBQSxDQUFlLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLFlBQVk7UUFDeEMsT0FBTyxLQUFLZ0gsV0FBQSxDQUFZLElBQUk7TUFDaEMsQ0FBQztNQUVELFNBQVNza0IsdUJBQXVCcnJCLE1BQUEsRUFBT3NyQixNQUFBLEVBQVE7UUFDM0N2ckIsY0FBQSxDQUFlLEdBQUcsQ0FBQ0MsTUFBQSxFQUFPQSxNQUFBLENBQU01SSxNQUFNLEdBQUcsR0FBR2swQixNQUFNO01BQ3REO01BRUFELHNCQUFBLENBQXVCLFFBQVEsVUFBVTtNQUN6Q0Esc0JBQUEsQ0FBdUIsU0FBUyxVQUFVO01BQzFDQSxzQkFBQSxDQUF1QixRQUFRLGFBQWE7TUFDNUNBLHNCQUFBLENBQXVCLFNBQVMsYUFBYTtNQU03QzFpQixhQUFBLENBQWMsS0FBS1IsV0FBVztNQUM5QlEsYUFBQSxDQUFjLEtBQUtSLFdBQVc7TUFDOUJRLGFBQUEsQ0FBYyxNQUFNZixTQUFBLEVBQVdKLE1BQU07TUFDckNtQixhQUFBLENBQWMsTUFBTWYsU0FBQSxFQUFXSixNQUFNO01BQ3JDbUIsYUFBQSxDQUFjLFFBQVFYLFNBQUEsRUFBV04sTUFBTTtNQUN2Q2lCLGFBQUEsQ0FBYyxRQUFRWCxTQUFBLEVBQVdOLE1BQU07TUFDdkNpQixhQUFBLENBQWMsU0FBU1YsU0FBQSxFQUFXTixNQUFNO01BQ3hDZ0IsYUFBQSxDQUFjLFNBQVNWLFNBQUEsRUFBV04sTUFBTTtNQUV4Q3dDLGlCQUFBLENBQ0ksQ0FBQyxRQUFRLFNBQVMsUUFBUSxPQUFPLEdBQ2pDLFVBQVU3VCxLQUFBLEVBQU93UCxJQUFBLEVBQU05SixNQUFBLEVBQVFnRSxNQUFBLEVBQU87UUFDbEM4RixJQUFBLENBQUs5RixNQUFBLENBQU1OLE1BQUEsQ0FBTyxHQUFHLENBQUMsS0FBS2lLLEtBQUEsQ0FBTXJULEtBQUs7TUFDMUMsQ0FDSjtNQUVBNlQsaUJBQUEsQ0FBa0IsQ0FBQyxNQUFNLElBQUksR0FBRyxVQUFVN1QsS0FBQSxFQUFPd1AsSUFBQSxFQUFNOUosTUFBQSxFQUFRZ0UsTUFBQSxFQUFPO1FBQ2xFOEYsSUFBQSxDQUFLOUYsTUFBQSxJQUFTaEssS0FBQSxDQUFNa1YsaUJBQUEsQ0FBa0I1VSxLQUFLO01BQy9DLENBQUM7TUFJRCxTQUFTaTFCLGVBQWVqMUIsS0FBQSxFQUFPO1FBQzNCLE9BQU9rMUIsb0JBQUEsQ0FBcUI3MEIsSUFBQSxDQUN4QixNQUNBTCxLQUFBLEVBQ0EsS0FBS3dQLElBQUEsQ0FBSyxHQUNWLEtBQUs1QixPQUFBLENBQVEsSUFBSSxLQUFLOUQsVUFBQSxDQUFXLEVBQUUwUixLQUFBLENBQU1kLEdBQUEsRUFDekMsS0FBSzVRLFVBQUEsQ0FBVyxFQUFFMFIsS0FBQSxDQUFNZCxHQUFBLEVBQ3hCLEtBQUs1USxVQUFBLENBQVcsRUFBRTBSLEtBQUEsQ0FBTWIsR0FDNUI7TUFDSjtNQUVBLFNBQVN3YSxrQkFBa0JuMUIsS0FBQSxFQUFPO1FBQzlCLE9BQU9rMUIsb0JBQUEsQ0FBcUI3MEIsSUFBQSxDQUN4QixNQUNBTCxLQUFBLEVBQ0EsS0FBSzBRLE9BQUEsQ0FBUSxHQUNiLEtBQUtKLFVBQUEsQ0FBVyxHQUNoQixHQUNBLENBQ0o7TUFDSjtNQUVBLFNBQVM4a0Isa0JBQUEsRUFBb0I7UUFDekIsT0FBTy9aLFdBQUEsQ0FBWSxLQUFLeEwsSUFBQSxDQUFLLEdBQUcsR0FBRyxDQUFDO01BQ3hDO01BRUEsU0FBU3dsQix5QkFBQSxFQUEyQjtRQUNoQyxPQUFPaGEsV0FBQSxDQUFZLEtBQUs1SyxXQUFBLENBQVksR0FBRyxHQUFHLENBQUM7TUFDL0M7TUFFQSxTQUFTNmtCLGVBQUEsRUFBaUI7UUFDdEIsSUFBSUMsUUFBQSxHQUFXLEtBQUt6ckIsVUFBQSxDQUFXLEVBQUUwUixLQUFBO1FBQ2pDLE9BQU9ILFdBQUEsQ0FBWSxLQUFLeEwsSUFBQSxDQUFLLEdBQUcwbEIsUUFBQSxDQUFTN2EsR0FBQSxFQUFLNmEsUUFBQSxDQUFTNWEsR0FBRztNQUM5RDtNQUVBLFNBQVM2YSxtQkFBQSxFQUFxQjtRQUMxQixJQUFJRCxRQUFBLEdBQVcsS0FBS3pyQixVQUFBLENBQVcsRUFBRTBSLEtBQUE7UUFDakMsT0FBT0gsV0FBQSxDQUFZLEtBQUs3SyxRQUFBLENBQVMsR0FBRytrQixRQUFBLENBQVM3YSxHQUFBLEVBQUs2YSxRQUFBLENBQVM1YSxHQUFHO01BQ2xFO01BRUEsU0FBU3VhLHFCQUFxQmwxQixLQUFBLEVBQU93UCxJQUFBLEVBQU01QixPQUFBLEVBQVM4TSxHQUFBLEVBQUtDLEdBQUEsRUFBSztRQUMxRCxJQUFJOGEsV0FBQTtRQUNKLElBQUl6MUIsS0FBQSxJQUFTLE1BQU07VUFDZixPQUFPbWIsVUFBQSxDQUFXLE1BQU1ULEdBQUEsRUFBS0MsR0FBRyxFQUFFOUssSUFBQTtRQUN0QyxPQUFPO1VBQ0g0bEIsV0FBQSxHQUFjcGEsV0FBQSxDQUFZcmIsS0FBQSxFQUFPMGEsR0FBQSxFQUFLQyxHQUFHO1VBQ3pDLElBQUluTCxJQUFBLEdBQU9pbUIsV0FBQSxFQUFhO1lBQ3BCam1CLElBQUEsR0FBT2ltQixXQUFBO1VBQ1g7VUFDQSxPQUFPQyxVQUFBLENBQVdyMUIsSUFBQSxDQUFLLE1BQU1MLEtBQUEsRUFBT3dQLElBQUEsRUFBTTVCLE9BQUEsRUFBUzhNLEdBQUEsRUFBS0MsR0FBRztRQUMvRDtNQUNKO01BRUEsU0FBUythLFdBQVdsbEIsUUFBQSxFQUFVaEIsSUFBQSxFQUFNNUIsT0FBQSxFQUFTOE0sR0FBQSxFQUFLQyxHQUFBLEVBQUs7UUFDbkQsSUFBSWdiLGFBQUEsR0FBZ0I3YSxrQkFBQSxDQUFtQnRLLFFBQUEsRUFBVWhCLElBQUEsRUFBTTVCLE9BQUEsRUFBUzhNLEdBQUEsRUFBS0MsR0FBRztVQUNwRXBOLElBQUEsR0FBT2dOLGFBQUEsQ0FBY29iLGFBQUEsQ0FBYzlsQixJQUFBLEVBQU0sR0FBRzhsQixhQUFBLENBQWNwbEIsU0FBUztRQUV2RSxLQUFLVixJQUFBLENBQUt0QyxJQUFBLENBQUs2SSxjQUFBLENBQWUsQ0FBQztRQUMvQixLQUFLekgsS0FBQSxDQUFNcEIsSUFBQSxDQUFLMkksV0FBQSxDQUFZLENBQUM7UUFDN0IsS0FBSzNJLElBQUEsQ0FBS0EsSUFBQSxDQUFLdUksVUFBQSxDQUFXLENBQUM7UUFDM0IsT0FBTztNQUNYO01BSUFyTSxjQUFBLENBQWUsS0FBSyxHQUFHLE1BQU0sU0FBUztNQUl0QzRJLGFBQUEsQ0FBYyxLQUFLcEIsTUFBTTtNQUN6QjBDLGFBQUEsQ0FBYyxLQUFLLFVBQVUzVCxLQUFBLEVBQU9vSyxLQUFBLEVBQU87UUFDdkNBLEtBQUEsQ0FBTWdLLEtBQUEsS0FBVWYsS0FBQSxDQUFNclQsS0FBSyxJQUFJLEtBQUs7TUFDeEMsQ0FBQztNQUlELFNBQVM0MUIsY0FBYzUxQixLQUFBLEVBQU87UUFDMUIsT0FBT0EsS0FBQSxJQUFTLE9BQ1Y4SSxJQUFBLENBQUtxSyxJQUFBLEVBQU0sS0FBS3hFLEtBQUEsQ0FBTSxJQUFJLEtBQUssQ0FBQyxJQUNoQyxLQUFLQSxLQUFBLEVBQU8zTyxLQUFBLEdBQVEsS0FBSyxJQUFLLEtBQUsyTyxLQUFBLENBQU0sSUFBSSxDQUFFO01BQ3pEO01BSUFsRixjQUFBLENBQWUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLE1BQU0sTUFBTTtNQUkzQzRJLGFBQUEsQ0FBYyxLQUFLZixTQUFBLEVBQVdZLHNCQUFzQjtNQUNwREcsYUFBQSxDQUFjLE1BQU1mLFNBQUEsRUFBV0osTUFBTTtNQUNyQ21CLGFBQUEsQ0FBYyxNQUFNLFVBQVVHLFFBQUEsRUFBVXpRLE9BQUEsRUFBUTtRQUU1QyxPQUFPeVEsUUFBQSxHQUNEelEsT0FBQSxDQUFPc0YsdUJBQUEsSUFBMkJ0RixPQUFBLENBQU93RixhQUFBLEdBQ3pDeEYsT0FBQSxDQUFPb0YsOEJBQUE7TUFDakIsQ0FBQztNQUVEd00sYUFBQSxDQUFjLENBQUMsS0FBSyxJQUFJLEdBQUdVLElBQUk7TUFDL0JWLGFBQUEsQ0FBYyxNQUFNLFVBQVUzVCxLQUFBLEVBQU9vSyxLQUFBLEVBQU87UUFDeENBLEtBQUEsQ0FBTWlLLElBQUEsSUFBUWhCLEtBQUEsQ0FBTXJULEtBQUEsQ0FBTWlLLEtBQUEsQ0FBTXFILFNBQVMsRUFBRSxFQUFFO01BQ2pELENBQUM7TUFJRCxJQUFJdWtCLGdCQUFBLEdBQW1CN2dCLFVBQUEsQ0FBVyxRQUFRLElBQUk7TUFJOUN2TCxjQUFBLENBQWUsT0FBTyxDQUFDLFFBQVEsQ0FBQyxHQUFHLFFBQVEsV0FBVztNQUl0RDRJLGFBQUEsQ0FBYyxPQUFPWixTQUFTO01BQzlCWSxhQUFBLENBQWMsUUFBUWxCLE1BQU07TUFDNUJ3QyxhQUFBLENBQWMsQ0FBQyxPQUFPLE1BQU0sR0FBRyxVQUFVM1QsS0FBQSxFQUFPb0ssS0FBQSxFQUFPMUUsTUFBQSxFQUFRO1FBQzNEQSxNQUFBLENBQU93Z0IsVUFBQSxHQUFhN1MsS0FBQSxDQUFNclQsS0FBSztNQUNuQyxDQUFDO01BTUQsU0FBUzgxQixnQkFBZ0I5MUIsS0FBQSxFQUFPO1FBQzVCLElBQUl1USxTQUFBLEdBQ0F6SCxJQUFBLENBQUsrZ0IsS0FBQSxFQUNBLEtBQUttQixLQUFBLENBQU0sRUFBRW1FLE9BQUEsQ0FBUSxLQUFLLElBQUksS0FBS25FLEtBQUEsQ0FBTSxFQUFFbUUsT0FBQSxDQUFRLE1BQU0sS0FBSyxLQUNuRSxJQUFJO1FBQ1IsT0FBT252QixLQUFBLElBQVMsT0FBT3VRLFNBQUEsR0FBWSxLQUFLc0wsR0FBQSxDQUFJN2IsS0FBQSxHQUFRdVEsU0FBQSxFQUFXLEdBQUc7TUFDdEU7TUFJQTlHLGNBQUEsQ0FBZSxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxRQUFRO01BSTFDNEksYUFBQSxDQUFjLEtBQUtmLFNBQUEsRUFBV2EsZ0JBQWdCO01BQzlDRSxhQUFBLENBQWMsTUFBTWYsU0FBQSxFQUFXSixNQUFNO01BQ3JDeUMsYUFBQSxDQUFjLENBQUMsS0FBSyxJQUFJLEdBQUdZLE1BQU07TUFJakMsSUFBSXdoQixZQUFBLEdBQWUvZ0IsVUFBQSxDQUFXLFdBQVcsS0FBSztNQUk5Q3ZMLGNBQUEsQ0FBZSxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxRQUFRO01BSTFDNEksYUFBQSxDQUFjLEtBQUtmLFNBQUEsRUFBV2EsZ0JBQWdCO01BQzlDRSxhQUFBLENBQWMsTUFBTWYsU0FBQSxFQUFXSixNQUFNO01BQ3JDeUMsYUFBQSxDQUFjLENBQUMsS0FBSyxJQUFJLEdBQUdhLE1BQU07TUFJakMsSUFBSXdoQixZQUFBLEdBQWVoaEIsVUFBQSxDQUFXLFdBQVcsS0FBSztNQUk5Q3ZMLGNBQUEsQ0FBZSxLQUFLLEdBQUcsR0FBRyxZQUFZO1FBQ2xDLE9BQU8sQ0FBQyxFQUFFLEtBQUs4RSxXQUFBLENBQVksSUFBSTtNQUNuQyxDQUFDO01BRUQ5RSxjQUFBLENBQWUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsWUFBWTtRQUN4QyxPQUFPLENBQUMsRUFBRSxLQUFLOEUsV0FBQSxDQUFZLElBQUk7TUFDbkMsQ0FBQztNQUVEOUUsY0FBQSxDQUFlLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxHQUFHLGFBQWE7TUFDOUNBLGNBQUEsQ0FBZSxHQUFHLENBQUMsUUFBUSxDQUFDLEdBQUcsR0FBRyxZQUFZO1FBQzFDLE9BQU8sS0FBSzhFLFdBQUEsQ0FBWSxJQUFJO01BQ2hDLENBQUM7TUFDRDlFLGNBQUEsQ0FBZSxHQUFHLENBQUMsU0FBUyxDQUFDLEdBQUcsR0FBRyxZQUFZO1FBQzNDLE9BQU8sS0FBSzhFLFdBQUEsQ0FBWSxJQUFJO01BQ2hDLENBQUM7TUFDRDlFLGNBQUEsQ0FBZSxHQUFHLENBQUMsVUFBVSxDQUFDLEdBQUcsR0FBRyxZQUFZO1FBQzVDLE9BQU8sS0FBSzhFLFdBQUEsQ0FBWSxJQUFJO01BQ2hDLENBQUM7TUFDRDlFLGNBQUEsQ0FBZSxHQUFHLENBQUMsV0FBVyxDQUFDLEdBQUcsR0FBRyxZQUFZO1FBQzdDLE9BQU8sS0FBSzhFLFdBQUEsQ0FBWSxJQUFJO01BQ2hDLENBQUM7TUFDRDlFLGNBQUEsQ0FBZSxHQUFHLENBQUMsWUFBWSxDQUFDLEdBQUcsR0FBRyxZQUFZO1FBQzlDLE9BQU8sS0FBSzhFLFdBQUEsQ0FBWSxJQUFJO01BQ2hDLENBQUM7TUFDRDlFLGNBQUEsQ0FBZSxHQUFHLENBQUMsYUFBYSxDQUFDLEdBQUcsR0FBRyxZQUFZO1FBQy9DLE9BQU8sS0FBSzhFLFdBQUEsQ0FBWSxJQUFJO01BQ2hDLENBQUM7TUFJRDhELGFBQUEsQ0FBYyxLQUFLWixTQUFBLEVBQVdSLE1BQU07TUFDcENvQixhQUFBLENBQWMsTUFBTVosU0FBQSxFQUFXUCxNQUFNO01BQ3JDbUIsYUFBQSxDQUFjLE9BQU9aLFNBQUEsRUFBV04sTUFBTTtNQUV0QyxJQUFJOGtCLEtBQUEsRUFBT0MsaUJBQUE7TUFDWCxLQUFLRCxLQUFBLEdBQVEsUUFBUUEsS0FBQSxDQUFNbjFCLE1BQUEsSUFBVSxHQUFHbTFCLEtBQUEsSUFBUyxLQUFLO1FBQ2xENWpCLGFBQUEsQ0FBYzRqQixLQUFBLEVBQU9ya0IsYUFBYTtNQUN0QztNQUVBLFNBQVN1a0IsUUFBUW4yQixLQUFBLEVBQU9vSyxLQUFBLEVBQU87UUFDM0JBLEtBQUEsQ0FBTXFLLFdBQUEsSUFBZXBCLEtBQUEsRUFBTyxPQUFPclQsS0FBQSxJQUFTLEdBQUk7TUFDcEQ7TUFFQSxLQUFLaTJCLEtBQUEsR0FBUSxLQUFLQSxLQUFBLENBQU1uMUIsTUFBQSxJQUFVLEdBQUdtMUIsS0FBQSxJQUFTLEtBQUs7UUFDL0N0aUIsYUFBQSxDQUFjc2lCLEtBQUEsRUFBT0UsT0FBTztNQUNoQztNQUVBRCxpQkFBQSxHQUFvQmxoQixVQUFBLENBQVcsZ0JBQWdCLEtBQUs7TUFJcER2TCxjQUFBLENBQWUsS0FBSyxHQUFHLEdBQUcsVUFBVTtNQUNwQ0EsY0FBQSxDQUFlLE1BQU0sR0FBRyxHQUFHLFVBQVU7TUFJckMsU0FBUzJzQixZQUFBLEVBQWM7UUFDbkIsT0FBTyxLQUFLOXdCLE1BQUEsR0FBUyxRQUFRO01BQ2pDO01BRUEsU0FBUyt3QixZQUFBLEVBQWM7UUFDbkIsT0FBTyxLQUFLL3dCLE1BQUEsR0FBUywrQkFBK0I7TUFDeEQ7TUFFQSxJQUFJZ3hCLEtBQUEsR0FBUTd3QixNQUFBLENBQU90RixTQUFBO01BRW5CbTJCLEtBQUEsQ0FBTXphLEdBQUEsR0FBTUEsR0FBQTtNQUNaeWEsS0FBQSxDQUFNbHVCLFFBQUEsR0FBVzJtQixVQUFBO01BQ2pCdUgsS0FBQSxDQUFNdEwsS0FBQSxHQUFRQSxLQUFBO01BQ2RzTCxLQUFBLENBQU14SCxJQUFBLEdBQU9BLElBQUE7TUFDYndILEtBQUEsQ0FBTS9HLEtBQUEsR0FBUUEsS0FBQTtNQUNkK0csS0FBQSxDQUFNakgsTUFBQSxHQUFTQSxNQUFBO01BQ2ZpSCxLQUFBLENBQU12SixJQUFBLEdBQU9BLElBQUE7TUFDYnVKLEtBQUEsQ0FBTWhGLE9BQUEsR0FBVUEsT0FBQTtNQUNoQmdGLEtBQUEsQ0FBTXRKLEVBQUEsR0FBS0EsRUFBQTtNQUNYc0osS0FBQSxDQUFNL0UsS0FBQSxHQUFRQSxLQUFBO01BQ2QrRSxLQUFBLENBQU1saEIsR0FBQSxHQUFNOEIsU0FBQTtNQUNab2YsS0FBQSxDQUFNN0QsU0FBQSxHQUFZQSxTQUFBO01BQ2xCNkQsS0FBQSxDQUFNakosT0FBQSxHQUFVQSxPQUFBO01BQ2hCaUosS0FBQSxDQUFNaEosUUFBQSxHQUFXQSxRQUFBO01BQ2pCZ0osS0FBQSxDQUFNOUcsU0FBQSxHQUFZQSxTQUFBO01BQ2xCOEcsS0FBQSxDQUFNMUcsTUFBQSxHQUFTQSxNQUFBO01BQ2YwRyxLQUFBLENBQU14RyxhQUFBLEdBQWdCQSxhQUFBO01BQ3RCd0csS0FBQSxDQUFNdkcsY0FBQSxHQUFpQkEsY0FBQTtNQUN2QnVHLEtBQUEsQ0FBTTN5QixPQUFBLEdBQVU0dUIsU0FBQTtNQUNoQitELEtBQUEsQ0FBTTdFLElBQUEsR0FBT0EsSUFBQTtNQUNiNkUsS0FBQSxDQUFNNUYsTUFBQSxHQUFTQSxNQUFBO01BQ2Y0RixLQUFBLENBQU14c0IsVUFBQSxHQUFhQSxVQUFBO01BQ25Cd3NCLEtBQUEsQ0FBTW50QixHQUFBLEdBQU1pZixZQUFBO01BQ1prTyxLQUFBLENBQU0vYyxHQUFBLEdBQU0yTyxZQUFBO01BQ1pvTyxLQUFBLENBQU05RCxZQUFBLEdBQWVBLFlBQUE7TUFDckI4RCxLQUFBLENBQU1ydkIsR0FBQSxHQUFNa1EsU0FBQTtNQUNabWYsS0FBQSxDQUFNbkgsT0FBQSxHQUFVQSxPQUFBO01BQ2hCbUgsS0FBQSxDQUFNeEssUUFBQSxHQUFXQSxRQUFBO01BQ2pCd0ssS0FBQSxDQUFNakssT0FBQSxHQUFVQSxPQUFBO01BQ2hCaUssS0FBQSxDQUFNakUsUUFBQSxHQUFXQSxRQUFBO01BQ2pCaUUsS0FBQSxDQUFNekYsTUFBQSxHQUFTQSxNQUFBO01BQ2Z5RixLQUFBLENBQU0zRixXQUFBLEdBQWNBLFdBQUE7TUFDcEIyRixLQUFBLENBQU14RixPQUFBLEdBQVVBLE9BQUE7TUFDaEIsSUFBSSxPQUFPeUYsTUFBQSxLQUFXLGVBQWVBLE1BQUEsQ0FBT0MsR0FBQSxJQUFPLE1BQU07UUFDckRGLEtBQUEsQ0FBTUMsTUFBQSxDQUFPQyxHQUFBLENBQUksNEJBQTRCLEtBQUssWUFBWTtVQUMxRCxPQUFPLFlBQVksS0FBS25ILE1BQUEsQ0FBTyxJQUFJO1FBQ3ZDO01BQ0o7TUFDQWlILEtBQUEsQ0FBTWhFLE1BQUEsR0FBU0EsTUFBQTtNQUNmZ0UsS0FBQSxDQUFNbDJCLFFBQUEsR0FBV0EsUUFBQTtNQUNqQmsyQixLQUFBLENBQU1sRSxJQUFBLEdBQU9BLElBQUE7TUFDYmtFLEtBQUEsQ0FBTTEwQixPQUFBLEdBQVVBLE9BQUE7TUFDaEIwMEIsS0FBQSxDQUFNNUQsWUFBQSxHQUFlQSxZQUFBO01BQ3JCNEQsS0FBQSxDQUFNN0MsT0FBQSxHQUFVSSxVQUFBO01BQ2hCeUMsS0FBQSxDQUFNRyxTQUFBLEdBQVkzQyxZQUFBO01BQ2xCd0MsS0FBQSxDQUFNSSxPQUFBLEdBQVUzQyxVQUFBO01BQ2hCdUMsS0FBQSxDQUFNSyxPQUFBLEdBQVUzQyxVQUFBO01BQ2hCc0MsS0FBQSxDQUFNem1CLElBQUEsR0FBT2tGLFVBQUE7TUFDYnVoQixLQUFBLENBQU1waUIsVUFBQSxHQUFhZSxhQUFBO01BQ25CcWhCLEtBQUEsQ0FBTTlsQixRQUFBLEdBQVd5a0IsY0FBQTtNQUNqQnFCLEtBQUEsQ0FBTTdsQixXQUFBLEdBQWMwa0IsaUJBQUE7TUFDcEJtQixLQUFBLENBQU14bkIsT0FBQSxHQUFVd25CLEtBQUEsQ0FBTXpuQixRQUFBLEdBQVcrbUIsYUFBQTtNQUNqQ1UsS0FBQSxDQUFNM25CLEtBQUEsR0FBUThLLFdBQUE7TUFDZDZjLEtBQUEsQ0FBTTNlLFdBQUEsR0FBYytCLGNBQUE7TUFDcEI0YyxLQUFBLENBQU05bUIsSUFBQSxHQUFPOG1CLEtBQUEsQ0FBTS9tQixLQUFBLEdBQVFxTSxVQUFBO01BQzNCMGEsS0FBQSxDQUFNNWxCLE9BQUEsR0FBVTRsQixLQUFBLENBQU1NLFFBQUEsR0FBVzlhLGFBQUE7TUFDakN3YSxLQUFBLENBQU1qYixXQUFBLEdBQWNpYSxjQUFBO01BQ3BCZ0IsS0FBQSxDQUFNTyxlQUFBLEdBQWtCckIsa0JBQUE7TUFDeEJjLEtBQUEsQ0FBTVEsY0FBQSxHQUFpQjFCLGlCQUFBO01BQ3ZCa0IsS0FBQSxDQUFNUyxxQkFBQSxHQUF3QjFCLHdCQUFBO01BQzlCaUIsS0FBQSxDQUFNL29CLElBQUEsR0FBT3NvQixnQkFBQTtNQUNiUyxLQUFBLENBQU03b0IsR0FBQSxHQUFNNm9CLEtBQUEsQ0FBTTlvQixJQUFBLEdBQU9zUSxlQUFBO01BQ3pCd1ksS0FBQSxDQUFNMW9CLE9BQUEsR0FBVW1RLHFCQUFBO01BQ2hCdVksS0FBQSxDQUFNaG1CLFVBQUEsR0FBYTBOLGtCQUFBO01BQ25Cc1ksS0FBQSxDQUFNL2xCLFNBQUEsR0FBWXVsQixlQUFBO01BQ2xCUSxLQUFBLENBQU1sb0IsSUFBQSxHQUFPa29CLEtBQUEsQ0FBTW5vQixLQUFBLEdBQVF3UixVQUFBO01BQzNCMlcsS0FBQSxDQUFNN25CLE1BQUEsR0FBUzZuQixLQUFBLENBQU05bkIsT0FBQSxHQUFVdW5CLFlBQUE7TUFDL0JPLEtBQUEsQ0FBTXRuQixNQUFBLEdBQVNzbkIsS0FBQSxDQUFNdm5CLE9BQUEsR0FBVWluQixZQUFBO01BQy9CTSxLQUFBLENBQU0vbkIsV0FBQSxHQUFjK25CLEtBQUEsQ0FBTWhvQixZQUFBLEdBQWU0bkIsaUJBQUE7TUFDekNJLEtBQUEsQ0FBTS9MLFNBQUEsR0FBWWMsWUFBQTtNQUNsQmlMLEtBQUEsQ0FBTXAwQixHQUFBLEdBQU0wcEIsY0FBQTtNQUNaMEssS0FBQSxDQUFNcEwsS0FBQSxHQUFRVyxnQkFBQTtNQUNkeUssS0FBQSxDQUFNVSxTQUFBLEdBQVlqTCx1QkFBQTtNQUNsQnVLLEtBQUEsQ0FBTXJLLG9CQUFBLEdBQXVCQSxvQkFBQTtNQUM3QnFLLEtBQUEsQ0FBTVcsS0FBQSxHQUFRL0ssb0JBQUE7TUFDZG9LLEtBQUEsQ0FBTWhLLE9BQUEsR0FBVUEsT0FBQTtNQUNoQmdLLEtBQUEsQ0FBTS9KLFdBQUEsR0FBY0EsV0FBQTtNQUNwQitKLEtBQUEsQ0FBTTlKLEtBQUEsR0FBUUEsS0FBQTtNQUNkOEosS0FBQSxDQUFNamhCLEtBQUEsR0FBUW1YLEtBQUE7TUFDZDhKLEtBQUEsQ0FBTVksUUFBQSxHQUFXZCxXQUFBO01BQ2pCRSxLQUFBLENBQU1hLFFBQUEsR0FBV2QsV0FBQTtNQUNqQkMsS0FBQSxDQUFNaHBCLEtBQUEsR0FBUXJILFNBQUEsQ0FDVixtREFDQTR2QixnQkFDSjtNQUNBUyxLQUFBLENBQU01bkIsTUFBQSxHQUFTekksU0FBQSxDQUNYLG9EQUNBd1QsV0FDSjtNQUNBNmMsS0FBQSxDQUFNMW1CLEtBQUEsR0FBUTNKLFNBQUEsQ0FDVixrREFDQThPLFVBQ0o7TUFDQXVoQixLQUFBLENBQU12RixJQUFBLEdBQU85cUIsU0FBQSxDQUNULDRHQUNBMGxCLFVBQ0o7TUFDQTJLLEtBQUEsQ0FBTWMsWUFBQSxHQUFlbnhCLFNBQUEsQ0FDakIsMkdBQ0FrbUIsMkJBQ0o7TUFFQSxTQUFTa0wsV0FBV3IzQixLQUFBLEVBQU87UUFDdkIsT0FBT3VtQixXQUFBLENBQVl2bUIsS0FBQSxHQUFRLEdBQUk7TUFDbkM7TUFFQSxTQUFTczNCLGFBQUEsRUFBZTtRQUNwQixPQUFPL1EsV0FBQSxDQUFZNW1CLEtBQUEsQ0FBTSxNQUFNQyxTQUFTLEVBQUVvM0IsU0FBQSxDQUFVO01BQ3hEO01BRUEsU0FBU08sbUJBQW1CeHFCLE1BQUEsRUFBUTtRQUNoQyxPQUFPQSxNQUFBO01BQ1g7TUFFQSxJQUFJeXFCLE9BQUEsR0FBVTd2QixNQUFBLENBQU94SCxTQUFBO01BRXJCcTNCLE9BQUEsQ0FBUXB2QixRQUFBLEdBQVdBLFFBQUE7TUFDbkJvdkIsT0FBQSxDQUFROXNCLGNBQUEsR0FBaUJBLGNBQUE7TUFDekI4c0IsT0FBQSxDQUFRanRCLFdBQUEsR0FBY0EsV0FBQTtNQUN0Qml0QixPQUFBLENBQVF6dEIsT0FBQSxHQUFVQSxPQUFBO01BQ2xCeXRCLE9BQUEsQ0FBUXhQLFFBQUEsR0FBV3VQLGtCQUFBO01BQ25CQyxPQUFBLENBQVFwRyxVQUFBLEdBQWFtRyxrQkFBQTtNQUNyQkMsT0FBQSxDQUFRM3FCLFlBQUEsR0FBZUEsWUFBQTtNQUN2QjJxQixPQUFBLENBQVF0cUIsVUFBQSxHQUFhQSxVQUFBO01BQ3JCc3FCLE9BQUEsQ0FBUXZ3QixHQUFBLEdBQU1BLEdBQUE7TUFDZHV3QixPQUFBLENBQVFyRSxJQUFBLEdBQU9ELFVBQUE7TUFDZnNFLE9BQUEsQ0FBUTFFLFNBQUEsR0FBWVUsZUFBQTtNQUNwQmdFLE9BQUEsQ0FBUXpRLGVBQUEsR0FBa0I0TSxxQkFBQTtNQUMxQjZELE9BQUEsQ0FBUW5ELGFBQUEsR0FBZ0JBLGFBQUE7TUFDeEJtRCxPQUFBLENBQVF2RCxhQUFBLEdBQWdCQSxhQUFBO01BQ3hCdUQsT0FBQSxDQUFRakQsZUFBQSxHQUFrQkEsZUFBQTtNQUUxQmlELE9BQUEsQ0FBUTlvQixNQUFBLEdBQVM2SixZQUFBO01BQ2pCaWYsT0FBQSxDQUFRM2YsV0FBQSxHQUFjYSxpQkFBQTtNQUN0QjhlLE9BQUEsQ0FBUXhmLFdBQUEsR0FBY29CLGlCQUFBO01BQ3RCb2UsT0FBQSxDQUFRemYsV0FBQSxHQUFjQSxXQUFBO01BQ3RCeWYsT0FBQSxDQUFRMWYsZ0JBQUEsR0FBbUJBLGdCQUFBO01BQzNCMGYsT0FBQSxDQUFRaG9CLElBQUEsR0FBTytMLFVBQUE7TUFDZmljLE9BQUEsQ0FBUUMsY0FBQSxHQUFpQjliLG9CQUFBO01BQ3pCNmIsT0FBQSxDQUFRRSxjQUFBLEdBQWlCaGMsb0JBQUE7TUFFekI4YixPQUFBLENBQVE3cEIsUUFBQSxHQUFXcVAsY0FBQTtNQUNuQndhLE9BQUEsQ0FBUXpiLFdBQUEsR0FBY3FCLGlCQUFBO01BQ3RCb2EsT0FBQSxDQUFReGIsYUFBQSxHQUFnQmtCLG1CQUFBO01BQ3hCc2EsT0FBQSxDQUFRcGIsYUFBQSxHQUFnQnVCLG1CQUFBO01BRXhCNlosT0FBQSxDQUFRcmIsYUFBQSxHQUFnQkEsYUFBQTtNQUN4QnFiLE9BQUEsQ0FBUXRiLGtCQUFBLEdBQXFCQSxrQkFBQTtNQUM3QnNiLE9BQUEsQ0FBUXZiLGdCQUFBLEdBQW1CQSxnQkFBQTtNQUUzQnViLE9BQUEsQ0FBUXJZLElBQUEsR0FBT0ssVUFBQTtNQUNmZ1ksT0FBQSxDQUFRdjBCLFFBQUEsR0FBVzJjLGNBQUE7TUFFbkIsU0FBUytYLE1BQU03MUIsT0FBQSxFQUFRODFCLEtBQUEsRUFBT0MsS0FBQSxFQUFPQyxNQUFBLEVBQVE7UUFDekMsSUFBSS8xQixPQUFBLEdBQVN5ZixTQUFBLENBQVU7VUFDbkJ0ZixHQUFBLEdBQU1MLFNBQUEsQ0FBVSxFQUFFb0YsR0FBQSxDQUFJNndCLE1BQUEsRUFBUUYsS0FBSztRQUN2QyxPQUFPNzFCLE9BQUEsQ0FBTzgxQixLQUFBLEVBQU8zMUIsR0FBQSxFQUFLSixPQUFNO01BQ3BDO01BRUEsU0FBU2kyQixlQUFlajJCLE9BQUEsRUFBUTgxQixLQUFBLEVBQU9DLEtBQUEsRUFBTztRQUMxQyxJQUFJNTJCLFFBQUEsQ0FBU2EsT0FBTSxHQUFHO1VBQ2xCODFCLEtBQUEsR0FBUTkxQixPQUFBO1VBQ1JBLE9BQUEsR0FBUztRQUNiO1FBRUFBLE9BQUEsR0FBU0EsT0FBQSxJQUFVO1FBRW5CLElBQUk4MUIsS0FBQSxJQUFTLE1BQU07VUFDZixPQUFPRCxLQUFBLENBQU03MUIsT0FBQSxFQUFRODFCLEtBQUEsRUFBT0MsS0FBQSxFQUFPLE9BQU87UUFDOUM7UUFFQSxJQUFJcjJCLENBQUE7VUFDQXcyQixHQUFBLEdBQU0sRUFBQztRQUNYLEtBQUt4MkIsQ0FBQSxHQUFJLEdBQUdBLENBQUEsR0FBSSxJQUFJQSxDQUFBLElBQUs7VUFDckJ3MkIsR0FBQSxDQUFJeDJCLENBQUEsSUFBS20yQixLQUFBLENBQU03MUIsT0FBQSxFQUFRTixDQUFBLEVBQUdxMkIsS0FBQSxFQUFPLE9BQU87UUFDNUM7UUFDQSxPQUFPRyxHQUFBO01BQ1g7TUFVQSxTQUFTQyxpQkFBaUJDLFlBQUEsRUFBY3AyQixPQUFBLEVBQVE4MUIsS0FBQSxFQUFPQyxLQUFBLEVBQU87UUFDMUQsSUFBSSxPQUFPSyxZQUFBLEtBQWlCLFdBQVc7VUFDbkMsSUFBSWozQixRQUFBLENBQVNhLE9BQU0sR0FBRztZQUNsQjgxQixLQUFBLEdBQVE5MUIsT0FBQTtZQUNSQSxPQUFBLEdBQVM7VUFDYjtVQUVBQSxPQUFBLEdBQVNBLE9BQUEsSUFBVTtRQUN2QixPQUFPO1VBQ0hBLE9BQUEsR0FBU28yQixZQUFBO1VBQ1ROLEtBQUEsR0FBUTkxQixPQUFBO1VBQ1JvMkIsWUFBQSxHQUFlO1VBRWYsSUFBSWozQixRQUFBLENBQVNhLE9BQU0sR0FBRztZQUNsQjgxQixLQUFBLEdBQVE5MUIsT0FBQTtZQUNSQSxPQUFBLEdBQVM7VUFDYjtVQUVBQSxPQUFBLEdBQVNBLE9BQUEsSUFBVTtRQUN2QjtRQUVBLElBQUlDLE9BQUEsR0FBU3lmLFNBQUEsQ0FBVTtVQUNuQjJXLEtBQUEsR0FBUUQsWUFBQSxHQUFlbjJCLE9BQUEsQ0FBT3laLEtBQUEsQ0FBTWQsR0FBQSxHQUFNO1VBQzFDbFosQ0FBQTtVQUNBdzJCLEdBQUEsR0FBTSxFQUFDO1FBRVgsSUFBSUosS0FBQSxJQUFTLE1BQU07VUFDZixPQUFPRCxLQUFBLENBQU03MUIsT0FBQSxHQUFTODFCLEtBQUEsR0FBUU8sS0FBQSxJQUFTLEdBQUdOLEtBQUEsRUFBTyxLQUFLO1FBQzFEO1FBRUEsS0FBS3IyQixDQUFBLEdBQUksR0FBR0EsQ0FBQSxHQUFJLEdBQUdBLENBQUEsSUFBSztVQUNwQncyQixHQUFBLENBQUl4MkIsQ0FBQSxJQUFLbTJCLEtBQUEsQ0FBTTcxQixPQUFBLEdBQVNOLENBQUEsR0FBSTIyQixLQUFBLElBQVMsR0FBR04sS0FBQSxFQUFPLEtBQUs7UUFDeEQ7UUFDQSxPQUFPRyxHQUFBO01BQ1g7TUFFQSxTQUFTSSxXQUFXdDJCLE9BQUEsRUFBUTgxQixLQUFBLEVBQU87UUFDL0IsT0FBT0csY0FBQSxDQUFlajJCLE9BQUEsRUFBUTgxQixLQUFBLEVBQU8sUUFBUTtNQUNqRDtNQUVBLFNBQVNTLGdCQUFnQnYyQixPQUFBLEVBQVE4MUIsS0FBQSxFQUFPO1FBQ3BDLE9BQU9HLGNBQUEsQ0FBZWoyQixPQUFBLEVBQVE4MUIsS0FBQSxFQUFPLGFBQWE7TUFDdEQ7TUFFQSxTQUFTVSxhQUFhSixZQUFBLEVBQWNwMkIsT0FBQSxFQUFRODFCLEtBQUEsRUFBTztRQUMvQyxPQUFPSyxnQkFBQSxDQUFpQkMsWUFBQSxFQUFjcDJCLE9BQUEsRUFBUTgxQixLQUFBLEVBQU8sVUFBVTtNQUNuRTtNQUVBLFNBQVNXLGtCQUFrQkwsWUFBQSxFQUFjcDJCLE9BQUEsRUFBUTgxQixLQUFBLEVBQU87UUFDcEQsT0FBT0ssZ0JBQUEsQ0FBaUJDLFlBQUEsRUFBY3AyQixPQUFBLEVBQVE4MUIsS0FBQSxFQUFPLGVBQWU7TUFDeEU7TUFFQSxTQUFTWSxnQkFBZ0JOLFlBQUEsRUFBY3AyQixPQUFBLEVBQVE4MUIsS0FBQSxFQUFPO1FBQ2xELE9BQU9LLGdCQUFBLENBQWlCQyxZQUFBLEVBQWNwMkIsT0FBQSxFQUFRODFCLEtBQUEsRUFBTyxhQUFhO01BQ3RFO01BRUF2VyxrQkFBQSxDQUFtQixNQUFNO1FBQ3JCOFIsSUFBQSxFQUFNLENBQ0Y7VUFDSUUsS0FBQSxFQUFPO1VBQ1BDLEtBQUEsRUFBT0MsUUFBQTtVQUNQbkosTUFBQSxFQUFRO1VBQ1J0akIsSUFBQSxFQUFNO1VBQ040c0IsTUFBQSxFQUFRO1VBQ1JoUyxJQUFBLEVBQU07UUFDVixHQUNBO1VBQ0kyUixLQUFBLEVBQU87VUFDUEMsS0FBQSxFQUFPLENBQUFDLFFBQUE7VUFDUG5KLE1BQUEsRUFBUTtVQUNSdGpCLElBQUEsRUFBTTtVQUNONHNCLE1BQUEsRUFBUTtVQUNSaFMsSUFBQSxFQUFNO1FBQ1YsRUFDSjtRQUNBekIsc0JBQUEsRUFBd0I7UUFDeEJsVyxPQUFBLEVBQVMsU0FBQUEsQ0FBVXJCLE1BQUEsRUFBUTtVQUN2QixJQUFJakksQ0FBQSxHQUFJaUksTUFBQSxHQUFTO1lBQ2JILE1BQUEsR0FDSThLLEtBQUEsQ0FBTzNLLE1BQUEsR0FBUyxNQUFPLEVBQUUsTUFBTSxJQUN6QixPQUNBakksQ0FBQSxLQUFNLElBQ0osT0FDQUEsQ0FBQSxLQUFNLElBQ0osT0FDQUEsQ0FBQSxLQUFNLElBQ0osT0FDQTtVQUNwQixPQUFPaUksTUFBQSxHQUFTSCxNQUFBO1FBQ3BCO01BQ0osQ0FBQztNQUlEN0ksS0FBQSxDQUFNK3hCLElBQUEsR0FBT3hyQixTQUFBLENBQ1QseURBQ0FvYixrQkFDSjtNQUNBM2hCLEtBQUEsQ0FBTSs0QixRQUFBLEdBQVd4eUIsU0FBQSxDQUNiLGlFQUNBdWIsU0FDSjtNQUVBLElBQUlrWCxPQUFBLEdBQVU1dkIsSUFBQSxDQUFLQyxHQUFBO01BRW5CLFNBQVNBLElBQUEsRUFBTTtRQUNYLElBQUl3WSxJQUFBLEdBQU8sS0FBS2tJLEtBQUE7UUFFaEIsS0FBS0YsYUFBQSxHQUFnQm1QLE9BQUEsQ0FBUSxLQUFLblAsYUFBYTtRQUMvQyxLQUFLQyxLQUFBLEdBQVFrUCxPQUFBLENBQVEsS0FBS2xQLEtBQUs7UUFDL0IsS0FBS2hSLE9BQUEsR0FBVWtnQixPQUFBLENBQVEsS0FBS2xnQixPQUFPO1FBRW5DK0ksSUFBQSxDQUFLalQsWUFBQSxHQUFlb3FCLE9BQUEsQ0FBUW5YLElBQUEsQ0FBS2pULFlBQVk7UUFDN0NpVCxJQUFBLENBQUt4UyxPQUFBLEdBQVUycEIsT0FBQSxDQUFRblgsSUFBQSxDQUFLeFMsT0FBTztRQUNuQ3dTLElBQUEsQ0FBSy9TLE9BQUEsR0FBVWtxQixPQUFBLENBQVFuWCxJQUFBLENBQUsvUyxPQUFPO1FBQ25DK1MsSUFBQSxDQUFLcFQsS0FBQSxHQUFRdXFCLE9BQUEsQ0FBUW5YLElBQUEsQ0FBS3BULEtBQUs7UUFDL0JvVCxJQUFBLENBQUs3UyxNQUFBLEdBQVNncUIsT0FBQSxDQUFRblgsSUFBQSxDQUFLN1MsTUFBTTtRQUNqQzZTLElBQUEsQ0FBSzNSLEtBQUEsR0FBUThvQixPQUFBLENBQVFuWCxJQUFBLENBQUszUixLQUFLO1FBRS9CLE9BQU87TUFDWDtNQUVBLFNBQVMrb0IsY0FBYzNQLFFBQUEsRUFBVWhwQixLQUFBLEVBQU93VCxLQUFBLEVBQU9nYSxTQUFBLEVBQVc7UUFDdEQsSUFBSXJGLEtBQUEsR0FBUVcsY0FBQSxDQUFlOW9CLEtBQUEsRUFBT3dULEtBQUs7UUFFdkN3VixRQUFBLENBQVNPLGFBQUEsSUFBaUJpRSxTQUFBLEdBQVlyRixLQUFBLENBQU1vQixhQUFBO1FBQzVDUCxRQUFBLENBQVNRLEtBQUEsSUFBU2dFLFNBQUEsR0FBWXJGLEtBQUEsQ0FBTXFCLEtBQUE7UUFDcENSLFFBQUEsQ0FBU3hRLE9BQUEsSUFBV2dWLFNBQUEsR0FBWXJGLEtBQUEsQ0FBTTNQLE9BQUE7UUFFdEMsT0FBT3dRLFFBQUEsQ0FBU1UsT0FBQSxDQUFRO01BQzVCO01BR0EsU0FBU2tQLE1BQU01NEIsS0FBQSxFQUFPd1QsS0FBQSxFQUFPO1FBQ3pCLE9BQU9tbEIsYUFBQSxDQUFjLE1BQU0zNEIsS0FBQSxFQUFPd1QsS0FBQSxFQUFPLENBQUM7TUFDOUM7TUFHQSxTQUFTcWxCLFdBQVc3NEIsS0FBQSxFQUFPd1QsS0FBQSxFQUFPO1FBQzlCLE9BQU9tbEIsYUFBQSxDQUFjLE1BQU0zNEIsS0FBQSxFQUFPd1QsS0FBQSxFQUFPLEVBQUU7TUFDL0M7TUFFQSxTQUFTc2xCLFFBQVFwd0IsTUFBQSxFQUFRO1FBQ3JCLElBQUlBLE1BQUEsR0FBUyxHQUFHO1VBQ1osT0FBT0ksSUFBQSxDQUFLc0ssS0FBQSxDQUFNMUssTUFBTTtRQUM1QixPQUFPO1VBQ0gsT0FBT0ksSUFBQSxDQUFLcUssSUFBQSxDQUFLekssTUFBTTtRQUMzQjtNQUNKO01BRUEsU0FBU3F3QixPQUFBLEVBQVM7UUFDZCxJQUFJelAsYUFBQSxHQUFlLEtBQUtDLGFBQUE7VUFDcEJILEtBQUEsR0FBTyxLQUFLSSxLQUFBO1VBQ1pOLE9BQUEsR0FBUyxLQUFLMVEsT0FBQTtVQUNkK0ksSUFBQSxHQUFPLEtBQUtrSSxLQUFBO1VBQ1pKLFFBQUE7VUFDQXZKLFFBQUE7VUFDQUQsTUFBQTtVQUNBb0osTUFBQTtVQUNBK1AsY0FBQTtRQUlKLElBQ0ksRUFDSzFQLGFBQUEsSUFBZ0IsS0FBS0YsS0FBQSxJQUFRLEtBQUtGLE9BQUEsSUFBVSxLQUM1Q0ksYUFBQSxJQUFnQixLQUFLRixLQUFBLElBQVEsS0FBS0YsT0FBQSxJQUFVLElBRW5EO1VBQ0VJLGFBQUEsSUFBZ0J3UCxPQUFBLENBQVFHLFlBQUEsQ0FBYS9QLE9BQU0sSUFBSUUsS0FBSSxJQUFJO1VBQ3ZEQSxLQUFBLEdBQU87VUFDUEYsT0FBQSxHQUFTO1FBQ2I7UUFJQTNILElBQUEsQ0FBS2pULFlBQUEsR0FBZWdiLGFBQUEsR0FBZTtRQUVuQ0QsUUFBQSxHQUFVblcsUUFBQSxDQUFTb1csYUFBQSxHQUFlLEdBQUk7UUFDdEMvSCxJQUFBLENBQUt4UyxPQUFBLEdBQVVzYSxRQUFBLEdBQVU7UUFFekJ2SixRQUFBLEdBQVU1TSxRQUFBLENBQVNtVyxRQUFBLEdBQVUsRUFBRTtRQUMvQjlILElBQUEsQ0FBSy9TLE9BQUEsR0FBVXNSLFFBQUEsR0FBVTtRQUV6QkQsTUFBQSxHQUFRM00sUUFBQSxDQUFTNE0sUUFBQSxHQUFVLEVBQUU7UUFDN0J5QixJQUFBLENBQUtwVCxLQUFBLEdBQVEwUixNQUFBLEdBQVE7UUFFckJ1SixLQUFBLElBQVFsVyxRQUFBLENBQVMyTSxNQUFBLEdBQVEsRUFBRTtRQUczQm1aLGNBQUEsR0FBaUI5bEIsUUFBQSxDQUFTZ21CLFlBQUEsQ0FBYTlQLEtBQUksQ0FBQztRQUM1Q0YsT0FBQSxJQUFVOFAsY0FBQTtRQUNWNVAsS0FBQSxJQUFRMFAsT0FBQSxDQUFRRyxZQUFBLENBQWFELGNBQWMsQ0FBQztRQUc1Qy9QLE1BQUEsR0FBUS9WLFFBQUEsQ0FBU2dXLE9BQUEsR0FBUyxFQUFFO1FBQzVCQSxPQUFBLElBQVU7UUFFVjNILElBQUEsQ0FBSy9ULElBQUEsR0FBTzRiLEtBQUE7UUFDWjdILElBQUEsQ0FBSzdTLE1BQUEsR0FBU3dhLE9BQUE7UUFDZDNILElBQUEsQ0FBSzNSLEtBQUEsR0FBUXFaLE1BQUE7UUFFYixPQUFPO01BQ1g7TUFFQSxTQUFTaVEsYUFBYTlQLEtBQUEsRUFBTTtRQUd4QixPQUFRQSxLQUFBLEdBQU8sT0FBUTtNQUMzQjtNQUVBLFNBQVM2UCxhQUFhL1AsT0FBQSxFQUFRO1FBRTFCLE9BQVFBLE9BQUEsR0FBUyxTQUFVO01BQy9CO01BRUEsU0FBU2lRLEdBQUdwcEIsS0FBQSxFQUFPO1FBQ2YsSUFBSSxDQUFDLEtBQUtwTSxPQUFBLENBQVEsR0FBRztVQUNqQixPQUFPYSxHQUFBO1FBQ1g7UUFDQSxJQUFJNGtCLEtBQUE7VUFDQUYsT0FBQTtVQUNBSSxhQUFBLEdBQWUsS0FBS0MsYUFBQTtRQUV4QnhaLEtBQUEsR0FBUUQsY0FBQSxDQUFlQyxLQUFLO1FBRTVCLElBQUlBLEtBQUEsS0FBVSxXQUFXQSxLQUFBLEtBQVUsYUFBYUEsS0FBQSxLQUFVLFFBQVE7VUFDOURxWixLQUFBLEdBQU8sS0FBS0ksS0FBQSxHQUFRRixhQUFBLEdBQWU7VUFDbkNKLE9BQUEsR0FBUyxLQUFLMVEsT0FBQSxHQUFVMGdCLFlBQUEsQ0FBYTlQLEtBQUk7VUFDekMsUUFBUXJaLEtBQUE7WUFBQSxLQUNDO2NBQ0QsT0FBT21aLE9BQUE7WUFBQSxLQUNOO2NBQ0QsT0FBT0EsT0FBQSxHQUFTO1lBQUEsS0FDZjtjQUNELE9BQU9BLE9BQUEsR0FBUztVQUFBO1FBRTVCLE9BQU87VUFFSEUsS0FBQSxHQUFPLEtBQUtJLEtBQUEsR0FBUTFnQixJQUFBLENBQUsrZ0IsS0FBQSxDQUFNb1AsWUFBQSxDQUFhLEtBQUt6Z0IsT0FBTyxDQUFDO1VBQ3pELFFBQVF6SSxLQUFBO1lBQUEsS0FDQztjQUNELE9BQU9xWixLQUFBLEdBQU8sSUFBSUUsYUFBQSxHQUFlO1lBQUEsS0FDaEM7Y0FDRCxPQUFPRixLQUFBLEdBQU9FLGFBQUEsR0FBZTtZQUFBLEtBQzVCO2NBQ0QsT0FBT0YsS0FBQSxHQUFPLEtBQUtFLGFBQUEsR0FBZTtZQUFBLEtBQ2pDO2NBQ0QsT0FBT0YsS0FBQSxHQUFPLE9BQU9FLGFBQUEsR0FBZTtZQUFBLEtBQ25DO2NBQ0QsT0FBT0YsS0FBQSxHQUFPLFFBQVFFLGFBQUEsR0FBZTtZQUFBLEtBRXBDO2NBQ0QsT0FBT3hnQixJQUFBLENBQUtzSyxLQUFBLENBQU1nVyxLQUFBLEdBQU8sS0FBSyxJQUFJRSxhQUFBO1lBQUE7Y0FFbEMsTUFBTSxJQUFJNWlCLEtBQUEsQ0FBTSxrQkFBa0JxSixLQUFLO1VBQUE7UUFFbkQ7TUFDSjtNQUVBLFNBQVNxcEIsT0FBT0MsS0FBQSxFQUFPO1FBQ25CLE9BQU8sWUFBWTtVQUNmLE9BQU8sS0FBS0YsRUFBQSxDQUFHRSxLQUFLO1FBQ3hCO01BQ0o7TUFFQSxJQUFJQyxjQUFBLEdBQWlCRixNQUFBLENBQU8sSUFBSTtRQUM1QkcsU0FBQSxHQUFZSCxNQUFBLENBQU8sR0FBRztRQUN0QkksU0FBQSxHQUFZSixNQUFBLENBQU8sR0FBRztRQUN0QkssT0FBQSxHQUFVTCxNQUFBLENBQU8sR0FBRztRQUNwQk0sTUFBQSxHQUFTTixNQUFBLENBQU8sR0FBRztRQUNuQk8sT0FBQSxHQUFVUCxNQUFBLENBQU8sR0FBRztRQUNwQlEsUUFBQSxHQUFXUixNQUFBLENBQU8sR0FBRztRQUNyQlMsVUFBQSxHQUFhVCxNQUFBLENBQU8sR0FBRztRQUN2QlUsT0FBQSxHQUFVVixNQUFBLENBQU8sR0FBRztRQUNwQlcsU0FBQSxHQUFZVCxjQUFBO01BRWhCLFNBQVNVLFFBQUEsRUFBVTtRQUNmLE9BQU9sUixjQUFBLENBQWUsSUFBSTtNQUM5QjtNQUVBLFNBQVNtUixNQUFNbHFCLEtBQUEsRUFBTztRQUNsQkEsS0FBQSxHQUFRRCxjQUFBLENBQWVDLEtBQUs7UUFDNUIsT0FBTyxLQUFLcE0sT0FBQSxDQUFRLElBQUksS0FBS29NLEtBQUEsR0FBUSxLQUFLLElBQUl2TCxHQUFBO01BQ2xEO01BRUEsU0FBUzAxQixXQUFXcHpCLElBQUEsRUFBTTtRQUN0QixPQUFPLFlBQVk7VUFDZixPQUFPLEtBQUtuRCxPQUFBLENBQVEsSUFBSSxLQUFLOGxCLEtBQUEsQ0FBTTNpQixJQUFBLElBQVF0QyxHQUFBO1FBQy9DO01BQ0o7TUFFQSxJQUFJOEosWUFBQSxHQUFlNHJCLFVBQUEsQ0FBVyxjQUFjO1FBQ3hDbnJCLE9BQUEsR0FBVW1yQixVQUFBLENBQVcsU0FBUztRQUM5QjFyQixPQUFBLEdBQVUwckIsVUFBQSxDQUFXLFNBQVM7UUFDOUIvckIsS0FBQSxHQUFRK3JCLFVBQUEsQ0FBVyxPQUFPO1FBQzFCMXNCLElBQUEsR0FBTzBzQixVQUFBLENBQVcsTUFBTTtRQUN4QnhyQixNQUFBLEdBQVN3ckIsVUFBQSxDQUFXLFFBQVE7UUFDNUJ0cUIsS0FBQSxHQUFRc3FCLFVBQUEsQ0FBVyxPQUFPO01BRTlCLFNBQVMzcUIsTUFBQSxFQUFRO1FBQ2IsT0FBTzJELFFBQUEsQ0FBUyxLQUFLMUYsSUFBQSxDQUFLLElBQUksQ0FBQztNQUNuQztNQUVBLElBQUlxYyxLQUFBLEdBQVEvZ0IsSUFBQSxDQUFLK2dCLEtBQUE7UUFDYnNRLFVBQUEsR0FBYTtVQUNUbHVCLEVBQUEsRUFBSTtVQUNKRCxDQUFBLEVBQUc7VUFDSDNJLENBQUEsRUFBRztVQUNIOEksQ0FBQSxFQUFHO1VBQ0hFLENBQUEsRUFBRztVQUNIRSxDQUFBLEVBQUc7VUFDSEUsQ0FBQSxFQUFHO1FBQ1A7TUFHSixTQUFTMnRCLGtCQUFrQnJ0QixNQUFBLEVBQVFyRSxNQUFBLEVBQVFvRSxhQUFBLEVBQWVFLFFBQUEsRUFBVWpMLE9BQUEsRUFBUTtRQUN4RSxPQUFPQSxPQUFBLENBQU84SyxZQUFBLENBQWFuRSxNQUFBLElBQVUsR0FBRyxDQUFDLENBQUNvRSxhQUFBLEVBQWVDLE1BQUEsRUFBUUMsUUFBUTtNQUM3RTtNQUVBLFNBQVNxdEIsZUFBZUMsY0FBQSxFQUFnQnh0QixhQUFBLEVBQWV5dEIsV0FBQSxFQUFZeDRCLE9BQUEsRUFBUTtRQUN2RSxJQUFJaW5CLFFBQUEsR0FBV0YsY0FBQSxDQUFld1IsY0FBYyxFQUFFdnhCLEdBQUEsQ0FBSTtVQUM5Q3NnQixRQUFBLEdBQVVRLEtBQUEsQ0FBTWIsUUFBQSxDQUFTbVEsRUFBQSxDQUFHLEdBQUcsQ0FBQztVQUNoQ3JaLFFBQUEsR0FBVStKLEtBQUEsQ0FBTWIsUUFBQSxDQUFTbVEsRUFBQSxDQUFHLEdBQUcsQ0FBQztVQUNoQ3RaLE1BQUEsR0FBUWdLLEtBQUEsQ0FBTWIsUUFBQSxDQUFTbVEsRUFBQSxDQUFHLEdBQUcsQ0FBQztVQUM5Qi9QLEtBQUEsR0FBT1MsS0FBQSxDQUFNYixRQUFBLENBQVNtUSxFQUFBLENBQUcsR0FBRyxDQUFDO1VBQzdCalEsT0FBQSxHQUFTVyxLQUFBLENBQU1iLFFBQUEsQ0FBU21RLEVBQUEsQ0FBRyxHQUFHLENBQUM7VUFDL0JoUSxNQUFBLEdBQVFVLEtBQUEsQ0FBTWIsUUFBQSxDQUFTbVEsRUFBQSxDQUFHLEdBQUcsQ0FBQztVQUM5QmxRLE1BQUEsR0FBUVksS0FBQSxDQUFNYixRQUFBLENBQVNtUSxFQUFBLENBQUcsR0FBRyxDQUFDO1VBQzlCMzRCLENBQUEsR0FDSzZvQixRQUFBLElBQVdrUixXQUFBLENBQVd0dUIsRUFBQSxJQUFNLENBQUMsS0FBS29kLFFBQU8sS0FDekNBLFFBQUEsR0FBVWtSLFdBQUEsQ0FBV3Z1QixDQUFBLElBQUssQ0FBQyxNQUFNcWQsUUFBTyxLQUN4Q3ZKLFFBQUEsSUFBVyxLQUFLLENBQUMsR0FBRyxLQUNwQkEsUUFBQSxHQUFVeWEsV0FBQSxDQUFXbDNCLENBQUEsSUFBSyxDQUFDLE1BQU15YyxRQUFPLEtBQ3hDRCxNQUFBLElBQVMsS0FBSyxDQUFDLEdBQUcsS0FDbEJBLE1BQUEsR0FBUTBhLFdBQUEsQ0FBV3B1QixDQUFBLElBQUssQ0FBQyxNQUFNMFQsTUFBSyxLQUNwQ3VKLEtBQUEsSUFBUSxLQUFLLENBQUMsR0FBRyxLQUNqQkEsS0FBQSxHQUFPbVIsV0FBQSxDQUFXbHVCLENBQUEsSUFBSyxDQUFDLE1BQU0rYyxLQUFJO1FBRTNDLElBQUltUixXQUFBLENBQVdodUIsQ0FBQSxJQUFLLE1BQU07VUFDdEIvTCxDQUFBLEdBQ0lBLENBQUEsSUFDQzJvQixNQUFBLElBQVMsS0FBSyxDQUFDLEdBQUcsS0FDbEJBLE1BQUEsR0FBUW9SLFdBQUEsQ0FBV2h1QixDQUFBLElBQUssQ0FBQyxNQUFNNGMsTUFBSztRQUM3QztRQUNBM29CLENBQUEsR0FBSUEsQ0FBQSxJQUNDMG9CLE9BQUEsSUFBVSxLQUFLLENBQUMsR0FBRyxLQUNuQkEsT0FBQSxHQUFTcVIsV0FBQSxDQUFXOXRCLENBQUEsSUFBSyxDQUFDLE1BQU15YyxPQUFNLEtBQ3RDRCxNQUFBLElBQVMsS0FBSyxDQUFDLEdBQUcsS0FBTSxDQUFDLE1BQU1BLE1BQUs7UUFFekN6b0IsQ0FBQSxDQUFFLEtBQUtzTSxhQUFBO1FBQ1B0TSxDQUFBLENBQUUsS0FBSyxDQUFDODVCLGNBQUEsR0FBaUI7UUFDekI5NUIsQ0FBQSxDQUFFLEtBQUt1QixPQUFBO1FBQ1AsT0FBT3E0QixpQkFBQSxDQUFrQno2QixLQUFBLENBQU0sTUFBTWEsQ0FBQztNQUMxQztNQUdBLFNBQVNnNkIsMkJBQTJCQyxnQkFBQSxFQUFrQjtRQUNsRCxJQUFJQSxnQkFBQSxLQUFxQixRQUFXO1VBQ2hDLE9BQU81USxLQUFBO1FBQ1g7UUFDQSxJQUFJLE9BQU80USxnQkFBQSxLQUFxQixZQUFZO1VBQ3hDNVEsS0FBQSxHQUFRNFEsZ0JBQUE7VUFDUixPQUFPO1FBQ1g7UUFDQSxPQUFPO01BQ1g7TUFHQSxTQUFTQyw0QkFBNEJDLFNBQUEsRUFBV0MsS0FBQSxFQUFPO1FBQ25ELElBQUlULFVBQUEsQ0FBV1EsU0FBQSxNQUFlLFFBQVc7VUFDckMsT0FBTztRQUNYO1FBQ0EsSUFBSUMsS0FBQSxLQUFVLFFBQVc7VUFDckIsT0FBT1QsVUFBQSxDQUFXUSxTQUFBO1FBQ3RCO1FBQ0FSLFVBQUEsQ0FBV1EsU0FBQSxJQUFhQyxLQUFBO1FBQ3hCLElBQUlELFNBQUEsS0FBYyxLQUFLO1VBQ25CUixVQUFBLENBQVdsdUIsRUFBQSxHQUFLMnVCLEtBQUEsR0FBUTtRQUM1QjtRQUNBLE9BQU87TUFDWDtNQUVBLFNBQVN2SixTQUFTd0osYUFBQSxFQUFlQyxhQUFBLEVBQWU7UUFDNUMsSUFBSSxDQUFDLEtBQUtuM0IsT0FBQSxDQUFRLEdBQUc7VUFDakIsT0FBTyxLQUFLbUcsVUFBQSxDQUFXLEVBQUVTLFdBQUEsQ0FBWTtRQUN6QztRQUVBLElBQUl3d0IsVUFBQSxHQUFhO1VBQ2JDLEVBQUEsR0FBS2IsVUFBQTtVQUNMcDRCLE9BQUE7VUFDQXdHLE1BQUE7UUFFSixJQUFJLE9BQU9zeUIsYUFBQSxLQUFrQixVQUFVO1VBQ25DQyxhQUFBLEdBQWdCRCxhQUFBO1VBQ2hCQSxhQUFBLEdBQWdCO1FBQ3BCO1FBQ0EsSUFBSSxPQUFPQSxhQUFBLEtBQWtCLFdBQVc7VUFDcENFLFVBQUEsR0FBYUYsYUFBQTtRQUNqQjtRQUNBLElBQUksT0FBT0MsYUFBQSxLQUFrQixVQUFVO1VBQ25DRSxFQUFBLEdBQUs5NkIsTUFBQSxDQUFPKzZCLE1BQUEsQ0FBTyxDQUFDLEdBQUdkLFVBQUEsRUFBWVcsYUFBYTtVQUNoRCxJQUFJQSxhQUFBLENBQWM5dUIsQ0FBQSxJQUFLLFFBQVE4dUIsYUFBQSxDQUFjN3VCLEVBQUEsSUFBTSxNQUFNO1lBQ3JEK3VCLEVBQUEsQ0FBRy91QixFQUFBLEdBQUs2dUIsYUFBQSxDQUFjOXVCLENBQUEsR0FBSTtVQUM5QjtRQUNKO1FBRUFqSyxPQUFBLEdBQVMsS0FBSytILFVBQUEsQ0FBVztRQUN6QnZCLE1BQUEsR0FBUzh4QixjQUFBLENBQWUsTUFBTSxDQUFDVSxVQUFBLEVBQVlDLEVBQUEsRUFBSWo1QixPQUFNO1FBRXJELElBQUlnNUIsVUFBQSxFQUFZO1VBQ1p4eUIsTUFBQSxHQUFTeEcsT0FBQSxDQUFPbUwsVUFBQSxDQUFXLENBQUMsTUFBTTNFLE1BQU07UUFDNUM7UUFFQSxPQUFPeEcsT0FBQSxDQUFPcXZCLFVBQUEsQ0FBVzdvQixNQUFNO01BQ25DO01BRUEsSUFBSTJ5QixLQUFBLEdBQVFweUIsSUFBQSxDQUFLQyxHQUFBO01BRWpCLFNBQVNveUIsS0FBSzNqQixDQUFBLEVBQUc7UUFDYixRQUFRQSxDQUFBLEdBQUksTUFBTUEsQ0FBQSxHQUFJLE1BQU0sQ0FBQ0EsQ0FBQTtNQUNqQztNQUVBLFNBQVM0akIsY0FBQSxFQUFnQjtRQVFyQixJQUFJLENBQUMsS0FBS3ozQixPQUFBLENBQVEsR0FBRztVQUNqQixPQUFPLEtBQUttRyxVQUFBLENBQVcsRUFBRVMsV0FBQSxDQUFZO1FBQ3pDO1FBRUEsSUFBSThlLFFBQUEsR0FBVTZSLEtBQUEsQ0FBTSxLQUFLM1IsYUFBYSxJQUFJO1VBQ3RDSCxLQUFBLEdBQU84UixLQUFBLENBQU0sS0FBSzFSLEtBQUs7VUFDdkJOLE9BQUEsR0FBU2dTLEtBQUEsQ0FBTSxLQUFLMWlCLE9BQU87VUFDM0JzSCxRQUFBO1VBQ0FELE1BQUE7VUFDQW9KLE1BQUE7VUFDQWpkLENBQUE7VUFDQXF2QixLQUFBLEdBQVEsS0FBSzlCLFNBQUEsQ0FBVTtVQUN2QitCLFNBQUE7VUFDQUMsTUFBQTtVQUNBQyxRQUFBO1VBQ0FDLE9BQUE7UUFFSixJQUFJLENBQUNKLEtBQUEsRUFBTztVQUdSLE9BQU87UUFDWDtRQUdBdmIsUUFBQSxHQUFVNU0sUUFBQSxDQUFTbVcsUUFBQSxHQUFVLEVBQUU7UUFDL0J4SixNQUFBLEdBQVEzTSxRQUFBLENBQVM0TSxRQUFBLEdBQVUsRUFBRTtRQUM3QnVKLFFBQUEsSUFBVztRQUNYdkosUUFBQSxJQUFXO1FBR1htSixNQUFBLEdBQVEvVixRQUFBLENBQVNnVyxPQUFBLEdBQVMsRUFBRTtRQUM1QkEsT0FBQSxJQUFVO1FBR1ZsZCxDQUFBLEdBQUlxZCxRQUFBLEdBQVVBLFFBQUEsQ0FBUXFTLE9BQUEsQ0FBUSxDQUFDLEVBQUV4eEIsT0FBQSxDQUFRLFVBQVUsRUFBRSxJQUFJO1FBRXpEb3hCLFNBQUEsR0FBWUQsS0FBQSxHQUFRLElBQUksTUFBTTtRQUM5QkUsTUFBQSxHQUFTSixJQUFBLENBQUssS0FBSzNpQixPQUFPLE1BQU0yaUIsSUFBQSxDQUFLRSxLQUFLLElBQUksTUFBTTtRQUNwREcsUUFBQSxHQUFXTCxJQUFBLENBQUssS0FBSzNSLEtBQUssTUFBTTJSLElBQUEsQ0FBS0UsS0FBSyxJQUFJLE1BQU07UUFDcERJLE9BQUEsR0FBVU4sSUFBQSxDQUFLLEtBQUs1UixhQUFhLE1BQU00UixJQUFBLENBQUtFLEtBQUssSUFBSSxNQUFNO1FBRTNELE9BQ0lDLFNBQUEsR0FDQSxPQUNDclMsTUFBQSxHQUFRc1MsTUFBQSxHQUFTdFMsTUFBQSxHQUFRLE1BQU0sT0FDL0JDLE9BQUEsR0FBU3FTLE1BQUEsR0FBU3JTLE9BQUEsR0FBUyxNQUFNLE9BQ2pDRSxLQUFBLEdBQU9vUyxRQUFBLEdBQVdwUyxLQUFBLEdBQU8sTUFBTSxPQUMvQnZKLE1BQUEsSUFBU0MsUUFBQSxJQUFXdUosUUFBQSxHQUFVLE1BQU0sT0FDcEN4SixNQUFBLEdBQVE0YixPQUFBLEdBQVU1YixNQUFBLEdBQVEsTUFBTSxPQUNoQ0MsUUFBQSxHQUFVMmIsT0FBQSxHQUFVM2IsUUFBQSxHQUFVLE1BQU0sT0FDcEN1SixRQUFBLEdBQVVvUyxPQUFBLEdBQVV6dkIsQ0FBQSxHQUFJLE1BQU07TUFFdkM7TUFFQSxJQUFJMnZCLE9BQUEsR0FBVTVTLFFBQUEsQ0FBUzVvQixTQUFBO01BRXZCdzdCLE9BQUEsQ0FBUWg0QixPQUFBLEdBQVVpbEIsU0FBQTtNQUNsQitTLE9BQUEsQ0FBUTV5QixHQUFBLEdBQU1BLEdBQUE7TUFDZDR5QixPQUFBLENBQVE5ZixHQUFBLEdBQU0rYyxLQUFBO01BQ2QrQyxPQUFBLENBQVE3UCxRQUFBLEdBQVcrTSxVQUFBO01BQ25COEMsT0FBQSxDQUFReEMsRUFBQSxHQUFLQSxFQUFBO01BQ2J3QyxPQUFBLENBQVFyQyxjQUFBLEdBQWlCQSxjQUFBO01BQ3pCcUMsT0FBQSxDQUFRcEMsU0FBQSxHQUFZQSxTQUFBO01BQ3BCb0MsT0FBQSxDQUFRbkMsU0FBQSxHQUFZQSxTQUFBO01BQ3BCbUMsT0FBQSxDQUFRbEMsT0FBQSxHQUFVQSxPQUFBO01BQ2xCa0MsT0FBQSxDQUFRakMsTUFBQSxHQUFTQSxNQUFBO01BQ2pCaUMsT0FBQSxDQUFRaEMsT0FBQSxHQUFVQSxPQUFBO01BQ2xCZ0MsT0FBQSxDQUFRL0IsUUFBQSxHQUFXQSxRQUFBO01BQ25CK0IsT0FBQSxDQUFROUIsVUFBQSxHQUFhQSxVQUFBO01BQ3JCOEIsT0FBQSxDQUFRN0IsT0FBQSxHQUFVQSxPQUFBO01BQ2xCNkIsT0FBQSxDQUFRLzVCLE9BQUEsR0FBVW00QixTQUFBO01BQ2xCNEIsT0FBQSxDQUFRalMsT0FBQSxHQUFVcVAsTUFBQTtNQUNsQjRDLE9BQUEsQ0FBUTNRLEtBQUEsR0FBUWdQLE9BQUE7TUFDaEIyQixPQUFBLENBQVF2bUIsR0FBQSxHQUFNNmtCLEtBQUE7TUFDZDBCLE9BQUEsQ0FBUXJ0QixZQUFBLEdBQWVBLFlBQUE7TUFDdkJxdEIsT0FBQSxDQUFRNXNCLE9BQUEsR0FBVUEsT0FBQTtNQUNsQjRzQixPQUFBLENBQVFudEIsT0FBQSxHQUFVQSxPQUFBO01BQ2xCbXRCLE9BQUEsQ0FBUXh0QixLQUFBLEdBQVFBLEtBQUE7TUFDaEJ3dEIsT0FBQSxDQUFRbnVCLElBQUEsR0FBT0EsSUFBQTtNQUNmbXVCLE9BQUEsQ0FBUXBzQixLQUFBLEdBQVFBLEtBQUE7TUFDaEJvc0IsT0FBQSxDQUFRanRCLE1BQUEsR0FBU0EsTUFBQTtNQUNqQml0QixPQUFBLENBQVEvckIsS0FBQSxHQUFRQSxLQUFBO01BQ2hCK3JCLE9BQUEsQ0FBUXRLLFFBQUEsR0FBV0EsUUFBQTtNQUNuQnNLLE9BQUEsQ0FBUWhMLFdBQUEsR0FBY3lLLGFBQUE7TUFDdEJPLE9BQUEsQ0FBUXY3QixRQUFBLEdBQVdnN0IsYUFBQTtNQUNuQk8sT0FBQSxDQUFRckosTUFBQSxHQUFTOEksYUFBQTtNQUNqQk8sT0FBQSxDQUFRakwsTUFBQSxHQUFTQSxNQUFBO01BQ2pCaUwsT0FBQSxDQUFRN3hCLFVBQUEsR0FBYUEsVUFBQTtNQUVyQjZ4QixPQUFBLENBQVFDLFdBQUEsR0FBYzMxQixTQUFBLENBQ2xCLHVGQUNBbTFCLGFBQ0o7TUFDQU8sT0FBQSxDQUFRbEssSUFBQSxHQUFPQSxJQUFBO01BSWZob0IsY0FBQSxDQUFlLEtBQUssR0FBRyxHQUFHLE1BQU07TUFDaENBLGNBQUEsQ0FBZSxLQUFLLEdBQUcsR0FBRyxTQUFTO01BSW5DNEksYUFBQSxDQUFjLEtBQUtSLFdBQVc7TUFDOUJRLGFBQUEsQ0FBYyxLQUFLTCxjQUFjO01BQ2pDMkIsYUFBQSxDQUFjLEtBQUssVUFBVTNULEtBQUEsRUFBT29LLEtBQUEsRUFBTzFFLE1BQUEsRUFBUTtRQUMvQ0EsTUFBQSxDQUFPM0IsRUFBQSxHQUFLLElBQUk1QyxJQUFBLENBQUt3bkIsVUFBQSxDQUFXM29CLEtBQUssSUFBSSxHQUFJO01BQ2pELENBQUM7TUFDRDJULGFBQUEsQ0FBYyxLQUFLLFVBQVUzVCxLQUFBLEVBQU9vSyxLQUFBLEVBQU8xRSxNQUFBLEVBQVE7UUFDL0NBLE1BQUEsQ0FBTzNCLEVBQUEsR0FBSyxJQUFJNUMsSUFBQSxDQUFLa1MsS0FBQSxDQUFNclQsS0FBSyxDQUFDO01BQ3JDLENBQUM7TUFJRE4sS0FBQSxDQUFNbThCLE9BQUEsR0FBVTtNQUVoQmg4QixlQUFBLENBQWdCMG1CLFdBQVc7TUFFM0I3bUIsS0FBQSxDQUFNNEIsRUFBQSxHQUFLZzFCLEtBQUE7TUFDWDUyQixLQUFBLENBQU02WixHQUFBLEdBQU1BLEdBQUE7TUFDWjdaLEtBQUEsQ0FBTXlKLEdBQUEsR0FBTUEsR0FBQTtNQUNaekosS0FBQSxDQUFNa21CLEdBQUEsR0FBTUEsR0FBQTtNQUNabG1CLEtBQUEsQ0FBTXdDLEdBQUEsR0FBTUwsU0FBQTtNQUNabkMsS0FBQSxDQUFNMHlCLElBQUEsR0FBT2lGLFVBQUE7TUFDYjMzQixLQUFBLENBQU1nUCxNQUFBLEdBQVMwcEIsVUFBQTtNQUNmMTRCLEtBQUEsQ0FBTXdCLE1BQUEsR0FBU0EsTUFBQTtNQUNmeEIsS0FBQSxDQUFNZ3hCLE1BQUEsR0FBU3JQLGtCQUFBO01BQ2YzaEIsS0FBQSxDQUFNdXRCLE9BQUEsR0FBVTFvQixhQUFBO01BQ2hCN0UsS0FBQSxDQUFNc3BCLFFBQUEsR0FBV0YsY0FBQTtNQUNqQnBwQixLQUFBLENBQU1rRyxRQUFBLEdBQVdBLFFBQUE7TUFDakJsRyxLQUFBLENBQU1pTyxRQUFBLEdBQVcycUIsWUFBQTtNQUNqQjU0QixLQUFBLENBQU1zM0IsU0FBQSxHQUFZTSxZQUFBO01BQ2xCNTNCLEtBQUEsQ0FBTW9LLFVBQUEsR0FBYTBYLFNBQUE7TUFDbkI5aEIsS0FBQSxDQUFNaXFCLFVBQUEsR0FBYUEsVUFBQTtNQUNuQmpxQixLQUFBLENBQU1tWSxXQUFBLEdBQWN3Z0IsZUFBQTtNQUNwQjM0QixLQUFBLENBQU1xYyxXQUFBLEdBQWN5YyxlQUFBO01BQ3BCOTRCLEtBQUEsQ0FBTStoQixZQUFBLEdBQWVBLFlBQUE7TUFDckIvaEIsS0FBQSxDQUFNbWlCLFlBQUEsR0FBZUEsWUFBQTtNQUNyQm5pQixLQUFBLENBQU15Z0IsT0FBQSxHQUFVNEIsV0FBQTtNQUNoQnJpQixLQUFBLENBQU1zYyxhQUFBLEdBQWdCdWMsaUJBQUE7TUFDdEI3NEIsS0FBQSxDQUFNb1EsY0FBQSxHQUFpQkEsY0FBQTtNQUN2QnBRLEtBQUEsQ0FBTW84QixvQkFBQSxHQUF1QnRCLDBCQUFBO01BQzdCOTZCLEtBQUEsQ0FBTXE4QixxQkFBQSxHQUF3QnJCLDJCQUFBO01BQzlCaDdCLEtBQUEsQ0FBTTB2QixjQUFBLEdBQWlCUixpQkFBQTtNQUN2Qmx2QixLQUFBLENBQU1TLFNBQUEsR0FBWW0yQixLQUFBO01BR2xCNTJCLEtBQUEsQ0FBTXM4QixTQUFBLEdBQVk7UUFDZEMsY0FBQSxFQUFnQjtRQUNoQkMsc0JBQUEsRUFBd0I7UUFDeEJDLGlCQUFBLEVBQW1CO1FBQ25COW5CLElBQUEsRUFBTTtRQUNOK25CLElBQUEsRUFBTTtRQUNOQyxZQUFBLEVBQWM7UUFDZEMsT0FBQSxFQUFTO1FBQ1Q1bkIsSUFBQSxFQUFNO1FBQ05OLEtBQUEsRUFBTztNQUNYO01BRUEsT0FBTzFVLEtBQUE7SUFFWCxDQUFFO0VBQUE7QUFBQTs7O0FDdmpMRixJQUFBNjhCLHFCQUFBO0FBQUFDLFFBQUEsQ0FBQUQscUJBQUE7RUFBQUUsT0FBQSxFQUFBQSxDQUFBLEtBQUFDO0FBQUE7QUFBQUMsTUFBQSxDQUFBejlCLE9BQUEsR0FBQTA5QixZQUFBLENBQUFMLHFCQUFBO0FBQUFNLFVBQUEsQ0FBQU4scUJBQUEsRUFBY08sT0FBQSxDQUFBLzlCLGNBQUEsS0FBZDQ5QixNQUFBLENBQUF6OUIsT0FBQTtBQUVBLElBQUE2OUIsYUFBQSxHQUFxQkQsT0FBQSxDQUFBLzlCLGNBQUE7QUFDckIsSUFBTzI5QixxQkFBQSxHQUFRSyxhQUFBLENBQUFOLE9BQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii9jbGllbnQvb3V0In0=