System.register(["react@18.2.0","@kurkle/color@0.3.2","chart.js@4.4.1"], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["react","18.2.0"],["@kurkle/color","0.3.2"],["chart.js","4.4.1"],["react-chartjs-2","5.2.0"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [dep => dependencies.set('react@18.2.0', dep), dep => dependencies.set('@kurkle/color@0.3.2', dep), dep => dependencies.set('chart.js@4.4.1', dep)],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
  value: mod,
  enumerable: true
}) : target, mod));
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/react-chartjs-2.5.2.0.js
var react_chartjs_2_5_2_0_exports = {};
__export(react_chartjs_2_5_2_0_exports, {
  Bar: () => Bar,
  Bubble: () => Bubble,
  Chart: () => Chart,
  Doughnut: () => Doughnut,
  Line: () => Line,
  Pie: () => Pie,
  PolarArea: () => PolarArea,
  Radar: () => Radar,
  Scatter: () => Scatter,
  getDatasetAtEvent: () => getDatasetAtEvent,
  getElementAtEvent: () => getElementAtEvent,
  getElementsAtEvent: () => getElementsAtEvent
});
module.exports = __toCommonJS(react_chartjs_2_5_2_0_exports);

// node_modules/react-chartjs-2/dist/index.js
var import_react = __toESM(require("react@18.2.0"), 0);
var import_chart = require("chart.js@4.4.1");
var defaultDatasetIdKey = "label";
function reforwardRef(ref, value) {
  if (typeof ref === "function") {
    ref(value);
  } else if (ref) {
    ref.current = value;
  }
}
function setOptions(chart, nextOptions) {
  const options = chart.options;
  if (options && nextOptions) {
    Object.assign(options, nextOptions);
  }
}
function setLabels(currentData, nextLabels) {
  currentData.labels = nextLabels;
}
function setDatasets(currentData, nextDatasets) {
  let datasetIdKey = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : defaultDatasetIdKey;
  const addedDatasets = [];
  currentData.datasets = nextDatasets.map(nextDataset => {
    const currentDataset = currentData.datasets.find(dataset => dataset[datasetIdKey] === nextDataset[datasetIdKey]);
    if (!currentDataset || !nextDataset.data || addedDatasets.includes(currentDataset)) {
      return {
        ...nextDataset
      };
    }
    addedDatasets.push(currentDataset);
    Object.assign(currentDataset, nextDataset);
    return currentDataset;
  });
}
function cloneData(data) {
  let datasetIdKey = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : defaultDatasetIdKey;
  const nextData = {
    labels: [],
    datasets: []
  };
  setLabels(nextData, data.labels);
  setDatasets(nextData, data.datasets, datasetIdKey);
  return nextData;
}
function getDatasetAtEvent(chart, event) {
  return chart.getElementsAtEventForMode(event.nativeEvent, "dataset", {
    intersect: true
  }, false);
}
function getElementAtEvent(chart, event) {
  return chart.getElementsAtEventForMode(event.nativeEvent, "nearest", {
    intersect: true
  }, false);
}
function getElementsAtEvent(chart, event) {
  return chart.getElementsAtEventForMode(event.nativeEvent, "index", {
    intersect: true
  }, false);
}
function ChartComponent(props, ref) {
  const {
    height = 150,
    width = 300,
    redraw = false,
    datasetIdKey,
    type,
    data,
    options,
    plugins = [],
    fallbackContent,
    updateMode,
    ...canvasProps
  } = props;
  const canvasRef = (0, import_react.useRef)(null);
  const chartRef = (0, import_react.useRef)();
  const renderChart = () => {
    if (!canvasRef.current) return;
    chartRef.current = new import_chart.Chart(canvasRef.current, {
      type,
      data: cloneData(data, datasetIdKey),
      options: options && {
        ...options
      },
      plugins
    });
    reforwardRef(ref, chartRef.current);
  };
  const destroyChart = () => {
    reforwardRef(ref, null);
    if (chartRef.current) {
      chartRef.current.destroy();
      chartRef.current = null;
    }
  };
  (0, import_react.useEffect)(() => {
    if (!redraw && chartRef.current && options) {
      setOptions(chartRef.current, options);
    }
  }, [redraw, options]);
  (0, import_react.useEffect)(() => {
    if (!redraw && chartRef.current) {
      setLabels(chartRef.current.config.data, data.labels);
    }
  }, [redraw, data.labels]);
  (0, import_react.useEffect)(() => {
    if (!redraw && chartRef.current && data.datasets) {
      setDatasets(chartRef.current.config.data, data.datasets, datasetIdKey);
    }
  }, [redraw, data.datasets]);
  (0, import_react.useEffect)(() => {
    if (!chartRef.current) return;
    if (redraw) {
      destroyChart();
      setTimeout(renderChart);
    } else {
      chartRef.current.update(updateMode);
    }
  }, [redraw, options, data.labels, data.datasets, updateMode]);
  (0, import_react.useEffect)(() => {
    if (!chartRef.current) return;
    destroyChart();
    setTimeout(renderChart);
  }, [type]);
  (0, import_react.useEffect)(() => {
    renderChart();
    return () => destroyChart();
  }, []);
  return /* @__PURE__ */import_react.default.createElement("canvas", Object.assign({
    ref: canvasRef,
    role: "img",
    height,
    width
  }, canvasProps), fallbackContent);
}
var Chart = /* @__PURE__ */(0, import_react.forwardRef)(ChartComponent);
function createTypedChart(type, registerables) {
  import_chart.Chart.register(registerables);
  return /* @__PURE__ */(0, import_react.forwardRef)((props, ref) => /* @__PURE__ */import_react.default.createElement(Chart, Object.assign({}, props, {
    ref,
    type
  })));
}
var Line = /* @__PURE__ */createTypedChart("line", import_chart.LineController);
var Bar = /* @__PURE__ */createTypedChart("bar", import_chart.BarController);
var Radar = /* @__PURE__ */createTypedChart("radar", import_chart.RadarController);
var Doughnut = /* @__PURE__ */createTypedChart("doughnut", import_chart.DoughnutController);
var PolarArea = /* @__PURE__ */createTypedChart("polarArea", import_chart.PolarAreaController);
var Bubble = /* @__PURE__ */createTypedChart("bubble", import_chart.BubbleController);
var Pie = /* @__PURE__ */createTypedChart("pie", import_chart.PieController);
var Scatter = /* @__PURE__ */createTypedChart("scatter", import_chart.ScatterController);
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL3JlYWN0LWNoYXJ0anMtMi41LjIuMC5qcyIsIi4uL25vZGVfbW9kdWxlcy9yZWFjdC1jaGFydGpzLTIvc3JjL3V0aWxzLnRzIiwiLi4vbm9kZV9tb2R1bGVzL3JlYWN0LWNoYXJ0anMtMi9zcmMvY2hhcnQudHN4IiwiLi4vbm9kZV9tb2R1bGVzL3JlYWN0LWNoYXJ0anMtMi9zcmMvdHlwZWRDaGFydHMudHN4Il0sIm5hbWVzIjpbInJlYWN0X2NoYXJ0anNfMl81XzJfMF9leHBvcnRzIiwiX19leHBvcnQiLCJCYXIiLCJCdWJibGUiLCJDaGFydCIsIkRvdWdobnV0IiwiTGluZSIsIlBpZSIsIlBvbGFyQXJlYSIsIlJhZGFyIiwiU2NhdHRlciIsImdldERhdGFzZXRBdEV2ZW50IiwiZ2V0RWxlbWVudEF0RXZlbnQiLCJnZXRFbGVtZW50c0F0RXZlbnQiLCJtb2R1bGUiLCJleHBvcnRzIiwiX190b0NvbW1vbkpTIiwiZGVmYXVsdERhdGFzZXRJZEtleSIsInJlZm9yd2FyZFJlZiIsInJlZiIsInZhbHVlIiwiY3VycmVudCIsInNldE9wdGlvbnMiLCJjaGFydCIsIm5leHRPcHRpb25zIiwib3B0aW9ucyIsIk9iamVjdCIsImFzc2lnbiIsInNldExhYmVscyIsImN1cnJlbnREYXRhIiwibmV4dExhYmVscyIsImxhYmVscyIsInNldERhdGFzZXRzIiwibmV4dERhdGFzZXRzIiwiZGF0YXNldElkS2V5IiwiYXJndW1lbnRzIiwibGVuZ3RoIiwiYWRkZWREYXRhc2V0cyIsImRhdGFzZXRzIiwibWFwIiwibmV4dERhdGFzZXQiLCJjdXJyZW50RGF0YXNldCIsImZpbmQiLCJkYXRhc2V0IiwiZGF0YSIsImluY2x1ZGVzIiwicHVzaCIsImNsb25lRGF0YSIsIm5leHREYXRhIiwiZXZlbnQiLCJnZXRFbGVtZW50c0F0RXZlbnRGb3JNb2RlIiwibmF0aXZlRXZlbnQiLCJpbnRlcnNlY3QiLCJDaGFydENvbXBvbmVudCIsInByb3BzIiwiaGVpZ2h0Iiwid2lkdGgiLCJyZWRyYXciLCJ0eXBlIiwicGx1Z2lucyIsImZhbGxiYWNrQ29udGVudCIsInVwZGF0ZU1vZGUiLCJjYW52YXNQcm9wcyIsImNhbnZhc1JlZiIsImltcG9ydF9yZWFjdCIsInVzZVJlZiIsImNoYXJ0UmVmIiwicmVuZGVyQ2hhcnQiLCJpbXBvcnRfY2hhcnQiLCJkZXN0cm95Q2hhcnQiLCJkZXN0cm95IiwidXNlRWZmZWN0IiwiY29uZmlnIiwic2V0VGltZW91dCIsInVwZGF0ZSIsImRlZmF1bHQiLCJjcmVhdGVFbGVtZW50Iiwicm9sZSIsImZvcndhcmRSZWYiLCJjcmVhdGVUeXBlZENoYXJ0IiwicmVnaXN0ZXJhYmxlcyIsInJlZ2lzdGVyIiwiTGluZUNvbnRyb2xsZXIiLCJCYXJDb250cm9sbGVyIiwiUmFkYXJDb250cm9sbGVyIiwiRG91Z2hudXRDb250cm9sbGVyIiwiUG9sYXJBcmVhQ29udHJvbGxlciIsIkJ1YmJsZUNvbnRyb2xsZXIiLCJQaWVDb250cm9sbGVyIiwiU2NhdHRlckNvbnRyb2xsZXIiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUFBLDZCQUFBO0FBQUFDLFFBQUEsQ0FBQUQsNkJBQUE7RUFBQUUsR0FBQSxFQUFBQSxDQUFBLEtBQUFBLEdBQUE7RUFBQUMsTUFBQSxFQUFBQSxDQUFBLEtBQUFBLE1BQUE7RUFBQUMsS0FBQSxFQUFBQSxDQUFBLEtBQUFBLEtBQUE7RUFBQUMsUUFBQSxFQUFBQSxDQUFBLEtBQUFBLFFBQUE7RUFBQUMsSUFBQSxFQUFBQSxDQUFBLEtBQUFBLElBQUE7RUFBQUMsR0FBQSxFQUFBQSxDQUFBLEtBQUFBLEdBQUE7RUFBQUMsU0FBQSxFQUFBQSxDQUFBLEtBQUFBLFNBQUE7RUFBQUMsS0FBQSxFQUFBQSxDQUFBLEtBQUFBLEtBQUE7RUFBQUMsT0FBQSxFQUFBQSxDQUFBLEtBQUFBLE9BQUE7RUFBQUMsaUJBQUEsRUFBQUEsQ0FBQSxLQUFBQSxpQkFBQTtFQUFBQyxpQkFBQSxFQUFBQSxDQUFBLEtBQUFBLGlCQUFBO0VBQUFDLGtCQUFBLEVBQUFBLENBQUEsS0FBQUE7QUFBQTtBQUFBQyxNQUFBLENBQUFDLE9BQUEsR0FBQUMsWUFBQSxDQUFBaEIsNkJBQUE7Ozs7O0FDWUEsSUFBTWlCLG1CQUFBLEdBQXNCO0FBRXJCLFNBQVNDLGFBQWdCQyxHQUFBLEVBQXNCQyxLQUFBLEVBQVU7RUFDOUQsSUFBSSxPQUFPRCxHQUFBLEtBQVEsWUFBWTtJQUM3QkEsR0FBQSxDQUFJQyxLQUFBO0VBQ04sV0FBV0QsR0FBQSxFQUFLO0lBQ2RBLEdBQUEsQ0FBSUUsT0FBQSxHQUFVRCxLQUFBOztBQUVsQjtBQUVPLFNBQVNFLFdBSWRDLEtBQUEsRUFBb0NDLFdBQUEsRUFBa0M7RUFDdEUsTUFBTUMsT0FBQSxHQUFVRixLQUFBLENBQU1FLE9BQUE7RUFFdEIsSUFBSUEsT0FBQSxJQUFXRCxXQUFBLEVBQWE7SUFDMUJFLE1BQUEsQ0FBT0MsTUFBQSxDQUFPRixPQUFBLEVBQVNELFdBQUE7O0FBRTNCO0FBRU8sU0FBU0ksVUFLZEMsV0FBQSxFQUNBQyxVQUFBLEVBQ0E7RUFDQUQsV0FBQSxDQUFZRSxNQUFBLEdBQVNELFVBQUE7QUFDdkI7QUFFTyxTQUFTRSxZQUtkSCxXQUFBLEVBQ0FJLFlBQUEsRUFFQTtFQURBLElBQUFDLFlBQUEsR0FBQUMsU0FBQSxDQUFBQyxNQUFBLFFBQUFELFNBQUEsaUJBQUFBLFNBQUEsTUFBZWxCLG1CQUFBO0VBRWYsTUFBTW9CLGFBQUEsR0FBOEM7RUFFcERSLFdBQUEsQ0FBWVMsUUFBQSxHQUFXTCxZQUFBLENBQWFNLEdBQUEsQ0FDakNDLFdBQUEsSUFBeUM7SUFFeEMsTUFBTUMsY0FBQSxHQUFpQlosV0FBQSxDQUFZUyxRQUFBLENBQVNJLElBQUEsQ0FDekNDLE9BQUEsSUFDQ0EsT0FBQSxDQUFRVCxZQUFBLE1BQWtCTSxXQUFBLENBQVlOLFlBQUEsQ0FBYTtJQUl2RCxJQUNFLENBQUNPLGNBQUEsSUFDRCxDQUFDRCxXQUFBLENBQVlJLElBQUEsSUFDYlAsYUFBQSxDQUFjUSxRQUFBLENBQVNKLGNBQ3ZCO01BQ0EsT0FBTztRQUFFLEdBQUdEO01BQVk7O0lBRzFCSCxhQUFBLENBQWNTLElBQUEsQ0FBS0wsY0FBQTtJQUVuQmYsTUFBQSxDQUFPQyxNQUFBLENBQU9jLGNBQUEsRUFBZ0JELFdBQUE7SUFFOUIsT0FBT0MsY0FBQTtFQUNUO0FBRUo7QUFFTyxTQUFTTSxVQUlkSCxJQUFBLEVBQTJFO0VBQXBDLElBQUFWLFlBQUEsR0FBQUMsU0FBQSxDQUFBQyxNQUFBLFFBQUFELFNBQUEsaUJBQUFBLFNBQUEsTUFBZWxCLG1CQUFBO0VBQ3RELE1BQU0rQixRQUFBLEdBQTRDO0lBQ2hEakIsTUFBQSxFQUFRO0lBQ1JPLFFBQUEsRUFBVTtFQUNaO0VBRUFWLFNBQUEsQ0FBVW9CLFFBQUEsRUFBVUosSUFBQSxDQUFLYixNQUFNO0VBQy9CQyxXQUFBLENBQVlnQixRQUFBLEVBQVVKLElBQUEsQ0FBS04sUUFBQSxFQUFVSixZQUFBO0VBRXJDLE9BQU9jLFFBQUE7QUFDVDtBQVFPLFNBQVNyQyxrQkFDZFksS0FBQSxFQUNBMEIsS0FBQSxFQUNBO0VBQ0EsT0FBTzFCLEtBQUEsQ0FBTTJCLHlCQUFBLENBQ1hELEtBQUEsQ0FBTUUsV0FBQSxFQUNOLFdBQ0E7SUFBRUMsU0FBQSxFQUFXO0VBQUssR0FDbEIsS0FBSztBQUVUO0FBUU8sU0FBU3hDLGtCQUNkVyxLQUFBLEVBQ0EwQixLQUFBLEVBQ0E7RUFDQSxPQUFPMUIsS0FBQSxDQUFNMkIseUJBQUEsQ0FDWEQsS0FBQSxDQUFNRSxXQUFBLEVBQ04sV0FDQTtJQUFFQyxTQUFBLEVBQVc7RUFBSyxHQUNsQixLQUFLO0FBRVQ7QUFRTyxTQUFTdkMsbUJBQ2RVLEtBQUEsRUFDQTBCLEtBQUEsRUFDQTtFQUNBLE9BQU8xQixLQUFBLENBQU0yQix5QkFBQSxDQUNYRCxLQUFBLENBQU1FLFdBQUEsRUFDTixTQUNBO0lBQUVDLFNBQUEsRUFBVztFQUFLLEdBQ2xCLEtBQUs7QUFFVDtBQ3pJQSxTQUFTQyxlQUtQQyxLQUFBLEVBQ0FuQyxHQUFBLEVBQ0E7RUFDQSxNQUFNO0lBQ0pvQyxNQUFBLEdBQVM7SUFDVEMsS0FBQSxHQUFRO0lBQ1JDLE1BQUEsR0FBUztJQUNUdkIsWUFBQTtJQUNBd0IsSUFBQTtJQUNBZCxJQUFBO0lBQ0FuQixPQUFBO0lBQ0FrQyxPQUFBLEdBQVU7SUFDVkMsZUFBQTtJQUNBQyxVQUFBO0lBQUEsR0FDR0M7RUFBQSxJQUNEUixLQUFBO0VBQ0osTUFBTVMsU0FBQSxPQUFZQyxZQUFBLENBQUFDLE1BQUEsRUFBMEIsSUFBSTtFQUNoRCxNQUFNQyxRQUFBLE9BQVdGLFlBQUEsQ0FBQUMsTUFBQTtFQUVqQixNQUFNRSxXQUFBLEdBQWNBLENBQUEsS0FBTTtJQUN4QixJQUFJLENBQUNKLFNBQUEsQ0FBVTFDLE9BQUEsRUFBUztJQUV4QjZDLFFBQUEsQ0FBUzdDLE9BQUEsR0FBVSxJQUFJK0MsWUFBQSxDQUFBaEUsS0FBQSxDQUFRMkQsU0FBQSxDQUFVMUMsT0FBQSxFQUFTO01BQ2hEcUMsSUFBQTtNQUNBZCxJQUFBLEVBQU1HLFNBQUEsQ0FBVUgsSUFBQSxFQUFNVixZQUFBO01BQ3RCVCxPQUFBLEVBQVNBLE9BQUEsSUFBVztRQUFFLEdBQUdBO01BQVE7TUFDakNrQztJQUNGO0lBRUF6QyxZQUFBLENBQWFDLEdBQUEsRUFBSytDLFFBQUEsQ0FBUzdDLE9BQU87RUFDcEM7RUFFQSxNQUFNZ0QsWUFBQSxHQUFlQSxDQUFBLEtBQU07SUFDekJuRCxZQUFBLENBQWFDLEdBQUEsRUFBSyxJQUFJO0lBRXRCLElBQUkrQyxRQUFBLENBQVM3QyxPQUFBLEVBQVM7TUFDcEI2QyxRQUFBLENBQVM3QyxPQUFBLENBQVFpRCxPQUFBLENBQU87TUFDeEJKLFFBQUEsQ0FBUzdDLE9BQUEsR0FBVTs7RUFFdkI7RUFFQSxJQUFBMkMsWUFBQSxDQUFBTyxTQUFBLEVBQVUsTUFBTTtJQUNkLElBQUksQ0FBQ2QsTUFBQSxJQUFVUyxRQUFBLENBQVM3QyxPQUFBLElBQVdJLE9BQUEsRUFBUztNQUMxQ0gsVUFBQSxDQUFXNEMsUUFBQSxDQUFTN0MsT0FBQSxFQUFTSSxPQUFBOztLQUU5QixDQUFDZ0MsTUFBQSxFQUFRaEMsT0FBQSxDQUFRO0VBRXBCLElBQUF1QyxZQUFBLENBQUFPLFNBQUEsRUFBVSxNQUFNO0lBQ2QsSUFBSSxDQUFDZCxNQUFBLElBQVVTLFFBQUEsQ0FBUzdDLE9BQUEsRUFBUztNQUMvQk8sU0FBQSxDQUFVc0MsUUFBQSxDQUFTN0MsT0FBQSxDQUFRbUQsTUFBQSxDQUFPNUIsSUFBQSxFQUFNQSxJQUFBLENBQUtiLE1BQU07O0tBRXBELENBQUMwQixNQUFBLEVBQVFiLElBQUEsQ0FBS2IsTUFBQSxDQUFPO0VBRXhCLElBQUFpQyxZQUFBLENBQUFPLFNBQUEsRUFBVSxNQUFNO0lBQ2QsSUFBSSxDQUFDZCxNQUFBLElBQVVTLFFBQUEsQ0FBUzdDLE9BQUEsSUFBV3VCLElBQUEsQ0FBS04sUUFBQSxFQUFVO01BQ2hETixXQUFBLENBQVlrQyxRQUFBLENBQVM3QyxPQUFBLENBQVFtRCxNQUFBLENBQU81QixJQUFBLEVBQU1BLElBQUEsQ0FBS04sUUFBQSxFQUFVSixZQUFBOztLQUUxRCxDQUFDdUIsTUFBQSxFQUFRYixJQUFBLENBQUtOLFFBQUEsQ0FBUztFQUUxQixJQUFBMEIsWUFBQSxDQUFBTyxTQUFBLEVBQVUsTUFBTTtJQUNkLElBQUksQ0FBQ0wsUUFBQSxDQUFTN0MsT0FBQSxFQUFTO0lBRXZCLElBQUlvQyxNQUFBLEVBQVE7TUFDVlksWUFBQTtNQUNBSSxVQUFBLENBQVdOLFdBQUE7V0FDTjtNQUNMRCxRQUFBLENBQVM3QyxPQUFBLENBQVFxRCxNQUFBLENBQU9iLFVBQUE7O0tBRXpCLENBQUNKLE1BQUEsRUFBUWhDLE9BQUEsRUFBU21CLElBQUEsQ0FBS2IsTUFBQSxFQUFRYSxJQUFBLENBQUtOLFFBQUEsRUFBVXVCLFVBQUEsQ0FBVztFQUU1RCxJQUFBRyxZQUFBLENBQUFPLFNBQUEsRUFBVSxNQUFNO0lBQ2QsSUFBSSxDQUFDTCxRQUFBLENBQVM3QyxPQUFBLEVBQVM7SUFFdkJnRCxZQUFBO0lBQ0FJLFVBQUEsQ0FBV04sV0FBQTtLQUNWLENBQUNULElBQUEsQ0FBSztFQUVULElBQUFNLFlBQUEsQ0FBQU8sU0FBQSxFQUFVLE1BQU07SUFDZEosV0FBQTtJQUVBLE9BQU8sTUFBTUUsWUFBQTtFQUNmLEdBQUcsRUFBRTtFQUVMLE9BQ0UsZUFBQUwsWUFBQSxDQUFBVyxPQUFBLENBQUNDLGFBQUEsV0FBQWxELE1BQUEsQ0FBQUMsTUFBQTtJQUNDUixHQUFBLEVBQUs0QyxTQUFBO0lBQ0xjLElBQUEsRUFBSztJQUNMdEIsTUFBQTtJQUNBQztLQUNJTSxXQUVILEdBQUFGLGVBQUE7QUFHUDtBQUVPLElBQU14RCxLQUFBLEdBQVEsbUJBQUE0RCxZQUFBLENBQUFjLFVBQUEsRUFBV3pCLGNBQXNDO0FDN0Z0RSxTQUFTMEIsaUJBQ1ByQixJQUFBLEVBQ0FzQixhQUFBLEVBQ0E7RUFDQVosWUFBQSxDQUFBaEUsS0FBQSxDQUFRNkUsUUFBQSxDQUFTRCxhQUFBO0VBRWpCLE9BQU8sbUJBQUFoQixZQUFBLENBQUFjLFVBQUEsRUFDTCxDQUFDeEIsS0FBQSxFQUFPbkMsR0FBQSxLQUFRLGVBQUE2QyxZQUFBLENBQUFXLE9BQUEsQ0FBQUMsYUFBQSxDQUFDeEUsS0FBQSxFQUFVc0IsTUFBQSxDQUFBQyxNQUFBLEtBQUEyQixLQUFBO0lBQU9uQyxHQUFBO0lBQVV1Qzs7QUFFaEQ7SUFFYXBELElBQUEsR0FBdUIsZUFBQXlFLGdCQUFBLENBQWlCLFFBQVFYLFlBQUEsQ0FBQWMsY0FBZ0I7SUFFaEVoRixHQUFBLEdBQXNCLGVBQUE2RSxnQkFBQSxDQUFpQixPQUFPWCxZQUFBLENBQUFlLGFBQWU7SUFFN0QxRSxLQUFBLEdBQXdCLGVBQUFzRSxnQkFBQSxDQUFpQixTQUFTWCxZQUFBLENBQUFnQixlQUFpQjtJQUVuRS9FLFFBQUEsR0FBMkIsZUFBQTBFLGdCQUFBLENBQ3RDLFlBQ0FYLFlBQUEsQ0FBQWlCLGtCQUNBO0lBRVc3RSxTQUFBLEdBQTRCLGVBQUF1RSxnQkFBQSxDQUN2QyxhQUNBWCxZQUFBLENBQUFrQixtQkFDQTtJQUVXbkYsTUFBQSxHQUF5QixlQUFBNEUsZ0JBQUEsQ0FDcEMsVUFDQVgsWUFBQSxDQUFBbUIsZ0JBQ0E7SUFFV2hGLEdBQUEsR0FBc0IsZUFBQXdFLGdCQUFBLENBQWlCLE9BQU9YLFlBQUEsQ0FBQW9CLGFBQWU7SUFFN0Q5RSxPQUFBLEdBQTBCLGVBQUFxRSxnQkFBQSxDQUNyQyxXQUNBWCxZQUFBLENBQUFxQixpQkFDQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==