System.register([], (_exports, _context) => {

const bimport = specifier => {
	const dependencies = new Map([["swiper","11.1.3"]]);
	return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
};


var dependencies = new Map();
var require = dependency => dependencies.get(dependency);
return {
setters: [],
execute: function() {
// Prevent esbuild from considering the context to be amd
const define = void 0;
const module = {};

const code = (module, require) => {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {
    get: all[name],
    enumerable: true
  });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: () => from[key],
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
  value: true
}), mod);

// .beyond/uimport/temp/swiper.11.1.3.js
var swiper_11_1_3_exports = {};
__export(swiper_11_1_3_exports, {
  Swiper: () => Swiper,
  default: () => swiper_11_1_3_default
});
module.exports = __toCommonJS(swiper_11_1_3_exports);

// node_modules/swiper/shared/ssr-window.esm.mjs
function isObject(obj) {
  return obj !== null && typeof obj === "object" && "constructor" in obj && obj.constructor === Object;
}
function extend(target, src) {
  if (target === void 0) {
    target = {};
  }
  if (src === void 0) {
    src = {};
  }
  Object.keys(src).forEach(key => {
    if (typeof target[key] === "undefined") target[key] = src[key];else if (isObject(src[key]) && isObject(target[key]) && Object.keys(src[key]).length > 0) {
      extend(target[key], src[key]);
    }
  });
}
var ssrDocument = {
  body: {},
  addEventListener() {},
  removeEventListener() {},
  activeElement: {
    blur() {},
    nodeName: ""
  },
  querySelector() {
    return null;
  },
  querySelectorAll() {
    return [];
  },
  getElementById() {
    return null;
  },
  createEvent() {
    return {
      initEvent() {}
    };
  },
  createElement() {
    return {
      children: [],
      childNodes: [],
      style: {},
      setAttribute() {},
      getElementsByTagName() {
        return [];
      }
    };
  },
  createElementNS() {
    return {};
  },
  importNode() {
    return null;
  },
  location: {
    hash: "",
    host: "",
    hostname: "",
    href: "",
    origin: "",
    pathname: "",
    protocol: "",
    search: ""
  }
};
function getDocument() {
  const doc = typeof document !== "undefined" ? document : {};
  extend(doc, ssrDocument);
  return doc;
}
var ssrWindow = {
  document: ssrDocument,
  navigator: {
    userAgent: ""
  },
  location: {
    hash: "",
    host: "",
    hostname: "",
    href: "",
    origin: "",
    pathname: "",
    protocol: "",
    search: ""
  },
  history: {
    replaceState() {},
    pushState() {},
    go() {},
    back() {}
  },
  CustomEvent: function CustomEvent() {
    return this;
  },
  addEventListener() {},
  removeEventListener() {},
  getComputedStyle() {
    return {
      getPropertyValue() {
        return "";
      }
    };
  },
  Image() {},
  Date() {},
  screen: {},
  setTimeout() {},
  clearTimeout() {},
  matchMedia() {
    return {};
  },
  requestAnimationFrame(callback) {
    if (typeof setTimeout === "undefined") {
      callback();
      return null;
    }
    return setTimeout(callback, 0);
  },
  cancelAnimationFrame(id) {
    if (typeof setTimeout === "undefined") {
      return;
    }
    clearTimeout(id);
  }
};
function getWindow() {
  const win = typeof window !== "undefined" ? window : {};
  extend(win, ssrWindow);
  return win;
}

// node_modules/swiper/shared/utils.mjs
function classesToTokens(classes2) {
  if (classes2 === void 0) {
    classes2 = "";
  }
  return classes2.trim().split(" ").filter(c => !!c.trim());
}
function deleteProps(obj) {
  const object = obj;
  Object.keys(object).forEach(key => {
    try {
      object[key] = null;
    } catch (e) {}
    try {
      delete object[key];
    } catch (e) {}
  });
}
function nextTick(callback, delay) {
  if (delay === void 0) {
    delay = 0;
  }
  return setTimeout(callback, delay);
}
function now() {
  return Date.now();
}
function getComputedStyle2(el) {
  const window2 = getWindow();
  let style;
  if (window2.getComputedStyle) {
    style = window2.getComputedStyle(el, null);
  }
  if (!style && el.currentStyle) {
    style = el.currentStyle;
  }
  if (!style) {
    style = el.style;
  }
  return style;
}
function getTranslate(el, axis) {
  if (axis === void 0) {
    axis = "x";
  }
  const window2 = getWindow();
  let matrix;
  let curTransform;
  let transformMatrix;
  const curStyle = getComputedStyle2(el);
  if (window2.WebKitCSSMatrix) {
    curTransform = curStyle.transform || curStyle.webkitTransform;
    if (curTransform.split(",").length > 6) {
      curTransform = curTransform.split(", ").map(a => a.replace(",", ".")).join(", ");
    }
    transformMatrix = new window2.WebKitCSSMatrix(curTransform === "none" ? "" : curTransform);
  } else {
    transformMatrix = curStyle.MozTransform || curStyle.OTransform || curStyle.MsTransform || curStyle.msTransform || curStyle.transform || curStyle.getPropertyValue("transform").replace("translate(", "matrix(1, 0, 0, 1,");
    matrix = transformMatrix.toString().split(",");
  }
  if (axis === "x") {
    if (window2.WebKitCSSMatrix) curTransform = transformMatrix.m41;else if (matrix.length === 16) curTransform = parseFloat(matrix[12]);else curTransform = parseFloat(matrix[4]);
  }
  if (axis === "y") {
    if (window2.WebKitCSSMatrix) curTransform = transformMatrix.m42;else if (matrix.length === 16) curTransform = parseFloat(matrix[13]);else curTransform = parseFloat(matrix[5]);
  }
  return curTransform || 0;
}
function isObject2(o) {
  return typeof o === "object" && o !== null && o.constructor && Object.prototype.toString.call(o).slice(8, -1) === "Object";
}
function isNode(node) {
  if (typeof window !== "undefined" && typeof window.HTMLElement !== "undefined") {
    return node instanceof HTMLElement;
  }
  return node && (node.nodeType === 1 || node.nodeType === 11);
}
function extend2() {
  const to = Object(arguments.length <= 0 ? void 0 : arguments[0]);
  const noExtend = ["__proto__", "constructor", "prototype"];
  for (let i = 1; i < arguments.length; i += 1) {
    const nextSource = i < 0 || arguments.length <= i ? void 0 : arguments[i];
    if (nextSource !== void 0 && nextSource !== null && !isNode(nextSource)) {
      const keysArray = Object.keys(Object(nextSource)).filter(key => noExtend.indexOf(key) < 0);
      for (let nextIndex = 0, len = keysArray.length; nextIndex < len; nextIndex += 1) {
        const nextKey = keysArray[nextIndex];
        const desc = Object.getOwnPropertyDescriptor(nextSource, nextKey);
        if (desc !== void 0 && desc.enumerable) {
          if (isObject2(to[nextKey]) && isObject2(nextSource[nextKey])) {
            if (nextSource[nextKey].__swiper__) {
              to[nextKey] = nextSource[nextKey];
            } else {
              extend2(to[nextKey], nextSource[nextKey]);
            }
          } else if (!isObject2(to[nextKey]) && isObject2(nextSource[nextKey])) {
            to[nextKey] = {};
            if (nextSource[nextKey].__swiper__) {
              to[nextKey] = nextSource[nextKey];
            } else {
              extend2(to[nextKey], nextSource[nextKey]);
            }
          } else {
            to[nextKey] = nextSource[nextKey];
          }
        }
      }
    }
  }
  return to;
}
function setCSSProperty(el, varName, varValue) {
  el.style.setProperty(varName, varValue);
}
function animateCSSModeScroll(_ref) {
  let {
    swiper,
    targetPosition,
    side
  } = _ref;
  const window2 = getWindow();
  const startPosition = -swiper.translate;
  let startTime = null;
  let time;
  const duration = swiper.params.speed;
  swiper.wrapperEl.style.scrollSnapType = "none";
  window2.cancelAnimationFrame(swiper.cssModeFrameID);
  const dir = targetPosition > startPosition ? "next" : "prev";
  const isOutOfBound = (current, target) => {
    return dir === "next" && current >= target || dir === "prev" && current <= target;
  };
  const animate = () => {
    time = new Date().getTime();
    if (startTime === null) {
      startTime = time;
    }
    const progress = Math.max(Math.min((time - startTime) / duration, 1), 0);
    const easeProgress = 0.5 - Math.cos(progress * Math.PI) / 2;
    let currentPosition = startPosition + easeProgress * (targetPosition - startPosition);
    if (isOutOfBound(currentPosition, targetPosition)) {
      currentPosition = targetPosition;
    }
    swiper.wrapperEl.scrollTo({
      [side]: currentPosition
    });
    if (isOutOfBound(currentPosition, targetPosition)) {
      swiper.wrapperEl.style.overflow = "hidden";
      swiper.wrapperEl.style.scrollSnapType = "";
      setTimeout(() => {
        swiper.wrapperEl.style.overflow = "";
        swiper.wrapperEl.scrollTo({
          [side]: currentPosition
        });
      });
      window2.cancelAnimationFrame(swiper.cssModeFrameID);
      return;
    }
    swiper.cssModeFrameID = window2.requestAnimationFrame(animate);
  };
  animate();
}
function getSlideTransformEl(slideEl) {
  return slideEl.querySelector(".swiper-slide-transform") || slideEl.shadowRoot && slideEl.shadowRoot.querySelector(".swiper-slide-transform") || slideEl;
}
function elementChildren(element, selector) {
  if (selector === void 0) {
    selector = "";
  }
  return [...element.children].filter(el => el.matches(selector));
}
function showWarning(text) {
  try {
    console.warn(text);
    return;
  } catch (err) {}
}
function createElement(tag, classes2) {
  if (classes2 === void 0) {
    classes2 = [];
  }
  const el = document.createElement(tag);
  el.classList.add(...(Array.isArray(classes2) ? classes2 : classesToTokens(classes2)));
  return el;
}
function elementOffset(el) {
  const window2 = getWindow();
  const document2 = getDocument();
  const box = el.getBoundingClientRect();
  const body = document2.body;
  const clientTop = el.clientTop || body.clientTop || 0;
  const clientLeft = el.clientLeft || body.clientLeft || 0;
  const scrollTop = el === window2 ? window2.scrollY : el.scrollTop;
  const scrollLeft = el === window2 ? window2.scrollX : el.scrollLeft;
  return {
    top: box.top + scrollTop - clientTop,
    left: box.left + scrollLeft - clientLeft
  };
}
function elementPrevAll(el, selector) {
  const prevEls = [];
  while (el.previousElementSibling) {
    const prev = el.previousElementSibling;
    if (selector) {
      if (prev.matches(selector)) prevEls.push(prev);
    } else prevEls.push(prev);
    el = prev;
  }
  return prevEls;
}
function elementNextAll(el, selector) {
  const nextEls = [];
  while (el.nextElementSibling) {
    const next = el.nextElementSibling;
    if (selector) {
      if (next.matches(selector)) nextEls.push(next);
    } else nextEls.push(next);
    el = next;
  }
  return nextEls;
}
function elementStyle(el, prop) {
  const window2 = getWindow();
  return window2.getComputedStyle(el, null).getPropertyValue(prop);
}
function elementIndex(el) {
  let child = el;
  let i;
  if (child) {
    i = 0;
    while ((child = child.previousSibling) !== null) {
      if (child.nodeType === 1) i += 1;
    }
    return i;
  }
  return void 0;
}
function elementParents(el, selector) {
  const parents = [];
  let parent = el.parentElement;
  while (parent) {
    if (selector) {
      if (parent.matches(selector)) parents.push(parent);
    } else {
      parents.push(parent);
    }
    parent = parent.parentElement;
  }
  return parents;
}
function elementTransitionEnd(el, callback) {
  function fireCallBack(e) {
    if (e.target !== el) return;
    callback.call(el, e);
    el.removeEventListener("transitionend", fireCallBack);
  }
  if (callback) {
    el.addEventListener("transitionend", fireCallBack);
  }
}
function elementOuterSize(el, size, includeMargins) {
  const window2 = getWindow();
  if (includeMargins) {
    return el[size === "width" ? "offsetWidth" : "offsetHeight"] + parseFloat(window2.getComputedStyle(el, null).getPropertyValue(size === "width" ? "margin-right" : "margin-top")) + parseFloat(window2.getComputedStyle(el, null).getPropertyValue(size === "width" ? "margin-left" : "margin-bottom"));
  }
  return el.offsetWidth;
}
function makeElementsArray(el) {
  return (Array.isArray(el) ? el : [el]).filter(e => !!e);
}

// node_modules/swiper/shared/swiper-core.mjs
var support;
function calcSupport() {
  const window2 = getWindow();
  const document2 = getDocument();
  return {
    smoothScroll: document2.documentElement && document2.documentElement.style && "scrollBehavior" in document2.documentElement.style,
    touch: !!("ontouchstart" in window2 || window2.DocumentTouch && document2 instanceof window2.DocumentTouch)
  };
}
function getSupport() {
  if (!support) {
    support = calcSupport();
  }
  return support;
}
var deviceCached;
function calcDevice(_temp) {
  let {
    userAgent
  } = _temp === void 0 ? {} : _temp;
  const support2 = getSupport();
  const window2 = getWindow();
  const platform = window2.navigator.platform;
  const ua = userAgent || window2.navigator.userAgent;
  const device = {
    ios: false,
    android: false
  };
  const screenWidth = window2.screen.width;
  const screenHeight = window2.screen.height;
  const android = ua.match(/(Android);?[\s\/]+([\d.]+)?/);
  let ipad = ua.match(/(iPad).*OS\s([\d_]+)/);
  const ipod = ua.match(/(iPod)(.*OS\s([\d_]+))?/);
  const iphone = !ipad && ua.match(/(iPhone\sOS|iOS)\s([\d_]+)/);
  const windows = platform === "Win32";
  let macos = platform === "MacIntel";
  const iPadScreens = ["1024x1366", "1366x1024", "834x1194", "1194x834", "834x1112", "1112x834", "768x1024", "1024x768", "820x1180", "1180x820", "810x1080", "1080x810"];
  if (!ipad && macos && support2.touch && iPadScreens.indexOf(`${screenWidth}x${screenHeight}`) >= 0) {
    ipad = ua.match(/(Version)\/([\d.]+)/);
    if (!ipad) ipad = [0, 1, "13_0_0"];
    macos = false;
  }
  if (android && !windows) {
    device.os = "android";
    device.android = true;
  }
  if (ipad || iphone || ipod) {
    device.os = "ios";
    device.ios = true;
  }
  return device;
}
function getDevice(overrides) {
  if (overrides === void 0) {
    overrides = {};
  }
  if (!deviceCached) {
    deviceCached = calcDevice(overrides);
  }
  return deviceCached;
}
var browser;
function calcBrowser() {
  const window2 = getWindow();
  const device = getDevice();
  let needPerspectiveFix = false;
  function isSafari() {
    const ua = window2.navigator.userAgent.toLowerCase();
    return ua.indexOf("safari") >= 0 && ua.indexOf("chrome") < 0 && ua.indexOf("android") < 0;
  }
  if (isSafari()) {
    const ua = String(window2.navigator.userAgent);
    if (ua.includes("Version/")) {
      const [major, minor] = ua.split("Version/")[1].split(" ")[0].split(".").map(num => Number(num));
      needPerspectiveFix = major < 16 || major === 16 && minor < 2;
    }
  }
  const isWebView = /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(window2.navigator.userAgent);
  const isSafariBrowser = isSafari();
  const need3dFix = isSafariBrowser || isWebView && device.ios;
  return {
    isSafari: needPerspectiveFix || isSafariBrowser,
    needPerspectiveFix,
    need3dFix,
    isWebView
  };
}
function getBrowser() {
  if (!browser) {
    browser = calcBrowser();
  }
  return browser;
}
function Resize(_ref) {
  let {
    swiper,
    on,
    emit
  } = _ref;
  const window2 = getWindow();
  let observer = null;
  let animationFrame = null;
  const resizeHandler = () => {
    if (!swiper || swiper.destroyed || !swiper.initialized) return;
    emit("beforeResize");
    emit("resize");
  };
  const createObserver = () => {
    if (!swiper || swiper.destroyed || !swiper.initialized) return;
    observer = new ResizeObserver(entries => {
      animationFrame = window2.requestAnimationFrame(() => {
        const {
          width,
          height
        } = swiper;
        let newWidth = width;
        let newHeight = height;
        entries.forEach(_ref2 => {
          let {
            contentBoxSize,
            contentRect,
            target
          } = _ref2;
          if (target && target !== swiper.el) return;
          newWidth = contentRect ? contentRect.width : (contentBoxSize[0] || contentBoxSize).inlineSize;
          newHeight = contentRect ? contentRect.height : (contentBoxSize[0] || contentBoxSize).blockSize;
        });
        if (newWidth !== width || newHeight !== height) {
          resizeHandler();
        }
      });
    });
    observer.observe(swiper.el);
  };
  const removeObserver = () => {
    if (animationFrame) {
      window2.cancelAnimationFrame(animationFrame);
    }
    if (observer && observer.unobserve && swiper.el) {
      observer.unobserve(swiper.el);
      observer = null;
    }
  };
  const orientationChangeHandler = () => {
    if (!swiper || swiper.destroyed || !swiper.initialized) return;
    emit("orientationchange");
  };
  on("init", () => {
    if (swiper.params.resizeObserver && typeof window2.ResizeObserver !== "undefined") {
      createObserver();
      return;
    }
    window2.addEventListener("resize", resizeHandler);
    window2.addEventListener("orientationchange", orientationChangeHandler);
  });
  on("destroy", () => {
    removeObserver();
    window2.removeEventListener("resize", resizeHandler);
    window2.removeEventListener("orientationchange", orientationChangeHandler);
  });
}
function Observer(_ref) {
  let {
    swiper,
    extendParams,
    on,
    emit
  } = _ref;
  const observers = [];
  const window2 = getWindow();
  const attach = function (target, options) {
    if (options === void 0) {
      options = {};
    }
    const ObserverFunc = window2.MutationObserver || window2.WebkitMutationObserver;
    const observer = new ObserverFunc(mutations => {
      if (swiper.__preventObserver__) return;
      if (mutations.length === 1) {
        emit("observerUpdate", mutations[0]);
        return;
      }
      const observerUpdate = function observerUpdate2() {
        emit("observerUpdate", mutations[0]);
      };
      if (window2.requestAnimationFrame) {
        window2.requestAnimationFrame(observerUpdate);
      } else {
        window2.setTimeout(observerUpdate, 0);
      }
    });
    observer.observe(target, {
      attributes: typeof options.attributes === "undefined" ? true : options.attributes,
      childList: typeof options.childList === "undefined" ? true : options.childList,
      characterData: typeof options.characterData === "undefined" ? true : options.characterData
    });
    observers.push(observer);
  };
  const init = () => {
    if (!swiper.params.observer) return;
    if (swiper.params.observeParents) {
      const containerParents = elementParents(swiper.hostEl);
      for (let i = 0; i < containerParents.length; i += 1) {
        attach(containerParents[i]);
      }
    }
    attach(swiper.hostEl, {
      childList: swiper.params.observeSlideChildren
    });
    attach(swiper.wrapperEl, {
      attributes: false
    });
  };
  const destroy = () => {
    observers.forEach(observer => {
      observer.disconnect();
    });
    observers.splice(0, observers.length);
  };
  extendParams({
    observer: false,
    observeParents: false,
    observeSlideChildren: false
  });
  on("init", init);
  on("destroy", destroy);
}
var eventsEmitter = {
  on(events2, handler, priority) {
    const self = this;
    if (!self.eventsListeners || self.destroyed) return self;
    if (typeof handler !== "function") return self;
    const method = priority ? "unshift" : "push";
    events2.split(" ").forEach(event => {
      if (!self.eventsListeners[event]) self.eventsListeners[event] = [];
      self.eventsListeners[event][method](handler);
    });
    return self;
  },
  once(events2, handler, priority) {
    const self = this;
    if (!self.eventsListeners || self.destroyed) return self;
    if (typeof handler !== "function") return self;
    function onceHandler() {
      self.off(events2, onceHandler);
      if (onceHandler.__emitterProxy) {
        delete onceHandler.__emitterProxy;
      }
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      handler.apply(self, args);
    }
    onceHandler.__emitterProxy = handler;
    return self.on(events2, onceHandler, priority);
  },
  onAny(handler, priority) {
    const self = this;
    if (!self.eventsListeners || self.destroyed) return self;
    if (typeof handler !== "function") return self;
    const method = priority ? "unshift" : "push";
    if (self.eventsAnyListeners.indexOf(handler) < 0) {
      self.eventsAnyListeners[method](handler);
    }
    return self;
  },
  offAny(handler) {
    const self = this;
    if (!self.eventsListeners || self.destroyed) return self;
    if (!self.eventsAnyListeners) return self;
    const index = self.eventsAnyListeners.indexOf(handler);
    if (index >= 0) {
      self.eventsAnyListeners.splice(index, 1);
    }
    return self;
  },
  off(events2, handler) {
    const self = this;
    if (!self.eventsListeners || self.destroyed) return self;
    if (!self.eventsListeners) return self;
    events2.split(" ").forEach(event => {
      if (typeof handler === "undefined") {
        self.eventsListeners[event] = [];
      } else if (self.eventsListeners[event]) {
        self.eventsListeners[event].forEach((eventHandler, index) => {
          if (eventHandler === handler || eventHandler.__emitterProxy && eventHandler.__emitterProxy === handler) {
            self.eventsListeners[event].splice(index, 1);
          }
        });
      }
    });
    return self;
  },
  emit() {
    const self = this;
    if (!self.eventsListeners || self.destroyed) return self;
    if (!self.eventsListeners) return self;
    let events2;
    let data;
    let context;
    for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }
    if (typeof args[0] === "string" || Array.isArray(args[0])) {
      events2 = args[0];
      data = args.slice(1, args.length);
      context = self;
    } else {
      events2 = args[0].events;
      data = args[0].data;
      context = args[0].context || self;
    }
    data.unshift(context);
    const eventsArray = Array.isArray(events2) ? events2 : events2.split(" ");
    eventsArray.forEach(event => {
      if (self.eventsAnyListeners && self.eventsAnyListeners.length) {
        self.eventsAnyListeners.forEach(eventHandler => {
          eventHandler.apply(context, [event, ...data]);
        });
      }
      if (self.eventsListeners && self.eventsListeners[event]) {
        self.eventsListeners[event].forEach(eventHandler => {
          eventHandler.apply(context, data);
        });
      }
    });
    return self;
  }
};
function updateSize() {
  const swiper = this;
  let width;
  let height;
  const el = swiper.el;
  if (typeof swiper.params.width !== "undefined" && swiper.params.width !== null) {
    width = swiper.params.width;
  } else {
    width = el.clientWidth;
  }
  if (typeof swiper.params.height !== "undefined" && swiper.params.height !== null) {
    height = swiper.params.height;
  } else {
    height = el.clientHeight;
  }
  if (width === 0 && swiper.isHorizontal() || height === 0 && swiper.isVertical()) {
    return;
  }
  width = width - parseInt(elementStyle(el, "padding-left") || 0, 10) - parseInt(elementStyle(el, "padding-right") || 0, 10);
  height = height - parseInt(elementStyle(el, "padding-top") || 0, 10) - parseInt(elementStyle(el, "padding-bottom") || 0, 10);
  if (Number.isNaN(width)) width = 0;
  if (Number.isNaN(height)) height = 0;
  Object.assign(swiper, {
    width,
    height,
    size: swiper.isHorizontal() ? width : height
  });
}
function updateSlides() {
  const swiper = this;
  function getDirectionPropertyValue(node, label) {
    return parseFloat(node.getPropertyValue(swiper.getDirectionLabel(label)) || 0);
  }
  const params = swiper.params;
  const {
    wrapperEl,
    slidesEl,
    size: swiperSize,
    rtlTranslate: rtl,
    wrongRTL
  } = swiper;
  const isVirtual = swiper.virtual && params.virtual.enabled;
  const previousSlidesLength = isVirtual ? swiper.virtual.slides.length : swiper.slides.length;
  const slides = elementChildren(slidesEl, `.${swiper.params.slideClass}, swiper-slide`);
  const slidesLength = isVirtual ? swiper.virtual.slides.length : slides.length;
  let snapGrid = [];
  const slidesGrid = [];
  const slidesSizesGrid = [];
  let offsetBefore = params.slidesOffsetBefore;
  if (typeof offsetBefore === "function") {
    offsetBefore = params.slidesOffsetBefore.call(swiper);
  }
  let offsetAfter = params.slidesOffsetAfter;
  if (typeof offsetAfter === "function") {
    offsetAfter = params.slidesOffsetAfter.call(swiper);
  }
  const previousSnapGridLength = swiper.snapGrid.length;
  const previousSlidesGridLength = swiper.slidesGrid.length;
  let spaceBetween = params.spaceBetween;
  let slidePosition = -offsetBefore;
  let prevSlideSize = 0;
  let index = 0;
  if (typeof swiperSize === "undefined") {
    return;
  }
  if (typeof spaceBetween === "string" && spaceBetween.indexOf("%") >= 0) {
    spaceBetween = parseFloat(spaceBetween.replace("%", "")) / 100 * swiperSize;
  } else if (typeof spaceBetween === "string") {
    spaceBetween = parseFloat(spaceBetween);
  }
  swiper.virtualSize = -spaceBetween;
  slides.forEach(slideEl => {
    if (rtl) {
      slideEl.style.marginLeft = "";
    } else {
      slideEl.style.marginRight = "";
    }
    slideEl.style.marginBottom = "";
    slideEl.style.marginTop = "";
  });
  if (params.centeredSlides && params.cssMode) {
    setCSSProperty(wrapperEl, "--swiper-centered-offset-before", "");
    setCSSProperty(wrapperEl, "--swiper-centered-offset-after", "");
  }
  const gridEnabled = params.grid && params.grid.rows > 1 && swiper.grid;
  if (gridEnabled) {
    swiper.grid.initSlides(slides);
  } else if (swiper.grid) {
    swiper.grid.unsetSlides();
  }
  let slideSize;
  const shouldResetSlideSize = params.slidesPerView === "auto" && params.breakpoints && Object.keys(params.breakpoints).filter(key => {
    return typeof params.breakpoints[key].slidesPerView !== "undefined";
  }).length > 0;
  for (let i = 0; i < slidesLength; i += 1) {
    slideSize = 0;
    let slide2;
    if (slides[i]) slide2 = slides[i];
    if (gridEnabled) {
      swiper.grid.updateSlide(i, slide2, slides);
    }
    if (slides[i] && elementStyle(slide2, "display") === "none") continue;
    if (params.slidesPerView === "auto") {
      if (shouldResetSlideSize) {
        slides[i].style[swiper.getDirectionLabel("width")] = ``;
      }
      const slideStyles = getComputedStyle(slide2);
      const currentTransform = slide2.style.transform;
      const currentWebKitTransform = slide2.style.webkitTransform;
      if (currentTransform) {
        slide2.style.transform = "none";
      }
      if (currentWebKitTransform) {
        slide2.style.webkitTransform = "none";
      }
      if (params.roundLengths) {
        slideSize = swiper.isHorizontal() ? elementOuterSize(slide2, "width", true) : elementOuterSize(slide2, "height", true);
      } else {
        const width = getDirectionPropertyValue(slideStyles, "width");
        const paddingLeft = getDirectionPropertyValue(slideStyles, "padding-left");
        const paddingRight = getDirectionPropertyValue(slideStyles, "padding-right");
        const marginLeft = getDirectionPropertyValue(slideStyles, "margin-left");
        const marginRight = getDirectionPropertyValue(slideStyles, "margin-right");
        const boxSizing = slideStyles.getPropertyValue("box-sizing");
        if (boxSizing && boxSizing === "border-box") {
          slideSize = width + marginLeft + marginRight;
        } else {
          const {
            clientWidth,
            offsetWidth
          } = slide2;
          slideSize = width + paddingLeft + paddingRight + marginLeft + marginRight + (offsetWidth - clientWidth);
        }
      }
      if (currentTransform) {
        slide2.style.transform = currentTransform;
      }
      if (currentWebKitTransform) {
        slide2.style.webkitTransform = currentWebKitTransform;
      }
      if (params.roundLengths) slideSize = Math.floor(slideSize);
    } else {
      slideSize = (swiperSize - (params.slidesPerView - 1) * spaceBetween) / params.slidesPerView;
      if (params.roundLengths) slideSize = Math.floor(slideSize);
      if (slides[i]) {
        slides[i].style[swiper.getDirectionLabel("width")] = `${slideSize}px`;
      }
    }
    if (slides[i]) {
      slides[i].swiperSlideSize = slideSize;
    }
    slidesSizesGrid.push(slideSize);
    if (params.centeredSlides) {
      slidePosition = slidePosition + slideSize / 2 + prevSlideSize / 2 + spaceBetween;
      if (prevSlideSize === 0 && i !== 0) slidePosition = slidePosition - swiperSize / 2 - spaceBetween;
      if (i === 0) slidePosition = slidePosition - swiperSize / 2 - spaceBetween;
      if (Math.abs(slidePosition) < 1 / 1e3) slidePosition = 0;
      if (params.roundLengths) slidePosition = Math.floor(slidePosition);
      if (index % params.slidesPerGroup === 0) snapGrid.push(slidePosition);
      slidesGrid.push(slidePosition);
    } else {
      if (params.roundLengths) slidePosition = Math.floor(slidePosition);
      if ((index - Math.min(swiper.params.slidesPerGroupSkip, index)) % swiper.params.slidesPerGroup === 0) snapGrid.push(slidePosition);
      slidesGrid.push(slidePosition);
      slidePosition = slidePosition + slideSize + spaceBetween;
    }
    swiper.virtualSize += slideSize + spaceBetween;
    prevSlideSize = slideSize;
    index += 1;
  }
  swiper.virtualSize = Math.max(swiper.virtualSize, swiperSize) + offsetAfter;
  if (rtl && wrongRTL && (params.effect === "slide" || params.effect === "coverflow")) {
    wrapperEl.style.width = `${swiper.virtualSize + spaceBetween}px`;
  }
  if (params.setWrapperSize) {
    wrapperEl.style[swiper.getDirectionLabel("width")] = `${swiper.virtualSize + spaceBetween}px`;
  }
  if (gridEnabled) {
    swiper.grid.updateWrapperSize(slideSize, snapGrid);
  }
  if (!params.centeredSlides) {
    const newSlidesGrid = [];
    for (let i = 0; i < snapGrid.length; i += 1) {
      let slidesGridItem = snapGrid[i];
      if (params.roundLengths) slidesGridItem = Math.floor(slidesGridItem);
      if (snapGrid[i] <= swiper.virtualSize - swiperSize) {
        newSlidesGrid.push(slidesGridItem);
      }
    }
    snapGrid = newSlidesGrid;
    if (Math.floor(swiper.virtualSize - swiperSize) - Math.floor(snapGrid[snapGrid.length - 1]) > 1) {
      snapGrid.push(swiper.virtualSize - swiperSize);
    }
  }
  if (isVirtual && params.loop) {
    const size = slidesSizesGrid[0] + spaceBetween;
    if (params.slidesPerGroup > 1) {
      const groups = Math.ceil((swiper.virtual.slidesBefore + swiper.virtual.slidesAfter) / params.slidesPerGroup);
      const groupSize = size * params.slidesPerGroup;
      for (let i = 0; i < groups; i += 1) {
        snapGrid.push(snapGrid[snapGrid.length - 1] + groupSize);
      }
    }
    for (let i = 0; i < swiper.virtual.slidesBefore + swiper.virtual.slidesAfter; i += 1) {
      if (params.slidesPerGroup === 1) {
        snapGrid.push(snapGrid[snapGrid.length - 1] + size);
      }
      slidesGrid.push(slidesGrid[slidesGrid.length - 1] + size);
      swiper.virtualSize += size;
    }
  }
  if (snapGrid.length === 0) snapGrid = [0];
  if (spaceBetween !== 0) {
    const key = swiper.isHorizontal() && rtl ? "marginLeft" : swiper.getDirectionLabel("marginRight");
    slides.filter((_, slideIndex) => {
      if (!params.cssMode || params.loop) return true;
      if (slideIndex === slides.length - 1) {
        return false;
      }
      return true;
    }).forEach(slideEl => {
      slideEl.style[key] = `${spaceBetween}px`;
    });
  }
  if (params.centeredSlides && params.centeredSlidesBounds) {
    let allSlidesSize = 0;
    slidesSizesGrid.forEach(slideSizeValue => {
      allSlidesSize += slideSizeValue + (spaceBetween || 0);
    });
    allSlidesSize -= spaceBetween;
    const maxSnap = allSlidesSize - swiperSize;
    snapGrid = snapGrid.map(snap => {
      if (snap <= 0) return -offsetBefore;
      if (snap > maxSnap) return maxSnap + offsetAfter;
      return snap;
    });
  }
  if (params.centerInsufficientSlides) {
    let allSlidesSize = 0;
    slidesSizesGrid.forEach(slideSizeValue => {
      allSlidesSize += slideSizeValue + (spaceBetween || 0);
    });
    allSlidesSize -= spaceBetween;
    const offsetSize = (params.slidesOffsetBefore || 0) + (params.slidesOffsetAfter || 0);
    if (allSlidesSize + offsetSize < swiperSize) {
      const allSlidesOffset = (swiperSize - allSlidesSize - offsetSize) / 2;
      snapGrid.forEach((snap, snapIndex) => {
        snapGrid[snapIndex] = snap - allSlidesOffset;
      });
      slidesGrid.forEach((snap, snapIndex) => {
        slidesGrid[snapIndex] = snap + allSlidesOffset;
      });
    }
  }
  Object.assign(swiper, {
    slides,
    snapGrid,
    slidesGrid,
    slidesSizesGrid
  });
  if (params.centeredSlides && params.cssMode && !params.centeredSlidesBounds) {
    setCSSProperty(wrapperEl, "--swiper-centered-offset-before", `${-snapGrid[0]}px`);
    setCSSProperty(wrapperEl, "--swiper-centered-offset-after", `${swiper.size / 2 - slidesSizesGrid[slidesSizesGrid.length - 1] / 2}px`);
    const addToSnapGrid = -swiper.snapGrid[0];
    const addToSlidesGrid = -swiper.slidesGrid[0];
    swiper.snapGrid = swiper.snapGrid.map(v => v + addToSnapGrid);
    swiper.slidesGrid = swiper.slidesGrid.map(v => v + addToSlidesGrid);
  }
  if (slidesLength !== previousSlidesLength) {
    swiper.emit("slidesLengthChange");
  }
  if (snapGrid.length !== previousSnapGridLength) {
    if (swiper.params.watchOverflow) swiper.checkOverflow();
    swiper.emit("snapGridLengthChange");
  }
  if (slidesGrid.length !== previousSlidesGridLength) {
    swiper.emit("slidesGridLengthChange");
  }
  if (params.watchSlidesProgress) {
    swiper.updateSlidesOffset();
  }
  swiper.emit("slidesUpdated");
  if (!isVirtual && !params.cssMode && (params.effect === "slide" || params.effect === "fade")) {
    const backFaceHiddenClass = `${params.containerModifierClass}backface-hidden`;
    const hasClassBackfaceClassAdded = swiper.el.classList.contains(backFaceHiddenClass);
    if (slidesLength <= params.maxBackfaceHiddenSlides) {
      if (!hasClassBackfaceClassAdded) swiper.el.classList.add(backFaceHiddenClass);
    } else if (hasClassBackfaceClassAdded) {
      swiper.el.classList.remove(backFaceHiddenClass);
    }
  }
}
function updateAutoHeight(speed) {
  const swiper = this;
  const activeSlides = [];
  const isVirtual = swiper.virtual && swiper.params.virtual.enabled;
  let newHeight = 0;
  let i;
  if (typeof speed === "number") {
    swiper.setTransition(speed);
  } else if (speed === true) {
    swiper.setTransition(swiper.params.speed);
  }
  const getSlideByIndex = index => {
    if (isVirtual) {
      return swiper.slides[swiper.getSlideIndexByData(index)];
    }
    return swiper.slides[index];
  };
  if (swiper.params.slidesPerView !== "auto" && swiper.params.slidesPerView > 1) {
    if (swiper.params.centeredSlides) {
      (swiper.visibleSlides || []).forEach(slide2 => {
        activeSlides.push(slide2);
      });
    } else {
      for (i = 0; i < Math.ceil(swiper.params.slidesPerView); i += 1) {
        const index = swiper.activeIndex + i;
        if (index > swiper.slides.length && !isVirtual) break;
        activeSlides.push(getSlideByIndex(index));
      }
    }
  } else {
    activeSlides.push(getSlideByIndex(swiper.activeIndex));
  }
  for (i = 0; i < activeSlides.length; i += 1) {
    if (typeof activeSlides[i] !== "undefined") {
      const height = activeSlides[i].offsetHeight;
      newHeight = height > newHeight ? height : newHeight;
    }
  }
  if (newHeight || newHeight === 0) swiper.wrapperEl.style.height = `${newHeight}px`;
}
function updateSlidesOffset() {
  const swiper = this;
  const slides = swiper.slides;
  const minusOffset = swiper.isElement ? swiper.isHorizontal() ? swiper.wrapperEl.offsetLeft : swiper.wrapperEl.offsetTop : 0;
  for (let i = 0; i < slides.length; i += 1) {
    slides[i].swiperSlideOffset = (swiper.isHorizontal() ? slides[i].offsetLeft : slides[i].offsetTop) - minusOffset - swiper.cssOverflowAdjustment();
  }
}
var toggleSlideClasses$1 = (slideEl, condition, className) => {
  if (condition && !slideEl.classList.contains(className)) {
    slideEl.classList.add(className);
  } else if (!condition && slideEl.classList.contains(className)) {
    slideEl.classList.remove(className);
  }
};
function updateSlidesProgress(translate2) {
  if (translate2 === void 0) {
    translate2 = this && this.translate || 0;
  }
  const swiper = this;
  const params = swiper.params;
  const {
    slides,
    rtlTranslate: rtl,
    snapGrid
  } = swiper;
  if (slides.length === 0) return;
  if (typeof slides[0].swiperSlideOffset === "undefined") swiper.updateSlidesOffset();
  let offsetCenter = -translate2;
  if (rtl) offsetCenter = translate2;
  swiper.visibleSlidesIndexes = [];
  swiper.visibleSlides = [];
  let spaceBetween = params.spaceBetween;
  if (typeof spaceBetween === "string" && spaceBetween.indexOf("%") >= 0) {
    spaceBetween = parseFloat(spaceBetween.replace("%", "")) / 100 * swiper.size;
  } else if (typeof spaceBetween === "string") {
    spaceBetween = parseFloat(spaceBetween);
  }
  for (let i = 0; i < slides.length; i += 1) {
    const slide2 = slides[i];
    let slideOffset = slide2.swiperSlideOffset;
    if (params.cssMode && params.centeredSlides) {
      slideOffset -= slides[0].swiperSlideOffset;
    }
    const slideProgress = (offsetCenter + (params.centeredSlides ? swiper.minTranslate() : 0) - slideOffset) / (slide2.swiperSlideSize + spaceBetween);
    const originalSlideProgress = (offsetCenter - snapGrid[0] + (params.centeredSlides ? swiper.minTranslate() : 0) - slideOffset) / (slide2.swiperSlideSize + spaceBetween);
    const slideBefore = -(offsetCenter - slideOffset);
    const slideAfter = slideBefore + swiper.slidesSizesGrid[i];
    const isFullyVisible = slideBefore >= 0 && slideBefore <= swiper.size - swiper.slidesSizesGrid[i];
    const isVisible = slideBefore >= 0 && slideBefore < swiper.size - 1 || slideAfter > 1 && slideAfter <= swiper.size || slideBefore <= 0 && slideAfter >= swiper.size;
    if (isVisible) {
      swiper.visibleSlides.push(slide2);
      swiper.visibleSlidesIndexes.push(i);
    }
    toggleSlideClasses$1(slide2, isVisible, params.slideVisibleClass);
    toggleSlideClasses$1(slide2, isFullyVisible, params.slideFullyVisibleClass);
    slide2.progress = rtl ? -slideProgress : slideProgress;
    slide2.originalProgress = rtl ? -originalSlideProgress : originalSlideProgress;
  }
}
function updateProgress(translate2) {
  const swiper = this;
  if (typeof translate2 === "undefined") {
    const multiplier = swiper.rtlTranslate ? -1 : 1;
    translate2 = swiper && swiper.translate && swiper.translate * multiplier || 0;
  }
  const params = swiper.params;
  const translatesDiff = swiper.maxTranslate() - swiper.minTranslate();
  let {
    progress,
    isBeginning,
    isEnd,
    progressLoop
  } = swiper;
  const wasBeginning = isBeginning;
  const wasEnd = isEnd;
  if (translatesDiff === 0) {
    progress = 0;
    isBeginning = true;
    isEnd = true;
  } else {
    progress = (translate2 - swiper.minTranslate()) / translatesDiff;
    const isBeginningRounded = Math.abs(translate2 - swiper.minTranslate()) < 1;
    const isEndRounded = Math.abs(translate2 - swiper.maxTranslate()) < 1;
    isBeginning = isBeginningRounded || progress <= 0;
    isEnd = isEndRounded || progress >= 1;
    if (isBeginningRounded) progress = 0;
    if (isEndRounded) progress = 1;
  }
  if (params.loop) {
    const firstSlideIndex = swiper.getSlideIndexByData(0);
    const lastSlideIndex = swiper.getSlideIndexByData(swiper.slides.length - 1);
    const firstSlideTranslate = swiper.slidesGrid[firstSlideIndex];
    const lastSlideTranslate = swiper.slidesGrid[lastSlideIndex];
    const translateMax = swiper.slidesGrid[swiper.slidesGrid.length - 1];
    const translateAbs = Math.abs(translate2);
    if (translateAbs >= firstSlideTranslate) {
      progressLoop = (translateAbs - firstSlideTranslate) / translateMax;
    } else {
      progressLoop = (translateAbs + translateMax - lastSlideTranslate) / translateMax;
    }
    if (progressLoop > 1) progressLoop -= 1;
  }
  Object.assign(swiper, {
    progress,
    progressLoop,
    isBeginning,
    isEnd
  });
  if (params.watchSlidesProgress || params.centeredSlides && params.autoHeight) swiper.updateSlidesProgress(translate2);
  if (isBeginning && !wasBeginning) {
    swiper.emit("reachBeginning toEdge");
  }
  if (isEnd && !wasEnd) {
    swiper.emit("reachEnd toEdge");
  }
  if (wasBeginning && !isBeginning || wasEnd && !isEnd) {
    swiper.emit("fromEdge");
  }
  swiper.emit("progress", progress);
}
var toggleSlideClasses = (slideEl, condition, className) => {
  if (condition && !slideEl.classList.contains(className)) {
    slideEl.classList.add(className);
  } else if (!condition && slideEl.classList.contains(className)) {
    slideEl.classList.remove(className);
  }
};
function updateSlidesClasses() {
  const swiper = this;
  const {
    slides,
    params,
    slidesEl,
    activeIndex
  } = swiper;
  const isVirtual = swiper.virtual && params.virtual.enabled;
  const gridEnabled = swiper.grid && params.grid && params.grid.rows > 1;
  const getFilteredSlide = selector => {
    return elementChildren(slidesEl, `.${params.slideClass}${selector}, swiper-slide${selector}`)[0];
  };
  let activeSlide;
  let prevSlide;
  let nextSlide;
  if (isVirtual) {
    if (params.loop) {
      let slideIndex = activeIndex - swiper.virtual.slidesBefore;
      if (slideIndex < 0) slideIndex = swiper.virtual.slides.length + slideIndex;
      if (slideIndex >= swiper.virtual.slides.length) slideIndex -= swiper.virtual.slides.length;
      activeSlide = getFilteredSlide(`[data-swiper-slide-index="${slideIndex}"]`);
    } else {
      activeSlide = getFilteredSlide(`[data-swiper-slide-index="${activeIndex}"]`);
    }
  } else {
    if (gridEnabled) {
      activeSlide = slides.filter(slideEl => slideEl.column === activeIndex)[0];
      nextSlide = slides.filter(slideEl => slideEl.column === activeIndex + 1)[0];
      prevSlide = slides.filter(slideEl => slideEl.column === activeIndex - 1)[0];
    } else {
      activeSlide = slides[activeIndex];
    }
  }
  if (activeSlide) {
    if (!gridEnabled) {
      nextSlide = elementNextAll(activeSlide, `.${params.slideClass}, swiper-slide`)[0];
      if (params.loop && !nextSlide) {
        nextSlide = slides[0];
      }
      prevSlide = elementPrevAll(activeSlide, `.${params.slideClass}, swiper-slide`)[0];
      if (params.loop && !prevSlide === 0) {
        prevSlide = slides[slides.length - 1];
      }
    }
  }
  slides.forEach(slideEl => {
    toggleSlideClasses(slideEl, slideEl === activeSlide, params.slideActiveClass);
    toggleSlideClasses(slideEl, slideEl === nextSlide, params.slideNextClass);
    toggleSlideClasses(slideEl, slideEl === prevSlide, params.slidePrevClass);
  });
  swiper.emitSlidesClasses();
}
var processLazyPreloader = (swiper, imageEl) => {
  if (!swiper || swiper.destroyed || !swiper.params) return;
  const slideSelector = () => swiper.isElement ? `swiper-slide` : `.${swiper.params.slideClass}`;
  const slideEl = imageEl.closest(slideSelector());
  if (slideEl) {
    let lazyEl = slideEl.querySelector(`.${swiper.params.lazyPreloaderClass}`);
    if (!lazyEl && swiper.isElement) {
      if (slideEl.shadowRoot) {
        lazyEl = slideEl.shadowRoot.querySelector(`.${swiper.params.lazyPreloaderClass}`);
      } else {
        requestAnimationFrame(() => {
          if (slideEl.shadowRoot) {
            lazyEl = slideEl.shadowRoot.querySelector(`.${swiper.params.lazyPreloaderClass}`);
            if (lazyEl) lazyEl.remove();
          }
        });
      }
    }
    if (lazyEl) lazyEl.remove();
  }
};
var unlazy = (swiper, index) => {
  if (!swiper.slides[index]) return;
  const imageEl = swiper.slides[index].querySelector('[loading="lazy"]');
  if (imageEl) imageEl.removeAttribute("loading");
};
var preload = swiper => {
  if (!swiper || swiper.destroyed || !swiper.params) return;
  let amount = swiper.params.lazyPreloadPrevNext;
  const len = swiper.slides.length;
  if (!len || !amount || amount < 0) return;
  amount = Math.min(amount, len);
  const slidesPerView = swiper.params.slidesPerView === "auto" ? swiper.slidesPerViewDynamic() : Math.ceil(swiper.params.slidesPerView);
  const activeIndex = swiper.activeIndex;
  if (swiper.params.grid && swiper.params.grid.rows > 1) {
    const activeColumn = activeIndex;
    const preloadColumns = [activeColumn - amount];
    preloadColumns.push(...Array.from({
      length: amount
    }).map((_, i) => {
      return activeColumn + slidesPerView + i;
    }));
    swiper.slides.forEach((slideEl, i) => {
      if (preloadColumns.includes(slideEl.column)) unlazy(swiper, i);
    });
    return;
  }
  const slideIndexLastInView = activeIndex + slidesPerView - 1;
  if (swiper.params.rewind || swiper.params.loop) {
    for (let i = activeIndex - amount; i <= slideIndexLastInView + amount; i += 1) {
      const realIndex = (i % len + len) % len;
      if (realIndex < activeIndex || realIndex > slideIndexLastInView) unlazy(swiper, realIndex);
    }
  } else {
    for (let i = Math.max(activeIndex - amount, 0); i <= Math.min(slideIndexLastInView + amount, len - 1); i += 1) {
      if (i !== activeIndex && (i > slideIndexLastInView || i < activeIndex)) {
        unlazy(swiper, i);
      }
    }
  }
};
function getActiveIndexByTranslate(swiper) {
  const {
    slidesGrid,
    params
  } = swiper;
  const translate2 = swiper.rtlTranslate ? swiper.translate : -swiper.translate;
  let activeIndex;
  for (let i = 0; i < slidesGrid.length; i += 1) {
    if (typeof slidesGrid[i + 1] !== "undefined") {
      if (translate2 >= slidesGrid[i] && translate2 < slidesGrid[i + 1] - (slidesGrid[i + 1] - slidesGrid[i]) / 2) {
        activeIndex = i;
      } else if (translate2 >= slidesGrid[i] && translate2 < slidesGrid[i + 1]) {
        activeIndex = i + 1;
      }
    } else if (translate2 >= slidesGrid[i]) {
      activeIndex = i;
    }
  }
  if (params.normalizeSlideIndex) {
    if (activeIndex < 0 || typeof activeIndex === "undefined") activeIndex = 0;
  }
  return activeIndex;
}
function updateActiveIndex(newActiveIndex) {
  const swiper = this;
  const translate2 = swiper.rtlTranslate ? swiper.translate : -swiper.translate;
  const {
    snapGrid,
    params,
    activeIndex: previousIndex,
    realIndex: previousRealIndex,
    snapIndex: previousSnapIndex
  } = swiper;
  let activeIndex = newActiveIndex;
  let snapIndex;
  const getVirtualRealIndex = aIndex => {
    let realIndex2 = aIndex - swiper.virtual.slidesBefore;
    if (realIndex2 < 0) {
      realIndex2 = swiper.virtual.slides.length + realIndex2;
    }
    if (realIndex2 >= swiper.virtual.slides.length) {
      realIndex2 -= swiper.virtual.slides.length;
    }
    return realIndex2;
  };
  if (typeof activeIndex === "undefined") {
    activeIndex = getActiveIndexByTranslate(swiper);
  }
  if (snapGrid.indexOf(translate2) >= 0) {
    snapIndex = snapGrid.indexOf(translate2);
  } else {
    const skip = Math.min(params.slidesPerGroupSkip, activeIndex);
    snapIndex = skip + Math.floor((activeIndex - skip) / params.slidesPerGroup);
  }
  if (snapIndex >= snapGrid.length) snapIndex = snapGrid.length - 1;
  if (activeIndex === previousIndex && !swiper.params.loop) {
    if (snapIndex !== previousSnapIndex) {
      swiper.snapIndex = snapIndex;
      swiper.emit("snapIndexChange");
    }
    return;
  }
  if (activeIndex === previousIndex && swiper.params.loop && swiper.virtual && swiper.params.virtual.enabled) {
    swiper.realIndex = getVirtualRealIndex(activeIndex);
    return;
  }
  const gridEnabled = swiper.grid && params.grid && params.grid.rows > 1;
  let realIndex;
  if (swiper.virtual && params.virtual.enabled && params.loop) {
    realIndex = getVirtualRealIndex(activeIndex);
  } else if (gridEnabled) {
    const firstSlideInColumn = swiper.slides.filter(slideEl => slideEl.column === activeIndex)[0];
    let activeSlideIndex = parseInt(firstSlideInColumn.getAttribute("data-swiper-slide-index"), 10);
    if (Number.isNaN(activeSlideIndex)) {
      activeSlideIndex = Math.max(swiper.slides.indexOf(firstSlideInColumn), 0);
    }
    realIndex = Math.floor(activeSlideIndex / params.grid.rows);
  } else if (swiper.slides[activeIndex]) {
    const slideIndex = swiper.slides[activeIndex].getAttribute("data-swiper-slide-index");
    if (slideIndex) {
      realIndex = parseInt(slideIndex, 10);
    } else {
      realIndex = activeIndex;
    }
  } else {
    realIndex = activeIndex;
  }
  Object.assign(swiper, {
    previousSnapIndex,
    snapIndex,
    previousRealIndex,
    realIndex,
    previousIndex,
    activeIndex
  });
  if (swiper.initialized) {
    preload(swiper);
  }
  swiper.emit("activeIndexChange");
  swiper.emit("snapIndexChange");
  if (swiper.initialized || swiper.params.runCallbacksOnInit) {
    if (previousRealIndex !== realIndex) {
      swiper.emit("realIndexChange");
    }
    swiper.emit("slideChange");
  }
}
function updateClickedSlide(el, path) {
  const swiper = this;
  const params = swiper.params;
  let slide2 = el.closest(`.${params.slideClass}, swiper-slide`);
  if (!slide2 && swiper.isElement && path && path.length > 1 && path.includes(el)) {
    [...path.slice(path.indexOf(el) + 1, path.length)].forEach(pathEl => {
      if (!slide2 && pathEl.matches && pathEl.matches(`.${params.slideClass}, swiper-slide`)) {
        slide2 = pathEl;
      }
    });
  }
  let slideFound = false;
  let slideIndex;
  if (slide2) {
    for (let i = 0; i < swiper.slides.length; i += 1) {
      if (swiper.slides[i] === slide2) {
        slideFound = true;
        slideIndex = i;
        break;
      }
    }
  }
  if (slide2 && slideFound) {
    swiper.clickedSlide = slide2;
    if (swiper.virtual && swiper.params.virtual.enabled) {
      swiper.clickedIndex = parseInt(slide2.getAttribute("data-swiper-slide-index"), 10);
    } else {
      swiper.clickedIndex = slideIndex;
    }
  } else {
    swiper.clickedSlide = void 0;
    swiper.clickedIndex = void 0;
    return;
  }
  if (params.slideToClickedSlide && swiper.clickedIndex !== void 0 && swiper.clickedIndex !== swiper.activeIndex) {
    swiper.slideToClickedSlide();
  }
}
var update = {
  updateSize,
  updateSlides,
  updateAutoHeight,
  updateSlidesOffset,
  updateSlidesProgress,
  updateProgress,
  updateSlidesClasses,
  updateActiveIndex,
  updateClickedSlide
};
function getSwiperTranslate(axis) {
  if (axis === void 0) {
    axis = this.isHorizontal() ? "x" : "y";
  }
  const swiper = this;
  const {
    params,
    rtlTranslate: rtl,
    translate: translate2,
    wrapperEl
  } = swiper;
  if (params.virtualTranslate) {
    return rtl ? -translate2 : translate2;
  }
  if (params.cssMode) {
    return translate2;
  }
  let currentTranslate = getTranslate(wrapperEl, axis);
  currentTranslate += swiper.cssOverflowAdjustment();
  if (rtl) currentTranslate = -currentTranslate;
  return currentTranslate || 0;
}
function setTranslate(translate2, byController) {
  const swiper = this;
  const {
    rtlTranslate: rtl,
    params,
    wrapperEl,
    progress
  } = swiper;
  let x = 0;
  let y = 0;
  const z = 0;
  if (swiper.isHorizontal()) {
    x = rtl ? -translate2 : translate2;
  } else {
    y = translate2;
  }
  if (params.roundLengths) {
    x = Math.floor(x);
    y = Math.floor(y);
  }
  swiper.previousTranslate = swiper.translate;
  swiper.translate = swiper.isHorizontal() ? x : y;
  if (params.cssMode) {
    wrapperEl[swiper.isHorizontal() ? "scrollLeft" : "scrollTop"] = swiper.isHorizontal() ? -x : -y;
  } else if (!params.virtualTranslate) {
    if (swiper.isHorizontal()) {
      x -= swiper.cssOverflowAdjustment();
    } else {
      y -= swiper.cssOverflowAdjustment();
    }
    wrapperEl.style.transform = `translate3d(${x}px, ${y}px, ${z}px)`;
  }
  let newProgress;
  const translatesDiff = swiper.maxTranslate() - swiper.minTranslate();
  if (translatesDiff === 0) {
    newProgress = 0;
  } else {
    newProgress = (translate2 - swiper.minTranslate()) / translatesDiff;
  }
  if (newProgress !== progress) {
    swiper.updateProgress(translate2);
  }
  swiper.emit("setTranslate", swiper.translate, byController);
}
function minTranslate() {
  return -this.snapGrid[0];
}
function maxTranslate() {
  return -this.snapGrid[this.snapGrid.length - 1];
}
function translateTo(translate2, speed, runCallbacks, translateBounds, internal) {
  if (translate2 === void 0) {
    translate2 = 0;
  }
  if (speed === void 0) {
    speed = this.params.speed;
  }
  if (runCallbacks === void 0) {
    runCallbacks = true;
  }
  if (translateBounds === void 0) {
    translateBounds = true;
  }
  const swiper = this;
  const {
    params,
    wrapperEl
  } = swiper;
  if (swiper.animating && params.preventInteractionOnTransition) {
    return false;
  }
  const minTranslate2 = swiper.minTranslate();
  const maxTranslate2 = swiper.maxTranslate();
  let newTranslate;
  if (translateBounds && translate2 > minTranslate2) newTranslate = minTranslate2;else if (translateBounds && translate2 < maxTranslate2) newTranslate = maxTranslate2;else newTranslate = translate2;
  swiper.updateProgress(newTranslate);
  if (params.cssMode) {
    const isH = swiper.isHorizontal();
    if (speed === 0) {
      wrapperEl[isH ? "scrollLeft" : "scrollTop"] = -newTranslate;
    } else {
      if (!swiper.support.smoothScroll) {
        animateCSSModeScroll({
          swiper,
          targetPosition: -newTranslate,
          side: isH ? "left" : "top"
        });
        return true;
      }
      wrapperEl.scrollTo({
        [isH ? "left" : "top"]: -newTranslate,
        behavior: "smooth"
      });
    }
    return true;
  }
  if (speed === 0) {
    swiper.setTransition(0);
    swiper.setTranslate(newTranslate);
    if (runCallbacks) {
      swiper.emit("beforeTransitionStart", speed, internal);
      swiper.emit("transitionEnd");
    }
  } else {
    swiper.setTransition(speed);
    swiper.setTranslate(newTranslate);
    if (runCallbacks) {
      swiper.emit("beforeTransitionStart", speed, internal);
      swiper.emit("transitionStart");
    }
    if (!swiper.animating) {
      swiper.animating = true;
      if (!swiper.onTranslateToWrapperTransitionEnd) {
        swiper.onTranslateToWrapperTransitionEnd = function transitionEnd2(e) {
          if (!swiper || swiper.destroyed) return;
          if (e.target !== this) return;
          swiper.wrapperEl.removeEventListener("transitionend", swiper.onTranslateToWrapperTransitionEnd);
          swiper.onTranslateToWrapperTransitionEnd = null;
          delete swiper.onTranslateToWrapperTransitionEnd;
          swiper.animating = false;
          if (runCallbacks) {
            swiper.emit("transitionEnd");
          }
        };
      }
      swiper.wrapperEl.addEventListener("transitionend", swiper.onTranslateToWrapperTransitionEnd);
    }
  }
  return true;
}
var translate = {
  getTranslate: getSwiperTranslate,
  setTranslate,
  minTranslate,
  maxTranslate,
  translateTo
};
function setTransition(duration, byController) {
  const swiper = this;
  if (!swiper.params.cssMode) {
    swiper.wrapperEl.style.transitionDuration = `${duration}ms`;
    swiper.wrapperEl.style.transitionDelay = duration === 0 ? `0ms` : "";
  }
  swiper.emit("setTransition", duration, byController);
}
function transitionEmit(_ref) {
  let {
    swiper,
    runCallbacks,
    direction,
    step
  } = _ref;
  const {
    activeIndex,
    previousIndex
  } = swiper;
  let dir = direction;
  if (!dir) {
    if (activeIndex > previousIndex) dir = "next";else if (activeIndex < previousIndex) dir = "prev";else dir = "reset";
  }
  swiper.emit(`transition${step}`);
  if (runCallbacks && activeIndex !== previousIndex) {
    if (dir === "reset") {
      swiper.emit(`slideResetTransition${step}`);
      return;
    }
    swiper.emit(`slideChangeTransition${step}`);
    if (dir === "next") {
      swiper.emit(`slideNextTransition${step}`);
    } else {
      swiper.emit(`slidePrevTransition${step}`);
    }
  }
}
function transitionStart(runCallbacks, direction) {
  if (runCallbacks === void 0) {
    runCallbacks = true;
  }
  const swiper = this;
  const {
    params
  } = swiper;
  if (params.cssMode) return;
  if (params.autoHeight) {
    swiper.updateAutoHeight();
  }
  transitionEmit({
    swiper,
    runCallbacks,
    direction,
    step: "Start"
  });
}
function transitionEnd(runCallbacks, direction) {
  if (runCallbacks === void 0) {
    runCallbacks = true;
  }
  const swiper = this;
  const {
    params
  } = swiper;
  swiper.animating = false;
  if (params.cssMode) return;
  swiper.setTransition(0);
  transitionEmit({
    swiper,
    runCallbacks,
    direction,
    step: "End"
  });
}
var transition = {
  setTransition,
  transitionStart,
  transitionEnd
};
function slideTo(index, speed, runCallbacks, internal, initial) {
  if (index === void 0) {
    index = 0;
  }
  if (runCallbacks === void 0) {
    runCallbacks = true;
  }
  if (typeof index === "string") {
    index = parseInt(index, 10);
  }
  const swiper = this;
  let slideIndex = index;
  if (slideIndex < 0) slideIndex = 0;
  const {
    params,
    snapGrid,
    slidesGrid,
    previousIndex,
    activeIndex,
    rtlTranslate: rtl,
    wrapperEl,
    enabled
  } = swiper;
  if (!enabled && !internal && !initial || swiper.destroyed || swiper.animating && params.preventInteractionOnTransition) {
    return false;
  }
  if (typeof speed === "undefined") {
    speed = swiper.params.speed;
  }
  const skip = Math.min(swiper.params.slidesPerGroupSkip, slideIndex);
  let snapIndex = skip + Math.floor((slideIndex - skip) / swiper.params.slidesPerGroup);
  if (snapIndex >= snapGrid.length) snapIndex = snapGrid.length - 1;
  const translate2 = -snapGrid[snapIndex];
  if (params.normalizeSlideIndex) {
    for (let i = 0; i < slidesGrid.length; i += 1) {
      const normalizedTranslate = -Math.floor(translate2 * 100);
      const normalizedGrid = Math.floor(slidesGrid[i] * 100);
      const normalizedGridNext = Math.floor(slidesGrid[i + 1] * 100);
      if (typeof slidesGrid[i + 1] !== "undefined") {
        if (normalizedTranslate >= normalizedGrid && normalizedTranslate < normalizedGridNext - (normalizedGridNext - normalizedGrid) / 2) {
          slideIndex = i;
        } else if (normalizedTranslate >= normalizedGrid && normalizedTranslate < normalizedGridNext) {
          slideIndex = i + 1;
        }
      } else if (normalizedTranslate >= normalizedGrid) {
        slideIndex = i;
      }
    }
  }
  if (swiper.initialized && slideIndex !== activeIndex) {
    if (!swiper.allowSlideNext && (rtl ? translate2 > swiper.translate && translate2 > swiper.minTranslate() : translate2 < swiper.translate && translate2 < swiper.minTranslate())) {
      return false;
    }
    if (!swiper.allowSlidePrev && translate2 > swiper.translate && translate2 > swiper.maxTranslate()) {
      if ((activeIndex || 0) !== slideIndex) {
        return false;
      }
    }
  }
  if (slideIndex !== (previousIndex || 0) && runCallbacks) {
    swiper.emit("beforeSlideChangeStart");
  }
  swiper.updateProgress(translate2);
  let direction;
  if (slideIndex > activeIndex) direction = "next";else if (slideIndex < activeIndex) direction = "prev";else direction = "reset";
  if (rtl && -translate2 === swiper.translate || !rtl && translate2 === swiper.translate) {
    swiper.updateActiveIndex(slideIndex);
    if (params.autoHeight) {
      swiper.updateAutoHeight();
    }
    swiper.updateSlidesClasses();
    if (params.effect !== "slide") {
      swiper.setTranslate(translate2);
    }
    if (direction !== "reset") {
      swiper.transitionStart(runCallbacks, direction);
      swiper.transitionEnd(runCallbacks, direction);
    }
    return false;
  }
  if (params.cssMode) {
    const isH = swiper.isHorizontal();
    const t = rtl ? translate2 : -translate2;
    if (speed === 0) {
      const isVirtual = swiper.virtual && swiper.params.virtual.enabled;
      if (isVirtual) {
        swiper.wrapperEl.style.scrollSnapType = "none";
        swiper._immediateVirtual = true;
      }
      if (isVirtual && !swiper._cssModeVirtualInitialSet && swiper.params.initialSlide > 0) {
        swiper._cssModeVirtualInitialSet = true;
        requestAnimationFrame(() => {
          wrapperEl[isH ? "scrollLeft" : "scrollTop"] = t;
        });
      } else {
        wrapperEl[isH ? "scrollLeft" : "scrollTop"] = t;
      }
      if (isVirtual) {
        requestAnimationFrame(() => {
          swiper.wrapperEl.style.scrollSnapType = "";
          swiper._immediateVirtual = false;
        });
      }
    } else {
      if (!swiper.support.smoothScroll) {
        animateCSSModeScroll({
          swiper,
          targetPosition: t,
          side: isH ? "left" : "top"
        });
        return true;
      }
      wrapperEl.scrollTo({
        [isH ? "left" : "top"]: t,
        behavior: "smooth"
      });
    }
    return true;
  }
  swiper.setTransition(speed);
  swiper.setTranslate(translate2);
  swiper.updateActiveIndex(slideIndex);
  swiper.updateSlidesClasses();
  swiper.emit("beforeTransitionStart", speed, internal);
  swiper.transitionStart(runCallbacks, direction);
  if (speed === 0) {
    swiper.transitionEnd(runCallbacks, direction);
  } else if (!swiper.animating) {
    swiper.animating = true;
    if (!swiper.onSlideToWrapperTransitionEnd) {
      swiper.onSlideToWrapperTransitionEnd = function transitionEnd2(e) {
        if (!swiper || swiper.destroyed) return;
        if (e.target !== this) return;
        swiper.wrapperEl.removeEventListener("transitionend", swiper.onSlideToWrapperTransitionEnd);
        swiper.onSlideToWrapperTransitionEnd = null;
        delete swiper.onSlideToWrapperTransitionEnd;
        swiper.transitionEnd(runCallbacks, direction);
      };
    }
    swiper.wrapperEl.addEventListener("transitionend", swiper.onSlideToWrapperTransitionEnd);
  }
  return true;
}
function slideToLoop(index, speed, runCallbacks, internal) {
  if (index === void 0) {
    index = 0;
  }
  if (runCallbacks === void 0) {
    runCallbacks = true;
  }
  if (typeof index === "string") {
    const indexAsNumber = parseInt(index, 10);
    index = indexAsNumber;
  }
  const swiper = this;
  if (swiper.destroyed) return;
  if (typeof speed === "undefined") {
    speed = swiper.params.speed;
  }
  const gridEnabled = swiper.grid && swiper.params.grid && swiper.params.grid.rows > 1;
  let newIndex = index;
  if (swiper.params.loop) {
    if (swiper.virtual && swiper.params.virtual.enabled) {
      newIndex = newIndex + swiper.virtual.slidesBefore;
    } else {
      let targetSlideIndex;
      if (gridEnabled) {
        const slideIndex = newIndex * swiper.params.grid.rows;
        targetSlideIndex = swiper.slides.filter(slideEl => slideEl.getAttribute("data-swiper-slide-index") * 1 === slideIndex)[0].column;
      } else {
        targetSlideIndex = swiper.getSlideIndexByData(newIndex);
      }
      const cols = gridEnabled ? Math.ceil(swiper.slides.length / swiper.params.grid.rows) : swiper.slides.length;
      const {
        centeredSlides
      } = swiper.params;
      let slidesPerView = swiper.params.slidesPerView;
      if (slidesPerView === "auto") {
        slidesPerView = swiper.slidesPerViewDynamic();
      } else {
        slidesPerView = Math.ceil(parseFloat(swiper.params.slidesPerView, 10));
        if (centeredSlides && slidesPerView % 2 === 0) {
          slidesPerView = slidesPerView + 1;
        }
      }
      let needLoopFix = cols - targetSlideIndex < slidesPerView;
      if (centeredSlides) {
        needLoopFix = needLoopFix || targetSlideIndex < Math.ceil(slidesPerView / 2);
      }
      if (internal && centeredSlides && swiper.params.slidesPerView !== "auto" && !gridEnabled) {
        needLoopFix = false;
      }
      if (needLoopFix) {
        const direction = centeredSlides ? targetSlideIndex < swiper.activeIndex ? "prev" : "next" : targetSlideIndex - swiper.activeIndex - 1 < swiper.params.slidesPerView ? "next" : "prev";
        swiper.loopFix({
          direction,
          slideTo: true,
          activeSlideIndex: direction === "next" ? targetSlideIndex + 1 : targetSlideIndex - cols + 1,
          slideRealIndex: direction === "next" ? swiper.realIndex : void 0
        });
      }
      if (gridEnabled) {
        const slideIndex = newIndex * swiper.params.grid.rows;
        newIndex = swiper.slides.filter(slideEl => slideEl.getAttribute("data-swiper-slide-index") * 1 === slideIndex)[0].column;
      } else {
        newIndex = swiper.getSlideIndexByData(newIndex);
      }
    }
  }
  requestAnimationFrame(() => {
    swiper.slideTo(newIndex, speed, runCallbacks, internal);
  });
  return swiper;
}
function slideNext(speed, runCallbacks, internal) {
  if (runCallbacks === void 0) {
    runCallbacks = true;
  }
  const swiper = this;
  const {
    enabled,
    params,
    animating
  } = swiper;
  if (!enabled || swiper.destroyed) return swiper;
  if (typeof speed === "undefined") {
    speed = swiper.params.speed;
  }
  let perGroup = params.slidesPerGroup;
  if (params.slidesPerView === "auto" && params.slidesPerGroup === 1 && params.slidesPerGroupAuto) {
    perGroup = Math.max(swiper.slidesPerViewDynamic("current", true), 1);
  }
  const increment = swiper.activeIndex < params.slidesPerGroupSkip ? 1 : perGroup;
  const isVirtual = swiper.virtual && params.virtual.enabled;
  if (params.loop) {
    if (animating && !isVirtual && params.loopPreventsSliding) return false;
    swiper.loopFix({
      direction: "next"
    });
    swiper._clientLeft = swiper.wrapperEl.clientLeft;
    if (swiper.activeIndex === swiper.slides.length - 1 && params.cssMode) {
      requestAnimationFrame(() => {
        swiper.slideTo(swiper.activeIndex + increment, speed, runCallbacks, internal);
      });
      return true;
    }
  }
  if (params.rewind && swiper.isEnd) {
    return swiper.slideTo(0, speed, runCallbacks, internal);
  }
  return swiper.slideTo(swiper.activeIndex + increment, speed, runCallbacks, internal);
}
function slidePrev(speed, runCallbacks, internal) {
  if (runCallbacks === void 0) {
    runCallbacks = true;
  }
  const swiper = this;
  const {
    params,
    snapGrid,
    slidesGrid,
    rtlTranslate,
    enabled,
    animating
  } = swiper;
  if (!enabled || swiper.destroyed) return swiper;
  if (typeof speed === "undefined") {
    speed = swiper.params.speed;
  }
  const isVirtual = swiper.virtual && params.virtual.enabled;
  if (params.loop) {
    if (animating && !isVirtual && params.loopPreventsSliding) return false;
    swiper.loopFix({
      direction: "prev"
    });
    swiper._clientLeft = swiper.wrapperEl.clientLeft;
  }
  const translate2 = rtlTranslate ? swiper.translate : -swiper.translate;
  function normalize(val) {
    if (val < 0) return -Math.floor(Math.abs(val));
    return Math.floor(val);
  }
  const normalizedTranslate = normalize(translate2);
  const normalizedSnapGrid = snapGrid.map(val => normalize(val));
  let prevSnap = snapGrid[normalizedSnapGrid.indexOf(normalizedTranslate) - 1];
  if (typeof prevSnap === "undefined" && params.cssMode) {
    let prevSnapIndex;
    snapGrid.forEach((snap, snapIndex) => {
      if (normalizedTranslate >= snap) {
        prevSnapIndex = snapIndex;
      }
    });
    if (typeof prevSnapIndex !== "undefined") {
      prevSnap = snapGrid[prevSnapIndex > 0 ? prevSnapIndex - 1 : prevSnapIndex];
    }
  }
  let prevIndex = 0;
  if (typeof prevSnap !== "undefined") {
    prevIndex = slidesGrid.indexOf(prevSnap);
    if (prevIndex < 0) prevIndex = swiper.activeIndex - 1;
    if (params.slidesPerView === "auto" && params.slidesPerGroup === 1 && params.slidesPerGroupAuto) {
      prevIndex = prevIndex - swiper.slidesPerViewDynamic("previous", true) + 1;
      prevIndex = Math.max(prevIndex, 0);
    }
  }
  if (params.rewind && swiper.isBeginning) {
    const lastIndex = swiper.params.virtual && swiper.params.virtual.enabled && swiper.virtual ? swiper.virtual.slides.length - 1 : swiper.slides.length - 1;
    return swiper.slideTo(lastIndex, speed, runCallbacks, internal);
  } else if (params.loop && swiper.activeIndex === 0 && params.cssMode) {
    requestAnimationFrame(() => {
      swiper.slideTo(prevIndex, speed, runCallbacks, internal);
    });
    return true;
  }
  return swiper.slideTo(prevIndex, speed, runCallbacks, internal);
}
function slideReset(speed, runCallbacks, internal) {
  if (runCallbacks === void 0) {
    runCallbacks = true;
  }
  const swiper = this;
  if (swiper.destroyed) return;
  if (typeof speed === "undefined") {
    speed = swiper.params.speed;
  }
  return swiper.slideTo(swiper.activeIndex, speed, runCallbacks, internal);
}
function slideToClosest(speed, runCallbacks, internal, threshold) {
  if (runCallbacks === void 0) {
    runCallbacks = true;
  }
  if (threshold === void 0) {
    threshold = 0.5;
  }
  const swiper = this;
  if (swiper.destroyed) return;
  if (typeof speed === "undefined") {
    speed = swiper.params.speed;
  }
  let index = swiper.activeIndex;
  const skip = Math.min(swiper.params.slidesPerGroupSkip, index);
  const snapIndex = skip + Math.floor((index - skip) / swiper.params.slidesPerGroup);
  const translate2 = swiper.rtlTranslate ? swiper.translate : -swiper.translate;
  if (translate2 >= swiper.snapGrid[snapIndex]) {
    const currentSnap = swiper.snapGrid[snapIndex];
    const nextSnap = swiper.snapGrid[snapIndex + 1];
    if (translate2 - currentSnap > (nextSnap - currentSnap) * threshold) {
      index += swiper.params.slidesPerGroup;
    }
  } else {
    const prevSnap = swiper.snapGrid[snapIndex - 1];
    const currentSnap = swiper.snapGrid[snapIndex];
    if (translate2 - prevSnap <= (currentSnap - prevSnap) * threshold) {
      index -= swiper.params.slidesPerGroup;
    }
  }
  index = Math.max(index, 0);
  index = Math.min(index, swiper.slidesGrid.length - 1);
  return swiper.slideTo(index, speed, runCallbacks, internal);
}
function slideToClickedSlide() {
  const swiper = this;
  if (swiper.destroyed) return;
  const {
    params,
    slidesEl
  } = swiper;
  const slidesPerView = params.slidesPerView === "auto" ? swiper.slidesPerViewDynamic() : params.slidesPerView;
  let slideToIndex = swiper.clickedIndex;
  let realIndex;
  const slideSelector = swiper.isElement ? `swiper-slide` : `.${params.slideClass}`;
  if (params.loop) {
    if (swiper.animating) return;
    realIndex = parseInt(swiper.clickedSlide.getAttribute("data-swiper-slide-index"), 10);
    if (params.centeredSlides) {
      if (slideToIndex < swiper.loopedSlides - slidesPerView / 2 || slideToIndex > swiper.slides.length - swiper.loopedSlides + slidesPerView / 2) {
        swiper.loopFix();
        slideToIndex = swiper.getSlideIndex(elementChildren(slidesEl, `${slideSelector}[data-swiper-slide-index="${realIndex}"]`)[0]);
        nextTick(() => {
          swiper.slideTo(slideToIndex);
        });
      } else {
        swiper.slideTo(slideToIndex);
      }
    } else if (slideToIndex > swiper.slides.length - slidesPerView) {
      swiper.loopFix();
      slideToIndex = swiper.getSlideIndex(elementChildren(slidesEl, `${slideSelector}[data-swiper-slide-index="${realIndex}"]`)[0]);
      nextTick(() => {
        swiper.slideTo(slideToIndex);
      });
    } else {
      swiper.slideTo(slideToIndex);
    }
  } else {
    swiper.slideTo(slideToIndex);
  }
}
var slide = {
  slideTo,
  slideToLoop,
  slideNext,
  slidePrev,
  slideReset,
  slideToClosest,
  slideToClickedSlide
};
function loopCreate(slideRealIndex) {
  const swiper = this;
  const {
    params,
    slidesEl
  } = swiper;
  if (!params.loop || swiper.virtual && swiper.params.virtual.enabled) return;
  const initSlides = () => {
    const slides = elementChildren(slidesEl, `.${params.slideClass}, swiper-slide`);
    slides.forEach((el, index) => {
      el.setAttribute("data-swiper-slide-index", index);
    });
  };
  const gridEnabled = swiper.grid && params.grid && params.grid.rows > 1;
  const slidesPerGroup = params.slidesPerGroup * (gridEnabled ? params.grid.rows : 1);
  const shouldFillGroup = swiper.slides.length % slidesPerGroup !== 0;
  const shouldFillGrid = gridEnabled && swiper.slides.length % params.grid.rows !== 0;
  const addBlankSlides = amountOfSlides => {
    for (let i = 0; i < amountOfSlides; i += 1) {
      const slideEl = swiper.isElement ? createElement("swiper-slide", [params.slideBlankClass]) : createElement("div", [params.slideClass, params.slideBlankClass]);
      swiper.slidesEl.append(slideEl);
    }
  };
  if (shouldFillGroup) {
    if (params.loopAddBlankSlides) {
      const slidesToAdd = slidesPerGroup - swiper.slides.length % slidesPerGroup;
      addBlankSlides(slidesToAdd);
      swiper.recalcSlides();
      swiper.updateSlides();
    } else {
      showWarning("Swiper Loop Warning: The number of slides is not even to slidesPerGroup, loop mode may not function properly. You need to add more slides (or make duplicates, or empty slides)");
    }
    initSlides();
  } else if (shouldFillGrid) {
    if (params.loopAddBlankSlides) {
      const slidesToAdd = params.grid.rows - swiper.slides.length % params.grid.rows;
      addBlankSlides(slidesToAdd);
      swiper.recalcSlides();
      swiper.updateSlides();
    } else {
      showWarning("Swiper Loop Warning: The number of slides is not even to grid.rows, loop mode may not function properly. You need to add more slides (or make duplicates, or empty slides)");
    }
    initSlides();
  } else {
    initSlides();
  }
  swiper.loopFix({
    slideRealIndex,
    direction: params.centeredSlides ? void 0 : "next"
  });
}
function loopFix(_temp) {
  let {
    slideRealIndex,
    slideTo: slideTo2 = true,
    direction,
    setTranslate: setTranslate2,
    activeSlideIndex,
    byController,
    byMousewheel
  } = _temp === void 0 ? {} : _temp;
  const swiper = this;
  if (!swiper.params.loop) return;
  swiper.emit("beforeLoopFix");
  const {
    slides,
    allowSlidePrev,
    allowSlideNext,
    slidesEl,
    params
  } = swiper;
  const {
    centeredSlides
  } = params;
  swiper.allowSlidePrev = true;
  swiper.allowSlideNext = true;
  if (swiper.virtual && params.virtual.enabled) {
    if (slideTo2) {
      if (!params.centeredSlides && swiper.snapIndex === 0) {
        swiper.slideTo(swiper.virtual.slides.length, 0, false, true);
      } else if (params.centeredSlides && swiper.snapIndex < params.slidesPerView) {
        swiper.slideTo(swiper.virtual.slides.length + swiper.snapIndex, 0, false, true);
      } else if (swiper.snapIndex === swiper.snapGrid.length - 1) {
        swiper.slideTo(swiper.virtual.slidesBefore, 0, false, true);
      }
    }
    swiper.allowSlidePrev = allowSlidePrev;
    swiper.allowSlideNext = allowSlideNext;
    swiper.emit("loopFix");
    return;
  }
  let slidesPerView = params.slidesPerView;
  if (slidesPerView === "auto") {
    slidesPerView = swiper.slidesPerViewDynamic();
  } else {
    slidesPerView = Math.ceil(parseFloat(params.slidesPerView, 10));
    if (centeredSlides && slidesPerView % 2 === 0) {
      slidesPerView = slidesPerView + 1;
    }
  }
  const slidesPerGroup = params.slidesPerGroupAuto ? slidesPerView : params.slidesPerGroup;
  let loopedSlides = slidesPerGroup;
  if (loopedSlides % slidesPerGroup !== 0) {
    loopedSlides += slidesPerGroup - loopedSlides % slidesPerGroup;
  }
  loopedSlides += params.loopAdditionalSlides;
  swiper.loopedSlides = loopedSlides;
  const gridEnabled = swiper.grid && params.grid && params.grid.rows > 1;
  if (slides.length < slidesPerView + loopedSlides) {
    showWarning("Swiper Loop Warning: The number of slides is not enough for loop mode, it will be disabled and not function properly. You need to add more slides (or make duplicates) or lower the values of slidesPerView and slidesPerGroup parameters");
  } else if (gridEnabled && params.grid.fill === "row") {
    showWarning("Swiper Loop Warning: Loop mode is not compatible with grid.fill = `row`");
  }
  const prependSlidesIndexes = [];
  const appendSlidesIndexes = [];
  let activeIndex = swiper.activeIndex;
  if (typeof activeSlideIndex === "undefined") {
    activeSlideIndex = swiper.getSlideIndex(slides.filter(el => el.classList.contains(params.slideActiveClass))[0]);
  } else {
    activeIndex = activeSlideIndex;
  }
  const isNext = direction === "next" || !direction;
  const isPrev = direction === "prev" || !direction;
  let slidesPrepended = 0;
  let slidesAppended = 0;
  const cols = gridEnabled ? Math.ceil(slides.length / params.grid.rows) : slides.length;
  const activeColIndex = gridEnabled ? slides[activeSlideIndex].column : activeSlideIndex;
  const activeColIndexWithShift = activeColIndex + (centeredSlides && typeof setTranslate2 === "undefined" ? -slidesPerView / 2 + 0.5 : 0);
  if (activeColIndexWithShift < loopedSlides) {
    slidesPrepended = Math.max(loopedSlides - activeColIndexWithShift, slidesPerGroup);
    for (let i = 0; i < loopedSlides - activeColIndexWithShift; i += 1) {
      const index = i - Math.floor(i / cols) * cols;
      if (gridEnabled) {
        const colIndexToPrepend = cols - index - 1;
        for (let i2 = slides.length - 1; i2 >= 0; i2 -= 1) {
          if (slides[i2].column === colIndexToPrepend) prependSlidesIndexes.push(i2);
        }
      } else {
        prependSlidesIndexes.push(cols - index - 1);
      }
    }
  } else if (activeColIndexWithShift + slidesPerView > cols - loopedSlides) {
    slidesAppended = Math.max(activeColIndexWithShift - (cols - loopedSlides * 2), slidesPerGroup);
    for (let i = 0; i < slidesAppended; i += 1) {
      const index = i - Math.floor(i / cols) * cols;
      if (gridEnabled) {
        slides.forEach((slide2, slideIndex) => {
          if (slide2.column === index) appendSlidesIndexes.push(slideIndex);
        });
      } else {
        appendSlidesIndexes.push(index);
      }
    }
  }
  swiper.__preventObserver__ = true;
  requestAnimationFrame(() => {
    swiper.__preventObserver__ = false;
  });
  if (isPrev) {
    prependSlidesIndexes.forEach(index => {
      slides[index].swiperLoopMoveDOM = true;
      slidesEl.prepend(slides[index]);
      slides[index].swiperLoopMoveDOM = false;
    });
  }
  if (isNext) {
    appendSlidesIndexes.forEach(index => {
      slides[index].swiperLoopMoveDOM = true;
      slidesEl.append(slides[index]);
      slides[index].swiperLoopMoveDOM = false;
    });
  }
  swiper.recalcSlides();
  if (params.slidesPerView === "auto") {
    swiper.updateSlides();
  } else if (gridEnabled && (prependSlidesIndexes.length > 0 && isPrev || appendSlidesIndexes.length > 0 && isNext)) {
    swiper.slides.forEach((slide2, slideIndex) => {
      swiper.grid.updateSlide(slideIndex, slide2, swiper.slides);
    });
  }
  if (params.watchSlidesProgress) {
    swiper.updateSlidesOffset();
  }
  if (slideTo2) {
    if (prependSlidesIndexes.length > 0 && isPrev) {
      if (typeof slideRealIndex === "undefined") {
        const currentSlideTranslate = swiper.slidesGrid[activeIndex];
        const newSlideTranslate = swiper.slidesGrid[activeIndex + slidesPrepended];
        const diff = newSlideTranslate - currentSlideTranslate;
        if (byMousewheel) {
          swiper.setTranslate(swiper.translate - diff);
        } else {
          swiper.slideTo(activeIndex + Math.ceil(slidesPrepended), 0, false, true);
          if (setTranslate2) {
            swiper.touchEventsData.startTranslate = swiper.touchEventsData.startTranslate - diff;
            swiper.touchEventsData.currentTranslate = swiper.touchEventsData.currentTranslate - diff;
          }
        }
      } else {
        if (setTranslate2) {
          const shift = gridEnabled ? prependSlidesIndexes.length / params.grid.rows : prependSlidesIndexes.length;
          swiper.slideTo(swiper.activeIndex + shift, 0, false, true);
          swiper.touchEventsData.currentTranslate = swiper.translate;
        }
      }
    } else if (appendSlidesIndexes.length > 0 && isNext) {
      if (typeof slideRealIndex === "undefined") {
        const currentSlideTranslate = swiper.slidesGrid[activeIndex];
        const newSlideTranslate = swiper.slidesGrid[activeIndex - slidesAppended];
        const diff = newSlideTranslate - currentSlideTranslate;
        if (byMousewheel) {
          swiper.setTranslate(swiper.translate - diff);
        } else {
          swiper.slideTo(activeIndex - slidesAppended, 0, false, true);
          if (setTranslate2) {
            swiper.touchEventsData.startTranslate = swiper.touchEventsData.startTranslate - diff;
            swiper.touchEventsData.currentTranslate = swiper.touchEventsData.currentTranslate - diff;
          }
        }
      } else {
        const shift = gridEnabled ? appendSlidesIndexes.length / params.grid.rows : appendSlidesIndexes.length;
        swiper.slideTo(swiper.activeIndex - shift, 0, false, true);
      }
    }
  }
  swiper.allowSlidePrev = allowSlidePrev;
  swiper.allowSlideNext = allowSlideNext;
  if (swiper.controller && swiper.controller.control && !byController) {
    const loopParams = {
      slideRealIndex,
      direction,
      setTranslate: setTranslate2,
      activeSlideIndex,
      byController: true
    };
    if (Array.isArray(swiper.controller.control)) {
      swiper.controller.control.forEach(c => {
        if (!c.destroyed && c.params.loop) c.loopFix({
          ...loopParams,
          slideTo: c.params.slidesPerView === params.slidesPerView ? slideTo2 : false
        });
      });
    } else if (swiper.controller.control instanceof swiper.constructor && swiper.controller.control.params.loop) {
      swiper.controller.control.loopFix({
        ...loopParams,
        slideTo: swiper.controller.control.params.slidesPerView === params.slidesPerView ? slideTo2 : false
      });
    }
  }
  swiper.emit("loopFix");
}
function loopDestroy() {
  const swiper = this;
  const {
    params,
    slidesEl
  } = swiper;
  if (!params.loop || swiper.virtual && swiper.params.virtual.enabled) return;
  swiper.recalcSlides();
  const newSlidesOrder = [];
  swiper.slides.forEach(slideEl => {
    const index = typeof slideEl.swiperSlideIndex === "undefined" ? slideEl.getAttribute("data-swiper-slide-index") * 1 : slideEl.swiperSlideIndex;
    newSlidesOrder[index] = slideEl;
  });
  swiper.slides.forEach(slideEl => {
    slideEl.removeAttribute("data-swiper-slide-index");
  });
  newSlidesOrder.forEach(slideEl => {
    slidesEl.append(slideEl);
  });
  swiper.recalcSlides();
  swiper.slideTo(swiper.realIndex, 0);
}
var loop = {
  loopCreate,
  loopFix,
  loopDestroy
};
function setGrabCursor(moving) {
  const swiper = this;
  if (!swiper.params.simulateTouch || swiper.params.watchOverflow && swiper.isLocked || swiper.params.cssMode) return;
  const el = swiper.params.touchEventsTarget === "container" ? swiper.el : swiper.wrapperEl;
  if (swiper.isElement) {
    swiper.__preventObserver__ = true;
  }
  el.style.cursor = "move";
  el.style.cursor = moving ? "grabbing" : "grab";
  if (swiper.isElement) {
    requestAnimationFrame(() => {
      swiper.__preventObserver__ = false;
    });
  }
}
function unsetGrabCursor() {
  const swiper = this;
  if (swiper.params.watchOverflow && swiper.isLocked || swiper.params.cssMode) {
    return;
  }
  if (swiper.isElement) {
    swiper.__preventObserver__ = true;
  }
  swiper[swiper.params.touchEventsTarget === "container" ? "el" : "wrapperEl"].style.cursor = "";
  if (swiper.isElement) {
    requestAnimationFrame(() => {
      swiper.__preventObserver__ = false;
    });
  }
}
var grabCursor = {
  setGrabCursor,
  unsetGrabCursor
};
function closestElement(selector, base) {
  if (base === void 0) {
    base = this;
  }
  function __closestFrom(el) {
    if (!el || el === getDocument() || el === getWindow()) return null;
    if (el.assignedSlot) el = el.assignedSlot;
    const found = el.closest(selector);
    if (!found && !el.getRootNode) {
      return null;
    }
    return found || __closestFrom(el.getRootNode().host);
  }
  return __closestFrom(base);
}
function preventEdgeSwipe(swiper, event, startX) {
  const window2 = getWindow();
  const {
    params
  } = swiper;
  const edgeSwipeDetection = params.edgeSwipeDetection;
  const edgeSwipeThreshold = params.edgeSwipeThreshold;
  if (edgeSwipeDetection && (startX <= edgeSwipeThreshold || startX >= window2.innerWidth - edgeSwipeThreshold)) {
    if (edgeSwipeDetection === "prevent") {
      event.preventDefault();
      return true;
    }
    return false;
  }
  return true;
}
function onTouchStart(event) {
  const swiper = this;
  const document2 = getDocument();
  let e = event;
  if (e.originalEvent) e = e.originalEvent;
  const data = swiper.touchEventsData;
  if (e.type === "pointerdown") {
    if (data.pointerId !== null && data.pointerId !== e.pointerId) {
      return;
    }
    data.pointerId = e.pointerId;
  } else if (e.type === "touchstart" && e.targetTouches.length === 1) {
    data.touchId = e.targetTouches[0].identifier;
  }
  if (e.type === "touchstart") {
    preventEdgeSwipe(swiper, e, e.targetTouches[0].pageX);
    return;
  }
  const {
    params,
    touches,
    enabled
  } = swiper;
  if (!enabled) return;
  if (!params.simulateTouch && e.pointerType === "mouse") return;
  if (swiper.animating && params.preventInteractionOnTransition) {
    return;
  }
  if (!swiper.animating && params.cssMode && params.loop) {
    swiper.loopFix();
  }
  let targetEl = e.target;
  if (params.touchEventsTarget === "wrapper") {
    if (!swiper.wrapperEl.contains(targetEl)) return;
  }
  if ("which" in e && e.which === 3) return;
  if ("button" in e && e.button > 0) return;
  if (data.isTouched && data.isMoved) return;
  const swipingClassHasValue = !!params.noSwipingClass && params.noSwipingClass !== "";
  const eventPath = e.composedPath ? e.composedPath() : e.path;
  if (swipingClassHasValue && e.target && e.target.shadowRoot && eventPath) {
    targetEl = eventPath[0];
  }
  const noSwipingSelector = params.noSwipingSelector ? params.noSwipingSelector : `.${params.noSwipingClass}`;
  const isTargetShadow = !!(e.target && e.target.shadowRoot);
  if (params.noSwiping && (isTargetShadow ? closestElement(noSwipingSelector, targetEl) : targetEl.closest(noSwipingSelector))) {
    swiper.allowClick = true;
    return;
  }
  if (params.swipeHandler) {
    if (!targetEl.closest(params.swipeHandler)) return;
  }
  touches.currentX = e.pageX;
  touches.currentY = e.pageY;
  const startX = touches.currentX;
  const startY = touches.currentY;
  if (!preventEdgeSwipe(swiper, e, startX)) {
    return;
  }
  Object.assign(data, {
    isTouched: true,
    isMoved: false,
    allowTouchCallbacks: true,
    isScrolling: void 0,
    startMoving: void 0
  });
  touches.startX = startX;
  touches.startY = startY;
  data.touchStartTime = now();
  swiper.allowClick = true;
  swiper.updateSize();
  swiper.swipeDirection = void 0;
  if (params.threshold > 0) data.allowThresholdMove = false;
  let preventDefault = true;
  if (targetEl.matches(data.focusableElements)) {
    preventDefault = false;
    if (targetEl.nodeName === "SELECT") {
      data.isTouched = false;
    }
  }
  if (document2.activeElement && document2.activeElement.matches(data.focusableElements) && document2.activeElement !== targetEl) {
    document2.activeElement.blur();
  }
  const shouldPreventDefault = preventDefault && swiper.allowTouchMove && params.touchStartPreventDefault;
  if ((params.touchStartForcePreventDefault || shouldPreventDefault) && !targetEl.isContentEditable) {
    e.preventDefault();
  }
  if (params.freeMode && params.freeMode.enabled && swiper.freeMode && swiper.animating && !params.cssMode) {
    swiper.freeMode.onTouchStart();
  }
  swiper.emit("touchStart", e);
}
function onTouchMove(event) {
  const document2 = getDocument();
  const swiper = this;
  const data = swiper.touchEventsData;
  const {
    params,
    touches,
    rtlTranslate: rtl,
    enabled
  } = swiper;
  if (!enabled) return;
  if (!params.simulateTouch && event.pointerType === "mouse") return;
  let e = event;
  if (e.originalEvent) e = e.originalEvent;
  if (e.type === "pointermove") {
    if (data.touchId !== null) return;
    const id = e.pointerId;
    if (id !== data.pointerId) return;
  }
  let targetTouch;
  if (e.type === "touchmove") {
    targetTouch = [...e.changedTouches].filter(t => t.identifier === data.touchId)[0];
    if (!targetTouch || targetTouch.identifier !== data.touchId) return;
  } else {
    targetTouch = e;
  }
  if (!data.isTouched) {
    if (data.startMoving && data.isScrolling) {
      swiper.emit("touchMoveOpposite", e);
    }
    return;
  }
  const pageX = targetTouch.pageX;
  const pageY = targetTouch.pageY;
  if (e.preventedByNestedSwiper) {
    touches.startX = pageX;
    touches.startY = pageY;
    return;
  }
  if (!swiper.allowTouchMove) {
    if (!e.target.matches(data.focusableElements)) {
      swiper.allowClick = false;
    }
    if (data.isTouched) {
      Object.assign(touches, {
        startX: pageX,
        startY: pageY,
        currentX: pageX,
        currentY: pageY
      });
      data.touchStartTime = now();
    }
    return;
  }
  if (params.touchReleaseOnEdges && !params.loop) {
    if (swiper.isVertical()) {
      if (pageY < touches.startY && swiper.translate <= swiper.maxTranslate() || pageY > touches.startY && swiper.translate >= swiper.minTranslate()) {
        data.isTouched = false;
        data.isMoved = false;
        return;
      }
    } else if (pageX < touches.startX && swiper.translate <= swiper.maxTranslate() || pageX > touches.startX && swiper.translate >= swiper.minTranslate()) {
      return;
    }
  }
  if (document2.activeElement) {
    if (e.target === document2.activeElement && e.target.matches(data.focusableElements)) {
      data.isMoved = true;
      swiper.allowClick = false;
      return;
    }
  }
  if (data.allowTouchCallbacks) {
    swiper.emit("touchMove", e);
  }
  touches.previousX = touches.currentX;
  touches.previousY = touches.currentY;
  touches.currentX = pageX;
  touches.currentY = pageY;
  const diffX = touches.currentX - touches.startX;
  const diffY = touches.currentY - touches.startY;
  if (swiper.params.threshold && Math.sqrt(diffX ** 2 + diffY ** 2) < swiper.params.threshold) return;
  if (typeof data.isScrolling === "undefined") {
    let touchAngle;
    if (swiper.isHorizontal() && touches.currentY === touches.startY || swiper.isVertical() && touches.currentX === touches.startX) {
      data.isScrolling = false;
    } else {
      if (diffX * diffX + diffY * diffY >= 25) {
        touchAngle = Math.atan2(Math.abs(diffY), Math.abs(diffX)) * 180 / Math.PI;
        data.isScrolling = swiper.isHorizontal() ? touchAngle > params.touchAngle : 90 - touchAngle > params.touchAngle;
      }
    }
  }
  if (data.isScrolling) {
    swiper.emit("touchMoveOpposite", e);
  }
  if (typeof data.startMoving === "undefined") {
    if (touches.currentX !== touches.startX || touches.currentY !== touches.startY) {
      data.startMoving = true;
    }
  }
  if (data.isScrolling || e.type === "touchmove" && data.preventTouchMoveFromPointerMove) {
    data.isTouched = false;
    return;
  }
  if (!data.startMoving) {
    return;
  }
  swiper.allowClick = false;
  if (!params.cssMode && e.cancelable) {
    e.preventDefault();
  }
  if (params.touchMoveStopPropagation && !params.nested) {
    e.stopPropagation();
  }
  let diff = swiper.isHorizontal() ? diffX : diffY;
  let touchesDiff = swiper.isHorizontal() ? touches.currentX - touches.previousX : touches.currentY - touches.previousY;
  if (params.oneWayMovement) {
    diff = Math.abs(diff) * (rtl ? 1 : -1);
    touchesDiff = Math.abs(touchesDiff) * (rtl ? 1 : -1);
  }
  touches.diff = diff;
  diff *= params.touchRatio;
  if (rtl) {
    diff = -diff;
    touchesDiff = -touchesDiff;
  }
  const prevTouchesDirection = swiper.touchesDirection;
  swiper.swipeDirection = diff > 0 ? "prev" : "next";
  swiper.touchesDirection = touchesDiff > 0 ? "prev" : "next";
  const isLoop = swiper.params.loop && !params.cssMode;
  const allowLoopFix = swiper.touchesDirection === "next" && swiper.allowSlideNext || swiper.touchesDirection === "prev" && swiper.allowSlidePrev;
  if (!data.isMoved) {
    if (isLoop && allowLoopFix) {
      swiper.loopFix({
        direction: swiper.swipeDirection
      });
    }
    data.startTranslate = swiper.getTranslate();
    swiper.setTransition(0);
    if (swiper.animating) {
      const evt = new window.CustomEvent("transitionend", {
        bubbles: true,
        cancelable: true,
        detail: {
          bySwiperTouchMove: true
        }
      });
      swiper.wrapperEl.dispatchEvent(evt);
    }
    data.allowMomentumBounce = false;
    if (params.grabCursor && (swiper.allowSlideNext === true || swiper.allowSlidePrev === true)) {
      swiper.setGrabCursor(true);
    }
    swiper.emit("sliderFirstMove", e);
  }
  let loopFixed;
  new Date().getTime();
  if (data.isMoved && data.allowThresholdMove && prevTouchesDirection !== swiper.touchesDirection && isLoop && allowLoopFix && Math.abs(diff) >= 1) {
    Object.assign(touches, {
      startX: pageX,
      startY: pageY,
      currentX: pageX,
      currentY: pageY,
      startTranslate: data.currentTranslate
    });
    data.loopSwapReset = true;
    data.startTranslate = data.currentTranslate;
    return;
  }
  swiper.emit("sliderMove", e);
  data.isMoved = true;
  data.currentTranslate = diff + data.startTranslate;
  let disableParentSwiper = true;
  let resistanceRatio = params.resistanceRatio;
  if (params.touchReleaseOnEdges) {
    resistanceRatio = 0;
  }
  if (diff > 0) {
    if (isLoop && allowLoopFix && !loopFixed && data.allowThresholdMove && data.currentTranslate > (params.centeredSlides ? swiper.minTranslate() - swiper.slidesSizesGrid[swiper.activeIndex + 1] : swiper.minTranslate())) {
      swiper.loopFix({
        direction: "prev",
        setTranslate: true,
        activeSlideIndex: 0
      });
    }
    if (data.currentTranslate > swiper.minTranslate()) {
      disableParentSwiper = false;
      if (params.resistance) {
        data.currentTranslate = swiper.minTranslate() - 1 + (-swiper.minTranslate() + data.startTranslate + diff) ** resistanceRatio;
      }
    }
  } else if (diff < 0) {
    if (isLoop && allowLoopFix && !loopFixed && data.allowThresholdMove && data.currentTranslate < (params.centeredSlides ? swiper.maxTranslate() + swiper.slidesSizesGrid[swiper.slidesSizesGrid.length - 1] : swiper.maxTranslate())) {
      swiper.loopFix({
        direction: "next",
        setTranslate: true,
        activeSlideIndex: swiper.slides.length - (params.slidesPerView === "auto" ? swiper.slidesPerViewDynamic() : Math.ceil(parseFloat(params.slidesPerView, 10)))
      });
    }
    if (data.currentTranslate < swiper.maxTranslate()) {
      disableParentSwiper = false;
      if (params.resistance) {
        data.currentTranslate = swiper.maxTranslate() + 1 - (swiper.maxTranslate() - data.startTranslate - diff) ** resistanceRatio;
      }
    }
  }
  if (disableParentSwiper) {
    e.preventedByNestedSwiper = true;
  }
  if (!swiper.allowSlideNext && swiper.swipeDirection === "next" && data.currentTranslate < data.startTranslate) {
    data.currentTranslate = data.startTranslate;
  }
  if (!swiper.allowSlidePrev && swiper.swipeDirection === "prev" && data.currentTranslate > data.startTranslate) {
    data.currentTranslate = data.startTranslate;
  }
  if (!swiper.allowSlidePrev && !swiper.allowSlideNext) {
    data.currentTranslate = data.startTranslate;
  }
  if (params.threshold > 0) {
    if (Math.abs(diff) > params.threshold || data.allowThresholdMove) {
      if (!data.allowThresholdMove) {
        data.allowThresholdMove = true;
        touches.startX = touches.currentX;
        touches.startY = touches.currentY;
        data.currentTranslate = data.startTranslate;
        touches.diff = swiper.isHorizontal() ? touches.currentX - touches.startX : touches.currentY - touches.startY;
        return;
      }
    } else {
      data.currentTranslate = data.startTranslate;
      return;
    }
  }
  if (!params.followFinger || params.cssMode) return;
  if (params.freeMode && params.freeMode.enabled && swiper.freeMode || params.watchSlidesProgress) {
    swiper.updateActiveIndex();
    swiper.updateSlidesClasses();
  }
  if (params.freeMode && params.freeMode.enabled && swiper.freeMode) {
    swiper.freeMode.onTouchMove();
  }
  swiper.updateProgress(data.currentTranslate);
  swiper.setTranslate(data.currentTranslate);
}
function onTouchEnd(event) {
  const swiper = this;
  const data = swiper.touchEventsData;
  let e = event;
  if (e.originalEvent) e = e.originalEvent;
  let targetTouch;
  const isTouchEvent = e.type === "touchend" || e.type === "touchcancel";
  if (!isTouchEvent) {
    if (data.touchId !== null) return;
    if (e.pointerId !== data.pointerId) return;
    targetTouch = e;
  } else {
    targetTouch = [...e.changedTouches].filter(t => t.identifier === data.touchId)[0];
    if (!targetTouch || targetTouch.identifier !== data.touchId) return;
  }
  if (["pointercancel", "pointerout", "pointerleave", "contextmenu"].includes(e.type)) {
    const proceed = ["pointercancel", "contextmenu"].includes(e.type) && (swiper.browser.isSafari || swiper.browser.isWebView);
    if (!proceed) {
      return;
    }
  }
  data.pointerId = null;
  data.touchId = null;
  const {
    params,
    touches,
    rtlTranslate: rtl,
    slidesGrid,
    enabled
  } = swiper;
  if (!enabled) return;
  if (!params.simulateTouch && e.pointerType === "mouse") return;
  if (data.allowTouchCallbacks) {
    swiper.emit("touchEnd", e);
  }
  data.allowTouchCallbacks = false;
  if (!data.isTouched) {
    if (data.isMoved && params.grabCursor) {
      swiper.setGrabCursor(false);
    }
    data.isMoved = false;
    data.startMoving = false;
    return;
  }
  if (params.grabCursor && data.isMoved && data.isTouched && (swiper.allowSlideNext === true || swiper.allowSlidePrev === true)) {
    swiper.setGrabCursor(false);
  }
  const touchEndTime = now();
  const timeDiff = touchEndTime - data.touchStartTime;
  if (swiper.allowClick) {
    const pathTree = e.path || e.composedPath && e.composedPath();
    swiper.updateClickedSlide(pathTree && pathTree[0] || e.target, pathTree);
    swiper.emit("tap click", e);
    if (timeDiff < 300 && touchEndTime - data.lastClickTime < 300) {
      swiper.emit("doubleTap doubleClick", e);
    }
  }
  data.lastClickTime = now();
  nextTick(() => {
    if (!swiper.destroyed) swiper.allowClick = true;
  });
  if (!data.isTouched || !data.isMoved || !swiper.swipeDirection || touches.diff === 0 && !data.loopSwapReset || data.currentTranslate === data.startTranslate && !data.loopSwapReset) {
    data.isTouched = false;
    data.isMoved = false;
    data.startMoving = false;
    return;
  }
  data.isTouched = false;
  data.isMoved = false;
  data.startMoving = false;
  let currentPos;
  if (params.followFinger) {
    currentPos = rtl ? swiper.translate : -swiper.translate;
  } else {
    currentPos = -data.currentTranslate;
  }
  if (params.cssMode) {
    return;
  }
  if (params.freeMode && params.freeMode.enabled) {
    swiper.freeMode.onTouchEnd({
      currentPos
    });
    return;
  }
  const swipeToLast = currentPos >= -swiper.maxTranslate() && !swiper.params.loop;
  let stopIndex = 0;
  let groupSize = swiper.slidesSizesGrid[0];
  for (let i = 0; i < slidesGrid.length; i += i < params.slidesPerGroupSkip ? 1 : params.slidesPerGroup) {
    const increment2 = i < params.slidesPerGroupSkip - 1 ? 1 : params.slidesPerGroup;
    if (typeof slidesGrid[i + increment2] !== "undefined") {
      if (swipeToLast || currentPos >= slidesGrid[i] && currentPos < slidesGrid[i + increment2]) {
        stopIndex = i;
        groupSize = slidesGrid[i + increment2] - slidesGrid[i];
      }
    } else if (swipeToLast || currentPos >= slidesGrid[i]) {
      stopIndex = i;
      groupSize = slidesGrid[slidesGrid.length - 1] - slidesGrid[slidesGrid.length - 2];
    }
  }
  let rewindFirstIndex = null;
  let rewindLastIndex = null;
  if (params.rewind) {
    if (swiper.isBeginning) {
      rewindLastIndex = params.virtual && params.virtual.enabled && swiper.virtual ? swiper.virtual.slides.length - 1 : swiper.slides.length - 1;
    } else if (swiper.isEnd) {
      rewindFirstIndex = 0;
    }
  }
  const ratio = (currentPos - slidesGrid[stopIndex]) / groupSize;
  const increment = stopIndex < params.slidesPerGroupSkip - 1 ? 1 : params.slidesPerGroup;
  if (timeDiff > params.longSwipesMs) {
    if (!params.longSwipes) {
      swiper.slideTo(swiper.activeIndex);
      return;
    }
    if (swiper.swipeDirection === "next") {
      if (ratio >= params.longSwipesRatio) swiper.slideTo(params.rewind && swiper.isEnd ? rewindFirstIndex : stopIndex + increment);else swiper.slideTo(stopIndex);
    }
    if (swiper.swipeDirection === "prev") {
      if (ratio > 1 - params.longSwipesRatio) {
        swiper.slideTo(stopIndex + increment);
      } else if (rewindLastIndex !== null && ratio < 0 && Math.abs(ratio) > params.longSwipesRatio) {
        swiper.slideTo(rewindLastIndex);
      } else {
        swiper.slideTo(stopIndex);
      }
    }
  } else {
    if (!params.shortSwipes) {
      swiper.slideTo(swiper.activeIndex);
      return;
    }
    const isNavButtonTarget = swiper.navigation && (e.target === swiper.navigation.nextEl || e.target === swiper.navigation.prevEl);
    if (!isNavButtonTarget) {
      if (swiper.swipeDirection === "next") {
        swiper.slideTo(rewindFirstIndex !== null ? rewindFirstIndex : stopIndex + increment);
      }
      if (swiper.swipeDirection === "prev") {
        swiper.slideTo(rewindLastIndex !== null ? rewindLastIndex : stopIndex);
      }
    } else if (e.target === swiper.navigation.nextEl) {
      swiper.slideTo(stopIndex + increment);
    } else {
      swiper.slideTo(stopIndex);
    }
  }
}
function onResize() {
  const swiper = this;
  const {
    params,
    el
  } = swiper;
  if (el && el.offsetWidth === 0) return;
  if (params.breakpoints) {
    swiper.setBreakpoint();
  }
  const {
    allowSlideNext,
    allowSlidePrev,
    snapGrid
  } = swiper;
  const isVirtual = swiper.virtual && swiper.params.virtual.enabled;
  swiper.allowSlideNext = true;
  swiper.allowSlidePrev = true;
  swiper.updateSize();
  swiper.updateSlides();
  swiper.updateSlidesClasses();
  const isVirtualLoop = isVirtual && params.loop;
  if ((params.slidesPerView === "auto" || params.slidesPerView > 1) && swiper.isEnd && !swiper.isBeginning && !swiper.params.centeredSlides && !isVirtualLoop) {
    swiper.slideTo(swiper.slides.length - 1, 0, false, true);
  } else {
    if (swiper.params.loop && !isVirtual) {
      swiper.slideToLoop(swiper.realIndex, 0, false, true);
    } else {
      swiper.slideTo(swiper.activeIndex, 0, false, true);
    }
  }
  if (swiper.autoplay && swiper.autoplay.running && swiper.autoplay.paused) {
    clearTimeout(swiper.autoplay.resizeTimeout);
    swiper.autoplay.resizeTimeout = setTimeout(() => {
      if (swiper.autoplay && swiper.autoplay.running && swiper.autoplay.paused) {
        swiper.autoplay.resume();
      }
    }, 500);
  }
  swiper.allowSlidePrev = allowSlidePrev;
  swiper.allowSlideNext = allowSlideNext;
  if (swiper.params.watchOverflow && snapGrid !== swiper.snapGrid) {
    swiper.checkOverflow();
  }
}
function onClick(e) {
  const swiper = this;
  if (!swiper.enabled) return;
  if (!swiper.allowClick) {
    if (swiper.params.preventClicks) e.preventDefault();
    if (swiper.params.preventClicksPropagation && swiper.animating) {
      e.stopPropagation();
      e.stopImmediatePropagation();
    }
  }
}
function onScroll() {
  const swiper = this;
  const {
    wrapperEl,
    rtlTranslate,
    enabled
  } = swiper;
  if (!enabled) return;
  swiper.previousTranslate = swiper.translate;
  if (swiper.isHorizontal()) {
    swiper.translate = -wrapperEl.scrollLeft;
  } else {
    swiper.translate = -wrapperEl.scrollTop;
  }
  if (swiper.translate === 0) swiper.translate = 0;
  swiper.updateActiveIndex();
  swiper.updateSlidesClasses();
  let newProgress;
  const translatesDiff = swiper.maxTranslate() - swiper.minTranslate();
  if (translatesDiff === 0) {
    newProgress = 0;
  } else {
    newProgress = (swiper.translate - swiper.minTranslate()) / translatesDiff;
  }
  if (newProgress !== swiper.progress) {
    swiper.updateProgress(rtlTranslate ? -swiper.translate : swiper.translate);
  }
  swiper.emit("setTranslate", swiper.translate, false);
}
function onLoad(e) {
  const swiper = this;
  processLazyPreloader(swiper, e.target);
  if (swiper.params.cssMode || swiper.params.slidesPerView !== "auto" && !swiper.params.autoHeight) {
    return;
  }
  swiper.update();
}
function onDocumentTouchStart() {
  const swiper = this;
  if (swiper.documentTouchHandlerProceeded) return;
  swiper.documentTouchHandlerProceeded = true;
  if (swiper.params.touchReleaseOnEdges) {
    swiper.el.style.touchAction = "auto";
  }
}
var events = (swiper, method) => {
  const document2 = getDocument();
  const {
    params,
    el,
    wrapperEl,
    device
  } = swiper;
  const capture = !!params.nested;
  const domMethod = method === "on" ? "addEventListener" : "removeEventListener";
  const swiperMethod = method;
  document2[domMethod]("touchstart", swiper.onDocumentTouchStart, {
    passive: false,
    capture
  });
  el[domMethod]("touchstart", swiper.onTouchStart, {
    passive: false
  });
  el[domMethod]("pointerdown", swiper.onTouchStart, {
    passive: false
  });
  document2[domMethod]("touchmove", swiper.onTouchMove, {
    passive: false,
    capture
  });
  document2[domMethod]("pointermove", swiper.onTouchMove, {
    passive: false,
    capture
  });
  document2[domMethod]("touchend", swiper.onTouchEnd, {
    passive: true
  });
  document2[domMethod]("pointerup", swiper.onTouchEnd, {
    passive: true
  });
  document2[domMethod]("pointercancel", swiper.onTouchEnd, {
    passive: true
  });
  document2[domMethod]("touchcancel", swiper.onTouchEnd, {
    passive: true
  });
  document2[domMethod]("pointerout", swiper.onTouchEnd, {
    passive: true
  });
  document2[domMethod]("pointerleave", swiper.onTouchEnd, {
    passive: true
  });
  document2[domMethod]("contextmenu", swiper.onTouchEnd, {
    passive: true
  });
  if (params.preventClicks || params.preventClicksPropagation) {
    el[domMethod]("click", swiper.onClick, true);
  }
  if (params.cssMode) {
    wrapperEl[domMethod]("scroll", swiper.onScroll);
  }
  if (params.updateOnWindowResize) {
    swiper[swiperMethod](device.ios || device.android ? "resize orientationchange observerUpdate" : "resize observerUpdate", onResize, true);
  } else {
    swiper[swiperMethod]("observerUpdate", onResize, true);
  }
  el[domMethod]("load", swiper.onLoad, {
    capture: true
  });
};
function attachEvents() {
  const swiper = this;
  const {
    params
  } = swiper;
  swiper.onTouchStart = onTouchStart.bind(swiper);
  swiper.onTouchMove = onTouchMove.bind(swiper);
  swiper.onTouchEnd = onTouchEnd.bind(swiper);
  swiper.onDocumentTouchStart = onDocumentTouchStart.bind(swiper);
  if (params.cssMode) {
    swiper.onScroll = onScroll.bind(swiper);
  }
  swiper.onClick = onClick.bind(swiper);
  swiper.onLoad = onLoad.bind(swiper);
  events(swiper, "on");
}
function detachEvents() {
  const swiper = this;
  events(swiper, "off");
}
var events$1 = {
  attachEvents,
  detachEvents
};
var isGridEnabled = (swiper, params) => {
  return swiper.grid && params.grid && params.grid.rows > 1;
};
function setBreakpoint() {
  const swiper = this;
  const {
    realIndex,
    initialized,
    params,
    el
  } = swiper;
  const breakpoints2 = params.breakpoints;
  if (!breakpoints2 || breakpoints2 && Object.keys(breakpoints2).length === 0) return;
  const breakpoint = swiper.getBreakpoint(breakpoints2, swiper.params.breakpointsBase, swiper.el);
  if (!breakpoint || swiper.currentBreakpoint === breakpoint) return;
  const breakpointOnlyParams = breakpoint in breakpoints2 ? breakpoints2[breakpoint] : void 0;
  const breakpointParams = breakpointOnlyParams || swiper.originalParams;
  const wasMultiRow = isGridEnabled(swiper, params);
  const isMultiRow = isGridEnabled(swiper, breakpointParams);
  const wasGrabCursor = swiper.params.grabCursor;
  const isGrabCursor = breakpointParams.grabCursor;
  const wasEnabled = params.enabled;
  if (wasMultiRow && !isMultiRow) {
    el.classList.remove(`${params.containerModifierClass}grid`, `${params.containerModifierClass}grid-column`);
    swiper.emitContainerClasses();
  } else if (!wasMultiRow && isMultiRow) {
    el.classList.add(`${params.containerModifierClass}grid`);
    if (breakpointParams.grid.fill && breakpointParams.grid.fill === "column" || !breakpointParams.grid.fill && params.grid.fill === "column") {
      el.classList.add(`${params.containerModifierClass}grid-column`);
    }
    swiper.emitContainerClasses();
  }
  if (wasGrabCursor && !isGrabCursor) {
    swiper.unsetGrabCursor();
  } else if (!wasGrabCursor && isGrabCursor) {
    swiper.setGrabCursor();
  }
  ["navigation", "pagination", "scrollbar"].forEach(prop => {
    if (typeof breakpointParams[prop] === "undefined") return;
    const wasModuleEnabled = params[prop] && params[prop].enabled;
    const isModuleEnabled = breakpointParams[prop] && breakpointParams[prop].enabled;
    if (wasModuleEnabled && !isModuleEnabled) {
      swiper[prop].disable();
    }
    if (!wasModuleEnabled && isModuleEnabled) {
      swiper[prop].enable();
    }
  });
  const directionChanged = breakpointParams.direction && breakpointParams.direction !== params.direction;
  const needsReLoop = params.loop && (breakpointParams.slidesPerView !== params.slidesPerView || directionChanged);
  const wasLoop = params.loop;
  if (directionChanged && initialized) {
    swiper.changeDirection();
  }
  extend2(swiper.params, breakpointParams);
  const isEnabled = swiper.params.enabled;
  const hasLoop = swiper.params.loop;
  Object.assign(swiper, {
    allowTouchMove: swiper.params.allowTouchMove,
    allowSlideNext: swiper.params.allowSlideNext,
    allowSlidePrev: swiper.params.allowSlidePrev
  });
  if (wasEnabled && !isEnabled) {
    swiper.disable();
  } else if (!wasEnabled && isEnabled) {
    swiper.enable();
  }
  swiper.currentBreakpoint = breakpoint;
  swiper.emit("_beforeBreakpoint", breakpointParams);
  if (initialized) {
    if (needsReLoop) {
      swiper.loopDestroy();
      swiper.loopCreate(realIndex);
      swiper.updateSlides();
    } else if (!wasLoop && hasLoop) {
      swiper.loopCreate(realIndex);
      swiper.updateSlides();
    } else if (wasLoop && !hasLoop) {
      swiper.loopDestroy();
    }
  }
  swiper.emit("breakpoint", breakpointParams);
}
function getBreakpoint(breakpoints2, base, containerEl) {
  if (base === void 0) {
    base = "window";
  }
  if (!breakpoints2 || base === "container" && !containerEl) return void 0;
  let breakpoint = false;
  const window2 = getWindow();
  const currentHeight = base === "window" ? window2.innerHeight : containerEl.clientHeight;
  const points = Object.keys(breakpoints2).map(point => {
    if (typeof point === "string" && point.indexOf("@") === 0) {
      const minRatio = parseFloat(point.substr(1));
      const value = currentHeight * minRatio;
      return {
        value,
        point
      };
    }
    return {
      value: point,
      point
    };
  });
  points.sort((a, b) => parseInt(a.value, 10) - parseInt(b.value, 10));
  for (let i = 0; i < points.length; i += 1) {
    const {
      point,
      value
    } = points[i];
    if (base === "window") {
      if (window2.matchMedia(`(min-width: ${value}px)`).matches) {
        breakpoint = point;
      }
    } else if (value <= containerEl.clientWidth) {
      breakpoint = point;
    }
  }
  return breakpoint || "max";
}
var breakpoints = {
  setBreakpoint,
  getBreakpoint
};
function prepareClasses(entries, prefix) {
  const resultClasses = [];
  entries.forEach(item => {
    if (typeof item === "object") {
      Object.keys(item).forEach(classNames => {
        if (item[classNames]) {
          resultClasses.push(prefix + classNames);
        }
      });
    } else if (typeof item === "string") {
      resultClasses.push(prefix + item);
    }
  });
  return resultClasses;
}
function addClasses() {
  const swiper = this;
  const {
    classNames,
    params,
    rtl,
    el,
    device
  } = swiper;
  const suffixes = prepareClasses(["initialized", params.direction, {
    "free-mode": swiper.params.freeMode && params.freeMode.enabled
  }, {
    "autoheight": params.autoHeight
  }, {
    "rtl": rtl
  }, {
    "grid": params.grid && params.grid.rows > 1
  }, {
    "grid-column": params.grid && params.grid.rows > 1 && params.grid.fill === "column"
  }, {
    "android": device.android
  }, {
    "ios": device.ios
  }, {
    "css-mode": params.cssMode
  }, {
    "centered": params.cssMode && params.centeredSlides
  }, {
    "watch-progress": params.watchSlidesProgress
  }], params.containerModifierClass);
  classNames.push(...suffixes);
  el.classList.add(...classNames);
  swiper.emitContainerClasses();
}
function removeClasses() {
  const swiper = this;
  const {
    el,
    classNames
  } = swiper;
  el.classList.remove(...classNames);
  swiper.emitContainerClasses();
}
var classes = {
  addClasses,
  removeClasses
};
function checkOverflow() {
  const swiper = this;
  const {
    isLocked: wasLocked,
    params
  } = swiper;
  const {
    slidesOffsetBefore
  } = params;
  if (slidesOffsetBefore) {
    const lastSlideIndex = swiper.slides.length - 1;
    const lastSlideRightEdge = swiper.slidesGrid[lastSlideIndex] + swiper.slidesSizesGrid[lastSlideIndex] + slidesOffsetBefore * 2;
    swiper.isLocked = swiper.size > lastSlideRightEdge;
  } else {
    swiper.isLocked = swiper.snapGrid.length === 1;
  }
  if (params.allowSlideNext === true) {
    swiper.allowSlideNext = !swiper.isLocked;
  }
  if (params.allowSlidePrev === true) {
    swiper.allowSlidePrev = !swiper.isLocked;
  }
  if (wasLocked && wasLocked !== swiper.isLocked) {
    swiper.isEnd = false;
  }
  if (wasLocked !== swiper.isLocked) {
    swiper.emit(swiper.isLocked ? "lock" : "unlock");
  }
}
var checkOverflow$1 = {
  checkOverflow
};
var defaults = {
  init: true,
  direction: "horizontal",
  oneWayMovement: false,
  swiperElementNodeName: "SWIPER-CONTAINER",
  touchEventsTarget: "wrapper",
  initialSlide: 0,
  speed: 300,
  cssMode: false,
  updateOnWindowResize: true,
  resizeObserver: true,
  nested: false,
  createElements: false,
  eventsPrefix: "swiper",
  enabled: true,
  focusableElements: "input, select, option, textarea, button, video, label",
  width: null,
  height: null,
  preventInteractionOnTransition: false,
  userAgent: null,
  url: null,
  edgeSwipeDetection: false,
  edgeSwipeThreshold: 20,
  autoHeight: false,
  setWrapperSize: false,
  virtualTranslate: false,
  effect: "slide",
  breakpoints: void 0,
  breakpointsBase: "window",
  spaceBetween: 0,
  slidesPerView: 1,
  slidesPerGroup: 1,
  slidesPerGroupSkip: 0,
  slidesPerGroupAuto: false,
  centeredSlides: false,
  centeredSlidesBounds: false,
  slidesOffsetBefore: 0,
  slidesOffsetAfter: 0,
  normalizeSlideIndex: true,
  centerInsufficientSlides: false,
  watchOverflow: true,
  roundLengths: false,
  touchRatio: 1,
  touchAngle: 45,
  simulateTouch: true,
  shortSwipes: true,
  longSwipes: true,
  longSwipesRatio: 0.5,
  longSwipesMs: 300,
  followFinger: true,
  allowTouchMove: true,
  threshold: 5,
  touchMoveStopPropagation: false,
  touchStartPreventDefault: true,
  touchStartForcePreventDefault: false,
  touchReleaseOnEdges: false,
  uniqueNavElements: true,
  resistance: true,
  resistanceRatio: 0.85,
  watchSlidesProgress: false,
  grabCursor: false,
  preventClicks: true,
  preventClicksPropagation: true,
  slideToClickedSlide: false,
  loop: false,
  loopAddBlankSlides: true,
  loopAdditionalSlides: 0,
  loopPreventsSliding: true,
  rewind: false,
  allowSlidePrev: true,
  allowSlideNext: true,
  swipeHandler: null,
  noSwiping: true,
  noSwipingClass: "swiper-no-swiping",
  noSwipingSelector: null,
  passiveListeners: true,
  maxBackfaceHiddenSlides: 10,
  containerModifierClass: "swiper-",
  slideClass: "swiper-slide",
  slideBlankClass: "swiper-slide-blank",
  slideActiveClass: "swiper-slide-active",
  slideVisibleClass: "swiper-slide-visible",
  slideFullyVisibleClass: "swiper-slide-fully-visible",
  slideNextClass: "swiper-slide-next",
  slidePrevClass: "swiper-slide-prev",
  wrapperClass: "swiper-wrapper",
  lazyPreloaderClass: "swiper-lazy-preloader",
  lazyPreloadPrevNext: 0,
  runCallbacksOnInit: true,
  _emitClasses: false
};
function moduleExtendParams(params, allModulesParams) {
  return function extendParams(obj) {
    if (obj === void 0) {
      obj = {};
    }
    const moduleParamName = Object.keys(obj)[0];
    const moduleParams = obj[moduleParamName];
    if (typeof moduleParams !== "object" || moduleParams === null) {
      extend2(allModulesParams, obj);
      return;
    }
    if (params[moduleParamName] === true) {
      params[moduleParamName] = {
        enabled: true
      };
    }
    if (moduleParamName === "navigation" && params[moduleParamName] && params[moduleParamName].enabled && !params[moduleParamName].prevEl && !params[moduleParamName].nextEl) {
      params[moduleParamName].auto = true;
    }
    if (["pagination", "scrollbar"].indexOf(moduleParamName) >= 0 && params[moduleParamName] && params[moduleParamName].enabled && !params[moduleParamName].el) {
      params[moduleParamName].auto = true;
    }
    if (!(moduleParamName in params && "enabled" in moduleParams)) {
      extend2(allModulesParams, obj);
      return;
    }
    if (typeof params[moduleParamName] === "object" && !("enabled" in params[moduleParamName])) {
      params[moduleParamName].enabled = true;
    }
    if (!params[moduleParamName]) params[moduleParamName] = {
      enabled: false
    };
    extend2(allModulesParams, obj);
  };
}
var prototypes = {
  eventsEmitter,
  update,
  translate,
  transition,
  slide,
  loop,
  grabCursor,
  events: events$1,
  breakpoints,
  checkOverflow: checkOverflow$1,
  classes
};
var extendedDefaults = {};
var Swiper = class {
  constructor() {
    let el;
    let params;
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    if (args.length === 1 && args[0].constructor && Object.prototype.toString.call(args[0]).slice(8, -1) === "Object") {
      params = args[0];
    } else {
      [el, params] = args;
    }
    if (!params) params = {};
    params = extend2({}, params);
    if (el && !params.el) params.el = el;
    const document2 = getDocument();
    if (params.el && typeof params.el === "string" && document2.querySelectorAll(params.el).length > 1) {
      const swipers = [];
      document2.querySelectorAll(params.el).forEach(containerEl => {
        const newParams = extend2({}, params, {
          el: containerEl
        });
        swipers.push(new Swiper(newParams));
      });
      return swipers;
    }
    const swiper = this;
    swiper.__swiper__ = true;
    swiper.support = getSupport();
    swiper.device = getDevice({
      userAgent: params.userAgent
    });
    swiper.browser = getBrowser();
    swiper.eventsListeners = {};
    swiper.eventsAnyListeners = [];
    swiper.modules = [...swiper.__modules__];
    if (params.modules && Array.isArray(params.modules)) {
      swiper.modules.push(...params.modules);
    }
    const allModulesParams = {};
    swiper.modules.forEach(mod => {
      mod({
        params,
        swiper,
        extendParams: moduleExtendParams(params, allModulesParams),
        on: swiper.on.bind(swiper),
        once: swiper.once.bind(swiper),
        off: swiper.off.bind(swiper),
        emit: swiper.emit.bind(swiper)
      });
    });
    const swiperParams = extend2({}, defaults, allModulesParams);
    swiper.params = extend2({}, swiperParams, extendedDefaults, params);
    swiper.originalParams = extend2({}, swiper.params);
    swiper.passedParams = extend2({}, params);
    if (swiper.params && swiper.params.on) {
      Object.keys(swiper.params.on).forEach(eventName => {
        swiper.on(eventName, swiper.params.on[eventName]);
      });
    }
    if (swiper.params && swiper.params.onAny) {
      swiper.onAny(swiper.params.onAny);
    }
    Object.assign(swiper, {
      enabled: swiper.params.enabled,
      el,
      classNames: [],
      slides: [],
      slidesGrid: [],
      snapGrid: [],
      slidesSizesGrid: [],
      isHorizontal() {
        return swiper.params.direction === "horizontal";
      },
      isVertical() {
        return swiper.params.direction === "vertical";
      },
      activeIndex: 0,
      realIndex: 0,
      isBeginning: true,
      isEnd: false,
      translate: 0,
      previousTranslate: 0,
      progress: 0,
      velocity: 0,
      animating: false,
      cssOverflowAdjustment() {
        return Math.trunc(this.translate / 2 ** 23) * 2 ** 23;
      },
      allowSlideNext: swiper.params.allowSlideNext,
      allowSlidePrev: swiper.params.allowSlidePrev,
      touchEventsData: {
        isTouched: void 0,
        isMoved: void 0,
        allowTouchCallbacks: void 0,
        touchStartTime: void 0,
        isScrolling: void 0,
        currentTranslate: void 0,
        startTranslate: void 0,
        allowThresholdMove: void 0,
        focusableElements: swiper.params.focusableElements,
        lastClickTime: 0,
        clickTimeout: void 0,
        velocities: [],
        allowMomentumBounce: void 0,
        startMoving: void 0,
        pointerId: null,
        touchId: null
      },
      allowClick: true,
      allowTouchMove: swiper.params.allowTouchMove,
      touches: {
        startX: 0,
        startY: 0,
        currentX: 0,
        currentY: 0,
        diff: 0
      },
      imagesToLoad: [],
      imagesLoaded: 0
    });
    swiper.emit("_swiper");
    if (swiper.params.init) {
      swiper.init();
    }
    return swiper;
  }
  getDirectionLabel(property) {
    if (this.isHorizontal()) {
      return property;
    }
    return {
      "width": "height",
      "margin-top": "margin-left",
      "margin-bottom ": "margin-right",
      "margin-left": "margin-top",
      "margin-right": "margin-bottom",
      "padding-left": "padding-top",
      "padding-right": "padding-bottom",
      "marginRight": "marginBottom"
    }[property];
  }
  getSlideIndex(slideEl) {
    const {
      slidesEl,
      params
    } = this;
    const slides = elementChildren(slidesEl, `.${params.slideClass}, swiper-slide`);
    const firstSlideIndex = elementIndex(slides[0]);
    return elementIndex(slideEl) - firstSlideIndex;
  }
  getSlideIndexByData(index) {
    return this.getSlideIndex(this.slides.filter(slideEl => slideEl.getAttribute("data-swiper-slide-index") * 1 === index)[0]);
  }
  recalcSlides() {
    const swiper = this;
    const {
      slidesEl,
      params
    } = swiper;
    swiper.slides = elementChildren(slidesEl, `.${params.slideClass}, swiper-slide`);
  }
  enable() {
    const swiper = this;
    if (swiper.enabled) return;
    swiper.enabled = true;
    if (swiper.params.grabCursor) {
      swiper.setGrabCursor();
    }
    swiper.emit("enable");
  }
  disable() {
    const swiper = this;
    if (!swiper.enabled) return;
    swiper.enabled = false;
    if (swiper.params.grabCursor) {
      swiper.unsetGrabCursor();
    }
    swiper.emit("disable");
  }
  setProgress(progress, speed) {
    const swiper = this;
    progress = Math.min(Math.max(progress, 0), 1);
    const min = swiper.minTranslate();
    const max = swiper.maxTranslate();
    const current = (max - min) * progress + min;
    swiper.translateTo(current, typeof speed === "undefined" ? 0 : speed);
    swiper.updateActiveIndex();
    swiper.updateSlidesClasses();
  }
  emitContainerClasses() {
    const swiper = this;
    if (!swiper.params._emitClasses || !swiper.el) return;
    const cls = swiper.el.className.split(" ").filter(className => {
      return className.indexOf("swiper") === 0 || className.indexOf(swiper.params.containerModifierClass) === 0;
    });
    swiper.emit("_containerClasses", cls.join(" "));
  }
  getSlideClasses(slideEl) {
    const swiper = this;
    if (swiper.destroyed) return "";
    return slideEl.className.split(" ").filter(className => {
      return className.indexOf("swiper-slide") === 0 || className.indexOf(swiper.params.slideClass) === 0;
    }).join(" ");
  }
  emitSlidesClasses() {
    const swiper = this;
    if (!swiper.params._emitClasses || !swiper.el) return;
    const updates = [];
    swiper.slides.forEach(slideEl => {
      const classNames = swiper.getSlideClasses(slideEl);
      updates.push({
        slideEl,
        classNames
      });
      swiper.emit("_slideClass", slideEl, classNames);
    });
    swiper.emit("_slideClasses", updates);
  }
  slidesPerViewDynamic(view, exact) {
    if (view === void 0) {
      view = "current";
    }
    if (exact === void 0) {
      exact = false;
    }
    const swiper = this;
    const {
      params,
      slides,
      slidesGrid,
      slidesSizesGrid,
      size: swiperSize,
      activeIndex
    } = swiper;
    let spv = 1;
    if (typeof params.slidesPerView === "number") return params.slidesPerView;
    if (params.centeredSlides) {
      let slideSize = slides[activeIndex] ? Math.ceil(slides[activeIndex].swiperSlideSize) : 0;
      let breakLoop;
      for (let i = activeIndex + 1; i < slides.length; i += 1) {
        if (slides[i] && !breakLoop) {
          slideSize += Math.ceil(slides[i].swiperSlideSize);
          spv += 1;
          if (slideSize > swiperSize) breakLoop = true;
        }
      }
      for (let i = activeIndex - 1; i >= 0; i -= 1) {
        if (slides[i] && !breakLoop) {
          slideSize += slides[i].swiperSlideSize;
          spv += 1;
          if (slideSize > swiperSize) breakLoop = true;
        }
      }
    } else {
      if (view === "current") {
        for (let i = activeIndex + 1; i < slides.length; i += 1) {
          const slideInView = exact ? slidesGrid[i] + slidesSizesGrid[i] - slidesGrid[activeIndex] < swiperSize : slidesGrid[i] - slidesGrid[activeIndex] < swiperSize;
          if (slideInView) {
            spv += 1;
          }
        }
      } else {
        for (let i = activeIndex - 1; i >= 0; i -= 1) {
          const slideInView = slidesGrid[activeIndex] - slidesGrid[i] < swiperSize;
          if (slideInView) {
            spv += 1;
          }
        }
      }
    }
    return spv;
  }
  update() {
    const swiper = this;
    if (!swiper || swiper.destroyed) return;
    const {
      snapGrid,
      params
    } = swiper;
    if (params.breakpoints) {
      swiper.setBreakpoint();
    }
    [...swiper.el.querySelectorAll('[loading="lazy"]')].forEach(imageEl => {
      if (imageEl.complete) {
        processLazyPreloader(swiper, imageEl);
      }
    });
    swiper.updateSize();
    swiper.updateSlides();
    swiper.updateProgress();
    swiper.updateSlidesClasses();
    function setTranslate2() {
      const translateValue = swiper.rtlTranslate ? swiper.translate * -1 : swiper.translate;
      const newTranslate = Math.min(Math.max(translateValue, swiper.maxTranslate()), swiper.minTranslate());
      swiper.setTranslate(newTranslate);
      swiper.updateActiveIndex();
      swiper.updateSlidesClasses();
    }
    let translated;
    if (params.freeMode && params.freeMode.enabled && !params.cssMode) {
      setTranslate2();
      if (params.autoHeight) {
        swiper.updateAutoHeight();
      }
    } else {
      if ((params.slidesPerView === "auto" || params.slidesPerView > 1) && swiper.isEnd && !params.centeredSlides) {
        const slides = swiper.virtual && params.virtual.enabled ? swiper.virtual.slides : swiper.slides;
        translated = swiper.slideTo(slides.length - 1, 0, false, true);
      } else {
        translated = swiper.slideTo(swiper.activeIndex, 0, false, true);
      }
      if (!translated) {
        setTranslate2();
      }
    }
    if (params.watchOverflow && snapGrid !== swiper.snapGrid) {
      swiper.checkOverflow();
    }
    swiper.emit("update");
  }
  changeDirection(newDirection, needUpdate) {
    if (needUpdate === void 0) {
      needUpdate = true;
    }
    const swiper = this;
    const currentDirection = swiper.params.direction;
    if (!newDirection) {
      newDirection = currentDirection === "horizontal" ? "vertical" : "horizontal";
    }
    if (newDirection === currentDirection || newDirection !== "horizontal" && newDirection !== "vertical") {
      return swiper;
    }
    swiper.el.classList.remove(`${swiper.params.containerModifierClass}${currentDirection}`);
    swiper.el.classList.add(`${swiper.params.containerModifierClass}${newDirection}`);
    swiper.emitContainerClasses();
    swiper.params.direction = newDirection;
    swiper.slides.forEach(slideEl => {
      if (newDirection === "vertical") {
        slideEl.style.width = "";
      } else {
        slideEl.style.height = "";
      }
    });
    swiper.emit("changeDirection");
    if (needUpdate) swiper.update();
    return swiper;
  }
  changeLanguageDirection(direction) {
    const swiper = this;
    if (swiper.rtl && direction === "rtl" || !swiper.rtl && direction === "ltr") return;
    swiper.rtl = direction === "rtl";
    swiper.rtlTranslate = swiper.params.direction === "horizontal" && swiper.rtl;
    if (swiper.rtl) {
      swiper.el.classList.add(`${swiper.params.containerModifierClass}rtl`);
      swiper.el.dir = "rtl";
    } else {
      swiper.el.classList.remove(`${swiper.params.containerModifierClass}rtl`);
      swiper.el.dir = "ltr";
    }
    swiper.update();
  }
  mount(element) {
    const swiper = this;
    if (swiper.mounted) return true;
    let el = element || swiper.params.el;
    if (typeof el === "string") {
      el = document.querySelector(el);
    }
    if (!el) {
      return false;
    }
    el.swiper = swiper;
    if (el.parentNode && el.parentNode.host && el.parentNode.host.nodeName === swiper.params.swiperElementNodeName.toUpperCase()) {
      swiper.isElement = true;
    }
    const getWrapperSelector = () => {
      return `.${(swiper.params.wrapperClass || "").trim().split(" ").join(".")}`;
    };
    const getWrapper = () => {
      if (el && el.shadowRoot && el.shadowRoot.querySelector) {
        const res = el.shadowRoot.querySelector(getWrapperSelector());
        return res;
      }
      return elementChildren(el, getWrapperSelector())[0];
    };
    let wrapperEl = getWrapper();
    if (!wrapperEl && swiper.params.createElements) {
      wrapperEl = createElement("div", swiper.params.wrapperClass);
      el.append(wrapperEl);
      elementChildren(el, `.${swiper.params.slideClass}`).forEach(slideEl => {
        wrapperEl.append(slideEl);
      });
    }
    Object.assign(swiper, {
      el,
      wrapperEl,
      slidesEl: swiper.isElement && !el.parentNode.host.slideSlots ? el.parentNode.host : wrapperEl,
      hostEl: swiper.isElement ? el.parentNode.host : el,
      mounted: true,
      rtl: el.dir.toLowerCase() === "rtl" || elementStyle(el, "direction") === "rtl",
      rtlTranslate: swiper.params.direction === "horizontal" && (el.dir.toLowerCase() === "rtl" || elementStyle(el, "direction") === "rtl"),
      wrongRTL: elementStyle(wrapperEl, "display") === "-webkit-box"
    });
    return true;
  }
  init(el) {
    const swiper = this;
    if (swiper.initialized) return swiper;
    const mounted = swiper.mount(el);
    if (mounted === false) return swiper;
    swiper.emit("beforeInit");
    if (swiper.params.breakpoints) {
      swiper.setBreakpoint();
    }
    swiper.addClasses();
    swiper.updateSize();
    swiper.updateSlides();
    if (swiper.params.watchOverflow) {
      swiper.checkOverflow();
    }
    if (swiper.params.grabCursor && swiper.enabled) {
      swiper.setGrabCursor();
    }
    if (swiper.params.loop && swiper.virtual && swiper.params.virtual.enabled) {
      swiper.slideTo(swiper.params.initialSlide + swiper.virtual.slidesBefore, 0, swiper.params.runCallbacksOnInit, false, true);
    } else {
      swiper.slideTo(swiper.params.initialSlide, 0, swiper.params.runCallbacksOnInit, false, true);
    }
    if (swiper.params.loop) {
      swiper.loopCreate();
    }
    swiper.attachEvents();
    const lazyElements = [...swiper.el.querySelectorAll('[loading="lazy"]')];
    if (swiper.isElement) {
      lazyElements.push(...swiper.hostEl.querySelectorAll('[loading="lazy"]'));
    }
    lazyElements.forEach(imageEl => {
      if (imageEl.complete) {
        processLazyPreloader(swiper, imageEl);
      } else {
        imageEl.addEventListener("load", e => {
          processLazyPreloader(swiper, e.target);
        });
      }
    });
    preload(swiper);
    swiper.initialized = true;
    preload(swiper);
    swiper.emit("init");
    swiper.emit("afterInit");
    return swiper;
  }
  destroy(deleteInstance, cleanStyles) {
    if (deleteInstance === void 0) {
      deleteInstance = true;
    }
    if (cleanStyles === void 0) {
      cleanStyles = true;
    }
    const swiper = this;
    const {
      params,
      el,
      wrapperEl,
      slides
    } = swiper;
    if (typeof swiper.params === "undefined" || swiper.destroyed) {
      return null;
    }
    swiper.emit("beforeDestroy");
    swiper.initialized = false;
    swiper.detachEvents();
    if (params.loop) {
      swiper.loopDestroy();
    }
    if (cleanStyles) {
      swiper.removeClasses();
      el.removeAttribute("style");
      wrapperEl.removeAttribute("style");
      if (slides && slides.length) {
        slides.forEach(slideEl => {
          slideEl.classList.remove(params.slideVisibleClass, params.slideFullyVisibleClass, params.slideActiveClass, params.slideNextClass, params.slidePrevClass);
          slideEl.removeAttribute("style");
          slideEl.removeAttribute("data-swiper-slide-index");
        });
      }
    }
    swiper.emit("destroy");
    Object.keys(swiper.eventsListeners).forEach(eventName => {
      swiper.off(eventName);
    });
    if (deleteInstance !== false) {
      swiper.el.swiper = null;
      deleteProps(swiper);
    }
    swiper.destroyed = true;
    return null;
  }
  static extendDefaults(newDefaults) {
    extend2(extendedDefaults, newDefaults);
  }
  static get extendedDefaults() {
    return extendedDefaults;
  }
  static get defaults() {
    return defaults;
  }
  static installModule(mod) {
    if (!Swiper.prototype.__modules__) Swiper.prototype.__modules__ = [];
    const modules = Swiper.prototype.__modules__;
    if (typeof mod === "function" && modules.indexOf(mod) < 0) {
      modules.push(mod);
    }
  }
  static use(module2) {
    if (Array.isArray(module2)) {
      module2.forEach(m => Swiper.installModule(m));
      return Swiper;
    }
    Swiper.installModule(module2);
    return Swiper;
  }
};
Object.keys(prototypes).forEach(prototypeGroup => {
  Object.keys(prototypes[prototypeGroup]).forEach(protoMethod => {
    Swiper.prototype[protoMethod] = prototypes[prototypeGroup][protoMethod];
  });
});
Swiper.use([Resize, Observer]);

// .beyond/uimport/temp/swiper.11.1.3.js
var swiper_11_1_3_default = Swiper;
};

code(module, require);
_exports(module.exports);
}}});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy5iZXlvbmQvdWltcG9ydC90ZW1wL3N3aXBlci4xMS4xLjMuanMiLCIuLi9ub2RlX21vZHVsZXMvc3dpcGVyL3NoYXJlZC9zc3Itd2luZG93LmVzbS5tanMiLCIuLi9ub2RlX21vZHVsZXMvc3dpcGVyL3NoYXJlZC91dGlscy5tanMiLCIuLi9ub2RlX21vZHVsZXMvc3dpcGVyL3NoYXJlZC9zd2lwZXItY29yZS5tanMiXSwibmFtZXMiOlsic3dpcGVyXzExXzFfM19leHBvcnRzIiwiX19leHBvcnQiLCJTd2lwZXIiLCJkZWZhdWx0Iiwic3dpcGVyXzExXzFfM19kZWZhdWx0IiwibW9kdWxlIiwiZXhwb3J0cyIsIl9fdG9Db21tb25KUyIsImlzT2JqZWN0Iiwib2JqIiwiY29uc3RydWN0b3IiLCJPYmplY3QiLCJleHRlbmQiLCJ0YXJnZXQiLCJzcmMiLCJrZXlzIiwiZm9yRWFjaCIsImtleSIsImxlbmd0aCIsInNzckRvY3VtZW50IiwiYm9keSIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiYWN0aXZlRWxlbWVudCIsImJsdXIiLCJub2RlTmFtZSIsInF1ZXJ5U2VsZWN0b3IiLCJxdWVyeVNlbGVjdG9yQWxsIiwiZ2V0RWxlbWVudEJ5SWQiLCJjcmVhdGVFdmVudCIsImluaXRFdmVudCIsImNyZWF0ZUVsZW1lbnQiLCJjaGlsZHJlbiIsImNoaWxkTm9kZXMiLCJzdHlsZSIsInNldEF0dHJpYnV0ZSIsImdldEVsZW1lbnRzQnlUYWdOYW1lIiwiY3JlYXRlRWxlbWVudE5TIiwiaW1wb3J0Tm9kZSIsImxvY2F0aW9uIiwiaGFzaCIsImhvc3QiLCJob3N0bmFtZSIsImhyZWYiLCJvcmlnaW4iLCJwYXRobmFtZSIsInByb3RvY29sIiwic2VhcmNoIiwiZ2V0RG9jdW1lbnQiLCJkb2MiLCJkb2N1bWVudCIsInNzcldpbmRvdyIsIm5hdmlnYXRvciIsInVzZXJBZ2VudCIsImhpc3RvcnkiLCJyZXBsYWNlU3RhdGUiLCJwdXNoU3RhdGUiLCJnbyIsImJhY2siLCJDdXN0b21FdmVudCIsImdldENvbXB1dGVkU3R5bGUiLCJnZXRQcm9wZXJ0eVZhbHVlIiwiSW1hZ2UiLCJEYXRlIiwic2NyZWVuIiwic2V0VGltZW91dCIsImNsZWFyVGltZW91dCIsIm1hdGNoTWVkaWEiLCJyZXF1ZXN0QW5pbWF0aW9uRnJhbWUiLCJjYWxsYmFjayIsImNhbmNlbEFuaW1hdGlvbkZyYW1lIiwiaWQiLCJnZXRXaW5kb3ciLCJ3aW4iLCJ3aW5kb3ciLCJjbGFzc2VzVG9Ub2tlbnMiLCJjbGFzc2VzMiIsInRyaW0iLCJzcGxpdCIsImZpbHRlciIsImMiLCJkZWxldGVQcm9wcyIsIm9iamVjdCIsImUiLCJuZXh0VGljayIsImRlbGF5Iiwibm93IiwiZ2V0Q29tcHV0ZWRTdHlsZTIiLCJlbCIsIndpbmRvdzIiLCJjdXJyZW50U3R5bGUiLCJnZXRUcmFuc2xhdGUiLCJheGlzIiwibWF0cml4IiwiY3VyVHJhbnNmb3JtIiwidHJhbnNmb3JtTWF0cml4IiwiY3VyU3R5bGUiLCJXZWJLaXRDU1NNYXRyaXgiLCJ0cmFuc2Zvcm0iLCJ3ZWJraXRUcmFuc2Zvcm0iLCJtYXAiLCJhIiwicmVwbGFjZSIsImpvaW4iLCJNb3pUcmFuc2Zvcm0iLCJPVHJhbnNmb3JtIiwiTXNUcmFuc2Zvcm0iLCJtc1RyYW5zZm9ybSIsInRvU3RyaW5nIiwibTQxIiwicGFyc2VGbG9hdCIsIm00MiIsImlzT2JqZWN0MiIsIm8iLCJwcm90b3R5cGUiLCJjYWxsIiwic2xpY2UiLCJpc05vZGUiLCJub2RlIiwiSFRNTEVsZW1lbnQiLCJub2RlVHlwZSIsImV4dGVuZDIiLCJ0byIsImFyZ3VtZW50cyIsIm5vRXh0ZW5kIiwiaSIsIm5leHRTb3VyY2UiLCJrZXlzQXJyYXkiLCJpbmRleE9mIiwibmV4dEluZGV4IiwibGVuIiwibmV4dEtleSIsImRlc2MiLCJnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IiLCJlbnVtZXJhYmxlIiwiX19zd2lwZXJfXyIsInNldENTU1Byb3BlcnR5IiwidmFyTmFtZSIsInZhclZhbHVlIiwic2V0UHJvcGVydHkiLCJhbmltYXRlQ1NTTW9kZVNjcm9sbCIsIl9yZWYiLCJzd2lwZXIiLCJ0YXJnZXRQb3NpdGlvbiIsInNpZGUiLCJzdGFydFBvc2l0aW9uIiwidHJhbnNsYXRlIiwic3RhcnRUaW1lIiwidGltZSIsImR1cmF0aW9uIiwicGFyYW1zIiwic3BlZWQiLCJ3cmFwcGVyRWwiLCJzY3JvbGxTbmFwVHlwZSIsImNzc01vZGVGcmFtZUlEIiwiZGlyIiwiaXNPdXRPZkJvdW5kIiwiY3VycmVudCIsImFuaW1hdGUiLCJnZXRUaW1lIiwicHJvZ3Jlc3MiLCJNYXRoIiwibWF4IiwibWluIiwiZWFzZVByb2dyZXNzIiwiY29zIiwiUEkiLCJjdXJyZW50UG9zaXRpb24iLCJzY3JvbGxUbyIsIm92ZXJmbG93IiwiZ2V0U2xpZGVUcmFuc2Zvcm1FbCIsInNsaWRlRWwiLCJzaGFkb3dSb290IiwiZWxlbWVudENoaWxkcmVuIiwiZWxlbWVudCIsInNlbGVjdG9yIiwibWF0Y2hlcyIsInNob3dXYXJuaW5nIiwidGV4dCIsImNvbnNvbGUiLCJ3YXJuIiwiZXJyIiwidGFnIiwiY2xhc3NMaXN0IiwiYWRkIiwiQXJyYXkiLCJpc0FycmF5IiwiZWxlbWVudE9mZnNldCIsImRvY3VtZW50MiIsImJveCIsImdldEJvdW5kaW5nQ2xpZW50UmVjdCIsImNsaWVudFRvcCIsImNsaWVudExlZnQiLCJzY3JvbGxUb3AiLCJzY3JvbGxZIiwic2Nyb2xsTGVmdCIsInNjcm9sbFgiLCJ0b3AiLCJsZWZ0IiwiZWxlbWVudFByZXZBbGwiLCJwcmV2RWxzIiwicHJldmlvdXNFbGVtZW50U2libGluZyIsInByZXYiLCJwdXNoIiwiZWxlbWVudE5leHRBbGwiLCJuZXh0RWxzIiwibmV4dEVsZW1lbnRTaWJsaW5nIiwibmV4dCIsImVsZW1lbnRTdHlsZSIsInByb3AiLCJlbGVtZW50SW5kZXgiLCJjaGlsZCIsInByZXZpb3VzU2libGluZyIsImVsZW1lbnRQYXJlbnRzIiwicGFyZW50cyIsInBhcmVudCIsInBhcmVudEVsZW1lbnQiLCJlbGVtZW50VHJhbnNpdGlvbkVuZCIsImZpcmVDYWxsQmFjayIsImVsZW1lbnRPdXRlclNpemUiLCJzaXplIiwiaW5jbHVkZU1hcmdpbnMiLCJvZmZzZXRXaWR0aCIsIm1ha2VFbGVtZW50c0FycmF5Iiwic3VwcG9ydCIsImNhbGNTdXBwb3J0Iiwic21vb3RoU2Nyb2xsIiwiZG9jdW1lbnRFbGVtZW50IiwidG91Y2giLCJEb2N1bWVudFRvdWNoIiwiZ2V0U3VwcG9ydCIsImRldmljZUNhY2hlZCIsImNhbGNEZXZpY2UiLCJfdGVtcCIsInN1cHBvcnQyIiwicGxhdGZvcm0iLCJ1YSIsImRldmljZSIsImlvcyIsImFuZHJvaWQiLCJzY3JlZW5XaWR0aCIsIndpZHRoIiwic2NyZWVuSGVpZ2h0IiwiaGVpZ2h0IiwibWF0Y2giLCJpcGFkIiwiaXBvZCIsImlwaG9uZSIsIndpbmRvd3MiLCJtYWNvcyIsImlQYWRTY3JlZW5zIiwib3MiLCJnZXREZXZpY2UiLCJvdmVycmlkZXMiLCJicm93c2VyIiwiY2FsY0Jyb3dzZXIiLCJuZWVkUGVyc3BlY3RpdmVGaXgiLCJpc1NhZmFyaSIsInRvTG93ZXJDYXNlIiwiU3RyaW5nIiwiaW5jbHVkZXMiLCJtYWpvciIsIm1pbm9yIiwibnVtIiwiTnVtYmVyIiwiaXNXZWJWaWV3IiwidGVzdCIsImlzU2FmYXJpQnJvd3NlciIsIm5lZWQzZEZpeCIsImdldEJyb3dzZXIiLCJSZXNpemUiLCJvbiIsImVtaXQiLCJvYnNlcnZlciIsImFuaW1hdGlvbkZyYW1lIiwicmVzaXplSGFuZGxlciIsImRlc3Ryb3llZCIsImluaXRpYWxpemVkIiwiY3JlYXRlT2JzZXJ2ZXIiLCJSZXNpemVPYnNlcnZlciIsImVudHJpZXMiLCJuZXdXaWR0aCIsIm5ld0hlaWdodCIsIl9yZWYyIiwiY29udGVudEJveFNpemUiLCJjb250ZW50UmVjdCIsImlubGluZVNpemUiLCJibG9ja1NpemUiLCJvYnNlcnZlIiwicmVtb3ZlT2JzZXJ2ZXIiLCJ1bm9ic2VydmUiLCJvcmllbnRhdGlvbkNoYW5nZUhhbmRsZXIiLCJyZXNpemVPYnNlcnZlciIsIk9ic2VydmVyIiwiZXh0ZW5kUGFyYW1zIiwib2JzZXJ2ZXJzIiwiYXR0YWNoIiwib3B0aW9ucyIsIk9ic2VydmVyRnVuYyIsIk11dGF0aW9uT2JzZXJ2ZXIiLCJXZWJraXRNdXRhdGlvbk9ic2VydmVyIiwibXV0YXRpb25zIiwiX19wcmV2ZW50T2JzZXJ2ZXJfXyIsIm9ic2VydmVyVXBkYXRlIiwib2JzZXJ2ZXJVcGRhdGUyIiwiYXR0cmlidXRlcyIsImNoaWxkTGlzdCIsImNoYXJhY3RlckRhdGEiLCJpbml0Iiwib2JzZXJ2ZVBhcmVudHMiLCJjb250YWluZXJQYXJlbnRzIiwiaG9zdEVsIiwib2JzZXJ2ZVNsaWRlQ2hpbGRyZW4iLCJkZXN0cm95IiwiZGlzY29ubmVjdCIsInNwbGljZSIsImV2ZW50c0VtaXR0ZXIiLCJldmVudHMyIiwiaGFuZGxlciIsInByaW9yaXR5Iiwic2VsZiIsImV2ZW50c0xpc3RlbmVycyIsIm1ldGhvZCIsImV2ZW50Iiwib25jZSIsIm9uY2VIYW5kbGVyIiwib2ZmIiwiX19lbWl0dGVyUHJveHkiLCJfbGVuIiwiYXJncyIsIl9rZXkiLCJhcHBseSIsIm9uQW55IiwiZXZlbnRzQW55TGlzdGVuZXJzIiwib2ZmQW55IiwiaW5kZXgiLCJldmVudEhhbmRsZXIiLCJkYXRhIiwiY29udGV4dCIsIl9sZW4yIiwiX2tleTIiLCJldmVudHMiLCJ1bnNoaWZ0IiwiZXZlbnRzQXJyYXkiLCJ1cGRhdGVTaXplIiwiY2xpZW50V2lkdGgiLCJjbGllbnRIZWlnaHQiLCJpc0hvcml6b250YWwiLCJpc1ZlcnRpY2FsIiwicGFyc2VJbnQiLCJpc05hTiIsImFzc2lnbiIsInVwZGF0ZVNsaWRlcyIsImdldERpcmVjdGlvblByb3BlcnR5VmFsdWUiLCJsYWJlbCIsImdldERpcmVjdGlvbkxhYmVsIiwic2xpZGVzRWwiLCJzd2lwZXJTaXplIiwicnRsVHJhbnNsYXRlIiwicnRsIiwid3JvbmdSVEwiLCJpc1ZpcnR1YWwiLCJ2aXJ0dWFsIiwiZW5hYmxlZCIsInByZXZpb3VzU2xpZGVzTGVuZ3RoIiwic2xpZGVzIiwic2xpZGVDbGFzcyIsInNsaWRlc0xlbmd0aCIsInNuYXBHcmlkIiwic2xpZGVzR3JpZCIsInNsaWRlc1NpemVzR3JpZCIsIm9mZnNldEJlZm9yZSIsInNsaWRlc09mZnNldEJlZm9yZSIsIm9mZnNldEFmdGVyIiwic2xpZGVzT2Zmc2V0QWZ0ZXIiLCJwcmV2aW91c1NuYXBHcmlkTGVuZ3RoIiwicHJldmlvdXNTbGlkZXNHcmlkTGVuZ3RoIiwic3BhY2VCZXR3ZWVuIiwic2xpZGVQb3NpdGlvbiIsInByZXZTbGlkZVNpemUiLCJ2aXJ0dWFsU2l6ZSIsIm1hcmdpbkxlZnQiLCJtYXJnaW5SaWdodCIsIm1hcmdpbkJvdHRvbSIsIm1hcmdpblRvcCIsImNlbnRlcmVkU2xpZGVzIiwiY3NzTW9kZSIsImdyaWRFbmFibGVkIiwiZ3JpZCIsInJvd3MiLCJpbml0U2xpZGVzIiwidW5zZXRTbGlkZXMiLCJzbGlkZVNpemUiLCJzaG91bGRSZXNldFNsaWRlU2l6ZSIsInNsaWRlc1BlclZpZXciLCJicmVha3BvaW50cyIsInNsaWRlMiIsInVwZGF0ZVNsaWRlIiwic2xpZGVTdHlsZXMiLCJjdXJyZW50VHJhbnNmb3JtIiwiY3VycmVudFdlYktpdFRyYW5zZm9ybSIsInJvdW5kTGVuZ3RocyIsInBhZGRpbmdMZWZ0IiwicGFkZGluZ1JpZ2h0IiwiYm94U2l6aW5nIiwiZmxvb3IiLCJzd2lwZXJTbGlkZVNpemUiLCJhYnMiLCJzbGlkZXNQZXJHcm91cCIsInNsaWRlc1Blckdyb3VwU2tpcCIsImVmZmVjdCIsInNldFdyYXBwZXJTaXplIiwidXBkYXRlV3JhcHBlclNpemUiLCJuZXdTbGlkZXNHcmlkIiwic2xpZGVzR3JpZEl0ZW0iLCJsb29wIiwiZ3JvdXBzIiwiY2VpbCIsInNsaWRlc0JlZm9yZSIsInNsaWRlc0FmdGVyIiwiZ3JvdXBTaXplIiwiXyIsInNsaWRlSW5kZXgiLCJjZW50ZXJlZFNsaWRlc0JvdW5kcyIsImFsbFNsaWRlc1NpemUiLCJzbGlkZVNpemVWYWx1ZSIsIm1heFNuYXAiLCJzbmFwIiwiY2VudGVySW5zdWZmaWNpZW50U2xpZGVzIiwib2Zmc2V0U2l6ZSIsImFsbFNsaWRlc09mZnNldCIsInNuYXBJbmRleCIsImFkZFRvU25hcEdyaWQiLCJhZGRUb1NsaWRlc0dyaWQiLCJ2Iiwid2F0Y2hPdmVyZmxvdyIsImNoZWNrT3ZlcmZsb3ciLCJ3YXRjaFNsaWRlc1Byb2dyZXNzIiwidXBkYXRlU2xpZGVzT2Zmc2V0IiwiYmFja0ZhY2VIaWRkZW5DbGFzcyIsImNvbnRhaW5lck1vZGlmaWVyQ2xhc3MiLCJoYXNDbGFzc0JhY2tmYWNlQ2xhc3NBZGRlZCIsImNvbnRhaW5zIiwibWF4QmFja2ZhY2VIaWRkZW5TbGlkZXMiLCJyZW1vdmUiLCJ1cGRhdGVBdXRvSGVpZ2h0IiwiYWN0aXZlU2xpZGVzIiwic2V0VHJhbnNpdGlvbiIsImdldFNsaWRlQnlJbmRleCIsImdldFNsaWRlSW5kZXhCeURhdGEiLCJ2aXNpYmxlU2xpZGVzIiwiYWN0aXZlSW5kZXgiLCJvZmZzZXRIZWlnaHQiLCJtaW51c09mZnNldCIsImlzRWxlbWVudCIsIm9mZnNldExlZnQiLCJvZmZzZXRUb3AiLCJzd2lwZXJTbGlkZU9mZnNldCIsImNzc092ZXJmbG93QWRqdXN0bWVudCIsInRvZ2dsZVNsaWRlQ2xhc3NlcyQxIiwiY29uZGl0aW9uIiwiY2xhc3NOYW1lIiwidXBkYXRlU2xpZGVzUHJvZ3Jlc3MiLCJ0cmFuc2xhdGUyIiwib2Zmc2V0Q2VudGVyIiwidmlzaWJsZVNsaWRlc0luZGV4ZXMiLCJzbGlkZU9mZnNldCIsInNsaWRlUHJvZ3Jlc3MiLCJtaW5UcmFuc2xhdGUiLCJvcmlnaW5hbFNsaWRlUHJvZ3Jlc3MiLCJzbGlkZUJlZm9yZSIsInNsaWRlQWZ0ZXIiLCJpc0Z1bGx5VmlzaWJsZSIsImlzVmlzaWJsZSIsInNsaWRlVmlzaWJsZUNsYXNzIiwic2xpZGVGdWxseVZpc2libGVDbGFzcyIsIm9yaWdpbmFsUHJvZ3Jlc3MiLCJ1cGRhdGVQcm9ncmVzcyIsIm11bHRpcGxpZXIiLCJ0cmFuc2xhdGVzRGlmZiIsIm1heFRyYW5zbGF0ZSIsImlzQmVnaW5uaW5nIiwiaXNFbmQiLCJwcm9ncmVzc0xvb3AiLCJ3YXNCZWdpbm5pbmciLCJ3YXNFbmQiLCJpc0JlZ2lubmluZ1JvdW5kZWQiLCJpc0VuZFJvdW5kZWQiLCJmaXJzdFNsaWRlSW5kZXgiLCJsYXN0U2xpZGVJbmRleCIsImZpcnN0U2xpZGVUcmFuc2xhdGUiLCJsYXN0U2xpZGVUcmFuc2xhdGUiLCJ0cmFuc2xhdGVNYXgiLCJ0cmFuc2xhdGVBYnMiLCJhdXRvSGVpZ2h0IiwidG9nZ2xlU2xpZGVDbGFzc2VzIiwidXBkYXRlU2xpZGVzQ2xhc3NlcyIsImdldEZpbHRlcmVkU2xpZGUiLCJhY3RpdmVTbGlkZSIsInByZXZTbGlkZSIsIm5leHRTbGlkZSIsImNvbHVtbiIsInNsaWRlQWN0aXZlQ2xhc3MiLCJzbGlkZU5leHRDbGFzcyIsInNsaWRlUHJldkNsYXNzIiwiZW1pdFNsaWRlc0NsYXNzZXMiLCJwcm9jZXNzTGF6eVByZWxvYWRlciIsImltYWdlRWwiLCJzbGlkZVNlbGVjdG9yIiwiY2xvc2VzdCIsImxhenlFbCIsImxhenlQcmVsb2FkZXJDbGFzcyIsInVubGF6eSIsInJlbW92ZUF0dHJpYnV0ZSIsInByZWxvYWQiLCJhbW91bnQiLCJsYXp5UHJlbG9hZFByZXZOZXh0Iiwic2xpZGVzUGVyVmlld0R5bmFtaWMiLCJhY3RpdmVDb2x1bW4iLCJwcmVsb2FkQ29sdW1ucyIsImZyb20iLCJzbGlkZUluZGV4TGFzdEluVmlldyIsInJld2luZCIsInJlYWxJbmRleCIsImdldEFjdGl2ZUluZGV4QnlUcmFuc2xhdGUiLCJub3JtYWxpemVTbGlkZUluZGV4IiwidXBkYXRlQWN0aXZlSW5kZXgiLCJuZXdBY3RpdmVJbmRleCIsInByZXZpb3VzSW5kZXgiLCJwcmV2aW91c1JlYWxJbmRleCIsInByZXZpb3VzU25hcEluZGV4IiwiZ2V0VmlydHVhbFJlYWxJbmRleCIsImFJbmRleCIsInJlYWxJbmRleDIiLCJza2lwIiwiZmlyc3RTbGlkZUluQ29sdW1uIiwiYWN0aXZlU2xpZGVJbmRleCIsImdldEF0dHJpYnV0ZSIsInJ1bkNhbGxiYWNrc09uSW5pdCIsInVwZGF0ZUNsaWNrZWRTbGlkZSIsInBhdGgiLCJwYXRoRWwiLCJzbGlkZUZvdW5kIiwiY2xpY2tlZFNsaWRlIiwiY2xpY2tlZEluZGV4Iiwic2xpZGVUb0NsaWNrZWRTbGlkZSIsInVwZGF0ZSIsImdldFN3aXBlclRyYW5zbGF0ZSIsInZpcnR1YWxUcmFuc2xhdGUiLCJjdXJyZW50VHJhbnNsYXRlIiwic2V0VHJhbnNsYXRlIiwiYnlDb250cm9sbGVyIiwieCIsInkiLCJ6IiwicHJldmlvdXNUcmFuc2xhdGUiLCJuZXdQcm9ncmVzcyIsInRyYW5zbGF0ZVRvIiwicnVuQ2FsbGJhY2tzIiwidHJhbnNsYXRlQm91bmRzIiwiaW50ZXJuYWwiLCJhbmltYXRpbmciLCJwcmV2ZW50SW50ZXJhY3Rpb25PblRyYW5zaXRpb24iLCJtaW5UcmFuc2xhdGUyIiwibWF4VHJhbnNsYXRlMiIsIm5ld1RyYW5zbGF0ZSIsImlzSCIsImJlaGF2aW9yIiwib25UcmFuc2xhdGVUb1dyYXBwZXJUcmFuc2l0aW9uRW5kIiwidHJhbnNpdGlvbkVuZDIiLCJ0cmFuc2l0aW9uRHVyYXRpb24iLCJ0cmFuc2l0aW9uRGVsYXkiLCJ0cmFuc2l0aW9uRW1pdCIsImRpcmVjdGlvbiIsInN0ZXAiLCJ0cmFuc2l0aW9uU3RhcnQiLCJ0cmFuc2l0aW9uRW5kIiwidHJhbnNpdGlvbiIsInNsaWRlVG8iLCJpbml0aWFsIiwibm9ybWFsaXplZFRyYW5zbGF0ZSIsIm5vcm1hbGl6ZWRHcmlkIiwibm9ybWFsaXplZEdyaWROZXh0IiwiYWxsb3dTbGlkZU5leHQiLCJhbGxvd1NsaWRlUHJldiIsInQiLCJfaW1tZWRpYXRlVmlydHVhbCIsIl9jc3NNb2RlVmlydHVhbEluaXRpYWxTZXQiLCJpbml0aWFsU2xpZGUiLCJvblNsaWRlVG9XcmFwcGVyVHJhbnNpdGlvbkVuZCIsInNsaWRlVG9Mb29wIiwiaW5kZXhBc051bWJlciIsIm5ld0luZGV4IiwidGFyZ2V0U2xpZGVJbmRleCIsImNvbHMiLCJuZWVkTG9vcEZpeCIsImxvb3BGaXgiLCJzbGlkZVJlYWxJbmRleCIsInNsaWRlTmV4dCIsInBlckdyb3VwIiwic2xpZGVzUGVyR3JvdXBBdXRvIiwiaW5jcmVtZW50IiwibG9vcFByZXZlbnRzU2xpZGluZyIsIl9jbGllbnRMZWZ0Iiwic2xpZGVQcmV2Iiwibm9ybWFsaXplIiwidmFsIiwibm9ybWFsaXplZFNuYXBHcmlkIiwicHJldlNuYXAiLCJwcmV2U25hcEluZGV4IiwicHJldkluZGV4IiwibGFzdEluZGV4Iiwic2xpZGVSZXNldCIsInNsaWRlVG9DbG9zZXN0IiwidGhyZXNob2xkIiwiY3VycmVudFNuYXAiLCJuZXh0U25hcCIsInNsaWRlVG9JbmRleCIsImxvb3BlZFNsaWRlcyIsImdldFNsaWRlSW5kZXgiLCJzbGlkZSIsImxvb3BDcmVhdGUiLCJzaG91bGRGaWxsR3JvdXAiLCJzaG91bGRGaWxsR3JpZCIsImFkZEJsYW5rU2xpZGVzIiwiYW1vdW50T2ZTbGlkZXMiLCJzbGlkZUJsYW5rQ2xhc3MiLCJhcHBlbmQiLCJsb29wQWRkQmxhbmtTbGlkZXMiLCJzbGlkZXNUb0FkZCIsInJlY2FsY1NsaWRlcyIsInNsaWRlVG8yIiwic2V0VHJhbnNsYXRlMiIsImJ5TW91c2V3aGVlbCIsImxvb3BBZGRpdGlvbmFsU2xpZGVzIiwiZmlsbCIsInByZXBlbmRTbGlkZXNJbmRleGVzIiwiYXBwZW5kU2xpZGVzSW5kZXhlcyIsImlzTmV4dCIsImlzUHJldiIsInNsaWRlc1ByZXBlbmRlZCIsInNsaWRlc0FwcGVuZGVkIiwiYWN0aXZlQ29sSW5kZXgiLCJhY3RpdmVDb2xJbmRleFdpdGhTaGlmdCIsImNvbEluZGV4VG9QcmVwZW5kIiwiaTIiLCJzd2lwZXJMb29wTW92ZURPTSIsInByZXBlbmQiLCJjdXJyZW50U2xpZGVUcmFuc2xhdGUiLCJuZXdTbGlkZVRyYW5zbGF0ZSIsImRpZmYiLCJ0b3VjaEV2ZW50c0RhdGEiLCJzdGFydFRyYW5zbGF0ZSIsInNoaWZ0IiwiY29udHJvbGxlciIsImNvbnRyb2wiLCJsb29wUGFyYW1zIiwibG9vcERlc3Ryb3kiLCJuZXdTbGlkZXNPcmRlciIsInN3aXBlclNsaWRlSW5kZXgiLCJzZXRHcmFiQ3Vyc29yIiwibW92aW5nIiwic2ltdWxhdGVUb3VjaCIsImlzTG9ja2VkIiwidG91Y2hFdmVudHNUYXJnZXQiLCJjdXJzb3IiLCJ1bnNldEdyYWJDdXJzb3IiLCJncmFiQ3Vyc29yIiwiY2xvc2VzdEVsZW1lbnQiLCJiYXNlIiwiX19jbG9zZXN0RnJvbSIsImFzc2lnbmVkU2xvdCIsImZvdW5kIiwiZ2V0Um9vdE5vZGUiLCJwcmV2ZW50RWRnZVN3aXBlIiwic3RhcnRYIiwiZWRnZVN3aXBlRGV0ZWN0aW9uIiwiZWRnZVN3aXBlVGhyZXNob2xkIiwiaW5uZXJXaWR0aCIsInByZXZlbnREZWZhdWx0Iiwib25Ub3VjaFN0YXJ0Iiwib3JpZ2luYWxFdmVudCIsInR5cGUiLCJwb2ludGVySWQiLCJ0YXJnZXRUb3VjaGVzIiwidG91Y2hJZCIsImlkZW50aWZpZXIiLCJwYWdlWCIsInRvdWNoZXMiLCJwb2ludGVyVHlwZSIsInRhcmdldEVsIiwid2hpY2giLCJidXR0b24iLCJpc1RvdWNoZWQiLCJpc01vdmVkIiwic3dpcGluZ0NsYXNzSGFzVmFsdWUiLCJub1N3aXBpbmdDbGFzcyIsImV2ZW50UGF0aCIsImNvbXBvc2VkUGF0aCIsIm5vU3dpcGluZ1NlbGVjdG9yIiwiaXNUYXJnZXRTaGFkb3ciLCJub1N3aXBpbmciLCJhbGxvd0NsaWNrIiwic3dpcGVIYW5kbGVyIiwiY3VycmVudFgiLCJjdXJyZW50WSIsInBhZ2VZIiwic3RhcnRZIiwiYWxsb3dUb3VjaENhbGxiYWNrcyIsImlzU2Nyb2xsaW5nIiwic3RhcnRNb3ZpbmciLCJ0b3VjaFN0YXJ0VGltZSIsInN3aXBlRGlyZWN0aW9uIiwiYWxsb3dUaHJlc2hvbGRNb3ZlIiwiZm9jdXNhYmxlRWxlbWVudHMiLCJzaG91bGRQcmV2ZW50RGVmYXVsdCIsImFsbG93VG91Y2hNb3ZlIiwidG91Y2hTdGFydFByZXZlbnREZWZhdWx0IiwidG91Y2hTdGFydEZvcmNlUHJldmVudERlZmF1bHQiLCJpc0NvbnRlbnRFZGl0YWJsZSIsImZyZWVNb2RlIiwib25Ub3VjaE1vdmUiLCJ0YXJnZXRUb3VjaCIsImNoYW5nZWRUb3VjaGVzIiwicHJldmVudGVkQnlOZXN0ZWRTd2lwZXIiLCJ0b3VjaFJlbGVhc2VPbkVkZ2VzIiwicHJldmlvdXNYIiwicHJldmlvdXNZIiwiZGlmZlgiLCJkaWZmWSIsInNxcnQiLCJ0b3VjaEFuZ2xlIiwiYXRhbjIiLCJwcmV2ZW50VG91Y2hNb3ZlRnJvbVBvaW50ZXJNb3ZlIiwiY2FuY2VsYWJsZSIsInRvdWNoTW92ZVN0b3BQcm9wYWdhdGlvbiIsIm5lc3RlZCIsInN0b3BQcm9wYWdhdGlvbiIsInRvdWNoZXNEaWZmIiwib25lV2F5TW92ZW1lbnQiLCJ0b3VjaFJhdGlvIiwicHJldlRvdWNoZXNEaXJlY3Rpb24iLCJ0b3VjaGVzRGlyZWN0aW9uIiwiaXNMb29wIiwiYWxsb3dMb29wRml4IiwiZXZ0IiwiYnViYmxlcyIsImRldGFpbCIsImJ5U3dpcGVyVG91Y2hNb3ZlIiwiZGlzcGF0Y2hFdmVudCIsImFsbG93TW9tZW50dW1Cb3VuY2UiLCJsb29wRml4ZWQiLCJsb29wU3dhcFJlc2V0IiwiZGlzYWJsZVBhcmVudFN3aXBlciIsInJlc2lzdGFuY2VSYXRpbyIsInJlc2lzdGFuY2UiLCJmb2xsb3dGaW5nZXIiLCJvblRvdWNoRW5kIiwiaXNUb3VjaEV2ZW50IiwicHJvY2VlZCIsInRvdWNoRW5kVGltZSIsInRpbWVEaWZmIiwicGF0aFRyZWUiLCJsYXN0Q2xpY2tUaW1lIiwiY3VycmVudFBvcyIsInN3aXBlVG9MYXN0Iiwic3RvcEluZGV4IiwiaW5jcmVtZW50MiIsInJld2luZEZpcnN0SW5kZXgiLCJyZXdpbmRMYXN0SW5kZXgiLCJyYXRpbyIsImxvbmdTd2lwZXNNcyIsImxvbmdTd2lwZXMiLCJsb25nU3dpcGVzUmF0aW8iLCJzaG9ydFN3aXBlcyIsImlzTmF2QnV0dG9uVGFyZ2V0IiwibmF2aWdhdGlvbiIsIm5leHRFbCIsInByZXZFbCIsIm9uUmVzaXplIiwic2V0QnJlYWtwb2ludCIsImlzVmlydHVhbExvb3AiLCJhdXRvcGxheSIsInJ1bm5pbmciLCJwYXVzZWQiLCJyZXNpemVUaW1lb3V0IiwicmVzdW1lIiwib25DbGljayIsInByZXZlbnRDbGlja3MiLCJwcmV2ZW50Q2xpY2tzUHJvcGFnYXRpb24iLCJzdG9wSW1tZWRpYXRlUHJvcGFnYXRpb24iLCJvblNjcm9sbCIsIm9uTG9hZCIsIm9uRG9jdW1lbnRUb3VjaFN0YXJ0IiwiZG9jdW1lbnRUb3VjaEhhbmRsZXJQcm9jZWVkZWQiLCJ0b3VjaEFjdGlvbiIsImNhcHR1cmUiLCJkb21NZXRob2QiLCJzd2lwZXJNZXRob2QiLCJwYXNzaXZlIiwidXBkYXRlT25XaW5kb3dSZXNpemUiLCJhdHRhY2hFdmVudHMiLCJiaW5kIiwiZGV0YWNoRXZlbnRzIiwiZXZlbnRzJDEiLCJpc0dyaWRFbmFibGVkIiwiYnJlYWtwb2ludHMyIiwiYnJlYWtwb2ludCIsImdldEJyZWFrcG9pbnQiLCJicmVha3BvaW50c0Jhc2UiLCJjdXJyZW50QnJlYWtwb2ludCIsImJyZWFrcG9pbnRPbmx5UGFyYW1zIiwiYnJlYWtwb2ludFBhcmFtcyIsIm9yaWdpbmFsUGFyYW1zIiwid2FzTXVsdGlSb3ciLCJpc011bHRpUm93Iiwid2FzR3JhYkN1cnNvciIsImlzR3JhYkN1cnNvciIsIndhc0VuYWJsZWQiLCJlbWl0Q29udGFpbmVyQ2xhc3NlcyIsIndhc01vZHVsZUVuYWJsZWQiLCJpc01vZHVsZUVuYWJsZWQiLCJkaXNhYmxlIiwiZW5hYmxlIiwiZGlyZWN0aW9uQ2hhbmdlZCIsIm5lZWRzUmVMb29wIiwid2FzTG9vcCIsImNoYW5nZURpcmVjdGlvbiIsImlzRW5hYmxlZCIsImhhc0xvb3AiLCJjb250YWluZXJFbCIsImN1cnJlbnRIZWlnaHQiLCJpbm5lckhlaWdodCIsInBvaW50cyIsInBvaW50IiwibWluUmF0aW8iLCJzdWJzdHIiLCJ2YWx1ZSIsInNvcnQiLCJiIiwicHJlcGFyZUNsYXNzZXMiLCJwcmVmaXgiLCJyZXN1bHRDbGFzc2VzIiwiaXRlbSIsImNsYXNzTmFtZXMiLCJhZGRDbGFzc2VzIiwic3VmZml4ZXMiLCJyZW1vdmVDbGFzc2VzIiwiY2xhc3NlcyIsIndhc0xvY2tlZCIsImxhc3RTbGlkZVJpZ2h0RWRnZSIsImNoZWNrT3ZlcmZsb3ckMSIsImRlZmF1bHRzIiwic3dpcGVyRWxlbWVudE5vZGVOYW1lIiwiY3JlYXRlRWxlbWVudHMiLCJldmVudHNQcmVmaXgiLCJ1cmwiLCJ1bmlxdWVOYXZFbGVtZW50cyIsInBhc3NpdmVMaXN0ZW5lcnMiLCJ3cmFwcGVyQ2xhc3MiLCJfZW1pdENsYXNzZXMiLCJtb2R1bGVFeHRlbmRQYXJhbXMiLCJhbGxNb2R1bGVzUGFyYW1zIiwibW9kdWxlUGFyYW1OYW1lIiwibW9kdWxlUGFyYW1zIiwiYXV0byIsInByb3RvdHlwZXMiLCJleHRlbmRlZERlZmF1bHRzIiwic3dpcGVycyIsIm5ld1BhcmFtcyIsIm1vZHVsZXMiLCJfX21vZHVsZXNfXyIsIm1vZCIsInN3aXBlclBhcmFtcyIsInBhc3NlZFBhcmFtcyIsImV2ZW50TmFtZSIsInZlbG9jaXR5IiwidHJ1bmMiLCJjbGlja1RpbWVvdXQiLCJ2ZWxvY2l0aWVzIiwiaW1hZ2VzVG9Mb2FkIiwiaW1hZ2VzTG9hZGVkIiwicHJvcGVydHkiLCJzZXRQcm9ncmVzcyIsImNscyIsImdldFNsaWRlQ2xhc3NlcyIsInVwZGF0ZXMiLCJ2aWV3IiwiZXhhY3QiLCJzcHYiLCJicmVha0xvb3AiLCJzbGlkZUluVmlldyIsImNvbXBsZXRlIiwidHJhbnNsYXRlVmFsdWUiLCJ0cmFuc2xhdGVkIiwibmV3RGlyZWN0aW9uIiwibmVlZFVwZGF0ZSIsImN1cnJlbnREaXJlY3Rpb24iLCJjaGFuZ2VMYW5ndWFnZURpcmVjdGlvbiIsIm1vdW50IiwibW91bnRlZCIsInBhcmVudE5vZGUiLCJ0b1VwcGVyQ2FzZSIsImdldFdyYXBwZXJTZWxlY3RvciIsImdldFdyYXBwZXIiLCJyZXMiLCJzbGlkZVNsb3RzIiwibGF6eUVsZW1lbnRzIiwiZGVsZXRlSW5zdGFuY2UiLCJjbGVhblN0eWxlcyIsImV4dGVuZERlZmF1bHRzIiwibmV3RGVmYXVsdHMiLCJpbnN0YWxsTW9kdWxlIiwidXNlIiwibW9kdWxlMiIsIm0iLCJwcm90b3R5cGVHcm91cCIsInByb3RvTWV0aG9kIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSxxQkFBQTtBQUFBQyxRQUFBLENBQUFELHFCQUFBO0VBQUFFLE1BQUEsRUFBQUEsQ0FBQSxLQUFBQSxNQUFBO0VBQUFDLE9BQUEsRUFBQUEsQ0FBQSxLQUFBQztBQUFBO0FBQUFDLE1BQUEsQ0FBQUMsT0FBQSxHQUFBQyxZQUFBLENBQUFQLHFCQUFBOzs7QUNZQSxTQUFTUSxTQUFTQyxHQUFBLEVBQUs7RUFDckIsT0FBT0EsR0FBQSxLQUFRLFFBQVEsT0FBT0EsR0FBQSxLQUFRLFlBQVksaUJBQWlCQSxHQUFBLElBQU9BLEdBQUEsQ0FBSUMsV0FBQSxLQUFnQkMsTUFBQTtBQUNoRztBQUNBLFNBQVNDLE9BQU9DLE1BQUEsRUFBUUMsR0FBQSxFQUFLO0VBQzNCLElBQUlELE1BQUEsS0FBVyxRQUFRO0lBQ3JCQSxNQUFBLEdBQVMsQ0FBQztFQUNaO0VBQ0EsSUFBSUMsR0FBQSxLQUFRLFFBQVE7SUFDbEJBLEdBQUEsR0FBTSxDQUFDO0VBQ1Q7RUFDQUgsTUFBQSxDQUFPSSxJQUFBLENBQUtELEdBQUcsRUFBRUUsT0FBQSxDQUFRQyxHQUFBLElBQU87SUFDOUIsSUFBSSxPQUFPSixNQUFBLENBQU9JLEdBQUEsTUFBUyxhQUFhSixNQUFBLENBQU9JLEdBQUEsSUFBT0gsR0FBQSxDQUFJRyxHQUFBLFdBQWNULFFBQUEsQ0FBU00sR0FBQSxDQUFJRyxHQUFBLENBQUksS0FBS1QsUUFBQSxDQUFTSyxNQUFBLENBQU9JLEdBQUEsQ0FBSSxLQUFLTixNQUFBLENBQU9JLElBQUEsQ0FBS0QsR0FBQSxDQUFJRyxHQUFBLENBQUksRUFBRUMsTUFBQSxHQUFTLEdBQUc7TUFDdkpOLE1BQUEsQ0FBT0MsTUFBQSxDQUFPSSxHQUFBLEdBQU1ILEdBQUEsQ0FBSUcsR0FBQSxDQUFJO0lBQzlCO0VBQ0YsQ0FBQztBQUNIO0FBQ0EsSUFBTUUsV0FBQSxHQUFjO0VBQ2xCQyxJQUFBLEVBQU0sQ0FBQztFQUNQQyxpQkFBQSxFQUFtQixDQUFDO0VBQ3BCQyxvQkFBQSxFQUFzQixDQUFDO0VBQ3ZCQyxhQUFBLEVBQWU7SUFDYkMsS0FBQSxFQUFPLENBQUM7SUFDUkMsUUFBQSxFQUFVO0VBQ1o7RUFDQUMsY0FBQSxFQUFnQjtJQUNkLE9BQU87RUFDVDtFQUNBQyxpQkFBQSxFQUFtQjtJQUNqQixPQUFPLEVBQUM7RUFDVjtFQUNBQyxlQUFBLEVBQWlCO0lBQ2YsT0FBTztFQUNUO0VBQ0FDLFlBQUEsRUFBYztJQUNaLE9BQU87TUFDTEMsVUFBQSxFQUFZLENBQUM7SUFDZjtFQUNGO0VBQ0FDLGNBQUEsRUFBZ0I7SUFDZCxPQUFPO01BQ0xDLFFBQUEsRUFBVSxFQUFDO01BQ1hDLFVBQUEsRUFBWSxFQUFDO01BQ2JDLEtBQUEsRUFBTyxDQUFDO01BQ1JDLGFBQUEsRUFBZSxDQUFDO01BQ2hCQyxxQkFBQSxFQUF1QjtRQUNyQixPQUFPLEVBQUM7TUFDVjtJQUNGO0VBQ0Y7RUFDQUMsZ0JBQUEsRUFBa0I7SUFDaEIsT0FBTyxDQUFDO0VBQ1Y7RUFDQUMsV0FBQSxFQUFhO0lBQ1gsT0FBTztFQUNUO0VBQ0FDLFFBQUEsRUFBVTtJQUNSQyxJQUFBLEVBQU07SUFDTkMsSUFBQSxFQUFNO0lBQ05DLFFBQUEsRUFBVTtJQUNWQyxJQUFBLEVBQU07SUFDTkMsTUFBQSxFQUFRO0lBQ1JDLFFBQUEsRUFBVTtJQUNWQyxRQUFBLEVBQVU7SUFDVkMsTUFBQSxFQUFRO0VBQ1Y7QUFDRjtBQUNBLFNBQVNDLFlBQUEsRUFBYztFQUNyQixNQUFNQyxHQUFBLEdBQU0sT0FBT0MsUUFBQSxLQUFhLGNBQWNBLFFBQUEsR0FBVyxDQUFDO0VBQzFEdEMsTUFBQSxDQUFPcUMsR0FBQSxFQUFLOUIsV0FBVztFQUN2QixPQUFPOEIsR0FBQTtBQUNUO0FBQ0EsSUFBTUUsU0FBQSxHQUFZO0VBQ2hCRCxRQUFBLEVBQVUvQixXQUFBO0VBQ1ZpQyxTQUFBLEVBQVc7SUFDVEMsU0FBQSxFQUFXO0VBQ2I7RUFDQWQsUUFBQSxFQUFVO0lBQ1JDLElBQUEsRUFBTTtJQUNOQyxJQUFBLEVBQU07SUFDTkMsUUFBQSxFQUFVO0lBQ1ZDLElBQUEsRUFBTTtJQUNOQyxNQUFBLEVBQVE7SUFDUkMsUUFBQSxFQUFVO0lBQ1ZDLFFBQUEsRUFBVTtJQUNWQyxNQUFBLEVBQVE7RUFDVjtFQUNBTyxPQUFBLEVBQVM7SUFDUEMsYUFBQSxFQUFlLENBQUM7SUFDaEJDLFVBQUEsRUFBWSxDQUFDO0lBQ2JDLEdBQUEsRUFBSyxDQUFDO0lBQ05DLEtBQUEsRUFBTyxDQUFDO0VBQ1Y7RUFDQUMsV0FBQSxFQUFhLFNBQVNBLFlBQUEsRUFBYztJQUNsQyxPQUFPO0VBQ1Q7RUFDQXRDLGlCQUFBLEVBQW1CLENBQUM7RUFDcEJDLG9CQUFBLEVBQXNCLENBQUM7RUFDdkJzQyxpQkFBQSxFQUFtQjtJQUNqQixPQUFPO01BQ0xDLGlCQUFBLEVBQW1CO1FBQ2pCLE9BQU87TUFDVDtJQUNGO0VBQ0Y7RUFDQUMsTUFBQSxFQUFRLENBQUM7RUFDVEMsS0FBQSxFQUFPLENBQUM7RUFDUkMsTUFBQSxFQUFRLENBQUM7RUFDVEMsV0FBQSxFQUFhLENBQUM7RUFDZEMsYUFBQSxFQUFlLENBQUM7RUFDaEJDLFdBQUEsRUFBYTtJQUNYLE9BQU8sQ0FBQztFQUNWO0VBQ0FDLHNCQUFzQkMsUUFBQSxFQUFVO0lBQzlCLElBQUksT0FBT0osVUFBQSxLQUFlLGFBQWE7TUFDckNJLFFBQUEsQ0FBUztNQUNULE9BQU87SUFDVDtJQUNBLE9BQU9KLFVBQUEsQ0FBV0ksUUFBQSxFQUFVLENBQUM7RUFDL0I7RUFDQUMscUJBQXFCQyxFQUFBLEVBQUk7SUFDdkIsSUFBSSxPQUFPTixVQUFBLEtBQWUsYUFBYTtNQUNyQztJQUNGO0lBQ0FDLFlBQUEsQ0FBYUssRUFBRTtFQUNqQjtBQUNGO0FBQ0EsU0FBU0MsVUFBQSxFQUFZO0VBQ25CLE1BQU1DLEdBQUEsR0FBTSxPQUFPQyxNQUFBLEtBQVcsY0FBY0EsTUFBQSxHQUFTLENBQUM7RUFDdEQ5RCxNQUFBLENBQU82RCxHQUFBLEVBQUt0QixTQUFTO0VBQ3JCLE9BQU9zQixHQUFBO0FBQ1Q7OztBQzVJQSxTQUFTRSxnQkFBZ0JDLFFBQUEsRUFBUztFQUNoQyxJQUFJQSxRQUFBLEtBQVksUUFBUTtJQUN0QkEsUUFBQSxHQUFVO0VBQ1o7RUFDQSxPQUFPQSxRQUFBLENBQVFDLElBQUEsQ0FBSyxFQUFFQyxLQUFBLENBQU0sR0FBRyxFQUFFQyxNQUFBLENBQU9DLENBQUEsSUFBSyxDQUFDLENBQUNBLENBQUEsQ0FBRUgsSUFBQSxDQUFLLENBQUM7QUFDekQ7QUFFQSxTQUFTSSxZQUFZeEUsR0FBQSxFQUFLO0VBQ3hCLE1BQU15RSxNQUFBLEdBQVN6RSxHQUFBO0VBQ2ZFLE1BQUEsQ0FBT0ksSUFBQSxDQUFLbUUsTUFBTSxFQUFFbEUsT0FBQSxDQUFRQyxHQUFBLElBQU87SUFDakMsSUFBSTtNQUNGaUUsTUFBQSxDQUFPakUsR0FBQSxJQUFPO0lBQ2hCLFNBQVNrRSxDQUFBLEVBQVAsQ0FFRjtJQUNBLElBQUk7TUFDRixPQUFPRCxNQUFBLENBQU9qRSxHQUFBO0lBQ2hCLFNBQVNrRSxDQUFBLEVBQVAsQ0FFRjtFQUNGLENBQUM7QUFDSDtBQUNBLFNBQVNDLFNBQVNmLFFBQUEsRUFBVWdCLEtBQUEsRUFBTztFQUNqQyxJQUFJQSxLQUFBLEtBQVUsUUFBUTtJQUNwQkEsS0FBQSxHQUFRO0VBQ1Y7RUFDQSxPQUFPcEIsVUFBQSxDQUFXSSxRQUFBLEVBQVVnQixLQUFLO0FBQ25DO0FBQ0EsU0FBU0MsSUFBQSxFQUFNO0VBQ2IsT0FBT3ZCLElBQUEsQ0FBS3VCLEdBQUEsQ0FBSTtBQUNsQjtBQUNBLFNBQVNDLGtCQUFpQkMsRUFBQSxFQUFJO0VBQzVCLE1BQU1DLE9BQUEsR0FBU2pCLFNBQUEsQ0FBVTtFQUN6QixJQUFJdEMsS0FBQTtFQUNKLElBQUl1RCxPQUFBLENBQU83QixnQkFBQSxFQUFrQjtJQUMzQjFCLEtBQUEsR0FBUXVELE9BQUEsQ0FBTzdCLGdCQUFBLENBQWlCNEIsRUFBQSxFQUFJLElBQUk7RUFDMUM7RUFDQSxJQUFJLENBQUN0RCxLQUFBLElBQVNzRCxFQUFBLENBQUdFLFlBQUEsRUFBYztJQUM3QnhELEtBQUEsR0FBUXNELEVBQUEsQ0FBR0UsWUFBQTtFQUNiO0VBQ0EsSUFBSSxDQUFDeEQsS0FBQSxFQUFPO0lBQ1ZBLEtBQUEsR0FBUXNELEVBQUEsQ0FBR3RELEtBQUE7RUFDYjtFQUNBLE9BQU9BLEtBQUE7QUFDVDtBQUNBLFNBQVN5RCxhQUFhSCxFQUFBLEVBQUlJLElBQUEsRUFBTTtFQUM5QixJQUFJQSxJQUFBLEtBQVMsUUFBUTtJQUNuQkEsSUFBQSxHQUFPO0VBQ1Q7RUFDQSxNQUFNSCxPQUFBLEdBQVNqQixTQUFBLENBQVU7RUFDekIsSUFBSXFCLE1BQUE7RUFDSixJQUFJQyxZQUFBO0VBQ0osSUFBSUMsZUFBQTtFQUNKLE1BQU1DLFFBQUEsR0FBV1QsaUJBQUEsQ0FBaUJDLEVBQUU7RUFDcEMsSUFBSUMsT0FBQSxDQUFPUSxlQUFBLEVBQWlCO0lBQzFCSCxZQUFBLEdBQWVFLFFBQUEsQ0FBU0UsU0FBQSxJQUFhRixRQUFBLENBQVNHLGVBQUE7SUFDOUMsSUFBSUwsWUFBQSxDQUFhaEIsS0FBQSxDQUFNLEdBQUcsRUFBRTVELE1BQUEsR0FBUyxHQUFHO01BQ3RDNEUsWUFBQSxHQUFlQSxZQUFBLENBQWFoQixLQUFBLENBQU0sSUFBSSxFQUFFc0IsR0FBQSxDQUFJQyxDQUFBLElBQUtBLENBQUEsQ0FBRUMsT0FBQSxDQUFRLEtBQUssR0FBRyxDQUFDLEVBQUVDLElBQUEsQ0FBSyxJQUFJO0lBQ2pGO0lBR0FSLGVBQUEsR0FBa0IsSUFBSU4sT0FBQSxDQUFPUSxlQUFBLENBQWdCSCxZQUFBLEtBQWlCLFNBQVMsS0FBS0EsWUFBWTtFQUMxRixPQUFPO0lBQ0xDLGVBQUEsR0FBa0JDLFFBQUEsQ0FBU1EsWUFBQSxJQUFnQlIsUUFBQSxDQUFTUyxVQUFBLElBQWNULFFBQUEsQ0FBU1UsV0FBQSxJQUFlVixRQUFBLENBQVNXLFdBQUEsSUFBZVgsUUFBQSxDQUFTRSxTQUFBLElBQWFGLFFBQUEsQ0FBU25DLGdCQUFBLENBQWlCLFdBQVcsRUFBRXlDLE9BQUEsQ0FBUSxjQUFjLG9CQUFvQjtJQUN6TlQsTUFBQSxHQUFTRSxlQUFBLENBQWdCYSxRQUFBLENBQVMsRUFBRTlCLEtBQUEsQ0FBTSxHQUFHO0VBQy9DO0VBQ0EsSUFBSWMsSUFBQSxLQUFTLEtBQUs7SUFFaEIsSUFBSUgsT0FBQSxDQUFPUSxlQUFBLEVBQWlCSCxZQUFBLEdBQWVDLGVBQUEsQ0FBZ0JjLEdBQUEsVUFFbERoQixNQUFBLENBQU8zRSxNQUFBLEtBQVcsSUFBSTRFLFlBQUEsR0FBZWdCLFVBQUEsQ0FBV2pCLE1BQUEsQ0FBTyxHQUFHLE9BRTlEQyxZQUFBLEdBQWVnQixVQUFBLENBQVdqQixNQUFBLENBQU8sRUFBRTtFQUMxQztFQUNBLElBQUlELElBQUEsS0FBUyxLQUFLO0lBRWhCLElBQUlILE9BQUEsQ0FBT1EsZUFBQSxFQUFpQkgsWUFBQSxHQUFlQyxlQUFBLENBQWdCZ0IsR0FBQSxVQUVsRGxCLE1BQUEsQ0FBTzNFLE1BQUEsS0FBVyxJQUFJNEUsWUFBQSxHQUFlZ0IsVUFBQSxDQUFXakIsTUFBQSxDQUFPLEdBQUcsT0FFOURDLFlBQUEsR0FBZWdCLFVBQUEsQ0FBV2pCLE1BQUEsQ0FBTyxFQUFFO0VBQzFDO0VBQ0EsT0FBT0MsWUFBQSxJQUFnQjtBQUN6QjtBQUNBLFNBQVNrQixVQUFTQyxDQUFBLEVBQUc7RUFDbkIsT0FBTyxPQUFPQSxDQUFBLEtBQU0sWUFBWUEsQ0FBQSxLQUFNLFFBQVFBLENBQUEsQ0FBRXZHLFdBQUEsSUFBZUMsTUFBQSxDQUFPdUcsU0FBQSxDQUFVTixRQUFBLENBQVNPLElBQUEsQ0FBS0YsQ0FBQyxFQUFFRyxLQUFBLENBQU0sR0FBRyxFQUFFLE1BQU07QUFDcEg7QUFDQSxTQUFTQyxPQUFPQyxJQUFBLEVBQU07RUFFcEIsSUFBSSxPQUFPNUMsTUFBQSxLQUFXLGVBQWUsT0FBT0EsTUFBQSxDQUFPNkMsV0FBQSxLQUFnQixhQUFhO0lBQzlFLE9BQU9ELElBQUEsWUFBZ0JDLFdBQUE7RUFDekI7RUFDQSxPQUFPRCxJQUFBLEtBQVNBLElBQUEsQ0FBS0UsUUFBQSxLQUFhLEtBQUtGLElBQUEsQ0FBS0UsUUFBQSxLQUFhO0FBQzNEO0FBQ0EsU0FBU0MsUUFBQSxFQUFTO0VBQ2hCLE1BQU1DLEVBQUEsR0FBSy9HLE1BQUEsQ0FBT2dILFNBQUEsQ0FBVXpHLE1BQUEsSUFBVSxJQUFJLFNBQVl5RyxTQUFBLENBQVUsRUFBRTtFQUNsRSxNQUFNQyxRQUFBLEdBQVcsQ0FBQyxhQUFhLGVBQWUsV0FBVztFQUN6RCxTQUFTQyxDQUFBLEdBQUksR0FBR0EsQ0FBQSxHQUFJRixTQUFBLENBQVV6RyxNQUFBLEVBQVEyRyxDQUFBLElBQUssR0FBRztJQUM1QyxNQUFNQyxVQUFBLEdBQWFELENBQUEsR0FBSSxLQUFLRixTQUFBLENBQVV6RyxNQUFBLElBQVUyRyxDQUFBLEdBQUksU0FBWUYsU0FBQSxDQUFVRSxDQUFBO0lBQzFFLElBQUlDLFVBQUEsS0FBZSxVQUFhQSxVQUFBLEtBQWUsUUFBUSxDQUFDVCxNQUFBLENBQU9TLFVBQVUsR0FBRztNQUMxRSxNQUFNQyxTQUFBLEdBQVlwSCxNQUFBLENBQU9JLElBQUEsQ0FBS0osTUFBQSxDQUFPbUgsVUFBVSxDQUFDLEVBQUUvQyxNQUFBLENBQU85RCxHQUFBLElBQU8yRyxRQUFBLENBQVNJLE9BQUEsQ0FBUS9HLEdBQUcsSUFBSSxDQUFDO01BQ3pGLFNBQVNnSCxTQUFBLEdBQVksR0FBR0MsR0FBQSxHQUFNSCxTQUFBLENBQVU3RyxNQUFBLEVBQVErRyxTQUFBLEdBQVlDLEdBQUEsRUFBS0QsU0FBQSxJQUFhLEdBQUc7UUFDL0UsTUFBTUUsT0FBQSxHQUFVSixTQUFBLENBQVVFLFNBQUE7UUFDMUIsTUFBTUcsSUFBQSxHQUFPekgsTUFBQSxDQUFPMEgsd0JBQUEsQ0FBeUJQLFVBQUEsRUFBWUssT0FBTztRQUNoRSxJQUFJQyxJQUFBLEtBQVMsVUFBYUEsSUFBQSxDQUFLRSxVQUFBLEVBQVk7VUFDekMsSUFBSXRCLFNBQUEsQ0FBU1UsRUFBQSxDQUFHUyxPQUFBLENBQVEsS0FBS25CLFNBQUEsQ0FBU2MsVUFBQSxDQUFXSyxPQUFBLENBQVEsR0FBRztZQUMxRCxJQUFJTCxVQUFBLENBQVdLLE9BQUEsRUFBU0ksVUFBQSxFQUFZO2NBQ2xDYixFQUFBLENBQUdTLE9BQUEsSUFBV0wsVUFBQSxDQUFXSyxPQUFBO1lBQzNCLE9BQU87Y0FDTFYsT0FBQSxDQUFPQyxFQUFBLENBQUdTLE9BQUEsR0FBVUwsVUFBQSxDQUFXSyxPQUFBLENBQVE7WUFDekM7VUFDRixXQUFXLENBQUNuQixTQUFBLENBQVNVLEVBQUEsQ0FBR1MsT0FBQSxDQUFRLEtBQUtuQixTQUFBLENBQVNjLFVBQUEsQ0FBV0ssT0FBQSxDQUFRLEdBQUc7WUFDbEVULEVBQUEsQ0FBR1MsT0FBQSxJQUFXLENBQUM7WUFDZixJQUFJTCxVQUFBLENBQVdLLE9BQUEsRUFBU0ksVUFBQSxFQUFZO2NBQ2xDYixFQUFBLENBQUdTLE9BQUEsSUFBV0wsVUFBQSxDQUFXSyxPQUFBO1lBQzNCLE9BQU87Y0FDTFYsT0FBQSxDQUFPQyxFQUFBLENBQUdTLE9BQUEsR0FBVUwsVUFBQSxDQUFXSyxPQUFBLENBQVE7WUFDekM7VUFDRixPQUFPO1lBQ0xULEVBQUEsQ0FBR1MsT0FBQSxJQUFXTCxVQUFBLENBQVdLLE9BQUE7VUFDM0I7UUFDRjtNQUNGO0lBQ0Y7RUFDRjtFQUNBLE9BQU9ULEVBQUE7QUFDVDtBQUNBLFNBQVNjLGVBQWVoRCxFQUFBLEVBQUlpRCxPQUFBLEVBQVNDLFFBQUEsRUFBVTtFQUM3Q2xELEVBQUEsQ0FBR3RELEtBQUEsQ0FBTXlHLFdBQUEsQ0FBWUYsT0FBQSxFQUFTQyxRQUFRO0FBQ3hDO0FBQ0EsU0FBU0UscUJBQXFCQyxJQUFBLEVBQU07RUFDbEMsSUFBSTtJQUNGQyxNQUFBO0lBQ0FDLGNBQUE7SUFDQUM7RUFDRixJQUFJSCxJQUFBO0VBQ0osTUFBTXBELE9BQUEsR0FBU2pCLFNBQUEsQ0FBVTtFQUN6QixNQUFNeUUsYUFBQSxHQUFnQixDQUFDSCxNQUFBLENBQU9JLFNBQUE7RUFDOUIsSUFBSUMsU0FBQSxHQUFZO0VBQ2hCLElBQUlDLElBQUE7RUFDSixNQUFNQyxRQUFBLEdBQVdQLE1BQUEsQ0FBT1EsTUFBQSxDQUFPQyxLQUFBO0VBQy9CVCxNQUFBLENBQU9VLFNBQUEsQ0FBVXRILEtBQUEsQ0FBTXVILGNBQUEsR0FBaUI7RUFDeENoRSxPQUFBLENBQU9uQixvQkFBQSxDQUFxQndFLE1BQUEsQ0FBT1ksY0FBYztFQUNqRCxNQUFNQyxHQUFBLEdBQU1aLGNBQUEsR0FBaUJFLGFBQUEsR0FBZ0IsU0FBUztFQUN0RCxNQUFNVyxZQUFBLEdBQWVBLENBQUNDLE9BQUEsRUFBU2hKLE1BQUEsS0FBVztJQUN4QyxPQUFPOEksR0FBQSxLQUFRLFVBQVVFLE9BQUEsSUFBV2hKLE1BQUEsSUFBVThJLEdBQUEsS0FBUSxVQUFVRSxPQUFBLElBQVdoSixNQUFBO0VBQzdFO0VBQ0EsTUFBTWlKLE9BQUEsR0FBVUEsQ0FBQSxLQUFNO0lBQ3BCVixJQUFBLEdBQU8sSUFBSXJGLElBQUEsQ0FBSyxFQUFFZ0csT0FBQSxDQUFRO0lBQzFCLElBQUlaLFNBQUEsS0FBYyxNQUFNO01BQ3RCQSxTQUFBLEdBQVlDLElBQUE7SUFDZDtJQUNBLE1BQU1ZLFFBQUEsR0FBV0MsSUFBQSxDQUFLQyxHQUFBLENBQUlELElBQUEsQ0FBS0UsR0FBQSxFQUFLZixJQUFBLEdBQU9ELFNBQUEsSUFBYUUsUUFBQSxFQUFVLENBQUMsR0FBRyxDQUFDO0lBQ3ZFLE1BQU1lLFlBQUEsR0FBZSxNQUFNSCxJQUFBLENBQUtJLEdBQUEsQ0FBSUwsUUFBQSxHQUFXQyxJQUFBLENBQUtLLEVBQUUsSUFBSTtJQUMxRCxJQUFJQyxlQUFBLEdBQWtCdEIsYUFBQSxHQUFnQm1CLFlBQUEsSUFBZ0JyQixjQUFBLEdBQWlCRSxhQUFBO0lBQ3ZFLElBQUlXLFlBQUEsQ0FBYVcsZUFBQSxFQUFpQnhCLGNBQWMsR0FBRztNQUNqRHdCLGVBQUEsR0FBa0J4QixjQUFBO0lBQ3BCO0lBQ0FELE1BQUEsQ0FBT1UsU0FBQSxDQUFVZ0IsUUFBQSxDQUFTO01BQ3hCLENBQUN4QixJQUFBLEdBQU91QjtJQUNWLENBQUM7SUFDRCxJQUFJWCxZQUFBLENBQWFXLGVBQUEsRUFBaUJ4QixjQUFjLEdBQUc7TUFDakRELE1BQUEsQ0FBT1UsU0FBQSxDQUFVdEgsS0FBQSxDQUFNdUksUUFBQSxHQUFXO01BQ2xDM0IsTUFBQSxDQUFPVSxTQUFBLENBQVV0SCxLQUFBLENBQU11SCxjQUFBLEdBQWlCO01BQ3hDeEYsVUFBQSxDQUFXLE1BQU07UUFDZjZFLE1BQUEsQ0FBT1UsU0FBQSxDQUFVdEgsS0FBQSxDQUFNdUksUUFBQSxHQUFXO1FBQ2xDM0IsTUFBQSxDQUFPVSxTQUFBLENBQVVnQixRQUFBLENBQVM7VUFDeEIsQ0FBQ3hCLElBQUEsR0FBT3VCO1FBQ1YsQ0FBQztNQUNILENBQUM7TUFDRDlFLE9BQUEsQ0FBT25CLG9CQUFBLENBQXFCd0UsTUFBQSxDQUFPWSxjQUFjO01BQ2pEO0lBQ0Y7SUFDQVosTUFBQSxDQUFPWSxjQUFBLEdBQWlCakUsT0FBQSxDQUFPckIscUJBQUEsQ0FBc0IwRixPQUFPO0VBQzlEO0VBQ0FBLE9BQUEsQ0FBUTtBQUNWO0FBQ0EsU0FBU1ksb0JBQW9CQyxPQUFBLEVBQVM7RUFDcEMsT0FBT0EsT0FBQSxDQUFRakosYUFBQSxDQUFjLHlCQUF5QixLQUFLaUosT0FBQSxDQUFRQyxVQUFBLElBQWNELE9BQUEsQ0FBUUMsVUFBQSxDQUFXbEosYUFBQSxDQUFjLHlCQUF5QixLQUFLaUosT0FBQTtBQUNsSjtBQUNBLFNBQVNFLGdCQUFnQkMsT0FBQSxFQUFTQyxRQUFBLEVBQVU7RUFDMUMsSUFBSUEsUUFBQSxLQUFhLFFBQVE7SUFDdkJBLFFBQUEsR0FBVztFQUNiO0VBQ0EsT0FBTyxDQUFDLEdBQUdELE9BQUEsQ0FBUTlJLFFBQVEsRUFBRStDLE1BQUEsQ0FBT1MsRUFBQSxJQUFNQSxFQUFBLENBQUd3RixPQUFBLENBQVFELFFBQVEsQ0FBQztBQUNoRTtBQUNBLFNBQVNFLFlBQVlDLElBQUEsRUFBTTtFQUN6QixJQUFJO0lBQ0ZDLE9BQUEsQ0FBUUMsSUFBQSxDQUFLRixJQUFJO0lBQ2pCO0VBQ0YsU0FBU0csR0FBQSxFQUFQLENBRUY7QUFDRjtBQUNBLFNBQVN0SixjQUFjdUosR0FBQSxFQUFLMUcsUUFBQSxFQUFTO0VBQ25DLElBQUlBLFFBQUEsS0FBWSxRQUFRO0lBQ3RCQSxRQUFBLEdBQVUsRUFBQztFQUNiO0VBQ0EsTUFBTVksRUFBQSxHQUFLdEMsUUFBQSxDQUFTbkIsYUFBQSxDQUFjdUosR0FBRztFQUNyQzlGLEVBQUEsQ0FBRytGLFNBQUEsQ0FBVUMsR0FBQSxDQUFJLElBQUlDLEtBQUEsQ0FBTUMsT0FBQSxDQUFROUcsUUFBTyxJQUFJQSxRQUFBLEdBQVVELGVBQUEsQ0FBZ0JDLFFBQU8sQ0FBRTtFQUNqRixPQUFPWSxFQUFBO0FBQ1Q7QUFDQSxTQUFTbUcsY0FBY25HLEVBQUEsRUFBSTtFQUN6QixNQUFNQyxPQUFBLEdBQVNqQixTQUFBLENBQVU7RUFDekIsTUFBTW9ILFNBQUEsR0FBVzVJLFdBQUEsQ0FBWTtFQUM3QixNQUFNNkksR0FBQSxHQUFNckcsRUFBQSxDQUFHc0cscUJBQUEsQ0FBc0I7RUFDckMsTUFBTTFLLElBQUEsR0FBT3dLLFNBQUEsQ0FBU3hLLElBQUE7RUFDdEIsTUFBTTJLLFNBQUEsR0FBWXZHLEVBQUEsQ0FBR3VHLFNBQUEsSUFBYTNLLElBQUEsQ0FBSzJLLFNBQUEsSUFBYTtFQUNwRCxNQUFNQyxVQUFBLEdBQWF4RyxFQUFBLENBQUd3RyxVQUFBLElBQWM1SyxJQUFBLENBQUs0SyxVQUFBLElBQWM7RUFDdkQsTUFBTUMsU0FBQSxHQUFZekcsRUFBQSxLQUFPQyxPQUFBLEdBQVNBLE9BQUEsQ0FBT3lHLE9BQUEsR0FBVTFHLEVBQUEsQ0FBR3lHLFNBQUE7RUFDdEQsTUFBTUUsVUFBQSxHQUFhM0csRUFBQSxLQUFPQyxPQUFBLEdBQVNBLE9BQUEsQ0FBTzJHLE9BQUEsR0FBVTVHLEVBQUEsQ0FBRzJHLFVBQUE7RUFDdkQsT0FBTztJQUNMRSxHQUFBLEVBQUtSLEdBQUEsQ0FBSVEsR0FBQSxHQUFNSixTQUFBLEdBQVlGLFNBQUE7SUFDM0JPLElBQUEsRUFBTVQsR0FBQSxDQUFJUyxJQUFBLEdBQU9ILFVBQUEsR0FBYUg7RUFDaEM7QUFDRjtBQUNBLFNBQVNPLGVBQWUvRyxFQUFBLEVBQUl1RixRQUFBLEVBQVU7RUFDcEMsTUFBTXlCLE9BQUEsR0FBVSxFQUFDO0VBQ2pCLE9BQU9oSCxFQUFBLENBQUdpSCxzQkFBQSxFQUF3QjtJQUNoQyxNQUFNQyxJQUFBLEdBQU9sSCxFQUFBLENBQUdpSCxzQkFBQTtJQUNoQixJQUFJMUIsUUFBQSxFQUFVO01BQ1osSUFBSTJCLElBQUEsQ0FBSzFCLE9BQUEsQ0FBUUQsUUFBUSxHQUFHeUIsT0FBQSxDQUFRRyxJQUFBLENBQUtELElBQUk7SUFDL0MsT0FBT0YsT0FBQSxDQUFRRyxJQUFBLENBQUtELElBQUk7SUFDeEJsSCxFQUFBLEdBQUtrSCxJQUFBO0VBQ1A7RUFDQSxPQUFPRixPQUFBO0FBQ1Q7QUFDQSxTQUFTSSxlQUFlcEgsRUFBQSxFQUFJdUYsUUFBQSxFQUFVO0VBQ3BDLE1BQU04QixPQUFBLEdBQVUsRUFBQztFQUNqQixPQUFPckgsRUFBQSxDQUFHc0gsa0JBQUEsRUFBb0I7SUFDNUIsTUFBTUMsSUFBQSxHQUFPdkgsRUFBQSxDQUFHc0gsa0JBQUE7SUFDaEIsSUFBSS9CLFFBQUEsRUFBVTtNQUNaLElBQUlnQyxJQUFBLENBQUsvQixPQUFBLENBQVFELFFBQVEsR0FBRzhCLE9BQUEsQ0FBUUYsSUFBQSxDQUFLSSxJQUFJO0lBQy9DLE9BQU9GLE9BQUEsQ0FBUUYsSUFBQSxDQUFLSSxJQUFJO0lBQ3hCdkgsRUFBQSxHQUFLdUgsSUFBQTtFQUNQO0VBQ0EsT0FBT0YsT0FBQTtBQUNUO0FBQ0EsU0FBU0csYUFBYXhILEVBQUEsRUFBSXlILElBQUEsRUFBTTtFQUM5QixNQUFNeEgsT0FBQSxHQUFTakIsU0FBQSxDQUFVO0VBQ3pCLE9BQU9pQixPQUFBLENBQU83QixnQkFBQSxDQUFpQjRCLEVBQUEsRUFBSSxJQUFJLEVBQUUzQixnQkFBQSxDQUFpQm9KLElBQUk7QUFDaEU7QUFDQSxTQUFTQyxhQUFhMUgsRUFBQSxFQUFJO0VBQ3hCLElBQUkySCxLQUFBLEdBQVEzSCxFQUFBO0VBQ1osSUFBSXFDLENBQUE7RUFDSixJQUFJc0YsS0FBQSxFQUFPO0lBQ1R0RixDQUFBLEdBQUk7SUFFSixRQUFRc0YsS0FBQSxHQUFRQSxLQUFBLENBQU1DLGVBQUEsTUFBcUIsTUFBTTtNQUMvQyxJQUFJRCxLQUFBLENBQU0zRixRQUFBLEtBQWEsR0FBR0ssQ0FBQSxJQUFLO0lBQ2pDO0lBQ0EsT0FBT0EsQ0FBQTtFQUNUO0VBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBU3dGLGVBQWU3SCxFQUFBLEVBQUl1RixRQUFBLEVBQVU7RUFDcEMsTUFBTXVDLE9BQUEsR0FBVSxFQUFDO0VBQ2pCLElBQUlDLE1BQUEsR0FBUy9ILEVBQUEsQ0FBR2dJLGFBQUE7RUFDaEIsT0FBT0QsTUFBQSxFQUFRO0lBQ2IsSUFBSXhDLFFBQUEsRUFBVTtNQUNaLElBQUl3QyxNQUFBLENBQU92QyxPQUFBLENBQVFELFFBQVEsR0FBR3VDLE9BQUEsQ0FBUVgsSUFBQSxDQUFLWSxNQUFNO0lBQ25ELE9BQU87TUFDTEQsT0FBQSxDQUFRWCxJQUFBLENBQUtZLE1BQU07SUFDckI7SUFDQUEsTUFBQSxHQUFTQSxNQUFBLENBQU9DLGFBQUE7RUFDbEI7RUFDQSxPQUFPRixPQUFBO0FBQ1Q7QUFDQSxTQUFTRyxxQkFBcUJqSSxFQUFBLEVBQUluQixRQUFBLEVBQVU7RUFDMUMsU0FBU3FKLGFBQWF2SSxDQUFBLEVBQUc7SUFDdkIsSUFBSUEsQ0FBQSxDQUFFdEUsTUFBQSxLQUFXMkUsRUFBQSxFQUFJO0lBQ3JCbkIsUUFBQSxDQUFTOEMsSUFBQSxDQUFLM0IsRUFBQSxFQUFJTCxDQUFDO0lBQ25CSyxFQUFBLENBQUdsRSxtQkFBQSxDQUFvQixpQkFBaUJvTSxZQUFZO0VBQ3REO0VBQ0EsSUFBSXJKLFFBQUEsRUFBVTtJQUNabUIsRUFBQSxDQUFHbkUsZ0JBQUEsQ0FBaUIsaUJBQWlCcU0sWUFBWTtFQUNuRDtBQUNGO0FBQ0EsU0FBU0MsaUJBQWlCbkksRUFBQSxFQUFJb0ksSUFBQSxFQUFNQyxjQUFBLEVBQWdCO0VBQ2xELE1BQU1wSSxPQUFBLEdBQVNqQixTQUFBLENBQVU7RUFDekIsSUFBSXFKLGNBQUEsRUFBZ0I7SUFDbEIsT0FBT3JJLEVBQUEsQ0FBR29JLElBQUEsS0FBUyxVQUFVLGdCQUFnQixrQkFBa0I5RyxVQUFBLENBQVdyQixPQUFBLENBQU83QixnQkFBQSxDQUFpQjRCLEVBQUEsRUFBSSxJQUFJLEVBQUUzQixnQkFBQSxDQUFpQitKLElBQUEsS0FBUyxVQUFVLGlCQUFpQixZQUFZLENBQUMsSUFBSTlHLFVBQUEsQ0FBV3JCLE9BQUEsQ0FBTzdCLGdCQUFBLENBQWlCNEIsRUFBQSxFQUFJLElBQUksRUFBRTNCLGdCQUFBLENBQWlCK0osSUFBQSxLQUFTLFVBQVUsZ0JBQWdCLGVBQWUsQ0FBQztFQUNyUztFQUNBLE9BQU9wSSxFQUFBLENBQUdzSSxXQUFBO0FBQ1o7QUFDQSxTQUFTQyxrQkFBa0J2SSxFQUFBLEVBQUk7RUFDN0IsUUFBUWlHLEtBQUEsQ0FBTUMsT0FBQSxDQUFRbEcsRUFBRSxJQUFJQSxFQUFBLEdBQUssQ0FBQ0EsRUFBRSxHQUFHVCxNQUFBLENBQU9JLENBQUEsSUFBSyxDQUFDLENBQUNBLENBQUM7QUFDeEQ7OztBQzlSQSxJQUFJNkksT0FBQTtBQUNKLFNBQVNDLFlBQUEsRUFBYztFQUNyQixNQUFNeEksT0FBQSxHQUFTakIsU0FBQSxDQUFVO0VBQ3pCLE1BQU1vSCxTQUFBLEdBQVc1SSxXQUFBLENBQVk7RUFDN0IsT0FBTztJQUNMa0wsWUFBQSxFQUFjdEMsU0FBQSxDQUFTdUMsZUFBQSxJQUFtQnZDLFNBQUEsQ0FBU3VDLGVBQUEsQ0FBZ0JqTSxLQUFBLElBQVMsb0JBQW9CMEosU0FBQSxDQUFTdUMsZUFBQSxDQUFnQmpNLEtBQUE7SUFDekhrTSxLQUFBLEVBQU8sQ0FBQyxFQUFFLGtCQUFrQjNJLE9BQUEsSUFBVUEsT0FBQSxDQUFPNEksYUFBQSxJQUFpQnpDLFNBQUEsWUFBb0JuRyxPQUFBLENBQU80SSxhQUFBO0VBQzNGO0FBQ0Y7QUFDQSxTQUFTQyxXQUFBLEVBQWE7RUFDcEIsSUFBSSxDQUFDTixPQUFBLEVBQVM7SUFDWkEsT0FBQSxHQUFVQyxXQUFBLENBQVk7RUFDeEI7RUFDQSxPQUFPRCxPQUFBO0FBQ1Q7QUFFQSxJQUFJTyxZQUFBO0FBQ0osU0FBU0MsV0FBV0MsS0FBQSxFQUFPO0VBQ3pCLElBQUk7SUFDRnBMO0VBQ0YsSUFBSW9MLEtBQUEsS0FBVSxTQUFTLENBQUMsSUFBSUEsS0FBQTtFQUM1QixNQUFNQyxRQUFBLEdBQVVKLFVBQUEsQ0FBVztFQUMzQixNQUFNN0ksT0FBQSxHQUFTakIsU0FBQSxDQUFVO0VBQ3pCLE1BQU1tSyxRQUFBLEdBQVdsSixPQUFBLENBQU9yQyxTQUFBLENBQVV1TCxRQUFBO0VBQ2xDLE1BQU1DLEVBQUEsR0FBS3ZMLFNBQUEsSUFBYW9DLE9BQUEsQ0FBT3JDLFNBQUEsQ0FBVUMsU0FBQTtFQUN6QyxNQUFNd0wsTUFBQSxHQUFTO0lBQ2JDLEdBQUEsRUFBSztJQUNMQyxPQUFBLEVBQVM7RUFDWDtFQUNBLE1BQU1DLFdBQUEsR0FBY3ZKLE9BQUEsQ0FBT3pCLE1BQUEsQ0FBT2lMLEtBQUE7RUFDbEMsTUFBTUMsWUFBQSxHQUFlekosT0FBQSxDQUFPekIsTUFBQSxDQUFPbUwsTUFBQTtFQUNuQyxNQUFNSixPQUFBLEdBQVVILEVBQUEsQ0FBR1EsS0FBQSxDQUFNLDZCQUE2QjtFQUN0RCxJQUFJQyxJQUFBLEdBQU9ULEVBQUEsQ0FBR1EsS0FBQSxDQUFNLHNCQUFzQjtFQUMxQyxNQUFNRSxJQUFBLEdBQU9WLEVBQUEsQ0FBR1EsS0FBQSxDQUFNLHlCQUF5QjtFQUMvQyxNQUFNRyxNQUFBLEdBQVMsQ0FBQ0YsSUFBQSxJQUFRVCxFQUFBLENBQUdRLEtBQUEsQ0FBTSw0QkFBNEI7RUFDN0QsTUFBTUksT0FBQSxHQUFVYixRQUFBLEtBQWE7RUFDN0IsSUFBSWMsS0FBQSxHQUFRZCxRQUFBLEtBQWE7RUFHekIsTUFBTWUsV0FBQSxHQUFjLENBQUMsYUFBYSxhQUFhLFlBQVksWUFBWSxZQUFZLFlBQVksWUFBWSxZQUFZLFlBQVksWUFBWSxZQUFZLFVBQVU7RUFDckssSUFBSSxDQUFDTCxJQUFBLElBQVFJLEtBQUEsSUFBU2YsUUFBQSxDQUFRTixLQUFBLElBQVNzQixXQUFBLENBQVkxSCxPQUFBLENBQVEsR0FBR2dILFdBQUEsSUFBZUUsWUFBQSxFQUFjLEtBQUssR0FBRztJQUNqR0csSUFBQSxHQUFPVCxFQUFBLENBQUdRLEtBQUEsQ0FBTSxxQkFBcUI7SUFDckMsSUFBSSxDQUFDQyxJQUFBLEVBQU1BLElBQUEsR0FBTyxDQUFDLEdBQUcsR0FBRyxRQUFRO0lBQ2pDSSxLQUFBLEdBQVE7RUFDVjtFQUdBLElBQUlWLE9BQUEsSUFBVyxDQUFDUyxPQUFBLEVBQVM7SUFDdkJYLE1BQUEsQ0FBT2MsRUFBQSxHQUFLO0lBQ1pkLE1BQUEsQ0FBT0UsT0FBQSxHQUFVO0VBQ25CO0VBQ0EsSUFBSU0sSUFBQSxJQUFRRSxNQUFBLElBQVVELElBQUEsRUFBTTtJQUMxQlQsTUFBQSxDQUFPYyxFQUFBLEdBQUs7SUFDWmQsTUFBQSxDQUFPQyxHQUFBLEdBQU07RUFDZjtFQUdBLE9BQU9ELE1BQUE7QUFDVDtBQUNBLFNBQVNlLFVBQVVDLFNBQUEsRUFBVztFQUM1QixJQUFJQSxTQUFBLEtBQWMsUUFBUTtJQUN4QkEsU0FBQSxHQUFZLENBQUM7RUFDZjtFQUNBLElBQUksQ0FBQ3RCLFlBQUEsRUFBYztJQUNqQkEsWUFBQSxHQUFlQyxVQUFBLENBQVdxQixTQUFTO0VBQ3JDO0VBQ0EsT0FBT3RCLFlBQUE7QUFDVDtBQUVBLElBQUl1QixPQUFBO0FBQ0osU0FBU0MsWUFBQSxFQUFjO0VBQ3JCLE1BQU10SyxPQUFBLEdBQVNqQixTQUFBLENBQVU7RUFDekIsTUFBTXFLLE1BQUEsR0FBU2UsU0FBQSxDQUFVO0VBQ3pCLElBQUlJLGtCQUFBLEdBQXFCO0VBQ3pCLFNBQVNDLFNBQUEsRUFBVztJQUNsQixNQUFNckIsRUFBQSxHQUFLbkosT0FBQSxDQUFPckMsU0FBQSxDQUFVQyxTQUFBLENBQVU2TSxXQUFBLENBQVk7SUFDbEQsT0FBT3RCLEVBQUEsQ0FBRzVHLE9BQUEsQ0FBUSxRQUFRLEtBQUssS0FBSzRHLEVBQUEsQ0FBRzVHLE9BQUEsQ0FBUSxRQUFRLElBQUksS0FBSzRHLEVBQUEsQ0FBRzVHLE9BQUEsQ0FBUSxTQUFTLElBQUk7RUFDMUY7RUFDQSxJQUFJaUksUUFBQSxDQUFTLEdBQUc7SUFDZCxNQUFNckIsRUFBQSxHQUFLdUIsTUFBQSxDQUFPMUssT0FBQSxDQUFPckMsU0FBQSxDQUFVQyxTQUFTO0lBQzVDLElBQUl1TCxFQUFBLENBQUd3QixRQUFBLENBQVMsVUFBVSxHQUFHO01BQzNCLE1BQU0sQ0FBQ0MsS0FBQSxFQUFPQyxLQUFLLElBQUkxQixFQUFBLENBQUc5SixLQUFBLENBQU0sVUFBVSxFQUFFLEdBQUdBLEtBQUEsQ0FBTSxHQUFHLEVBQUUsR0FBR0EsS0FBQSxDQUFNLEdBQUcsRUFBRXNCLEdBQUEsQ0FBSW1LLEdBQUEsSUFBT0MsTUFBQSxDQUFPRCxHQUFHLENBQUM7TUFDOUZQLGtCQUFBLEdBQXFCSyxLQUFBLEdBQVEsTUFBTUEsS0FBQSxLQUFVLE1BQU1DLEtBQUEsR0FBUTtJQUM3RDtFQUNGO0VBQ0EsTUFBTUcsU0FBQSxHQUFZLCtDQUErQ0MsSUFBQSxDQUFLakwsT0FBQSxDQUFPckMsU0FBQSxDQUFVQyxTQUFTO0VBQ2hHLE1BQU1zTixlQUFBLEdBQWtCVixRQUFBLENBQVM7RUFDakMsTUFBTVcsU0FBQSxHQUFZRCxlQUFBLElBQW1CRixTQUFBLElBQWE1QixNQUFBLENBQU9DLEdBQUE7RUFDekQsT0FBTztJQUNMbUIsUUFBQSxFQUFVRCxrQkFBQSxJQUFzQlcsZUFBQTtJQUNoQ1gsa0JBQUE7SUFDQVksU0FBQTtJQUNBSDtFQUNGO0FBQ0Y7QUFDQSxTQUFTSSxXQUFBLEVBQWE7RUFDcEIsSUFBSSxDQUFDZixPQUFBLEVBQVM7SUFDWkEsT0FBQSxHQUFVQyxXQUFBLENBQVk7RUFDeEI7RUFDQSxPQUFPRCxPQUFBO0FBQ1Q7QUFFQSxTQUFTZ0IsT0FBT2pJLElBQUEsRUFBTTtFQUNwQixJQUFJO0lBQ0ZDLE1BQUE7SUFDQWlJLEVBQUE7SUFDQUM7RUFDRixJQUFJbkksSUFBQTtFQUNKLE1BQU1wRCxPQUFBLEdBQVNqQixTQUFBLENBQVU7RUFDekIsSUFBSXlNLFFBQUEsR0FBVztFQUNmLElBQUlDLGNBQUEsR0FBaUI7RUFDckIsTUFBTUMsYUFBQSxHQUFnQkEsQ0FBQSxLQUFNO0lBQzFCLElBQUksQ0FBQ3JJLE1BQUEsSUFBVUEsTUFBQSxDQUFPc0ksU0FBQSxJQUFhLENBQUN0SSxNQUFBLENBQU91SSxXQUFBLEVBQWE7SUFDeERMLElBQUEsQ0FBSyxjQUFjO0lBQ25CQSxJQUFBLENBQUssUUFBUTtFQUNmO0VBQ0EsTUFBTU0sY0FBQSxHQUFpQkEsQ0FBQSxLQUFNO0lBQzNCLElBQUksQ0FBQ3hJLE1BQUEsSUFBVUEsTUFBQSxDQUFPc0ksU0FBQSxJQUFhLENBQUN0SSxNQUFBLENBQU91SSxXQUFBLEVBQWE7SUFDeERKLFFBQUEsR0FBVyxJQUFJTSxjQUFBLENBQWVDLE9BQUEsSUFBVztNQUN2Q04sY0FBQSxHQUFpQnpMLE9BQUEsQ0FBT3JCLHFCQUFBLENBQXNCLE1BQU07UUFDbEQsTUFBTTtVQUNKNkssS0FBQTtVQUNBRTtRQUNGLElBQUlyRyxNQUFBO1FBQ0osSUFBSTJJLFFBQUEsR0FBV3hDLEtBQUE7UUFDZixJQUFJeUMsU0FBQSxHQUFZdkMsTUFBQTtRQUNoQnFDLE9BQUEsQ0FBUXhRLE9BQUEsQ0FBUTJRLEtBQUEsSUFBUztVQUN2QixJQUFJO1lBQ0ZDLGNBQUE7WUFDQUMsV0FBQTtZQUNBaFI7VUFDRixJQUFJOFEsS0FBQTtVQUNKLElBQUk5USxNQUFBLElBQVVBLE1BQUEsS0FBV2lJLE1BQUEsQ0FBT3RELEVBQUEsRUFBSTtVQUNwQ2lNLFFBQUEsR0FBV0ksV0FBQSxHQUFjQSxXQUFBLENBQVk1QyxLQUFBLElBQVMyQyxjQUFBLENBQWUsTUFBTUEsY0FBQSxFQUFnQkUsVUFBQTtVQUNuRkosU0FBQSxHQUFZRyxXQUFBLEdBQWNBLFdBQUEsQ0FBWTFDLE1BQUEsSUFBVXlDLGNBQUEsQ0FBZSxNQUFNQSxjQUFBLEVBQWdCRyxTQUFBO1FBQ3ZGLENBQUM7UUFDRCxJQUFJTixRQUFBLEtBQWF4QyxLQUFBLElBQVN5QyxTQUFBLEtBQWN2QyxNQUFBLEVBQVE7VUFDOUNnQyxhQUFBLENBQWM7UUFDaEI7TUFDRixDQUFDO0lBQ0gsQ0FBQztJQUNERixRQUFBLENBQVNlLE9BQUEsQ0FBUWxKLE1BQUEsQ0FBT3RELEVBQUU7RUFDNUI7RUFDQSxNQUFNeU0sY0FBQSxHQUFpQkEsQ0FBQSxLQUFNO0lBQzNCLElBQUlmLGNBQUEsRUFBZ0I7TUFDbEJ6TCxPQUFBLENBQU9uQixvQkFBQSxDQUFxQjRNLGNBQWM7SUFDNUM7SUFDQSxJQUFJRCxRQUFBLElBQVlBLFFBQUEsQ0FBU2lCLFNBQUEsSUFBYXBKLE1BQUEsQ0FBT3RELEVBQUEsRUFBSTtNQUMvQ3lMLFFBQUEsQ0FBU2lCLFNBQUEsQ0FBVXBKLE1BQUEsQ0FBT3RELEVBQUU7TUFDNUJ5TCxRQUFBLEdBQVc7SUFDYjtFQUNGO0VBQ0EsTUFBTWtCLHdCQUFBLEdBQTJCQSxDQUFBLEtBQU07SUFDckMsSUFBSSxDQUFDckosTUFBQSxJQUFVQSxNQUFBLENBQU9zSSxTQUFBLElBQWEsQ0FBQ3RJLE1BQUEsQ0FBT3VJLFdBQUEsRUFBYTtJQUN4REwsSUFBQSxDQUFLLG1CQUFtQjtFQUMxQjtFQUNBRCxFQUFBLENBQUcsUUFBUSxNQUFNO0lBQ2YsSUFBSWpJLE1BQUEsQ0FBT1EsTUFBQSxDQUFPOEksY0FBQSxJQUFrQixPQUFPM00sT0FBQSxDQUFPOEwsY0FBQSxLQUFtQixhQUFhO01BQ2hGRCxjQUFBLENBQWU7TUFDZjtJQUNGO0lBQ0E3TCxPQUFBLENBQU9wRSxnQkFBQSxDQUFpQixVQUFVOFAsYUFBYTtJQUMvQzFMLE9BQUEsQ0FBT3BFLGdCQUFBLENBQWlCLHFCQUFxQjhRLHdCQUF3QjtFQUN2RSxDQUFDO0VBQ0RwQixFQUFBLENBQUcsV0FBVyxNQUFNO0lBQ2xCa0IsY0FBQSxDQUFlO0lBQ2Z4TSxPQUFBLENBQU9uRSxtQkFBQSxDQUFvQixVQUFVNlAsYUFBYTtJQUNsRDFMLE9BQUEsQ0FBT25FLG1CQUFBLENBQW9CLHFCQUFxQjZRLHdCQUF3QjtFQUMxRSxDQUFDO0FBQ0g7QUFFQSxTQUFTRSxTQUFTeEosSUFBQSxFQUFNO0VBQ3RCLElBQUk7SUFDRkMsTUFBQTtJQUNBd0osWUFBQTtJQUNBdkIsRUFBQTtJQUNBQztFQUNGLElBQUluSSxJQUFBO0VBQ0osTUFBTTBKLFNBQUEsR0FBWSxFQUFDO0VBQ25CLE1BQU05TSxPQUFBLEdBQVNqQixTQUFBLENBQVU7RUFDekIsTUFBTWdPLE1BQUEsR0FBUyxTQUFBQSxDQUFVM1IsTUFBQSxFQUFRNFIsT0FBQSxFQUFTO0lBQ3hDLElBQUlBLE9BQUEsS0FBWSxRQUFRO01BQ3RCQSxPQUFBLEdBQVUsQ0FBQztJQUNiO0lBQ0EsTUFBTUMsWUFBQSxHQUFlak4sT0FBQSxDQUFPa04sZ0JBQUEsSUFBb0JsTixPQUFBLENBQU9tTixzQkFBQTtJQUN2RCxNQUFNM0IsUUFBQSxHQUFXLElBQUl5QixZQUFBLENBQWFHLFNBQUEsSUFBYTtNQUk3QyxJQUFJL0osTUFBQSxDQUFPZ0ssbUJBQUEsRUFBcUI7TUFDaEMsSUFBSUQsU0FBQSxDQUFVM1IsTUFBQSxLQUFXLEdBQUc7UUFDMUI4UCxJQUFBLENBQUssa0JBQWtCNkIsU0FBQSxDQUFVLEVBQUU7UUFDbkM7TUFDRjtNQUNBLE1BQU1FLGNBQUEsR0FBaUIsU0FBU0MsZ0JBQUEsRUFBaUI7UUFDL0NoQyxJQUFBLENBQUssa0JBQWtCNkIsU0FBQSxDQUFVLEVBQUU7TUFDckM7TUFDQSxJQUFJcE4sT0FBQSxDQUFPckIscUJBQUEsRUFBdUI7UUFDaENxQixPQUFBLENBQU9yQixxQkFBQSxDQUFzQjJPLGNBQWM7TUFDN0MsT0FBTztRQUNMdE4sT0FBQSxDQUFPeEIsVUFBQSxDQUFXOE8sY0FBQSxFQUFnQixDQUFDO01BQ3JDO0lBQ0YsQ0FBQztJQUNEOUIsUUFBQSxDQUFTZSxPQUFBLENBQVFuUixNQUFBLEVBQVE7TUFDdkJvUyxVQUFBLEVBQVksT0FBT1IsT0FBQSxDQUFRUSxVQUFBLEtBQWUsY0FBYyxPQUFPUixPQUFBLENBQVFRLFVBQUE7TUFDdkVDLFNBQUEsRUFBVyxPQUFPVCxPQUFBLENBQVFTLFNBQUEsS0FBYyxjQUFjLE9BQU9ULE9BQUEsQ0FBUVMsU0FBQTtNQUNyRUMsYUFBQSxFQUFlLE9BQU9WLE9BQUEsQ0FBUVUsYUFBQSxLQUFrQixjQUFjLE9BQU9WLE9BQUEsQ0FBUVU7SUFDL0UsQ0FBQztJQUNEWixTQUFBLENBQVU1RixJQUFBLENBQUtzRSxRQUFRO0VBQ3pCO0VBQ0EsTUFBTW1DLElBQUEsR0FBT0EsQ0FBQSxLQUFNO0lBQ2pCLElBQUksQ0FBQ3RLLE1BQUEsQ0FBT1EsTUFBQSxDQUFPMkgsUUFBQSxFQUFVO0lBQzdCLElBQUluSSxNQUFBLENBQU9RLE1BQUEsQ0FBTytKLGNBQUEsRUFBZ0I7TUFDaEMsTUFBTUMsZ0JBQUEsR0FBbUJqRyxjQUFBLENBQWV2RSxNQUFBLENBQU95SyxNQUFNO01BQ3JELFNBQVMxTCxDQUFBLEdBQUksR0FBR0EsQ0FBQSxHQUFJeUwsZ0JBQUEsQ0FBaUJwUyxNQUFBLEVBQVEyRyxDQUFBLElBQUssR0FBRztRQUNuRDJLLE1BQUEsQ0FBT2MsZ0JBQUEsQ0FBaUJ6TCxDQUFBLENBQUU7TUFDNUI7SUFDRjtJQUVBMkssTUFBQSxDQUFPMUosTUFBQSxDQUFPeUssTUFBQSxFQUFRO01BQ3BCTCxTQUFBLEVBQVdwSyxNQUFBLENBQU9RLE1BQUEsQ0FBT2tLO0lBQzNCLENBQUM7SUFHRGhCLE1BQUEsQ0FBTzFKLE1BQUEsQ0FBT1UsU0FBQSxFQUFXO01BQ3ZCeUosVUFBQSxFQUFZO0lBQ2QsQ0FBQztFQUNIO0VBQ0EsTUFBTVEsT0FBQSxHQUFVQSxDQUFBLEtBQU07SUFDcEJsQixTQUFBLENBQVV2UixPQUFBLENBQVFpUSxRQUFBLElBQVk7TUFDNUJBLFFBQUEsQ0FBU3lDLFVBQUEsQ0FBVztJQUN0QixDQUFDO0lBQ0RuQixTQUFBLENBQVVvQixNQUFBLENBQU8sR0FBR3BCLFNBQUEsQ0FBVXJSLE1BQU07RUFDdEM7RUFDQW9SLFlBQUEsQ0FBYTtJQUNYckIsUUFBQSxFQUFVO0lBQ1ZvQyxjQUFBLEVBQWdCO0lBQ2hCRyxvQkFBQSxFQUFzQjtFQUN4QixDQUFDO0VBQ0R6QyxFQUFBLENBQUcsUUFBUXFDLElBQUk7RUFDZnJDLEVBQUEsQ0FBRyxXQUFXMEMsT0FBTztBQUN2QjtBQUlBLElBQUlHLGFBQUEsR0FBZ0I7RUFDbEI3QyxHQUFHOEMsT0FBQSxFQUFRQyxPQUFBLEVBQVNDLFFBQUEsRUFBVTtJQUM1QixNQUFNQyxJQUFBLEdBQU87SUFDYixJQUFJLENBQUNBLElBQUEsQ0FBS0MsZUFBQSxJQUFtQkQsSUFBQSxDQUFLNUMsU0FBQSxFQUFXLE9BQU80QyxJQUFBO0lBQ3BELElBQUksT0FBT0YsT0FBQSxLQUFZLFlBQVksT0FBT0UsSUFBQTtJQUMxQyxNQUFNRSxNQUFBLEdBQVNILFFBQUEsR0FBVyxZQUFZO0lBQ3RDRixPQUFBLENBQU8vTyxLQUFBLENBQU0sR0FBRyxFQUFFOUQsT0FBQSxDQUFRbVQsS0FBQSxJQUFTO01BQ2pDLElBQUksQ0FBQ0gsSUFBQSxDQUFLQyxlQUFBLENBQWdCRSxLQUFBLEdBQVFILElBQUEsQ0FBS0MsZUFBQSxDQUFnQkUsS0FBQSxJQUFTLEVBQUM7TUFDakVILElBQUEsQ0FBS0MsZUFBQSxDQUFnQkUsS0FBQSxFQUFPRCxNQUFBLEVBQVFKLE9BQU87SUFDN0MsQ0FBQztJQUNELE9BQU9FLElBQUE7RUFDVDtFQUNBSSxLQUFLUCxPQUFBLEVBQVFDLE9BQUEsRUFBU0MsUUFBQSxFQUFVO0lBQzlCLE1BQU1DLElBQUEsR0FBTztJQUNiLElBQUksQ0FBQ0EsSUFBQSxDQUFLQyxlQUFBLElBQW1CRCxJQUFBLENBQUs1QyxTQUFBLEVBQVcsT0FBTzRDLElBQUE7SUFDcEQsSUFBSSxPQUFPRixPQUFBLEtBQVksWUFBWSxPQUFPRSxJQUFBO0lBQzFDLFNBQVNLLFlBQUEsRUFBYztNQUNyQkwsSUFBQSxDQUFLTSxHQUFBLENBQUlULE9BQUEsRUFBUVEsV0FBVztNQUM1QixJQUFJQSxXQUFBLENBQVlFLGNBQUEsRUFBZ0I7UUFDOUIsT0FBT0YsV0FBQSxDQUFZRSxjQUFBO01BQ3JCO01BQ0EsU0FBU0MsSUFBQSxHQUFPN00sU0FBQSxDQUFVekcsTUFBQSxFQUFRdVQsSUFBQSxHQUFPLElBQUloSixLQUFBLENBQU0rSSxJQUFJLEdBQUdFLElBQUEsR0FBTyxHQUFHQSxJQUFBLEdBQU9GLElBQUEsRUFBTUUsSUFBQSxJQUFRO1FBQ3ZGRCxJQUFBLENBQUtDLElBQUEsSUFBUS9NLFNBQUEsQ0FBVStNLElBQUE7TUFDekI7TUFDQVosT0FBQSxDQUFRYSxLQUFBLENBQU1YLElBQUEsRUFBTVMsSUFBSTtJQUMxQjtJQUNBSixXQUFBLENBQVlFLGNBQUEsR0FBaUJULE9BQUE7SUFDN0IsT0FBT0UsSUFBQSxDQUFLakQsRUFBQSxDQUFHOEMsT0FBQSxFQUFRUSxXQUFBLEVBQWFOLFFBQVE7RUFDOUM7RUFDQWEsTUFBTWQsT0FBQSxFQUFTQyxRQUFBLEVBQVU7SUFDdkIsTUFBTUMsSUFBQSxHQUFPO0lBQ2IsSUFBSSxDQUFDQSxJQUFBLENBQUtDLGVBQUEsSUFBbUJELElBQUEsQ0FBSzVDLFNBQUEsRUFBVyxPQUFPNEMsSUFBQTtJQUNwRCxJQUFJLE9BQU9GLE9BQUEsS0FBWSxZQUFZLE9BQU9FLElBQUE7SUFDMUMsTUFBTUUsTUFBQSxHQUFTSCxRQUFBLEdBQVcsWUFBWTtJQUN0QyxJQUFJQyxJQUFBLENBQUthLGtCQUFBLENBQW1CN00sT0FBQSxDQUFROEwsT0FBTyxJQUFJLEdBQUc7TUFDaERFLElBQUEsQ0FBS2Esa0JBQUEsQ0FBbUJYLE1BQUEsRUFBUUosT0FBTztJQUN6QztJQUNBLE9BQU9FLElBQUE7RUFDVDtFQUNBYyxPQUFPaEIsT0FBQSxFQUFTO0lBQ2QsTUFBTUUsSUFBQSxHQUFPO0lBQ2IsSUFBSSxDQUFDQSxJQUFBLENBQUtDLGVBQUEsSUFBbUJELElBQUEsQ0FBSzVDLFNBQUEsRUFBVyxPQUFPNEMsSUFBQTtJQUNwRCxJQUFJLENBQUNBLElBQUEsQ0FBS2Esa0JBQUEsRUFBb0IsT0FBT2IsSUFBQTtJQUNyQyxNQUFNZSxLQUFBLEdBQVFmLElBQUEsQ0FBS2Esa0JBQUEsQ0FBbUI3TSxPQUFBLENBQVE4TCxPQUFPO0lBQ3JELElBQUlpQixLQUFBLElBQVMsR0FBRztNQUNkZixJQUFBLENBQUthLGtCQUFBLENBQW1CbEIsTUFBQSxDQUFPb0IsS0FBQSxFQUFPLENBQUM7SUFDekM7SUFDQSxPQUFPZixJQUFBO0VBQ1Q7RUFDQU0sSUFBSVQsT0FBQSxFQUFRQyxPQUFBLEVBQVM7SUFDbkIsTUFBTUUsSUFBQSxHQUFPO0lBQ2IsSUFBSSxDQUFDQSxJQUFBLENBQUtDLGVBQUEsSUFBbUJELElBQUEsQ0FBSzVDLFNBQUEsRUFBVyxPQUFPNEMsSUFBQTtJQUNwRCxJQUFJLENBQUNBLElBQUEsQ0FBS0MsZUFBQSxFQUFpQixPQUFPRCxJQUFBO0lBQ2xDSCxPQUFBLENBQU8vTyxLQUFBLENBQU0sR0FBRyxFQUFFOUQsT0FBQSxDQUFRbVQsS0FBQSxJQUFTO01BQ2pDLElBQUksT0FBT0wsT0FBQSxLQUFZLGFBQWE7UUFDbENFLElBQUEsQ0FBS0MsZUFBQSxDQUFnQkUsS0FBQSxJQUFTLEVBQUM7TUFDakMsV0FBV0gsSUFBQSxDQUFLQyxlQUFBLENBQWdCRSxLQUFBLEdBQVE7UUFDdENILElBQUEsQ0FBS0MsZUFBQSxDQUFnQkUsS0FBQSxFQUFPblQsT0FBQSxDQUFRLENBQUNnVSxZQUFBLEVBQWNELEtBQUEsS0FBVTtVQUMzRCxJQUFJQyxZQUFBLEtBQWlCbEIsT0FBQSxJQUFXa0IsWUFBQSxDQUFhVCxjQUFBLElBQWtCUyxZQUFBLENBQWFULGNBQUEsS0FBbUJULE9BQUEsRUFBUztZQUN0R0UsSUFBQSxDQUFLQyxlQUFBLENBQWdCRSxLQUFBLEVBQU9SLE1BQUEsQ0FBT29CLEtBQUEsRUFBTyxDQUFDO1VBQzdDO1FBQ0YsQ0FBQztNQUNIO0lBQ0YsQ0FBQztJQUNELE9BQU9mLElBQUE7RUFDVDtFQUNBaEQsS0FBQSxFQUFPO0lBQ0wsTUFBTWdELElBQUEsR0FBTztJQUNiLElBQUksQ0FBQ0EsSUFBQSxDQUFLQyxlQUFBLElBQW1CRCxJQUFBLENBQUs1QyxTQUFBLEVBQVcsT0FBTzRDLElBQUE7SUFDcEQsSUFBSSxDQUFDQSxJQUFBLENBQUtDLGVBQUEsRUFBaUIsT0FBT0QsSUFBQTtJQUNsQyxJQUFJSCxPQUFBO0lBQ0osSUFBSW9CLElBQUE7SUFDSixJQUFJQyxPQUFBO0lBQ0osU0FBU0MsS0FBQSxHQUFReE4sU0FBQSxDQUFVekcsTUFBQSxFQUFRdVQsSUFBQSxHQUFPLElBQUloSixLQUFBLENBQU0wSixLQUFLLEdBQUdDLEtBQUEsR0FBUSxHQUFHQSxLQUFBLEdBQVFELEtBQUEsRUFBT0MsS0FBQSxJQUFTO01BQzdGWCxJQUFBLENBQUtXLEtBQUEsSUFBU3pOLFNBQUEsQ0FBVXlOLEtBQUE7SUFDMUI7SUFDQSxJQUFJLE9BQU9YLElBQUEsQ0FBSyxPQUFPLFlBQVloSixLQUFBLENBQU1DLE9BQUEsQ0FBUStJLElBQUEsQ0FBSyxFQUFFLEdBQUc7TUFDekRaLE9BQUEsR0FBU1ksSUFBQSxDQUFLO01BQ2RRLElBQUEsR0FBT1IsSUFBQSxDQUFLck4sS0FBQSxDQUFNLEdBQUdxTixJQUFBLENBQUt2VCxNQUFNO01BQ2hDZ1UsT0FBQSxHQUFVbEIsSUFBQTtJQUNaLE9BQU87TUFDTEgsT0FBQSxHQUFTWSxJQUFBLENBQUssR0FBR1ksTUFBQTtNQUNqQkosSUFBQSxHQUFPUixJQUFBLENBQUssR0FBR1EsSUFBQTtNQUNmQyxPQUFBLEdBQVVULElBQUEsQ0FBSyxHQUFHUyxPQUFBLElBQVdsQixJQUFBO0lBQy9CO0lBQ0FpQixJQUFBLENBQUtLLE9BQUEsQ0FBUUosT0FBTztJQUNwQixNQUFNSyxXQUFBLEdBQWM5SixLQUFBLENBQU1DLE9BQUEsQ0FBUW1JLE9BQU0sSUFBSUEsT0FBQSxHQUFTQSxPQUFBLENBQU8vTyxLQUFBLENBQU0sR0FBRztJQUNyRXlRLFdBQUEsQ0FBWXZVLE9BQUEsQ0FBUW1ULEtBQUEsSUFBUztNQUMzQixJQUFJSCxJQUFBLENBQUthLGtCQUFBLElBQXNCYixJQUFBLENBQUthLGtCQUFBLENBQW1CM1QsTUFBQSxFQUFRO1FBQzdEOFMsSUFBQSxDQUFLYSxrQkFBQSxDQUFtQjdULE9BQUEsQ0FBUWdVLFlBQUEsSUFBZ0I7VUFDOUNBLFlBQUEsQ0FBYUwsS0FBQSxDQUFNTyxPQUFBLEVBQVMsQ0FBQ2YsS0FBQSxFQUFPLEdBQUdjLElBQUksQ0FBQztRQUM5QyxDQUFDO01BQ0g7TUFDQSxJQUFJakIsSUFBQSxDQUFLQyxlQUFBLElBQW1CRCxJQUFBLENBQUtDLGVBQUEsQ0FBZ0JFLEtBQUEsR0FBUTtRQUN2REgsSUFBQSxDQUFLQyxlQUFBLENBQWdCRSxLQUFBLEVBQU9uVCxPQUFBLENBQVFnVSxZQUFBLElBQWdCO1VBQ2xEQSxZQUFBLENBQWFMLEtBQUEsQ0FBTU8sT0FBQSxFQUFTRCxJQUFJO1FBQ2xDLENBQUM7TUFDSDtJQUNGLENBQUM7SUFDRCxPQUFPakIsSUFBQTtFQUNUO0FBQ0Y7QUFFQSxTQUFTd0IsV0FBQSxFQUFhO0VBQ3BCLE1BQU0xTSxNQUFBLEdBQVM7RUFDZixJQUFJbUcsS0FBQTtFQUNKLElBQUlFLE1BQUE7RUFDSixNQUFNM0osRUFBQSxHQUFLc0QsTUFBQSxDQUFPdEQsRUFBQTtFQUNsQixJQUFJLE9BQU9zRCxNQUFBLENBQU9RLE1BQUEsQ0FBTzJGLEtBQUEsS0FBVSxlQUFlbkcsTUFBQSxDQUFPUSxNQUFBLENBQU8yRixLQUFBLEtBQVUsTUFBTTtJQUM5RUEsS0FBQSxHQUFRbkcsTUFBQSxDQUFPUSxNQUFBLENBQU8yRixLQUFBO0VBQ3hCLE9BQU87SUFDTEEsS0FBQSxHQUFRekosRUFBQSxDQUFHaVEsV0FBQTtFQUNiO0VBQ0EsSUFBSSxPQUFPM00sTUFBQSxDQUFPUSxNQUFBLENBQU82RixNQUFBLEtBQVcsZUFBZXJHLE1BQUEsQ0FBT1EsTUFBQSxDQUFPNkYsTUFBQSxLQUFXLE1BQU07SUFDaEZBLE1BQUEsR0FBU3JHLE1BQUEsQ0FBT1EsTUFBQSxDQUFPNkYsTUFBQTtFQUN6QixPQUFPO0lBQ0xBLE1BQUEsR0FBUzNKLEVBQUEsQ0FBR2tRLFlBQUE7RUFDZDtFQUNBLElBQUl6RyxLQUFBLEtBQVUsS0FBS25HLE1BQUEsQ0FBTzZNLFlBQUEsQ0FBYSxLQUFLeEcsTUFBQSxLQUFXLEtBQUtyRyxNQUFBLENBQU84TSxVQUFBLENBQVcsR0FBRztJQUMvRTtFQUNGO0VBR0EzRyxLQUFBLEdBQVFBLEtBQUEsR0FBUTRHLFFBQUEsQ0FBUzdJLFlBQUEsQ0FBYXhILEVBQUEsRUFBSSxjQUFjLEtBQUssR0FBRyxFQUFFLElBQUlxUSxRQUFBLENBQVM3SSxZQUFBLENBQWF4SCxFQUFBLEVBQUksZUFBZSxLQUFLLEdBQUcsRUFBRTtFQUN6SDJKLE1BQUEsR0FBU0EsTUFBQSxHQUFTMEcsUUFBQSxDQUFTN0ksWUFBQSxDQUFheEgsRUFBQSxFQUFJLGFBQWEsS0FBSyxHQUFHLEVBQUUsSUFBSXFRLFFBQUEsQ0FBUzdJLFlBQUEsQ0FBYXhILEVBQUEsRUFBSSxnQkFBZ0IsS0FBSyxHQUFHLEVBQUU7RUFDM0gsSUFBSWdMLE1BQUEsQ0FBT3NGLEtBQUEsQ0FBTTdHLEtBQUssR0FBR0EsS0FBQSxHQUFRO0VBQ2pDLElBQUl1QixNQUFBLENBQU9zRixLQUFBLENBQU0zRyxNQUFNLEdBQUdBLE1BQUEsR0FBUztFQUNuQ3hPLE1BQUEsQ0FBT29WLE1BQUEsQ0FBT2pOLE1BQUEsRUFBUTtJQUNwQm1HLEtBQUE7SUFDQUUsTUFBQTtJQUNBdkIsSUFBQSxFQUFNOUUsTUFBQSxDQUFPNk0sWUFBQSxDQUFhLElBQUkxRyxLQUFBLEdBQVFFO0VBQ3hDLENBQUM7QUFDSDtBQUVBLFNBQVM2RyxhQUFBLEVBQWU7RUFDdEIsTUFBTWxOLE1BQUEsR0FBUztFQUNmLFNBQVNtTiwwQkFBMEIzTyxJQUFBLEVBQU00TyxLQUFBLEVBQU87SUFDOUMsT0FBT3BQLFVBQUEsQ0FBV1EsSUFBQSxDQUFLekQsZ0JBQUEsQ0FBaUJpRixNQUFBLENBQU9xTixpQkFBQSxDQUFrQkQsS0FBSyxDQUFDLEtBQUssQ0FBQztFQUMvRTtFQUNBLE1BQU01TSxNQUFBLEdBQVNSLE1BQUEsQ0FBT1EsTUFBQTtFQUN0QixNQUFNO0lBQ0pFLFNBQUE7SUFDQTRNLFFBQUE7SUFDQXhJLElBQUEsRUFBTXlJLFVBQUE7SUFDTkMsWUFBQSxFQUFjQyxHQUFBO0lBQ2RDO0VBQ0YsSUFBSTFOLE1BQUE7RUFDSixNQUFNMk4sU0FBQSxHQUFZM04sTUFBQSxDQUFPNE4sT0FBQSxJQUFXcE4sTUFBQSxDQUFPb04sT0FBQSxDQUFRQyxPQUFBO0VBQ25ELE1BQU1DLG9CQUFBLEdBQXVCSCxTQUFBLEdBQVkzTixNQUFBLENBQU80TixPQUFBLENBQVFHLE1BQUEsQ0FBTzNWLE1BQUEsR0FBUzRILE1BQUEsQ0FBTytOLE1BQUEsQ0FBTzNWLE1BQUE7RUFDdEYsTUFBTTJWLE1BQUEsR0FBU2hNLGVBQUEsQ0FBZ0J1TCxRQUFBLEVBQVUsSUFBSXROLE1BQUEsQ0FBT1EsTUFBQSxDQUFPd04sVUFBQSxnQkFBMEI7RUFDckYsTUFBTUMsWUFBQSxHQUFlTixTQUFBLEdBQVkzTixNQUFBLENBQU80TixPQUFBLENBQVFHLE1BQUEsQ0FBTzNWLE1BQUEsR0FBUzJWLE1BQUEsQ0FBTzNWLE1BQUE7RUFDdkUsSUFBSThWLFFBQUEsR0FBVyxFQUFDO0VBQ2hCLE1BQU1DLFVBQUEsR0FBYSxFQUFDO0VBQ3BCLE1BQU1DLGVBQUEsR0FBa0IsRUFBQztFQUN6QixJQUFJQyxZQUFBLEdBQWU3TixNQUFBLENBQU84TixrQkFBQTtFQUMxQixJQUFJLE9BQU9ELFlBQUEsS0FBaUIsWUFBWTtJQUN0Q0EsWUFBQSxHQUFlN04sTUFBQSxDQUFPOE4sa0JBQUEsQ0FBbUJqUSxJQUFBLENBQUsyQixNQUFNO0VBQ3REO0VBQ0EsSUFBSXVPLFdBQUEsR0FBYy9OLE1BQUEsQ0FBT2dPLGlCQUFBO0VBQ3pCLElBQUksT0FBT0QsV0FBQSxLQUFnQixZQUFZO0lBQ3JDQSxXQUFBLEdBQWMvTixNQUFBLENBQU9nTyxpQkFBQSxDQUFrQm5RLElBQUEsQ0FBSzJCLE1BQU07RUFDcEQ7RUFDQSxNQUFNeU8sc0JBQUEsR0FBeUJ6TyxNQUFBLENBQU9rTyxRQUFBLENBQVM5VixNQUFBO0VBQy9DLE1BQU1zVyx3QkFBQSxHQUEyQjFPLE1BQUEsQ0FBT21PLFVBQUEsQ0FBVy9WLE1BQUE7RUFDbkQsSUFBSXVXLFlBQUEsR0FBZW5PLE1BQUEsQ0FBT21PLFlBQUE7RUFDMUIsSUFBSUMsYUFBQSxHQUFnQixDQUFDUCxZQUFBO0VBQ3JCLElBQUlRLGFBQUEsR0FBZ0I7RUFDcEIsSUFBSTVDLEtBQUEsR0FBUTtFQUNaLElBQUksT0FBT3NCLFVBQUEsS0FBZSxhQUFhO0lBQ3JDO0VBQ0Y7RUFDQSxJQUFJLE9BQU9vQixZQUFBLEtBQWlCLFlBQVlBLFlBQUEsQ0FBYXpQLE9BQUEsQ0FBUSxHQUFHLEtBQUssR0FBRztJQUN0RXlQLFlBQUEsR0FBZTNRLFVBQUEsQ0FBVzJRLFlBQUEsQ0FBYW5SLE9BQUEsQ0FBUSxLQUFLLEVBQUUsQ0FBQyxJQUFJLE1BQU0rUCxVQUFBO0VBQ25FLFdBQVcsT0FBT29CLFlBQUEsS0FBaUIsVUFBVTtJQUMzQ0EsWUFBQSxHQUFlM1EsVUFBQSxDQUFXMlEsWUFBWTtFQUN4QztFQUNBM08sTUFBQSxDQUFPOE8sV0FBQSxHQUFjLENBQUNILFlBQUE7RUFHdEJaLE1BQUEsQ0FBTzdWLE9BQUEsQ0FBUTJKLE9BQUEsSUFBVztJQUN4QixJQUFJNEwsR0FBQSxFQUFLO01BQ1A1TCxPQUFBLENBQVF6SSxLQUFBLENBQU0yVixVQUFBLEdBQWE7SUFDN0IsT0FBTztNQUNMbE4sT0FBQSxDQUFRekksS0FBQSxDQUFNNFYsV0FBQSxHQUFjO0lBQzlCO0lBQ0FuTixPQUFBLENBQVF6SSxLQUFBLENBQU02VixZQUFBLEdBQWU7SUFDN0JwTixPQUFBLENBQVF6SSxLQUFBLENBQU04VixTQUFBLEdBQVk7RUFDNUIsQ0FBQztFQUdELElBQUkxTyxNQUFBLENBQU8yTyxjQUFBLElBQWtCM08sTUFBQSxDQUFPNE8sT0FBQSxFQUFTO0lBQzNDMVAsY0FBQSxDQUFlZ0IsU0FBQSxFQUFXLG1DQUFtQyxFQUFFO0lBQy9EaEIsY0FBQSxDQUFlZ0IsU0FBQSxFQUFXLGtDQUFrQyxFQUFFO0VBQ2hFO0VBQ0EsTUFBTTJPLFdBQUEsR0FBYzdPLE1BQUEsQ0FBTzhPLElBQUEsSUFBUTlPLE1BQUEsQ0FBTzhPLElBQUEsQ0FBS0MsSUFBQSxHQUFPLEtBQUt2UCxNQUFBLENBQU9zUCxJQUFBO0VBQ2xFLElBQUlELFdBQUEsRUFBYTtJQUNmclAsTUFBQSxDQUFPc1AsSUFBQSxDQUFLRSxVQUFBLENBQVd6QixNQUFNO0VBQy9CLFdBQVcvTixNQUFBLENBQU9zUCxJQUFBLEVBQU07SUFDdEJ0UCxNQUFBLENBQU9zUCxJQUFBLENBQUtHLFdBQUEsQ0FBWTtFQUMxQjtFQUdBLElBQUlDLFNBQUE7RUFDSixNQUFNQyxvQkFBQSxHQUF1Qm5QLE1BQUEsQ0FBT29QLGFBQUEsS0FBa0IsVUFBVXBQLE1BQUEsQ0FBT3FQLFdBQUEsSUFBZWhZLE1BQUEsQ0FBT0ksSUFBQSxDQUFLdUksTUFBQSxDQUFPcVAsV0FBVyxFQUFFNVQsTUFBQSxDQUFPOUQsR0FBQSxJQUFPO0lBQ2xJLE9BQU8sT0FBT3FJLE1BQUEsQ0FBT3FQLFdBQUEsQ0FBWTFYLEdBQUEsRUFBS3lYLGFBQUEsS0FBa0I7RUFDMUQsQ0FBQyxFQUFFeFgsTUFBQSxHQUFTO0VBQ1osU0FBUzJHLENBQUEsR0FBSSxHQUFHQSxDQUFBLEdBQUlrUCxZQUFBLEVBQWNsUCxDQUFBLElBQUssR0FBRztJQUN4QzJRLFNBQUEsR0FBWTtJQUNaLElBQUlJLE1BQUE7SUFDSixJQUFJL0IsTUFBQSxDQUFPaFAsQ0FBQSxHQUFJK1EsTUFBQSxHQUFRL0IsTUFBQSxDQUFPaFAsQ0FBQTtJQUM5QixJQUFJc1EsV0FBQSxFQUFhO01BQ2ZyUCxNQUFBLENBQU9zUCxJQUFBLENBQUtTLFdBQUEsQ0FBWWhSLENBQUEsRUFBRytRLE1BQUEsRUFBTy9CLE1BQU07SUFDMUM7SUFDQSxJQUFJQSxNQUFBLENBQU9oUCxDQUFBLEtBQU1tRixZQUFBLENBQWE0TCxNQUFBLEVBQU8sU0FBUyxNQUFNLFFBQVE7SUFFNUQsSUFBSXRQLE1BQUEsQ0FBT29QLGFBQUEsS0FBa0IsUUFBUTtNQUNuQyxJQUFJRCxvQkFBQSxFQUFzQjtRQUN4QjVCLE1BQUEsQ0FBT2hQLENBQUEsRUFBRzNGLEtBQUEsQ0FBTTRHLE1BQUEsQ0FBT3FOLGlCQUFBLENBQWtCLE9BQU8sS0FBSztNQUN2RDtNQUNBLE1BQU0yQyxXQUFBLEdBQWNsVixnQkFBQSxDQUFpQmdWLE1BQUs7TUFDMUMsTUFBTUcsZ0JBQUEsR0FBbUJILE1BQUEsQ0FBTTFXLEtBQUEsQ0FBTWdFLFNBQUE7TUFDckMsTUFBTThTLHNCQUFBLEdBQXlCSixNQUFBLENBQU0xVyxLQUFBLENBQU1pRSxlQUFBO01BQzNDLElBQUk0UyxnQkFBQSxFQUFrQjtRQUNwQkgsTUFBQSxDQUFNMVcsS0FBQSxDQUFNZ0UsU0FBQSxHQUFZO01BQzFCO01BQ0EsSUFBSThTLHNCQUFBLEVBQXdCO1FBQzFCSixNQUFBLENBQU0xVyxLQUFBLENBQU1pRSxlQUFBLEdBQWtCO01BQ2hDO01BQ0EsSUFBSW1ELE1BQUEsQ0FBTzJQLFlBQUEsRUFBYztRQUN2QlQsU0FBQSxHQUFZMVAsTUFBQSxDQUFPNk0sWUFBQSxDQUFhLElBQUloSSxnQkFBQSxDQUFpQmlMLE1BQUEsRUFBTyxTQUFTLElBQUksSUFBSWpMLGdCQUFBLENBQWlCaUwsTUFBQSxFQUFPLFVBQVUsSUFBSTtNQUNySCxPQUFPO1FBRUwsTUFBTTNKLEtBQUEsR0FBUWdILHlCQUFBLENBQTBCNkMsV0FBQSxFQUFhLE9BQU87UUFDNUQsTUFBTUksV0FBQSxHQUFjakQseUJBQUEsQ0FBMEI2QyxXQUFBLEVBQWEsY0FBYztRQUN6RSxNQUFNSyxZQUFBLEdBQWVsRCx5QkFBQSxDQUEwQjZDLFdBQUEsRUFBYSxlQUFlO1FBQzNFLE1BQU1qQixVQUFBLEdBQWE1Qix5QkFBQSxDQUEwQjZDLFdBQUEsRUFBYSxhQUFhO1FBQ3ZFLE1BQU1oQixXQUFBLEdBQWM3Qix5QkFBQSxDQUEwQjZDLFdBQUEsRUFBYSxjQUFjO1FBQ3pFLE1BQU1NLFNBQUEsR0FBWU4sV0FBQSxDQUFZalYsZ0JBQUEsQ0FBaUIsWUFBWTtRQUMzRCxJQUFJdVYsU0FBQSxJQUFhQSxTQUFBLEtBQWMsY0FBYztVQUMzQ1osU0FBQSxHQUFZdkosS0FBQSxHQUFRNEksVUFBQSxHQUFhQyxXQUFBO1FBQ25DLE9BQU87VUFDTCxNQUFNO1lBQ0pyQyxXQUFBO1lBQ0EzSDtVQUNGLElBQUk4SyxNQUFBO1VBQ0pKLFNBQUEsR0FBWXZKLEtBQUEsR0FBUWlLLFdBQUEsR0FBY0MsWUFBQSxHQUFldEIsVUFBQSxHQUFhQyxXQUFBLElBQWVoSyxXQUFBLEdBQWMySCxXQUFBO1FBQzdGO01BQ0Y7TUFDQSxJQUFJc0QsZ0JBQUEsRUFBa0I7UUFDcEJILE1BQUEsQ0FBTTFXLEtBQUEsQ0FBTWdFLFNBQUEsR0FBWTZTLGdCQUFBO01BQzFCO01BQ0EsSUFBSUMsc0JBQUEsRUFBd0I7UUFDMUJKLE1BQUEsQ0FBTTFXLEtBQUEsQ0FBTWlFLGVBQUEsR0FBa0I2UyxzQkFBQTtNQUNoQztNQUNBLElBQUkxUCxNQUFBLENBQU8yUCxZQUFBLEVBQWNULFNBQUEsR0FBWXZPLElBQUEsQ0FBS29QLEtBQUEsQ0FBTWIsU0FBUztJQUMzRCxPQUFPO01BQ0xBLFNBQUEsSUFBYW5DLFVBQUEsSUFBYy9NLE1BQUEsQ0FBT29QLGFBQUEsR0FBZ0IsS0FBS2pCLFlBQUEsSUFBZ0JuTyxNQUFBLENBQU9vUCxhQUFBO01BQzlFLElBQUlwUCxNQUFBLENBQU8yUCxZQUFBLEVBQWNULFNBQUEsR0FBWXZPLElBQUEsQ0FBS29QLEtBQUEsQ0FBTWIsU0FBUztNQUN6RCxJQUFJM0IsTUFBQSxDQUFPaFAsQ0FBQSxHQUFJO1FBQ2JnUCxNQUFBLENBQU9oUCxDQUFBLEVBQUczRixLQUFBLENBQU00RyxNQUFBLENBQU9xTixpQkFBQSxDQUFrQixPQUFPLEtBQUssR0FBR3FDLFNBQUE7TUFDMUQ7SUFDRjtJQUNBLElBQUkzQixNQUFBLENBQU9oUCxDQUFBLEdBQUk7TUFDYmdQLE1BQUEsQ0FBT2hQLENBQUEsRUFBR3lSLGVBQUEsR0FBa0JkLFNBQUE7SUFDOUI7SUFDQXRCLGVBQUEsQ0FBZ0J2SyxJQUFBLENBQUs2TCxTQUFTO0lBQzlCLElBQUlsUCxNQUFBLENBQU8yTyxjQUFBLEVBQWdCO01BQ3pCUCxhQUFBLEdBQWdCQSxhQUFBLEdBQWdCYyxTQUFBLEdBQVksSUFBSWIsYUFBQSxHQUFnQixJQUFJRixZQUFBO01BQ3BFLElBQUlFLGFBQUEsS0FBa0IsS0FBSzlQLENBQUEsS0FBTSxHQUFHNlAsYUFBQSxHQUFnQkEsYUFBQSxHQUFnQnJCLFVBQUEsR0FBYSxJQUFJb0IsWUFBQTtNQUNyRixJQUFJNVAsQ0FBQSxLQUFNLEdBQUc2UCxhQUFBLEdBQWdCQSxhQUFBLEdBQWdCckIsVUFBQSxHQUFhLElBQUlvQixZQUFBO01BQzlELElBQUl4TixJQUFBLENBQUtzUCxHQUFBLENBQUk3QixhQUFhLElBQUksSUFBSSxLQUFNQSxhQUFBLEdBQWdCO01BQ3hELElBQUlwTyxNQUFBLENBQU8yUCxZQUFBLEVBQWN2QixhQUFBLEdBQWdCek4sSUFBQSxDQUFLb1AsS0FBQSxDQUFNM0IsYUFBYTtNQUNqRSxJQUFJM0MsS0FBQSxHQUFRekwsTUFBQSxDQUFPa1EsY0FBQSxLQUFtQixHQUFHeEMsUUFBQSxDQUFTckssSUFBQSxDQUFLK0ssYUFBYTtNQUNwRVQsVUFBQSxDQUFXdEssSUFBQSxDQUFLK0ssYUFBYTtJQUMvQixPQUFPO01BQ0wsSUFBSXBPLE1BQUEsQ0FBTzJQLFlBQUEsRUFBY3ZCLGFBQUEsR0FBZ0J6TixJQUFBLENBQUtvUCxLQUFBLENBQU0zQixhQUFhO01BQ2pFLEtBQUszQyxLQUFBLEdBQVE5SyxJQUFBLENBQUtFLEdBQUEsQ0FBSXJCLE1BQUEsQ0FBT1EsTUFBQSxDQUFPbVEsa0JBQUEsRUFBb0IxRSxLQUFLLEtBQUtqTSxNQUFBLENBQU9RLE1BQUEsQ0FBT2tRLGNBQUEsS0FBbUIsR0FBR3hDLFFBQUEsQ0FBU3JLLElBQUEsQ0FBSytLLGFBQWE7TUFDaklULFVBQUEsQ0FBV3RLLElBQUEsQ0FBSytLLGFBQWE7TUFDN0JBLGFBQUEsR0FBZ0JBLGFBQUEsR0FBZ0JjLFNBQUEsR0FBWWYsWUFBQTtJQUM5QztJQUNBM08sTUFBQSxDQUFPOE8sV0FBQSxJQUFlWSxTQUFBLEdBQVlmLFlBQUE7SUFDbENFLGFBQUEsR0FBZ0JhLFNBQUE7SUFDaEJ6RCxLQUFBLElBQVM7RUFDWDtFQUNBak0sTUFBQSxDQUFPOE8sV0FBQSxHQUFjM04sSUFBQSxDQUFLQyxHQUFBLENBQUlwQixNQUFBLENBQU84TyxXQUFBLEVBQWF2QixVQUFVLElBQUlnQixXQUFBO0VBQ2hFLElBQUlkLEdBQUEsSUFBT0MsUUFBQSxLQUFhbE4sTUFBQSxDQUFPb1EsTUFBQSxLQUFXLFdBQVdwUSxNQUFBLENBQU9vUSxNQUFBLEtBQVcsY0FBYztJQUNuRmxRLFNBQUEsQ0FBVXRILEtBQUEsQ0FBTStNLEtBQUEsR0FBUSxHQUFHbkcsTUFBQSxDQUFPOE8sV0FBQSxHQUFjSCxZQUFBO0VBQ2xEO0VBQ0EsSUFBSW5PLE1BQUEsQ0FBT3FRLGNBQUEsRUFBZ0I7SUFDekJuUSxTQUFBLENBQVV0SCxLQUFBLENBQU00RyxNQUFBLENBQU9xTixpQkFBQSxDQUFrQixPQUFPLEtBQUssR0FBR3JOLE1BQUEsQ0FBTzhPLFdBQUEsR0FBY0gsWUFBQTtFQUMvRTtFQUNBLElBQUlVLFdBQUEsRUFBYTtJQUNmclAsTUFBQSxDQUFPc1AsSUFBQSxDQUFLd0IsaUJBQUEsQ0FBa0JwQixTQUFBLEVBQVd4QixRQUFRO0VBQ25EO0VBR0EsSUFBSSxDQUFDMU4sTUFBQSxDQUFPMk8sY0FBQSxFQUFnQjtJQUMxQixNQUFNNEIsYUFBQSxHQUFnQixFQUFDO0lBQ3ZCLFNBQVNoUyxDQUFBLEdBQUksR0FBR0EsQ0FBQSxHQUFJbVAsUUFBQSxDQUFTOVYsTUFBQSxFQUFRMkcsQ0FBQSxJQUFLLEdBQUc7TUFDM0MsSUFBSWlTLGNBQUEsR0FBaUI5QyxRQUFBLENBQVNuUCxDQUFBO01BQzlCLElBQUl5QixNQUFBLENBQU8yUCxZQUFBLEVBQWNhLGNBQUEsR0FBaUI3UCxJQUFBLENBQUtvUCxLQUFBLENBQU1TLGNBQWM7TUFDbkUsSUFBSTlDLFFBQUEsQ0FBU25QLENBQUEsS0FBTWlCLE1BQUEsQ0FBTzhPLFdBQUEsR0FBY3ZCLFVBQUEsRUFBWTtRQUNsRHdELGFBQUEsQ0FBY2xOLElBQUEsQ0FBS21OLGNBQWM7TUFDbkM7SUFDRjtJQUNBOUMsUUFBQSxHQUFXNkMsYUFBQTtJQUNYLElBQUk1UCxJQUFBLENBQUtvUCxLQUFBLENBQU12USxNQUFBLENBQU84TyxXQUFBLEdBQWN2QixVQUFVLElBQUlwTSxJQUFBLENBQUtvUCxLQUFBLENBQU1yQyxRQUFBLENBQVNBLFFBQUEsQ0FBUzlWLE1BQUEsR0FBUyxFQUFFLElBQUksR0FBRztNQUMvRjhWLFFBQUEsQ0FBU3JLLElBQUEsQ0FBSzdELE1BQUEsQ0FBTzhPLFdBQUEsR0FBY3ZCLFVBQVU7SUFDL0M7RUFDRjtFQUNBLElBQUlJLFNBQUEsSUFBYW5OLE1BQUEsQ0FBT3lRLElBQUEsRUFBTTtJQUM1QixNQUFNbk0sSUFBQSxHQUFPc0osZUFBQSxDQUFnQixLQUFLTyxZQUFBO0lBQ2xDLElBQUluTyxNQUFBLENBQU9rUSxjQUFBLEdBQWlCLEdBQUc7TUFDN0IsTUFBTVEsTUFBQSxHQUFTL1AsSUFBQSxDQUFLZ1EsSUFBQSxFQUFNblIsTUFBQSxDQUFPNE4sT0FBQSxDQUFRd0QsWUFBQSxHQUFlcFIsTUFBQSxDQUFPNE4sT0FBQSxDQUFReUQsV0FBQSxJQUFlN1EsTUFBQSxDQUFPa1EsY0FBYztNQUMzRyxNQUFNWSxTQUFBLEdBQVl4TSxJQUFBLEdBQU90RSxNQUFBLENBQU9rUSxjQUFBO01BQ2hDLFNBQVMzUixDQUFBLEdBQUksR0FBR0EsQ0FBQSxHQUFJbVMsTUFBQSxFQUFRblMsQ0FBQSxJQUFLLEdBQUc7UUFDbENtUCxRQUFBLENBQVNySyxJQUFBLENBQUtxSyxRQUFBLENBQVNBLFFBQUEsQ0FBUzlWLE1BQUEsR0FBUyxLQUFLa1osU0FBUztNQUN6RDtJQUNGO0lBQ0EsU0FBU3ZTLENBQUEsR0FBSSxHQUFHQSxDQUFBLEdBQUlpQixNQUFBLENBQU80TixPQUFBLENBQVF3RCxZQUFBLEdBQWVwUixNQUFBLENBQU80TixPQUFBLENBQVF5RCxXQUFBLEVBQWF0UyxDQUFBLElBQUssR0FBRztNQUNwRixJQUFJeUIsTUFBQSxDQUFPa1EsY0FBQSxLQUFtQixHQUFHO1FBQy9CeEMsUUFBQSxDQUFTckssSUFBQSxDQUFLcUssUUFBQSxDQUFTQSxRQUFBLENBQVM5VixNQUFBLEdBQVMsS0FBSzBNLElBQUk7TUFDcEQ7TUFDQXFKLFVBQUEsQ0FBV3RLLElBQUEsQ0FBS3NLLFVBQUEsQ0FBV0EsVUFBQSxDQUFXL1YsTUFBQSxHQUFTLEtBQUswTSxJQUFJO01BQ3hEOUUsTUFBQSxDQUFPOE8sV0FBQSxJQUFlaEssSUFBQTtJQUN4QjtFQUNGO0VBQ0EsSUFBSW9KLFFBQUEsQ0FBUzlWLE1BQUEsS0FBVyxHQUFHOFYsUUFBQSxHQUFXLENBQUMsQ0FBQztFQUN4QyxJQUFJUyxZQUFBLEtBQWlCLEdBQUc7SUFDdEIsTUFBTXhXLEdBQUEsR0FBTTZILE1BQUEsQ0FBTzZNLFlBQUEsQ0FBYSxLQUFLWSxHQUFBLEdBQU0sZUFBZXpOLE1BQUEsQ0FBT3FOLGlCQUFBLENBQWtCLGFBQWE7SUFDaEdVLE1BQUEsQ0FBTzlSLE1BQUEsQ0FBTyxDQUFDc1YsQ0FBQSxFQUFHQyxVQUFBLEtBQWU7TUFDL0IsSUFBSSxDQUFDaFIsTUFBQSxDQUFPNE8sT0FBQSxJQUFXNU8sTUFBQSxDQUFPeVEsSUFBQSxFQUFNLE9BQU87TUFDM0MsSUFBSU8sVUFBQSxLQUFlekQsTUFBQSxDQUFPM1YsTUFBQSxHQUFTLEdBQUc7UUFDcEMsT0FBTztNQUNUO01BQ0EsT0FBTztJQUNULENBQUMsRUFBRUYsT0FBQSxDQUFRMkosT0FBQSxJQUFXO01BQ3BCQSxPQUFBLENBQVF6SSxLQUFBLENBQU1qQixHQUFBLElBQU8sR0FBR3dXLFlBQUE7SUFDMUIsQ0FBQztFQUNIO0VBQ0EsSUFBSW5PLE1BQUEsQ0FBTzJPLGNBQUEsSUFBa0IzTyxNQUFBLENBQU9pUixvQkFBQSxFQUFzQjtJQUN4RCxJQUFJQyxhQUFBLEdBQWdCO0lBQ3BCdEQsZUFBQSxDQUFnQmxXLE9BQUEsQ0FBUXlaLGNBQUEsSUFBa0I7TUFDeENELGFBQUEsSUFBaUJDLGNBQUEsSUFBa0JoRCxZQUFBLElBQWdCO0lBQ3JELENBQUM7SUFDRCtDLGFBQUEsSUFBaUIvQyxZQUFBO0lBQ2pCLE1BQU1pRCxPQUFBLEdBQVVGLGFBQUEsR0FBZ0JuRSxVQUFBO0lBQ2hDVyxRQUFBLEdBQVdBLFFBQUEsQ0FBUzVRLEdBQUEsQ0FBSXVVLElBQUEsSUFBUTtNQUM5QixJQUFJQSxJQUFBLElBQVEsR0FBRyxPQUFPLENBQUN4RCxZQUFBO01BQ3ZCLElBQUl3RCxJQUFBLEdBQU9ELE9BQUEsRUFBUyxPQUFPQSxPQUFBLEdBQVVyRCxXQUFBO01BQ3JDLE9BQU9zRCxJQUFBO0lBQ1QsQ0FBQztFQUNIO0VBQ0EsSUFBSXJSLE1BQUEsQ0FBT3NSLHdCQUFBLEVBQTBCO0lBQ25DLElBQUlKLGFBQUEsR0FBZ0I7SUFDcEJ0RCxlQUFBLENBQWdCbFcsT0FBQSxDQUFReVosY0FBQSxJQUFrQjtNQUN4Q0QsYUFBQSxJQUFpQkMsY0FBQSxJQUFrQmhELFlBQUEsSUFBZ0I7SUFDckQsQ0FBQztJQUNEK0MsYUFBQSxJQUFpQi9DLFlBQUE7SUFDakIsTUFBTW9ELFVBQUEsSUFBY3ZSLE1BQUEsQ0FBTzhOLGtCQUFBLElBQXNCLE1BQU05TixNQUFBLENBQU9nTyxpQkFBQSxJQUFxQjtJQUNuRixJQUFJa0QsYUFBQSxHQUFnQkssVUFBQSxHQUFheEUsVUFBQSxFQUFZO01BQzNDLE1BQU15RSxlQUFBLElBQW1CekUsVUFBQSxHQUFhbUUsYUFBQSxHQUFnQkssVUFBQSxJQUFjO01BQ3BFN0QsUUFBQSxDQUFTaFcsT0FBQSxDQUFRLENBQUMyWixJQUFBLEVBQU1JLFNBQUEsS0FBYztRQUNwQy9ELFFBQUEsQ0FBUytELFNBQUEsSUFBYUosSUFBQSxHQUFPRyxlQUFBO01BQy9CLENBQUM7TUFDRDdELFVBQUEsQ0FBV2pXLE9BQUEsQ0FBUSxDQUFDMlosSUFBQSxFQUFNSSxTQUFBLEtBQWM7UUFDdEM5RCxVQUFBLENBQVc4RCxTQUFBLElBQWFKLElBQUEsR0FBT0csZUFBQTtNQUNqQyxDQUFDO0lBQ0g7RUFDRjtFQUNBbmEsTUFBQSxDQUFPb1YsTUFBQSxDQUFPak4sTUFBQSxFQUFRO0lBQ3BCK04sTUFBQTtJQUNBRyxRQUFBO0lBQ0FDLFVBQUE7SUFDQUM7RUFDRixDQUFDO0VBQ0QsSUFBSTVOLE1BQUEsQ0FBTzJPLGNBQUEsSUFBa0IzTyxNQUFBLENBQU80TyxPQUFBLElBQVcsQ0FBQzVPLE1BQUEsQ0FBT2lSLG9CQUFBLEVBQXNCO0lBQzNFL1IsY0FBQSxDQUFlZ0IsU0FBQSxFQUFXLG1DQUFtQyxHQUFHLENBQUN3TixRQUFBLENBQVMsTUFBTTtJQUNoRnhPLGNBQUEsQ0FBZWdCLFNBQUEsRUFBVyxrQ0FBa0MsR0FBR1YsTUFBQSxDQUFPOEUsSUFBQSxHQUFPLElBQUlzSixlQUFBLENBQWdCQSxlQUFBLENBQWdCaFcsTUFBQSxHQUFTLEtBQUssS0FBSztJQUNwSSxNQUFNOFosYUFBQSxHQUFnQixDQUFDbFMsTUFBQSxDQUFPa08sUUFBQSxDQUFTO0lBQ3ZDLE1BQU1pRSxlQUFBLEdBQWtCLENBQUNuUyxNQUFBLENBQU9tTyxVQUFBLENBQVc7SUFDM0NuTyxNQUFBLENBQU9rTyxRQUFBLEdBQVdsTyxNQUFBLENBQU9rTyxRQUFBLENBQVM1USxHQUFBLENBQUk4VSxDQUFBLElBQUtBLENBQUEsR0FBSUYsYUFBYTtJQUM1RGxTLE1BQUEsQ0FBT21PLFVBQUEsR0FBYW5PLE1BQUEsQ0FBT21PLFVBQUEsQ0FBVzdRLEdBQUEsQ0FBSThVLENBQUEsSUFBS0EsQ0FBQSxHQUFJRCxlQUFlO0VBQ3BFO0VBQ0EsSUFBSWxFLFlBQUEsS0FBaUJILG9CQUFBLEVBQXNCO0lBQ3pDOU4sTUFBQSxDQUFPa0ksSUFBQSxDQUFLLG9CQUFvQjtFQUNsQztFQUNBLElBQUlnRyxRQUFBLENBQVM5VixNQUFBLEtBQVdxVyxzQkFBQSxFQUF3QjtJQUM5QyxJQUFJek8sTUFBQSxDQUFPUSxNQUFBLENBQU82UixhQUFBLEVBQWVyUyxNQUFBLENBQU9zUyxhQUFBLENBQWM7SUFDdER0UyxNQUFBLENBQU9rSSxJQUFBLENBQUssc0JBQXNCO0VBQ3BDO0VBQ0EsSUFBSWlHLFVBQUEsQ0FBVy9WLE1BQUEsS0FBV3NXLHdCQUFBLEVBQTBCO0lBQ2xEMU8sTUFBQSxDQUFPa0ksSUFBQSxDQUFLLHdCQUF3QjtFQUN0QztFQUNBLElBQUkxSCxNQUFBLENBQU8rUixtQkFBQSxFQUFxQjtJQUM5QnZTLE1BQUEsQ0FBT3dTLGtCQUFBLENBQW1CO0VBQzVCO0VBQ0F4UyxNQUFBLENBQU9rSSxJQUFBLENBQUssZUFBZTtFQUMzQixJQUFJLENBQUN5RixTQUFBLElBQWEsQ0FBQ25OLE1BQUEsQ0FBTzRPLE9BQUEsS0FBWTVPLE1BQUEsQ0FBT29RLE1BQUEsS0FBVyxXQUFXcFEsTUFBQSxDQUFPb1EsTUFBQSxLQUFXLFNBQVM7SUFDNUYsTUFBTTZCLG1CQUFBLEdBQXNCLEdBQUdqUyxNQUFBLENBQU9rUyxzQkFBQTtJQUN0QyxNQUFNQywwQkFBQSxHQUE2QjNTLE1BQUEsQ0FBT3RELEVBQUEsQ0FBRytGLFNBQUEsQ0FBVW1RLFFBQUEsQ0FBU0gsbUJBQW1CO0lBQ25GLElBQUl4RSxZQUFBLElBQWdCek4sTUFBQSxDQUFPcVMsdUJBQUEsRUFBeUI7TUFDbEQsSUFBSSxDQUFDRiwwQkFBQSxFQUE0QjNTLE1BQUEsQ0FBT3RELEVBQUEsQ0FBRytGLFNBQUEsQ0FBVUMsR0FBQSxDQUFJK1AsbUJBQW1CO0lBQzlFLFdBQVdFLDBCQUFBLEVBQTRCO01BQ3JDM1MsTUFBQSxDQUFPdEQsRUFBQSxDQUFHK0YsU0FBQSxDQUFVcVEsTUFBQSxDQUFPTCxtQkFBbUI7SUFDaEQ7RUFDRjtBQUNGO0FBRUEsU0FBU00saUJBQWlCdFMsS0FBQSxFQUFPO0VBQy9CLE1BQU1ULE1BQUEsR0FBUztFQUNmLE1BQU1nVCxZQUFBLEdBQWUsRUFBQztFQUN0QixNQUFNckYsU0FBQSxHQUFZM04sTUFBQSxDQUFPNE4sT0FBQSxJQUFXNU4sTUFBQSxDQUFPUSxNQUFBLENBQU9vTixPQUFBLENBQVFDLE9BQUE7RUFDMUQsSUFBSWpGLFNBQUEsR0FBWTtFQUNoQixJQUFJN0osQ0FBQTtFQUNKLElBQUksT0FBTzBCLEtBQUEsS0FBVSxVQUFVO0lBQzdCVCxNQUFBLENBQU9pVCxhQUFBLENBQWN4UyxLQUFLO0VBQzVCLFdBQVdBLEtBQUEsS0FBVSxNQUFNO0lBQ3pCVCxNQUFBLENBQU9pVCxhQUFBLENBQWNqVCxNQUFBLENBQU9RLE1BQUEsQ0FBT0MsS0FBSztFQUMxQztFQUNBLE1BQU15UyxlQUFBLEdBQWtCakgsS0FBQSxJQUFTO0lBQy9CLElBQUkwQixTQUFBLEVBQVc7TUFDYixPQUFPM04sTUFBQSxDQUFPK04sTUFBQSxDQUFPL04sTUFBQSxDQUFPbVQsbUJBQUEsQ0FBb0JsSCxLQUFLO0lBQ3ZEO0lBQ0EsT0FBT2pNLE1BQUEsQ0FBTytOLE1BQUEsQ0FBTzlCLEtBQUE7RUFDdkI7RUFFQSxJQUFJak0sTUFBQSxDQUFPUSxNQUFBLENBQU9vUCxhQUFBLEtBQWtCLFVBQVU1UCxNQUFBLENBQU9RLE1BQUEsQ0FBT29QLGFBQUEsR0FBZ0IsR0FBRztJQUM3RSxJQUFJNVAsTUFBQSxDQUFPUSxNQUFBLENBQU8yTyxjQUFBLEVBQWdCO01BQ2hDLENBQUNuUCxNQUFBLENBQU9vVCxhQUFBLElBQWlCLEVBQUMsRUFBR2xiLE9BQUEsQ0FBUTRYLE1BQUEsSUFBUztRQUM1Q2tELFlBQUEsQ0FBYW5QLElBQUEsQ0FBS2lNLE1BQUs7TUFDekIsQ0FBQztJQUNILE9BQU87TUFDTCxLQUFLL1EsQ0FBQSxHQUFJLEdBQUdBLENBQUEsR0FBSW9DLElBQUEsQ0FBS2dRLElBQUEsQ0FBS25SLE1BQUEsQ0FBT1EsTUFBQSxDQUFPb1AsYUFBYSxHQUFHN1EsQ0FBQSxJQUFLLEdBQUc7UUFDOUQsTUFBTWtOLEtBQUEsR0FBUWpNLE1BQUEsQ0FBT3FULFdBQUEsR0FBY3RVLENBQUE7UUFDbkMsSUFBSWtOLEtBQUEsR0FBUWpNLE1BQUEsQ0FBTytOLE1BQUEsQ0FBTzNWLE1BQUEsSUFBVSxDQUFDdVYsU0FBQSxFQUFXO1FBQ2hEcUYsWUFBQSxDQUFhblAsSUFBQSxDQUFLcVAsZUFBQSxDQUFnQmpILEtBQUssQ0FBQztNQUMxQztJQUNGO0VBQ0YsT0FBTztJQUNMK0csWUFBQSxDQUFhblAsSUFBQSxDQUFLcVAsZUFBQSxDQUFnQmxULE1BQUEsQ0FBT3FULFdBQVcsQ0FBQztFQUN2RDtFQUdBLEtBQUt0VSxDQUFBLEdBQUksR0FBR0EsQ0FBQSxHQUFJaVUsWUFBQSxDQUFhNWEsTUFBQSxFQUFRMkcsQ0FBQSxJQUFLLEdBQUc7SUFDM0MsSUFBSSxPQUFPaVUsWUFBQSxDQUFhalUsQ0FBQSxNQUFPLGFBQWE7TUFDMUMsTUFBTXNILE1BQUEsR0FBUzJNLFlBQUEsQ0FBYWpVLENBQUEsRUFBR3VVLFlBQUE7TUFDL0IxSyxTQUFBLEdBQVl2QyxNQUFBLEdBQVN1QyxTQUFBLEdBQVl2QyxNQUFBLEdBQVN1QyxTQUFBO0lBQzVDO0VBQ0Y7RUFHQSxJQUFJQSxTQUFBLElBQWFBLFNBQUEsS0FBYyxHQUFHNUksTUFBQSxDQUFPVSxTQUFBLENBQVV0SCxLQUFBLENBQU1pTixNQUFBLEdBQVMsR0FBR3VDLFNBQUE7QUFDdkU7QUFFQSxTQUFTNEosbUJBQUEsRUFBcUI7RUFDNUIsTUFBTXhTLE1BQUEsR0FBUztFQUNmLE1BQU0rTixNQUFBLEdBQVMvTixNQUFBLENBQU8rTixNQUFBO0VBRXRCLE1BQU13RixXQUFBLEdBQWN2VCxNQUFBLENBQU93VCxTQUFBLEdBQVl4VCxNQUFBLENBQU82TSxZQUFBLENBQWEsSUFBSTdNLE1BQUEsQ0FBT1UsU0FBQSxDQUFVK1MsVUFBQSxHQUFhelQsTUFBQSxDQUFPVSxTQUFBLENBQVVnVCxTQUFBLEdBQVk7RUFDMUgsU0FBUzNVLENBQUEsR0FBSSxHQUFHQSxDQUFBLEdBQUlnUCxNQUFBLENBQU8zVixNQUFBLEVBQVEyRyxDQUFBLElBQUssR0FBRztJQUN6Q2dQLE1BQUEsQ0FBT2hQLENBQUEsRUFBRzRVLGlCQUFBLElBQXFCM1QsTUFBQSxDQUFPNk0sWUFBQSxDQUFhLElBQUlrQixNQUFBLENBQU9oUCxDQUFBLEVBQUcwVSxVQUFBLEdBQWExRixNQUFBLENBQU9oUCxDQUFBLEVBQUcyVSxTQUFBLElBQWFILFdBQUEsR0FBY3ZULE1BQUEsQ0FBTzRULHFCQUFBLENBQXNCO0VBQ2xKO0FBQ0Y7QUFFQSxJQUFNQyxvQkFBQSxHQUF1QkEsQ0FBQ2hTLE9BQUEsRUFBU2lTLFNBQUEsRUFBV0MsU0FBQSxLQUFjO0VBQzlELElBQUlELFNBQUEsSUFBYSxDQUFDalMsT0FBQSxDQUFRWSxTQUFBLENBQVVtUSxRQUFBLENBQVNtQixTQUFTLEdBQUc7SUFDdkRsUyxPQUFBLENBQVFZLFNBQUEsQ0FBVUMsR0FBQSxDQUFJcVIsU0FBUztFQUNqQyxXQUFXLENBQUNELFNBQUEsSUFBYWpTLE9BQUEsQ0FBUVksU0FBQSxDQUFVbVEsUUFBQSxDQUFTbUIsU0FBUyxHQUFHO0lBQzlEbFMsT0FBQSxDQUFRWSxTQUFBLENBQVVxUSxNQUFBLENBQU9pQixTQUFTO0VBQ3BDO0FBQ0Y7QUFDQSxTQUFTQyxxQkFBcUJDLFVBQUEsRUFBVztFQUN2QyxJQUFJQSxVQUFBLEtBQWMsUUFBUTtJQUN4QkEsVUFBQSxHQUFZLFFBQVEsS0FBSzdULFNBQUEsSUFBYTtFQUN4QztFQUNBLE1BQU1KLE1BQUEsR0FBUztFQUNmLE1BQU1RLE1BQUEsR0FBU1IsTUFBQSxDQUFPUSxNQUFBO0VBQ3RCLE1BQU07SUFDSnVOLE1BQUE7SUFDQVAsWUFBQSxFQUFjQyxHQUFBO0lBQ2RTO0VBQ0YsSUFBSWxPLE1BQUE7RUFDSixJQUFJK04sTUFBQSxDQUFPM1YsTUFBQSxLQUFXLEdBQUc7RUFDekIsSUFBSSxPQUFPMlYsTUFBQSxDQUFPLEdBQUc0RixpQkFBQSxLQUFzQixhQUFhM1QsTUFBQSxDQUFPd1Msa0JBQUEsQ0FBbUI7RUFDbEYsSUFBSTBCLFlBQUEsR0FBZSxDQUFDRCxVQUFBO0VBQ3BCLElBQUl4RyxHQUFBLEVBQUt5RyxZQUFBLEdBQWVELFVBQUE7RUFDeEJqVSxNQUFBLENBQU9tVSxvQkFBQSxHQUF1QixFQUFDO0VBQy9CblUsTUFBQSxDQUFPb1QsYUFBQSxHQUFnQixFQUFDO0VBQ3hCLElBQUl6RSxZQUFBLEdBQWVuTyxNQUFBLENBQU9tTyxZQUFBO0VBQzFCLElBQUksT0FBT0EsWUFBQSxLQUFpQixZQUFZQSxZQUFBLENBQWF6UCxPQUFBLENBQVEsR0FBRyxLQUFLLEdBQUc7SUFDdEV5UCxZQUFBLEdBQWUzUSxVQUFBLENBQVcyUSxZQUFBLENBQWFuUixPQUFBLENBQVEsS0FBSyxFQUFFLENBQUMsSUFBSSxNQUFNd0MsTUFBQSxDQUFPOEUsSUFBQTtFQUMxRSxXQUFXLE9BQU82SixZQUFBLEtBQWlCLFVBQVU7SUFDM0NBLFlBQUEsR0FBZTNRLFVBQUEsQ0FBVzJRLFlBQVk7RUFDeEM7RUFDQSxTQUFTNVAsQ0FBQSxHQUFJLEdBQUdBLENBQUEsR0FBSWdQLE1BQUEsQ0FBTzNWLE1BQUEsRUFBUTJHLENBQUEsSUFBSyxHQUFHO0lBQ3pDLE1BQU0rUSxNQUFBLEdBQVEvQixNQUFBLENBQU9oUCxDQUFBO0lBQ3JCLElBQUlxVixXQUFBLEdBQWN0RSxNQUFBLENBQU02RCxpQkFBQTtJQUN4QixJQUFJblQsTUFBQSxDQUFPNE8sT0FBQSxJQUFXNU8sTUFBQSxDQUFPMk8sY0FBQSxFQUFnQjtNQUMzQ2lGLFdBQUEsSUFBZXJHLE1BQUEsQ0FBTyxHQUFHNEYsaUJBQUE7SUFDM0I7SUFDQSxNQUFNVSxhQUFBLElBQWlCSCxZQUFBLElBQWdCMVQsTUFBQSxDQUFPMk8sY0FBQSxHQUFpQm5QLE1BQUEsQ0FBT3NVLFlBQUEsQ0FBYSxJQUFJLEtBQUtGLFdBQUEsS0FBZ0J0RSxNQUFBLENBQU1VLGVBQUEsR0FBa0I3QixZQUFBO0lBQ3BJLE1BQU00RixxQkFBQSxJQUF5QkwsWUFBQSxHQUFlaEcsUUFBQSxDQUFTLE1BQU0xTixNQUFBLENBQU8yTyxjQUFBLEdBQWlCblAsTUFBQSxDQUFPc1UsWUFBQSxDQUFhLElBQUksS0FBS0YsV0FBQSxLQUFnQnRFLE1BQUEsQ0FBTVUsZUFBQSxHQUFrQjdCLFlBQUE7SUFDMUosTUFBTTZGLFdBQUEsR0FBYyxFQUFFTixZQUFBLEdBQWVFLFdBQUE7SUFDckMsTUFBTUssVUFBQSxHQUFhRCxXQUFBLEdBQWN4VSxNQUFBLENBQU9vTyxlQUFBLENBQWdCclAsQ0FBQTtJQUN4RCxNQUFNMlYsY0FBQSxHQUFpQkYsV0FBQSxJQUFlLEtBQUtBLFdBQUEsSUFBZXhVLE1BQUEsQ0FBTzhFLElBQUEsR0FBTzlFLE1BQUEsQ0FBT29PLGVBQUEsQ0FBZ0JyUCxDQUFBO0lBQy9GLE1BQU00VixTQUFBLEdBQVlILFdBQUEsSUFBZSxLQUFLQSxXQUFBLEdBQWN4VSxNQUFBLENBQU84RSxJQUFBLEdBQU8sS0FBSzJQLFVBQUEsR0FBYSxLQUFLQSxVQUFBLElBQWN6VSxNQUFBLENBQU84RSxJQUFBLElBQVEwUCxXQUFBLElBQWUsS0FBS0MsVUFBQSxJQUFjelUsTUFBQSxDQUFPOEUsSUFBQTtJQUMvSixJQUFJNlAsU0FBQSxFQUFXO01BQ2IzVSxNQUFBLENBQU9vVCxhQUFBLENBQWN2UCxJQUFBLENBQUtpTSxNQUFLO01BQy9COVAsTUFBQSxDQUFPbVUsb0JBQUEsQ0FBcUJ0USxJQUFBLENBQUs5RSxDQUFDO0lBQ3BDO0lBQ0E4VSxvQkFBQSxDQUFxQi9ELE1BQUEsRUFBTzZFLFNBQUEsRUFBV25VLE1BQUEsQ0FBT29VLGlCQUFpQjtJQUMvRGYsb0JBQUEsQ0FBcUIvRCxNQUFBLEVBQU80RSxjQUFBLEVBQWdCbFUsTUFBQSxDQUFPcVUsc0JBQXNCO0lBQ3pFL0UsTUFBQSxDQUFNNU8sUUFBQSxHQUFXdU0sR0FBQSxHQUFNLENBQUM0RyxhQUFBLEdBQWdCQSxhQUFBO0lBQ3hDdkUsTUFBQSxDQUFNZ0YsZ0JBQUEsR0FBbUJySCxHQUFBLEdBQU0sQ0FBQzhHLHFCQUFBLEdBQXdCQSxxQkFBQTtFQUMxRDtBQUNGO0FBRUEsU0FBU1EsZUFBZWQsVUFBQSxFQUFXO0VBQ2pDLE1BQU1qVSxNQUFBLEdBQVM7RUFDZixJQUFJLE9BQU9pVSxVQUFBLEtBQWMsYUFBYTtJQUNwQyxNQUFNZSxVQUFBLEdBQWFoVixNQUFBLENBQU93TixZQUFBLEdBQWUsS0FBSztJQUU5Q3lHLFVBQUEsR0FBWWpVLE1BQUEsSUFBVUEsTUFBQSxDQUFPSSxTQUFBLElBQWFKLE1BQUEsQ0FBT0ksU0FBQSxHQUFZNFUsVUFBQSxJQUFjO0VBQzdFO0VBQ0EsTUFBTXhVLE1BQUEsR0FBU1IsTUFBQSxDQUFPUSxNQUFBO0VBQ3RCLE1BQU15VSxjQUFBLEdBQWlCalYsTUFBQSxDQUFPa1YsWUFBQSxDQUFhLElBQUlsVixNQUFBLENBQU9zVSxZQUFBLENBQWE7RUFDbkUsSUFBSTtJQUNGcFQsUUFBQTtJQUNBaVUsV0FBQTtJQUNBQyxLQUFBO0lBQ0FDO0VBQ0YsSUFBSXJWLE1BQUE7RUFDSixNQUFNc1YsWUFBQSxHQUFlSCxXQUFBO0VBQ3JCLE1BQU1JLE1BQUEsR0FBU0gsS0FBQTtFQUNmLElBQUlILGNBQUEsS0FBbUIsR0FBRztJQUN4Qi9ULFFBQUEsR0FBVztJQUNYaVUsV0FBQSxHQUFjO0lBQ2RDLEtBQUEsR0FBUTtFQUNWLE9BQU87SUFDTGxVLFFBQUEsSUFBWStTLFVBQUEsR0FBWWpVLE1BQUEsQ0FBT3NVLFlBQUEsQ0FBYSxLQUFLVyxjQUFBO0lBQ2pELE1BQU1PLGtCQUFBLEdBQXFCclUsSUFBQSxDQUFLc1AsR0FBQSxDQUFJd0QsVUFBQSxHQUFZalUsTUFBQSxDQUFPc1UsWUFBQSxDQUFhLENBQUMsSUFBSTtJQUN6RSxNQUFNbUIsWUFBQSxHQUFldFUsSUFBQSxDQUFLc1AsR0FBQSxDQUFJd0QsVUFBQSxHQUFZalUsTUFBQSxDQUFPa1YsWUFBQSxDQUFhLENBQUMsSUFBSTtJQUNuRUMsV0FBQSxHQUFjSyxrQkFBQSxJQUFzQnRVLFFBQUEsSUFBWTtJQUNoRGtVLEtBQUEsR0FBUUssWUFBQSxJQUFnQnZVLFFBQUEsSUFBWTtJQUNwQyxJQUFJc1Usa0JBQUEsRUFBb0J0VSxRQUFBLEdBQVc7SUFDbkMsSUFBSXVVLFlBQUEsRUFBY3ZVLFFBQUEsR0FBVztFQUMvQjtFQUNBLElBQUlWLE1BQUEsQ0FBT3lRLElBQUEsRUFBTTtJQUNmLE1BQU15RSxlQUFBLEdBQWtCMVYsTUFBQSxDQUFPbVQsbUJBQUEsQ0FBb0IsQ0FBQztJQUNwRCxNQUFNd0MsY0FBQSxHQUFpQjNWLE1BQUEsQ0FBT21ULG1CQUFBLENBQW9CblQsTUFBQSxDQUFPK04sTUFBQSxDQUFPM1YsTUFBQSxHQUFTLENBQUM7SUFDMUUsTUFBTXdkLG1CQUFBLEdBQXNCNVYsTUFBQSxDQUFPbU8sVUFBQSxDQUFXdUgsZUFBQTtJQUM5QyxNQUFNRyxrQkFBQSxHQUFxQjdWLE1BQUEsQ0FBT21PLFVBQUEsQ0FBV3dILGNBQUE7SUFDN0MsTUFBTUcsWUFBQSxHQUFlOVYsTUFBQSxDQUFPbU8sVUFBQSxDQUFXbk8sTUFBQSxDQUFPbU8sVUFBQSxDQUFXL1YsTUFBQSxHQUFTO0lBQ2xFLE1BQU0yZCxZQUFBLEdBQWU1VSxJQUFBLENBQUtzUCxHQUFBLENBQUl3RCxVQUFTO0lBQ3ZDLElBQUk4QixZQUFBLElBQWdCSCxtQkFBQSxFQUFxQjtNQUN2Q1AsWUFBQSxJQUFnQlUsWUFBQSxHQUFlSCxtQkFBQSxJQUF1QkUsWUFBQTtJQUN4RCxPQUFPO01BQ0xULFlBQUEsSUFBZ0JVLFlBQUEsR0FBZUQsWUFBQSxHQUFlRCxrQkFBQSxJQUFzQkMsWUFBQTtJQUN0RTtJQUNBLElBQUlULFlBQUEsR0FBZSxHQUFHQSxZQUFBLElBQWdCO0VBQ3hDO0VBQ0F4ZCxNQUFBLENBQU9vVixNQUFBLENBQU9qTixNQUFBLEVBQVE7SUFDcEJrQixRQUFBO0lBQ0FtVSxZQUFBO0lBQ0FGLFdBQUE7SUFDQUM7RUFDRixDQUFDO0VBQ0QsSUFBSTVVLE1BQUEsQ0FBTytSLG1CQUFBLElBQXVCL1IsTUFBQSxDQUFPMk8sY0FBQSxJQUFrQjNPLE1BQUEsQ0FBT3dWLFVBQUEsRUFBWWhXLE1BQUEsQ0FBT2dVLG9CQUFBLENBQXFCQyxVQUFTO0VBQ25ILElBQUlrQixXQUFBLElBQWUsQ0FBQ0csWUFBQSxFQUFjO0lBQ2hDdFYsTUFBQSxDQUFPa0ksSUFBQSxDQUFLLHVCQUF1QjtFQUNyQztFQUNBLElBQUlrTixLQUFBLElBQVMsQ0FBQ0csTUFBQSxFQUFRO0lBQ3BCdlYsTUFBQSxDQUFPa0ksSUFBQSxDQUFLLGlCQUFpQjtFQUMvQjtFQUNBLElBQUlvTixZQUFBLElBQWdCLENBQUNILFdBQUEsSUFBZUksTUFBQSxJQUFVLENBQUNILEtBQUEsRUFBTztJQUNwRHBWLE1BQUEsQ0FBT2tJLElBQUEsQ0FBSyxVQUFVO0VBQ3hCO0VBQ0FsSSxNQUFBLENBQU9rSSxJQUFBLENBQUssWUFBWWhILFFBQVE7QUFDbEM7QUFFQSxJQUFNK1Usa0JBQUEsR0FBcUJBLENBQUNwVSxPQUFBLEVBQVNpUyxTQUFBLEVBQVdDLFNBQUEsS0FBYztFQUM1RCxJQUFJRCxTQUFBLElBQWEsQ0FBQ2pTLE9BQUEsQ0FBUVksU0FBQSxDQUFVbVEsUUFBQSxDQUFTbUIsU0FBUyxHQUFHO0lBQ3ZEbFMsT0FBQSxDQUFRWSxTQUFBLENBQVVDLEdBQUEsQ0FBSXFSLFNBQVM7RUFDakMsV0FBVyxDQUFDRCxTQUFBLElBQWFqUyxPQUFBLENBQVFZLFNBQUEsQ0FBVW1RLFFBQUEsQ0FBU21CLFNBQVMsR0FBRztJQUM5RGxTLE9BQUEsQ0FBUVksU0FBQSxDQUFVcVEsTUFBQSxDQUFPaUIsU0FBUztFQUNwQztBQUNGO0FBQ0EsU0FBU21DLG9CQUFBLEVBQXNCO0VBQzdCLE1BQU1sVyxNQUFBLEdBQVM7RUFDZixNQUFNO0lBQ0orTixNQUFBO0lBQ0F2TixNQUFBO0lBQ0E4TSxRQUFBO0lBQ0ErRjtFQUNGLElBQUlyVCxNQUFBO0VBQ0osTUFBTTJOLFNBQUEsR0FBWTNOLE1BQUEsQ0FBTzROLE9BQUEsSUFBV3BOLE1BQUEsQ0FBT29OLE9BQUEsQ0FBUUMsT0FBQTtFQUNuRCxNQUFNd0IsV0FBQSxHQUFjclAsTUFBQSxDQUFPc1AsSUFBQSxJQUFROU8sTUFBQSxDQUFPOE8sSUFBQSxJQUFROU8sTUFBQSxDQUFPOE8sSUFBQSxDQUFLQyxJQUFBLEdBQU87RUFDckUsTUFBTTRHLGdCQUFBLEdBQW1CbFUsUUFBQSxJQUFZO0lBQ25DLE9BQU9GLGVBQUEsQ0FBZ0J1TCxRQUFBLEVBQVUsSUFBSTlNLE1BQUEsQ0FBT3dOLFVBQUEsR0FBYS9MLFFBQUEsaUJBQXlCQSxRQUFBLEVBQVUsRUFBRTtFQUNoRztFQUNBLElBQUltVSxXQUFBO0VBQ0osSUFBSUMsU0FBQTtFQUNKLElBQUlDLFNBQUE7RUFDSixJQUFJM0ksU0FBQSxFQUFXO0lBQ2IsSUFBSW5OLE1BQUEsQ0FBT3lRLElBQUEsRUFBTTtNQUNmLElBQUlPLFVBQUEsR0FBYTZCLFdBQUEsR0FBY3JULE1BQUEsQ0FBTzROLE9BQUEsQ0FBUXdELFlBQUE7TUFDOUMsSUFBSUksVUFBQSxHQUFhLEdBQUdBLFVBQUEsR0FBYXhSLE1BQUEsQ0FBTzROLE9BQUEsQ0FBUUcsTUFBQSxDQUFPM1YsTUFBQSxHQUFTb1osVUFBQTtNQUNoRSxJQUFJQSxVQUFBLElBQWN4UixNQUFBLENBQU80TixPQUFBLENBQVFHLE1BQUEsQ0FBTzNWLE1BQUEsRUFBUW9aLFVBQUEsSUFBY3hSLE1BQUEsQ0FBTzROLE9BQUEsQ0FBUUcsTUFBQSxDQUFPM1YsTUFBQTtNQUNwRmdlLFdBQUEsR0FBY0QsZ0JBQUEsQ0FBaUIsNkJBQTZCM0UsVUFBQSxJQUFjO0lBQzVFLE9BQU87TUFDTDRFLFdBQUEsR0FBY0QsZ0JBQUEsQ0FBaUIsNkJBQTZCOUMsV0FBQSxJQUFlO0lBQzdFO0VBQ0YsT0FBTztJQUNMLElBQUloRSxXQUFBLEVBQWE7TUFDZitHLFdBQUEsR0FBY3JJLE1BQUEsQ0FBTzlSLE1BQUEsQ0FBTzRGLE9BQUEsSUFBV0EsT0FBQSxDQUFRMFUsTUFBQSxLQUFXbEQsV0FBVyxFQUFFO01BQ3ZFaUQsU0FBQSxHQUFZdkksTUFBQSxDQUFPOVIsTUFBQSxDQUFPNEYsT0FBQSxJQUFXQSxPQUFBLENBQVEwVSxNQUFBLEtBQVdsRCxXQUFBLEdBQWMsQ0FBQyxFQUFFO01BQ3pFZ0QsU0FBQSxHQUFZdEksTUFBQSxDQUFPOVIsTUFBQSxDQUFPNEYsT0FBQSxJQUFXQSxPQUFBLENBQVEwVSxNQUFBLEtBQVdsRCxXQUFBLEdBQWMsQ0FBQyxFQUFFO0lBQzNFLE9BQU87TUFDTCtDLFdBQUEsR0FBY3JJLE1BQUEsQ0FBT3NGLFdBQUE7SUFDdkI7RUFDRjtFQUNBLElBQUkrQyxXQUFBLEVBQWE7SUFDZixJQUFJLENBQUMvRyxXQUFBLEVBQWE7TUFFaEJpSCxTQUFBLEdBQVl4UyxjQUFBLENBQWVzUyxXQUFBLEVBQWEsSUFBSTVWLE1BQUEsQ0FBT3dOLFVBQUEsZ0JBQTBCLEVBQUU7TUFDL0UsSUFBSXhOLE1BQUEsQ0FBT3lRLElBQUEsSUFBUSxDQUFDcUYsU0FBQSxFQUFXO1FBQzdCQSxTQUFBLEdBQVl2SSxNQUFBLENBQU87TUFDckI7TUFHQXNJLFNBQUEsR0FBWTVTLGNBQUEsQ0FBZTJTLFdBQUEsRUFBYSxJQUFJNVYsTUFBQSxDQUFPd04sVUFBQSxnQkFBMEIsRUFBRTtNQUMvRSxJQUFJeE4sTUFBQSxDQUFPeVEsSUFBQSxJQUFRLENBQUNvRixTQUFBLEtBQWMsR0FBRztRQUNuQ0EsU0FBQSxHQUFZdEksTUFBQSxDQUFPQSxNQUFBLENBQU8zVixNQUFBLEdBQVM7TUFDckM7SUFDRjtFQUNGO0VBQ0EyVixNQUFBLENBQU83VixPQUFBLENBQVEySixPQUFBLElBQVc7SUFDeEJvVSxrQkFBQSxDQUFtQnBVLE9BQUEsRUFBU0EsT0FBQSxLQUFZdVUsV0FBQSxFQUFhNVYsTUFBQSxDQUFPZ1csZ0JBQWdCO0lBQzVFUCxrQkFBQSxDQUFtQnBVLE9BQUEsRUFBU0EsT0FBQSxLQUFZeVUsU0FBQSxFQUFXOVYsTUFBQSxDQUFPaVcsY0FBYztJQUN4RVIsa0JBQUEsQ0FBbUJwVSxPQUFBLEVBQVNBLE9BQUEsS0FBWXdVLFNBQUEsRUFBVzdWLE1BQUEsQ0FBT2tXLGNBQWM7RUFDMUUsQ0FBQztFQUNEMVcsTUFBQSxDQUFPMlcsaUJBQUEsQ0FBa0I7QUFDM0I7QUFFQSxJQUFNQyxvQkFBQSxHQUF1QkEsQ0FBQzVXLE1BQUEsRUFBUTZXLE9BQUEsS0FBWTtFQUNoRCxJQUFJLENBQUM3VyxNQUFBLElBQVVBLE1BQUEsQ0FBT3NJLFNBQUEsSUFBYSxDQUFDdEksTUFBQSxDQUFPUSxNQUFBLEVBQVE7RUFDbkQsTUFBTXNXLGFBQUEsR0FBZ0JBLENBQUEsS0FBTTlXLE1BQUEsQ0FBT3dULFNBQUEsR0FBWSxpQkFBaUIsSUFBSXhULE1BQUEsQ0FBT1EsTUFBQSxDQUFPd04sVUFBQTtFQUNsRixNQUFNbk0sT0FBQSxHQUFVZ1YsT0FBQSxDQUFRRSxPQUFBLENBQVFELGFBQUEsQ0FBYyxDQUFDO0VBQy9DLElBQUlqVixPQUFBLEVBQVM7SUFDWCxJQUFJbVYsTUFBQSxHQUFTblYsT0FBQSxDQUFRakosYUFBQSxDQUFjLElBQUlvSCxNQUFBLENBQU9RLE1BQUEsQ0FBT3lXLGtCQUFBLEVBQW9CO0lBQ3pFLElBQUksQ0FBQ0QsTUFBQSxJQUFVaFgsTUFBQSxDQUFPd1QsU0FBQSxFQUFXO01BQy9CLElBQUkzUixPQUFBLENBQVFDLFVBQUEsRUFBWTtRQUN0QmtWLE1BQUEsR0FBU25WLE9BQUEsQ0FBUUMsVUFBQSxDQUFXbEosYUFBQSxDQUFjLElBQUlvSCxNQUFBLENBQU9RLE1BQUEsQ0FBT3lXLGtCQUFBLEVBQW9CO01BQ2xGLE9BQU87UUFFTDNiLHFCQUFBLENBQXNCLE1BQU07VUFDMUIsSUFBSXVHLE9BQUEsQ0FBUUMsVUFBQSxFQUFZO1lBQ3RCa1YsTUFBQSxHQUFTblYsT0FBQSxDQUFRQyxVQUFBLENBQVdsSixhQUFBLENBQWMsSUFBSW9ILE1BQUEsQ0FBT1EsTUFBQSxDQUFPeVcsa0JBQUEsRUFBb0I7WUFDaEYsSUFBSUQsTUFBQSxFQUFRQSxNQUFBLENBQU9sRSxNQUFBLENBQU87VUFDNUI7UUFDRixDQUFDO01BQ0g7SUFDRjtJQUNBLElBQUlrRSxNQUFBLEVBQVFBLE1BQUEsQ0FBT2xFLE1BQUEsQ0FBTztFQUM1QjtBQUNGO0FBQ0EsSUFBTW9FLE1BQUEsR0FBU0EsQ0FBQ2xYLE1BQUEsRUFBUWlNLEtBQUEsS0FBVTtFQUNoQyxJQUFJLENBQUNqTSxNQUFBLENBQU8rTixNQUFBLENBQU85QixLQUFBLEdBQVE7RUFDM0IsTUFBTTRLLE9BQUEsR0FBVTdXLE1BQUEsQ0FBTytOLE1BQUEsQ0FBTzlCLEtBQUEsRUFBT3JULGFBQUEsQ0FBYyxrQkFBa0I7RUFDckUsSUFBSWllLE9BQUEsRUFBU0EsT0FBQSxDQUFRTSxlQUFBLENBQWdCLFNBQVM7QUFDaEQ7QUFDQSxJQUFNQyxPQUFBLEdBQVVwWCxNQUFBLElBQVU7RUFDeEIsSUFBSSxDQUFDQSxNQUFBLElBQVVBLE1BQUEsQ0FBT3NJLFNBQUEsSUFBYSxDQUFDdEksTUFBQSxDQUFPUSxNQUFBLEVBQVE7RUFDbkQsSUFBSTZXLE1BQUEsR0FBU3JYLE1BQUEsQ0FBT1EsTUFBQSxDQUFPOFcsbUJBQUE7RUFDM0IsTUFBTWxZLEdBQUEsR0FBTVksTUFBQSxDQUFPK04sTUFBQSxDQUFPM1YsTUFBQTtFQUMxQixJQUFJLENBQUNnSCxHQUFBLElBQU8sQ0FBQ2lZLE1BQUEsSUFBVUEsTUFBQSxHQUFTLEdBQUc7RUFDbkNBLE1BQUEsR0FBU2xXLElBQUEsQ0FBS0UsR0FBQSxDQUFJZ1csTUFBQSxFQUFRalksR0FBRztFQUM3QixNQUFNd1EsYUFBQSxHQUFnQjVQLE1BQUEsQ0FBT1EsTUFBQSxDQUFPb1AsYUFBQSxLQUFrQixTQUFTNVAsTUFBQSxDQUFPdVgsb0JBQUEsQ0FBcUIsSUFBSXBXLElBQUEsQ0FBS2dRLElBQUEsQ0FBS25SLE1BQUEsQ0FBT1EsTUFBQSxDQUFPb1AsYUFBYTtFQUNwSSxNQUFNeUQsV0FBQSxHQUFjclQsTUFBQSxDQUFPcVQsV0FBQTtFQUMzQixJQUFJclQsTUFBQSxDQUFPUSxNQUFBLENBQU84TyxJQUFBLElBQVF0UCxNQUFBLENBQU9RLE1BQUEsQ0FBTzhPLElBQUEsQ0FBS0MsSUFBQSxHQUFPLEdBQUc7SUFDckQsTUFBTWlJLFlBQUEsR0FBZW5FLFdBQUE7SUFDckIsTUFBTW9FLGNBQUEsR0FBaUIsQ0FBQ0QsWUFBQSxHQUFlSCxNQUFNO0lBQzdDSSxjQUFBLENBQWU1VCxJQUFBLENBQUssR0FBR2xCLEtBQUEsQ0FBTStVLElBQUEsQ0FBSztNQUNoQ3RmLE1BQUEsRUFBUWlmO0lBQ1YsQ0FBQyxFQUFFL1osR0FBQSxDQUFJLENBQUNpVSxDQUFBLEVBQUd4UyxDQUFBLEtBQU07TUFDZixPQUFPeVksWUFBQSxHQUFlNUgsYUFBQSxHQUFnQjdRLENBQUE7SUFDeEMsQ0FBQyxDQUFDO0lBQ0ZpQixNQUFBLENBQU8rTixNQUFBLENBQU83VixPQUFBLENBQVEsQ0FBQzJKLE9BQUEsRUFBUzlDLENBQUEsS0FBTTtNQUNwQyxJQUFJMFksY0FBQSxDQUFlblEsUUFBQSxDQUFTekYsT0FBQSxDQUFRMFUsTUFBTSxHQUFHVyxNQUFBLENBQU9sWCxNQUFBLEVBQVFqQixDQUFDO0lBQy9ELENBQUM7SUFDRDtFQUNGO0VBQ0EsTUFBTTRZLG9CQUFBLEdBQXVCdEUsV0FBQSxHQUFjekQsYUFBQSxHQUFnQjtFQUMzRCxJQUFJNVAsTUFBQSxDQUFPUSxNQUFBLENBQU9vWCxNQUFBLElBQVU1WCxNQUFBLENBQU9RLE1BQUEsQ0FBT3lRLElBQUEsRUFBTTtJQUM5QyxTQUFTbFMsQ0FBQSxHQUFJc1UsV0FBQSxHQUFjZ0UsTUFBQSxFQUFRdFksQ0FBQSxJQUFLNFksb0JBQUEsR0FBdUJOLE1BQUEsRUFBUXRZLENBQUEsSUFBSyxHQUFHO01BQzdFLE1BQU04WSxTQUFBLElBQWE5WSxDQUFBLEdBQUlLLEdBQUEsR0FBTUEsR0FBQSxJQUFPQSxHQUFBO01BQ3BDLElBQUl5WSxTQUFBLEdBQVl4RSxXQUFBLElBQWV3RSxTQUFBLEdBQVlGLG9CQUFBLEVBQXNCVCxNQUFBLENBQU9sWCxNQUFBLEVBQVE2WCxTQUFTO0lBQzNGO0VBQ0YsT0FBTztJQUNMLFNBQVM5WSxDQUFBLEdBQUlvQyxJQUFBLENBQUtDLEdBQUEsQ0FBSWlTLFdBQUEsR0FBY2dFLE1BQUEsRUFBUSxDQUFDLEdBQUd0WSxDQUFBLElBQUtvQyxJQUFBLENBQUtFLEdBQUEsQ0FBSXNXLG9CQUFBLEdBQXVCTixNQUFBLEVBQVFqWSxHQUFBLEdBQU0sQ0FBQyxHQUFHTCxDQUFBLElBQUssR0FBRztNQUM3RyxJQUFJQSxDQUFBLEtBQU1zVSxXQUFBLEtBQWdCdFUsQ0FBQSxHQUFJNFksb0JBQUEsSUFBd0I1WSxDQUFBLEdBQUlzVSxXQUFBLEdBQWM7UUFDdEU2RCxNQUFBLENBQU9sWCxNQUFBLEVBQVFqQixDQUFDO01BQ2xCO0lBQ0Y7RUFDRjtBQUNGO0FBRUEsU0FBUytZLDBCQUEwQjlYLE1BQUEsRUFBUTtFQUN6QyxNQUFNO0lBQ0ptTyxVQUFBO0lBQ0EzTjtFQUNGLElBQUlSLE1BQUE7RUFDSixNQUFNaVUsVUFBQSxHQUFZalUsTUFBQSxDQUFPd04sWUFBQSxHQUFleE4sTUFBQSxDQUFPSSxTQUFBLEdBQVksQ0FBQ0osTUFBQSxDQUFPSSxTQUFBO0VBQ25FLElBQUlpVCxXQUFBO0VBQ0osU0FBU3RVLENBQUEsR0FBSSxHQUFHQSxDQUFBLEdBQUlvUCxVQUFBLENBQVcvVixNQUFBLEVBQVEyRyxDQUFBLElBQUssR0FBRztJQUM3QyxJQUFJLE9BQU9vUCxVQUFBLENBQVdwUCxDQUFBLEdBQUksT0FBTyxhQUFhO01BQzVDLElBQUlrVixVQUFBLElBQWE5RixVQUFBLENBQVdwUCxDQUFBLEtBQU1rVixVQUFBLEdBQVk5RixVQUFBLENBQVdwUCxDQUFBLEdBQUksTUFBTW9QLFVBQUEsQ0FBV3BQLENBQUEsR0FBSSxLQUFLb1AsVUFBQSxDQUFXcFAsQ0FBQSxLQUFNLEdBQUc7UUFDekdzVSxXQUFBLEdBQWN0VSxDQUFBO01BQ2hCLFdBQVdrVixVQUFBLElBQWE5RixVQUFBLENBQVdwUCxDQUFBLEtBQU1rVixVQUFBLEdBQVk5RixVQUFBLENBQVdwUCxDQUFBLEdBQUksSUFBSTtRQUN0RXNVLFdBQUEsR0FBY3RVLENBQUEsR0FBSTtNQUNwQjtJQUNGLFdBQVdrVixVQUFBLElBQWE5RixVQUFBLENBQVdwUCxDQUFBLEdBQUk7TUFDckNzVSxXQUFBLEdBQWN0VSxDQUFBO0lBQ2hCO0VBQ0Y7RUFFQSxJQUFJeUIsTUFBQSxDQUFPdVgsbUJBQUEsRUFBcUI7SUFDOUIsSUFBSTFFLFdBQUEsR0FBYyxLQUFLLE9BQU9BLFdBQUEsS0FBZ0IsYUFBYUEsV0FBQSxHQUFjO0VBQzNFO0VBQ0EsT0FBT0EsV0FBQTtBQUNUO0FBQ0EsU0FBUzJFLGtCQUFrQkMsY0FBQSxFQUFnQjtFQUN6QyxNQUFNalksTUFBQSxHQUFTO0VBQ2YsTUFBTWlVLFVBQUEsR0FBWWpVLE1BQUEsQ0FBT3dOLFlBQUEsR0FBZXhOLE1BQUEsQ0FBT0ksU0FBQSxHQUFZLENBQUNKLE1BQUEsQ0FBT0ksU0FBQTtFQUNuRSxNQUFNO0lBQ0o4TixRQUFBO0lBQ0ExTixNQUFBO0lBQ0E2UyxXQUFBLEVBQWE2RSxhQUFBO0lBQ2JMLFNBQUEsRUFBV00saUJBQUE7SUFDWGxHLFNBQUEsRUFBV21HO0VBQ2IsSUFBSXBZLE1BQUE7RUFDSixJQUFJcVQsV0FBQSxHQUFjNEUsY0FBQTtFQUNsQixJQUFJaEcsU0FBQTtFQUNKLE1BQU1vRyxtQkFBQSxHQUFzQkMsTUFBQSxJQUFVO0lBQ3BDLElBQUlDLFVBQUEsR0FBWUQsTUFBQSxHQUFTdFksTUFBQSxDQUFPNE4sT0FBQSxDQUFRd0QsWUFBQTtJQUN4QyxJQUFJbUgsVUFBQSxHQUFZLEdBQUc7TUFDakJBLFVBQUEsR0FBWXZZLE1BQUEsQ0FBTzROLE9BQUEsQ0FBUUcsTUFBQSxDQUFPM1YsTUFBQSxHQUFTbWdCLFVBQUE7SUFDN0M7SUFDQSxJQUFJQSxVQUFBLElBQWF2WSxNQUFBLENBQU80TixPQUFBLENBQVFHLE1BQUEsQ0FBTzNWLE1BQUEsRUFBUTtNQUM3Q21nQixVQUFBLElBQWF2WSxNQUFBLENBQU80TixPQUFBLENBQVFHLE1BQUEsQ0FBTzNWLE1BQUE7SUFDckM7SUFDQSxPQUFPbWdCLFVBQUE7RUFDVDtFQUNBLElBQUksT0FBT2xGLFdBQUEsS0FBZ0IsYUFBYTtJQUN0Q0EsV0FBQSxHQUFjeUUseUJBQUEsQ0FBMEI5WCxNQUFNO0VBQ2hEO0VBQ0EsSUFBSWtPLFFBQUEsQ0FBU2hQLE9BQUEsQ0FBUStVLFVBQVMsS0FBSyxHQUFHO0lBQ3BDaEMsU0FBQSxHQUFZL0QsUUFBQSxDQUFTaFAsT0FBQSxDQUFRK1UsVUFBUztFQUN4QyxPQUFPO0lBQ0wsTUFBTXVFLElBQUEsR0FBT3JYLElBQUEsQ0FBS0UsR0FBQSxDQUFJYixNQUFBLENBQU9tUSxrQkFBQSxFQUFvQjBDLFdBQVc7SUFDNURwQixTQUFBLEdBQVl1RyxJQUFBLEdBQU9yWCxJQUFBLENBQUtvUCxLQUFBLEVBQU84QyxXQUFBLEdBQWNtRixJQUFBLElBQVFoWSxNQUFBLENBQU9rUSxjQUFjO0VBQzVFO0VBQ0EsSUFBSXVCLFNBQUEsSUFBYS9ELFFBQUEsQ0FBUzlWLE1BQUEsRUFBUTZaLFNBQUEsR0FBWS9ELFFBQUEsQ0FBUzlWLE1BQUEsR0FBUztFQUNoRSxJQUFJaWIsV0FBQSxLQUFnQjZFLGFBQUEsSUFBaUIsQ0FBQ2xZLE1BQUEsQ0FBT1EsTUFBQSxDQUFPeVEsSUFBQSxFQUFNO0lBQ3hELElBQUlnQixTQUFBLEtBQWNtRyxpQkFBQSxFQUFtQjtNQUNuQ3BZLE1BQUEsQ0FBT2lTLFNBQUEsR0FBWUEsU0FBQTtNQUNuQmpTLE1BQUEsQ0FBT2tJLElBQUEsQ0FBSyxpQkFBaUI7SUFDL0I7SUFDQTtFQUNGO0VBQ0EsSUFBSW1MLFdBQUEsS0FBZ0I2RSxhQUFBLElBQWlCbFksTUFBQSxDQUFPUSxNQUFBLENBQU95USxJQUFBLElBQVFqUixNQUFBLENBQU80TixPQUFBLElBQVc1TixNQUFBLENBQU9RLE1BQUEsQ0FBT29OLE9BQUEsQ0FBUUMsT0FBQSxFQUFTO0lBQzFHN04sTUFBQSxDQUFPNlgsU0FBQSxHQUFZUSxtQkFBQSxDQUFvQmhGLFdBQVc7SUFDbEQ7RUFDRjtFQUNBLE1BQU1oRSxXQUFBLEdBQWNyUCxNQUFBLENBQU9zUCxJQUFBLElBQVE5TyxNQUFBLENBQU84TyxJQUFBLElBQVE5TyxNQUFBLENBQU84TyxJQUFBLENBQUtDLElBQUEsR0FBTztFQUdyRSxJQUFJc0ksU0FBQTtFQUNKLElBQUk3WCxNQUFBLENBQU80TixPQUFBLElBQVdwTixNQUFBLENBQU9vTixPQUFBLENBQVFDLE9BQUEsSUFBV3JOLE1BQUEsQ0FBT3lRLElBQUEsRUFBTTtJQUMzRDRHLFNBQUEsR0FBWVEsbUJBQUEsQ0FBb0JoRixXQUFXO0VBQzdDLFdBQVdoRSxXQUFBLEVBQWE7SUFDdEIsTUFBTW9KLGtCQUFBLEdBQXFCelksTUFBQSxDQUFPK04sTUFBQSxDQUFPOVIsTUFBQSxDQUFPNEYsT0FBQSxJQUFXQSxPQUFBLENBQVEwVSxNQUFBLEtBQVdsRCxXQUFXLEVBQUU7SUFDM0YsSUFBSXFGLGdCQUFBLEdBQW1CM0wsUUFBQSxDQUFTMEwsa0JBQUEsQ0FBbUJFLFlBQUEsQ0FBYSx5QkFBeUIsR0FBRyxFQUFFO0lBQzlGLElBQUlqUixNQUFBLENBQU9zRixLQUFBLENBQU0wTCxnQkFBZ0IsR0FBRztNQUNsQ0EsZ0JBQUEsR0FBbUJ2WCxJQUFBLENBQUtDLEdBQUEsQ0FBSXBCLE1BQUEsQ0FBTytOLE1BQUEsQ0FBTzdPLE9BQUEsQ0FBUXVaLGtCQUFrQixHQUFHLENBQUM7SUFDMUU7SUFDQVosU0FBQSxHQUFZMVcsSUFBQSxDQUFLb1AsS0FBQSxDQUFNbUksZ0JBQUEsR0FBbUJsWSxNQUFBLENBQU84TyxJQUFBLENBQUtDLElBQUk7RUFDNUQsV0FBV3ZQLE1BQUEsQ0FBTytOLE1BQUEsQ0FBT3NGLFdBQUEsR0FBYztJQUNyQyxNQUFNN0IsVUFBQSxHQUFheFIsTUFBQSxDQUFPK04sTUFBQSxDQUFPc0YsV0FBQSxFQUFhc0YsWUFBQSxDQUFhLHlCQUF5QjtJQUNwRixJQUFJbkgsVUFBQSxFQUFZO01BQ2RxRyxTQUFBLEdBQVk5SyxRQUFBLENBQVN5RSxVQUFBLEVBQVksRUFBRTtJQUNyQyxPQUFPO01BQ0xxRyxTQUFBLEdBQVl4RSxXQUFBO0lBQ2Q7RUFDRixPQUFPO0lBQ0x3RSxTQUFBLEdBQVl4RSxXQUFBO0VBQ2Q7RUFDQXhiLE1BQUEsQ0FBT29WLE1BQUEsQ0FBT2pOLE1BQUEsRUFBUTtJQUNwQm9ZLGlCQUFBO0lBQ0FuRyxTQUFBO0lBQ0FrRyxpQkFBQTtJQUNBTixTQUFBO0lBQ0FLLGFBQUE7SUFDQTdFO0VBQ0YsQ0FBQztFQUNELElBQUlyVCxNQUFBLENBQU91SSxXQUFBLEVBQWE7SUFDdEI2TyxPQUFBLENBQVFwWCxNQUFNO0VBQ2hCO0VBQ0FBLE1BQUEsQ0FBT2tJLElBQUEsQ0FBSyxtQkFBbUI7RUFDL0JsSSxNQUFBLENBQU9rSSxJQUFBLENBQUssaUJBQWlCO0VBQzdCLElBQUlsSSxNQUFBLENBQU91SSxXQUFBLElBQWV2SSxNQUFBLENBQU9RLE1BQUEsQ0FBT29ZLGtCQUFBLEVBQW9CO0lBQzFELElBQUlULGlCQUFBLEtBQXNCTixTQUFBLEVBQVc7TUFDbkM3WCxNQUFBLENBQU9rSSxJQUFBLENBQUssaUJBQWlCO0lBQy9CO0lBQ0FsSSxNQUFBLENBQU9rSSxJQUFBLENBQUssYUFBYTtFQUMzQjtBQUNGO0FBRUEsU0FBUzJRLG1CQUFtQm5jLEVBQUEsRUFBSW9jLElBQUEsRUFBTTtFQUNwQyxNQUFNOVksTUFBQSxHQUFTO0VBQ2YsTUFBTVEsTUFBQSxHQUFTUixNQUFBLENBQU9RLE1BQUE7RUFDdEIsSUFBSXNQLE1BQUEsR0FBUXBULEVBQUEsQ0FBR3FhLE9BQUEsQ0FBUSxJQUFJdlcsTUFBQSxDQUFPd04sVUFBQSxnQkFBMEI7RUFDNUQsSUFBSSxDQUFDOEIsTUFBQSxJQUFTOVAsTUFBQSxDQUFPd1QsU0FBQSxJQUFhc0YsSUFBQSxJQUFRQSxJQUFBLENBQUsxZ0IsTUFBQSxHQUFTLEtBQUswZ0IsSUFBQSxDQUFLeFIsUUFBQSxDQUFTNUssRUFBRSxHQUFHO0lBQzlFLENBQUMsR0FBR29jLElBQUEsQ0FBS3hhLEtBQUEsQ0FBTXdhLElBQUEsQ0FBSzVaLE9BQUEsQ0FBUXhDLEVBQUUsSUFBSSxHQUFHb2MsSUFBQSxDQUFLMWdCLE1BQU0sQ0FBQyxFQUFFRixPQUFBLENBQVE2Z0IsTUFBQSxJQUFVO01BQ25FLElBQUksQ0FBQ2pKLE1BQUEsSUFBU2lKLE1BQUEsQ0FBTzdXLE9BQUEsSUFBVzZXLE1BQUEsQ0FBTzdXLE9BQUEsQ0FBUSxJQUFJMUIsTUFBQSxDQUFPd04sVUFBQSxnQkFBMEIsR0FBRztRQUNyRjhCLE1BQUEsR0FBUWlKLE1BQUE7TUFDVjtJQUNGLENBQUM7RUFDSDtFQUNBLElBQUlDLFVBQUEsR0FBYTtFQUNqQixJQUFJeEgsVUFBQTtFQUNKLElBQUkxQixNQUFBLEVBQU87SUFDVCxTQUFTL1EsQ0FBQSxHQUFJLEdBQUdBLENBQUEsR0FBSWlCLE1BQUEsQ0FBTytOLE1BQUEsQ0FBTzNWLE1BQUEsRUFBUTJHLENBQUEsSUFBSyxHQUFHO01BQ2hELElBQUlpQixNQUFBLENBQU8rTixNQUFBLENBQU9oUCxDQUFBLE1BQU8rUSxNQUFBLEVBQU87UUFDOUJrSixVQUFBLEdBQWE7UUFDYnhILFVBQUEsR0FBYXpTLENBQUE7UUFDYjtNQUNGO0lBQ0Y7RUFDRjtFQUNBLElBQUkrUSxNQUFBLElBQVNrSixVQUFBLEVBQVk7SUFDdkJoWixNQUFBLENBQU9pWixZQUFBLEdBQWVuSixNQUFBO0lBQ3RCLElBQUk5UCxNQUFBLENBQU80TixPQUFBLElBQVc1TixNQUFBLENBQU9RLE1BQUEsQ0FBT29OLE9BQUEsQ0FBUUMsT0FBQSxFQUFTO01BQ25EN04sTUFBQSxDQUFPa1osWUFBQSxHQUFlbk0sUUFBQSxDQUFTK0MsTUFBQSxDQUFNNkksWUFBQSxDQUFhLHlCQUF5QixHQUFHLEVBQUU7SUFDbEYsT0FBTztNQUNMM1ksTUFBQSxDQUFPa1osWUFBQSxHQUFlMUgsVUFBQTtJQUN4QjtFQUNGLE9BQU87SUFDTHhSLE1BQUEsQ0FBT2laLFlBQUEsR0FBZTtJQUN0QmpaLE1BQUEsQ0FBT2taLFlBQUEsR0FBZTtJQUN0QjtFQUNGO0VBQ0EsSUFBSTFZLE1BQUEsQ0FBTzJZLG1CQUFBLElBQXVCblosTUFBQSxDQUFPa1osWUFBQSxLQUFpQixVQUFhbFosTUFBQSxDQUFPa1osWUFBQSxLQUFpQmxaLE1BQUEsQ0FBT3FULFdBQUEsRUFBYTtJQUNqSHJULE1BQUEsQ0FBT21aLG1CQUFBLENBQW9CO0VBQzdCO0FBQ0Y7QUFFQSxJQUFJQyxNQUFBLEdBQVM7RUFDWDFNLFVBQUE7RUFDQVEsWUFBQTtFQUNBNkYsZ0JBQUE7RUFDQVAsa0JBQUE7RUFDQXdCLG9CQUFBO0VBQ0FlLGNBQUE7RUFDQW1CLG1CQUFBO0VBQ0E4QixpQkFBQTtFQUNBYTtBQUNGO0FBRUEsU0FBU1EsbUJBQW1CdmMsSUFBQSxFQUFNO0VBQ2hDLElBQUlBLElBQUEsS0FBUyxRQUFRO0lBQ25CQSxJQUFBLEdBQU8sS0FBSytQLFlBQUEsQ0FBYSxJQUFJLE1BQU07RUFDckM7RUFDQSxNQUFNN00sTUFBQSxHQUFTO0VBQ2YsTUFBTTtJQUNKUSxNQUFBO0lBQ0FnTixZQUFBLEVBQWNDLEdBQUE7SUFDZHJOLFNBQUEsRUFBQTZULFVBQUE7SUFDQXZUO0VBQ0YsSUFBSVYsTUFBQTtFQUNKLElBQUlRLE1BQUEsQ0FBTzhZLGdCQUFBLEVBQWtCO0lBQzNCLE9BQU83TCxHQUFBLEdBQU0sQ0FBQ3dHLFVBQUEsR0FBWUEsVUFBQTtFQUM1QjtFQUNBLElBQUl6VCxNQUFBLENBQU80TyxPQUFBLEVBQVM7SUFDbEIsT0FBTzZFLFVBQUE7RUFDVDtFQUNBLElBQUlzRixnQkFBQSxHQUFtQjFjLFlBQUEsQ0FBYTZELFNBQUEsRUFBVzVELElBQUk7RUFDbkR5YyxnQkFBQSxJQUFvQnZaLE1BQUEsQ0FBTzRULHFCQUFBLENBQXNCO0VBQ2pELElBQUluRyxHQUFBLEVBQUs4TCxnQkFBQSxHQUFtQixDQUFDQSxnQkFBQTtFQUM3QixPQUFPQSxnQkFBQSxJQUFvQjtBQUM3QjtBQUVBLFNBQVNDLGFBQWF2RixVQUFBLEVBQVd3RixZQUFBLEVBQWM7RUFDN0MsTUFBTXpaLE1BQUEsR0FBUztFQUNmLE1BQU07SUFDSndOLFlBQUEsRUFBY0MsR0FBQTtJQUNkak4sTUFBQTtJQUNBRSxTQUFBO0lBQ0FRO0VBQ0YsSUFBSWxCLE1BQUE7RUFDSixJQUFJMFosQ0FBQSxHQUFJO0VBQ1IsSUFBSUMsQ0FBQSxHQUFJO0VBQ1IsTUFBTUMsQ0FBQSxHQUFJO0VBQ1YsSUFBSTVaLE1BQUEsQ0FBTzZNLFlBQUEsQ0FBYSxHQUFHO0lBQ3pCNk0sQ0FBQSxHQUFJak0sR0FBQSxHQUFNLENBQUN3RyxVQUFBLEdBQVlBLFVBQUE7RUFDekIsT0FBTztJQUNMMEYsQ0FBQSxHQUFJMUYsVUFBQTtFQUNOO0VBQ0EsSUFBSXpULE1BQUEsQ0FBTzJQLFlBQUEsRUFBYztJQUN2QnVKLENBQUEsR0FBSXZZLElBQUEsQ0FBS29QLEtBQUEsQ0FBTW1KLENBQUM7SUFDaEJDLENBQUEsR0FBSXhZLElBQUEsQ0FBS29QLEtBQUEsQ0FBTW9KLENBQUM7RUFDbEI7RUFDQTNaLE1BQUEsQ0FBTzZaLGlCQUFBLEdBQW9CN1osTUFBQSxDQUFPSSxTQUFBO0VBQ2xDSixNQUFBLENBQU9JLFNBQUEsR0FBWUosTUFBQSxDQUFPNk0sWUFBQSxDQUFhLElBQUk2TSxDQUFBLEdBQUlDLENBQUE7RUFDL0MsSUFBSW5aLE1BQUEsQ0FBTzRPLE9BQUEsRUFBUztJQUNsQjFPLFNBQUEsQ0FBVVYsTUFBQSxDQUFPNk0sWUFBQSxDQUFhLElBQUksZUFBZSxlQUFlN00sTUFBQSxDQUFPNk0sWUFBQSxDQUFhLElBQUksQ0FBQzZNLENBQUEsR0FBSSxDQUFDQyxDQUFBO0VBQ2hHLFdBQVcsQ0FBQ25aLE1BQUEsQ0FBTzhZLGdCQUFBLEVBQWtCO0lBQ25DLElBQUl0WixNQUFBLENBQU82TSxZQUFBLENBQWEsR0FBRztNQUN6QjZNLENBQUEsSUFBSzFaLE1BQUEsQ0FBTzRULHFCQUFBLENBQXNCO0lBQ3BDLE9BQU87TUFDTCtGLENBQUEsSUFBSzNaLE1BQUEsQ0FBTzRULHFCQUFBLENBQXNCO0lBQ3BDO0lBQ0FsVCxTQUFBLENBQVV0SCxLQUFBLENBQU1nRSxTQUFBLEdBQVksZUFBZXNjLENBQUEsT0FBUUMsQ0FBQSxPQUFRQyxDQUFBO0VBQzdEO0VBR0EsSUFBSUUsV0FBQTtFQUNKLE1BQU03RSxjQUFBLEdBQWlCalYsTUFBQSxDQUFPa1YsWUFBQSxDQUFhLElBQUlsVixNQUFBLENBQU9zVSxZQUFBLENBQWE7RUFDbkUsSUFBSVcsY0FBQSxLQUFtQixHQUFHO0lBQ3hCNkUsV0FBQSxHQUFjO0VBQ2hCLE9BQU87SUFDTEEsV0FBQSxJQUFlN0YsVUFBQSxHQUFZalUsTUFBQSxDQUFPc1UsWUFBQSxDQUFhLEtBQUtXLGNBQUE7RUFDdEQ7RUFDQSxJQUFJNkUsV0FBQSxLQUFnQjVZLFFBQUEsRUFBVTtJQUM1QmxCLE1BQUEsQ0FBTytVLGNBQUEsQ0FBZWQsVUFBUztFQUNqQztFQUNBalUsTUFBQSxDQUFPa0ksSUFBQSxDQUFLLGdCQUFnQmxJLE1BQUEsQ0FBT0ksU0FBQSxFQUFXcVosWUFBWTtBQUM1RDtBQUVBLFNBQVNuRixhQUFBLEVBQWU7RUFDdEIsT0FBTyxDQUFDLEtBQUtwRyxRQUFBLENBQVM7QUFDeEI7QUFFQSxTQUFTZ0gsYUFBQSxFQUFlO0VBQ3RCLE9BQU8sQ0FBQyxLQUFLaEgsUUFBQSxDQUFTLEtBQUtBLFFBQUEsQ0FBUzlWLE1BQUEsR0FBUztBQUMvQztBQUVBLFNBQVMyaEIsWUFBWTlGLFVBQUEsRUFBV3hULEtBQUEsRUFBT3VaLFlBQUEsRUFBY0MsZUFBQSxFQUFpQkMsUUFBQSxFQUFVO0VBQzlFLElBQUlqRyxVQUFBLEtBQWMsUUFBUTtJQUN4QkEsVUFBQSxHQUFZO0VBQ2Q7RUFDQSxJQUFJeFQsS0FBQSxLQUFVLFFBQVE7SUFDcEJBLEtBQUEsR0FBUSxLQUFLRCxNQUFBLENBQU9DLEtBQUE7RUFDdEI7RUFDQSxJQUFJdVosWUFBQSxLQUFpQixRQUFRO0lBQzNCQSxZQUFBLEdBQWU7RUFDakI7RUFDQSxJQUFJQyxlQUFBLEtBQW9CLFFBQVE7SUFDOUJBLGVBQUEsR0FBa0I7RUFDcEI7RUFDQSxNQUFNamEsTUFBQSxHQUFTO0VBQ2YsTUFBTTtJQUNKUSxNQUFBO0lBQ0FFO0VBQ0YsSUFBSVYsTUFBQTtFQUNKLElBQUlBLE1BQUEsQ0FBT21hLFNBQUEsSUFBYTNaLE1BQUEsQ0FBTzRaLDhCQUFBLEVBQWdDO0lBQzdELE9BQU87RUFDVDtFQUNBLE1BQU1DLGFBQUEsR0FBZXJhLE1BQUEsQ0FBT3NVLFlBQUEsQ0FBYTtFQUN6QyxNQUFNZ0csYUFBQSxHQUFldGEsTUFBQSxDQUFPa1YsWUFBQSxDQUFhO0VBQ3pDLElBQUlxRixZQUFBO0VBQ0osSUFBSU4sZUFBQSxJQUFtQmhHLFVBQUEsR0FBWW9HLGFBQUEsRUFBY0UsWUFBQSxHQUFlRixhQUFBLFVBQXNCSixlQUFBLElBQW1CaEcsVUFBQSxHQUFZcUcsYUFBQSxFQUFjQyxZQUFBLEdBQWVELGFBQUEsTUFBa0JDLFlBQUEsR0FBZXRHLFVBQUE7RUFHbkxqVSxNQUFBLENBQU8rVSxjQUFBLENBQWV3RixZQUFZO0VBQ2xDLElBQUkvWixNQUFBLENBQU80TyxPQUFBLEVBQVM7SUFDbEIsTUFBTW9MLEdBQUEsR0FBTXhhLE1BQUEsQ0FBTzZNLFlBQUEsQ0FBYTtJQUNoQyxJQUFJcE0sS0FBQSxLQUFVLEdBQUc7TUFDZkMsU0FBQSxDQUFVOFosR0FBQSxHQUFNLGVBQWUsZUFBZSxDQUFDRCxZQUFBO0lBQ2pELE9BQU87TUFDTCxJQUFJLENBQUN2YSxNQUFBLENBQU9rRixPQUFBLENBQVFFLFlBQUEsRUFBYztRQUNoQ3RGLG9CQUFBLENBQXFCO1VBQ25CRSxNQUFBO1VBQ0FDLGNBQUEsRUFBZ0IsQ0FBQ3NhLFlBQUE7VUFDakJyYSxJQUFBLEVBQU1zYSxHQUFBLEdBQU0sU0FBUztRQUN2QixDQUFDO1FBQ0QsT0FBTztNQUNUO01BQ0E5WixTQUFBLENBQVVnQixRQUFBLENBQVM7UUFDakIsQ0FBQzhZLEdBQUEsR0FBTSxTQUFTLFFBQVEsQ0FBQ0QsWUFBQTtRQUN6QkUsUUFBQSxFQUFVO01BQ1osQ0FBQztJQUNIO0lBQ0EsT0FBTztFQUNUO0VBQ0EsSUFBSWhhLEtBQUEsS0FBVSxHQUFHO0lBQ2ZULE1BQUEsQ0FBT2lULGFBQUEsQ0FBYyxDQUFDO0lBQ3RCalQsTUFBQSxDQUFPd1osWUFBQSxDQUFhZSxZQUFZO0lBQ2hDLElBQUlQLFlBQUEsRUFBYztNQUNoQmhhLE1BQUEsQ0FBT2tJLElBQUEsQ0FBSyx5QkFBeUJ6SCxLQUFBLEVBQU95WixRQUFRO01BQ3BEbGEsTUFBQSxDQUFPa0ksSUFBQSxDQUFLLGVBQWU7SUFDN0I7RUFDRixPQUFPO0lBQ0xsSSxNQUFBLENBQU9pVCxhQUFBLENBQWN4UyxLQUFLO0lBQzFCVCxNQUFBLENBQU93WixZQUFBLENBQWFlLFlBQVk7SUFDaEMsSUFBSVAsWUFBQSxFQUFjO01BQ2hCaGEsTUFBQSxDQUFPa0ksSUFBQSxDQUFLLHlCQUF5QnpILEtBQUEsRUFBT3laLFFBQVE7TUFDcERsYSxNQUFBLENBQU9rSSxJQUFBLENBQUssaUJBQWlCO0lBQy9CO0lBQ0EsSUFBSSxDQUFDbEksTUFBQSxDQUFPbWEsU0FBQSxFQUFXO01BQ3JCbmEsTUFBQSxDQUFPbWEsU0FBQSxHQUFZO01BQ25CLElBQUksQ0FBQ25hLE1BQUEsQ0FBTzBhLGlDQUFBLEVBQW1DO1FBQzdDMWEsTUFBQSxDQUFPMGEsaUNBQUEsR0FBb0MsU0FBU0MsZUFBY3RlLENBQUEsRUFBRztVQUNuRSxJQUFJLENBQUMyRCxNQUFBLElBQVVBLE1BQUEsQ0FBT3NJLFNBQUEsRUFBVztVQUNqQyxJQUFJak0sQ0FBQSxDQUFFdEUsTUFBQSxLQUFXLE1BQU07VUFDdkJpSSxNQUFBLENBQU9VLFNBQUEsQ0FBVWxJLG1CQUFBLENBQW9CLGlCQUFpQndILE1BQUEsQ0FBTzBhLGlDQUFpQztVQUM5RjFhLE1BQUEsQ0FBTzBhLGlDQUFBLEdBQW9DO1VBQzNDLE9BQU8xYSxNQUFBLENBQU8wYSxpQ0FBQTtVQUNkMWEsTUFBQSxDQUFPbWEsU0FBQSxHQUFZO1VBQ25CLElBQUlILFlBQUEsRUFBYztZQUNoQmhhLE1BQUEsQ0FBT2tJLElBQUEsQ0FBSyxlQUFlO1VBQzdCO1FBQ0Y7TUFDRjtNQUNBbEksTUFBQSxDQUFPVSxTQUFBLENBQVVuSSxnQkFBQSxDQUFpQixpQkFBaUJ5SCxNQUFBLENBQU8wYSxpQ0FBaUM7SUFDN0Y7RUFDRjtFQUNBLE9BQU87QUFDVDtBQUVBLElBQUl0YSxTQUFBLEdBQVk7RUFDZHZELFlBQUEsRUFBY3djLGtCQUFBO0VBQ2RHLFlBQUE7RUFDQWxGLFlBQUE7RUFDQVksWUFBQTtFQUNBNkU7QUFDRjtBQUVBLFNBQVM5RyxjQUFjMVMsUUFBQSxFQUFVa1osWUFBQSxFQUFjO0VBQzdDLE1BQU16WixNQUFBLEdBQVM7RUFDZixJQUFJLENBQUNBLE1BQUEsQ0FBT1EsTUFBQSxDQUFPNE8sT0FBQSxFQUFTO0lBQzFCcFAsTUFBQSxDQUFPVSxTQUFBLENBQVV0SCxLQUFBLENBQU13aEIsa0JBQUEsR0FBcUIsR0FBR3JhLFFBQUE7SUFDL0NQLE1BQUEsQ0FBT1UsU0FBQSxDQUFVdEgsS0FBQSxDQUFNeWhCLGVBQUEsR0FBa0J0YSxRQUFBLEtBQWEsSUFBSSxRQUFRO0VBQ3BFO0VBQ0FQLE1BQUEsQ0FBT2tJLElBQUEsQ0FBSyxpQkFBaUIzSCxRQUFBLEVBQVVrWixZQUFZO0FBQ3JEO0FBRUEsU0FBU3FCLGVBQWUvYSxJQUFBLEVBQU07RUFDNUIsSUFBSTtJQUNGQyxNQUFBO0lBQ0FnYSxZQUFBO0lBQ0FlLFNBQUE7SUFDQUM7RUFDRixJQUFJamIsSUFBQTtFQUNKLE1BQU07SUFDSnNULFdBQUE7SUFDQTZFO0VBQ0YsSUFBSWxZLE1BQUE7RUFDSixJQUFJYSxHQUFBLEdBQU1rYSxTQUFBO0VBQ1YsSUFBSSxDQUFDbGEsR0FBQSxFQUFLO0lBQ1IsSUFBSXdTLFdBQUEsR0FBYzZFLGFBQUEsRUFBZXJYLEdBQUEsR0FBTSxnQkFBZ0J3UyxXQUFBLEdBQWM2RSxhQUFBLEVBQWVyWCxHQUFBLEdBQU0sWUFBWUEsR0FBQSxHQUFNO0VBQzlHO0VBQ0FiLE1BQUEsQ0FBT2tJLElBQUEsQ0FBSyxhQUFhOFMsSUFBQSxFQUFNO0VBQy9CLElBQUloQixZQUFBLElBQWdCM0csV0FBQSxLQUFnQjZFLGFBQUEsRUFBZTtJQUNqRCxJQUFJclgsR0FBQSxLQUFRLFNBQVM7TUFDbkJiLE1BQUEsQ0FBT2tJLElBQUEsQ0FBSyx1QkFBdUI4UyxJQUFBLEVBQU07TUFDekM7SUFDRjtJQUNBaGIsTUFBQSxDQUFPa0ksSUFBQSxDQUFLLHdCQUF3QjhTLElBQUEsRUFBTTtJQUMxQyxJQUFJbmEsR0FBQSxLQUFRLFFBQVE7TUFDbEJiLE1BQUEsQ0FBT2tJLElBQUEsQ0FBSyxzQkFBc0I4UyxJQUFBLEVBQU07SUFDMUMsT0FBTztNQUNMaGIsTUFBQSxDQUFPa0ksSUFBQSxDQUFLLHNCQUFzQjhTLElBQUEsRUFBTTtJQUMxQztFQUNGO0FBQ0Y7QUFFQSxTQUFTQyxnQkFBZ0JqQixZQUFBLEVBQWNlLFNBQUEsRUFBVztFQUNoRCxJQUFJZixZQUFBLEtBQWlCLFFBQVE7SUFDM0JBLFlBQUEsR0FBZTtFQUNqQjtFQUNBLE1BQU1oYSxNQUFBLEdBQVM7RUFDZixNQUFNO0lBQ0pRO0VBQ0YsSUFBSVIsTUFBQTtFQUNKLElBQUlRLE1BQUEsQ0FBTzRPLE9BQUEsRUFBUztFQUNwQixJQUFJNU8sTUFBQSxDQUFPd1YsVUFBQSxFQUFZO0lBQ3JCaFcsTUFBQSxDQUFPK1MsZ0JBQUEsQ0FBaUI7RUFDMUI7RUFDQStILGNBQUEsQ0FBZTtJQUNiOWEsTUFBQTtJQUNBZ2EsWUFBQTtJQUNBZSxTQUFBO0lBQ0FDLElBQUEsRUFBTTtFQUNSLENBQUM7QUFDSDtBQUVBLFNBQVNFLGNBQWNsQixZQUFBLEVBQWNlLFNBQUEsRUFBVztFQUM5QyxJQUFJZixZQUFBLEtBQWlCLFFBQVE7SUFDM0JBLFlBQUEsR0FBZTtFQUNqQjtFQUNBLE1BQU1oYSxNQUFBLEdBQVM7RUFDZixNQUFNO0lBQ0pRO0VBQ0YsSUFBSVIsTUFBQTtFQUNKQSxNQUFBLENBQU9tYSxTQUFBLEdBQVk7RUFDbkIsSUFBSTNaLE1BQUEsQ0FBTzRPLE9BQUEsRUFBUztFQUNwQnBQLE1BQUEsQ0FBT2lULGFBQUEsQ0FBYyxDQUFDO0VBQ3RCNkgsY0FBQSxDQUFlO0lBQ2I5YSxNQUFBO0lBQ0FnYSxZQUFBO0lBQ0FlLFNBQUE7SUFDQUMsSUFBQSxFQUFNO0VBQ1IsQ0FBQztBQUNIO0FBRUEsSUFBSUcsVUFBQSxHQUFhO0VBQ2ZsSSxhQUFBO0VBQ0FnSSxlQUFBO0VBQ0FDO0FBQ0Y7QUFFQSxTQUFTRSxRQUFRblAsS0FBQSxFQUFPeEwsS0FBQSxFQUFPdVosWUFBQSxFQUFjRSxRQUFBLEVBQVVtQixPQUFBLEVBQVM7RUFDOUQsSUFBSXBQLEtBQUEsS0FBVSxRQUFRO0lBQ3BCQSxLQUFBLEdBQVE7RUFDVjtFQUNBLElBQUkrTixZQUFBLEtBQWlCLFFBQVE7SUFDM0JBLFlBQUEsR0FBZTtFQUNqQjtFQUNBLElBQUksT0FBTy9OLEtBQUEsS0FBVSxVQUFVO0lBQzdCQSxLQUFBLEdBQVFjLFFBQUEsQ0FBU2QsS0FBQSxFQUFPLEVBQUU7RUFDNUI7RUFDQSxNQUFNak0sTUFBQSxHQUFTO0VBQ2YsSUFBSXdSLFVBQUEsR0FBYXZGLEtBQUE7RUFDakIsSUFBSXVGLFVBQUEsR0FBYSxHQUFHQSxVQUFBLEdBQWE7RUFDakMsTUFBTTtJQUNKaFIsTUFBQTtJQUNBME4sUUFBQTtJQUNBQyxVQUFBO0lBQ0ErSixhQUFBO0lBQ0E3RSxXQUFBO0lBQ0E3RixZQUFBLEVBQWNDLEdBQUE7SUFDZC9NLFNBQUE7SUFDQW1OO0VBQ0YsSUFBSTdOLE1BQUE7RUFDSixJQUFJLENBQUM2TixPQUFBLElBQVcsQ0FBQ3FNLFFBQUEsSUFBWSxDQUFDbUIsT0FBQSxJQUFXcmIsTUFBQSxDQUFPc0ksU0FBQSxJQUFhdEksTUFBQSxDQUFPbWEsU0FBQSxJQUFhM1osTUFBQSxDQUFPNFosOEJBQUEsRUFBZ0M7SUFDdEgsT0FBTztFQUNUO0VBQ0EsSUFBSSxPQUFPM1osS0FBQSxLQUFVLGFBQWE7SUFDaENBLEtBQUEsR0FBUVQsTUFBQSxDQUFPUSxNQUFBLENBQU9DLEtBQUE7RUFDeEI7RUFDQSxNQUFNK1gsSUFBQSxHQUFPclgsSUFBQSxDQUFLRSxHQUFBLENBQUlyQixNQUFBLENBQU9RLE1BQUEsQ0FBT21RLGtCQUFBLEVBQW9CYSxVQUFVO0VBQ2xFLElBQUlTLFNBQUEsR0FBWXVHLElBQUEsR0FBT3JYLElBQUEsQ0FBS29QLEtBQUEsRUFBT2lCLFVBQUEsR0FBYWdILElBQUEsSUFBUXhZLE1BQUEsQ0FBT1EsTUFBQSxDQUFPa1EsY0FBYztFQUNwRixJQUFJdUIsU0FBQSxJQUFhL0QsUUFBQSxDQUFTOVYsTUFBQSxFQUFRNlosU0FBQSxHQUFZL0QsUUFBQSxDQUFTOVYsTUFBQSxHQUFTO0VBQ2hFLE1BQU02YixVQUFBLEdBQVksQ0FBQy9GLFFBQUEsQ0FBUytELFNBQUE7RUFFNUIsSUFBSXpSLE1BQUEsQ0FBT3VYLG1CQUFBLEVBQXFCO0lBQzlCLFNBQVNoWixDQUFBLEdBQUksR0FBR0EsQ0FBQSxHQUFJb1AsVUFBQSxDQUFXL1YsTUFBQSxFQUFRMkcsQ0FBQSxJQUFLLEdBQUc7TUFDN0MsTUFBTXVjLG1CQUFBLEdBQXNCLENBQUNuYSxJQUFBLENBQUtvUCxLQUFBLENBQU0wRCxVQUFBLEdBQVksR0FBRztNQUN2RCxNQUFNc0gsY0FBQSxHQUFpQnBhLElBQUEsQ0FBS29QLEtBQUEsQ0FBTXBDLFVBQUEsQ0FBV3BQLENBQUEsSUFBSyxHQUFHO01BQ3JELE1BQU15YyxrQkFBQSxHQUFxQnJhLElBQUEsQ0FBS29QLEtBQUEsQ0FBTXBDLFVBQUEsQ0FBV3BQLENBQUEsR0FBSSxLQUFLLEdBQUc7TUFDN0QsSUFBSSxPQUFPb1AsVUFBQSxDQUFXcFAsQ0FBQSxHQUFJLE9BQU8sYUFBYTtRQUM1QyxJQUFJdWMsbUJBQUEsSUFBdUJDLGNBQUEsSUFBa0JELG1CQUFBLEdBQXNCRSxrQkFBQSxJQUFzQkEsa0JBQUEsR0FBcUJELGNBQUEsSUFBa0IsR0FBRztVQUNqSS9KLFVBQUEsR0FBYXpTLENBQUE7UUFDZixXQUFXdWMsbUJBQUEsSUFBdUJDLGNBQUEsSUFBa0JELG1CQUFBLEdBQXNCRSxrQkFBQSxFQUFvQjtVQUM1RmhLLFVBQUEsR0FBYXpTLENBQUEsR0FBSTtRQUNuQjtNQUNGLFdBQVd1YyxtQkFBQSxJQUF1QkMsY0FBQSxFQUFnQjtRQUNoRC9KLFVBQUEsR0FBYXpTLENBQUE7TUFDZjtJQUNGO0VBQ0Y7RUFFQSxJQUFJaUIsTUFBQSxDQUFPdUksV0FBQSxJQUFlaUosVUFBQSxLQUFlNkIsV0FBQSxFQUFhO0lBQ3BELElBQUksQ0FBQ3JULE1BQUEsQ0FBT3liLGNBQUEsS0FBbUJoTyxHQUFBLEdBQU13RyxVQUFBLEdBQVlqVSxNQUFBLENBQU9JLFNBQUEsSUFBYTZULFVBQUEsR0FBWWpVLE1BQUEsQ0FBT3NVLFlBQUEsQ0FBYSxJQUFJTCxVQUFBLEdBQVlqVSxNQUFBLENBQU9JLFNBQUEsSUFBYTZULFVBQUEsR0FBWWpVLE1BQUEsQ0FBT3NVLFlBQUEsQ0FBYSxJQUFJO01BQzNLLE9BQU87SUFDVDtJQUNBLElBQUksQ0FBQ3RVLE1BQUEsQ0FBTzBiLGNBQUEsSUFBa0J6SCxVQUFBLEdBQVlqVSxNQUFBLENBQU9JLFNBQUEsSUFBYTZULFVBQUEsR0FBWWpVLE1BQUEsQ0FBT2tWLFlBQUEsQ0FBYSxHQUFHO01BQy9GLEtBQUs3QixXQUFBLElBQWUsT0FBTzdCLFVBQUEsRUFBWTtRQUNyQyxPQUFPO01BQ1Q7SUFDRjtFQUNGO0VBQ0EsSUFBSUEsVUFBQSxNQUFnQjBHLGFBQUEsSUFBaUIsTUFBTThCLFlBQUEsRUFBYztJQUN2RGhhLE1BQUEsQ0FBT2tJLElBQUEsQ0FBSyx3QkFBd0I7RUFDdEM7RUFHQWxJLE1BQUEsQ0FBTytVLGNBQUEsQ0FBZWQsVUFBUztFQUMvQixJQUFJOEcsU0FBQTtFQUNKLElBQUl2SixVQUFBLEdBQWE2QixXQUFBLEVBQWEwSCxTQUFBLEdBQVksZ0JBQWdCdkosVUFBQSxHQUFhNkIsV0FBQSxFQUFhMEgsU0FBQSxHQUFZLFlBQVlBLFNBQUEsR0FBWTtFQUd4SCxJQUFJdE4sR0FBQSxJQUFPLENBQUN3RyxVQUFBLEtBQWNqVSxNQUFBLENBQU9JLFNBQUEsSUFBYSxDQUFDcU4sR0FBQSxJQUFPd0csVUFBQSxLQUFjalUsTUFBQSxDQUFPSSxTQUFBLEVBQVc7SUFDcEZKLE1BQUEsQ0FBT2dZLGlCQUFBLENBQWtCeEcsVUFBVTtJQUVuQyxJQUFJaFIsTUFBQSxDQUFPd1YsVUFBQSxFQUFZO01BQ3JCaFcsTUFBQSxDQUFPK1MsZ0JBQUEsQ0FBaUI7SUFDMUI7SUFDQS9TLE1BQUEsQ0FBT2tXLG1CQUFBLENBQW9CO0lBQzNCLElBQUkxVixNQUFBLENBQU9vUSxNQUFBLEtBQVcsU0FBUztNQUM3QjVRLE1BQUEsQ0FBT3daLFlBQUEsQ0FBYXZGLFVBQVM7SUFDL0I7SUFDQSxJQUFJOEcsU0FBQSxLQUFjLFNBQVM7TUFDekIvYSxNQUFBLENBQU9pYixlQUFBLENBQWdCakIsWUFBQSxFQUFjZSxTQUFTO01BQzlDL2EsTUFBQSxDQUFPa2IsYUFBQSxDQUFjbEIsWUFBQSxFQUFjZSxTQUFTO0lBQzlDO0lBQ0EsT0FBTztFQUNUO0VBQ0EsSUFBSXZhLE1BQUEsQ0FBTzRPLE9BQUEsRUFBUztJQUNsQixNQUFNb0wsR0FBQSxHQUFNeGEsTUFBQSxDQUFPNk0sWUFBQSxDQUFhO0lBQ2hDLE1BQU04TyxDQUFBLEdBQUlsTyxHQUFBLEdBQU13RyxVQUFBLEdBQVksQ0FBQ0EsVUFBQTtJQUM3QixJQUFJeFQsS0FBQSxLQUFVLEdBQUc7TUFDZixNQUFNa04sU0FBQSxHQUFZM04sTUFBQSxDQUFPNE4sT0FBQSxJQUFXNU4sTUFBQSxDQUFPUSxNQUFBLENBQU9vTixPQUFBLENBQVFDLE9BQUE7TUFDMUQsSUFBSUYsU0FBQSxFQUFXO1FBQ2IzTixNQUFBLENBQU9VLFNBQUEsQ0FBVXRILEtBQUEsQ0FBTXVILGNBQUEsR0FBaUI7UUFDeENYLE1BQUEsQ0FBTzRiLGlCQUFBLEdBQW9CO01BQzdCO01BQ0EsSUFBSWpPLFNBQUEsSUFBYSxDQUFDM04sTUFBQSxDQUFPNmIseUJBQUEsSUFBNkI3YixNQUFBLENBQU9RLE1BQUEsQ0FBT3NiLFlBQUEsR0FBZSxHQUFHO1FBQ3BGOWIsTUFBQSxDQUFPNmIseUJBQUEsR0FBNEI7UUFDbkN2Z0IscUJBQUEsQ0FBc0IsTUFBTTtVQUMxQm9GLFNBQUEsQ0FBVThaLEdBQUEsR0FBTSxlQUFlLGVBQWVtQixDQUFBO1FBQ2hELENBQUM7TUFDSCxPQUFPO1FBQ0xqYixTQUFBLENBQVU4WixHQUFBLEdBQU0sZUFBZSxlQUFlbUIsQ0FBQTtNQUNoRDtNQUNBLElBQUloTyxTQUFBLEVBQVc7UUFDYnJTLHFCQUFBLENBQXNCLE1BQU07VUFDMUIwRSxNQUFBLENBQU9VLFNBQUEsQ0FBVXRILEtBQUEsQ0FBTXVILGNBQUEsR0FBaUI7VUFDeENYLE1BQUEsQ0FBTzRiLGlCQUFBLEdBQW9CO1FBQzdCLENBQUM7TUFDSDtJQUNGLE9BQU87TUFDTCxJQUFJLENBQUM1YixNQUFBLENBQU9rRixPQUFBLENBQVFFLFlBQUEsRUFBYztRQUNoQ3RGLG9CQUFBLENBQXFCO1VBQ25CRSxNQUFBO1VBQ0FDLGNBQUEsRUFBZ0IwYixDQUFBO1VBQ2hCemIsSUFBQSxFQUFNc2EsR0FBQSxHQUFNLFNBQVM7UUFDdkIsQ0FBQztRQUNELE9BQU87TUFDVDtNQUNBOVosU0FBQSxDQUFVZ0IsUUFBQSxDQUFTO1FBQ2pCLENBQUM4WSxHQUFBLEdBQU0sU0FBUyxRQUFRbUIsQ0FBQTtRQUN4QmxCLFFBQUEsRUFBVTtNQUNaLENBQUM7SUFDSDtJQUNBLE9BQU87RUFDVDtFQUNBemEsTUFBQSxDQUFPaVQsYUFBQSxDQUFjeFMsS0FBSztFQUMxQlQsTUFBQSxDQUFPd1osWUFBQSxDQUFhdkYsVUFBUztFQUM3QmpVLE1BQUEsQ0FBT2dZLGlCQUFBLENBQWtCeEcsVUFBVTtFQUNuQ3hSLE1BQUEsQ0FBT2tXLG1CQUFBLENBQW9CO0VBQzNCbFcsTUFBQSxDQUFPa0ksSUFBQSxDQUFLLHlCQUF5QnpILEtBQUEsRUFBT3laLFFBQVE7RUFDcERsYSxNQUFBLENBQU9pYixlQUFBLENBQWdCakIsWUFBQSxFQUFjZSxTQUFTO0VBQzlDLElBQUl0YSxLQUFBLEtBQVUsR0FBRztJQUNmVCxNQUFBLENBQU9rYixhQUFBLENBQWNsQixZQUFBLEVBQWNlLFNBQVM7RUFDOUMsV0FBVyxDQUFDL2EsTUFBQSxDQUFPbWEsU0FBQSxFQUFXO0lBQzVCbmEsTUFBQSxDQUFPbWEsU0FBQSxHQUFZO0lBQ25CLElBQUksQ0FBQ25hLE1BQUEsQ0FBTytiLDZCQUFBLEVBQStCO01BQ3pDL2IsTUFBQSxDQUFPK2IsNkJBQUEsR0FBZ0MsU0FBU3BCLGVBQWN0ZSxDQUFBLEVBQUc7UUFDL0QsSUFBSSxDQUFDMkQsTUFBQSxJQUFVQSxNQUFBLENBQU9zSSxTQUFBLEVBQVc7UUFDakMsSUFBSWpNLENBQUEsQ0FBRXRFLE1BQUEsS0FBVyxNQUFNO1FBQ3ZCaUksTUFBQSxDQUFPVSxTQUFBLENBQVVsSSxtQkFBQSxDQUFvQixpQkFBaUJ3SCxNQUFBLENBQU8rYiw2QkFBNkI7UUFDMUYvYixNQUFBLENBQU8rYiw2QkFBQSxHQUFnQztRQUN2QyxPQUFPL2IsTUFBQSxDQUFPK2IsNkJBQUE7UUFDZC9iLE1BQUEsQ0FBT2tiLGFBQUEsQ0FBY2xCLFlBQUEsRUFBY2UsU0FBUztNQUM5QztJQUNGO0lBQ0EvYSxNQUFBLENBQU9VLFNBQUEsQ0FBVW5JLGdCQUFBLENBQWlCLGlCQUFpQnlILE1BQUEsQ0FBTytiLDZCQUE2QjtFQUN6RjtFQUNBLE9BQU87QUFDVDtBQUVBLFNBQVNDLFlBQVkvUCxLQUFBLEVBQU94TCxLQUFBLEVBQU91WixZQUFBLEVBQWNFLFFBQUEsRUFBVTtFQUN6RCxJQUFJak8sS0FBQSxLQUFVLFFBQVE7SUFDcEJBLEtBQUEsR0FBUTtFQUNWO0VBQ0EsSUFBSStOLFlBQUEsS0FBaUIsUUFBUTtJQUMzQkEsWUFBQSxHQUFlO0VBQ2pCO0VBQ0EsSUFBSSxPQUFPL04sS0FBQSxLQUFVLFVBQVU7SUFDN0IsTUFBTWdRLGFBQUEsR0FBZ0JsUCxRQUFBLENBQVNkLEtBQUEsRUFBTyxFQUFFO0lBQ3hDQSxLQUFBLEdBQVFnUSxhQUFBO0VBQ1Y7RUFDQSxNQUFNamMsTUFBQSxHQUFTO0VBQ2YsSUFBSUEsTUFBQSxDQUFPc0ksU0FBQSxFQUFXO0VBQ3RCLElBQUksT0FBTzdILEtBQUEsS0FBVSxhQUFhO0lBQ2hDQSxLQUFBLEdBQVFULE1BQUEsQ0FBT1EsTUFBQSxDQUFPQyxLQUFBO0VBQ3hCO0VBQ0EsTUFBTTRPLFdBQUEsR0FBY3JQLE1BQUEsQ0FBT3NQLElBQUEsSUFBUXRQLE1BQUEsQ0FBT1EsTUFBQSxDQUFPOE8sSUFBQSxJQUFRdFAsTUFBQSxDQUFPUSxNQUFBLENBQU84TyxJQUFBLENBQUtDLElBQUEsR0FBTztFQUNuRixJQUFJMk0sUUFBQSxHQUFXalEsS0FBQTtFQUNmLElBQUlqTSxNQUFBLENBQU9RLE1BQUEsQ0FBT3lRLElBQUEsRUFBTTtJQUN0QixJQUFJalIsTUFBQSxDQUFPNE4sT0FBQSxJQUFXNU4sTUFBQSxDQUFPUSxNQUFBLENBQU9vTixPQUFBLENBQVFDLE9BQUEsRUFBUztNQUVuRHFPLFFBQUEsR0FBV0EsUUFBQSxHQUFXbGMsTUFBQSxDQUFPNE4sT0FBQSxDQUFRd0QsWUFBQTtJQUN2QyxPQUFPO01BQ0wsSUFBSStLLGdCQUFBO01BQ0osSUFBSTlNLFdBQUEsRUFBYTtRQUNmLE1BQU1tQyxVQUFBLEdBQWEwSyxRQUFBLEdBQVdsYyxNQUFBLENBQU9RLE1BQUEsQ0FBTzhPLElBQUEsQ0FBS0MsSUFBQTtRQUNqRDRNLGdCQUFBLEdBQW1CbmMsTUFBQSxDQUFPK04sTUFBQSxDQUFPOVIsTUFBQSxDQUFPNEYsT0FBQSxJQUFXQSxPQUFBLENBQVE4VyxZQUFBLENBQWEseUJBQXlCLElBQUksTUFBTW5ILFVBQVUsRUFBRSxHQUFHK0UsTUFBQTtNQUM1SCxPQUFPO1FBQ0w0RixnQkFBQSxHQUFtQm5jLE1BQUEsQ0FBT21ULG1CQUFBLENBQW9CK0ksUUFBUTtNQUN4RDtNQUNBLE1BQU1FLElBQUEsR0FBTy9NLFdBQUEsR0FBY2xPLElBQUEsQ0FBS2dRLElBQUEsQ0FBS25SLE1BQUEsQ0FBTytOLE1BQUEsQ0FBTzNWLE1BQUEsR0FBUzRILE1BQUEsQ0FBT1EsTUFBQSxDQUFPOE8sSUFBQSxDQUFLQyxJQUFJLElBQUl2UCxNQUFBLENBQU8rTixNQUFBLENBQU8zVixNQUFBO01BQ3JHLE1BQU07UUFDSitXO01BQ0YsSUFBSW5QLE1BQUEsQ0FBT1EsTUFBQTtNQUNYLElBQUlvUCxhQUFBLEdBQWdCNVAsTUFBQSxDQUFPUSxNQUFBLENBQU9vUCxhQUFBO01BQ2xDLElBQUlBLGFBQUEsS0FBa0IsUUFBUTtRQUM1QkEsYUFBQSxHQUFnQjVQLE1BQUEsQ0FBT3VYLG9CQUFBLENBQXFCO01BQzlDLE9BQU87UUFDTDNILGFBQUEsR0FBZ0J6TyxJQUFBLENBQUtnUSxJQUFBLENBQUtuVCxVQUFBLENBQVdnQyxNQUFBLENBQU9RLE1BQUEsQ0FBT29QLGFBQUEsRUFBZSxFQUFFLENBQUM7UUFDckUsSUFBSVQsY0FBQSxJQUFrQlMsYUFBQSxHQUFnQixNQUFNLEdBQUc7VUFDN0NBLGFBQUEsR0FBZ0JBLGFBQUEsR0FBZ0I7UUFDbEM7TUFDRjtNQUNBLElBQUl5TSxXQUFBLEdBQWNELElBQUEsR0FBT0QsZ0JBQUEsR0FBbUJ2TSxhQUFBO01BQzVDLElBQUlULGNBQUEsRUFBZ0I7UUFDbEJrTixXQUFBLEdBQWNBLFdBQUEsSUFBZUYsZ0JBQUEsR0FBbUJoYixJQUFBLENBQUtnUSxJQUFBLENBQUt2QixhQUFBLEdBQWdCLENBQUM7TUFDN0U7TUFDQSxJQUFJc0ssUUFBQSxJQUFZL0ssY0FBQSxJQUFrQm5QLE1BQUEsQ0FBT1EsTUFBQSxDQUFPb1AsYUFBQSxLQUFrQixVQUFVLENBQUNQLFdBQUEsRUFBYTtRQUN4RmdOLFdBQUEsR0FBYztNQUNoQjtNQUNBLElBQUlBLFdBQUEsRUFBYTtRQUNmLE1BQU10QixTQUFBLEdBQVk1TCxjQUFBLEdBQWlCZ04sZ0JBQUEsR0FBbUJuYyxNQUFBLENBQU9xVCxXQUFBLEdBQWMsU0FBUyxTQUFTOEksZ0JBQUEsR0FBbUJuYyxNQUFBLENBQU9xVCxXQUFBLEdBQWMsSUFBSXJULE1BQUEsQ0FBT1EsTUFBQSxDQUFPb1AsYUFBQSxHQUFnQixTQUFTO1FBQ2hMNVAsTUFBQSxDQUFPc2MsT0FBQSxDQUFRO1VBQ2J2QixTQUFBO1VBQ0FLLE9BQUEsRUFBUztVQUNUMUMsZ0JBQUEsRUFBa0JxQyxTQUFBLEtBQWMsU0FBU29CLGdCQUFBLEdBQW1CLElBQUlBLGdCQUFBLEdBQW1CQyxJQUFBLEdBQU87VUFDMUZHLGNBQUEsRUFBZ0J4QixTQUFBLEtBQWMsU0FBUy9hLE1BQUEsQ0FBTzZYLFNBQUEsR0FBWTtRQUM1RCxDQUFDO01BQ0g7TUFDQSxJQUFJeEksV0FBQSxFQUFhO1FBQ2YsTUFBTW1DLFVBQUEsR0FBYTBLLFFBQUEsR0FBV2xjLE1BQUEsQ0FBT1EsTUFBQSxDQUFPOE8sSUFBQSxDQUFLQyxJQUFBO1FBQ2pEMk0sUUFBQSxHQUFXbGMsTUFBQSxDQUFPK04sTUFBQSxDQUFPOVIsTUFBQSxDQUFPNEYsT0FBQSxJQUFXQSxPQUFBLENBQVE4VyxZQUFBLENBQWEseUJBQXlCLElBQUksTUFBTW5ILFVBQVUsRUFBRSxHQUFHK0UsTUFBQTtNQUNwSCxPQUFPO1FBQ0wyRixRQUFBLEdBQVdsYyxNQUFBLENBQU9tVCxtQkFBQSxDQUFvQitJLFFBQVE7TUFDaEQ7SUFDRjtFQUNGO0VBQ0E1Z0IscUJBQUEsQ0FBc0IsTUFBTTtJQUMxQjBFLE1BQUEsQ0FBT29iLE9BQUEsQ0FBUWMsUUFBQSxFQUFVemIsS0FBQSxFQUFPdVosWUFBQSxFQUFjRSxRQUFRO0VBQ3hELENBQUM7RUFDRCxPQUFPbGEsTUFBQTtBQUNUO0FBR0EsU0FBU3djLFVBQVUvYixLQUFBLEVBQU91WixZQUFBLEVBQWNFLFFBQUEsRUFBVTtFQUNoRCxJQUFJRixZQUFBLEtBQWlCLFFBQVE7SUFDM0JBLFlBQUEsR0FBZTtFQUNqQjtFQUNBLE1BQU1oYSxNQUFBLEdBQVM7RUFDZixNQUFNO0lBQ0o2TixPQUFBO0lBQ0FyTixNQUFBO0lBQ0EyWjtFQUNGLElBQUluYSxNQUFBO0VBQ0osSUFBSSxDQUFDNk4sT0FBQSxJQUFXN04sTUFBQSxDQUFPc0ksU0FBQSxFQUFXLE9BQU90SSxNQUFBO0VBQ3pDLElBQUksT0FBT1MsS0FBQSxLQUFVLGFBQWE7SUFDaENBLEtBQUEsR0FBUVQsTUFBQSxDQUFPUSxNQUFBLENBQU9DLEtBQUE7RUFDeEI7RUFDQSxJQUFJZ2MsUUFBQSxHQUFXamMsTUFBQSxDQUFPa1EsY0FBQTtFQUN0QixJQUFJbFEsTUFBQSxDQUFPb1AsYUFBQSxLQUFrQixVQUFVcFAsTUFBQSxDQUFPa1EsY0FBQSxLQUFtQixLQUFLbFEsTUFBQSxDQUFPa2Msa0JBQUEsRUFBb0I7SUFDL0ZELFFBQUEsR0FBV3RiLElBQUEsQ0FBS0MsR0FBQSxDQUFJcEIsTUFBQSxDQUFPdVgsb0JBQUEsQ0FBcUIsV0FBVyxJQUFJLEdBQUcsQ0FBQztFQUNyRTtFQUNBLE1BQU1vRixTQUFBLEdBQVkzYyxNQUFBLENBQU9xVCxXQUFBLEdBQWM3UyxNQUFBLENBQU9tUSxrQkFBQSxHQUFxQixJQUFJOEwsUUFBQTtFQUN2RSxNQUFNOU8sU0FBQSxHQUFZM04sTUFBQSxDQUFPNE4sT0FBQSxJQUFXcE4sTUFBQSxDQUFPb04sT0FBQSxDQUFRQyxPQUFBO0VBQ25ELElBQUlyTixNQUFBLENBQU95USxJQUFBLEVBQU07SUFDZixJQUFJa0osU0FBQSxJQUFhLENBQUN4TSxTQUFBLElBQWFuTixNQUFBLENBQU9vYyxtQkFBQSxFQUFxQixPQUFPO0lBQ2xFNWMsTUFBQSxDQUFPc2MsT0FBQSxDQUFRO01BQ2J2QixTQUFBLEVBQVc7SUFDYixDQUFDO0lBRUQvYSxNQUFBLENBQU82YyxXQUFBLEdBQWM3YyxNQUFBLENBQU9VLFNBQUEsQ0FBVXdDLFVBQUE7SUFDdEMsSUFBSWxELE1BQUEsQ0FBT3FULFdBQUEsS0FBZ0JyVCxNQUFBLENBQU8rTixNQUFBLENBQU8zVixNQUFBLEdBQVMsS0FBS29JLE1BQUEsQ0FBTzRPLE9BQUEsRUFBUztNQUNyRTlULHFCQUFBLENBQXNCLE1BQU07UUFDMUIwRSxNQUFBLENBQU9vYixPQUFBLENBQVFwYixNQUFBLENBQU9xVCxXQUFBLEdBQWNzSixTQUFBLEVBQVdsYyxLQUFBLEVBQU91WixZQUFBLEVBQWNFLFFBQVE7TUFDOUUsQ0FBQztNQUNELE9BQU87SUFDVDtFQUNGO0VBQ0EsSUFBSTFaLE1BQUEsQ0FBT29YLE1BQUEsSUFBVTVYLE1BQUEsQ0FBT29WLEtBQUEsRUFBTztJQUNqQyxPQUFPcFYsTUFBQSxDQUFPb2IsT0FBQSxDQUFRLEdBQUczYSxLQUFBLEVBQU91WixZQUFBLEVBQWNFLFFBQVE7RUFDeEQ7RUFDQSxPQUFPbGEsTUFBQSxDQUFPb2IsT0FBQSxDQUFRcGIsTUFBQSxDQUFPcVQsV0FBQSxHQUFjc0osU0FBQSxFQUFXbGMsS0FBQSxFQUFPdVosWUFBQSxFQUFjRSxRQUFRO0FBQ3JGO0FBR0EsU0FBUzRDLFVBQVVyYyxLQUFBLEVBQU91WixZQUFBLEVBQWNFLFFBQUEsRUFBVTtFQUNoRCxJQUFJRixZQUFBLEtBQWlCLFFBQVE7SUFDM0JBLFlBQUEsR0FBZTtFQUNqQjtFQUNBLE1BQU1oYSxNQUFBLEdBQVM7RUFDZixNQUFNO0lBQ0pRLE1BQUE7SUFDQTBOLFFBQUE7SUFDQUMsVUFBQTtJQUNBWCxZQUFBO0lBQ0FLLE9BQUE7SUFDQXNNO0VBQ0YsSUFBSW5hLE1BQUE7RUFDSixJQUFJLENBQUM2TixPQUFBLElBQVc3TixNQUFBLENBQU9zSSxTQUFBLEVBQVcsT0FBT3RJLE1BQUE7RUFDekMsSUFBSSxPQUFPUyxLQUFBLEtBQVUsYUFBYTtJQUNoQ0EsS0FBQSxHQUFRVCxNQUFBLENBQU9RLE1BQUEsQ0FBT0MsS0FBQTtFQUN4QjtFQUNBLE1BQU1rTixTQUFBLEdBQVkzTixNQUFBLENBQU80TixPQUFBLElBQVdwTixNQUFBLENBQU9vTixPQUFBLENBQVFDLE9BQUE7RUFDbkQsSUFBSXJOLE1BQUEsQ0FBT3lRLElBQUEsRUFBTTtJQUNmLElBQUlrSixTQUFBLElBQWEsQ0FBQ3hNLFNBQUEsSUFBYW5OLE1BQUEsQ0FBT29jLG1CQUFBLEVBQXFCLE9BQU87SUFDbEU1YyxNQUFBLENBQU9zYyxPQUFBLENBQVE7TUFDYnZCLFNBQUEsRUFBVztJQUNiLENBQUM7SUFFRC9hLE1BQUEsQ0FBTzZjLFdBQUEsR0FBYzdjLE1BQUEsQ0FBT1UsU0FBQSxDQUFVd0MsVUFBQTtFQUN4QztFQUNBLE1BQU0rUSxVQUFBLEdBQVl6RyxZQUFBLEdBQWV4TixNQUFBLENBQU9JLFNBQUEsR0FBWSxDQUFDSixNQUFBLENBQU9JLFNBQUE7RUFDNUQsU0FBUzJjLFVBQVVDLEdBQUEsRUFBSztJQUN0QixJQUFJQSxHQUFBLEdBQU0sR0FBRyxPQUFPLENBQUM3YixJQUFBLENBQUtvUCxLQUFBLENBQU1wUCxJQUFBLENBQUtzUCxHQUFBLENBQUl1TSxHQUFHLENBQUM7SUFDN0MsT0FBTzdiLElBQUEsQ0FBS29QLEtBQUEsQ0FBTXlNLEdBQUc7RUFDdkI7RUFDQSxNQUFNMUIsbUJBQUEsR0FBc0J5QixTQUFBLENBQVU5SSxVQUFTO0VBQy9DLE1BQU1nSixrQkFBQSxHQUFxQi9PLFFBQUEsQ0FBUzVRLEdBQUEsQ0FBSTBmLEdBQUEsSUFBT0QsU0FBQSxDQUFVQyxHQUFHLENBQUM7RUFDN0QsSUFBSUUsUUFBQSxHQUFXaFAsUUFBQSxDQUFTK08sa0JBQUEsQ0FBbUIvZCxPQUFBLENBQVFvYyxtQkFBbUIsSUFBSTtFQUMxRSxJQUFJLE9BQU80QixRQUFBLEtBQWEsZUFBZTFjLE1BQUEsQ0FBTzRPLE9BQUEsRUFBUztJQUNyRCxJQUFJK04sYUFBQTtJQUNKalAsUUFBQSxDQUFTaFcsT0FBQSxDQUFRLENBQUMyWixJQUFBLEVBQU1JLFNBQUEsS0FBYztNQUNwQyxJQUFJcUosbUJBQUEsSUFBdUJ6SixJQUFBLEVBQU07UUFFL0JzTCxhQUFBLEdBQWdCbEwsU0FBQTtNQUNsQjtJQUNGLENBQUM7SUFDRCxJQUFJLE9BQU9rTCxhQUFBLEtBQWtCLGFBQWE7TUFDeENELFFBQUEsR0FBV2hQLFFBQUEsQ0FBU2lQLGFBQUEsR0FBZ0IsSUFBSUEsYUFBQSxHQUFnQixJQUFJQSxhQUFBO0lBQzlEO0VBQ0Y7RUFDQSxJQUFJQyxTQUFBLEdBQVk7RUFDaEIsSUFBSSxPQUFPRixRQUFBLEtBQWEsYUFBYTtJQUNuQ0UsU0FBQSxHQUFZalAsVUFBQSxDQUFXalAsT0FBQSxDQUFRZ2UsUUFBUTtJQUN2QyxJQUFJRSxTQUFBLEdBQVksR0FBR0EsU0FBQSxHQUFZcGQsTUFBQSxDQUFPcVQsV0FBQSxHQUFjO0lBQ3BELElBQUk3UyxNQUFBLENBQU9vUCxhQUFBLEtBQWtCLFVBQVVwUCxNQUFBLENBQU9rUSxjQUFBLEtBQW1CLEtBQUtsUSxNQUFBLENBQU9rYyxrQkFBQSxFQUFvQjtNQUMvRlUsU0FBQSxHQUFZQSxTQUFBLEdBQVlwZCxNQUFBLENBQU91WCxvQkFBQSxDQUFxQixZQUFZLElBQUksSUFBSTtNQUN4RTZGLFNBQUEsR0FBWWpjLElBQUEsQ0FBS0MsR0FBQSxDQUFJZ2MsU0FBQSxFQUFXLENBQUM7SUFDbkM7RUFDRjtFQUNBLElBQUk1YyxNQUFBLENBQU9vWCxNQUFBLElBQVU1WCxNQUFBLENBQU9tVixXQUFBLEVBQWE7SUFDdkMsTUFBTWtJLFNBQUEsR0FBWXJkLE1BQUEsQ0FBT1EsTUFBQSxDQUFPb04sT0FBQSxJQUFXNU4sTUFBQSxDQUFPUSxNQUFBLENBQU9vTixPQUFBLENBQVFDLE9BQUEsSUFBVzdOLE1BQUEsQ0FBTzROLE9BQUEsR0FBVTVOLE1BQUEsQ0FBTzROLE9BQUEsQ0FBUUcsTUFBQSxDQUFPM1YsTUFBQSxHQUFTLElBQUk0SCxNQUFBLENBQU8rTixNQUFBLENBQU8zVixNQUFBLEdBQVM7SUFDdkosT0FBTzRILE1BQUEsQ0FBT29iLE9BQUEsQ0FBUWlDLFNBQUEsRUFBVzVjLEtBQUEsRUFBT3VaLFlBQUEsRUFBY0UsUUFBUTtFQUNoRSxXQUFXMVosTUFBQSxDQUFPeVEsSUFBQSxJQUFRalIsTUFBQSxDQUFPcVQsV0FBQSxLQUFnQixLQUFLN1MsTUFBQSxDQUFPNE8sT0FBQSxFQUFTO0lBQ3BFOVQscUJBQUEsQ0FBc0IsTUFBTTtNQUMxQjBFLE1BQUEsQ0FBT29iLE9BQUEsQ0FBUWdDLFNBQUEsRUFBVzNjLEtBQUEsRUFBT3VaLFlBQUEsRUFBY0UsUUFBUTtJQUN6RCxDQUFDO0lBQ0QsT0FBTztFQUNUO0VBQ0EsT0FBT2xhLE1BQUEsQ0FBT29iLE9BQUEsQ0FBUWdDLFNBQUEsRUFBVzNjLEtBQUEsRUFBT3VaLFlBQUEsRUFBY0UsUUFBUTtBQUNoRTtBQUdBLFNBQVNvRCxXQUFXN2MsS0FBQSxFQUFPdVosWUFBQSxFQUFjRSxRQUFBLEVBQVU7RUFDakQsSUFBSUYsWUFBQSxLQUFpQixRQUFRO0lBQzNCQSxZQUFBLEdBQWU7RUFDakI7RUFDQSxNQUFNaGEsTUFBQSxHQUFTO0VBQ2YsSUFBSUEsTUFBQSxDQUFPc0ksU0FBQSxFQUFXO0VBQ3RCLElBQUksT0FBTzdILEtBQUEsS0FBVSxhQUFhO0lBQ2hDQSxLQUFBLEdBQVFULE1BQUEsQ0FBT1EsTUFBQSxDQUFPQyxLQUFBO0VBQ3hCO0VBQ0EsT0FBT1QsTUFBQSxDQUFPb2IsT0FBQSxDQUFRcGIsTUFBQSxDQUFPcVQsV0FBQSxFQUFhNVMsS0FBQSxFQUFPdVosWUFBQSxFQUFjRSxRQUFRO0FBQ3pFO0FBR0EsU0FBU3FELGVBQWU5YyxLQUFBLEVBQU91WixZQUFBLEVBQWNFLFFBQUEsRUFBVXNELFNBQUEsRUFBVztFQUNoRSxJQUFJeEQsWUFBQSxLQUFpQixRQUFRO0lBQzNCQSxZQUFBLEdBQWU7RUFDakI7RUFDQSxJQUFJd0QsU0FBQSxLQUFjLFFBQVE7SUFDeEJBLFNBQUEsR0FBWTtFQUNkO0VBQ0EsTUFBTXhkLE1BQUEsR0FBUztFQUNmLElBQUlBLE1BQUEsQ0FBT3NJLFNBQUEsRUFBVztFQUN0QixJQUFJLE9BQU83SCxLQUFBLEtBQVUsYUFBYTtJQUNoQ0EsS0FBQSxHQUFRVCxNQUFBLENBQU9RLE1BQUEsQ0FBT0MsS0FBQTtFQUN4QjtFQUNBLElBQUl3TCxLQUFBLEdBQVFqTSxNQUFBLENBQU9xVCxXQUFBO0VBQ25CLE1BQU1tRixJQUFBLEdBQU9yWCxJQUFBLENBQUtFLEdBQUEsQ0FBSXJCLE1BQUEsQ0FBT1EsTUFBQSxDQUFPbVEsa0JBQUEsRUFBb0IxRSxLQUFLO0VBQzdELE1BQU1nRyxTQUFBLEdBQVl1RyxJQUFBLEdBQU9yWCxJQUFBLENBQUtvUCxLQUFBLEVBQU90RSxLQUFBLEdBQVF1TSxJQUFBLElBQVF4WSxNQUFBLENBQU9RLE1BQUEsQ0FBT2tRLGNBQWM7RUFDakYsTUFBTXVELFVBQUEsR0FBWWpVLE1BQUEsQ0FBT3dOLFlBQUEsR0FBZXhOLE1BQUEsQ0FBT0ksU0FBQSxHQUFZLENBQUNKLE1BQUEsQ0FBT0ksU0FBQTtFQUNuRSxJQUFJNlQsVUFBQSxJQUFhalUsTUFBQSxDQUFPa08sUUFBQSxDQUFTK0QsU0FBQSxHQUFZO0lBRzNDLE1BQU13TCxXQUFBLEdBQWN6ZCxNQUFBLENBQU9rTyxRQUFBLENBQVMrRCxTQUFBO0lBQ3BDLE1BQU15TCxRQUFBLEdBQVcxZCxNQUFBLENBQU9rTyxRQUFBLENBQVMrRCxTQUFBLEdBQVk7SUFDN0MsSUFBSWdDLFVBQUEsR0FBWXdKLFdBQUEsSUFBZUMsUUFBQSxHQUFXRCxXQUFBLElBQWVELFNBQUEsRUFBVztNQUNsRXZSLEtBQUEsSUFBU2pNLE1BQUEsQ0FBT1EsTUFBQSxDQUFPa1EsY0FBQTtJQUN6QjtFQUNGLE9BQU87SUFHTCxNQUFNd00sUUFBQSxHQUFXbGQsTUFBQSxDQUFPa08sUUFBQSxDQUFTK0QsU0FBQSxHQUFZO0lBQzdDLE1BQU13TCxXQUFBLEdBQWN6ZCxNQUFBLENBQU9rTyxRQUFBLENBQVMrRCxTQUFBO0lBQ3BDLElBQUlnQyxVQUFBLEdBQVlpSixRQUFBLEtBQWFPLFdBQUEsR0FBY1AsUUFBQSxJQUFZTSxTQUFBLEVBQVc7TUFDaEV2UixLQUFBLElBQVNqTSxNQUFBLENBQU9RLE1BQUEsQ0FBT2tRLGNBQUE7SUFDekI7RUFDRjtFQUNBekUsS0FBQSxHQUFROUssSUFBQSxDQUFLQyxHQUFBLENBQUk2SyxLQUFBLEVBQU8sQ0FBQztFQUN6QkEsS0FBQSxHQUFROUssSUFBQSxDQUFLRSxHQUFBLENBQUk0SyxLQUFBLEVBQU9qTSxNQUFBLENBQU9tTyxVQUFBLENBQVcvVixNQUFBLEdBQVMsQ0FBQztFQUNwRCxPQUFPNEgsTUFBQSxDQUFPb2IsT0FBQSxDQUFRblAsS0FBQSxFQUFPeEwsS0FBQSxFQUFPdVosWUFBQSxFQUFjRSxRQUFRO0FBQzVEO0FBRUEsU0FBU2Ysb0JBQUEsRUFBc0I7RUFDN0IsTUFBTW5aLE1BQUEsR0FBUztFQUNmLElBQUlBLE1BQUEsQ0FBT3NJLFNBQUEsRUFBVztFQUN0QixNQUFNO0lBQ0o5SCxNQUFBO0lBQ0E4TTtFQUNGLElBQUl0TixNQUFBO0VBQ0osTUFBTTRQLGFBQUEsR0FBZ0JwUCxNQUFBLENBQU9vUCxhQUFBLEtBQWtCLFNBQVM1UCxNQUFBLENBQU91WCxvQkFBQSxDQUFxQixJQUFJL1csTUFBQSxDQUFPb1AsYUFBQTtFQUMvRixJQUFJK04sWUFBQSxHQUFlM2QsTUFBQSxDQUFPa1osWUFBQTtFQUMxQixJQUFJckIsU0FBQTtFQUNKLE1BQU1mLGFBQUEsR0FBZ0I5VyxNQUFBLENBQU93VCxTQUFBLEdBQVksaUJBQWlCLElBQUloVCxNQUFBLENBQU93TixVQUFBO0VBQ3JFLElBQUl4TixNQUFBLENBQU95USxJQUFBLEVBQU07SUFDZixJQUFJalIsTUFBQSxDQUFPbWEsU0FBQSxFQUFXO0lBQ3RCdEMsU0FBQSxHQUFZOUssUUFBQSxDQUFTL00sTUFBQSxDQUFPaVosWUFBQSxDQUFhTixZQUFBLENBQWEseUJBQXlCLEdBQUcsRUFBRTtJQUNwRixJQUFJblksTUFBQSxDQUFPMk8sY0FBQSxFQUFnQjtNQUN6QixJQUFJd08sWUFBQSxHQUFlM2QsTUFBQSxDQUFPNGQsWUFBQSxHQUFlaE8sYUFBQSxHQUFnQixLQUFLK04sWUFBQSxHQUFlM2QsTUFBQSxDQUFPK04sTUFBQSxDQUFPM1YsTUFBQSxHQUFTNEgsTUFBQSxDQUFPNGQsWUFBQSxHQUFlaE8sYUFBQSxHQUFnQixHQUFHO1FBQzNJNVAsTUFBQSxDQUFPc2MsT0FBQSxDQUFRO1FBQ2ZxQixZQUFBLEdBQWUzZCxNQUFBLENBQU82ZCxhQUFBLENBQWM5YixlQUFBLENBQWdCdUwsUUFBQSxFQUFVLEdBQUd3SixhQUFBLDZCQUEwQ2UsU0FBQSxJQUFhLEVBQUUsRUFBRTtRQUM1SHZiLFFBQUEsQ0FBUyxNQUFNO1VBQ2IwRCxNQUFBLENBQU9vYixPQUFBLENBQVF1QyxZQUFZO1FBQzdCLENBQUM7TUFDSCxPQUFPO1FBQ0wzZCxNQUFBLENBQU9vYixPQUFBLENBQVF1QyxZQUFZO01BQzdCO0lBQ0YsV0FBV0EsWUFBQSxHQUFlM2QsTUFBQSxDQUFPK04sTUFBQSxDQUFPM1YsTUFBQSxHQUFTd1gsYUFBQSxFQUFlO01BQzlENVAsTUFBQSxDQUFPc2MsT0FBQSxDQUFRO01BQ2ZxQixZQUFBLEdBQWUzZCxNQUFBLENBQU82ZCxhQUFBLENBQWM5YixlQUFBLENBQWdCdUwsUUFBQSxFQUFVLEdBQUd3SixhQUFBLDZCQUEwQ2UsU0FBQSxJQUFhLEVBQUUsRUFBRTtNQUM1SHZiLFFBQUEsQ0FBUyxNQUFNO1FBQ2IwRCxNQUFBLENBQU9vYixPQUFBLENBQVF1QyxZQUFZO01BQzdCLENBQUM7SUFDSCxPQUFPO01BQ0wzZCxNQUFBLENBQU9vYixPQUFBLENBQVF1QyxZQUFZO0lBQzdCO0VBQ0YsT0FBTztJQUNMM2QsTUFBQSxDQUFPb2IsT0FBQSxDQUFRdUMsWUFBWTtFQUM3QjtBQUNGO0FBRUEsSUFBSUcsS0FBQSxHQUFRO0VBQ1YxQyxPQUFBO0VBQ0FZLFdBQUE7RUFDQVEsU0FBQTtFQUNBTSxTQUFBO0VBQ0FRLFVBQUE7RUFDQUMsY0FBQTtFQUNBcEU7QUFDRjtBQUVBLFNBQVM0RSxXQUFXeEIsY0FBQSxFQUFnQjtFQUNsQyxNQUFNdmMsTUFBQSxHQUFTO0VBQ2YsTUFBTTtJQUNKUSxNQUFBO0lBQ0E4TTtFQUNGLElBQUl0TixNQUFBO0VBQ0osSUFBSSxDQUFDUSxNQUFBLENBQU95USxJQUFBLElBQVFqUixNQUFBLENBQU80TixPQUFBLElBQVc1TixNQUFBLENBQU9RLE1BQUEsQ0FBT29OLE9BQUEsQ0FBUUMsT0FBQSxFQUFTO0VBQ3JFLE1BQU0yQixVQUFBLEdBQWFBLENBQUEsS0FBTTtJQUN2QixNQUFNekIsTUFBQSxHQUFTaE0sZUFBQSxDQUFnQnVMLFFBQUEsRUFBVSxJQUFJOU0sTUFBQSxDQUFPd04sVUFBQSxnQkFBMEI7SUFDOUVELE1BQUEsQ0FBTzdWLE9BQUEsQ0FBUSxDQUFDd0UsRUFBQSxFQUFJdVAsS0FBQSxLQUFVO01BQzVCdlAsRUFBQSxDQUFHckQsWUFBQSxDQUFhLDJCQUEyQjRTLEtBQUs7SUFDbEQsQ0FBQztFQUNIO0VBQ0EsTUFBTW9ELFdBQUEsR0FBY3JQLE1BQUEsQ0FBT3NQLElBQUEsSUFBUTlPLE1BQUEsQ0FBTzhPLElBQUEsSUFBUTlPLE1BQUEsQ0FBTzhPLElBQUEsQ0FBS0MsSUFBQSxHQUFPO0VBQ3JFLE1BQU1tQixjQUFBLEdBQWlCbFEsTUFBQSxDQUFPa1EsY0FBQSxJQUFrQnJCLFdBQUEsR0FBYzdPLE1BQUEsQ0FBTzhPLElBQUEsQ0FBS0MsSUFBQSxHQUFPO0VBQ2pGLE1BQU15TyxlQUFBLEdBQWtCaGUsTUFBQSxDQUFPK04sTUFBQSxDQUFPM1YsTUFBQSxHQUFTc1ksY0FBQSxLQUFtQjtFQUNsRSxNQUFNdU4sY0FBQSxHQUFpQjVPLFdBQUEsSUFBZXJQLE1BQUEsQ0FBTytOLE1BQUEsQ0FBTzNWLE1BQUEsR0FBU29JLE1BQUEsQ0FBTzhPLElBQUEsQ0FBS0MsSUFBQSxLQUFTO0VBQ2xGLE1BQU0yTyxjQUFBLEdBQWlCQyxjQUFBLElBQWtCO0lBQ3ZDLFNBQVNwZixDQUFBLEdBQUksR0FBR0EsQ0FBQSxHQUFJb2YsY0FBQSxFQUFnQnBmLENBQUEsSUFBSyxHQUFHO01BQzFDLE1BQU04QyxPQUFBLEdBQVU3QixNQUFBLENBQU93VCxTQUFBLEdBQVl2YSxhQUFBLENBQWMsZ0JBQWdCLENBQUN1SCxNQUFBLENBQU80ZCxlQUFlLENBQUMsSUFBSW5sQixhQUFBLENBQWMsT0FBTyxDQUFDdUgsTUFBQSxDQUFPd04sVUFBQSxFQUFZeE4sTUFBQSxDQUFPNGQsZUFBZSxDQUFDO01BQzdKcGUsTUFBQSxDQUFPc04sUUFBQSxDQUFTK1EsTUFBQSxDQUFPeGMsT0FBTztJQUNoQztFQUNGO0VBQ0EsSUFBSW1jLGVBQUEsRUFBaUI7SUFDbkIsSUFBSXhkLE1BQUEsQ0FBTzhkLGtCQUFBLEVBQW9CO01BQzdCLE1BQU1DLFdBQUEsR0FBYzdOLGNBQUEsR0FBaUIxUSxNQUFBLENBQU8rTixNQUFBLENBQU8zVixNQUFBLEdBQVNzWSxjQUFBO01BQzVEd04sY0FBQSxDQUFlSyxXQUFXO01BQzFCdmUsTUFBQSxDQUFPd2UsWUFBQSxDQUFhO01BQ3BCeGUsTUFBQSxDQUFPa04sWUFBQSxDQUFhO0lBQ3RCLE9BQU87TUFDTC9LLFdBQUEsQ0FBWSxpTEFBaUw7SUFDL0w7SUFDQXFOLFVBQUEsQ0FBVztFQUNiLFdBQVd5TyxjQUFBLEVBQWdCO0lBQ3pCLElBQUl6ZCxNQUFBLENBQU84ZCxrQkFBQSxFQUFvQjtNQUM3QixNQUFNQyxXQUFBLEdBQWMvZCxNQUFBLENBQU84TyxJQUFBLENBQUtDLElBQUEsR0FBT3ZQLE1BQUEsQ0FBTytOLE1BQUEsQ0FBTzNWLE1BQUEsR0FBU29JLE1BQUEsQ0FBTzhPLElBQUEsQ0FBS0MsSUFBQTtNQUMxRTJPLGNBQUEsQ0FBZUssV0FBVztNQUMxQnZlLE1BQUEsQ0FBT3dlLFlBQUEsQ0FBYTtNQUNwQnhlLE1BQUEsQ0FBT2tOLFlBQUEsQ0FBYTtJQUN0QixPQUFPO01BQ0wvSyxXQUFBLENBQVksNEtBQTRLO0lBQzFMO0lBQ0FxTixVQUFBLENBQVc7RUFDYixPQUFPO0lBQ0xBLFVBQUEsQ0FBVztFQUNiO0VBQ0F4UCxNQUFBLENBQU9zYyxPQUFBLENBQVE7SUFDYkMsY0FBQTtJQUNBeEIsU0FBQSxFQUFXdmEsTUFBQSxDQUFPMk8sY0FBQSxHQUFpQixTQUFZO0VBQ2pELENBQUM7QUFDSDtBQUVBLFNBQVNtTixRQUFRM1csS0FBQSxFQUFPO0VBQ3RCLElBQUk7SUFDRjRXLGNBQUE7SUFDQW5CLE9BQUEsRUFBQXFELFFBQUEsR0FBVTtJQUNWMUQsU0FBQTtJQUNBdkIsWUFBQSxFQUFBa0YsYUFBQTtJQUNBaEcsZ0JBQUE7SUFDQWUsWUFBQTtJQUNBa0Y7RUFDRixJQUFJaFosS0FBQSxLQUFVLFNBQVMsQ0FBQyxJQUFJQSxLQUFBO0VBQzVCLE1BQU0zRixNQUFBLEdBQVM7RUFDZixJQUFJLENBQUNBLE1BQUEsQ0FBT1EsTUFBQSxDQUFPeVEsSUFBQSxFQUFNO0VBQ3pCalIsTUFBQSxDQUFPa0ksSUFBQSxDQUFLLGVBQWU7RUFDM0IsTUFBTTtJQUNKNkYsTUFBQTtJQUNBMk4sY0FBQTtJQUNBRCxjQUFBO0lBQ0FuTyxRQUFBO0lBQ0E5TTtFQUNGLElBQUlSLE1BQUE7RUFDSixNQUFNO0lBQ0ptUDtFQUNGLElBQUkzTyxNQUFBO0VBQ0pSLE1BQUEsQ0FBTzBiLGNBQUEsR0FBaUI7RUFDeEIxYixNQUFBLENBQU95YixjQUFBLEdBQWlCO0VBQ3hCLElBQUl6YixNQUFBLENBQU80TixPQUFBLElBQVdwTixNQUFBLENBQU9vTixPQUFBLENBQVFDLE9BQUEsRUFBUztJQUM1QyxJQUFJNFEsUUFBQSxFQUFTO01BQ1gsSUFBSSxDQUFDamUsTUFBQSxDQUFPMk8sY0FBQSxJQUFrQm5QLE1BQUEsQ0FBT2lTLFNBQUEsS0FBYyxHQUFHO1FBQ3BEalMsTUFBQSxDQUFPb2IsT0FBQSxDQUFRcGIsTUFBQSxDQUFPNE4sT0FBQSxDQUFRRyxNQUFBLENBQU8zVixNQUFBLEVBQVEsR0FBRyxPQUFPLElBQUk7TUFDN0QsV0FBV29JLE1BQUEsQ0FBTzJPLGNBQUEsSUFBa0JuUCxNQUFBLENBQU9pUyxTQUFBLEdBQVl6UixNQUFBLENBQU9vUCxhQUFBLEVBQWU7UUFDM0U1UCxNQUFBLENBQU9vYixPQUFBLENBQVFwYixNQUFBLENBQU80TixPQUFBLENBQVFHLE1BQUEsQ0FBTzNWLE1BQUEsR0FBUzRILE1BQUEsQ0FBT2lTLFNBQUEsRUFBVyxHQUFHLE9BQU8sSUFBSTtNQUNoRixXQUFXalMsTUFBQSxDQUFPaVMsU0FBQSxLQUFjalMsTUFBQSxDQUFPa08sUUFBQSxDQUFTOVYsTUFBQSxHQUFTLEdBQUc7UUFDMUQ0SCxNQUFBLENBQU9vYixPQUFBLENBQVFwYixNQUFBLENBQU80TixPQUFBLENBQVF3RCxZQUFBLEVBQWMsR0FBRyxPQUFPLElBQUk7TUFDNUQ7SUFDRjtJQUNBcFIsTUFBQSxDQUFPMGIsY0FBQSxHQUFpQkEsY0FBQTtJQUN4QjFiLE1BQUEsQ0FBT3liLGNBQUEsR0FBaUJBLGNBQUE7SUFDeEJ6YixNQUFBLENBQU9rSSxJQUFBLENBQUssU0FBUztJQUNyQjtFQUNGO0VBQ0EsSUFBSTBILGFBQUEsR0FBZ0JwUCxNQUFBLENBQU9vUCxhQUFBO0VBQzNCLElBQUlBLGFBQUEsS0FBa0IsUUFBUTtJQUM1QkEsYUFBQSxHQUFnQjVQLE1BQUEsQ0FBT3VYLG9CQUFBLENBQXFCO0VBQzlDLE9BQU87SUFDTDNILGFBQUEsR0FBZ0J6TyxJQUFBLENBQUtnUSxJQUFBLENBQUtuVCxVQUFBLENBQVd3QyxNQUFBLENBQU9vUCxhQUFBLEVBQWUsRUFBRSxDQUFDO0lBQzlELElBQUlULGNBQUEsSUFBa0JTLGFBQUEsR0FBZ0IsTUFBTSxHQUFHO01BQzdDQSxhQUFBLEdBQWdCQSxhQUFBLEdBQWdCO0lBQ2xDO0VBQ0Y7RUFDQSxNQUFNYyxjQUFBLEdBQWlCbFEsTUFBQSxDQUFPa2Msa0JBQUEsR0FBcUI5TSxhQUFBLEdBQWdCcFAsTUFBQSxDQUFPa1EsY0FBQTtFQUMxRSxJQUFJa04sWUFBQSxHQUFlbE4sY0FBQTtFQUNuQixJQUFJa04sWUFBQSxHQUFlbE4sY0FBQSxLQUFtQixHQUFHO0lBQ3ZDa04sWUFBQSxJQUFnQmxOLGNBQUEsR0FBaUJrTixZQUFBLEdBQWVsTixjQUFBO0VBQ2xEO0VBQ0FrTixZQUFBLElBQWdCcGQsTUFBQSxDQUFPb2Usb0JBQUE7RUFDdkI1ZSxNQUFBLENBQU80ZCxZQUFBLEdBQWVBLFlBQUE7RUFDdEIsTUFBTXZPLFdBQUEsR0FBY3JQLE1BQUEsQ0FBT3NQLElBQUEsSUFBUTlPLE1BQUEsQ0FBTzhPLElBQUEsSUFBUTlPLE1BQUEsQ0FBTzhPLElBQUEsQ0FBS0MsSUFBQSxHQUFPO0VBQ3JFLElBQUl4QixNQUFBLENBQU8zVixNQUFBLEdBQVN3WCxhQUFBLEdBQWdCZ08sWUFBQSxFQUFjO0lBQ2hEemIsV0FBQSxDQUFZLDJPQUEyTztFQUN6UCxXQUFXa04sV0FBQSxJQUFlN08sTUFBQSxDQUFPOE8sSUFBQSxDQUFLdVAsSUFBQSxLQUFTLE9BQU87SUFDcEQxYyxXQUFBLENBQVkseUVBQXlFO0VBQ3ZGO0VBQ0EsTUFBTTJjLG9CQUFBLEdBQXVCLEVBQUM7RUFDOUIsTUFBTUMsbUJBQUEsR0FBc0IsRUFBQztFQUM3QixJQUFJMUwsV0FBQSxHQUFjclQsTUFBQSxDQUFPcVQsV0FBQTtFQUN6QixJQUFJLE9BQU9xRixnQkFBQSxLQUFxQixhQUFhO0lBQzNDQSxnQkFBQSxHQUFtQjFZLE1BQUEsQ0FBTzZkLGFBQUEsQ0FBYzlQLE1BQUEsQ0FBTzlSLE1BQUEsQ0FBT1MsRUFBQSxJQUFNQSxFQUFBLENBQUcrRixTQUFBLENBQVVtUSxRQUFBLENBQVNwUyxNQUFBLENBQU9nVyxnQkFBZ0IsQ0FBQyxFQUFFLEVBQUU7RUFDaEgsT0FBTztJQUNMbkQsV0FBQSxHQUFjcUYsZ0JBQUE7RUFDaEI7RUFDQSxNQUFNc0csTUFBQSxHQUFTakUsU0FBQSxLQUFjLFVBQVUsQ0FBQ0EsU0FBQTtFQUN4QyxNQUFNa0UsTUFBQSxHQUFTbEUsU0FBQSxLQUFjLFVBQVUsQ0FBQ0EsU0FBQTtFQUN4QyxJQUFJbUUsZUFBQSxHQUFrQjtFQUN0QixJQUFJQyxjQUFBLEdBQWlCO0VBQ3JCLE1BQU0vQyxJQUFBLEdBQU8vTSxXQUFBLEdBQWNsTyxJQUFBLENBQUtnUSxJQUFBLENBQUtwRCxNQUFBLENBQU8zVixNQUFBLEdBQVNvSSxNQUFBLENBQU84TyxJQUFBLENBQUtDLElBQUksSUFBSXhCLE1BQUEsQ0FBTzNWLE1BQUE7RUFDaEYsTUFBTWduQixjQUFBLEdBQWlCL1AsV0FBQSxHQUFjdEIsTUFBQSxDQUFPMkssZ0JBQUEsRUFBa0JuQyxNQUFBLEdBQVNtQyxnQkFBQTtFQUN2RSxNQUFNMkcsdUJBQUEsR0FBMEJELGNBQUEsSUFBa0JqUSxjQUFBLElBQWtCLE9BQU91UCxhQUFBLEtBQWlCLGNBQWMsQ0FBQzlPLGFBQUEsR0FBZ0IsSUFBSSxNQUFNO0VBRXJJLElBQUl5UCx1QkFBQSxHQUEwQnpCLFlBQUEsRUFBYztJQUMxQ3NCLGVBQUEsR0FBa0IvZCxJQUFBLENBQUtDLEdBQUEsQ0FBSXdjLFlBQUEsR0FBZXlCLHVCQUFBLEVBQXlCM08sY0FBYztJQUNqRixTQUFTM1IsQ0FBQSxHQUFJLEdBQUdBLENBQUEsR0FBSTZlLFlBQUEsR0FBZXlCLHVCQUFBLEVBQXlCdGdCLENBQUEsSUFBSyxHQUFHO01BQ2xFLE1BQU1rTixLQUFBLEdBQVFsTixDQUFBLEdBQUlvQyxJQUFBLENBQUtvUCxLQUFBLENBQU14UixDQUFBLEdBQUlxZCxJQUFJLElBQUlBLElBQUE7TUFDekMsSUFBSS9NLFdBQUEsRUFBYTtRQUNmLE1BQU1pUSxpQkFBQSxHQUFvQmxELElBQUEsR0FBT25RLEtBQUEsR0FBUTtRQUN6QyxTQUFTc1QsRUFBQSxHQUFJeFIsTUFBQSxDQUFPM1YsTUFBQSxHQUFTLEdBQUdtbkIsRUFBQSxJQUFLLEdBQUdBLEVBQUEsSUFBSyxHQUFHO1VBQzlDLElBQUl4UixNQUFBLENBQU93UixFQUFBLEVBQUdoSixNQUFBLEtBQVcrSSxpQkFBQSxFQUFtQlIsb0JBQUEsQ0FBcUJqYixJQUFBLENBQUswYixFQUFDO1FBQ3pFO01BSUYsT0FBTztRQUNMVCxvQkFBQSxDQUFxQmpiLElBQUEsQ0FBS3VZLElBQUEsR0FBT25RLEtBQUEsR0FBUSxDQUFDO01BQzVDO0lBQ0Y7RUFDRixXQUFXb1QsdUJBQUEsR0FBMEJ6UCxhQUFBLEdBQWdCd00sSUFBQSxHQUFPd0IsWUFBQSxFQUFjO0lBQ3hFdUIsY0FBQSxHQUFpQmhlLElBQUEsQ0FBS0MsR0FBQSxDQUFJaWUsdUJBQUEsSUFBMkJqRCxJQUFBLEdBQU93QixZQUFBLEdBQWUsSUFBSWxOLGNBQWM7SUFDN0YsU0FBUzNSLENBQUEsR0FBSSxHQUFHQSxDQUFBLEdBQUlvZ0IsY0FBQSxFQUFnQnBnQixDQUFBLElBQUssR0FBRztNQUMxQyxNQUFNa04sS0FBQSxHQUFRbE4sQ0FBQSxHQUFJb0MsSUFBQSxDQUFLb1AsS0FBQSxDQUFNeFIsQ0FBQSxHQUFJcWQsSUFBSSxJQUFJQSxJQUFBO01BQ3pDLElBQUkvTSxXQUFBLEVBQWE7UUFDZnRCLE1BQUEsQ0FBTzdWLE9BQUEsQ0FBUSxDQUFDNFgsTUFBQSxFQUFPMEIsVUFBQSxLQUFlO1VBQ3BDLElBQUkxQixNQUFBLENBQU15RyxNQUFBLEtBQVd0SyxLQUFBLEVBQU84UyxtQkFBQSxDQUFvQmxiLElBQUEsQ0FBSzJOLFVBQVU7UUFDakUsQ0FBQztNQUNILE9BQU87UUFDTHVOLG1CQUFBLENBQW9CbGIsSUFBQSxDQUFLb0ksS0FBSztNQUNoQztJQUNGO0VBQ0Y7RUFDQWpNLE1BQUEsQ0FBT2dLLG1CQUFBLEdBQXNCO0VBQzdCMU8scUJBQUEsQ0FBc0IsTUFBTTtJQUMxQjBFLE1BQUEsQ0FBT2dLLG1CQUFBLEdBQXNCO0VBQy9CLENBQUM7RUFDRCxJQUFJaVYsTUFBQSxFQUFRO0lBQ1ZILG9CQUFBLENBQXFCNW1CLE9BQUEsQ0FBUStULEtBQUEsSUFBUztNQUNwQzhCLE1BQUEsQ0FBTzlCLEtBQUEsRUFBT3VULGlCQUFBLEdBQW9CO01BQ2xDbFMsUUFBQSxDQUFTbVMsT0FBQSxDQUFRMVIsTUFBQSxDQUFPOUIsS0FBQSxDQUFNO01BQzlCOEIsTUFBQSxDQUFPOUIsS0FBQSxFQUFPdVQsaUJBQUEsR0FBb0I7SUFDcEMsQ0FBQztFQUNIO0VBQ0EsSUFBSVIsTUFBQSxFQUFRO0lBQ1ZELG1CQUFBLENBQW9CN21CLE9BQUEsQ0FBUStULEtBQUEsSUFBUztNQUNuQzhCLE1BQUEsQ0FBTzlCLEtBQUEsRUFBT3VULGlCQUFBLEdBQW9CO01BQ2xDbFMsUUFBQSxDQUFTK1EsTUFBQSxDQUFPdFEsTUFBQSxDQUFPOUIsS0FBQSxDQUFNO01BQzdCOEIsTUFBQSxDQUFPOUIsS0FBQSxFQUFPdVQsaUJBQUEsR0FBb0I7SUFDcEMsQ0FBQztFQUNIO0VBQ0F4ZixNQUFBLENBQU93ZSxZQUFBLENBQWE7RUFDcEIsSUFBSWhlLE1BQUEsQ0FBT29QLGFBQUEsS0FBa0IsUUFBUTtJQUNuQzVQLE1BQUEsQ0FBT2tOLFlBQUEsQ0FBYTtFQUN0QixXQUFXbUMsV0FBQSxLQUFnQnlQLG9CQUFBLENBQXFCMW1CLE1BQUEsR0FBUyxLQUFLNm1CLE1BQUEsSUFBVUYsbUJBQUEsQ0FBb0IzbUIsTUFBQSxHQUFTLEtBQUs0bUIsTUFBQSxHQUFTO0lBQ2pIaGYsTUFBQSxDQUFPK04sTUFBQSxDQUFPN1YsT0FBQSxDQUFRLENBQUM0WCxNQUFBLEVBQU8wQixVQUFBLEtBQWU7TUFDM0N4UixNQUFBLENBQU9zUCxJQUFBLENBQUtTLFdBQUEsQ0FBWXlCLFVBQUEsRUFBWTFCLE1BQUEsRUFBTzlQLE1BQUEsQ0FBTytOLE1BQU07SUFDMUQsQ0FBQztFQUNIO0VBQ0EsSUFBSXZOLE1BQUEsQ0FBTytSLG1CQUFBLEVBQXFCO0lBQzlCdlMsTUFBQSxDQUFPd1Msa0JBQUEsQ0FBbUI7RUFDNUI7RUFDQSxJQUFJaU0sUUFBQSxFQUFTO0lBQ1gsSUFBSUssb0JBQUEsQ0FBcUIxbUIsTUFBQSxHQUFTLEtBQUs2bUIsTUFBQSxFQUFRO01BQzdDLElBQUksT0FBTzFDLGNBQUEsS0FBbUIsYUFBYTtRQUN6QyxNQUFNbUQscUJBQUEsR0FBd0IxZixNQUFBLENBQU9tTyxVQUFBLENBQVdrRixXQUFBO1FBQ2hELE1BQU1zTSxpQkFBQSxHQUFvQjNmLE1BQUEsQ0FBT21PLFVBQUEsQ0FBV2tGLFdBQUEsR0FBYzZMLGVBQUE7UUFDMUQsTUFBTVUsSUFBQSxHQUFPRCxpQkFBQSxHQUFvQkQscUJBQUE7UUFDakMsSUFBSWYsWUFBQSxFQUFjO1VBQ2hCM2UsTUFBQSxDQUFPd1osWUFBQSxDQUFheFosTUFBQSxDQUFPSSxTQUFBLEdBQVl3ZixJQUFJO1FBQzdDLE9BQU87VUFDTDVmLE1BQUEsQ0FBT29iLE9BQUEsQ0FBUS9ILFdBQUEsR0FBY2xTLElBQUEsQ0FBS2dRLElBQUEsQ0FBSytOLGVBQWUsR0FBRyxHQUFHLE9BQU8sSUFBSTtVQUN2RSxJQUFJUixhQUFBLEVBQWM7WUFDaEIxZSxNQUFBLENBQU82ZixlQUFBLENBQWdCQyxjQUFBLEdBQWlCOWYsTUFBQSxDQUFPNmYsZUFBQSxDQUFnQkMsY0FBQSxHQUFpQkYsSUFBQTtZQUNoRjVmLE1BQUEsQ0FBTzZmLGVBQUEsQ0FBZ0J0RyxnQkFBQSxHQUFtQnZaLE1BQUEsQ0FBTzZmLGVBQUEsQ0FBZ0J0RyxnQkFBQSxHQUFtQnFHLElBQUE7VUFDdEY7UUFDRjtNQUNGLE9BQU87UUFDTCxJQUFJbEIsYUFBQSxFQUFjO1VBQ2hCLE1BQU1xQixLQUFBLEdBQVExUSxXQUFBLEdBQWN5UCxvQkFBQSxDQUFxQjFtQixNQUFBLEdBQVNvSSxNQUFBLENBQU84TyxJQUFBLENBQUtDLElBQUEsR0FBT3VQLG9CQUFBLENBQXFCMW1CLE1BQUE7VUFDbEc0SCxNQUFBLENBQU9vYixPQUFBLENBQVFwYixNQUFBLENBQU9xVCxXQUFBLEdBQWMwTSxLQUFBLEVBQU8sR0FBRyxPQUFPLElBQUk7VUFDekQvZixNQUFBLENBQU82ZixlQUFBLENBQWdCdEcsZ0JBQUEsR0FBbUJ2WixNQUFBLENBQU9JLFNBQUE7UUFDbkQ7TUFDRjtJQUNGLFdBQVcyZSxtQkFBQSxDQUFvQjNtQixNQUFBLEdBQVMsS0FBSzRtQixNQUFBLEVBQVE7TUFDbkQsSUFBSSxPQUFPekMsY0FBQSxLQUFtQixhQUFhO1FBQ3pDLE1BQU1tRCxxQkFBQSxHQUF3QjFmLE1BQUEsQ0FBT21PLFVBQUEsQ0FBV2tGLFdBQUE7UUFDaEQsTUFBTXNNLGlCQUFBLEdBQW9CM2YsTUFBQSxDQUFPbU8sVUFBQSxDQUFXa0YsV0FBQSxHQUFjOEwsY0FBQTtRQUMxRCxNQUFNUyxJQUFBLEdBQU9ELGlCQUFBLEdBQW9CRCxxQkFBQTtRQUNqQyxJQUFJZixZQUFBLEVBQWM7VUFDaEIzZSxNQUFBLENBQU93WixZQUFBLENBQWF4WixNQUFBLENBQU9JLFNBQUEsR0FBWXdmLElBQUk7UUFDN0MsT0FBTztVQUNMNWYsTUFBQSxDQUFPb2IsT0FBQSxDQUFRL0gsV0FBQSxHQUFjOEwsY0FBQSxFQUFnQixHQUFHLE9BQU8sSUFBSTtVQUMzRCxJQUFJVCxhQUFBLEVBQWM7WUFDaEIxZSxNQUFBLENBQU82ZixlQUFBLENBQWdCQyxjQUFBLEdBQWlCOWYsTUFBQSxDQUFPNmYsZUFBQSxDQUFnQkMsY0FBQSxHQUFpQkYsSUFBQTtZQUNoRjVmLE1BQUEsQ0FBTzZmLGVBQUEsQ0FBZ0J0RyxnQkFBQSxHQUFtQnZaLE1BQUEsQ0FBTzZmLGVBQUEsQ0FBZ0J0RyxnQkFBQSxHQUFtQnFHLElBQUE7VUFDdEY7UUFDRjtNQUNGLE9BQU87UUFDTCxNQUFNRyxLQUFBLEdBQVExUSxXQUFBLEdBQWMwUCxtQkFBQSxDQUFvQjNtQixNQUFBLEdBQVNvSSxNQUFBLENBQU84TyxJQUFBLENBQUtDLElBQUEsR0FBT3dQLG1CQUFBLENBQW9CM21CLE1BQUE7UUFDaEc0SCxNQUFBLENBQU9vYixPQUFBLENBQVFwYixNQUFBLENBQU9xVCxXQUFBLEdBQWMwTSxLQUFBLEVBQU8sR0FBRyxPQUFPLElBQUk7TUFDM0Q7SUFDRjtFQUNGO0VBQ0EvZixNQUFBLENBQU8wYixjQUFBLEdBQWlCQSxjQUFBO0VBQ3hCMWIsTUFBQSxDQUFPeWIsY0FBQSxHQUFpQkEsY0FBQTtFQUN4QixJQUFJemIsTUFBQSxDQUFPZ2dCLFVBQUEsSUFBY2hnQixNQUFBLENBQU9nZ0IsVUFBQSxDQUFXQyxPQUFBLElBQVcsQ0FBQ3hHLFlBQUEsRUFBYztJQUNuRSxNQUFNeUcsVUFBQSxHQUFhO01BQ2pCM0QsY0FBQTtNQUNBeEIsU0FBQTtNQUNBdkIsWUFBQSxFQUFBa0YsYUFBQTtNQUNBaEcsZ0JBQUE7TUFDQWUsWUFBQSxFQUFjO0lBQ2hCO0lBQ0EsSUFBSTlXLEtBQUEsQ0FBTUMsT0FBQSxDQUFRNUMsTUFBQSxDQUFPZ2dCLFVBQUEsQ0FBV0MsT0FBTyxHQUFHO01BQzVDamdCLE1BQUEsQ0FBT2dnQixVQUFBLENBQVdDLE9BQUEsQ0FBUS9uQixPQUFBLENBQVFnRSxDQUFBLElBQUs7UUFDckMsSUFBSSxDQUFDQSxDQUFBLENBQUVvTSxTQUFBLElBQWFwTSxDQUFBLENBQUVzRSxNQUFBLENBQU95USxJQUFBLEVBQU0vVSxDQUFBLENBQUVvZ0IsT0FBQSxDQUFRO1VBQzNDLEdBQUc0RCxVQUFBO1VBQ0g5RSxPQUFBLEVBQVNsZixDQUFBLENBQUVzRSxNQUFBLENBQU9vUCxhQUFBLEtBQWtCcFAsTUFBQSxDQUFPb1AsYUFBQSxHQUFnQjZPLFFBQUEsR0FBVTtRQUN2RSxDQUFDO01BQ0gsQ0FBQztJQUNILFdBQVd6ZSxNQUFBLENBQU9nZ0IsVUFBQSxDQUFXQyxPQUFBLFlBQW1CamdCLE1BQUEsQ0FBT3BJLFdBQUEsSUFBZW9JLE1BQUEsQ0FBT2dnQixVQUFBLENBQVdDLE9BQUEsQ0FBUXpmLE1BQUEsQ0FBT3lRLElBQUEsRUFBTTtNQUMzR2pSLE1BQUEsQ0FBT2dnQixVQUFBLENBQVdDLE9BQUEsQ0FBUTNELE9BQUEsQ0FBUTtRQUNoQyxHQUFHNEQsVUFBQTtRQUNIOUUsT0FBQSxFQUFTcGIsTUFBQSxDQUFPZ2dCLFVBQUEsQ0FBV0MsT0FBQSxDQUFRemYsTUFBQSxDQUFPb1AsYUFBQSxLQUFrQnBQLE1BQUEsQ0FBT29QLGFBQUEsR0FBZ0I2TyxRQUFBLEdBQVU7TUFDL0YsQ0FBQztJQUNIO0VBQ0Y7RUFDQXplLE1BQUEsQ0FBT2tJLElBQUEsQ0FBSyxTQUFTO0FBQ3ZCO0FBRUEsU0FBU2lZLFlBQUEsRUFBYztFQUNyQixNQUFNbmdCLE1BQUEsR0FBUztFQUNmLE1BQU07SUFDSlEsTUFBQTtJQUNBOE07RUFDRixJQUFJdE4sTUFBQTtFQUNKLElBQUksQ0FBQ1EsTUFBQSxDQUFPeVEsSUFBQSxJQUFRalIsTUFBQSxDQUFPNE4sT0FBQSxJQUFXNU4sTUFBQSxDQUFPUSxNQUFBLENBQU9vTixPQUFBLENBQVFDLE9BQUEsRUFBUztFQUNyRTdOLE1BQUEsQ0FBT3dlLFlBQUEsQ0FBYTtFQUNwQixNQUFNNEIsY0FBQSxHQUFpQixFQUFDO0VBQ3hCcGdCLE1BQUEsQ0FBTytOLE1BQUEsQ0FBTzdWLE9BQUEsQ0FBUTJKLE9BQUEsSUFBVztJQUMvQixNQUFNb0ssS0FBQSxHQUFRLE9BQU9wSyxPQUFBLENBQVF3ZSxnQkFBQSxLQUFxQixjQUFjeGUsT0FBQSxDQUFROFcsWUFBQSxDQUFhLHlCQUF5QixJQUFJLElBQUk5VyxPQUFBLENBQVF3ZSxnQkFBQTtJQUM5SEQsY0FBQSxDQUFlblUsS0FBQSxJQUFTcEssT0FBQTtFQUMxQixDQUFDO0VBQ0Q3QixNQUFBLENBQU8rTixNQUFBLENBQU83VixPQUFBLENBQVEySixPQUFBLElBQVc7SUFDL0JBLE9BQUEsQ0FBUXNWLGVBQUEsQ0FBZ0IseUJBQXlCO0VBQ25ELENBQUM7RUFDRGlKLGNBQUEsQ0FBZWxvQixPQUFBLENBQVEySixPQUFBLElBQVc7SUFDaEN5TCxRQUFBLENBQVMrUSxNQUFBLENBQU94YyxPQUFPO0VBQ3pCLENBQUM7RUFDRDdCLE1BQUEsQ0FBT3dlLFlBQUEsQ0FBYTtFQUNwQnhlLE1BQUEsQ0FBT29iLE9BQUEsQ0FBUXBiLE1BQUEsQ0FBTzZYLFNBQUEsRUFBVyxDQUFDO0FBQ3BDO0FBRUEsSUFBSTVHLElBQUEsR0FBTztFQUNUOE0sVUFBQTtFQUNBekIsT0FBQTtFQUNBNkQ7QUFDRjtBQUVBLFNBQVNHLGNBQWNDLE1BQUEsRUFBUTtFQUM3QixNQUFNdmdCLE1BQUEsR0FBUztFQUNmLElBQUksQ0FBQ0EsTUFBQSxDQUFPUSxNQUFBLENBQU9nZ0IsYUFBQSxJQUFpQnhnQixNQUFBLENBQU9RLE1BQUEsQ0FBTzZSLGFBQUEsSUFBaUJyUyxNQUFBLENBQU95Z0IsUUFBQSxJQUFZemdCLE1BQUEsQ0FBT1EsTUFBQSxDQUFPNE8sT0FBQSxFQUFTO0VBQzdHLE1BQU0xUyxFQUFBLEdBQUtzRCxNQUFBLENBQU9RLE1BQUEsQ0FBT2tnQixpQkFBQSxLQUFzQixjQUFjMWdCLE1BQUEsQ0FBT3RELEVBQUEsR0FBS3NELE1BQUEsQ0FBT1UsU0FBQTtFQUNoRixJQUFJVixNQUFBLENBQU93VCxTQUFBLEVBQVc7SUFDcEJ4VCxNQUFBLENBQU9nSyxtQkFBQSxHQUFzQjtFQUMvQjtFQUNBdE4sRUFBQSxDQUFHdEQsS0FBQSxDQUFNdW5CLE1BQUEsR0FBUztFQUNsQmprQixFQUFBLENBQUd0RCxLQUFBLENBQU11bkIsTUFBQSxHQUFTSixNQUFBLEdBQVMsYUFBYTtFQUN4QyxJQUFJdmdCLE1BQUEsQ0FBT3dULFNBQUEsRUFBVztJQUNwQmxZLHFCQUFBLENBQXNCLE1BQU07TUFDMUIwRSxNQUFBLENBQU9nSyxtQkFBQSxHQUFzQjtJQUMvQixDQUFDO0VBQ0g7QUFDRjtBQUVBLFNBQVM0VyxnQkFBQSxFQUFrQjtFQUN6QixNQUFNNWdCLE1BQUEsR0FBUztFQUNmLElBQUlBLE1BQUEsQ0FBT1EsTUFBQSxDQUFPNlIsYUFBQSxJQUFpQnJTLE1BQUEsQ0FBT3lnQixRQUFBLElBQVl6Z0IsTUFBQSxDQUFPUSxNQUFBLENBQU80TyxPQUFBLEVBQVM7SUFDM0U7RUFDRjtFQUNBLElBQUlwUCxNQUFBLENBQU93VCxTQUFBLEVBQVc7SUFDcEJ4VCxNQUFBLENBQU9nSyxtQkFBQSxHQUFzQjtFQUMvQjtFQUNBaEssTUFBQSxDQUFPQSxNQUFBLENBQU9RLE1BQUEsQ0FBT2tnQixpQkFBQSxLQUFzQixjQUFjLE9BQU8sYUFBYXRuQixLQUFBLENBQU11bkIsTUFBQSxHQUFTO0VBQzVGLElBQUkzZ0IsTUFBQSxDQUFPd1QsU0FBQSxFQUFXO0lBQ3BCbFkscUJBQUEsQ0FBc0IsTUFBTTtNQUMxQjBFLE1BQUEsQ0FBT2dLLG1CQUFBLEdBQXNCO0lBQy9CLENBQUM7RUFDSDtBQUNGO0FBRUEsSUFBSTZXLFVBQUEsR0FBYTtFQUNmUCxhQUFBO0VBQ0FNO0FBQ0Y7QUFHQSxTQUFTRSxlQUFlN2UsUUFBQSxFQUFVOGUsSUFBQSxFQUFNO0VBQ3RDLElBQUlBLElBQUEsS0FBUyxRQUFRO0lBQ25CQSxJQUFBLEdBQU87RUFDVDtFQUNBLFNBQVNDLGNBQWN0a0IsRUFBQSxFQUFJO0lBQ3pCLElBQUksQ0FBQ0EsRUFBQSxJQUFNQSxFQUFBLEtBQU94QyxXQUFBLENBQVksS0FBS3dDLEVBQUEsS0FBT2hCLFNBQUEsQ0FBVSxHQUFHLE9BQU87SUFDOUQsSUFBSWdCLEVBQUEsQ0FBR3VrQixZQUFBLEVBQWN2a0IsRUFBQSxHQUFLQSxFQUFBLENBQUd1a0IsWUFBQTtJQUM3QixNQUFNQyxLQUFBLEdBQVF4a0IsRUFBQSxDQUFHcWEsT0FBQSxDQUFROVUsUUFBUTtJQUNqQyxJQUFJLENBQUNpZixLQUFBLElBQVMsQ0FBQ3hrQixFQUFBLENBQUd5a0IsV0FBQSxFQUFhO01BQzdCLE9BQU87SUFDVDtJQUNBLE9BQU9ELEtBQUEsSUFBU0YsYUFBQSxDQUFjdGtCLEVBQUEsQ0FBR3lrQixXQUFBLENBQVksRUFBRXhuQixJQUFJO0VBQ3JEO0VBQ0EsT0FBT3FuQixhQUFBLENBQWNELElBQUk7QUFDM0I7QUFDQSxTQUFTSyxpQkFBaUJwaEIsTUFBQSxFQUFRcUwsS0FBQSxFQUFPZ1csTUFBQSxFQUFRO0VBQy9DLE1BQU0xa0IsT0FBQSxHQUFTakIsU0FBQSxDQUFVO0VBQ3pCLE1BQU07SUFDSjhFO0VBQ0YsSUFBSVIsTUFBQTtFQUNKLE1BQU1zaEIsa0JBQUEsR0FBcUI5Z0IsTUFBQSxDQUFPOGdCLGtCQUFBO0VBQ2xDLE1BQU1DLGtCQUFBLEdBQXFCL2dCLE1BQUEsQ0FBTytnQixrQkFBQTtFQUNsQyxJQUFJRCxrQkFBQSxLQUF1QkQsTUFBQSxJQUFVRSxrQkFBQSxJQUFzQkYsTUFBQSxJQUFVMWtCLE9BQUEsQ0FBTzZrQixVQUFBLEdBQWFELGtCQUFBLEdBQXFCO0lBQzVHLElBQUlELGtCQUFBLEtBQXVCLFdBQVc7TUFDcENqVyxLQUFBLENBQU1vVyxjQUFBLENBQWU7TUFDckIsT0FBTztJQUNUO0lBQ0EsT0FBTztFQUNUO0VBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBU0MsYUFBYXJXLEtBQUEsRUFBTztFQUMzQixNQUFNckwsTUFBQSxHQUFTO0VBQ2YsTUFBTThDLFNBQUEsR0FBVzVJLFdBQUEsQ0FBWTtFQUM3QixJQUFJbUMsQ0FBQSxHQUFJZ1AsS0FBQTtFQUNSLElBQUloUCxDQUFBLENBQUVzbEIsYUFBQSxFQUFldGxCLENBQUEsR0FBSUEsQ0FBQSxDQUFFc2xCLGFBQUE7RUFDM0IsTUFBTXhWLElBQUEsR0FBT25NLE1BQUEsQ0FBTzZmLGVBQUE7RUFDcEIsSUFBSXhqQixDQUFBLENBQUV1bEIsSUFBQSxLQUFTLGVBQWU7SUFDNUIsSUFBSXpWLElBQUEsQ0FBSzBWLFNBQUEsS0FBYyxRQUFRMVYsSUFBQSxDQUFLMFYsU0FBQSxLQUFjeGxCLENBQUEsQ0FBRXdsQixTQUFBLEVBQVc7TUFDN0Q7SUFDRjtJQUNBMVYsSUFBQSxDQUFLMFYsU0FBQSxHQUFZeGxCLENBQUEsQ0FBRXdsQixTQUFBO0VBQ3JCLFdBQVd4bEIsQ0FBQSxDQUFFdWxCLElBQUEsS0FBUyxnQkFBZ0J2bEIsQ0FBQSxDQUFFeWxCLGFBQUEsQ0FBYzFwQixNQUFBLEtBQVcsR0FBRztJQUNsRStULElBQUEsQ0FBSzRWLE9BQUEsR0FBVTFsQixDQUFBLENBQUV5bEIsYUFBQSxDQUFjLEdBQUdFLFVBQUE7RUFDcEM7RUFDQSxJQUFJM2xCLENBQUEsQ0FBRXVsQixJQUFBLEtBQVMsY0FBYztJQUUzQlIsZ0JBQUEsQ0FBaUJwaEIsTUFBQSxFQUFRM0QsQ0FBQSxFQUFHQSxDQUFBLENBQUV5bEIsYUFBQSxDQUFjLEdBQUdHLEtBQUs7SUFDcEQ7RUFDRjtFQUNBLE1BQU07SUFDSnpoQixNQUFBO0lBQ0EwaEIsT0FBQTtJQUNBclU7RUFDRixJQUFJN04sTUFBQTtFQUNKLElBQUksQ0FBQzZOLE9BQUEsRUFBUztFQUNkLElBQUksQ0FBQ3JOLE1BQUEsQ0FBT2dnQixhQUFBLElBQWlCbmtCLENBQUEsQ0FBRThsQixXQUFBLEtBQWdCLFNBQVM7RUFDeEQsSUFBSW5pQixNQUFBLENBQU9tYSxTQUFBLElBQWEzWixNQUFBLENBQU80Wiw4QkFBQSxFQUFnQztJQUM3RDtFQUNGO0VBQ0EsSUFBSSxDQUFDcGEsTUFBQSxDQUFPbWEsU0FBQSxJQUFhM1osTUFBQSxDQUFPNE8sT0FBQSxJQUFXNU8sTUFBQSxDQUFPeVEsSUFBQSxFQUFNO0lBQ3REalIsTUFBQSxDQUFPc2MsT0FBQSxDQUFRO0VBQ2pCO0VBQ0EsSUFBSThGLFFBQUEsR0FBVy9sQixDQUFBLENBQUV0RSxNQUFBO0VBQ2pCLElBQUl5SSxNQUFBLENBQU9rZ0IsaUJBQUEsS0FBc0IsV0FBVztJQUMxQyxJQUFJLENBQUMxZ0IsTUFBQSxDQUFPVSxTQUFBLENBQVVrUyxRQUFBLENBQVN3UCxRQUFRLEdBQUc7RUFDNUM7RUFDQSxJQUFJLFdBQVcvbEIsQ0FBQSxJQUFLQSxDQUFBLENBQUVnbUIsS0FBQSxLQUFVLEdBQUc7RUFDbkMsSUFBSSxZQUFZaG1CLENBQUEsSUFBS0EsQ0FBQSxDQUFFaW1CLE1BQUEsR0FBUyxHQUFHO0VBQ25DLElBQUluVyxJQUFBLENBQUtvVyxTQUFBLElBQWFwVyxJQUFBLENBQUtxVyxPQUFBLEVBQVM7RUFHcEMsTUFBTUMsb0JBQUEsR0FBdUIsQ0FBQyxDQUFDamlCLE1BQUEsQ0FBT2tpQixjQUFBLElBQWtCbGlCLE1BQUEsQ0FBT2tpQixjQUFBLEtBQW1CO0VBRWxGLE1BQU1DLFNBQUEsR0FBWXRtQixDQUFBLENBQUV1bUIsWUFBQSxHQUFldm1CLENBQUEsQ0FBRXVtQixZQUFBLENBQWEsSUFBSXZtQixDQUFBLENBQUV5YyxJQUFBO0VBQ3hELElBQUkySixvQkFBQSxJQUF3QnBtQixDQUFBLENBQUV0RSxNQUFBLElBQVVzRSxDQUFBLENBQUV0RSxNQUFBLENBQU8rSixVQUFBLElBQWM2Z0IsU0FBQSxFQUFXO0lBQ3hFUCxRQUFBLEdBQVdPLFNBQUEsQ0FBVTtFQUN2QjtFQUNBLE1BQU1FLGlCQUFBLEdBQW9CcmlCLE1BQUEsQ0FBT3FpQixpQkFBQSxHQUFvQnJpQixNQUFBLENBQU9xaUIsaUJBQUEsR0FBb0IsSUFBSXJpQixNQUFBLENBQU9raUIsY0FBQTtFQUMzRixNQUFNSSxjQUFBLEdBQWlCLENBQUMsRUFBRXptQixDQUFBLENBQUV0RSxNQUFBLElBQVVzRSxDQUFBLENBQUV0RSxNQUFBLENBQU8rSixVQUFBO0VBRy9DLElBQUl0QixNQUFBLENBQU91aUIsU0FBQSxLQUFjRCxjQUFBLEdBQWlCaEMsY0FBQSxDQUFlK0IsaUJBQUEsRUFBbUJULFFBQVEsSUFBSUEsUUFBQSxDQUFTckwsT0FBQSxDQUFROEwsaUJBQWlCLElBQUk7SUFDNUg3aUIsTUFBQSxDQUFPZ2pCLFVBQUEsR0FBYTtJQUNwQjtFQUNGO0VBQ0EsSUFBSXhpQixNQUFBLENBQU95aUIsWUFBQSxFQUFjO0lBQ3ZCLElBQUksQ0FBQ2IsUUFBQSxDQUFTckwsT0FBQSxDQUFRdlcsTUFBQSxDQUFPeWlCLFlBQVksR0FBRztFQUM5QztFQUNBZixPQUFBLENBQVFnQixRQUFBLEdBQVc3bUIsQ0FBQSxDQUFFNGxCLEtBQUE7RUFDckJDLE9BQUEsQ0FBUWlCLFFBQUEsR0FBVzltQixDQUFBLENBQUUrbUIsS0FBQTtFQUNyQixNQUFNL0IsTUFBQSxHQUFTYSxPQUFBLENBQVFnQixRQUFBO0VBQ3ZCLE1BQU1HLE1BQUEsR0FBU25CLE9BQUEsQ0FBUWlCLFFBQUE7RUFJdkIsSUFBSSxDQUFDL0IsZ0JBQUEsQ0FBaUJwaEIsTUFBQSxFQUFRM0QsQ0FBQSxFQUFHZ2xCLE1BQU0sR0FBRztJQUN4QztFQUNGO0VBQ0F4cEIsTUFBQSxDQUFPb1YsTUFBQSxDQUFPZCxJQUFBLEVBQU07SUFDbEJvVyxTQUFBLEVBQVc7SUFDWEMsT0FBQSxFQUFTO0lBQ1RjLG1CQUFBLEVBQXFCO0lBQ3JCQyxXQUFBLEVBQWE7SUFDYkMsV0FBQSxFQUFhO0VBQ2YsQ0FBQztFQUNEdEIsT0FBQSxDQUFRYixNQUFBLEdBQVNBLE1BQUE7RUFDakJhLE9BQUEsQ0FBUW1CLE1BQUEsR0FBU0EsTUFBQTtFQUNqQmxYLElBQUEsQ0FBS3NYLGNBQUEsR0FBaUJqbkIsR0FBQSxDQUFJO0VBQzFCd0QsTUFBQSxDQUFPZ2pCLFVBQUEsR0FBYTtFQUNwQmhqQixNQUFBLENBQU8wTSxVQUFBLENBQVc7RUFDbEIxTSxNQUFBLENBQU8wakIsY0FBQSxHQUFpQjtFQUN4QixJQUFJbGpCLE1BQUEsQ0FBT2dkLFNBQUEsR0FBWSxHQUFHclIsSUFBQSxDQUFLd1gsa0JBQUEsR0FBcUI7RUFDcEQsSUFBSWxDLGNBQUEsR0FBaUI7RUFDckIsSUFBSVcsUUFBQSxDQUFTbGdCLE9BQUEsQ0FBUWlLLElBQUEsQ0FBS3lYLGlCQUFpQixHQUFHO0lBQzVDbkMsY0FBQSxHQUFpQjtJQUNqQixJQUFJVyxRQUFBLENBQVN6cEIsUUFBQSxLQUFhLFVBQVU7TUFDbEN3VCxJQUFBLENBQUtvVyxTQUFBLEdBQVk7SUFDbkI7RUFDRjtFQUNBLElBQUl6ZixTQUFBLENBQVNySyxhQUFBLElBQWlCcUssU0FBQSxDQUFTckssYUFBQSxDQUFjeUosT0FBQSxDQUFRaUssSUFBQSxDQUFLeVgsaUJBQWlCLEtBQUs5Z0IsU0FBQSxDQUFTckssYUFBQSxLQUFrQjJwQixRQUFBLEVBQVU7SUFDM0h0ZixTQUFBLENBQVNySyxhQUFBLENBQWNDLElBQUEsQ0FBSztFQUM5QjtFQUNBLE1BQU1tckIsb0JBQUEsR0FBdUJwQyxjQUFBLElBQWtCemhCLE1BQUEsQ0FBTzhqQixjQUFBLElBQWtCdGpCLE1BQUEsQ0FBT3VqQix3QkFBQTtFQUMvRSxLQUFLdmpCLE1BQUEsQ0FBT3dqQiw2QkFBQSxJQUFpQ0gsb0JBQUEsS0FBeUIsQ0FBQ3pCLFFBQUEsQ0FBUzZCLGlCQUFBLEVBQW1CO0lBQ2pHNW5CLENBQUEsQ0FBRW9sQixjQUFBLENBQWU7RUFDbkI7RUFDQSxJQUFJamhCLE1BQUEsQ0FBTzBqQixRQUFBLElBQVkxakIsTUFBQSxDQUFPMGpCLFFBQUEsQ0FBU3JXLE9BQUEsSUFBVzdOLE1BQUEsQ0FBT2trQixRQUFBLElBQVlsa0IsTUFBQSxDQUFPbWEsU0FBQSxJQUFhLENBQUMzWixNQUFBLENBQU80TyxPQUFBLEVBQVM7SUFDeEdwUCxNQUFBLENBQU9ra0IsUUFBQSxDQUFTeEMsWUFBQSxDQUFhO0VBQy9CO0VBQ0ExaEIsTUFBQSxDQUFPa0ksSUFBQSxDQUFLLGNBQWM3TCxDQUFDO0FBQzdCO0FBRUEsU0FBUzhuQixZQUFZOVksS0FBQSxFQUFPO0VBQzFCLE1BQU12SSxTQUFBLEdBQVc1SSxXQUFBLENBQVk7RUFDN0IsTUFBTThGLE1BQUEsR0FBUztFQUNmLE1BQU1tTSxJQUFBLEdBQU9uTSxNQUFBLENBQU82ZixlQUFBO0VBQ3BCLE1BQU07SUFDSnJmLE1BQUE7SUFDQTBoQixPQUFBO0lBQ0ExVSxZQUFBLEVBQWNDLEdBQUE7SUFDZEk7RUFDRixJQUFJN04sTUFBQTtFQUNKLElBQUksQ0FBQzZOLE9BQUEsRUFBUztFQUNkLElBQUksQ0FBQ3JOLE1BQUEsQ0FBT2dnQixhQUFBLElBQWlCblYsS0FBQSxDQUFNOFcsV0FBQSxLQUFnQixTQUFTO0VBQzVELElBQUk5bEIsQ0FBQSxHQUFJZ1AsS0FBQTtFQUNSLElBQUloUCxDQUFBLENBQUVzbEIsYUFBQSxFQUFldGxCLENBQUEsR0FBSUEsQ0FBQSxDQUFFc2xCLGFBQUE7RUFDM0IsSUFBSXRsQixDQUFBLENBQUV1bEIsSUFBQSxLQUFTLGVBQWU7SUFDNUIsSUFBSXpWLElBQUEsQ0FBSzRWLE9BQUEsS0FBWSxNQUFNO0lBQzNCLE1BQU10bUIsRUFBQSxHQUFLWSxDQUFBLENBQUV3bEIsU0FBQTtJQUNiLElBQUlwbUIsRUFBQSxLQUFPMFEsSUFBQSxDQUFLMFYsU0FBQSxFQUFXO0VBQzdCO0VBQ0EsSUFBSXVDLFdBQUE7RUFDSixJQUFJL25CLENBQUEsQ0FBRXVsQixJQUFBLEtBQVMsYUFBYTtJQUMxQndDLFdBQUEsR0FBYyxDQUFDLEdBQUcvbkIsQ0FBQSxDQUFFZ29CLGNBQWMsRUFBRXBvQixNQUFBLENBQU8wZixDQUFBLElBQUtBLENBQUEsQ0FBRXFHLFVBQUEsS0FBZTdWLElBQUEsQ0FBSzRWLE9BQU8sRUFBRTtJQUMvRSxJQUFJLENBQUNxQyxXQUFBLElBQWVBLFdBQUEsQ0FBWXBDLFVBQUEsS0FBZTdWLElBQUEsQ0FBSzRWLE9BQUEsRUFBUztFQUMvRCxPQUFPO0lBQ0xxQyxXQUFBLEdBQWMvbkIsQ0FBQTtFQUNoQjtFQUNBLElBQUksQ0FBQzhQLElBQUEsQ0FBS29XLFNBQUEsRUFBVztJQUNuQixJQUFJcFcsSUFBQSxDQUFLcVgsV0FBQSxJQUFlclgsSUFBQSxDQUFLb1gsV0FBQSxFQUFhO01BQ3hDdmpCLE1BQUEsQ0FBT2tJLElBQUEsQ0FBSyxxQkFBcUI3TCxDQUFDO0lBQ3BDO0lBQ0E7RUFDRjtFQUNBLE1BQU00bEIsS0FBQSxHQUFRbUMsV0FBQSxDQUFZbkMsS0FBQTtFQUMxQixNQUFNbUIsS0FBQSxHQUFRZ0IsV0FBQSxDQUFZaEIsS0FBQTtFQUMxQixJQUFJL21CLENBQUEsQ0FBRWlvQix1QkFBQSxFQUF5QjtJQUM3QnBDLE9BQUEsQ0FBUWIsTUFBQSxHQUFTWSxLQUFBO0lBQ2pCQyxPQUFBLENBQVFtQixNQUFBLEdBQVNELEtBQUE7SUFDakI7RUFDRjtFQUNBLElBQUksQ0FBQ3BqQixNQUFBLENBQU84akIsY0FBQSxFQUFnQjtJQUMxQixJQUFJLENBQUN6bkIsQ0FBQSxDQUFFdEUsTUFBQSxDQUFPbUssT0FBQSxDQUFRaUssSUFBQSxDQUFLeVgsaUJBQWlCLEdBQUc7TUFDN0M1akIsTUFBQSxDQUFPZ2pCLFVBQUEsR0FBYTtJQUN0QjtJQUNBLElBQUk3VyxJQUFBLENBQUtvVyxTQUFBLEVBQVc7TUFDbEIxcUIsTUFBQSxDQUFPb1YsTUFBQSxDQUFPaVYsT0FBQSxFQUFTO1FBQ3JCYixNQUFBLEVBQVFZLEtBQUE7UUFDUm9CLE1BQUEsRUFBUUQsS0FBQTtRQUNSRixRQUFBLEVBQVVqQixLQUFBO1FBQ1ZrQixRQUFBLEVBQVVDO01BQ1osQ0FBQztNQUNEalgsSUFBQSxDQUFLc1gsY0FBQSxHQUFpQmpuQixHQUFBLENBQUk7SUFDNUI7SUFDQTtFQUNGO0VBQ0EsSUFBSWdFLE1BQUEsQ0FBTytqQixtQkFBQSxJQUF1QixDQUFDL2pCLE1BQUEsQ0FBT3lRLElBQUEsRUFBTTtJQUM5QyxJQUFJalIsTUFBQSxDQUFPOE0sVUFBQSxDQUFXLEdBQUc7TUFFdkIsSUFBSXNXLEtBQUEsR0FBUWxCLE9BQUEsQ0FBUW1CLE1BQUEsSUFBVXJqQixNQUFBLENBQU9JLFNBQUEsSUFBYUosTUFBQSxDQUFPa1YsWUFBQSxDQUFhLEtBQUtrTyxLQUFBLEdBQVFsQixPQUFBLENBQVFtQixNQUFBLElBQVVyakIsTUFBQSxDQUFPSSxTQUFBLElBQWFKLE1BQUEsQ0FBT3NVLFlBQUEsQ0FBYSxHQUFHO1FBQzlJbkksSUFBQSxDQUFLb1csU0FBQSxHQUFZO1FBQ2pCcFcsSUFBQSxDQUFLcVcsT0FBQSxHQUFVO1FBQ2Y7TUFDRjtJQUNGLFdBQVdQLEtBQUEsR0FBUUMsT0FBQSxDQUFRYixNQUFBLElBQVVyaEIsTUFBQSxDQUFPSSxTQUFBLElBQWFKLE1BQUEsQ0FBT2tWLFlBQUEsQ0FBYSxLQUFLK00sS0FBQSxHQUFRQyxPQUFBLENBQVFiLE1BQUEsSUFBVXJoQixNQUFBLENBQU9JLFNBQUEsSUFBYUosTUFBQSxDQUFPc1UsWUFBQSxDQUFhLEdBQUc7TUFDcko7SUFDRjtFQUNGO0VBQ0EsSUFBSXhSLFNBQUEsQ0FBU3JLLGFBQUEsRUFBZTtJQUMxQixJQUFJNEQsQ0FBQSxDQUFFdEUsTUFBQSxLQUFXK0ssU0FBQSxDQUFTckssYUFBQSxJQUFpQjRELENBQUEsQ0FBRXRFLE1BQUEsQ0FBT21LLE9BQUEsQ0FBUWlLLElBQUEsQ0FBS3lYLGlCQUFpQixHQUFHO01BQ25GelgsSUFBQSxDQUFLcVcsT0FBQSxHQUFVO01BQ2Z4aUIsTUFBQSxDQUFPZ2pCLFVBQUEsR0FBYTtNQUNwQjtJQUNGO0VBQ0Y7RUFDQSxJQUFJN1csSUFBQSxDQUFLbVgsbUJBQUEsRUFBcUI7SUFDNUJ0akIsTUFBQSxDQUFPa0ksSUFBQSxDQUFLLGFBQWE3TCxDQUFDO0VBQzVCO0VBQ0E2bEIsT0FBQSxDQUFRc0MsU0FBQSxHQUFZdEMsT0FBQSxDQUFRZ0IsUUFBQTtFQUM1QmhCLE9BQUEsQ0FBUXVDLFNBQUEsR0FBWXZDLE9BQUEsQ0FBUWlCLFFBQUE7RUFDNUJqQixPQUFBLENBQVFnQixRQUFBLEdBQVdqQixLQUFBO0VBQ25CQyxPQUFBLENBQVFpQixRQUFBLEdBQVdDLEtBQUE7RUFDbkIsTUFBTXNCLEtBQUEsR0FBUXhDLE9BQUEsQ0FBUWdCLFFBQUEsR0FBV2hCLE9BQUEsQ0FBUWIsTUFBQTtFQUN6QyxNQUFNc0QsS0FBQSxHQUFRekMsT0FBQSxDQUFRaUIsUUFBQSxHQUFXakIsT0FBQSxDQUFRbUIsTUFBQTtFQUN6QyxJQUFJcmpCLE1BQUEsQ0FBT1EsTUFBQSxDQUFPZ2QsU0FBQSxJQUFhcmMsSUFBQSxDQUFLeWpCLElBQUEsQ0FBS0YsS0FBQSxJQUFTLElBQUlDLEtBQUEsSUFBUyxDQUFDLElBQUkza0IsTUFBQSxDQUFPUSxNQUFBLENBQU9nZCxTQUFBLEVBQVc7RUFDN0YsSUFBSSxPQUFPclIsSUFBQSxDQUFLb1gsV0FBQSxLQUFnQixhQUFhO0lBQzNDLElBQUlzQixVQUFBO0lBQ0osSUFBSTdrQixNQUFBLENBQU82TSxZQUFBLENBQWEsS0FBS3FWLE9BQUEsQ0FBUWlCLFFBQUEsS0FBYWpCLE9BQUEsQ0FBUW1CLE1BQUEsSUFBVXJqQixNQUFBLENBQU84TSxVQUFBLENBQVcsS0FBS29WLE9BQUEsQ0FBUWdCLFFBQUEsS0FBYWhCLE9BQUEsQ0FBUWIsTUFBQSxFQUFRO01BQzlIbFYsSUFBQSxDQUFLb1gsV0FBQSxHQUFjO0lBQ3JCLE9BQU87TUFFTCxJQUFJbUIsS0FBQSxHQUFRQSxLQUFBLEdBQVFDLEtBQUEsR0FBUUEsS0FBQSxJQUFTLElBQUk7UUFDdkNFLFVBQUEsR0FBYTFqQixJQUFBLENBQUsyakIsS0FBQSxDQUFNM2pCLElBQUEsQ0FBS3NQLEdBQUEsQ0FBSWtVLEtBQUssR0FBR3hqQixJQUFBLENBQUtzUCxHQUFBLENBQUlpVSxLQUFLLENBQUMsSUFBSSxNQUFNdmpCLElBQUEsQ0FBS0ssRUFBQTtRQUN2RTJLLElBQUEsQ0FBS29YLFdBQUEsR0FBY3ZqQixNQUFBLENBQU82TSxZQUFBLENBQWEsSUFBSWdZLFVBQUEsR0FBYXJrQixNQUFBLENBQU9xa0IsVUFBQSxHQUFhLEtBQUtBLFVBQUEsR0FBYXJrQixNQUFBLENBQU9xa0IsVUFBQTtNQUN2RztJQUNGO0VBQ0Y7RUFDQSxJQUFJMVksSUFBQSxDQUFLb1gsV0FBQSxFQUFhO0lBQ3BCdmpCLE1BQUEsQ0FBT2tJLElBQUEsQ0FBSyxxQkFBcUI3TCxDQUFDO0VBQ3BDO0VBQ0EsSUFBSSxPQUFPOFAsSUFBQSxDQUFLcVgsV0FBQSxLQUFnQixhQUFhO0lBQzNDLElBQUl0QixPQUFBLENBQVFnQixRQUFBLEtBQWFoQixPQUFBLENBQVFiLE1BQUEsSUFBVWEsT0FBQSxDQUFRaUIsUUFBQSxLQUFhakIsT0FBQSxDQUFRbUIsTUFBQSxFQUFRO01BQzlFbFgsSUFBQSxDQUFLcVgsV0FBQSxHQUFjO0lBQ3JCO0VBQ0Y7RUFDQSxJQUFJclgsSUFBQSxDQUFLb1gsV0FBQSxJQUFlbG5CLENBQUEsQ0FBRXVsQixJQUFBLEtBQVMsZUFBZXpWLElBQUEsQ0FBSzRZLCtCQUFBLEVBQWlDO0lBQ3RGNVksSUFBQSxDQUFLb1csU0FBQSxHQUFZO0lBQ2pCO0VBQ0Y7RUFDQSxJQUFJLENBQUNwVyxJQUFBLENBQUtxWCxXQUFBLEVBQWE7SUFDckI7RUFDRjtFQUNBeGpCLE1BQUEsQ0FBT2dqQixVQUFBLEdBQWE7RUFDcEIsSUFBSSxDQUFDeGlCLE1BQUEsQ0FBTzRPLE9BQUEsSUFBVy9TLENBQUEsQ0FBRTJvQixVQUFBLEVBQVk7SUFDbkMzb0IsQ0FBQSxDQUFFb2xCLGNBQUEsQ0FBZTtFQUNuQjtFQUNBLElBQUlqaEIsTUFBQSxDQUFPeWtCLHdCQUFBLElBQTRCLENBQUN6a0IsTUFBQSxDQUFPMGtCLE1BQUEsRUFBUTtJQUNyRDdvQixDQUFBLENBQUU4b0IsZUFBQSxDQUFnQjtFQUNwQjtFQUNBLElBQUl2RixJQUFBLEdBQU81ZixNQUFBLENBQU82TSxZQUFBLENBQWEsSUFBSTZYLEtBQUEsR0FBUUMsS0FBQTtFQUMzQyxJQUFJUyxXQUFBLEdBQWNwbEIsTUFBQSxDQUFPNk0sWUFBQSxDQUFhLElBQUlxVixPQUFBLENBQVFnQixRQUFBLEdBQVdoQixPQUFBLENBQVFzQyxTQUFBLEdBQVl0QyxPQUFBLENBQVFpQixRQUFBLEdBQVdqQixPQUFBLENBQVF1QyxTQUFBO0VBQzVHLElBQUlqa0IsTUFBQSxDQUFPNmtCLGNBQUEsRUFBZ0I7SUFDekJ6RixJQUFBLEdBQU96ZSxJQUFBLENBQUtzUCxHQUFBLENBQUltUCxJQUFJLEtBQUtuUyxHQUFBLEdBQU0sSUFBSTtJQUNuQzJYLFdBQUEsR0FBY2prQixJQUFBLENBQUtzUCxHQUFBLENBQUkyVSxXQUFXLEtBQUszWCxHQUFBLEdBQU0sSUFBSTtFQUNuRDtFQUNBeVUsT0FBQSxDQUFRdEMsSUFBQSxHQUFPQSxJQUFBO0VBQ2ZBLElBQUEsSUFBUXBmLE1BQUEsQ0FBTzhrQixVQUFBO0VBQ2YsSUFBSTdYLEdBQUEsRUFBSztJQUNQbVMsSUFBQSxHQUFPLENBQUNBLElBQUE7SUFDUndGLFdBQUEsR0FBYyxDQUFDQSxXQUFBO0VBQ2pCO0VBQ0EsTUFBTUcsb0JBQUEsR0FBdUJ2bEIsTUFBQSxDQUFPd2xCLGdCQUFBO0VBQ3BDeGxCLE1BQUEsQ0FBTzBqQixjQUFBLEdBQWlCOUQsSUFBQSxHQUFPLElBQUksU0FBUztFQUM1QzVmLE1BQUEsQ0FBT3dsQixnQkFBQSxHQUFtQkosV0FBQSxHQUFjLElBQUksU0FBUztFQUNyRCxNQUFNSyxNQUFBLEdBQVN6bEIsTUFBQSxDQUFPUSxNQUFBLENBQU95USxJQUFBLElBQVEsQ0FBQ3pRLE1BQUEsQ0FBTzRPLE9BQUE7RUFDN0MsTUFBTXNXLFlBQUEsR0FBZTFsQixNQUFBLENBQU93bEIsZ0JBQUEsS0FBcUIsVUFBVXhsQixNQUFBLENBQU95YixjQUFBLElBQWtCemIsTUFBQSxDQUFPd2xCLGdCQUFBLEtBQXFCLFVBQVV4bEIsTUFBQSxDQUFPMGIsY0FBQTtFQUNqSSxJQUFJLENBQUN2UCxJQUFBLENBQUtxVyxPQUFBLEVBQVM7SUFDakIsSUFBSWlELE1BQUEsSUFBVUMsWUFBQSxFQUFjO01BQzFCMWxCLE1BQUEsQ0FBT3NjLE9BQUEsQ0FBUTtRQUNidkIsU0FBQSxFQUFXL2EsTUFBQSxDQUFPMGpCO01BQ3BCLENBQUM7SUFDSDtJQUNBdlgsSUFBQSxDQUFLMlQsY0FBQSxHQUFpQjlmLE1BQUEsQ0FBT25ELFlBQUEsQ0FBYTtJQUMxQ21ELE1BQUEsQ0FBT2lULGFBQUEsQ0FBYyxDQUFDO0lBQ3RCLElBQUlqVCxNQUFBLENBQU9tYSxTQUFBLEVBQVc7TUFDcEIsTUFBTXdMLEdBQUEsR0FBTSxJQUFJL3BCLE1BQUEsQ0FBT2YsV0FBQSxDQUFZLGlCQUFpQjtRQUNsRCtxQixPQUFBLEVBQVM7UUFDVFosVUFBQSxFQUFZO1FBQ1phLE1BQUEsRUFBUTtVQUNOQyxpQkFBQSxFQUFtQjtRQUNyQjtNQUNGLENBQUM7TUFDRDlsQixNQUFBLENBQU9VLFNBQUEsQ0FBVXFsQixhQUFBLENBQWNKLEdBQUc7SUFDcEM7SUFDQXhaLElBQUEsQ0FBSzZaLG1CQUFBLEdBQXNCO0lBRTNCLElBQUl4bEIsTUFBQSxDQUFPcWdCLFVBQUEsS0FBZTdnQixNQUFBLENBQU95YixjQUFBLEtBQW1CLFFBQVF6YixNQUFBLENBQU8wYixjQUFBLEtBQW1CLE9BQU87TUFDM0YxYixNQUFBLENBQU9zZ0IsYUFBQSxDQUFjLElBQUk7SUFDM0I7SUFDQXRnQixNQUFBLENBQU9rSSxJQUFBLENBQUssbUJBQW1CN0wsQ0FBQztFQUNsQztFQUNBLElBQUk0cEIsU0FBQTtFQUNKLElBQUlockIsSUFBQSxDQUFLLEVBQUVnRyxPQUFBLENBQVE7RUFDbkIsSUFBSWtMLElBQUEsQ0FBS3FXLE9BQUEsSUFBV3JXLElBQUEsQ0FBS3dYLGtCQUFBLElBQXNCNEIsb0JBQUEsS0FBeUJ2bEIsTUFBQSxDQUFPd2xCLGdCQUFBLElBQW9CQyxNQUFBLElBQVVDLFlBQUEsSUFBZ0J2a0IsSUFBQSxDQUFLc1AsR0FBQSxDQUFJbVAsSUFBSSxLQUFLLEdBQUc7SUFDaEovbkIsTUFBQSxDQUFPb1YsTUFBQSxDQUFPaVYsT0FBQSxFQUFTO01BQ3JCYixNQUFBLEVBQVFZLEtBQUE7TUFDUm9CLE1BQUEsRUFBUUQsS0FBQTtNQUNSRixRQUFBLEVBQVVqQixLQUFBO01BQ1ZrQixRQUFBLEVBQVVDLEtBQUE7TUFDVnRELGNBQUEsRUFBZ0IzVCxJQUFBLENBQUtvTjtJQUN2QixDQUFDO0lBQ0RwTixJQUFBLENBQUsrWixhQUFBLEdBQWdCO0lBQ3JCL1osSUFBQSxDQUFLMlQsY0FBQSxHQUFpQjNULElBQUEsQ0FBS29OLGdCQUFBO0lBQzNCO0VBQ0Y7RUFDQXZaLE1BQUEsQ0FBT2tJLElBQUEsQ0FBSyxjQUFjN0wsQ0FBQztFQUMzQjhQLElBQUEsQ0FBS3FXLE9BQUEsR0FBVTtFQUNmclcsSUFBQSxDQUFLb04sZ0JBQUEsR0FBbUJxRyxJQUFBLEdBQU96VCxJQUFBLENBQUsyVCxjQUFBO0VBQ3BDLElBQUlxRyxtQkFBQSxHQUFzQjtFQUMxQixJQUFJQyxlQUFBLEdBQWtCNWxCLE1BQUEsQ0FBTzRsQixlQUFBO0VBQzdCLElBQUk1bEIsTUFBQSxDQUFPK2pCLG1CQUFBLEVBQXFCO0lBQzlCNkIsZUFBQSxHQUFrQjtFQUNwQjtFQUNBLElBQUl4RyxJQUFBLEdBQU8sR0FBRztJQUNaLElBQUk2RixNQUFBLElBQVVDLFlBQUEsSUFBZ0IsQ0FBQ08sU0FBQSxJQUFhOVosSUFBQSxDQUFLd1gsa0JBQUEsSUFBc0J4WCxJQUFBLENBQUtvTixnQkFBQSxJQUFvQi9ZLE1BQUEsQ0FBTzJPLGNBQUEsR0FBaUJuUCxNQUFBLENBQU9zVSxZQUFBLENBQWEsSUFBSXRVLE1BQUEsQ0FBT29PLGVBQUEsQ0FBZ0JwTyxNQUFBLENBQU9xVCxXQUFBLEdBQWMsS0FBS3JULE1BQUEsQ0FBT3NVLFlBQUEsQ0FBYSxJQUFJO01BQ3ZOdFUsTUFBQSxDQUFPc2MsT0FBQSxDQUFRO1FBQ2J2QixTQUFBLEVBQVc7UUFDWHZCLFlBQUEsRUFBYztRQUNkZCxnQkFBQSxFQUFrQjtNQUNwQixDQUFDO0lBQ0g7SUFDQSxJQUFJdk0sSUFBQSxDQUFLb04sZ0JBQUEsR0FBbUJ2WixNQUFBLENBQU9zVSxZQUFBLENBQWEsR0FBRztNQUNqRDZSLG1CQUFBLEdBQXNCO01BQ3RCLElBQUkzbEIsTUFBQSxDQUFPNmxCLFVBQUEsRUFBWTtRQUNyQmxhLElBQUEsQ0FBS29OLGdCQUFBLEdBQW1CdlosTUFBQSxDQUFPc1UsWUFBQSxDQUFhLElBQUksS0FBSyxDQUFDdFUsTUFBQSxDQUFPc1UsWUFBQSxDQUFhLElBQUluSSxJQUFBLENBQUsyVCxjQUFBLEdBQWlCRixJQUFBLEtBQVN3RyxlQUFBO01BQy9HO0lBQ0Y7RUFDRixXQUFXeEcsSUFBQSxHQUFPLEdBQUc7SUFDbkIsSUFBSTZGLE1BQUEsSUFBVUMsWUFBQSxJQUFnQixDQUFDTyxTQUFBLElBQWE5WixJQUFBLENBQUt3WCxrQkFBQSxJQUFzQnhYLElBQUEsQ0FBS29OLGdCQUFBLElBQW9CL1ksTUFBQSxDQUFPMk8sY0FBQSxHQUFpQm5QLE1BQUEsQ0FBT2tWLFlBQUEsQ0FBYSxJQUFJbFYsTUFBQSxDQUFPb08sZUFBQSxDQUFnQnBPLE1BQUEsQ0FBT29PLGVBQUEsQ0FBZ0JoVyxNQUFBLEdBQVMsS0FBSzRILE1BQUEsQ0FBT2tWLFlBQUEsQ0FBYSxJQUFJO01BQ2xPbFYsTUFBQSxDQUFPc2MsT0FBQSxDQUFRO1FBQ2J2QixTQUFBLEVBQVc7UUFDWHZCLFlBQUEsRUFBYztRQUNkZCxnQkFBQSxFQUFrQjFZLE1BQUEsQ0FBTytOLE1BQUEsQ0FBTzNWLE1BQUEsSUFBVW9JLE1BQUEsQ0FBT29QLGFBQUEsS0FBa0IsU0FBUzVQLE1BQUEsQ0FBT3VYLG9CQUFBLENBQXFCLElBQUlwVyxJQUFBLENBQUtnUSxJQUFBLENBQUtuVCxVQUFBLENBQVd3QyxNQUFBLENBQU9vUCxhQUFBLEVBQWUsRUFBRSxDQUFDO01BQzVKLENBQUM7SUFDSDtJQUNBLElBQUl6RCxJQUFBLENBQUtvTixnQkFBQSxHQUFtQnZaLE1BQUEsQ0FBT2tWLFlBQUEsQ0FBYSxHQUFHO01BQ2pEaVIsbUJBQUEsR0FBc0I7TUFDdEIsSUFBSTNsQixNQUFBLENBQU82bEIsVUFBQSxFQUFZO1FBQ3JCbGEsSUFBQSxDQUFLb04sZ0JBQUEsR0FBbUJ2WixNQUFBLENBQU9rVixZQUFBLENBQWEsSUFBSSxLQUFLbFYsTUFBQSxDQUFPa1YsWUFBQSxDQUFhLElBQUkvSSxJQUFBLENBQUsyVCxjQUFBLEdBQWlCRixJQUFBLEtBQVN3RyxlQUFBO01BQzlHO0lBQ0Y7RUFDRjtFQUNBLElBQUlELG1CQUFBLEVBQXFCO0lBQ3ZCOXBCLENBQUEsQ0FBRWlvQix1QkFBQSxHQUEwQjtFQUM5QjtFQUdBLElBQUksQ0FBQ3RrQixNQUFBLENBQU95YixjQUFBLElBQWtCemIsTUFBQSxDQUFPMGpCLGNBQUEsS0FBbUIsVUFBVXZYLElBQUEsQ0FBS29OLGdCQUFBLEdBQW1CcE4sSUFBQSxDQUFLMlQsY0FBQSxFQUFnQjtJQUM3RzNULElBQUEsQ0FBS29OLGdCQUFBLEdBQW1CcE4sSUFBQSxDQUFLMlQsY0FBQTtFQUMvQjtFQUNBLElBQUksQ0FBQzlmLE1BQUEsQ0FBTzBiLGNBQUEsSUFBa0IxYixNQUFBLENBQU8wakIsY0FBQSxLQUFtQixVQUFVdlgsSUFBQSxDQUFLb04sZ0JBQUEsR0FBbUJwTixJQUFBLENBQUsyVCxjQUFBLEVBQWdCO0lBQzdHM1QsSUFBQSxDQUFLb04sZ0JBQUEsR0FBbUJwTixJQUFBLENBQUsyVCxjQUFBO0VBQy9CO0VBQ0EsSUFBSSxDQUFDOWYsTUFBQSxDQUFPMGIsY0FBQSxJQUFrQixDQUFDMWIsTUFBQSxDQUFPeWIsY0FBQSxFQUFnQjtJQUNwRHRQLElBQUEsQ0FBS29OLGdCQUFBLEdBQW1CcE4sSUFBQSxDQUFLMlQsY0FBQTtFQUMvQjtFQUdBLElBQUl0ZixNQUFBLENBQU9nZCxTQUFBLEdBQVksR0FBRztJQUN4QixJQUFJcmMsSUFBQSxDQUFLc1AsR0FBQSxDQUFJbVAsSUFBSSxJQUFJcGYsTUFBQSxDQUFPZ2QsU0FBQSxJQUFhclIsSUFBQSxDQUFLd1gsa0JBQUEsRUFBb0I7TUFDaEUsSUFBSSxDQUFDeFgsSUFBQSxDQUFLd1gsa0JBQUEsRUFBb0I7UUFDNUJ4WCxJQUFBLENBQUt3WCxrQkFBQSxHQUFxQjtRQUMxQnpCLE9BQUEsQ0FBUWIsTUFBQSxHQUFTYSxPQUFBLENBQVFnQixRQUFBO1FBQ3pCaEIsT0FBQSxDQUFRbUIsTUFBQSxHQUFTbkIsT0FBQSxDQUFRaUIsUUFBQTtRQUN6QmhYLElBQUEsQ0FBS29OLGdCQUFBLEdBQW1CcE4sSUFBQSxDQUFLMlQsY0FBQTtRQUM3Qm9DLE9BQUEsQ0FBUXRDLElBQUEsR0FBTzVmLE1BQUEsQ0FBTzZNLFlBQUEsQ0FBYSxJQUFJcVYsT0FBQSxDQUFRZ0IsUUFBQSxHQUFXaEIsT0FBQSxDQUFRYixNQUFBLEdBQVNhLE9BQUEsQ0FBUWlCLFFBQUEsR0FBV2pCLE9BQUEsQ0FBUW1CLE1BQUE7UUFDdEc7TUFDRjtJQUNGLE9BQU87TUFDTGxYLElBQUEsQ0FBS29OLGdCQUFBLEdBQW1CcE4sSUFBQSxDQUFLMlQsY0FBQTtNQUM3QjtJQUNGO0VBQ0Y7RUFDQSxJQUFJLENBQUN0ZixNQUFBLENBQU84bEIsWUFBQSxJQUFnQjlsQixNQUFBLENBQU80TyxPQUFBLEVBQVM7RUFHNUMsSUFBSTVPLE1BQUEsQ0FBTzBqQixRQUFBLElBQVkxakIsTUFBQSxDQUFPMGpCLFFBQUEsQ0FBU3JXLE9BQUEsSUFBVzdOLE1BQUEsQ0FBT2trQixRQUFBLElBQVkxakIsTUFBQSxDQUFPK1IsbUJBQUEsRUFBcUI7SUFDL0Z2UyxNQUFBLENBQU9nWSxpQkFBQSxDQUFrQjtJQUN6QmhZLE1BQUEsQ0FBT2tXLG1CQUFBLENBQW9CO0VBQzdCO0VBQ0EsSUFBSTFWLE1BQUEsQ0FBTzBqQixRQUFBLElBQVkxakIsTUFBQSxDQUFPMGpCLFFBQUEsQ0FBU3JXLE9BQUEsSUFBVzdOLE1BQUEsQ0FBT2trQixRQUFBLEVBQVU7SUFDakVsa0IsTUFBQSxDQUFPa2tCLFFBQUEsQ0FBU0MsV0FBQSxDQUFZO0VBQzlCO0VBRUFua0IsTUFBQSxDQUFPK1UsY0FBQSxDQUFlNUksSUFBQSxDQUFLb04sZ0JBQWdCO0VBRTNDdlosTUFBQSxDQUFPd1osWUFBQSxDQUFhck4sSUFBQSxDQUFLb04sZ0JBQWdCO0FBQzNDO0FBRUEsU0FBU2dOLFdBQVdsYixLQUFBLEVBQU87RUFDekIsTUFBTXJMLE1BQUEsR0FBUztFQUNmLE1BQU1tTSxJQUFBLEdBQU9uTSxNQUFBLENBQU82ZixlQUFBO0VBQ3BCLElBQUl4akIsQ0FBQSxHQUFJZ1AsS0FBQTtFQUNSLElBQUloUCxDQUFBLENBQUVzbEIsYUFBQSxFQUFldGxCLENBQUEsR0FBSUEsQ0FBQSxDQUFFc2xCLGFBQUE7RUFDM0IsSUFBSXlDLFdBQUE7RUFDSixNQUFNb0MsWUFBQSxHQUFlbnFCLENBQUEsQ0FBRXVsQixJQUFBLEtBQVMsY0FBY3ZsQixDQUFBLENBQUV1bEIsSUFBQSxLQUFTO0VBQ3pELElBQUksQ0FBQzRFLFlBQUEsRUFBYztJQUNqQixJQUFJcmEsSUFBQSxDQUFLNFYsT0FBQSxLQUFZLE1BQU07SUFDM0IsSUFBSTFsQixDQUFBLENBQUV3bEIsU0FBQSxLQUFjMVYsSUFBQSxDQUFLMFYsU0FBQSxFQUFXO0lBQ3BDdUMsV0FBQSxHQUFjL25CLENBQUE7RUFDaEIsT0FBTztJQUNMK25CLFdBQUEsR0FBYyxDQUFDLEdBQUcvbkIsQ0FBQSxDQUFFZ29CLGNBQWMsRUFBRXBvQixNQUFBLENBQU8wZixDQUFBLElBQUtBLENBQUEsQ0FBRXFHLFVBQUEsS0FBZTdWLElBQUEsQ0FBSzRWLE9BQU8sRUFBRTtJQUMvRSxJQUFJLENBQUNxQyxXQUFBLElBQWVBLFdBQUEsQ0FBWXBDLFVBQUEsS0FBZTdWLElBQUEsQ0FBSzRWLE9BQUEsRUFBUztFQUMvRDtFQUNBLElBQUksQ0FBQyxpQkFBaUIsY0FBYyxnQkFBZ0IsYUFBYSxFQUFFemEsUUFBQSxDQUFTakwsQ0FBQSxDQUFFdWxCLElBQUksR0FBRztJQUNuRixNQUFNNkUsT0FBQSxHQUFVLENBQUMsaUJBQWlCLGFBQWEsRUFBRW5mLFFBQUEsQ0FBU2pMLENBQUEsQ0FBRXVsQixJQUFJLE1BQU01aEIsTUFBQSxDQUFPZ0gsT0FBQSxDQUFRRyxRQUFBLElBQVluSCxNQUFBLENBQU9nSCxPQUFBLENBQVFXLFNBQUE7SUFDaEgsSUFBSSxDQUFDOGUsT0FBQSxFQUFTO01BQ1o7SUFDRjtFQUNGO0VBQ0F0YSxJQUFBLENBQUswVixTQUFBLEdBQVk7RUFDakIxVixJQUFBLENBQUs0VixPQUFBLEdBQVU7RUFDZixNQUFNO0lBQ0p2aEIsTUFBQTtJQUNBMGhCLE9BQUE7SUFDQTFVLFlBQUEsRUFBY0MsR0FBQTtJQUNkVSxVQUFBO0lBQ0FOO0VBQ0YsSUFBSTdOLE1BQUE7RUFDSixJQUFJLENBQUM2TixPQUFBLEVBQVM7RUFDZCxJQUFJLENBQUNyTixNQUFBLENBQU9nZ0IsYUFBQSxJQUFpQm5rQixDQUFBLENBQUU4bEIsV0FBQSxLQUFnQixTQUFTO0VBQ3hELElBQUloVyxJQUFBLENBQUttWCxtQkFBQSxFQUFxQjtJQUM1QnRqQixNQUFBLENBQU9rSSxJQUFBLENBQUssWUFBWTdMLENBQUM7RUFDM0I7RUFDQThQLElBQUEsQ0FBS21YLG1CQUFBLEdBQXNCO0VBQzNCLElBQUksQ0FBQ25YLElBQUEsQ0FBS29XLFNBQUEsRUFBVztJQUNuQixJQUFJcFcsSUFBQSxDQUFLcVcsT0FBQSxJQUFXaGlCLE1BQUEsQ0FBT3FnQixVQUFBLEVBQVk7TUFDckM3Z0IsTUFBQSxDQUFPc2dCLGFBQUEsQ0FBYyxLQUFLO0lBQzVCO0lBQ0FuVSxJQUFBLENBQUtxVyxPQUFBLEdBQVU7SUFDZnJXLElBQUEsQ0FBS3FYLFdBQUEsR0FBYztJQUNuQjtFQUNGO0VBR0EsSUFBSWhqQixNQUFBLENBQU9xZ0IsVUFBQSxJQUFjMVUsSUFBQSxDQUFLcVcsT0FBQSxJQUFXclcsSUFBQSxDQUFLb1csU0FBQSxLQUFjdmlCLE1BQUEsQ0FBT3liLGNBQUEsS0FBbUIsUUFBUXpiLE1BQUEsQ0FBTzBiLGNBQUEsS0FBbUIsT0FBTztJQUM3SDFiLE1BQUEsQ0FBT3NnQixhQUFBLENBQWMsS0FBSztFQUM1QjtFQUdBLE1BQU1vRyxZQUFBLEdBQWVscUIsR0FBQSxDQUFJO0VBQ3pCLE1BQU1tcUIsUUFBQSxHQUFXRCxZQUFBLEdBQWV2YSxJQUFBLENBQUtzWCxjQUFBO0VBR3JDLElBQUl6akIsTUFBQSxDQUFPZ2pCLFVBQUEsRUFBWTtJQUNyQixNQUFNNEQsUUFBQSxHQUFXdnFCLENBQUEsQ0FBRXljLElBQUEsSUFBUXpjLENBQUEsQ0FBRXVtQixZQUFBLElBQWdCdm1CLENBQUEsQ0FBRXVtQixZQUFBLENBQWE7SUFDNUQ1aUIsTUFBQSxDQUFPNlksa0JBQUEsQ0FBbUIrTixRQUFBLElBQVlBLFFBQUEsQ0FBUyxNQUFNdnFCLENBQUEsQ0FBRXRFLE1BQUEsRUFBUTZ1QixRQUFRO0lBQ3ZFNW1CLE1BQUEsQ0FBT2tJLElBQUEsQ0FBSyxhQUFhN0wsQ0FBQztJQUMxQixJQUFJc3FCLFFBQUEsR0FBVyxPQUFPRCxZQUFBLEdBQWV2YSxJQUFBLENBQUswYSxhQUFBLEdBQWdCLEtBQUs7TUFDN0Q3bUIsTUFBQSxDQUFPa0ksSUFBQSxDQUFLLHlCQUF5QjdMLENBQUM7SUFDeEM7RUFDRjtFQUNBOFAsSUFBQSxDQUFLMGEsYUFBQSxHQUFnQnJxQixHQUFBLENBQUk7RUFDekJGLFFBQUEsQ0FBUyxNQUFNO0lBQ2IsSUFBSSxDQUFDMEQsTUFBQSxDQUFPc0ksU0FBQSxFQUFXdEksTUFBQSxDQUFPZ2pCLFVBQUEsR0FBYTtFQUM3QyxDQUFDO0VBQ0QsSUFBSSxDQUFDN1csSUFBQSxDQUFLb1csU0FBQSxJQUFhLENBQUNwVyxJQUFBLENBQUtxVyxPQUFBLElBQVcsQ0FBQ3hpQixNQUFBLENBQU8wakIsY0FBQSxJQUFrQnhCLE9BQUEsQ0FBUXRDLElBQUEsS0FBUyxLQUFLLENBQUN6VCxJQUFBLENBQUsrWixhQUFBLElBQWlCL1osSUFBQSxDQUFLb04sZ0JBQUEsS0FBcUJwTixJQUFBLENBQUsyVCxjQUFBLElBQWtCLENBQUMzVCxJQUFBLENBQUsrWixhQUFBLEVBQWU7SUFDbkwvWixJQUFBLENBQUtvVyxTQUFBLEdBQVk7SUFDakJwVyxJQUFBLENBQUtxVyxPQUFBLEdBQVU7SUFDZnJXLElBQUEsQ0FBS3FYLFdBQUEsR0FBYztJQUNuQjtFQUNGO0VBQ0FyWCxJQUFBLENBQUtvVyxTQUFBLEdBQVk7RUFDakJwVyxJQUFBLENBQUtxVyxPQUFBLEdBQVU7RUFDZnJXLElBQUEsQ0FBS3FYLFdBQUEsR0FBYztFQUNuQixJQUFJc0QsVUFBQTtFQUNKLElBQUl0bUIsTUFBQSxDQUFPOGxCLFlBQUEsRUFBYztJQUN2QlEsVUFBQSxHQUFhclosR0FBQSxHQUFNek4sTUFBQSxDQUFPSSxTQUFBLEdBQVksQ0FBQ0osTUFBQSxDQUFPSSxTQUFBO0VBQ2hELE9BQU87SUFDTDBtQixVQUFBLEdBQWEsQ0FBQzNhLElBQUEsQ0FBS29OLGdCQUFBO0VBQ3JCO0VBQ0EsSUFBSS9ZLE1BQUEsQ0FBTzRPLE9BQUEsRUFBUztJQUNsQjtFQUNGO0VBQ0EsSUFBSTVPLE1BQUEsQ0FBTzBqQixRQUFBLElBQVkxakIsTUFBQSxDQUFPMGpCLFFBQUEsQ0FBU3JXLE9BQUEsRUFBUztJQUM5QzdOLE1BQUEsQ0FBT2trQixRQUFBLENBQVNxQyxVQUFBLENBQVc7TUFDekJPO0lBQ0YsQ0FBQztJQUNEO0VBQ0Y7RUFHQSxNQUFNQyxXQUFBLEdBQWNELFVBQUEsSUFBYyxDQUFDOW1CLE1BQUEsQ0FBT2tWLFlBQUEsQ0FBYSxLQUFLLENBQUNsVixNQUFBLENBQU9RLE1BQUEsQ0FBT3lRLElBQUE7RUFDM0UsSUFBSStWLFNBQUEsR0FBWTtFQUNoQixJQUFJMVYsU0FBQSxHQUFZdFIsTUFBQSxDQUFPb08sZUFBQSxDQUFnQjtFQUN2QyxTQUFTclAsQ0FBQSxHQUFJLEdBQUdBLENBQUEsR0FBSW9QLFVBQUEsQ0FBVy9WLE1BQUEsRUFBUTJHLENBQUEsSUFBS0EsQ0FBQSxHQUFJeUIsTUFBQSxDQUFPbVEsa0JBQUEsR0FBcUIsSUFBSW5RLE1BQUEsQ0FBT2tRLGNBQUEsRUFBZ0I7SUFDckcsTUFBTXVXLFVBQUEsR0FBWWxvQixDQUFBLEdBQUl5QixNQUFBLENBQU9tUSxrQkFBQSxHQUFxQixJQUFJLElBQUluUSxNQUFBLENBQU9rUSxjQUFBO0lBQ2pFLElBQUksT0FBT3ZDLFVBQUEsQ0FBV3BQLENBQUEsR0FBSWtvQixVQUFBLE1BQWUsYUFBYTtNQUNwRCxJQUFJRixXQUFBLElBQWVELFVBQUEsSUFBYzNZLFVBQUEsQ0FBV3BQLENBQUEsS0FBTStuQixVQUFBLEdBQWEzWSxVQUFBLENBQVdwUCxDQUFBLEdBQUlrb0IsVUFBQSxHQUFZO1FBQ3hGRCxTQUFBLEdBQVlqb0IsQ0FBQTtRQUNadVMsU0FBQSxHQUFZbkQsVUFBQSxDQUFXcFAsQ0FBQSxHQUFJa29CLFVBQUEsSUFBYTlZLFVBQUEsQ0FBV3BQLENBQUE7TUFDckQ7SUFDRixXQUFXZ29CLFdBQUEsSUFBZUQsVUFBQSxJQUFjM1ksVUFBQSxDQUFXcFAsQ0FBQSxHQUFJO01BQ3JEaW9CLFNBQUEsR0FBWWpvQixDQUFBO01BQ1p1UyxTQUFBLEdBQVluRCxVQUFBLENBQVdBLFVBQUEsQ0FBVy9WLE1BQUEsR0FBUyxLQUFLK1YsVUFBQSxDQUFXQSxVQUFBLENBQVcvVixNQUFBLEdBQVM7SUFDakY7RUFDRjtFQUNBLElBQUk4dUIsZ0JBQUEsR0FBbUI7RUFDdkIsSUFBSUMsZUFBQSxHQUFrQjtFQUN0QixJQUFJM21CLE1BQUEsQ0FBT29YLE1BQUEsRUFBUTtJQUNqQixJQUFJNVgsTUFBQSxDQUFPbVYsV0FBQSxFQUFhO01BQ3RCZ1MsZUFBQSxHQUFrQjNtQixNQUFBLENBQU9vTixPQUFBLElBQVdwTixNQUFBLENBQU9vTixPQUFBLENBQVFDLE9BQUEsSUFBVzdOLE1BQUEsQ0FBTzROLE9BQUEsR0FBVTVOLE1BQUEsQ0FBTzROLE9BQUEsQ0FBUUcsTUFBQSxDQUFPM1YsTUFBQSxHQUFTLElBQUk0SCxNQUFBLENBQU8rTixNQUFBLENBQU8zVixNQUFBLEdBQVM7SUFDM0ksV0FBVzRILE1BQUEsQ0FBT29WLEtBQUEsRUFBTztNQUN2QjhSLGdCQUFBLEdBQW1CO0lBQ3JCO0VBQ0Y7RUFFQSxNQUFNRSxLQUFBLElBQVNOLFVBQUEsR0FBYTNZLFVBQUEsQ0FBVzZZLFNBQUEsS0FBYzFWLFNBQUE7RUFDckQsTUFBTXFMLFNBQUEsR0FBWXFLLFNBQUEsR0FBWXhtQixNQUFBLENBQU9tUSxrQkFBQSxHQUFxQixJQUFJLElBQUluUSxNQUFBLENBQU9rUSxjQUFBO0VBQ3pFLElBQUlpVyxRQUFBLEdBQVdubUIsTUFBQSxDQUFPNm1CLFlBQUEsRUFBYztJQUVsQyxJQUFJLENBQUM3bUIsTUFBQSxDQUFPOG1CLFVBQUEsRUFBWTtNQUN0QnRuQixNQUFBLENBQU9vYixPQUFBLENBQVFwYixNQUFBLENBQU9xVCxXQUFXO01BQ2pDO0lBQ0Y7SUFDQSxJQUFJclQsTUFBQSxDQUFPMGpCLGNBQUEsS0FBbUIsUUFBUTtNQUNwQyxJQUFJMEQsS0FBQSxJQUFTNW1CLE1BQUEsQ0FBTyttQixlQUFBLEVBQWlCdm5CLE1BQUEsQ0FBT29iLE9BQUEsQ0FBUTVhLE1BQUEsQ0FBT29YLE1BQUEsSUFBVTVYLE1BQUEsQ0FBT29WLEtBQUEsR0FBUThSLGdCQUFBLEdBQW1CRixTQUFBLEdBQVlySyxTQUFTLE9BQU8zYyxNQUFBLENBQU9vYixPQUFBLENBQVE0TCxTQUFTO0lBQzdKO0lBQ0EsSUFBSWhuQixNQUFBLENBQU8wakIsY0FBQSxLQUFtQixRQUFRO01BQ3BDLElBQUkwRCxLQUFBLEdBQVEsSUFBSTVtQixNQUFBLENBQU8rbUIsZUFBQSxFQUFpQjtRQUN0Q3ZuQixNQUFBLENBQU9vYixPQUFBLENBQVE0TCxTQUFBLEdBQVlySyxTQUFTO01BQ3RDLFdBQVd3SyxlQUFBLEtBQW9CLFFBQVFDLEtBQUEsR0FBUSxLQUFLam1CLElBQUEsQ0FBS3NQLEdBQUEsQ0FBSTJXLEtBQUssSUFBSTVtQixNQUFBLENBQU8rbUIsZUFBQSxFQUFpQjtRQUM1RnZuQixNQUFBLENBQU9vYixPQUFBLENBQVErTCxlQUFlO01BQ2hDLE9BQU87UUFDTG5uQixNQUFBLENBQU9vYixPQUFBLENBQVE0TCxTQUFTO01BQzFCO0lBQ0Y7RUFDRixPQUFPO0lBRUwsSUFBSSxDQUFDeG1CLE1BQUEsQ0FBT2duQixXQUFBLEVBQWE7TUFDdkJ4bkIsTUFBQSxDQUFPb2IsT0FBQSxDQUFRcGIsTUFBQSxDQUFPcVQsV0FBVztNQUNqQztJQUNGO0lBQ0EsTUFBTW9VLGlCQUFBLEdBQW9Cem5CLE1BQUEsQ0FBTzBuQixVQUFBLEtBQWVyckIsQ0FBQSxDQUFFdEUsTUFBQSxLQUFXaUksTUFBQSxDQUFPMG5CLFVBQUEsQ0FBV0MsTUFBQSxJQUFVdHJCLENBQUEsQ0FBRXRFLE1BQUEsS0FBV2lJLE1BQUEsQ0FBTzBuQixVQUFBLENBQVdFLE1BQUE7SUFDeEgsSUFBSSxDQUFDSCxpQkFBQSxFQUFtQjtNQUN0QixJQUFJem5CLE1BQUEsQ0FBTzBqQixjQUFBLEtBQW1CLFFBQVE7UUFDcEMxakIsTUFBQSxDQUFPb2IsT0FBQSxDQUFROEwsZ0JBQUEsS0FBcUIsT0FBT0EsZ0JBQUEsR0FBbUJGLFNBQUEsR0FBWXJLLFNBQVM7TUFDckY7TUFDQSxJQUFJM2MsTUFBQSxDQUFPMGpCLGNBQUEsS0FBbUIsUUFBUTtRQUNwQzFqQixNQUFBLENBQU9vYixPQUFBLENBQVErTCxlQUFBLEtBQW9CLE9BQU9BLGVBQUEsR0FBa0JILFNBQVM7TUFDdkU7SUFDRixXQUFXM3FCLENBQUEsQ0FBRXRFLE1BQUEsS0FBV2lJLE1BQUEsQ0FBTzBuQixVQUFBLENBQVdDLE1BQUEsRUFBUTtNQUNoRDNuQixNQUFBLENBQU9vYixPQUFBLENBQVE0TCxTQUFBLEdBQVlySyxTQUFTO0lBQ3RDLE9BQU87TUFDTDNjLE1BQUEsQ0FBT29iLE9BQUEsQ0FBUTRMLFNBQVM7SUFDMUI7RUFDRjtBQUNGO0FBRUEsU0FBU2EsU0FBQSxFQUFXO0VBQ2xCLE1BQU03bkIsTUFBQSxHQUFTO0VBQ2YsTUFBTTtJQUNKUSxNQUFBO0lBQ0E5RDtFQUNGLElBQUlzRCxNQUFBO0VBQ0osSUFBSXRELEVBQUEsSUFBTUEsRUFBQSxDQUFHc0ksV0FBQSxLQUFnQixHQUFHO0VBR2hDLElBQUl4RSxNQUFBLENBQU9xUCxXQUFBLEVBQWE7SUFDdEI3UCxNQUFBLENBQU84bkIsYUFBQSxDQUFjO0VBQ3ZCO0VBR0EsTUFBTTtJQUNKck0sY0FBQTtJQUNBQyxjQUFBO0lBQ0F4TjtFQUNGLElBQUlsTyxNQUFBO0VBQ0osTUFBTTJOLFNBQUEsR0FBWTNOLE1BQUEsQ0FBTzROLE9BQUEsSUFBVzVOLE1BQUEsQ0FBT1EsTUFBQSxDQUFPb04sT0FBQSxDQUFRQyxPQUFBO0VBRzFEN04sTUFBQSxDQUFPeWIsY0FBQSxHQUFpQjtFQUN4QnpiLE1BQUEsQ0FBTzBiLGNBQUEsR0FBaUI7RUFDeEIxYixNQUFBLENBQU8wTSxVQUFBLENBQVc7RUFDbEIxTSxNQUFBLENBQU9rTixZQUFBLENBQWE7RUFDcEJsTixNQUFBLENBQU9rVyxtQkFBQSxDQUFvQjtFQUMzQixNQUFNNlIsYUFBQSxHQUFnQnBhLFNBQUEsSUFBYW5OLE1BQUEsQ0FBT3lRLElBQUE7RUFDMUMsS0FBS3pRLE1BQUEsQ0FBT29QLGFBQUEsS0FBa0IsVUFBVXBQLE1BQUEsQ0FBT29QLGFBQUEsR0FBZ0IsTUFBTTVQLE1BQUEsQ0FBT29WLEtBQUEsSUFBUyxDQUFDcFYsTUFBQSxDQUFPbVYsV0FBQSxJQUFlLENBQUNuVixNQUFBLENBQU9RLE1BQUEsQ0FBTzJPLGNBQUEsSUFBa0IsQ0FBQzRZLGFBQUEsRUFBZTtJQUMzSi9uQixNQUFBLENBQU9vYixPQUFBLENBQVFwYixNQUFBLENBQU8rTixNQUFBLENBQU8zVixNQUFBLEdBQVMsR0FBRyxHQUFHLE9BQU8sSUFBSTtFQUN6RCxPQUFPO0lBQ0wsSUFBSTRILE1BQUEsQ0FBT1EsTUFBQSxDQUFPeVEsSUFBQSxJQUFRLENBQUN0RCxTQUFBLEVBQVc7TUFDcEMzTixNQUFBLENBQU9nYyxXQUFBLENBQVloYyxNQUFBLENBQU82WCxTQUFBLEVBQVcsR0FBRyxPQUFPLElBQUk7SUFDckQsT0FBTztNQUNMN1gsTUFBQSxDQUFPb2IsT0FBQSxDQUFRcGIsTUFBQSxDQUFPcVQsV0FBQSxFQUFhLEdBQUcsT0FBTyxJQUFJO0lBQ25EO0VBQ0Y7RUFDQSxJQUFJclQsTUFBQSxDQUFPZ29CLFFBQUEsSUFBWWhvQixNQUFBLENBQU9nb0IsUUFBQSxDQUFTQyxPQUFBLElBQVdqb0IsTUFBQSxDQUFPZ29CLFFBQUEsQ0FBU0UsTUFBQSxFQUFRO0lBQ3hFOXNCLFlBQUEsQ0FBYTRFLE1BQUEsQ0FBT2dvQixRQUFBLENBQVNHLGFBQWE7SUFDMUNub0IsTUFBQSxDQUFPZ29CLFFBQUEsQ0FBU0csYUFBQSxHQUFnQmh0QixVQUFBLENBQVcsTUFBTTtNQUMvQyxJQUFJNkUsTUFBQSxDQUFPZ29CLFFBQUEsSUFBWWhvQixNQUFBLENBQU9nb0IsUUFBQSxDQUFTQyxPQUFBLElBQVdqb0IsTUFBQSxDQUFPZ29CLFFBQUEsQ0FBU0UsTUFBQSxFQUFRO1FBQ3hFbG9CLE1BQUEsQ0FBT2dvQixRQUFBLENBQVNJLE1BQUEsQ0FBTztNQUN6QjtJQUNGLEdBQUcsR0FBRztFQUNSO0VBRUFwb0IsTUFBQSxDQUFPMGIsY0FBQSxHQUFpQkEsY0FBQTtFQUN4QjFiLE1BQUEsQ0FBT3liLGNBQUEsR0FBaUJBLGNBQUE7RUFDeEIsSUFBSXpiLE1BQUEsQ0FBT1EsTUFBQSxDQUFPNlIsYUFBQSxJQUFpQm5FLFFBQUEsS0FBYWxPLE1BQUEsQ0FBT2tPLFFBQUEsRUFBVTtJQUMvRGxPLE1BQUEsQ0FBT3NTLGFBQUEsQ0FBYztFQUN2QjtBQUNGO0FBRUEsU0FBUytWLFFBQVFoc0IsQ0FBQSxFQUFHO0VBQ2xCLE1BQU0yRCxNQUFBLEdBQVM7RUFDZixJQUFJLENBQUNBLE1BQUEsQ0FBTzZOLE9BQUEsRUFBUztFQUNyQixJQUFJLENBQUM3TixNQUFBLENBQU9nakIsVUFBQSxFQUFZO0lBQ3RCLElBQUloakIsTUFBQSxDQUFPUSxNQUFBLENBQU84bkIsYUFBQSxFQUFlanNCLENBQUEsQ0FBRW9sQixjQUFBLENBQWU7SUFDbEQsSUFBSXpoQixNQUFBLENBQU9RLE1BQUEsQ0FBTytuQix3QkFBQSxJQUE0QnZvQixNQUFBLENBQU9tYSxTQUFBLEVBQVc7TUFDOUQ5ZCxDQUFBLENBQUU4b0IsZUFBQSxDQUFnQjtNQUNsQjlvQixDQUFBLENBQUVtc0Isd0JBQUEsQ0FBeUI7SUFDN0I7RUFDRjtBQUNGO0FBRUEsU0FBU0MsU0FBQSxFQUFXO0VBQ2xCLE1BQU16b0IsTUFBQSxHQUFTO0VBQ2YsTUFBTTtJQUNKVSxTQUFBO0lBQ0E4TSxZQUFBO0lBQ0FLO0VBQ0YsSUFBSTdOLE1BQUE7RUFDSixJQUFJLENBQUM2TixPQUFBLEVBQVM7RUFDZDdOLE1BQUEsQ0FBTzZaLGlCQUFBLEdBQW9CN1osTUFBQSxDQUFPSSxTQUFBO0VBQ2xDLElBQUlKLE1BQUEsQ0FBTzZNLFlBQUEsQ0FBYSxHQUFHO0lBQ3pCN00sTUFBQSxDQUFPSSxTQUFBLEdBQVksQ0FBQ00sU0FBQSxDQUFVMkMsVUFBQTtFQUNoQyxPQUFPO0lBQ0xyRCxNQUFBLENBQU9JLFNBQUEsR0FBWSxDQUFDTSxTQUFBLENBQVV5QyxTQUFBO0VBQ2hDO0VBRUEsSUFBSW5ELE1BQUEsQ0FBT0ksU0FBQSxLQUFjLEdBQUdKLE1BQUEsQ0FBT0ksU0FBQSxHQUFZO0VBQy9DSixNQUFBLENBQU9nWSxpQkFBQSxDQUFrQjtFQUN6QmhZLE1BQUEsQ0FBT2tXLG1CQUFBLENBQW9CO0VBQzNCLElBQUk0RCxXQUFBO0VBQ0osTUFBTTdFLGNBQUEsR0FBaUJqVixNQUFBLENBQU9rVixZQUFBLENBQWEsSUFBSWxWLE1BQUEsQ0FBT3NVLFlBQUEsQ0FBYTtFQUNuRSxJQUFJVyxjQUFBLEtBQW1CLEdBQUc7SUFDeEI2RSxXQUFBLEdBQWM7RUFDaEIsT0FBTztJQUNMQSxXQUFBLElBQWU5WixNQUFBLENBQU9JLFNBQUEsR0FBWUosTUFBQSxDQUFPc1UsWUFBQSxDQUFhLEtBQUtXLGNBQUE7RUFDN0Q7RUFDQSxJQUFJNkUsV0FBQSxLQUFnQjlaLE1BQUEsQ0FBT2tCLFFBQUEsRUFBVTtJQUNuQ2xCLE1BQUEsQ0FBTytVLGNBQUEsQ0FBZXZILFlBQUEsR0FBZSxDQUFDeE4sTUFBQSxDQUFPSSxTQUFBLEdBQVlKLE1BQUEsQ0FBT0ksU0FBUztFQUMzRTtFQUNBSixNQUFBLENBQU9rSSxJQUFBLENBQUssZ0JBQWdCbEksTUFBQSxDQUFPSSxTQUFBLEVBQVcsS0FBSztBQUNyRDtBQUVBLFNBQVNzb0IsT0FBT3JzQixDQUFBLEVBQUc7RUFDakIsTUFBTTJELE1BQUEsR0FBUztFQUNmNFcsb0JBQUEsQ0FBcUI1VyxNQUFBLEVBQVEzRCxDQUFBLENBQUV0RSxNQUFNO0VBQ3JDLElBQUlpSSxNQUFBLENBQU9RLE1BQUEsQ0FBTzRPLE9BQUEsSUFBV3BQLE1BQUEsQ0FBT1EsTUFBQSxDQUFPb1AsYUFBQSxLQUFrQixVQUFVLENBQUM1UCxNQUFBLENBQU9RLE1BQUEsQ0FBT3dWLFVBQUEsRUFBWTtJQUNoRztFQUNGO0VBQ0FoVyxNQUFBLENBQU9vWixNQUFBLENBQU87QUFDaEI7QUFFQSxTQUFTdVAscUJBQUEsRUFBdUI7RUFDOUIsTUFBTTNvQixNQUFBLEdBQVM7RUFDZixJQUFJQSxNQUFBLENBQU80b0IsNkJBQUEsRUFBK0I7RUFDMUM1b0IsTUFBQSxDQUFPNG9CLDZCQUFBLEdBQWdDO0VBQ3ZDLElBQUk1b0IsTUFBQSxDQUFPUSxNQUFBLENBQU8rakIsbUJBQUEsRUFBcUI7SUFDckN2a0IsTUFBQSxDQUFPdEQsRUFBQSxDQUFHdEQsS0FBQSxDQUFNeXZCLFdBQUEsR0FBYztFQUNoQztBQUNGO0FBRUEsSUFBTXRjLE1BQUEsR0FBU0EsQ0FBQ3ZNLE1BQUEsRUFBUW9MLE1BQUEsS0FBVztFQUNqQyxNQUFNdEksU0FBQSxHQUFXNUksV0FBQSxDQUFZO0VBQzdCLE1BQU07SUFDSnNHLE1BQUE7SUFDQTlELEVBQUE7SUFDQWdFLFNBQUE7SUFDQXFGO0VBQ0YsSUFBSS9GLE1BQUE7RUFDSixNQUFNOG9CLE9BQUEsR0FBVSxDQUFDLENBQUN0b0IsTUFBQSxDQUFPMGtCLE1BQUE7RUFDekIsTUFBTTZELFNBQUEsR0FBWTNkLE1BQUEsS0FBVyxPQUFPLHFCQUFxQjtFQUN6RCxNQUFNNGQsWUFBQSxHQUFlNWQsTUFBQTtFQUdyQnRJLFNBQUEsQ0FBU2ltQixTQUFBLEVBQVcsY0FBYy9vQixNQUFBLENBQU8yb0Isb0JBQUEsRUFBc0I7SUFDN0RNLE9BQUEsRUFBUztJQUNUSDtFQUNGLENBQUM7RUFDRHBzQixFQUFBLENBQUdxc0IsU0FBQSxFQUFXLGNBQWMvb0IsTUFBQSxDQUFPMGhCLFlBQUEsRUFBYztJQUMvQ3VILE9BQUEsRUFBUztFQUNYLENBQUM7RUFDRHZzQixFQUFBLENBQUdxc0IsU0FBQSxFQUFXLGVBQWUvb0IsTUFBQSxDQUFPMGhCLFlBQUEsRUFBYztJQUNoRHVILE9BQUEsRUFBUztFQUNYLENBQUM7RUFDRG5tQixTQUFBLENBQVNpbUIsU0FBQSxFQUFXLGFBQWEvb0IsTUFBQSxDQUFPbWtCLFdBQUEsRUFBYTtJQUNuRDhFLE9BQUEsRUFBUztJQUNUSDtFQUNGLENBQUM7RUFDRGhtQixTQUFBLENBQVNpbUIsU0FBQSxFQUFXLGVBQWUvb0IsTUFBQSxDQUFPbWtCLFdBQUEsRUFBYTtJQUNyRDhFLE9BQUEsRUFBUztJQUNUSDtFQUNGLENBQUM7RUFDRGhtQixTQUFBLENBQVNpbUIsU0FBQSxFQUFXLFlBQVkvb0IsTUFBQSxDQUFPdW1CLFVBQUEsRUFBWTtJQUNqRDBDLE9BQUEsRUFBUztFQUNYLENBQUM7RUFDRG5tQixTQUFBLENBQVNpbUIsU0FBQSxFQUFXLGFBQWEvb0IsTUFBQSxDQUFPdW1CLFVBQUEsRUFBWTtJQUNsRDBDLE9BQUEsRUFBUztFQUNYLENBQUM7RUFDRG5tQixTQUFBLENBQVNpbUIsU0FBQSxFQUFXLGlCQUFpQi9vQixNQUFBLENBQU91bUIsVUFBQSxFQUFZO0lBQ3REMEMsT0FBQSxFQUFTO0VBQ1gsQ0FBQztFQUNEbm1CLFNBQUEsQ0FBU2ltQixTQUFBLEVBQVcsZUFBZS9vQixNQUFBLENBQU91bUIsVUFBQSxFQUFZO0lBQ3BEMEMsT0FBQSxFQUFTO0VBQ1gsQ0FBQztFQUNEbm1CLFNBQUEsQ0FBU2ltQixTQUFBLEVBQVcsY0FBYy9vQixNQUFBLENBQU91bUIsVUFBQSxFQUFZO0lBQ25EMEMsT0FBQSxFQUFTO0VBQ1gsQ0FBQztFQUNEbm1CLFNBQUEsQ0FBU2ltQixTQUFBLEVBQVcsZ0JBQWdCL29CLE1BQUEsQ0FBT3VtQixVQUFBLEVBQVk7SUFDckQwQyxPQUFBLEVBQVM7RUFDWCxDQUFDO0VBQ0RubUIsU0FBQSxDQUFTaW1CLFNBQUEsRUFBVyxlQUFlL29CLE1BQUEsQ0FBT3VtQixVQUFBLEVBQVk7SUFDcEQwQyxPQUFBLEVBQVM7RUFDWCxDQUFDO0VBR0QsSUFBSXpvQixNQUFBLENBQU84bkIsYUFBQSxJQUFpQjluQixNQUFBLENBQU8rbkIsd0JBQUEsRUFBMEI7SUFDM0Q3ckIsRUFBQSxDQUFHcXNCLFNBQUEsRUFBVyxTQUFTL29CLE1BQUEsQ0FBT3FvQixPQUFBLEVBQVMsSUFBSTtFQUM3QztFQUNBLElBQUk3bkIsTUFBQSxDQUFPNE8sT0FBQSxFQUFTO0lBQ2xCMU8sU0FBQSxDQUFVcW9CLFNBQUEsRUFBVyxVQUFVL29CLE1BQUEsQ0FBT3lvQixRQUFRO0VBQ2hEO0VBR0EsSUFBSWpvQixNQUFBLENBQU8wb0Isb0JBQUEsRUFBc0I7SUFDL0JscEIsTUFBQSxDQUFPZ3BCLFlBQUEsRUFBY2pqQixNQUFBLENBQU9DLEdBQUEsSUFBT0QsTUFBQSxDQUFPRSxPQUFBLEdBQVUsNENBQTRDLHlCQUF5QjRoQixRQUFBLEVBQVUsSUFBSTtFQUN6SSxPQUFPO0lBQ0w3bkIsTUFBQSxDQUFPZ3BCLFlBQUEsRUFBYyxrQkFBa0JuQixRQUFBLEVBQVUsSUFBSTtFQUN2RDtFQUdBbnJCLEVBQUEsQ0FBR3FzQixTQUFBLEVBQVcsUUFBUS9vQixNQUFBLENBQU8wb0IsTUFBQSxFQUFRO0lBQ25DSSxPQUFBLEVBQVM7RUFDWCxDQUFDO0FBQ0g7QUFDQSxTQUFTSyxhQUFBLEVBQWU7RUFDdEIsTUFBTW5wQixNQUFBLEdBQVM7RUFDZixNQUFNO0lBQ0pRO0VBQ0YsSUFBSVIsTUFBQTtFQUNKQSxNQUFBLENBQU8waEIsWUFBQSxHQUFlQSxZQUFBLENBQWEwSCxJQUFBLENBQUtwcEIsTUFBTTtFQUM5Q0EsTUFBQSxDQUFPbWtCLFdBQUEsR0FBY0EsV0FBQSxDQUFZaUYsSUFBQSxDQUFLcHBCLE1BQU07RUFDNUNBLE1BQUEsQ0FBT3VtQixVQUFBLEdBQWFBLFVBQUEsQ0FBVzZDLElBQUEsQ0FBS3BwQixNQUFNO0VBQzFDQSxNQUFBLENBQU8yb0Isb0JBQUEsR0FBdUJBLG9CQUFBLENBQXFCUyxJQUFBLENBQUtwcEIsTUFBTTtFQUM5RCxJQUFJUSxNQUFBLENBQU80TyxPQUFBLEVBQVM7SUFDbEJwUCxNQUFBLENBQU95b0IsUUFBQSxHQUFXQSxRQUFBLENBQVNXLElBQUEsQ0FBS3BwQixNQUFNO0VBQ3hDO0VBQ0FBLE1BQUEsQ0FBT3FvQixPQUFBLEdBQVVBLE9BQUEsQ0FBUWUsSUFBQSxDQUFLcHBCLE1BQU07RUFDcENBLE1BQUEsQ0FBTzBvQixNQUFBLEdBQVNBLE1BQUEsQ0FBT1UsSUFBQSxDQUFLcHBCLE1BQU07RUFDbEN1TSxNQUFBLENBQU92TSxNQUFBLEVBQVEsSUFBSTtBQUNyQjtBQUNBLFNBQVNxcEIsYUFBQSxFQUFlO0VBQ3RCLE1BQU1ycEIsTUFBQSxHQUFTO0VBQ2Z1TSxNQUFBLENBQU92TSxNQUFBLEVBQVEsS0FBSztBQUN0QjtBQUNBLElBQUlzcEIsUUFBQSxHQUFXO0VBQ2JILFlBQUE7RUFDQUU7QUFDRjtBQUVBLElBQU1FLGFBQUEsR0FBZ0JBLENBQUN2cEIsTUFBQSxFQUFRUSxNQUFBLEtBQVc7RUFDeEMsT0FBT1IsTUFBQSxDQUFPc1AsSUFBQSxJQUFROU8sTUFBQSxDQUFPOE8sSUFBQSxJQUFROU8sTUFBQSxDQUFPOE8sSUFBQSxDQUFLQyxJQUFBLEdBQU87QUFDMUQ7QUFDQSxTQUFTdVksY0FBQSxFQUFnQjtFQUN2QixNQUFNOW5CLE1BQUEsR0FBUztFQUNmLE1BQU07SUFDSjZYLFNBQUE7SUFDQXRQLFdBQUE7SUFDQS9ILE1BQUE7SUFDQTlEO0VBQ0YsSUFBSXNELE1BQUE7RUFDSixNQUFNd3BCLFlBQUEsR0FBY2hwQixNQUFBLENBQU9xUCxXQUFBO0VBQzNCLElBQUksQ0FBQzJaLFlBQUEsSUFBZUEsWUFBQSxJQUFlM3hCLE1BQUEsQ0FBT0ksSUFBQSxDQUFLdXhCLFlBQVcsRUFBRXB4QixNQUFBLEtBQVcsR0FBRztFQUcxRSxNQUFNcXhCLFVBQUEsR0FBYXpwQixNQUFBLENBQU8wcEIsYUFBQSxDQUFjRixZQUFBLEVBQWF4cEIsTUFBQSxDQUFPUSxNQUFBLENBQU9tcEIsZUFBQSxFQUFpQjNwQixNQUFBLENBQU90RCxFQUFFO0VBQzdGLElBQUksQ0FBQytzQixVQUFBLElBQWN6cEIsTUFBQSxDQUFPNHBCLGlCQUFBLEtBQXNCSCxVQUFBLEVBQVk7RUFDNUQsTUFBTUksb0JBQUEsR0FBdUJKLFVBQUEsSUFBY0QsWUFBQSxHQUFjQSxZQUFBLENBQVlDLFVBQUEsSUFBYztFQUNuRixNQUFNSyxnQkFBQSxHQUFtQkQsb0JBQUEsSUFBd0I3cEIsTUFBQSxDQUFPK3BCLGNBQUE7RUFDeEQsTUFBTUMsV0FBQSxHQUFjVCxhQUFBLENBQWN2cEIsTUFBQSxFQUFRUSxNQUFNO0VBQ2hELE1BQU15cEIsVUFBQSxHQUFhVixhQUFBLENBQWN2cEIsTUFBQSxFQUFROHBCLGdCQUFnQjtFQUN6RCxNQUFNSSxhQUFBLEdBQWdCbHFCLE1BQUEsQ0FBT1EsTUFBQSxDQUFPcWdCLFVBQUE7RUFDcEMsTUFBTXNKLFlBQUEsR0FBZUwsZ0JBQUEsQ0FBaUJqSixVQUFBO0VBQ3RDLE1BQU11SixVQUFBLEdBQWE1cEIsTUFBQSxDQUFPcU4sT0FBQTtFQUMxQixJQUFJbWMsV0FBQSxJQUFlLENBQUNDLFVBQUEsRUFBWTtJQUM5QnZ0QixFQUFBLENBQUcrRixTQUFBLENBQVVxUSxNQUFBLENBQU8sR0FBR3RTLE1BQUEsQ0FBT2tTLHNCQUFBLFFBQThCLEdBQUdsUyxNQUFBLENBQU9rUyxzQkFBQSxhQUFtQztJQUN6RzFTLE1BQUEsQ0FBT3FxQixvQkFBQSxDQUFxQjtFQUM5QixXQUFXLENBQUNMLFdBQUEsSUFBZUMsVUFBQSxFQUFZO0lBQ3JDdnRCLEVBQUEsQ0FBRytGLFNBQUEsQ0FBVUMsR0FBQSxDQUFJLEdBQUdsQyxNQUFBLENBQU9rUyxzQkFBQSxNQUE0QjtJQUN2RCxJQUFJb1gsZ0JBQUEsQ0FBaUJ4YSxJQUFBLENBQUt1UCxJQUFBLElBQVFpTCxnQkFBQSxDQUFpQnhhLElBQUEsQ0FBS3VQLElBQUEsS0FBUyxZQUFZLENBQUNpTCxnQkFBQSxDQUFpQnhhLElBQUEsQ0FBS3VQLElBQUEsSUFBUXJlLE1BQUEsQ0FBTzhPLElBQUEsQ0FBS3VQLElBQUEsS0FBUyxVQUFVO01BQ3pJbmlCLEVBQUEsQ0FBRytGLFNBQUEsQ0FBVUMsR0FBQSxDQUFJLEdBQUdsQyxNQUFBLENBQU9rUyxzQkFBQSxhQUFtQztJQUNoRTtJQUNBMVMsTUFBQSxDQUFPcXFCLG9CQUFBLENBQXFCO0VBQzlCO0VBQ0EsSUFBSUgsYUFBQSxJQUFpQixDQUFDQyxZQUFBLEVBQWM7SUFDbENucUIsTUFBQSxDQUFPNGdCLGVBQUEsQ0FBZ0I7RUFDekIsV0FBVyxDQUFDc0osYUFBQSxJQUFpQkMsWUFBQSxFQUFjO0lBQ3pDbnFCLE1BQUEsQ0FBT3NnQixhQUFBLENBQWM7RUFDdkI7RUFHQSxDQUFDLGNBQWMsY0FBYyxXQUFXLEVBQUVwb0IsT0FBQSxDQUFRaU0sSUFBQSxJQUFRO0lBQ3hELElBQUksT0FBTzJsQixnQkFBQSxDQUFpQjNsQixJQUFBLE1BQVUsYUFBYTtJQUNuRCxNQUFNbW1CLGdCQUFBLEdBQW1COXBCLE1BQUEsQ0FBTzJELElBQUEsS0FBUzNELE1BQUEsQ0FBTzJELElBQUEsRUFBTTBKLE9BQUE7SUFDdEQsTUFBTTBjLGVBQUEsR0FBa0JULGdCQUFBLENBQWlCM2xCLElBQUEsS0FBUzJsQixnQkFBQSxDQUFpQjNsQixJQUFBLEVBQU0wSixPQUFBO0lBQ3pFLElBQUl5YyxnQkFBQSxJQUFvQixDQUFDQyxlQUFBLEVBQWlCO01BQ3hDdnFCLE1BQUEsQ0FBT21FLElBQUEsRUFBTXFtQixPQUFBLENBQVE7SUFDdkI7SUFDQSxJQUFJLENBQUNGLGdCQUFBLElBQW9CQyxlQUFBLEVBQWlCO01BQ3hDdnFCLE1BQUEsQ0FBT21FLElBQUEsRUFBTXNtQixNQUFBLENBQU87SUFDdEI7RUFDRixDQUFDO0VBQ0QsTUFBTUMsZ0JBQUEsR0FBbUJaLGdCQUFBLENBQWlCL08sU0FBQSxJQUFhK08sZ0JBQUEsQ0FBaUIvTyxTQUFBLEtBQWN2YSxNQUFBLENBQU91YSxTQUFBO0VBQzdGLE1BQU00UCxXQUFBLEdBQWNucUIsTUFBQSxDQUFPeVEsSUFBQSxLQUFTNlksZ0JBQUEsQ0FBaUJsYSxhQUFBLEtBQWtCcFAsTUFBQSxDQUFPb1AsYUFBQSxJQUFpQjhhLGdCQUFBO0VBQy9GLE1BQU1FLE9BQUEsR0FBVXBxQixNQUFBLENBQU95USxJQUFBO0VBQ3ZCLElBQUl5WixnQkFBQSxJQUFvQm5pQixXQUFBLEVBQWE7SUFDbkN2SSxNQUFBLENBQU82cUIsZUFBQSxDQUFnQjtFQUN6QjtFQUNBbHNCLE9BQUEsQ0FBT3FCLE1BQUEsQ0FBT1EsTUFBQSxFQUFRc3BCLGdCQUFnQjtFQUN0QyxNQUFNZ0IsU0FBQSxHQUFZOXFCLE1BQUEsQ0FBT1EsTUFBQSxDQUFPcU4sT0FBQTtFQUNoQyxNQUFNa2QsT0FBQSxHQUFVL3FCLE1BQUEsQ0FBT1EsTUFBQSxDQUFPeVEsSUFBQTtFQUM5QnBaLE1BQUEsQ0FBT29WLE1BQUEsQ0FBT2pOLE1BQUEsRUFBUTtJQUNwQjhqQixjQUFBLEVBQWdCOWpCLE1BQUEsQ0FBT1EsTUFBQSxDQUFPc2pCLGNBQUE7SUFDOUJySSxjQUFBLEVBQWdCemIsTUFBQSxDQUFPUSxNQUFBLENBQU9pYixjQUFBO0lBQzlCQyxjQUFBLEVBQWdCMWIsTUFBQSxDQUFPUSxNQUFBLENBQU9rYjtFQUNoQyxDQUFDO0VBQ0QsSUFBSTBPLFVBQUEsSUFBYyxDQUFDVSxTQUFBLEVBQVc7SUFDNUI5cUIsTUFBQSxDQUFPd3FCLE9BQUEsQ0FBUTtFQUNqQixXQUFXLENBQUNKLFVBQUEsSUFBY1UsU0FBQSxFQUFXO0lBQ25DOXFCLE1BQUEsQ0FBT3lxQixNQUFBLENBQU87RUFDaEI7RUFDQXpxQixNQUFBLENBQU80cEIsaUJBQUEsR0FBb0JILFVBQUE7RUFDM0J6cEIsTUFBQSxDQUFPa0ksSUFBQSxDQUFLLHFCQUFxQjRoQixnQkFBZ0I7RUFDakQsSUFBSXZoQixXQUFBLEVBQWE7SUFDZixJQUFJb2lCLFdBQUEsRUFBYTtNQUNmM3FCLE1BQUEsQ0FBT21nQixXQUFBLENBQVk7TUFDbkJuZ0IsTUFBQSxDQUFPK2QsVUFBQSxDQUFXbEcsU0FBUztNQUMzQjdYLE1BQUEsQ0FBT2tOLFlBQUEsQ0FBYTtJQUN0QixXQUFXLENBQUMwZCxPQUFBLElBQVdHLE9BQUEsRUFBUztNQUM5Qi9xQixNQUFBLENBQU8rZCxVQUFBLENBQVdsRyxTQUFTO01BQzNCN1gsTUFBQSxDQUFPa04sWUFBQSxDQUFhO0lBQ3RCLFdBQVcwZCxPQUFBLElBQVcsQ0FBQ0csT0FBQSxFQUFTO01BQzlCL3FCLE1BQUEsQ0FBT21nQixXQUFBLENBQVk7SUFDckI7RUFDRjtFQUNBbmdCLE1BQUEsQ0FBT2tJLElBQUEsQ0FBSyxjQUFjNGhCLGdCQUFnQjtBQUM1QztBQUVBLFNBQVNKLGNBQWNGLFlBQUEsRUFBYXpJLElBQUEsRUFBTWlLLFdBQUEsRUFBYTtFQUNyRCxJQUFJakssSUFBQSxLQUFTLFFBQVE7SUFDbkJBLElBQUEsR0FBTztFQUNUO0VBQ0EsSUFBSSxDQUFDeUksWUFBQSxJQUFlekksSUFBQSxLQUFTLGVBQWUsQ0FBQ2lLLFdBQUEsRUFBYSxPQUFPO0VBQ2pFLElBQUl2QixVQUFBLEdBQWE7RUFDakIsTUFBTTlzQixPQUFBLEdBQVNqQixTQUFBLENBQVU7RUFDekIsTUFBTXV2QixhQUFBLEdBQWdCbEssSUFBQSxLQUFTLFdBQVdwa0IsT0FBQSxDQUFPdXVCLFdBQUEsR0FBY0YsV0FBQSxDQUFZcGUsWUFBQTtFQUMzRSxNQUFNdWUsTUFBQSxHQUFTdHpCLE1BQUEsQ0FBT0ksSUFBQSxDQUFLdXhCLFlBQVcsRUFBRWxzQixHQUFBLENBQUk4dEIsS0FBQSxJQUFTO0lBQ25ELElBQUksT0FBT0EsS0FBQSxLQUFVLFlBQVlBLEtBQUEsQ0FBTWxzQixPQUFBLENBQVEsR0FBRyxNQUFNLEdBQUc7TUFDekQsTUFBTW1zQixRQUFBLEdBQVdydEIsVUFBQSxDQUFXb3RCLEtBQUEsQ0FBTUUsTUFBQSxDQUFPLENBQUMsQ0FBQztNQUMzQyxNQUFNQyxLQUFBLEdBQVFOLGFBQUEsR0FBZ0JJLFFBQUE7TUFDOUIsT0FBTztRQUNMRSxLQUFBO1FBQ0FIO01BQ0Y7SUFDRjtJQUNBLE9BQU87TUFDTEcsS0FBQSxFQUFPSCxLQUFBO01BQ1BBO0lBQ0Y7RUFDRixDQUFDO0VBQ0RELE1BQUEsQ0FBT0ssSUFBQSxDQUFLLENBQUNqdUIsQ0FBQSxFQUFHa3VCLENBQUEsS0FBTTFlLFFBQUEsQ0FBU3hQLENBQUEsQ0FBRWd1QixLQUFBLEVBQU8sRUFBRSxJQUFJeGUsUUFBQSxDQUFTMGUsQ0FBQSxDQUFFRixLQUFBLEVBQU8sRUFBRSxDQUFDO0VBQ25FLFNBQVN4c0IsQ0FBQSxHQUFJLEdBQUdBLENBQUEsR0FBSW9zQixNQUFBLENBQU8veUIsTUFBQSxFQUFRMkcsQ0FBQSxJQUFLLEdBQUc7SUFDekMsTUFBTTtNQUNKcXNCLEtBQUE7TUFDQUc7SUFDRixJQUFJSixNQUFBLENBQU9wc0IsQ0FBQTtJQUNYLElBQUlnaUIsSUFBQSxLQUFTLFVBQVU7TUFDckIsSUFBSXBrQixPQUFBLENBQU90QixVQUFBLENBQVcsZUFBZWt3QixLQUFBLEtBQVUsRUFBRXJwQixPQUFBLEVBQVM7UUFDeER1bkIsVUFBQSxHQUFhMkIsS0FBQTtNQUNmO0lBQ0YsV0FBV0csS0FBQSxJQUFTUCxXQUFBLENBQVlyZSxXQUFBLEVBQWE7TUFDM0M4YyxVQUFBLEdBQWEyQixLQUFBO0lBQ2Y7RUFDRjtFQUNBLE9BQU8zQixVQUFBLElBQWM7QUFDdkI7QUFFQSxJQUFJNVosV0FBQSxHQUFjO0VBQ2hCaVksYUFBQTtFQUNBNEI7QUFDRjtBQUVBLFNBQVNnQyxlQUFlaGpCLE9BQUEsRUFBU2lqQixNQUFBLEVBQVE7RUFDdkMsTUFBTUMsYUFBQSxHQUFnQixFQUFDO0VBQ3ZCbGpCLE9BQUEsQ0FBUXhRLE9BQUEsQ0FBUTJ6QixJQUFBLElBQVE7SUFDdEIsSUFBSSxPQUFPQSxJQUFBLEtBQVMsVUFBVTtNQUM1QmgwQixNQUFBLENBQU9JLElBQUEsQ0FBSzR6QixJQUFJLEVBQUUzekIsT0FBQSxDQUFRNHpCLFVBQUEsSUFBYztRQUN0QyxJQUFJRCxJQUFBLENBQUtDLFVBQUEsR0FBYTtVQUNwQkYsYUFBQSxDQUFjL25CLElBQUEsQ0FBSzhuQixNQUFBLEdBQVNHLFVBQVU7UUFDeEM7TUFDRixDQUFDO0lBQ0gsV0FBVyxPQUFPRCxJQUFBLEtBQVMsVUFBVTtNQUNuQ0QsYUFBQSxDQUFjL25CLElBQUEsQ0FBSzhuQixNQUFBLEdBQVNFLElBQUk7SUFDbEM7RUFDRixDQUFDO0VBQ0QsT0FBT0QsYUFBQTtBQUNUO0FBQ0EsU0FBU0csV0FBQSxFQUFhO0VBQ3BCLE1BQU0vckIsTUFBQSxHQUFTO0VBQ2YsTUFBTTtJQUNKOHJCLFVBQUE7SUFDQXRyQixNQUFBO0lBQ0FpTixHQUFBO0lBQ0EvUSxFQUFBO0lBQ0FxSjtFQUNGLElBQUkvRixNQUFBO0VBRUosTUFBTWdzQixRQUFBLEdBQVdOLGNBQUEsQ0FBZSxDQUFDLGVBQWVsckIsTUFBQSxDQUFPdWEsU0FBQSxFQUFXO0lBQ2hFLGFBQWEvYSxNQUFBLENBQU9RLE1BQUEsQ0FBTzBqQixRQUFBLElBQVkxakIsTUFBQSxDQUFPMGpCLFFBQUEsQ0FBU3JXO0VBQ3pELEdBQUc7SUFDRCxjQUFjck4sTUFBQSxDQUFPd1Y7RUFDdkIsR0FBRztJQUNELE9BQU92STtFQUNULEdBQUc7SUFDRCxRQUFRak4sTUFBQSxDQUFPOE8sSUFBQSxJQUFROU8sTUFBQSxDQUFPOE8sSUFBQSxDQUFLQyxJQUFBLEdBQU87RUFDNUMsR0FBRztJQUNELGVBQWUvTyxNQUFBLENBQU84TyxJQUFBLElBQVE5TyxNQUFBLENBQU84TyxJQUFBLENBQUtDLElBQUEsR0FBTyxLQUFLL08sTUFBQSxDQUFPOE8sSUFBQSxDQUFLdVAsSUFBQSxLQUFTO0VBQzdFLEdBQUc7SUFDRCxXQUFXOVksTUFBQSxDQUFPRTtFQUNwQixHQUFHO0lBQ0QsT0FBT0YsTUFBQSxDQUFPQztFQUNoQixHQUFHO0lBQ0QsWUFBWXhGLE1BQUEsQ0FBTzRPO0VBQ3JCLEdBQUc7SUFDRCxZQUFZNU8sTUFBQSxDQUFPNE8sT0FBQSxJQUFXNU8sTUFBQSxDQUFPMk87RUFDdkMsR0FBRztJQUNELGtCQUFrQjNPLE1BQUEsQ0FBTytSO0VBQzNCLENBQUMsR0FBRy9SLE1BQUEsQ0FBT2tTLHNCQUFzQjtFQUNqQ29aLFVBQUEsQ0FBV2pvQixJQUFBLENBQUssR0FBR21vQixRQUFRO0VBQzNCdHZCLEVBQUEsQ0FBRytGLFNBQUEsQ0FBVUMsR0FBQSxDQUFJLEdBQUdvcEIsVUFBVTtFQUM5QjlyQixNQUFBLENBQU9xcUIsb0JBQUEsQ0FBcUI7QUFDOUI7QUFFQSxTQUFTNEIsY0FBQSxFQUFnQjtFQUN2QixNQUFNanNCLE1BQUEsR0FBUztFQUNmLE1BQU07SUFDSnRELEVBQUE7SUFDQW92QjtFQUNGLElBQUk5ckIsTUFBQTtFQUNKdEQsRUFBQSxDQUFHK0YsU0FBQSxDQUFVcVEsTUFBQSxDQUFPLEdBQUdnWixVQUFVO0VBQ2pDOXJCLE1BQUEsQ0FBT3FxQixvQkFBQSxDQUFxQjtBQUM5QjtBQUVBLElBQUk2QixPQUFBLEdBQVU7RUFDWkgsVUFBQTtFQUNBRTtBQUNGO0FBRUEsU0FBUzNaLGNBQUEsRUFBZ0I7RUFDdkIsTUFBTXRTLE1BQUEsR0FBUztFQUNmLE1BQU07SUFDSnlnQixRQUFBLEVBQVUwTCxTQUFBO0lBQ1YzckI7RUFDRixJQUFJUixNQUFBO0VBQ0osTUFBTTtJQUNKc087RUFDRixJQUFJOU4sTUFBQTtFQUNKLElBQUk4TixrQkFBQSxFQUFvQjtJQUN0QixNQUFNcUgsY0FBQSxHQUFpQjNWLE1BQUEsQ0FBTytOLE1BQUEsQ0FBTzNWLE1BQUEsR0FBUztJQUM5QyxNQUFNZzBCLGtCQUFBLEdBQXFCcHNCLE1BQUEsQ0FBT21PLFVBQUEsQ0FBV3dILGNBQUEsSUFBa0IzVixNQUFBLENBQU9vTyxlQUFBLENBQWdCdUgsY0FBQSxJQUFrQnJILGtCQUFBLEdBQXFCO0lBQzdIdE8sTUFBQSxDQUFPeWdCLFFBQUEsR0FBV3pnQixNQUFBLENBQU84RSxJQUFBLEdBQU9zbkIsa0JBQUE7RUFDbEMsT0FBTztJQUNMcHNCLE1BQUEsQ0FBT3lnQixRQUFBLEdBQVd6Z0IsTUFBQSxDQUFPa08sUUFBQSxDQUFTOVYsTUFBQSxLQUFXO0VBQy9DO0VBQ0EsSUFBSW9JLE1BQUEsQ0FBT2liLGNBQUEsS0FBbUIsTUFBTTtJQUNsQ3piLE1BQUEsQ0FBT3liLGNBQUEsR0FBaUIsQ0FBQ3piLE1BQUEsQ0FBT3lnQixRQUFBO0VBQ2xDO0VBQ0EsSUFBSWpnQixNQUFBLENBQU9rYixjQUFBLEtBQW1CLE1BQU07SUFDbEMxYixNQUFBLENBQU8wYixjQUFBLEdBQWlCLENBQUMxYixNQUFBLENBQU95Z0IsUUFBQTtFQUNsQztFQUNBLElBQUkwTCxTQUFBLElBQWFBLFNBQUEsS0FBY25zQixNQUFBLENBQU95Z0IsUUFBQSxFQUFVO0lBQzlDemdCLE1BQUEsQ0FBT29WLEtBQUEsR0FBUTtFQUNqQjtFQUNBLElBQUkrVyxTQUFBLEtBQWNuc0IsTUFBQSxDQUFPeWdCLFFBQUEsRUFBVTtJQUNqQ3pnQixNQUFBLENBQU9rSSxJQUFBLENBQUtsSSxNQUFBLENBQU95Z0IsUUFBQSxHQUFXLFNBQVMsUUFBUTtFQUNqRDtBQUNGO0FBQ0EsSUFBSTRMLGVBQUEsR0FBa0I7RUFDcEIvWjtBQUNGO0FBRUEsSUFBSWdhLFFBQUEsR0FBVztFQUNiaGlCLElBQUEsRUFBTTtFQUNOeVEsU0FBQSxFQUFXO0VBQ1hzSyxjQUFBLEVBQWdCO0VBQ2hCa0gscUJBQUEsRUFBdUI7RUFDdkI3TCxpQkFBQSxFQUFtQjtFQUNuQjVFLFlBQUEsRUFBYztFQUNkcmIsS0FBQSxFQUFPO0VBQ1AyTyxPQUFBLEVBQVM7RUFDVDhaLG9CQUFBLEVBQXNCO0VBQ3RCNWYsY0FBQSxFQUFnQjtFQUNoQjRiLE1BQUEsRUFBUTtFQUNSc0gsY0FBQSxFQUFnQjtFQUNoQkMsWUFBQSxFQUFjO0VBQ2Q1ZSxPQUFBLEVBQVM7RUFDVCtWLGlCQUFBLEVBQW1CO0VBRW5CemQsS0FBQSxFQUFPO0VBQ1BFLE1BQUEsRUFBUTtFQUVSK1QsOEJBQUEsRUFBZ0M7RUFFaEM3ZixTQUFBLEVBQVc7RUFDWG15QixHQUFBLEVBQUs7RUFFTHBMLGtCQUFBLEVBQW9CO0VBQ3BCQyxrQkFBQSxFQUFvQjtFQUVwQnZMLFVBQUEsRUFBWTtFQUVabkYsY0FBQSxFQUFnQjtFQUVoQnlJLGdCQUFBLEVBQWtCO0VBRWxCMUksTUFBQSxFQUFRO0VBSVJmLFdBQUEsRUFBYTtFQUNiOFosZUFBQSxFQUFpQjtFQUVqQmhiLFlBQUEsRUFBYztFQUNkaUIsYUFBQSxFQUFlO0VBQ2ZjLGNBQUEsRUFBZ0I7RUFDaEJDLGtCQUFBLEVBQW9CO0VBQ3BCK0wsa0JBQUEsRUFBb0I7RUFDcEJ2TixjQUFBLEVBQWdCO0VBQ2hCc0Msb0JBQUEsRUFBc0I7RUFDdEJuRCxrQkFBQSxFQUFvQjtFQUVwQkUsaUJBQUEsRUFBbUI7RUFFbkJ1SixtQkFBQSxFQUFxQjtFQUNyQmpHLHdCQUFBLEVBQTBCO0VBRTFCTyxhQUFBLEVBQWU7RUFFZmxDLFlBQUEsRUFBYztFQUVkbVYsVUFBQSxFQUFZO0VBQ1pULFVBQUEsRUFBWTtFQUNackUsYUFBQSxFQUFlO0VBQ2ZnSCxXQUFBLEVBQWE7RUFDYkYsVUFBQSxFQUFZO0VBQ1pDLGVBQUEsRUFBaUI7RUFDakJGLFlBQUEsRUFBYztFQUNkZixZQUFBLEVBQWM7RUFDZHhDLGNBQUEsRUFBZ0I7RUFDaEJ0RyxTQUFBLEVBQVc7RUFDWHlILHdCQUFBLEVBQTBCO0VBQzFCbEIsd0JBQUEsRUFBMEI7RUFDMUJDLDZCQUFBLEVBQStCO0VBQy9CTyxtQkFBQSxFQUFxQjtFQUVyQm9JLGlCQUFBLEVBQW1CO0VBRW5CdEcsVUFBQSxFQUFZO0VBQ1pELGVBQUEsRUFBaUI7RUFFakI3VCxtQkFBQSxFQUFxQjtFQUVyQnNPLFVBQUEsRUFBWTtFQUVaeUgsYUFBQSxFQUFlO0VBQ2ZDLHdCQUFBLEVBQTBCO0VBQzFCcFAsbUJBQUEsRUFBcUI7RUFFckJsSSxJQUFBLEVBQU07RUFDTnFOLGtCQUFBLEVBQW9CO0VBQ3BCTSxvQkFBQSxFQUFzQjtFQUN0QmhDLG1CQUFBLEVBQXFCO0VBRXJCaEYsTUFBQSxFQUFRO0VBRVI4RCxjQUFBLEVBQWdCO0VBQ2hCRCxjQUFBLEVBQWdCO0VBQ2hCd0gsWUFBQSxFQUFjO0VBRWRGLFNBQUEsRUFBVztFQUNYTCxjQUFBLEVBQWdCO0VBQ2hCRyxpQkFBQSxFQUFtQjtFQUVuQitKLGdCQUFBLEVBQWtCO0VBQ2xCL1osdUJBQUEsRUFBeUI7RUFFekJILHNCQUFBLEVBQXdCO0VBRXhCMUUsVUFBQSxFQUFZO0VBQ1pvUSxlQUFBLEVBQWlCO0VBQ2pCNUgsZ0JBQUEsRUFBa0I7RUFDbEI1QixpQkFBQSxFQUFtQjtFQUNuQkMsc0JBQUEsRUFBd0I7RUFDeEI0QixjQUFBLEVBQWdCO0VBQ2hCQyxjQUFBLEVBQWdCO0VBQ2hCbVcsWUFBQSxFQUFjO0VBQ2Q1VixrQkFBQSxFQUFvQjtFQUNwQkssbUJBQUEsRUFBcUI7RUFFckJzQixrQkFBQSxFQUFvQjtFQUVwQmtVLFlBQUEsRUFBYztBQUNoQjtBQUVBLFNBQVNDLG1CQUFtQnZzQixNQUFBLEVBQVF3c0IsZ0JBQUEsRUFBa0I7RUFDcEQsT0FBTyxTQUFTeGpCLGFBQWE3UixHQUFBLEVBQUs7SUFDaEMsSUFBSUEsR0FBQSxLQUFRLFFBQVE7TUFDbEJBLEdBQUEsR0FBTSxDQUFDO0lBQ1Q7SUFDQSxNQUFNczFCLGVBQUEsR0FBa0JwMUIsTUFBQSxDQUFPSSxJQUFBLENBQUtOLEdBQUcsRUFBRTtJQUN6QyxNQUFNdTFCLFlBQUEsR0FBZXYxQixHQUFBLENBQUlzMUIsZUFBQTtJQUN6QixJQUFJLE9BQU9DLFlBQUEsS0FBaUIsWUFBWUEsWUFBQSxLQUFpQixNQUFNO01BQzdEdnVCLE9BQUEsQ0FBT3F1QixnQkFBQSxFQUFrQnIxQixHQUFHO01BQzVCO0lBQ0Y7SUFDQSxJQUFJNkksTUFBQSxDQUFPeXNCLGVBQUEsTUFBcUIsTUFBTTtNQUNwQ3pzQixNQUFBLENBQU95c0IsZUFBQSxJQUFtQjtRQUN4QnBmLE9BQUEsRUFBUztNQUNYO0lBQ0Y7SUFDQSxJQUFJb2YsZUFBQSxLQUFvQixnQkFBZ0J6c0IsTUFBQSxDQUFPeXNCLGVBQUEsS0FBb0J6c0IsTUFBQSxDQUFPeXNCLGVBQUEsRUFBaUJwZixPQUFBLElBQVcsQ0FBQ3JOLE1BQUEsQ0FBT3lzQixlQUFBLEVBQWlCckYsTUFBQSxJQUFVLENBQUNwbkIsTUFBQSxDQUFPeXNCLGVBQUEsRUFBaUJ0RixNQUFBLEVBQVE7TUFDeEtubkIsTUFBQSxDQUFPeXNCLGVBQUEsRUFBaUJFLElBQUEsR0FBTztJQUNqQztJQUNBLElBQUksQ0FBQyxjQUFjLFdBQVcsRUFBRWp1QixPQUFBLENBQVErdEIsZUFBZSxLQUFLLEtBQUt6c0IsTUFBQSxDQUFPeXNCLGVBQUEsS0FBb0J6c0IsTUFBQSxDQUFPeXNCLGVBQUEsRUFBaUJwZixPQUFBLElBQVcsQ0FBQ3JOLE1BQUEsQ0FBT3lzQixlQUFBLEVBQWlCdndCLEVBQUEsRUFBSTtNQUMxSjhELE1BQUEsQ0FBT3lzQixlQUFBLEVBQWlCRSxJQUFBLEdBQU87SUFDakM7SUFDQSxJQUFJLEVBQUVGLGVBQUEsSUFBbUJ6c0IsTUFBQSxJQUFVLGFBQWEwc0IsWUFBQSxHQUFlO01BQzdEdnVCLE9BQUEsQ0FBT3F1QixnQkFBQSxFQUFrQnIxQixHQUFHO01BQzVCO0lBQ0Y7SUFDQSxJQUFJLE9BQU82SSxNQUFBLENBQU95c0IsZUFBQSxNQUFxQixZQUFZLEVBQUUsYUFBYXpzQixNQUFBLENBQU95c0IsZUFBQSxJQUFtQjtNQUMxRnpzQixNQUFBLENBQU95c0IsZUFBQSxFQUFpQnBmLE9BQUEsR0FBVTtJQUNwQztJQUNBLElBQUksQ0FBQ3JOLE1BQUEsQ0FBT3lzQixlQUFBLEdBQWtCenNCLE1BQUEsQ0FBT3lzQixlQUFBLElBQW1CO01BQ3REcGYsT0FBQSxFQUFTO0lBQ1g7SUFDQWxQLE9BQUEsQ0FBT3F1QixnQkFBQSxFQUFrQnIxQixHQUFHO0VBQzlCO0FBQ0Y7QUFHQSxJQUFNeTFCLFVBQUEsR0FBYTtFQUNqQnRpQixhQUFBO0VBQ0FzTyxNQUFBO0VBQ0FoWixTQUFBO0VBQ0ErYSxVQUFBO0VBQ0EyQyxLQUFBO0VBQ0E3TSxJQUFBO0VBQ0E0UCxVQUFBO0VBQ0F0VSxNQUFBLEVBQVErYyxRQUFBO0VBQ1J6WixXQUFBO0VBQ0F5QyxhQUFBLEVBQWUrWixlQUFBO0VBQ2ZIO0FBQ0Y7QUFDQSxJQUFNbUIsZ0JBQUEsR0FBbUIsQ0FBQztBQUMxQixJQUFNajJCLE1BQUEsR0FBTixNQUFhO0VBQ1hRLFlBQUEsRUFBYztJQUNaLElBQUk4RSxFQUFBO0lBQ0osSUFBSThELE1BQUE7SUFDSixTQUFTa0wsSUFBQSxHQUFPN00sU0FBQSxDQUFVekcsTUFBQSxFQUFRdVQsSUFBQSxHQUFPLElBQUloSixLQUFBLENBQU0rSSxJQUFJLEdBQUdFLElBQUEsR0FBTyxHQUFHQSxJQUFBLEdBQU9GLElBQUEsRUFBTUUsSUFBQSxJQUFRO01BQ3ZGRCxJQUFBLENBQUtDLElBQUEsSUFBUS9NLFNBQUEsQ0FBVStNLElBQUE7SUFDekI7SUFDQSxJQUFJRCxJQUFBLENBQUt2VCxNQUFBLEtBQVcsS0FBS3VULElBQUEsQ0FBSyxHQUFHL1QsV0FBQSxJQUFlQyxNQUFBLENBQU91RyxTQUFBLENBQVVOLFFBQUEsQ0FBU08sSUFBQSxDQUFLc04sSUFBQSxDQUFLLEVBQUUsRUFBRXJOLEtBQUEsQ0FBTSxHQUFHLEVBQUUsTUFBTSxVQUFVO01BQ2pIa0MsTUFBQSxHQUFTbUwsSUFBQSxDQUFLO0lBQ2hCLE9BQU87TUFDTCxDQUFDalAsRUFBQSxFQUFJOEQsTUFBTSxJQUFJbUwsSUFBQTtJQUNqQjtJQUNBLElBQUksQ0FBQ25MLE1BQUEsRUFBUUEsTUFBQSxHQUFTLENBQUM7SUFDdkJBLE1BQUEsR0FBUzdCLE9BQUEsQ0FBTyxDQUFDLEdBQUc2QixNQUFNO0lBQzFCLElBQUk5RCxFQUFBLElBQU0sQ0FBQzhELE1BQUEsQ0FBTzlELEVBQUEsRUFBSThELE1BQUEsQ0FBTzlELEVBQUEsR0FBS0EsRUFBQTtJQUNsQyxNQUFNb0csU0FBQSxHQUFXNUksV0FBQSxDQUFZO0lBQzdCLElBQUlzRyxNQUFBLENBQU85RCxFQUFBLElBQU0sT0FBTzhELE1BQUEsQ0FBTzlELEVBQUEsS0FBTyxZQUFZb0csU0FBQSxDQUFTakssZ0JBQUEsQ0FBaUIySCxNQUFBLENBQU85RCxFQUFFLEVBQUV0RSxNQUFBLEdBQVMsR0FBRztNQUNqRyxNQUFNazFCLE9BQUEsR0FBVSxFQUFDO01BQ2pCeHFCLFNBQUEsQ0FBU2pLLGdCQUFBLENBQWlCMkgsTUFBQSxDQUFPOUQsRUFBRSxFQUFFeEUsT0FBQSxDQUFROHlCLFdBQUEsSUFBZTtRQUMxRCxNQUFNdUMsU0FBQSxHQUFZNXVCLE9BQUEsQ0FBTyxDQUFDLEdBQUc2QixNQUFBLEVBQVE7VUFDbkM5RCxFQUFBLEVBQUlzdUI7UUFDTixDQUFDO1FBQ0RzQyxPQUFBLENBQVF6cEIsSUFBQSxDQUFLLElBQUl6TSxNQUFBLENBQU9tMkIsU0FBUyxDQUFDO01BQ3BDLENBQUM7TUFFRCxPQUFPRCxPQUFBO0lBQ1Q7SUFHQSxNQUFNdHRCLE1BQUEsR0FBUztJQUNmQSxNQUFBLENBQU9QLFVBQUEsR0FBYTtJQUNwQk8sTUFBQSxDQUFPa0YsT0FBQSxHQUFVTSxVQUFBLENBQVc7SUFDNUJ4RixNQUFBLENBQU8rRixNQUFBLEdBQVNlLFNBQUEsQ0FBVTtNQUN4QnZNLFNBQUEsRUFBV2lHLE1BQUEsQ0FBT2pHO0lBQ3BCLENBQUM7SUFDRHlGLE1BQUEsQ0FBT2dILE9BQUEsR0FBVWUsVUFBQSxDQUFXO0lBQzVCL0gsTUFBQSxDQUFPbUwsZUFBQSxHQUFrQixDQUFDO0lBQzFCbkwsTUFBQSxDQUFPK0wsa0JBQUEsR0FBcUIsRUFBQztJQUM3Qi9MLE1BQUEsQ0FBT3d0QixPQUFBLEdBQVUsQ0FBQyxHQUFHeHRCLE1BQUEsQ0FBT3l0QixXQUFXO0lBQ3ZDLElBQUlqdEIsTUFBQSxDQUFPZ3RCLE9BQUEsSUFBVzdxQixLQUFBLENBQU1DLE9BQUEsQ0FBUXBDLE1BQUEsQ0FBT2d0QixPQUFPLEdBQUc7TUFDbkR4dEIsTUFBQSxDQUFPd3RCLE9BQUEsQ0FBUTNwQixJQUFBLENBQUssR0FBR3JELE1BQUEsQ0FBT2d0QixPQUFPO0lBQ3ZDO0lBQ0EsTUFBTVIsZ0JBQUEsR0FBbUIsQ0FBQztJQUMxQmh0QixNQUFBLENBQU93dEIsT0FBQSxDQUFRdDFCLE9BQUEsQ0FBUXcxQixHQUFBLElBQU87TUFDNUJBLEdBQUEsQ0FBSTtRQUNGbHRCLE1BQUE7UUFDQVIsTUFBQTtRQUNBd0osWUFBQSxFQUFjdWpCLGtCQUFBLENBQW1CdnNCLE1BQUEsRUFBUXdzQixnQkFBZ0I7UUFDekQva0IsRUFBQSxFQUFJakksTUFBQSxDQUFPaUksRUFBQSxDQUFHbWhCLElBQUEsQ0FBS3BwQixNQUFNO1FBQ3pCc0wsSUFBQSxFQUFNdEwsTUFBQSxDQUFPc0wsSUFBQSxDQUFLOGQsSUFBQSxDQUFLcHBCLE1BQU07UUFDN0J3TCxHQUFBLEVBQUt4TCxNQUFBLENBQU93TCxHQUFBLENBQUk0ZCxJQUFBLENBQUtwcEIsTUFBTTtRQUMzQmtJLElBQUEsRUFBTWxJLE1BQUEsQ0FBT2tJLElBQUEsQ0FBS2toQixJQUFBLENBQUtwcEIsTUFBTTtNQUMvQixDQUFDO0lBQ0gsQ0FBQztJQUdELE1BQU0ydEIsWUFBQSxHQUFlaHZCLE9BQUEsQ0FBTyxDQUFDLEdBQUcydEIsUUFBQSxFQUFVVSxnQkFBZ0I7SUFHMURodEIsTUFBQSxDQUFPUSxNQUFBLEdBQVM3QixPQUFBLENBQU8sQ0FBQyxHQUFHZ3ZCLFlBQUEsRUFBY04sZ0JBQUEsRUFBa0I3c0IsTUFBTTtJQUNqRVIsTUFBQSxDQUFPK3BCLGNBQUEsR0FBaUJwckIsT0FBQSxDQUFPLENBQUMsR0FBR3FCLE1BQUEsQ0FBT1EsTUFBTTtJQUNoRFIsTUFBQSxDQUFPNHRCLFlBQUEsR0FBZWp2QixPQUFBLENBQU8sQ0FBQyxHQUFHNkIsTUFBTTtJQUd2QyxJQUFJUixNQUFBLENBQU9RLE1BQUEsSUFBVVIsTUFBQSxDQUFPUSxNQUFBLENBQU95SCxFQUFBLEVBQUk7TUFDckNwUSxNQUFBLENBQU9JLElBQUEsQ0FBSytILE1BQUEsQ0FBT1EsTUFBQSxDQUFPeUgsRUFBRSxFQUFFL1AsT0FBQSxDQUFRMjFCLFNBQUEsSUFBYTtRQUNqRDd0QixNQUFBLENBQU9pSSxFQUFBLENBQUc0bEIsU0FBQSxFQUFXN3RCLE1BQUEsQ0FBT1EsTUFBQSxDQUFPeUgsRUFBQSxDQUFHNGxCLFNBQUEsQ0FBVTtNQUNsRCxDQUFDO0lBQ0g7SUFDQSxJQUFJN3RCLE1BQUEsQ0FBT1EsTUFBQSxJQUFVUixNQUFBLENBQU9RLE1BQUEsQ0FBT3NMLEtBQUEsRUFBTztNQUN4QzlMLE1BQUEsQ0FBTzhMLEtBQUEsQ0FBTTlMLE1BQUEsQ0FBT1EsTUFBQSxDQUFPc0wsS0FBSztJQUNsQztJQUdBalUsTUFBQSxDQUFPb1YsTUFBQSxDQUFPak4sTUFBQSxFQUFRO01BQ3BCNk4sT0FBQSxFQUFTN04sTUFBQSxDQUFPUSxNQUFBLENBQU9xTixPQUFBO01BQ3ZCblIsRUFBQTtNQUVBb3ZCLFVBQUEsRUFBWSxFQUFDO01BRWIvZCxNQUFBLEVBQVEsRUFBQztNQUNUSSxVQUFBLEVBQVksRUFBQztNQUNiRCxRQUFBLEVBQVUsRUFBQztNQUNYRSxlQUFBLEVBQWlCLEVBQUM7TUFFbEJ2QixhQUFBLEVBQWU7UUFDYixPQUFPN00sTUFBQSxDQUFPUSxNQUFBLENBQU91YSxTQUFBLEtBQWM7TUFDckM7TUFDQWpPLFdBQUEsRUFBYTtRQUNYLE9BQU85TSxNQUFBLENBQU9RLE1BQUEsQ0FBT3VhLFNBQUEsS0FBYztNQUNyQztNQUVBMUgsV0FBQSxFQUFhO01BQ2J3RSxTQUFBLEVBQVc7TUFFWDFDLFdBQUEsRUFBYTtNQUNiQyxLQUFBLEVBQU87TUFFUGhWLFNBQUEsRUFBVztNQUNYeVosaUJBQUEsRUFBbUI7TUFDbkIzWSxRQUFBLEVBQVU7TUFDVjRzQixRQUFBLEVBQVU7TUFDVjNULFNBQUEsRUFBVztNQUNYdkcsc0JBQUEsRUFBd0I7UUFHdEIsT0FBT3pTLElBQUEsQ0FBSzRzQixLQUFBLENBQU0sS0FBSzN0QixTQUFBLEdBQVksS0FBSyxFQUFFLElBQUksS0FBSztNQUNyRDtNQUVBcWIsY0FBQSxFQUFnQnpiLE1BQUEsQ0FBT1EsTUFBQSxDQUFPaWIsY0FBQTtNQUM5QkMsY0FBQSxFQUFnQjFiLE1BQUEsQ0FBT1EsTUFBQSxDQUFPa2IsY0FBQTtNQUU5Qm1FLGVBQUEsRUFBaUI7UUFDZjBDLFNBQUEsRUFBVztRQUNYQyxPQUFBLEVBQVM7UUFDVGMsbUJBQUEsRUFBcUI7UUFDckJHLGNBQUEsRUFBZ0I7UUFDaEJGLFdBQUEsRUFBYTtRQUNiaEssZ0JBQUEsRUFBa0I7UUFDbEJ1RyxjQUFBLEVBQWdCO1FBQ2hCNkQsa0JBQUEsRUFBb0I7UUFFcEJDLGlCQUFBLEVBQW1CNWpCLE1BQUEsQ0FBT1EsTUFBQSxDQUFPb2pCLGlCQUFBO1FBRWpDaUQsYUFBQSxFQUFlO1FBQ2ZtSCxZQUFBLEVBQWM7UUFFZEMsVUFBQSxFQUFZLEVBQUM7UUFDYmpJLG1CQUFBLEVBQXFCO1FBQ3JCeEMsV0FBQSxFQUFhO1FBQ2IzQixTQUFBLEVBQVc7UUFDWEUsT0FBQSxFQUFTO01BQ1g7TUFFQWlCLFVBQUEsRUFBWTtNQUVaYyxjQUFBLEVBQWdCOWpCLE1BQUEsQ0FBT1EsTUFBQSxDQUFPc2pCLGNBQUE7TUFDOUI1QixPQUFBLEVBQVM7UUFDUGIsTUFBQSxFQUFRO1FBQ1JnQyxNQUFBLEVBQVE7UUFDUkgsUUFBQSxFQUFVO1FBQ1ZDLFFBQUEsRUFBVTtRQUNWdkQsSUFBQSxFQUFNO01BQ1I7TUFFQXNPLFlBQUEsRUFBYyxFQUFDO01BQ2ZDLFlBQUEsRUFBYztJQUNoQixDQUFDO0lBQ0RudUIsTUFBQSxDQUFPa0ksSUFBQSxDQUFLLFNBQVM7SUFHckIsSUFBSWxJLE1BQUEsQ0FBT1EsTUFBQSxDQUFPOEosSUFBQSxFQUFNO01BQ3RCdEssTUFBQSxDQUFPc0ssSUFBQSxDQUFLO0lBQ2Q7SUFJQSxPQUFPdEssTUFBQTtFQUNUO0VBQ0FxTixrQkFBa0IrZ0IsUUFBQSxFQUFVO0lBQzFCLElBQUksS0FBS3ZoQixZQUFBLENBQWEsR0FBRztNQUN2QixPQUFPdWhCLFFBQUE7SUFDVDtJQUVBLE9BQU87TUFDTCxTQUFTO01BQ1QsY0FBYztNQUNkLGtCQUFrQjtNQUNsQixlQUFlO01BQ2YsZ0JBQWdCO01BQ2hCLGdCQUFnQjtNQUNoQixpQkFBaUI7TUFDakIsZUFBZTtJQUNqQixFQUFFQSxRQUFBO0VBQ0o7RUFDQXZRLGNBQWNoYyxPQUFBLEVBQVM7SUFDckIsTUFBTTtNQUNKeUwsUUFBQTtNQUNBOU07SUFDRixJQUFJO0lBQ0osTUFBTXVOLE1BQUEsR0FBU2hNLGVBQUEsQ0FBZ0J1TCxRQUFBLEVBQVUsSUFBSTlNLE1BQUEsQ0FBT3dOLFVBQUEsZ0JBQTBCO0lBQzlFLE1BQU0wSCxlQUFBLEdBQWtCdFIsWUFBQSxDQUFhMkosTUFBQSxDQUFPLEVBQUU7SUFDOUMsT0FBTzNKLFlBQUEsQ0FBYXZDLE9BQU8sSUFBSTZULGVBQUE7RUFDakM7RUFDQXZDLG9CQUFvQmxILEtBQUEsRUFBTztJQUN6QixPQUFPLEtBQUs0UixhQUFBLENBQWMsS0FBSzlQLE1BQUEsQ0FBTzlSLE1BQUEsQ0FBTzRGLE9BQUEsSUFBV0EsT0FBQSxDQUFROFcsWUFBQSxDQUFhLHlCQUF5QixJQUFJLE1BQU0xTSxLQUFLLEVBQUUsRUFBRTtFQUMzSDtFQUNBdVMsYUFBQSxFQUFlO0lBQ2IsTUFBTXhlLE1BQUEsR0FBUztJQUNmLE1BQU07TUFDSnNOLFFBQUE7TUFDQTlNO0lBQ0YsSUFBSVIsTUFBQTtJQUNKQSxNQUFBLENBQU8rTixNQUFBLEdBQVNoTSxlQUFBLENBQWdCdUwsUUFBQSxFQUFVLElBQUk5TSxNQUFBLENBQU93TixVQUFBLGdCQUEwQjtFQUNqRjtFQUNBeWMsT0FBQSxFQUFTO0lBQ1AsTUFBTXpxQixNQUFBLEdBQVM7SUFDZixJQUFJQSxNQUFBLENBQU82TixPQUFBLEVBQVM7SUFDcEI3TixNQUFBLENBQU82TixPQUFBLEdBQVU7SUFDakIsSUFBSTdOLE1BQUEsQ0FBT1EsTUFBQSxDQUFPcWdCLFVBQUEsRUFBWTtNQUM1QjdnQixNQUFBLENBQU9zZ0IsYUFBQSxDQUFjO0lBQ3ZCO0lBQ0F0Z0IsTUFBQSxDQUFPa0ksSUFBQSxDQUFLLFFBQVE7RUFDdEI7RUFDQXNpQixRQUFBLEVBQVU7SUFDUixNQUFNeHFCLE1BQUEsR0FBUztJQUNmLElBQUksQ0FBQ0EsTUFBQSxDQUFPNk4sT0FBQSxFQUFTO0lBQ3JCN04sTUFBQSxDQUFPNk4sT0FBQSxHQUFVO0lBQ2pCLElBQUk3TixNQUFBLENBQU9RLE1BQUEsQ0FBT3FnQixVQUFBLEVBQVk7TUFDNUI3Z0IsTUFBQSxDQUFPNGdCLGVBQUEsQ0FBZ0I7SUFDekI7SUFDQTVnQixNQUFBLENBQU9rSSxJQUFBLENBQUssU0FBUztFQUN2QjtFQUNBbW1CLFlBQVludEIsUUFBQSxFQUFVVCxLQUFBLEVBQU87SUFDM0IsTUFBTVQsTUFBQSxHQUFTO0lBQ2ZrQixRQUFBLEdBQVdDLElBQUEsQ0FBS0UsR0FBQSxDQUFJRixJQUFBLENBQUtDLEdBQUEsQ0FBSUYsUUFBQSxFQUFVLENBQUMsR0FBRyxDQUFDO0lBQzVDLE1BQU1HLEdBQUEsR0FBTXJCLE1BQUEsQ0FBT3NVLFlBQUEsQ0FBYTtJQUNoQyxNQUFNbFQsR0FBQSxHQUFNcEIsTUFBQSxDQUFPa1YsWUFBQSxDQUFhO0lBQ2hDLE1BQU1uVSxPQUFBLElBQVdLLEdBQUEsR0FBTUMsR0FBQSxJQUFPSCxRQUFBLEdBQVdHLEdBQUE7SUFDekNyQixNQUFBLENBQU8rWixXQUFBLENBQVloWixPQUFBLEVBQVMsT0FBT04sS0FBQSxLQUFVLGNBQWMsSUFBSUEsS0FBSztJQUNwRVQsTUFBQSxDQUFPZ1ksaUJBQUEsQ0FBa0I7SUFDekJoWSxNQUFBLENBQU9rVyxtQkFBQSxDQUFvQjtFQUM3QjtFQUNBbVUscUJBQUEsRUFBdUI7SUFDckIsTUFBTXJxQixNQUFBLEdBQVM7SUFDZixJQUFJLENBQUNBLE1BQUEsQ0FBT1EsTUFBQSxDQUFPc3NCLFlBQUEsSUFBZ0IsQ0FBQzlzQixNQUFBLENBQU90RCxFQUFBLEVBQUk7SUFDL0MsTUFBTTR4QixHQUFBLEdBQU10dUIsTUFBQSxDQUFPdEQsRUFBQSxDQUFHcVgsU0FBQSxDQUFVL1gsS0FBQSxDQUFNLEdBQUcsRUFBRUMsTUFBQSxDQUFPOFgsU0FBQSxJQUFhO01BQzdELE9BQU9BLFNBQUEsQ0FBVTdVLE9BQUEsQ0FBUSxRQUFRLE1BQU0sS0FBSzZVLFNBQUEsQ0FBVTdVLE9BQUEsQ0FBUWMsTUFBQSxDQUFPUSxNQUFBLENBQU9rUyxzQkFBc0IsTUFBTTtJQUMxRyxDQUFDO0lBQ0QxUyxNQUFBLENBQU9rSSxJQUFBLENBQUsscUJBQXFCb21CLEdBQUEsQ0FBSTd3QixJQUFBLENBQUssR0FBRyxDQUFDO0VBQ2hEO0VBQ0E4d0IsZ0JBQWdCMXNCLE9BQUEsRUFBUztJQUN2QixNQUFNN0IsTUFBQSxHQUFTO0lBQ2YsSUFBSUEsTUFBQSxDQUFPc0ksU0FBQSxFQUFXLE9BQU87SUFDN0IsT0FBT3pHLE9BQUEsQ0FBUWtTLFNBQUEsQ0FBVS9YLEtBQUEsQ0FBTSxHQUFHLEVBQUVDLE1BQUEsQ0FBTzhYLFNBQUEsSUFBYTtNQUN0RCxPQUFPQSxTQUFBLENBQVU3VSxPQUFBLENBQVEsY0FBYyxNQUFNLEtBQUs2VSxTQUFBLENBQVU3VSxPQUFBLENBQVFjLE1BQUEsQ0FBT1EsTUFBQSxDQUFPd04sVUFBVSxNQUFNO0lBQ3BHLENBQUMsRUFBRXZRLElBQUEsQ0FBSyxHQUFHO0VBQ2I7RUFDQWtaLGtCQUFBLEVBQW9CO0lBQ2xCLE1BQU0zVyxNQUFBLEdBQVM7SUFDZixJQUFJLENBQUNBLE1BQUEsQ0FBT1EsTUFBQSxDQUFPc3NCLFlBQUEsSUFBZ0IsQ0FBQzlzQixNQUFBLENBQU90RCxFQUFBLEVBQUk7SUFDL0MsTUFBTTh4QixPQUFBLEdBQVUsRUFBQztJQUNqQnh1QixNQUFBLENBQU8rTixNQUFBLENBQU83VixPQUFBLENBQVEySixPQUFBLElBQVc7TUFDL0IsTUFBTWlxQixVQUFBLEdBQWE5ckIsTUFBQSxDQUFPdXVCLGVBQUEsQ0FBZ0Ixc0IsT0FBTztNQUNqRDJzQixPQUFBLENBQVEzcUIsSUFBQSxDQUFLO1FBQ1hoQyxPQUFBO1FBQ0FpcUI7TUFDRixDQUFDO01BQ0Q5ckIsTUFBQSxDQUFPa0ksSUFBQSxDQUFLLGVBQWVyRyxPQUFBLEVBQVNpcUIsVUFBVTtJQUNoRCxDQUFDO0lBQ0Q5ckIsTUFBQSxDQUFPa0ksSUFBQSxDQUFLLGlCQUFpQnNtQixPQUFPO0VBQ3RDO0VBQ0FqWCxxQkFBcUJrWCxJQUFBLEVBQU1DLEtBQUEsRUFBTztJQUNoQyxJQUFJRCxJQUFBLEtBQVMsUUFBUTtNQUNuQkEsSUFBQSxHQUFPO0lBQ1Q7SUFDQSxJQUFJQyxLQUFBLEtBQVUsUUFBUTtNQUNwQkEsS0FBQSxHQUFRO0lBQ1Y7SUFDQSxNQUFNMXVCLE1BQUEsR0FBUztJQUNmLE1BQU07TUFDSlEsTUFBQTtNQUNBdU4sTUFBQTtNQUNBSSxVQUFBO01BQ0FDLGVBQUE7TUFDQXRKLElBQUEsRUFBTXlJLFVBQUE7TUFDTjhGO0lBQ0YsSUFBSXJULE1BQUE7SUFDSixJQUFJMnVCLEdBQUEsR0FBTTtJQUNWLElBQUksT0FBT251QixNQUFBLENBQU9vUCxhQUFBLEtBQWtCLFVBQVUsT0FBT3BQLE1BQUEsQ0FBT29QLGFBQUE7SUFDNUQsSUFBSXBQLE1BQUEsQ0FBTzJPLGNBQUEsRUFBZ0I7TUFDekIsSUFBSU8sU0FBQSxHQUFZM0IsTUFBQSxDQUFPc0YsV0FBQSxJQUFlbFMsSUFBQSxDQUFLZ1EsSUFBQSxDQUFLcEQsTUFBQSxDQUFPc0YsV0FBQSxFQUFhN0MsZUFBZSxJQUFJO01BQ3ZGLElBQUlvZSxTQUFBO01BQ0osU0FBUzd2QixDQUFBLEdBQUlzVSxXQUFBLEdBQWMsR0FBR3RVLENBQUEsR0FBSWdQLE1BQUEsQ0FBTzNWLE1BQUEsRUFBUTJHLENBQUEsSUFBSyxHQUFHO1FBQ3ZELElBQUlnUCxNQUFBLENBQU9oUCxDQUFBLEtBQU0sQ0FBQzZ2QixTQUFBLEVBQVc7VUFDM0JsZixTQUFBLElBQWF2TyxJQUFBLENBQUtnUSxJQUFBLENBQUtwRCxNQUFBLENBQU9oUCxDQUFBLEVBQUd5UixlQUFlO1VBQ2hEbWUsR0FBQSxJQUFPO1VBQ1AsSUFBSWpmLFNBQUEsR0FBWW5DLFVBQUEsRUFBWXFoQixTQUFBLEdBQVk7UUFDMUM7TUFDRjtNQUNBLFNBQVM3dkIsQ0FBQSxHQUFJc1UsV0FBQSxHQUFjLEdBQUd0VSxDQUFBLElBQUssR0FBR0EsQ0FBQSxJQUFLLEdBQUc7UUFDNUMsSUFBSWdQLE1BQUEsQ0FBT2hQLENBQUEsS0FBTSxDQUFDNnZCLFNBQUEsRUFBVztVQUMzQmxmLFNBQUEsSUFBYTNCLE1BQUEsQ0FBT2hQLENBQUEsRUFBR3lSLGVBQUE7VUFDdkJtZSxHQUFBLElBQU87VUFDUCxJQUFJamYsU0FBQSxHQUFZbkMsVUFBQSxFQUFZcWhCLFNBQUEsR0FBWTtRQUMxQztNQUNGO0lBQ0YsT0FBTztNQUVMLElBQUlILElBQUEsS0FBUyxXQUFXO1FBQ3RCLFNBQVMxdkIsQ0FBQSxHQUFJc1UsV0FBQSxHQUFjLEdBQUd0VSxDQUFBLEdBQUlnUCxNQUFBLENBQU8zVixNQUFBLEVBQVEyRyxDQUFBLElBQUssR0FBRztVQUN2RCxNQUFNOHZCLFdBQUEsR0FBY0gsS0FBQSxHQUFRdmdCLFVBQUEsQ0FBV3BQLENBQUEsSUFBS3FQLGVBQUEsQ0FBZ0JyUCxDQUFBLElBQUtvUCxVQUFBLENBQVdrRixXQUFBLElBQWU5RixVQUFBLEdBQWFZLFVBQUEsQ0FBV3BQLENBQUEsSUFBS29QLFVBQUEsQ0FBV2tGLFdBQUEsSUFBZTlGLFVBQUE7VUFDbEosSUFBSXNoQixXQUFBLEVBQWE7WUFDZkYsR0FBQSxJQUFPO1VBQ1Q7UUFDRjtNQUNGLE9BQU87UUFFTCxTQUFTNXZCLENBQUEsR0FBSXNVLFdBQUEsR0FBYyxHQUFHdFUsQ0FBQSxJQUFLLEdBQUdBLENBQUEsSUFBSyxHQUFHO1VBQzVDLE1BQU04dkIsV0FBQSxHQUFjMWdCLFVBQUEsQ0FBV2tGLFdBQUEsSUFBZWxGLFVBQUEsQ0FBV3BQLENBQUEsSUFBS3dPLFVBQUE7VUFDOUQsSUFBSXNoQixXQUFBLEVBQWE7WUFDZkYsR0FBQSxJQUFPO1VBQ1Q7UUFDRjtNQUNGO0lBQ0Y7SUFDQSxPQUFPQSxHQUFBO0VBQ1Q7RUFDQXZWLE9BQUEsRUFBUztJQUNQLE1BQU1wWixNQUFBLEdBQVM7SUFDZixJQUFJLENBQUNBLE1BQUEsSUFBVUEsTUFBQSxDQUFPc0ksU0FBQSxFQUFXO0lBQ2pDLE1BQU07TUFDSjRGLFFBQUE7TUFDQTFOO0lBQ0YsSUFBSVIsTUFBQTtJQUVKLElBQUlRLE1BQUEsQ0FBT3FQLFdBQUEsRUFBYTtNQUN0QjdQLE1BQUEsQ0FBTzhuQixhQUFBLENBQWM7SUFDdkI7SUFDQSxDQUFDLEdBQUc5bkIsTUFBQSxDQUFPdEQsRUFBQSxDQUFHN0QsZ0JBQUEsQ0FBaUIsa0JBQWtCLENBQUMsRUFBRVgsT0FBQSxDQUFRMmUsT0FBQSxJQUFXO01BQ3JFLElBQUlBLE9BQUEsQ0FBUWlZLFFBQUEsRUFBVTtRQUNwQmxZLG9CQUFBLENBQXFCNVcsTUFBQSxFQUFRNlcsT0FBTztNQUN0QztJQUNGLENBQUM7SUFDRDdXLE1BQUEsQ0FBTzBNLFVBQUEsQ0FBVztJQUNsQjFNLE1BQUEsQ0FBT2tOLFlBQUEsQ0FBYTtJQUNwQmxOLE1BQUEsQ0FBTytVLGNBQUEsQ0FBZTtJQUN0Qi9VLE1BQUEsQ0FBT2tXLG1CQUFBLENBQW9CO0lBQzNCLFNBQVN3SSxjQUFBLEVBQWU7TUFDdEIsTUFBTXFRLGNBQUEsR0FBaUIvdUIsTUFBQSxDQUFPd04sWUFBQSxHQUFleE4sTUFBQSxDQUFPSSxTQUFBLEdBQVksS0FBS0osTUFBQSxDQUFPSSxTQUFBO01BQzVFLE1BQU1tYSxZQUFBLEdBQWVwWixJQUFBLENBQUtFLEdBQUEsQ0FBSUYsSUFBQSxDQUFLQyxHQUFBLENBQUkydEIsY0FBQSxFQUFnQi91QixNQUFBLENBQU9rVixZQUFBLENBQWEsQ0FBQyxHQUFHbFYsTUFBQSxDQUFPc1UsWUFBQSxDQUFhLENBQUM7TUFDcEd0VSxNQUFBLENBQU93WixZQUFBLENBQWFlLFlBQVk7TUFDaEN2YSxNQUFBLENBQU9nWSxpQkFBQSxDQUFrQjtNQUN6QmhZLE1BQUEsQ0FBT2tXLG1CQUFBLENBQW9CO0lBQzdCO0lBQ0EsSUFBSThZLFVBQUE7SUFDSixJQUFJeHVCLE1BQUEsQ0FBTzBqQixRQUFBLElBQVkxakIsTUFBQSxDQUFPMGpCLFFBQUEsQ0FBU3JXLE9BQUEsSUFBVyxDQUFDck4sTUFBQSxDQUFPNE8sT0FBQSxFQUFTO01BQ2pFc1AsYUFBQSxDQUFhO01BQ2IsSUFBSWxlLE1BQUEsQ0FBT3dWLFVBQUEsRUFBWTtRQUNyQmhXLE1BQUEsQ0FBTytTLGdCQUFBLENBQWlCO01BQzFCO0lBQ0YsT0FBTztNQUNMLEtBQUt2UyxNQUFBLENBQU9vUCxhQUFBLEtBQWtCLFVBQVVwUCxNQUFBLENBQU9vUCxhQUFBLEdBQWdCLE1BQU01UCxNQUFBLENBQU9vVixLQUFBLElBQVMsQ0FBQzVVLE1BQUEsQ0FBTzJPLGNBQUEsRUFBZ0I7UUFDM0csTUFBTXBCLE1BQUEsR0FBUy9OLE1BQUEsQ0FBTzROLE9BQUEsSUFBV3BOLE1BQUEsQ0FBT29OLE9BQUEsQ0FBUUMsT0FBQSxHQUFVN04sTUFBQSxDQUFPNE4sT0FBQSxDQUFRRyxNQUFBLEdBQVMvTixNQUFBLENBQU8rTixNQUFBO1FBQ3pGaWhCLFVBQUEsR0FBYWh2QixNQUFBLENBQU9vYixPQUFBLENBQVFyTixNQUFBLENBQU8zVixNQUFBLEdBQVMsR0FBRyxHQUFHLE9BQU8sSUFBSTtNQUMvRCxPQUFPO1FBQ0w0MkIsVUFBQSxHQUFhaHZCLE1BQUEsQ0FBT29iLE9BQUEsQ0FBUXBiLE1BQUEsQ0FBT3FULFdBQUEsRUFBYSxHQUFHLE9BQU8sSUFBSTtNQUNoRTtNQUNBLElBQUksQ0FBQzJiLFVBQUEsRUFBWTtRQUNmdFEsYUFBQSxDQUFhO01BQ2Y7SUFDRjtJQUNBLElBQUlsZSxNQUFBLENBQU82UixhQUFBLElBQWlCbkUsUUFBQSxLQUFhbE8sTUFBQSxDQUFPa08sUUFBQSxFQUFVO01BQ3hEbE8sTUFBQSxDQUFPc1MsYUFBQSxDQUFjO0lBQ3ZCO0lBQ0F0UyxNQUFBLENBQU9rSSxJQUFBLENBQUssUUFBUTtFQUN0QjtFQUNBMmlCLGdCQUFnQm9FLFlBQUEsRUFBY0MsVUFBQSxFQUFZO0lBQ3hDLElBQUlBLFVBQUEsS0FBZSxRQUFRO01BQ3pCQSxVQUFBLEdBQWE7SUFDZjtJQUNBLE1BQU1sdkIsTUFBQSxHQUFTO0lBQ2YsTUFBTW12QixnQkFBQSxHQUFtQm52QixNQUFBLENBQU9RLE1BQUEsQ0FBT3VhLFNBQUE7SUFDdkMsSUFBSSxDQUFDa1UsWUFBQSxFQUFjO01BRWpCQSxZQUFBLEdBQWVFLGdCQUFBLEtBQXFCLGVBQWUsYUFBYTtJQUNsRTtJQUNBLElBQUlGLFlBQUEsS0FBaUJFLGdCQUFBLElBQW9CRixZQUFBLEtBQWlCLGdCQUFnQkEsWUFBQSxLQUFpQixZQUFZO01BQ3JHLE9BQU9qdkIsTUFBQTtJQUNUO0lBQ0FBLE1BQUEsQ0FBT3RELEVBQUEsQ0FBRytGLFNBQUEsQ0FBVXFRLE1BQUEsQ0FBTyxHQUFHOVMsTUFBQSxDQUFPUSxNQUFBLENBQU9rUyxzQkFBQSxHQUF5QnljLGdCQUFBLEVBQWtCO0lBQ3ZGbnZCLE1BQUEsQ0FBT3RELEVBQUEsQ0FBRytGLFNBQUEsQ0FBVUMsR0FBQSxDQUFJLEdBQUcxQyxNQUFBLENBQU9RLE1BQUEsQ0FBT2tTLHNCQUFBLEdBQXlCdWMsWUFBQSxFQUFjO0lBQ2hGanZCLE1BQUEsQ0FBT3FxQixvQkFBQSxDQUFxQjtJQUM1QnJxQixNQUFBLENBQU9RLE1BQUEsQ0FBT3VhLFNBQUEsR0FBWWtVLFlBQUE7SUFDMUJqdkIsTUFBQSxDQUFPK04sTUFBQSxDQUFPN1YsT0FBQSxDQUFRMkosT0FBQSxJQUFXO01BQy9CLElBQUlvdEIsWUFBQSxLQUFpQixZQUFZO1FBQy9CcHRCLE9BQUEsQ0FBUXpJLEtBQUEsQ0FBTStNLEtBQUEsR0FBUTtNQUN4QixPQUFPO1FBQ0x0RSxPQUFBLENBQVF6SSxLQUFBLENBQU1pTixNQUFBLEdBQVM7TUFDekI7SUFDRixDQUFDO0lBQ0RyRyxNQUFBLENBQU9rSSxJQUFBLENBQUssaUJBQWlCO0lBQzdCLElBQUlnbkIsVUFBQSxFQUFZbHZCLE1BQUEsQ0FBT29aLE1BQUEsQ0FBTztJQUM5QixPQUFPcFosTUFBQTtFQUNUO0VBQ0FvdkIsd0JBQXdCclUsU0FBQSxFQUFXO0lBQ2pDLE1BQU0vYSxNQUFBLEdBQVM7SUFDZixJQUFJQSxNQUFBLENBQU95TixHQUFBLElBQU9zTixTQUFBLEtBQWMsU0FBUyxDQUFDL2EsTUFBQSxDQUFPeU4sR0FBQSxJQUFPc04sU0FBQSxLQUFjLE9BQU87SUFDN0UvYSxNQUFBLENBQU95TixHQUFBLEdBQU1zTixTQUFBLEtBQWM7SUFDM0IvYSxNQUFBLENBQU93TixZQUFBLEdBQWV4TixNQUFBLENBQU9RLE1BQUEsQ0FBT3VhLFNBQUEsS0FBYyxnQkFBZ0IvYSxNQUFBLENBQU95TixHQUFBO0lBQ3pFLElBQUl6TixNQUFBLENBQU95TixHQUFBLEVBQUs7TUFDZHpOLE1BQUEsQ0FBT3RELEVBQUEsQ0FBRytGLFNBQUEsQ0FBVUMsR0FBQSxDQUFJLEdBQUcxQyxNQUFBLENBQU9RLE1BQUEsQ0FBT2tTLHNCQUFBLEtBQTJCO01BQ3BFMVMsTUFBQSxDQUFPdEQsRUFBQSxDQUFHbUUsR0FBQSxHQUFNO0lBQ2xCLE9BQU87TUFDTGIsTUFBQSxDQUFPdEQsRUFBQSxDQUFHK0YsU0FBQSxDQUFVcVEsTUFBQSxDQUFPLEdBQUc5UyxNQUFBLENBQU9RLE1BQUEsQ0FBT2tTLHNCQUFBLEtBQTJCO01BQ3ZFMVMsTUFBQSxDQUFPdEQsRUFBQSxDQUFHbUUsR0FBQSxHQUFNO0lBQ2xCO0lBQ0FiLE1BQUEsQ0FBT29aLE1BQUEsQ0FBTztFQUNoQjtFQUNBaVcsTUFBTXJ0QixPQUFBLEVBQVM7SUFDYixNQUFNaEMsTUFBQSxHQUFTO0lBQ2YsSUFBSUEsTUFBQSxDQUFPc3ZCLE9BQUEsRUFBUyxPQUFPO0lBRzNCLElBQUk1eUIsRUFBQSxHQUFLc0YsT0FBQSxJQUFXaEMsTUFBQSxDQUFPUSxNQUFBLENBQU85RCxFQUFBO0lBQ2xDLElBQUksT0FBT0EsRUFBQSxLQUFPLFVBQVU7TUFDMUJBLEVBQUEsR0FBS3RDLFFBQUEsQ0FBU3hCLGFBQUEsQ0FBYzhELEVBQUU7SUFDaEM7SUFDQSxJQUFJLENBQUNBLEVBQUEsRUFBSTtNQUNQLE9BQU87SUFDVDtJQUNBQSxFQUFBLENBQUdzRCxNQUFBLEdBQVNBLE1BQUE7SUFDWixJQUFJdEQsRUFBQSxDQUFHNnlCLFVBQUEsSUFBYzd5QixFQUFBLENBQUc2eUIsVUFBQSxDQUFXNTFCLElBQUEsSUFBUStDLEVBQUEsQ0FBRzZ5QixVQUFBLENBQVc1MUIsSUFBQSxDQUFLaEIsUUFBQSxLQUFhcUgsTUFBQSxDQUFPUSxNQUFBLENBQU8rckIscUJBQUEsQ0FBc0JpRCxXQUFBLENBQVksR0FBRztNQUM1SHh2QixNQUFBLENBQU93VCxTQUFBLEdBQVk7SUFDckI7SUFDQSxNQUFNaWMsa0JBQUEsR0FBcUJBLENBQUEsS0FBTTtNQUMvQixPQUFPLEtBQUt6dkIsTUFBQSxDQUFPUSxNQUFBLENBQU9xc0IsWUFBQSxJQUFnQixJQUFJOXdCLElBQUEsQ0FBSyxFQUFFQyxLQUFBLENBQU0sR0FBRyxFQUFFeUIsSUFBQSxDQUFLLEdBQUc7SUFDMUU7SUFDQSxNQUFNaXlCLFVBQUEsR0FBYUEsQ0FBQSxLQUFNO01BQ3ZCLElBQUloekIsRUFBQSxJQUFNQSxFQUFBLENBQUdvRixVQUFBLElBQWNwRixFQUFBLENBQUdvRixVQUFBLENBQVdsSixhQUFBLEVBQWU7UUFDdEQsTUFBTSsyQixHQUFBLEdBQU1qekIsRUFBQSxDQUFHb0YsVUFBQSxDQUFXbEosYUFBQSxDQUFjNjJCLGtCQUFBLENBQW1CLENBQUM7UUFFNUQsT0FBT0UsR0FBQTtNQUNUO01BQ0EsT0FBTzV0QixlQUFBLENBQWdCckYsRUFBQSxFQUFJK3lCLGtCQUFBLENBQW1CLENBQUMsRUFBRTtJQUNuRDtJQUVBLElBQUkvdUIsU0FBQSxHQUFZZ3ZCLFVBQUEsQ0FBVztJQUMzQixJQUFJLENBQUNodkIsU0FBQSxJQUFhVixNQUFBLENBQU9RLE1BQUEsQ0FBT2dzQixjQUFBLEVBQWdCO01BQzlDOXJCLFNBQUEsR0FBWXpILGFBQUEsQ0FBYyxPQUFPK0csTUFBQSxDQUFPUSxNQUFBLENBQU9xc0IsWUFBWTtNQUMzRG53QixFQUFBLENBQUcyaEIsTUFBQSxDQUFPM2QsU0FBUztNQUNuQnFCLGVBQUEsQ0FBZ0JyRixFQUFBLEVBQUksSUFBSXNELE1BQUEsQ0FBT1EsTUFBQSxDQUFPd04sVUFBQSxFQUFZLEVBQUU5VixPQUFBLENBQVEySixPQUFBLElBQVc7UUFDckVuQixTQUFBLENBQVUyZCxNQUFBLENBQU94YyxPQUFPO01BQzFCLENBQUM7SUFDSDtJQUNBaEssTUFBQSxDQUFPb1YsTUFBQSxDQUFPak4sTUFBQSxFQUFRO01BQ3BCdEQsRUFBQTtNQUNBZ0UsU0FBQTtNQUNBNE0sUUFBQSxFQUFVdE4sTUFBQSxDQUFPd1QsU0FBQSxJQUFhLENBQUM5VyxFQUFBLENBQUc2eUIsVUFBQSxDQUFXNTFCLElBQUEsQ0FBS2kyQixVQUFBLEdBQWFsekIsRUFBQSxDQUFHNnlCLFVBQUEsQ0FBVzUxQixJQUFBLEdBQU8rRyxTQUFBO01BQ3BGK0osTUFBQSxFQUFRekssTUFBQSxDQUFPd1QsU0FBQSxHQUFZOVcsRUFBQSxDQUFHNnlCLFVBQUEsQ0FBVzUxQixJQUFBLEdBQU8rQyxFQUFBO01BQ2hENHlCLE9BQUEsRUFBUztNQUVUN2hCLEdBQUEsRUFBSy9RLEVBQUEsQ0FBR21FLEdBQUEsQ0FBSXVHLFdBQUEsQ0FBWSxNQUFNLFNBQVNsRCxZQUFBLENBQWF4SCxFQUFBLEVBQUksV0FBVyxNQUFNO01BQ3pFOFEsWUFBQSxFQUFjeE4sTUFBQSxDQUFPUSxNQUFBLENBQU91YSxTQUFBLEtBQWMsaUJBQWlCcmUsRUFBQSxDQUFHbUUsR0FBQSxDQUFJdUcsV0FBQSxDQUFZLE1BQU0sU0FBU2xELFlBQUEsQ0FBYXhILEVBQUEsRUFBSSxXQUFXLE1BQU07TUFDL0hnUixRQUFBLEVBQVV4SixZQUFBLENBQWF4RCxTQUFBLEVBQVcsU0FBUyxNQUFNO0lBQ25ELENBQUM7SUFDRCxPQUFPO0VBQ1Q7RUFDQTRKLEtBQUs1TixFQUFBLEVBQUk7SUFDUCxNQUFNc0QsTUFBQSxHQUFTO0lBQ2YsSUFBSUEsTUFBQSxDQUFPdUksV0FBQSxFQUFhLE9BQU92SSxNQUFBO0lBQy9CLE1BQU1zdkIsT0FBQSxHQUFVdHZCLE1BQUEsQ0FBT3F2QixLQUFBLENBQU0zeUIsRUFBRTtJQUMvQixJQUFJNHlCLE9BQUEsS0FBWSxPQUFPLE9BQU90dkIsTUFBQTtJQUM5QkEsTUFBQSxDQUFPa0ksSUFBQSxDQUFLLFlBQVk7SUFHeEIsSUFBSWxJLE1BQUEsQ0FBT1EsTUFBQSxDQUFPcVAsV0FBQSxFQUFhO01BQzdCN1AsTUFBQSxDQUFPOG5CLGFBQUEsQ0FBYztJQUN2QjtJQUdBOW5CLE1BQUEsQ0FBTytyQixVQUFBLENBQVc7SUFHbEIvckIsTUFBQSxDQUFPME0sVUFBQSxDQUFXO0lBR2xCMU0sTUFBQSxDQUFPa04sWUFBQSxDQUFhO0lBQ3BCLElBQUlsTixNQUFBLENBQU9RLE1BQUEsQ0FBTzZSLGFBQUEsRUFBZTtNQUMvQnJTLE1BQUEsQ0FBT3NTLGFBQUEsQ0FBYztJQUN2QjtJQUdBLElBQUl0UyxNQUFBLENBQU9RLE1BQUEsQ0FBT3FnQixVQUFBLElBQWM3Z0IsTUFBQSxDQUFPNk4sT0FBQSxFQUFTO01BQzlDN04sTUFBQSxDQUFPc2dCLGFBQUEsQ0FBYztJQUN2QjtJQUdBLElBQUl0Z0IsTUFBQSxDQUFPUSxNQUFBLENBQU95USxJQUFBLElBQVFqUixNQUFBLENBQU80TixPQUFBLElBQVc1TixNQUFBLENBQU9RLE1BQUEsQ0FBT29OLE9BQUEsQ0FBUUMsT0FBQSxFQUFTO01BQ3pFN04sTUFBQSxDQUFPb2IsT0FBQSxDQUFRcGIsTUFBQSxDQUFPUSxNQUFBLENBQU9zYixZQUFBLEdBQWU5YixNQUFBLENBQU80TixPQUFBLENBQVF3RCxZQUFBLEVBQWMsR0FBR3BSLE1BQUEsQ0FBT1EsTUFBQSxDQUFPb1ksa0JBQUEsRUFBb0IsT0FBTyxJQUFJO0lBQzNILE9BQU87TUFDTDVZLE1BQUEsQ0FBT29iLE9BQUEsQ0FBUXBiLE1BQUEsQ0FBT1EsTUFBQSxDQUFPc2IsWUFBQSxFQUFjLEdBQUc5YixNQUFBLENBQU9RLE1BQUEsQ0FBT29ZLGtCQUFBLEVBQW9CLE9BQU8sSUFBSTtJQUM3RjtJQUdBLElBQUk1WSxNQUFBLENBQU9RLE1BQUEsQ0FBT3lRLElBQUEsRUFBTTtNQUN0QmpSLE1BQUEsQ0FBTytkLFVBQUEsQ0FBVztJQUNwQjtJQUdBL2QsTUFBQSxDQUFPbXBCLFlBQUEsQ0FBYTtJQUNwQixNQUFNMEcsWUFBQSxHQUFlLENBQUMsR0FBRzd2QixNQUFBLENBQU90RCxFQUFBLENBQUc3RCxnQkFBQSxDQUFpQixrQkFBa0IsQ0FBQztJQUN2RSxJQUFJbUgsTUFBQSxDQUFPd1QsU0FBQSxFQUFXO01BQ3BCcWMsWUFBQSxDQUFhaHNCLElBQUEsQ0FBSyxHQUFHN0QsTUFBQSxDQUFPeUssTUFBQSxDQUFPNVIsZ0JBQUEsQ0FBaUIsa0JBQWtCLENBQUM7SUFDekU7SUFDQWczQixZQUFBLENBQWEzM0IsT0FBQSxDQUFRMmUsT0FBQSxJQUFXO01BQzlCLElBQUlBLE9BQUEsQ0FBUWlZLFFBQUEsRUFBVTtRQUNwQmxZLG9CQUFBLENBQXFCNVcsTUFBQSxFQUFRNlcsT0FBTztNQUN0QyxPQUFPO1FBQ0xBLE9BQUEsQ0FBUXRlLGdCQUFBLENBQWlCLFFBQVE4RCxDQUFBLElBQUs7VUFDcEN1YSxvQkFBQSxDQUFxQjVXLE1BQUEsRUFBUTNELENBQUEsQ0FBRXRFLE1BQU07UUFDdkMsQ0FBQztNQUNIO0lBQ0YsQ0FBQztJQUNEcWYsT0FBQSxDQUFRcFgsTUFBTTtJQUdkQSxNQUFBLENBQU91SSxXQUFBLEdBQWM7SUFDckI2TyxPQUFBLENBQVFwWCxNQUFNO0lBR2RBLE1BQUEsQ0FBT2tJLElBQUEsQ0FBSyxNQUFNO0lBQ2xCbEksTUFBQSxDQUFPa0ksSUFBQSxDQUFLLFdBQVc7SUFDdkIsT0FBT2xJLE1BQUE7RUFDVDtFQUNBMkssUUFBUW1sQixjQUFBLEVBQWdCQyxXQUFBLEVBQWE7SUFDbkMsSUFBSUQsY0FBQSxLQUFtQixRQUFRO01BQzdCQSxjQUFBLEdBQWlCO0lBQ25CO0lBQ0EsSUFBSUMsV0FBQSxLQUFnQixRQUFRO01BQzFCQSxXQUFBLEdBQWM7SUFDaEI7SUFDQSxNQUFNL3ZCLE1BQUEsR0FBUztJQUNmLE1BQU07TUFDSlEsTUFBQTtNQUNBOUQsRUFBQTtNQUNBZ0UsU0FBQTtNQUNBcU47SUFDRixJQUFJL04sTUFBQTtJQUNKLElBQUksT0FBT0EsTUFBQSxDQUFPUSxNQUFBLEtBQVcsZUFBZVIsTUFBQSxDQUFPc0ksU0FBQSxFQUFXO01BQzVELE9BQU87SUFDVDtJQUNBdEksTUFBQSxDQUFPa0ksSUFBQSxDQUFLLGVBQWU7SUFHM0JsSSxNQUFBLENBQU91SSxXQUFBLEdBQWM7SUFHckJ2SSxNQUFBLENBQU9xcEIsWUFBQSxDQUFhO0lBR3BCLElBQUk3b0IsTUFBQSxDQUFPeVEsSUFBQSxFQUFNO01BQ2ZqUixNQUFBLENBQU9tZ0IsV0FBQSxDQUFZO0lBQ3JCO0lBR0EsSUFBSTRQLFdBQUEsRUFBYTtNQUNmL3ZCLE1BQUEsQ0FBT2lzQixhQUFBLENBQWM7TUFDckJ2dkIsRUFBQSxDQUFHeWEsZUFBQSxDQUFnQixPQUFPO01BQzFCelcsU0FBQSxDQUFVeVcsZUFBQSxDQUFnQixPQUFPO01BQ2pDLElBQUlwSixNQUFBLElBQVVBLE1BQUEsQ0FBTzNWLE1BQUEsRUFBUTtRQUMzQjJWLE1BQUEsQ0FBTzdWLE9BQUEsQ0FBUTJKLE9BQUEsSUFBVztVQUN4QkEsT0FBQSxDQUFRWSxTQUFBLENBQVVxUSxNQUFBLENBQU90UyxNQUFBLENBQU9vVSxpQkFBQSxFQUFtQnBVLE1BQUEsQ0FBT3FVLHNCQUFBLEVBQXdCclUsTUFBQSxDQUFPZ1csZ0JBQUEsRUFBa0JoVyxNQUFBLENBQU9pVyxjQUFBLEVBQWdCalcsTUFBQSxDQUFPa1csY0FBYztVQUN2SjdVLE9BQUEsQ0FBUXNWLGVBQUEsQ0FBZ0IsT0FBTztVQUMvQnRWLE9BQUEsQ0FBUXNWLGVBQUEsQ0FBZ0IseUJBQXlCO1FBQ25ELENBQUM7TUFDSDtJQUNGO0lBQ0FuWCxNQUFBLENBQU9rSSxJQUFBLENBQUssU0FBUztJQUdyQnJRLE1BQUEsQ0FBT0ksSUFBQSxDQUFLK0gsTUFBQSxDQUFPbUwsZUFBZSxFQUFFalQsT0FBQSxDQUFRMjFCLFNBQUEsSUFBYTtNQUN2RDd0QixNQUFBLENBQU93TCxHQUFBLENBQUlxaUIsU0FBUztJQUN0QixDQUFDO0lBQ0QsSUFBSWlDLGNBQUEsS0FBbUIsT0FBTztNQUM1Qjl2QixNQUFBLENBQU90RCxFQUFBLENBQUdzRCxNQUFBLEdBQVM7TUFDbkI3RCxXQUFBLENBQVk2RCxNQUFNO0lBQ3BCO0lBQ0FBLE1BQUEsQ0FBT3NJLFNBQUEsR0FBWTtJQUNuQixPQUFPO0VBQ1Q7RUFDQSxPQUFPMG5CLGVBQWVDLFdBQUEsRUFBYTtJQUNqQ3R4QixPQUFBLENBQU8wdUIsZ0JBQUEsRUFBa0I0QyxXQUFXO0VBQ3RDO0VBQ0EsV0FBVzVDLGlCQUFBLEVBQW1CO0lBQzVCLE9BQU9BLGdCQUFBO0VBQ1Q7RUFDQSxXQUFXZixTQUFBLEVBQVc7SUFDcEIsT0FBT0EsUUFBQTtFQUNUO0VBQ0EsT0FBTzRELGNBQWN4QyxHQUFBLEVBQUs7SUFDeEIsSUFBSSxDQUFDdDJCLE1BQUEsQ0FBT2dILFNBQUEsQ0FBVXF2QixXQUFBLEVBQWFyMkIsTUFBQSxDQUFPZ0gsU0FBQSxDQUFVcXZCLFdBQUEsR0FBYyxFQUFDO0lBQ25FLE1BQU1ELE9BQUEsR0FBVXAyQixNQUFBLENBQU9nSCxTQUFBLENBQVVxdkIsV0FBQTtJQUNqQyxJQUFJLE9BQU9DLEdBQUEsS0FBUSxjQUFjRixPQUFBLENBQVF0dUIsT0FBQSxDQUFRd3VCLEdBQUcsSUFBSSxHQUFHO01BQ3pERixPQUFBLENBQVEzcEIsSUFBQSxDQUFLNnBCLEdBQUc7SUFDbEI7RUFDRjtFQUNBLE9BQU95QyxJQUFJQyxPQUFBLEVBQVE7SUFDakIsSUFBSXp0QixLQUFBLENBQU1DLE9BQUEsQ0FBUXd0QixPQUFNLEdBQUc7TUFDekJBLE9BQUEsQ0FBT2w0QixPQUFBLENBQVFtNEIsQ0FBQSxJQUFLajVCLE1BQUEsQ0FBTzg0QixhQUFBLENBQWNHLENBQUMsQ0FBQztNQUMzQyxPQUFPajVCLE1BQUE7SUFDVDtJQUNBQSxNQUFBLENBQU84NEIsYUFBQSxDQUFjRSxPQUFNO0lBQzNCLE9BQU9oNUIsTUFBQTtFQUNUO0FBQ0Y7QUFDQVMsTUFBQSxDQUFPSSxJQUFBLENBQUttMUIsVUFBVSxFQUFFbDFCLE9BQUEsQ0FBUW80QixjQUFBLElBQWtCO0VBQ2hEejRCLE1BQUEsQ0FBT0ksSUFBQSxDQUFLbTFCLFVBQUEsQ0FBV2tELGNBQUEsQ0FBZSxFQUFFcDRCLE9BQUEsQ0FBUXE0QixXQUFBLElBQWU7SUFDN0RuNUIsTUFBQSxDQUFPZ0gsU0FBQSxDQUFVbXlCLFdBQUEsSUFBZW5ELFVBQUEsQ0FBV2tELGNBQUEsRUFBZ0JDLFdBQUE7RUFDN0QsQ0FBQztBQUNILENBQUM7QUFDRG41QixNQUFBLENBQU8rNEIsR0FBQSxDQUFJLENBQUNub0IsTUFBQSxFQUFRdUIsUUFBUSxDQUFDOzs7QUhyekg3QixJQUFPalMscUJBQUEsR0FBUUYsTUFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiL2NsaWVudC9vdXQifQ==